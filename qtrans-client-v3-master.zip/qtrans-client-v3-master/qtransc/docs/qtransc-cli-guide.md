# qtransc 命令行工具指南

## 常见命令

```bash
qtransc --server <host[:port]> [认证参数] <command> [命令参数]
```

### 浏览和管理远端文件

```bash
# 浏览根目录或指定目录
qtransc --server qt.example.com:23500 list /
qtransc --server qt.example.com:23500 list /project/data

# 创建目录树
qtransc --server qt.example.com:23500 mkdir /project/releases

# 移动或重命名
qtransc --server qt.example.com:23500 \
  move /project/aaa.txt /archive/bbb.txt

# 删除文件或空目录
qtransc --server qt.example.com:23500 delete /archive/bbb.txt

# 递归删除目录
qtransc --server qt.example.com:23500 delete -r /archive/old
```

不带 `-r` 或 `--recursive` 时只能删除文件或空目录。根路径 `/` 不允许删除。

### 下载文件或目录

```bash
# 下载到默认目录 $HOME/qtransdownload
qtransc --server qt.example.com download /public/aaa.txt

# 下载到指定目录
mkdir -p ./downloads
qtransc --server qt.example.com \
  download /public/aaa.txt ./downloads

# 下载目录
qtransc --server qt.example.com \
  download /public/dataset ./downloads

# 下载多个文件或目录
qtransc --server qt.example.com download \
  --source /public/aaa.txt \
  --source /public/bbb.txt \
  --destination ./downloads

# 限制整个下载任务的速度
qtransc --server qt.example.com \
  --limit-rate 20MiB/s \
  download /public/dataset ./downloads
```

显式指定的本地下载目录必须已经存在。普通大文件会在目标文件旁保存 `<文件名>.progress` 断点信息，成功后自动删除。

下载也支持 UTF-8 文件清单，每个非空行填写一个远端绝对路径：

```text
/public/aaa.txt
/public/bbb.txt
```

```bash
qtransc --server qt.example.com download \
  --filelist ./bbb.txt \
  --destination ./downloads
```

### 上传文件或目录

```bash
# 上传单个文件
qtransc --server qt.example.com:23500 \
  upload ./aaa.txt /incoming

# 上传目录
qtransc --server qt.example.com:23500 \
  upload ./dataset /incoming

# 上传多个文件或目录
qtransc --server qt.example.com:23500 upload \
  --source ./aaa.txt \
  --source ./bbb.txt \
  --destination /incoming

# 限制任务总速度和总大小
qtransc --server qt.example.com:23500 \
  --limit-rate 10MiB/s \
  upload --limit-size 100GiB ./dataset /incoming
```

远端目标始终按目录解释：

- `upload ./aaa.txt /incoming` 生成 `/incoming/aaa.txt`。
- `upload ./dataset /incoming` 生成 `/incoming/dataset/...`。
- 空目录会保留。

也可以使用 UTF-8 文件清单，每个非空行填写一个本地绝对路径：

```text
/data/run-01/aaa.txt
/data/run-02/bbb.txt
/data/metadata
```

```bash
qtransc --server qt.example.com upload \
  --filelist ./aaa.txt \
  --destination /incoming
```

## 认证相关

前面的示例中，我们使用了匿名访问，实际访问的是anonymous这个用户的家目录。也可以使用 token 或用户名和密码认证。

```bash
# 匿名访问
qtransc --server qt.example.com:23500 list /

# 使用 token
export QTRANSC_TOKEN='replace-with-your-token'
qtransc --server qt.example.com:23500 \
  --auth-token "$QTRANSC_TOKEN" \
  list /

# 使用用户名和密码
qtransc --server qt.example.com:23500 \
  --auth-username 'user@example.com' \
  --auth-password 'password' \
  list /
```

### 调整 transport 和并发

```bash
qtransc --server qt.example.com \
  --transport v3 \
  --connections 2 \
  --streams 8 \
  --transfers 4 \
  download /public/dataset ./downloads
```

- `--transport` 可选 `v3`、`v2` 或 `v1`，默认 `v3`。
- `--connections` 是每次任务执行、每个服务地址的连接数上限，默认 `10`，按需建连。
- `--streams` 默认 `1`；使用 `v1` 时，调大该值不会增加并发，当前只接受 `1`。
- `--transfers` 是普通文件并发数，默认 `5`。
- 三种 transport 之间不会自动回退。

普通文件共享 `connections × streams` 个分片操作额度，不再按 `transfers` 平均分配。比如连接数 `3`、每连接请求数 `3`、文件并发 `3`，只有一个文件且分片充足时，也可以并发处理 `9` 个分片。分片重试等待仍占用分片额度，因此实际在途请求数可能更少。