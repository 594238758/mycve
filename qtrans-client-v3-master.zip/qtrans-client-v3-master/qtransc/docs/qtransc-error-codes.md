# QTrans 错误码注册表

本文是 `qtransc serve` 错误码、固定英文 message、meta 和研发触发条件的唯一权威源

## 使用规则

- HTTP 成功查询失败任务时，外层仍为 `0/Success`，执行错误放在 `data.error`；列表项和文件视图遵循同一规则。
- 每个错误包含固定安全英文 `message` 和 `meta{retryable,visible}`，两个布尔值始终显式输出。message 不拼接底层错误、绝对路径、token 或请求头。
- API 的 `retryable` 表示允许重试该请求；执行错误的 `retryable` 表示默认恢复建议，仍须遵守对应操作的重试条件。创建任务时显式设置 `autoRetry=true`，表示调用方选择对全部执行失败重新排队，不以 `retryable` 为筛选条件；各错误的固定元数据不因此改变。该选择只启动新一轮任务，不授权盲目重复结果未知的写请求。
- 源文件变化默认要求新建任务。启用 `autoRetry` 后允许保留客户端任务 ID，但必须重新读取源文件、计算指纹和哈希，并为新内容生成新的服务端执行 ID；不得恢复变化文件的旧上传会话。
- `visible` 表示固定 message 是否允许直接展示给最终用户。

## 号码选取规则

- 成功使用 `code=0`、`message="Success"`，省略当前信封的 `meta`。
- 错误码不决定责任归属；首位 `3` 表示结论由 QTrans 给出。
- `30xxx` 表达 API 请求失败，只能出现在 HTTP 顶层；`31xxx` 表达任务或文件执行失败，出现在 SSE 顶层或 HTTP 任务、文件数据的 `error` 对象。
- 非法、未登记、成功码或跨类别码用于构造失败时，API 归一为 `30999`，执行错误归一为 `31999`，同时使用对应的固定 message/meta。

## 变更规则

code、默认 message、retryable、visible、适用对象、研发触发条件和归一规则均属于稳定规范。先修改本文并由维护者审核，再同步 OpenSpec，最后同步编译期集中登记、分类器和 HTTP/SSE 转换。OpenSpec 不复制完整码表，综合 API 文档只链接本文。

## 码表

以下是一张表：上半部分为 API 请求错误，下半部分为执行错误。新增 API 错误插入上半部分；新增执行错误插入下半部分。预留项不代表已有触发路径。

任务因执行故障终止时统一为 `failed`；明确暂停、停止及正常停服逐个停止任务时使用 `stopped` 且无执行错误。文件失败及随后任务失败事件使用相应执行错误码，后续 HTTP 查询可取得当前错误。

|    code | 默认 message                             | retryable | visible | 适用对象        | 研发触发条件                                                        |
| ------: | -------------------------------------- | :-------: | :-----: | ----------- | ------------------------------------------------------------- |
| `30001` | `QTrans request invalid`               |  `false`  | `false` | API 请求      | 调用方提交的 serve 请求格式、字段、参数、接口路径或 HTTP method 不符合要求               |
| `30002` | `QTrans access denied`                 |  `false`  | `false` | API 请求      | 调用方访问受保护的 qtransc serve 接口时，没有提供正确的访问密钥                       |
| `30003` | `Authentication configuration invalid` |  `false`  | `false` | API 请求      | qtransc 需要使用认证信息，但当前没有可用凭证，或者现有认证方式无法完成这次操作                   |
| `30004` | `Task already exists`                  |  `false`  | `false` | API 请求      | 创建任务时，当前 qtransc 进程中已经有一个尚未删除的相同 `taskId` 任务                  |
| `30005` | `Task not found`                       |  `false`  | `false` | API 请求      | 调用方要查询、启动、暂停或删除的任务在当前 qtransc 进程中不存在                          |
| `30006` | `Task state conflict`                  |  `false`  | `false` | API 请求      | 任务存在，但当前状态不允许执行这次操作，例如运行中的任务被再次启动，或已完成的任务被暂停                  |
| `30007` | `Task capacity exceeded`               |   `true`  | `false` | API 请求      | qtransc 的运行名额或等待队列已经占满，暂时无法接收这个任务                             |
| `30008` | `Task file limit exceeded`             |  `false`  |  `true` | API 请求      | 创建请求中显式提交的 `fileList` 项数超过允许上限，任务不被接受                         |
| `30009` | `QTrans service shutting down`         |  `false`  | `false` | API 请求      | serve 正在关闭，暂不接受新的创建或启动任务请求                                    |
| `30999` | `QTrans internal error`                |  `false`  |  `true` | API 请求      | qtransc 遇到了未预料到的程序错误，或者这个错误暂时无法归入其他已定义的错误码                    |
| `31001` | `QTrans request invalid`               |  `false`  | `false` | 任务 / 文件     | 已接受任务执行时发现执行参数或向下游提交的请求无效；不包括 serve 请求的 JSON 解码错误             |
| `31002` | `Authentication configuration invalid` |  `false`  | `false` | 任务 / 文件     | qtransc 需要使用认证信息，但当前没有可用凭证，或者现有认证方式无法完成这次操作                   |
| `31003` | `Authentication rejected`              |  `false`  | `false` | 任务 / 文件     | qtransc 已经把凭证交给 Qtserver 或认证服务，但对方拒绝了该凭证                      |
| `31004` | `File size limit exceeded`             |  `false`  |  `true` | 任务 / 文件     | 任务中的某个文件超过了允许的单文件大小                                           |
| `31005` | `Task file limit exceeded`             |  `false`  |  `true` | 任务 / 文件     | 已接受任务在目录展开、去重或执行规划时发现普通文件数量超过允许上限                             |
| `31006` | `Task size limit exceeded`             |  `false`  |  `true` | 任务 / 文件（预留） | 任务中所有文件的总大小超过了允许上限                                            |
| `31007` | `Local resource not found`             |  `false`  |  `true` | 任务 / 文件     | 上传时找不到调用方指定的本地文件或目录                                           |
| `31008` | `Local path unavailable`               |  `false`  |  `true` | 任务 / 文件     | qtransc 能找到本地路径，但无法正常读取、创建或写入，例如路径不可用或没有权限                    |
| `31009` | `Insufficient disk space`              |  `false`  |  `true` | 任务 / 文件     | qtransc 要写入的磁盘剩余空间不足，无法安全保存文件                                 |
| `31010` | `Local file changed`                   |  `false`  | `false` | 任务 / 文件     | 上传任务执行期间，源文件被修改、替换，或者已经不再是创建任务时的那个文件                          |
| `31011` | `Remote resource not found`            |   `true`  |  `true` | 任务 / 文件     | qtransc 要读取或操作的远端文件或目录不存在                                     |
| `31012` | `Required capability unavailable`      |  `false`  |  `true` | 任务 / 文件     | Qtserver 当前不支持完成这次操作所需要的版本、功能、文件类型或访问方式                       |
| `31013` | `Integrity check failed`               |   `true`  | `false` | 任务 / 文件     | 文件下载完成后，实际内容与预期的校验结果不一致                                       |
| `31014` | `Remote state conflict`                |   `true`  | `false` | 任务 / 文件     | 远端文件或目录仍然存在，但状态已经变化，导致当前操作不能继续，例如文件被改动或目录不是空的                 |
| `31015` | `Downstream service unavailable`       |   `true`  |  `true` | 任务 / 文件     | qtransc 调用 Qtserver 或认证服务时，在确认请求产生结果之前遇到网络、连接、超时或服务暂时不可用的问题   |
| `31016` | `Downstream service busy`              |   `true`  | `false` | 任务 / 文件     | qtransc 已经连上 Qtserver 等服务，但对方正忙、正在限制请求速度、相关资源被占用，或允许的等待时间已经用完 |
| `31017` | `Operation result unknown`             |  `false`  |  `true` | 任务 / 文件     | 请求可能已经被 Qtserver 等服务执行，或者只执行了一部分，但 qtransc 没有拿到明确的最终结果        |
| `31999` | `QTrans internal error`                |  `false`  |  `true` | 任务 / 文件     | qtransc 遇到了未预料到的程序错误，或者这个错误暂时无法归入其他已定义的错误码                    |
