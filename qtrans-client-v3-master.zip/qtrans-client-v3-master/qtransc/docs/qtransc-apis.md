# qtransc Serve API

## 基本约定

- 基础路径：`/api/v1`
- HTTP 请求/响应业务字段统一使用 lowerCamelCase.
- 所有时间字段，都使用RFC3339 UTC 时间字符串
- 错误响应包含稳定的数字 `code`、固定安全英文 `message` 和处置建议 `meta`；`data` 字段会被省略。完整定义见 [QTrans 错误码注册表](qtransc-error-codes.md)

通用成功响应格式：

```json
{
  "code": 0,
  "message": "Success"
}
```

通用错误响应格式：

```json
{
  "code": 30001,
  "message": "QTrans request invalid",
  "meta": {
    "retryable": false,
    "visible": false
  }
}
```

字段说明：

- `code`：机器可读业务响应码，`0` 表示本次 HTTP 请求成功，`30xxx` 表示请求失败；任务、文件的执行错误使用 `31xxx`
- `message`：码表中的固定安全英文文案；调用方不得解析该字段决定业务行为
- `data`：有载荷的成功响应数据体，可为对象或数组；无载荷成功和全部失败响应都省略
- `meta`：失败响应必填的处置建议，包含布尔字段 `retryable` 和 `visible`；成功响应省略

## 枚举与公共语义

### 任务状态 `status`

当前实现只有以下 5 种任务状态：

| 值           | 含义                                                           |
| ----------- | ------------------------------------------------------------ |
| `pending`   | 已创建或已重新排队，等待执行；经 `/start` 进入 pending 时可能仍显示上一轮进度、文件信息和时间     |
| `running`   | 正在执行                                                         |
| `completed` | 本轮已成功完成；可通过 `/start` 重新执行，例如目的端文件已被删除时重传                     |
| `stopped`   | 明确暂停、停止或正常停服时主动停止；无任务错误，可通过 `/start` 再次执行                    |
| `failed`    | 本轮执行失败，必带结构化错误；启用 `autoRetry` 时会自动重新排队，也可按规则通过 `/start` 再次执行 |

状态转移规则（实现层面）：

- `pending -> running | stopped`
- `running -> completed | stopped | failed`
- `stopped -> pending`
- `failed -> pending`
- `completed -> pending`

`pending` 中保留的上一轮进度和完成标记不代表当前正在传输，当前是否执行应以 `status` 为准。Retry 后 HTTP 查询会隐藏上一轮任务及文件错误，但进度、文件信息和执行时间仍可能保留到下一次 Run 初始化。

### SSE 事件类型 `messageType`

SSE 统一使用如下 JSON 包装：

```json
{
  "messageType": "qtrans.task.progress",
  "code": 0,
  "message": "Success",
  "data": {}
}
```

当前实现会实际推送 8 种事件：

| 事件类型                      | 当前是否实际推送 | 说明                                                |
| ------------------------- | -------- | ------------------------------------------------- |
| `qtrans.health.heartbeat` | 是        | 连接保活事件，默认每 `5s` 一条，可通过 `sse.heartbeatInterval` 调整 |
| `qtrans.task.status`      | 是        | 任务生命周期事件                                          |
| `qtrans.task.delete`      | 是        | 任务删除事件，不属于任务状态                                    |
| `qtrans.file.status`      | 是        | 文件生命周期事件                                          |
| `qtrans.chunk.status`     | 是        | 分片生命周期事件                                          |
| `qtrans.task.progress`    | 是        | 任务整体进度快照，周期由 `sse.progressInterval` 控制            |
| `qtrans.file.progress`    | 是        | 文件进度快照，周期由 `sse.progressInterval` 控制              |
| `qtrans.chunk.progress`   | 是        | 分片进度快照，周期由 `sse.progressInterval` 控制              |

SSE 顶层字段说明：

| 字段            | 类型      | 说明                                        |
| ------------- | ------- | ----------------------------------------- |
| `messageType` | string  | 事件类型                                      |
| `code`        | integer | `0` 或失败 `3xxxx`                           |
| `message`     | string  | 对应固定安全英文文案                                |
| `data`        | object  | 事件正文                                      |
| `meta`        | object  | 仅失败事件携带，包含 `retryable` 和 `visible` 两个布尔字段 |

各类 `data` 字段如下：

| `messageType`             | `data` 字段                                                         |
| ------------------------- | ----------------------------------------------------------------- |
| `qtrans.health.heartbeat` | `timestamp`                                                       |
| `qtrans.task.status`      | `taskId`, `status`                                                |
| `qtrans.task.delete`      | `taskId`                                                          |
| `qtrans.file.status`      | `taskId`, `fileKey`, `status`                                     |
| `qtrans.chunk.status`     | `taskId`, `fileKey`, `chunkIndex`, `status`                       |
| `qtrans.task.progress`    | `taskId`, `total`, `transferred`, `rate`                          |
| `qtrans.file.progress`    | `taskId`, `fileKey`, `total`, `transferred`, `rate`               |
| `qtrans.chunk.progress`   | `taskId`, `fileKey`, `chunkIndex`, `total`, `transferred`, `rate` |

说明：

- `fileKey` 当前实现优先使用规范化后的远端 `objectKey`，通常以 `/` 开头；仅在对象键为空时回退到本地相对路径
- SSE 不提供事件重放；任务错误不跨进程保存

## 数据模型

### 当前执行错误 `error`

任务和文件共用以下结构；其 code/message/meta 与对应 SSE 失败事件一致。`meta.retryable` 是默认恢复建议。显式启用 `autoRetry` 后，全部执行失败都会重新排队，包括 `retryable=false`；错误元数据保持不变。源文件变化时的恢复条件见[错误码规范](qtransc-error-codes.md)。

| 字段               | 类型      | 说明                            |
| ---------------- | ------- | ----------------------------- |
| `code`           | integer | 执行类五位错误码 `31xxx`              |
| `message`        | string  | 固定安全英文文案，不解析文本做业务判断           |
| `meta.retryable` | boolean | 默认是否建议恢复当前任务；显式包含 false       |
| `meta.visible`   | boolean | message 是否可直接展示给用户；显式包含 false |

成功查询失败任务的示例（省略其他任务业务字段）：

```json
{
  "code": 0,
  "message": "Success",
  "data": {
    "taskId": "task-123",
    "status": "failed",
    "error": {
      "code": 31009,
      "message": "Insufficient disk space",
      "meta": {"retryable": false, "visible": true}
    }
  }
}
```

### `HealthResponse.data`

| 字段        | 类型      | 说明            |
| --------- | ------- | ------------- |
| `me`      | string  | 固定为 `qtransc` |
| `pid`     | integer | 当前进程 PID      |
| `version` | string  | 版本号           |

### 创建任务请求体 `TaskCreateRequest`

顶层字段：

| 字段                     | 必填   | 类型              | 说明                                                                                    |
| ---------------------- | ---- | --------------- | ------------------------------------------------------------------------------------- |
| `taskId`               | 是    | string          | 调用方提供的任务 ID；去除首尾空白后非空，最多 128 字节                                                       |
| `taskPid`              | 否    | string          | 仅用于日志关联；首尾SP/HTAB会被trim，trim后允许为空，非空值最大128 bytes且必须能安全通过HTTP header传播                 |
| `enterpriseId`         | 否    | string          | 仅用于外部企业日志关联；校验与 `taskPid` 相同，不具有企业身份、tenant 或授权语义                                     |
| `callerVersion`        | 否    | string          | 调用方版本标签，最大 256 bytes                                                                  |
| `taskName`             | 是    | string          | 任务名称                                                                                  |
| `mode`                 | 是    | string          | `download` 或 `upload`                                                                 |
| `transport`            | 否    | string          | `https`、`https2`、`https3`；未传或为空时使用服务默认协议（内置默认 `https3`）                               |
| `connections`          | 否    | integer         | `1..1024`；未传时继承服务默认连接数                                                                |
| `streams`              | 否    | integer         | `https2/https3` 为 `1..1024`；未传时继承服务默认值；`https` 时固定为1设置无效                              |
| `transfers`            | 否    | integer         | 正整数；普通文件并发上限。未传时继承服务默认值；                                                              |
| `limitRateBytesPerSec` | 否    | integer         | 最大为 int64 上限；未传时不限速。                                                                  |
| `autoRetry`            | 否    | boolean         | `true` 启用失败后自动重新排队，每秒检查一次，次数不限；省略或 `false` 不启用；`null` 和非布尔值拒绝                         |
| `serverAddr`           | 是    | string          | qtserver origin，不能包含 path；远端 API 前缀固定为 `/qtserver/v1`                                 |
| `fileList`             | 是    | array           | 文件列表，至少 1 项；单任务最多 100000 个普通文件                                                        |
| `targetDir`            | 下载必填 | string          | 下载根目录；当前代码只校验非空                                                                       |
| `sourceDir`            | 上传必填 | string          | 上传根目录；当前代码只校验非空                                                                       |
| `dirPaths`             | 否    | array of string | 空目录列表；上传时表示远端逻辑路径，下载时表示 `targetDir` 下的本地相对路径；当前 HTTP 校验仍要求 `fileList` 至少 1 项，不能只提交空目录 |
| `bearerToken`          | 否    | string          | 不传或去除首尾空白后为空时按 anonymous 执行；传入非空值时，该任务固定使用去除首尾空白后的 token，不读取进程内 static token          |

- `fileList[]` 字段：

| 字段             | 下载任务 | 上传任务 | 说明                                                |
| -------------- | ---- | ---- | ------------------------------------------------- |
| `localRelPath` | 必填   | 必填   | 相对于任务根目录的相对路径；不能为绝对路径，不能通过 `..` 越界                |
| `remoteUrl`    | 必填   | 忽略   | **这里的实际语义是远端对象键**，不是完整下载 URL；会规范化为以 `/` 开头的逻辑绝对路径 |
| `objectKey`    | 忽略   | 必填   | 上传目标对象键；会规范化为以 `/` 开头的逻辑绝对路径                      |

下载任务示例：

```json
{
  "taskId": "download-demo-001",
  "taskPid": "external-business-123",
  "enterpriseId": "enterprise-42",
  "taskName": "download-demo",
  "mode": "download",
  "transport": "https3",
  "connections": 3,
  "streams": 3,
  "transfers": 5,
  "limitRateBytesPerSec": 1048576,
  "autoRetry": true,
  "serverAddr": "https://qt.example.com",
  "targetDir": "/data/downloads",
  "fileList": [
    {
      "localRelPath": "dataset/a.txt",
      "remoteUrl": "/dataset/a.txt"
    }
  ]
}
```

上传任务示例（未传的连接数和流数继承服务默认值）：

```json
{
  "taskId": "upload-demo-001",
  "bearerToken": "your-access-token",
  "taskPid": "external-business-123",
  "enterpriseId": "enterprise-42",
  "taskName": "upload-demo",
  "mode": "upload",
  "transport": "https2",
  "transfers": 3,
  "serverAddr": "https://qt.example.com",
  "sourceDir": "/data/upload-source",
  "fileList": [
    {
      "localRelPath": "subdir/a.txt",
      "objectKey": "/gsa/demo/subdir/a.txt"
    }
  ],
  "dirPaths": [
    "/gsa/demo/empty-dir"
  ]
}
```

### 下载任务摘要 `DownloadTaskSummary`

| 字段                  | 类型      | 说明                                              |
| ------------------- | ------- | ----------------------------------------------- |
| `taskId`            | string  | 任务 ID                                           |
| `taskName`          | string  | 任务名称                                            |
| `mode`              | string  | 固定为 `download`                                  |
| `status`            | string  | 任务状态                                            |
| `error`             | object  | 当前执行错误 `{code,message,meta}`；仅 failed 必填，其他状态省略 |
| `started`           | boolean | 任务是否已开始执行过                                      |
| `transferredBytes`  | integer | 已传输字节数                                          |
| `totalSize`         | integer | 总字节数                                            |
| `transferRate`      | integer | 当前速率，单位字节/秒                                     |
| `transferringFiles` | array   | 当前正在传输的文件摘要列表                                   |

### 上传任务摘要 `UploadTaskSummary`

与下载摘要类似，差异主要在 `transferringFiles[]` 子项结构：

| 字段                  | 类型      | 说明                                              |
| ------------------- | ------- | ----------------------------------------------- |
| `taskId`            | string  | 任务 ID                                           |
| `taskName`          | string  | 任务名称                                            |
| `mode`              | string  | 固定为 `upload`                                    |
| `status`            | string  | 任务状态                                            |
| `error`             | object  | 当前执行错误 `{code,message,meta}`；仅 failed 必填，其他状态省略 |
| `started`           | boolean | 任务是否已开始执行过                                      |
| `transferredBytes`  | integer | 已上传字节数                                          |
| `totalSize`         | integer | 总字节数                                            |
| `transferRate`      | integer | 当前速率，单位字节/秒                                     |
| `transferringFiles` | array   | 当前正在传输的上传文件摘要列表                                 |

### 下载任务详情 `DownloadTaskDetail`

创建响应和任务详情会返回合并后的配置，即使任务仍在排队或已经停止。严格检查响应字段的调用方需要接纳新增的 `transport`、`connections`、`streams`；`fileConcurrency` 保持原字段名，响应不另增 `transfers`。

`POST /tasks`（创建下载任务成功）和 `GET /tasks/:task_id/detail`（下载任务）会返回以下结构：

| 字段                     | 类型      | 说明                                              |
| ---------------------- | ------- | ----------------------------------------------- |
| `taskId`               | string  | 任务 ID                                           |
| `taskName`             | string  | 任务名称                                            |
| `mode`                 | string  | 固定为 `download`                                  |
| `serverAddr`           | string  | 规范化后的 qtserver origin，不包含 `/qtserver/v1` 等路径    |
| `targetDir`            | string  | 本地下载根目录                                         |
| `status`               | string  | 任务状态                                            |
| `error`                | object  | 当前执行错误 `{code,message,meta}`；仅 failed 必填，其他状态省略 |
| `started`              | boolean | 任务是否已经开始执行                                      |
| `authorizedFiles`      | array   | 授权成功的文件详情，包含零字节文件                               |
| `unauthorizedFiles`    | array   | 未获得授权的文件详情                                      |
| `transferredBytes`     | integer | 已传输字节数                                          |
| `networkReceivedBytes` | integer | 当前会话中实际通过网络接收的字节数                               |
| `totalSize`            | integer | 总字节数                                            |
| `transferRate`         | integer | 当前速率，单位字节/秒                                     |
| `transport`            | string  | 任务实际使用的协议：`https`、`https2` 或 `https3`           |
| `connections`          | integer | 生效的每任务、每服务地址连接数上限                               |
| `streams`              | integer | 生效的每连接请求数上限，`https` 为 `1`                       |
| `fileConcurrency`      | integer | 生效的 `transfers`，普通文件并发上限，不代表活跃分片数               |
| `createdAt`            | string  | 创建时间，RFC3339                                    |
| `updatedAt`            | string  | 更新时间，RFC3339                                    |
| `startedAt`            | string  | 开始时间，未开始则可能省略或为零值                               |
| `finishedAt`           | string  | 完成时间，未完成则可能省略或为零值                               |

### 上传任务详情 `UploadTaskDetail`

`POST /tasks`（创建上传任务成功）和 `GET /tasks/:task_id/detail`（上传任务）会返回以下结构：

| 字段                 | 类型      | 说明                                                           |
| ------------------ | ------- | ------------------------------------------------------------ |
| `taskId`           | string  | 本地任务 ID                                                      |
| `taskName`         | string  | 任务名称                                                         |
| `mode`             | string  | 固定为 `upload`                                                 |
| `serverAddr`       | string  | 规范化后的 qtserver origin，不包含 `/qtserver/v1` 等路径                 |
| `sourceDir`        | string  | 本地上传根目录                                                      |
| `serverTaskId`     | string  | qtserver 统计关联 ID；普通 serve 流程与 `taskId` 相同，启用自动重排且源文件发生变化时会更新 |
| `status`           | string  | 任务状态                                                         |
| `error`            | object  | 当前执行错误 `{code,message,meta}`；仅 failed 必填，其他状态省略              |
| `started`          | boolean | 任务是否已经开始执行                                                   |
| `readyFiles`       | array   | 已初始化成功、可以上传或继续上传的文件详情                                        |
| `conflictFiles`    | array   | 服务端判定已存在/冲突，但本地认为已完成的文件详情                                    |
| `rejectedFiles`    | array   | 未获授权、且不属于冲突场景的文件详情                                           |
| `transferredBytes` | integer | 已上传字节数                                                       |
| `networkSentBytes` | integer | 当前会话中通过网络实际发送的字节数                                            |
| `totalSize`        | integer | 总字节数                                                         |
| `transferRate`     | integer | 当前速率，单位字节/秒                                                  |
| `transport`        | string  | 任务实际使用的协议：`https`、`https2` 或 `https3`                        |
| `connections`      | integer | 生效的每任务、每服务地址连接数上限                                            |
| `streams`          | integer | 生效的每连接请求数上限，`https` 为 `1`                                    |
| `fileConcurrency`  | integer | 生效的 `transfers`，普通文件并发上限，不代表活跃分片数                            |
| `createdAt`        | string  | 创建时间，RFC3339                                                 |
| `updatedAt`        | string  | 更新时间，RFC3339                                                 |
| `startedAt`        | string  | 开始时间                                                         |
| `finishedAt`       | string  | 完成时间                                                         |

### 下载文件摘要/详情

下载摘要子项 `transferringFiles[]`：

| 字段                 | 类型      | 说明                     |
| ------------------ | ------- | ---------------------- |
| `error`            | object  | 文件最终执行错误，结构同上；无最终错误时省略 |
| `localRelPath`     | string  | 本地相对路径                 |
| `remoteUrl`        | string  | 规范化后的远端对象键，通常以 `/` 开头  |
| `authorized`       | boolean | 是否已授权                  |
| `size`             | integer | 文件大小                   |
| `transferredBytes` | integer | 已传输字节数                 |
| `transferRate`     | integer | 当前速率                   |
| `overallChecksum`  | string  | 文件总校验值                 |
| `received`         | boolean | 本地文件是否已完整接收            |
| `verified`         | boolean | 是否已完成校验                |

下载详情子项 `authorizedFiles[]` / `unauthorizedFiles[]`：在上述字段基础上增加：

| 字段       | 类型    | 说明             |
| -------- | ----- | -------------- |
| `chunks` | array | 分片详情列表，仅大文件会出现 |

`chunks[]` 字段：

| 字段                 | 类型      | 说明         |
| ------------------ | ------- | ---------- |
| `index`            | integer | 分片序号       |
| `startOffset`      | integer | 起始偏移       |
| `endOffset`        | integer | 结束偏移       |
| `transferredBytes` | integer | 当前分片已传输字节数 |
| `size`             | integer | 当前分片大小     |
| `completed`        | boolean | 当前分片是否完成   |

### 上传文件摘要/详情

上传摘要子项 `transferringFiles[]`：

| 字段                 | 类型      | 说明                                                        |
| ------------------ | ------- | --------------------------------------------------------- |
| `error`            | object  | 文件最终执行错误，结构同上；无最终错误时省略                                    |
| `localRelPath`     | string  | 本地相对路径                                                    |
| `objectKey`        | string  | 规范化后的目标对象键，通常以 `/` 开头                                     |
| `size`             | integer | 文件大小                                                      |
| `status`           | string  | 上传文件状态；当前实际取值主要为 `active`、`exists`、`committed`；尚未初始化时可能省略 |
| `transferredBytes` | integer | 已上传字节数                                                    |
| `transferRate`     | integer | 当前速率                                                      |
| `uploaded`         | boolean | 是否已上传完成                                                   |
| `verified`         | boolean | 是否已校验完成                                                   |
| `message`          | string  | 失败时按五位码安全化后的固定英文说明                                        |

上传详情子项 `readyFiles[]` / `conflictFiles[]` / `rejectedFiles[]`：在上述字段基础上增加：

| 字段             | 类型      | 说明                          |
| -------------- | ------- | --------------------------- |
| `fileHash`     | string  | 文件整体哈希                      |
| `uploadUrl`    | string  | 当前上传会话的分片上传基础地址；会话尚未建立时可能省略 |
| `chunkSize`    | integer | 分片大小                        |
| `chunkCount`   | integer | 分片数量                        |
| `ready`        | boolean | 文件是否已完成上传会话初始化并可进入传输        |
| `exists`       | boolean | 服务端是否报告对象已存在                |
| `lastModified` | string  | 本地文件最后修改时间，RFC3339Nano      |

## 接口清单

### 1. 健康检查

- 方法：`GET`
- 路径：`/api/v1/health`
- 用途：检查服务状态，返回版本与进程信息
- 响应示例：
  ```json
  {
    "code": 0,
    "message": "Success",
    "data": {
      "me": "qtransc", // 服务名称
      "pid": 92316, // 服务进程 ID
      "version": "dev" // 服务版本
    }
  }
  ```

### 2. 查询服务配置

- 方法：`GET`
- 路径：`/api/v1/conf`
- 用途：查询任务限制和默认传输参数，供调用方自行控制任务提交
- 请求头：
  - `Authorization: Bearer <server-secret>`（可选）
- 响应体：
  | 字段                          | 类型      | 说明                                      |
  | --------------------------- | ------- | --------------------------------------- |
  | `limits.maxConcurrentTasks` | integer | 任务并发数，即最多同时执行的任务数；当前为 `10`              |
  | `limits.maxAdmittedTasks`   | integer | 任务量上限，即排队任务与尚未释放名额的执行任务之和的上限；当前为 `64`   |
  | `defaults.transport`        | string  | 创建任务未指定协议时使用的默认值；内置默认 `https3`          |
  | `defaults.connections`      | integer | 每个任务、每个服务地址的默认连接数上限；内置默认 `10`           |
  | `defaults.streams`          | integer | 每连接的默认请求数上限；内置默认 `1`                    |
  | `defaults.fileConcurrency`  | integer | 默认普通文件并发数，对应创建请求中的 `transfers`；内置默认 `5` |
- 响应示例：
  ```json
  {
    "code": 0,
    "message": "Success",
    "data": {
      "limits": {
        "maxConcurrentTasks": 10,
        "maxAdmittedTasks": 64
      },
      "defaults": {
        "transport": "https3",
        "connections": 10,
        "streams": 1,
        "fileConcurrency": 5
      }
    }
  }
  ```
- 错误码：
  | `code` | `message` | 场景 |
  |---|---|---|
  | `30002` | `QTrans access denied` | 服务启用了密钥鉴权，请求缺少或携带了错误密钥 |
  | `30999` | `QTrans internal error` | 响应提交前发生了被恢复的程序异常 |
  | `30001` | `QTrans request invalid` | 使用错误的 HTTP method，或请求路径不匹配 |

### 3.

- XXXXX

### 4. 创建并启动任务

- 方法：`POST`
- 路径：`/api/v1/tasks`
- 用途：创建并启动任务
- 请求头：
  - `Authorization: Bearer <server-secret>`（可选）
- 请求体： `TaskCreateRequest`
- 响应体：
  - 创建下载任务返回 `DownloadTaskDetail`
  - 创建上传任务返回 `UploadTaskDetail`

- 错误码：
  | code | message | 触发场景 |
  |---|---|---|
  | `30001` | `QTrans request invalid` | JSON、字段、路径或参数无效，包括缺少有效 `taskId`、并发参数越界 |
  | `30002` | `QTrans access denied` | 访问 qtransc 的服务密钥缺失或错误 |
  | `30004` | `Task already exists` | 相同 `taskId` 已存在且尚未删除 |
  | `30007` | `Task capacity exceeded` | 总接纳容量已满，当前上限为 64 |
  | `30008` | `Task file limit exceeded` | 请求的 `fileList` 超过 100000 项 |
  | `30009` | `QTrans service shutting down` | 服务正在关闭，不再接受新任务 |
  | `30999` | `QTrans internal error` | 未预料到或无法分类的内部错误 |

### 5. 获取任务列表

- 方法：`GET`
- 路径：`/api/v1/tasks`
- 用途：获取当前所有任务摘要
- 请求头：
  - `Authorization: Bearer <server-secret>`（可选）
- 响应体：同时包含下载摘要`DownloadTaskDetail`和上传摘要`UploadTaskDetail`的数组
- 响应示例：
  ```json
  {
    "code": 0,
    "message": "Success",
    "data": [
      {
        // 下载任务摘要
      },
      {
        // 上传任务摘要
      },
  }
  ```

### 6. 获取任务详情

- 方法：`GET`
- 路径：`/api/v1/tasks/:task_id/detail`
- 用途：获取完整任务详情
- 响应体： `DownloadTaskDetail` 或 `UploadTaskDetail`。

任务不存在时：

```json
{
  "code": 30005,
  "message": "Task not found",
  "meta": {
    "retryable": false,
    "visible": false
  }
}
```

### 7. 获取任务摘要

- 方法：`GET`
- 路径：`/api/v1/tasks/:task_id/summary`
- 用途：获取轻量级任务状态信息
- 响应体： `DownloadTaskSummary` 或 `UploadTaskSummary`。

任务不存在时与详情接口一致，HTTP 为 `200`，业务码为 `30005`。

### 8. 启动或重新入队任务

- 方法：`POST`
- 路径：`/api/v1/tasks/:task_id/start`
- 用途：把任务置回待执行状态并重新提交到调度器

成功响应：

```json
{
  "code": 0,
  "message": "Success"
}
```

失败响应：

```json
{
  "code": 30006,
  "message": "Task state conflict",
  "meta": {
    "retryable": false,
    "visible": false
  }
}
```

注意：

- 当前实现没有单独的 `/resume` 或 `/retry` 端点
- 对已 `completed`、`stopped` 或 `failed` 的任务，恢复方式都是调用 `/start`
- 重新启动被接受时只把状态改为 `pending` 并重新排队；上一轮任务及文件错误仍保留在任务内部，但 HTTP 查询在 pending 阶段隐藏它们，下一次 Run 初始化新一轮数据时才清除。请求被拒绝时保留原快照。前一轮执行尚未释放时返回 `30006`
- `completed` 任务重新执行时会重新检查源和目标；例如目的端文件已被删除时会重新传输，不会仅凭上一轮完成标记跳过
- 源文件变化后，未启用 `autoRetry` 的任务仍须新建任务，启动原任务返回 `30006`；已启用的任务会重新读取当前文件，并使用新的服务端执行 ID，客户端 `taskId` 保持不变
- 成功启动会重新启用创建时的 `autoRetry` 策略；与自动入队同时发生的手动启动可能因任务已进入 `pending/running` 返回 `30006`
- 任务不存在返回 `30005`，状态不允许启动返回 `30006`，容量不足返回 `30007`，服务正在关闭返回 `30009`

### 9. 停止任务

- 方法：`POST`
- 路径：`/api/v1/tasks/:task_id/pause`
- 用途：停止运行中的任务，或把 `pending` 任务直接标记为 `stopped`

对启用 `autoRetry` 且尚未主动中止重排的任务，`/pause` 也接受 `failed` 状态，包括失败收尾和等待容量期间。成功后撤销自动重排，保留已发生的失败及错误；不会为了暂停覆盖原故障。后续需要调用 `/start` 才会再次执行。

成功响应：

```json
{
  "code": 0,
  "message": "Success"
}
```

任务不存在或状态冲突分别返回：

```json
{
  "code": 30005,
  "message": "Task not found",
  "meta": {
    "retryable": false,
    "visible": false
  }
}
```

### 10. 删除任务

- 方法：`DELETE`
- 路径：`/api/v1/tasks/:task_id`
- 用途：删除任务；若任务仍在执行，会先请求取消

成功响应：

```json
{
  "code": 0,
  "message": "Success"
}
```

失败响应：

```json
{
  "code": 30005,
  "message": "Task not found",
  "meta": {
    "retryable": false,
    "visible": false
  }
}
```

注意：

- 当前实现没有 `remove_files` 查询参数
- 任务不存在返回 `30005`；其他无法安全分类的清理失败返回 `30999`

### 11. 订阅任务事件（SSE）

- 方法：`GET`
- 路径：`/api/v1/events`
- 用途：通过 SSE 订阅 `qtransc serve` 进程内的全局任务事件流

响应头：

```text
Content-Type: text/event-stream
Cache-Control: no-cache
Connection: keep-alive
```

当前实现的推送行为：

- SSE 连接建立并 flush 响应头后，会立即发送一条 `qtrans.health.heartbeat`
- `qtrans.health.heartbeat` 的发送周期由 `serve` 配置 `sse.heartbeatInterval` 控制，默认 `5s`
- 任务状态变化时发送 `qtrans.task.status`
- 任务删除时发送 `qtrans.task.delete`
- 文件状态变化时发送 `qtrans.file.status`
- 分片状态变化时发送 `qtrans.chunk.status`
- 任务传输过程中按 `sse.progressInterval` 周期发送 `qtrans.task.progress`，默认 `1s`
- 文件传输过程中按 `sse.progressInterval` 周期发送 `qtrans.file.progress`
- 分片传输过程中按 `sse.progressInterval` 周期发送 `qtrans.chunk.progress`
- 上述周期只控制 SSE 事件发布；内存进度按每次 payload 读取更新，速率由独立的 `300ms` 内部采样器维护
- 文件、分片或任务进入终态时会先停止本轮周期进度发布，然后强制发送最终进度快照，再发送终态状态事件；终态后不再发布该轮进度
- Retry 被接受后只发送一次 `pending` 状态事件，使用成功信封，不携带上一轮执行错误，也不伪造归零进度；允许出现 `completed → pending → running` 的状态序列

所有消息都通过 SSE `data:` 行承载 JSON。

心跳示例：

```text
data: {"messageType":"qtrans.health.heartbeat","code":0,"message":"Success","data":{"timestamp":"2026-05-26T12:34:56Z"}}
```

任务状态事件示例：

```text
data: {"messageType":"qtrans.task.status","code":0,"message":"Success","data":{"taskId":"1715156789012345678-000001","status":"running"}}
```

任务失败事件示例：

```text
data: {"messageType":"qtrans.task.status","code":31007,"message":"Local resource not found","data":{"taskId":"1715156789012345678-000001","status":"failed"},"meta":{"retryable":false,"visible":true}}
```

任务删除事件示例：

```text
data: {"messageType":"qtrans.task.delete","code":0,"message":"Success","data":{"taskId":"1715156789012345678-000001"}}
```

文件状态事件示例：

```text
data: {"messageType":"qtrans.file.status","code":0,"message":"Success","data":{"taskId":"1715156789012345678-000001","fileKey":"/dataset/a.txt","status":"completed"}}
```

文件进度事件示例：

```text
data: {"messageType":"qtrans.file.progress","code":0,"message":"Success","data":{"taskId":"1715156789012345678-000001","fileKey":"/dataset/a.txt","total":8388608,"transferred":1048576,"rate":524288}}
```

## 当前实现注意事项

以下内容是调用方最容易踩坑的地方，建议上线前先看一眼：

1. 所有 JSON 业务响应均为 HTTP `200`；成功业务码为 `0`
2. 每个 upload/download 任务在去重后最多包含 `100000` 个普通文件；空目录不计入该数量，但仍受既有 200000 总 entries 上限约束。
