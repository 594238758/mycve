# qtransc

`qtransc` 是 `qtrans` 体系里的客户端执行引擎，负责对接 `qtserver` 完成文件上传与下载。

## 核心能力

- 下载小文件（< 4 MiB）批量通道：每批最多 100 个文件且总量不超过 128 MiB，调用 `/d/small`，不做断点续传
- 上传统一通道：所有文件均走 canonical `/uploads` session/chunk/finalize/complete
- 下载大文件标准通道：走 `grant → down → verify`
- XXH3-128 分层哈希：100 MiB 分块，与 `qtserver` 完全对齐
- 三种运行模式：前台 CLI、本地 HTTP 服务、旧桌面端兼容

## 子命令

| 命令 | 说明 |
|------|------|
| `serve` | 启动本地 HTTP API 服务，供外部程序调用 |
| `list` | 浏览统一远端文件空间 |
| `mkdir` | 创建远端目录树 |
| `move` | 移动或重命名远端路径 |
| `delete` | 递归删除远端路径 |
| `download` | 前台执行下载 |
| `upload` | 前台执行上传 |
| `upload2` | 兼容旧版上传调用方式 |
| `download2` | 兼容旧版下载调用方式 |

## 快速使用

说明：除 `serve` 外，所有 CLI 命令都必须通过无默认值的全局
`--server host[:port]` 指定 qtserver，端口省略时固定补为 `443`。CLI 会
将服务器地址解析为 origin，并固定访问 `/qtserver/v1/...`。用户名密码认证
同样只访问这个服务器，token endpoint 固定为
`/qtserver/v1/oauth2/token`；认证服务的真实部署地址由网关隔离。

## 安装开发版

在仓库根目录执行以下命令，编译当前源码的 `dev` 版本并安装为
`~/.local/bin/qtransc`：

```bash
make -C qtransc install
qtransc -v
```

上述命令不会修改系统目录。若终端提示找不到 `qtransc`，请将
`$HOME/.local/bin` 加入当前 shell 的 `PATH`；例如 Bash：

```bash
export PATH="$HOME/.local/bin:$PATH"
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
```

使用 Zsh 时将最后一行写入 `~/.zshrc`。重新执行 `make -C qtransc install` 会重新编译并覆盖本地开发版。

## 快速使用

```bash
# 下载目录浏览
qtransc --server qt.example.com list /gsa/

# upload 家目录浏览
qtransc --server qt.example.com list /project/ --auth-token TOKEN

# anonymous 文件管理：未指定认证时自动使用 anonymous 写身份
qtransc --server qt.example.com mkdir /incoming
qtransc --server qt.example.com move /incoming/old.bin /incoming/new.bin
qtransc --server qt.example.com delete /incoming/new.bin

# 普通用户文件管理
qtransc --server qt.example.com --auth-token TOKEN mkdir /project/releases

# 前台下载：单源位置参数模式
qtransc --server qt.example.com download /gsa/demo.txt

# 前台下载：多源显式模式
qtransc --server qt.example.com download \
  -s /gsa/a \
  -s /gsa/b \
  -d ./downloads

# 前台 anonymous 上传：未指定认证时自动使用 anonymous 写身份
qtransc --server qt.example.com upload /data/file.txt /incoming

# 前台普通用户上传
qtransc --server qt.example.com --auth-token TOKEN \
  upload /data/file.txt /incoming

# 启动本地服务
qtransc serve --port 8080

# 可选：为本地 API 启用 Bearer secret 鉴权
qtransc serve --port 8080 --secret-key 'replace-with-a-random-secret'

# 旧桌面端兼容模式
qtransc upload2 --taskid TASK_ID --wss-url wss://... --jf /path/to/files.json --server qt.example.com:443 --auth-token TOKEN

# 旧版下载兼容模式
qtransc download2 --taskid TASK_ID --wss-url wss://... --jf /path/to/files.json --server qt.example.com:443 --destination /data/output --auth-token TOKEN
```

说明：`download2` 的 JSON 中，`remote_url` 既可以是公开下载使用的完整 URL，也可以是授权下载使用的相对路径 / 对象 key；无论采用哪种写法，调用方都必须显式传入 `--server`。

## 文档

| 文档 | 说明 |
|------|------|
| [docs/DESIGN.md](docs/DESIGN.md) | 设计文档（权威参考） |
| [docs/qtransc-cli-guide.md](docs/qtransc-cli-guide.md) | CLI 使用手册 |
| [docs/USER_GUIDE.md](docs/USER_GUIDE.md) | 用户手册（serve 消息码、任务状态、排错） |
| [docs/qtransc-apis.md](docs/qtransc-apis.md) | engine API 文档 |
| [docs/TEST_PLAN.md](docs/TEST_PLAN.md) | 本地测试计划 |
| [../qtserver/docs/qtserver-apis.md](../qtserver/docs/qtserver-apis.md) | `qtserver` 服务端 API 人类可读文档 |

## 代码组织

```text
cmd/qtransc/
  root.go               Cobra 入口
  cmd_serve.go          本地 HTTP 服务入口
  cmd_files.go          list/mkdir/move/delete 统一文件管理入口
  cmd_download.go       前台下载入口
  cmd_upload.go         前台上传入口
  cmd_upload2.go        旧版上传兼容入口
  cmd_download2.go      旧版下载兼容入口
  progress.go           CLI 文本进度
internal/
  downloadtask/         下载核心模块（小文件批量 + 大文件标准）
  uploadtask/           上传核心模块（统一 init/chunk/complete）
  filehash/             XXH3-128 分层哈希
  netclient/            统一客户端池选择层
  h12client/            HTTP/1.1/2 客户端池
  h3client/             HTTP/3 客户端池
  handlers/             serve 模式 HTTP Handler
  taskmanager/          serve 模式任务管理
  scheduler/            serve 模式任务调度
  eventcollector/       全局事件通道
  types/                API 与协议模型
```

## 设计约束

1. 传输逻辑只收敛在 `downloadtask` 与 `uploadtask` 两个内部模块
2. `serve`、CLI、`upload2`、`download2` 都只做参数转换和进度展示，不重复实现传输逻辑
3. `list` 展示 `LAST MODIFIED`；list API 不提供 checksum，传输完整性校验由传输协议独立完成
4. 下载小文件阈值 4 MiB，每批最多 100 个文件且总量不超过 128 MiB；上传不按文件大小分流
5. 下载小文件路径不做本地断点和远端续传探测
6. 下载大文件保留 `grant + data + verify`；所有上传文件统一使用 canonical `/uploads` 协议
7. `upload2` 的 WebSocket 只负责进度查询与状态回报，不承载传输数据
8. 本地 HTTP 服务统一通过 `/api/v1/*` 暴露任务管理与事件接口

## 日志约定

- `--debug` 开启 JSON Lines 日志
- 只传 `--debug` 时，日志仅写终端
- `download`、`upload`、`download2`、`upload2` 同时传入 `--debug` 和
  `--log-path` 时，日志仅写入 `<log-path>/qtransc-<taskid>.log`
- `serve` 同时传入 `--debug` 和 `--log-path` 时，应用与 Gin 日志仅写入
  `<log-path>/qtransc.log`
- `list`、`mkdir`、`delete`、`move` 不写日志文件

上述文件都是客户端本地调试日志，不属于服务端原始业务日志。qtransc 不上报业务 event，只在文件首请求携带日志上下文；qtserver 和 Nginx 根据传输 API 的实际执行结果输出服务端原始业务事件。协议边界见 [`transfer-task-correlation`](../openspec/specs/transfer-task-correlation/spec.md)。
