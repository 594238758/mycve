package authmanager

import "time"

const (
	// EnvAuthClientID and EnvAuthClientSecret provide OAuth client credentials
	// that override the built-in deployment credentials when rotation is needed.
	EnvAuthClientID     = "QTRANSC_AUTH_CLIENT_ID"
	EnvAuthClientSecret = "QTRANSC_AUTH_CLIENT_SECRET"

	// These credentials identify the fixed CLI client registered by the auth
	// service. Because they are distributed in the binary, they must not be
	// treated as a user-specific secret or an authorization boundary.
	defaultOAuthClientID     = "oidc-client-cli"
	defaultOAuthClientSecret = "IoRCXoCqMsAGOthmcGgWTcsdMHpnC8NC9Cv0qDwBFa2zWN4tu_gc_y03n1BZQT74"
)

type AuthMode string

const (
	AuthModeUninitialized AuthMode = ""
	AuthModeStaticToken   AuthMode = "staticToken"
	AuthModeUserAndPass   AuthMode = "userandpass"
)

type UserAndPassConfig struct {
	Username     string
	Password     string
	ServerOrigin string
	ClientID     string
	ClientSecret string
}

type Snapshot struct {
	Mode            AuthMode   `json:"mode"`
	Initialized     bool       `json:"initialized"`
	HasAccessToken  bool       `json:"has_access_token"`
	HasRefreshToken bool       `json:"has_refresh_token"`
	ExpiresAt       *time.Time `json:"expires_at,omitempty"`
	LastLoginErr    string     `json:"last_login_err,omitempty"`
	LastRefreshErr  string     `json:"last_refresh_err,omitempty"`
}

type session struct {
	AccessToken  string
	RefreshToken string
	ExpiresAt    time.Time
	TokenType    string
	Subject      string
}

type tokenResponse struct {
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
	ExpiresIn    int64  `json:"expires_in"`
	TokenType    string `json:"token_type"`
	Subject      string `json:"subject"`
}
