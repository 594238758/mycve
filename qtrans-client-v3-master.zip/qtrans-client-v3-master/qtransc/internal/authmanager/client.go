package authmanager

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"qtransc/internal/qtserverurl"
)

type authServiceClient interface {
	Login(ctx context.Context, cfg UserAndPassConfig) (*tokenResponse, error)
	Refresh(ctx context.Context, cfg UserAndPassConfig, refreshToken string) (*tokenResponse, error)
}

type httpAuthServiceClient struct {
	httpClient *http.Client
}

const (
	externalPasswordGrant = "urn:qtrans:grant-type:external-password"
	refreshTokenGrant     = "refresh_token"
	defaultOIDCScope      = "openid"
)

func newHTTPAuthServiceClient() authServiceClient {
	transport := http.DefaultTransport.(*http.Transport).Clone()
	transport.TLSClientConfig = &tls.Config{
		InsecureSkipVerify: true,
	}
	return &httpAuthServiceClient{
		httpClient: &http.Client{
			Transport: transport,
			Timeout:   30 * time.Second,
		},
	}
}

func (c *httpAuthServiceClient) Login(ctx context.Context, cfg UserAndPassConfig) (*tokenResponse, error) {
	form := url.Values{
		"grant_type": {externalPasswordGrant},
		"username":   {cfg.Username},
		"password":   {cfg.Password},
		"scope":      {defaultOIDCScope},
	}
	return c.doTokenRequest(ctx, cfg, form, ErrAuthLoginFailed)
}

func (c *httpAuthServiceClient) Refresh(ctx context.Context, cfg UserAndPassConfig, refreshToken string) (*tokenResponse, error) {
	form := url.Values{
		"grant_type":    {refreshTokenGrant},
		"refresh_token": {refreshToken},
	}
	return c.doTokenRequest(ctx, cfg, form, ErrAuthRefreshFailed)
}

func (c *httpAuthServiceClient) doTokenRequest(ctx context.Context, cfg UserAndPassConfig, form url.Values, baseErr error) (*tokenResponse, error) {
	rawURL, err := qtserverurl.JoinEndpoint(cfg.ServerOrigin, "/oauth2/token")
	if err != nil {
		return nil, fmt.Errorf("%w: build token endpoint: %v", baseErr, err)
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, rawURL, strings.NewReader(form.Encode()))
	if err != nil {
		return nil, fmt.Errorf("%w: create request: %v", baseErr, err)
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.SetBasicAuth(cfg.ClientID, cfg.ClientSecret)

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("%w: request failed: %v", baseErr, err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("%w: read response: %v", baseErr, err)
	}
	if resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden {
		return nil, fmt.Errorf("%w: %w", baseErr, ErrAuthUnauthorized)
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("%w: status=%d %s", baseErr, resp.StatusCode, formatOAuthError(respBody))
	}

	var tokenResp tokenResponse
	if err := json.Unmarshal(respBody, &tokenResp); err != nil {
		return nil, fmt.Errorf("%w: decode response: %v", baseErr, err)
	}
	if strings.TrimSpace(tokenResp.AccessToken) == "" {
		return nil, fmt.Errorf("%w: access_token is missing", baseErr)
	}
	if tokenResp.ExpiresIn <= 0 {
		return nil, fmt.Errorf("%w: expires_in must be greater than zero", baseErr)
	}
	if strings.TrimSpace(tokenResp.TokenType) == "" {
		tokenResp.TokenType = "Bearer"
	}
	return &tokenResp, nil
}

func formatOAuthError(body []byte) string {
	var oauthErr struct {
		Error            string `json:"error"`
		ErrorDescription string `json:"error_description"`
	}
	if err := json.Unmarshal(body, &oauthErr); err == nil && (oauthErr.Error != "" || oauthErr.ErrorDescription != "") {
		return fmt.Sprintf("error=%q description=%q", oauthErr.Error, oauthErr.ErrorDescription)
	}
	message := strings.TrimSpace(string(body))
	if message == "" {
		return ""
	}
	return fmt.Sprintf("body=%q", message)
}
