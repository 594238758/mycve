package authmanager

import (
	"context"
	"fmt"
	"os"
	"strings"
	"sync"
	"time"

	"qtransc/internal/qtserverurl"

	"golang.org/x/sync/singleflight"
)

const refreshSkew = 2 * time.Minute

type manager struct {
	mu sync.RWMutex

	mode        AuthMode
	staticToken string
	userpass    *UserAndPassConfig
	session     *session

	version uint64

	lastLoginErr   error
	lastRefreshErr error

	refreshGroup singleflight.Group
	bgCancel     context.CancelFunc
	client       authServiceClient
}

var singleton = &manager{
	client: newHTTPAuthServiceClient(),
}

func Get() (string, error) {
	return singleton.Get()
}

func SetStaticToken(token string) error {
	return singleton.SetStaticToken(token)
}

func SetUserAndPass(cfg UserAndPassConfig) error {
	return singleton.SetUserAndPass(cfg)
}

func Clear() error {
	return singleton.Clear()
}

func SnapshotState() Snapshot {
	return singleton.SnapshotState()
}

func ForceRefresh(ctx context.Context) error {
	return singleton.ForceRefresh(ctx)
}

func Mode() AuthMode {
	return singleton.Mode()
}

func (m *manager) Get() (string, error) {
	m.mu.RLock()
	mode := m.mode
	staticToken := m.staticToken
	cfg := cloneUserAndPassConfig(m.userpass)
	sess := cloneSession(m.session)
	m.mu.RUnlock()

	switch mode {
	case AuthModeUninitialized:
		return "", ErrAuthNotInitialized
	case AuthModeStaticToken:
		if strings.TrimSpace(staticToken) == "" {
			return "", ErrAccessTokenMissing
		}
		return staticToken, nil
	case AuthModeUserAndPass:
		return m.getUserAndPassToken(context.Background(), cfg, sess)
	default:
		return "", ErrAuthModeUnsupported
	}
}

func (m *manager) getUserAndPassToken(ctx context.Context, cfg *UserAndPassConfig, sess *session) (string, error) {
	if cfg == nil {
		return "", ErrAuthNotInitialized
	}
	if sess != nil {
		if !m.needsRefresh(sess) {
			return sess.AccessToken, nil
		}
		if time.Now().Before(sess.ExpiresAt) {
			go func() {
				_ = m.ForceRefresh(context.Background())
			}()
			return sess.AccessToken, nil
		}
	}
	if err := m.refreshOrLogin(ctx); err != nil {
		fallback := m.currentSession()
		if fallback != nil && strings.TrimSpace(fallback.AccessToken) != "" && time.Now().Before(fallback.ExpiresAt) {
			return fallback.AccessToken, nil
		}
		return "", err
	}

	fresh := m.currentSession()
	if fresh == nil || strings.TrimSpace(fresh.AccessToken) == "" {
		return "", ErrAccessTokenMissing
	}
	return fresh.AccessToken, nil
}

func (m *manager) SetStaticToken(token string) error {
	trimmed := strings.TrimSpace(token)

	m.mu.Lock()
	defer m.mu.Unlock()

	switch m.mode {
	case AuthModeUninitialized:
		m.mode = AuthModeStaticToken
	case AuthModeStaticToken:
	default:
		return ErrAuthModeLocked
	}

	if m.bgCancel != nil {
		m.bgCancel()
		m.bgCancel = nil
	}
	m.staticToken = trimmed
	m.session = nil
	m.userpass = nil
	m.lastLoginErr = nil
	m.lastRefreshErr = nil
	m.version++
	return nil
}

func (m *manager) SetUserAndPass(cfg UserAndPassConfig) error {
	normalized := UserAndPassConfig{
		// Usernames are matched and sent exactly as provided by the caller.
		Username: cfg.Username,
		// Passwords are opaque credentials. In particular, leading or trailing
		// whitespace is valid and must be sent to the auth service unchanged.
		Password:     cfg.Password,
		ServerOrigin: strings.TrimSpace(cfg.ServerOrigin),
		ClientID:     strings.TrimSpace(cfg.ClientID),
		ClientSecret: cfg.ClientSecret,
	}
	if normalized.ClientID == "" {
		normalized.ClientID = strings.TrimSpace(os.Getenv(EnvAuthClientID))
		if normalized.ClientID == "" {
			normalized.ClientID = defaultOAuthClientID
		}
	}
	if normalized.ClientSecret == "" {
		normalized.ClientSecret = os.Getenv(EnvAuthClientSecret)
		if normalized.ClientSecret == "" {
			normalized.ClientSecret = defaultOAuthClientSecret
		}
	}
	if normalized.Username == "" || normalized.Password == "" {
		return fmt.Errorf("%w: username and password are required", ErrAuthLoginFailed)
	}
	if normalized.ClientID == "" || strings.TrimSpace(normalized.ClientSecret) == "" {
		return fmt.Errorf("%w: OAuth client credentials are required through %s and %s", ErrAuthLoginFailed, EnvAuthClientID, EnvAuthClientSecret)
	}
	serverOrigin, err := qtserverurl.NormalizeServerOrigin(normalized.ServerOrigin)
	if err != nil {
		return fmt.Errorf("%w: server origin: %v", ErrAuthLoginFailed, err)
	}
	normalized.ServerOrigin = serverOrigin

	m.mu.Lock()
	switch m.mode {
	case AuthModeUninitialized:
		m.mode = AuthModeUserAndPass
	case AuthModeUserAndPass:
	default:
		m.mu.Unlock()
		return ErrAuthModeLocked
	}

	if m.bgCancel != nil {
		m.bgCancel()
		m.bgCancel = nil
	}
	m.userpass = &normalized
	m.staticToken = ""
	m.session = nil
	m.lastLoginErr = nil
	m.lastRefreshErr = nil
	m.version++
	version := m.version
	m.startRefreshWorkerLocked(version)
	m.mu.Unlock()
	return nil
}

func (m *manager) Clear() error {
	m.mu.Lock()
	defer m.mu.Unlock()

	if m.bgCancel != nil {
		m.bgCancel()
		m.bgCancel = nil
	}
	switch m.mode {
	case AuthModeStaticToken:
		m.staticToken = ""
	case AuthModeUserAndPass:
		m.session = nil
		m.lastLoginErr = nil
		m.lastRefreshErr = nil
		m.startRefreshWorkerLocked(m.version + 1)
	default:
		return nil
	}
	m.version++
	return nil
}

func (m *manager) SnapshotState() Snapshot {
	m.mu.RLock()
	defer m.mu.RUnlock()

	snapshot := Snapshot{
		Mode:        m.mode,
		Initialized: m.mode != AuthModeUninitialized,
	}
	if m.session != nil {
		snapshot.HasAccessToken = strings.TrimSpace(m.session.AccessToken) != ""
		snapshot.HasRefreshToken = strings.TrimSpace(m.session.RefreshToken) != ""
		expiresAt := m.session.ExpiresAt
		snapshot.ExpiresAt = &expiresAt
	}
	if m.mode == AuthModeStaticToken {
		snapshot.HasAccessToken = strings.TrimSpace(m.staticToken) != ""
	}
	if m.lastLoginErr != nil {
		snapshot.LastLoginErr = m.lastLoginErr.Error()
	}
	if m.lastRefreshErr != nil {
		snapshot.LastRefreshErr = m.lastRefreshErr.Error()
	}
	return snapshot
}

func (m *manager) ForceRefresh(ctx context.Context) error {
	m.mu.RLock()
	mode := m.mode
	m.mu.RUnlock()
	if mode != AuthModeUserAndPass {
		return ErrAuthModeUnsupported
	}
	return m.refreshOrLogin(ctx)
}

func (m *manager) Mode() AuthMode {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.mode
}

func (m *manager) refreshOrLogin(ctx context.Context) error {
	_, err, _ := m.refreshGroup.Do("refresh-or-login", func() (any, error) {
		cfg, sess, version := m.snapshotForRefresh()
		if cfg == nil {
			return nil, ErrAuthNotInitialized
		}
		if sess != nil && strings.TrimSpace(sess.RefreshToken) != "" {
			tokenResp, err := m.client.Refresh(ctx, *cfg, sess.RefreshToken)
			if err == nil {
				m.applyTokenResponse(version, tokenResp, false)
				return nil, nil
			}
			m.setLastRefreshError(err)
		}

		tokenResp, err := m.client.Login(ctx, *cfg)
		if err != nil {
			m.setLastLoginError(err)
			return nil, err
		}
		m.applyTokenResponse(version, tokenResp, true)
		return nil, nil
	})
	return err
}

func (m *manager) applyTokenResponse(version uint64, tokenResp *tokenResponse, resetRefreshErr bool) {
	if tokenResp == nil {
		return
	}

	m.mu.Lock()
	defer m.mu.Unlock()
	if m.mode != AuthModeUserAndPass || m.version != version {
		return
	}

	refreshToken := strings.TrimSpace(tokenResp.RefreshToken)
	if refreshToken == "" && m.session != nil {
		// RFC 6749 does not require a refresh response to rotate the refresh
		// token. Keep the current one when the server omits a replacement.
		refreshToken = m.session.RefreshToken
	}

	m.session = &session{
		AccessToken:  strings.TrimSpace(tokenResp.AccessToken),
		RefreshToken: refreshToken,
		ExpiresAt:    time.Now().Add(time.Duration(tokenResp.ExpiresIn) * time.Second),
		TokenType:    strings.TrimSpace(tokenResp.TokenType),
		Subject:      strings.TrimSpace(tokenResp.Subject),
	}
	m.lastLoginErr = nil
	if resetRefreshErr {
		m.lastRefreshErr = nil
	}
}

func (m *manager) setLastLoginError(err error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.lastLoginErr = err
}

func (m *manager) setLastRefreshError(err error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.lastRefreshErr = err
}

func (m *manager) snapshotForRefresh() (*UserAndPassConfig, *session, uint64) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return cloneUserAndPassConfig(m.userpass), cloneSession(m.session), m.version
}

func (m *manager) currentSession() *session {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return cloneSession(m.session)
}

func (m *manager) needsRefresh(sess *session) bool {
	if sess == nil {
		return true
	}
	if strings.TrimSpace(sess.AccessToken) == "" {
		return true
	}
	return time.Until(sess.ExpiresAt) <= refreshSkew
}

func (m *manager) startRefreshWorkerLocked(version uint64) {
	ctx, cancel := context.WithCancel(context.Background())
	m.bgCancel = cancel
	go m.refreshLoop(ctx, version)
}

func (m *manager) refreshLoop(ctx context.Context, version uint64) {
	timer := time.NewTimer(time.Second)
	defer timer.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
		}

		m.mu.RLock()
		if m.mode != AuthModeUserAndPass || m.version != version {
			m.mu.RUnlock()
			return
		}
		sess := cloneSession(m.session)
		m.mu.RUnlock()

		delay := time.Minute
		if sess == nil || strings.TrimSpace(sess.AccessToken) == "" {
			delay = 5 * time.Second
		} else {
			untilRefresh := time.Until(sess.ExpiresAt.Add(-refreshSkew))
			if untilRefresh <= 0 {
				_ = m.ForceRefresh(context.Background())
				delay = time.Minute
			} else {
				delay = untilRefresh
			}
		}
		if delay < time.Second {
			delay = time.Second
		}
		timer.Reset(delay)
	}
}

func cloneUserAndPassConfig(cfg *UserAndPassConfig) *UserAndPassConfig {
	if cfg == nil {
		return nil
	}
	cloned := *cfg
	return &cloned
}

func cloneSession(sess *session) *session {
	if sess == nil {
		return nil
	}
	cloned := *sess
	return &cloned
}
