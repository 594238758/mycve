package authmanager

import "errors"

var (
	ErrAuthNotInitialized  = errors.New("auth is not initialized")
	ErrAuthModeLocked      = errors.New("auth mode is locked and cannot be changed")
	ErrAuthModeUnsupported = errors.New("operation is not supported in current auth mode")
	ErrAccessTokenMissing  = errors.New("access token is missing")
	ErrAuthLoginFailed     = errors.New("auth login failed")
	ErrAuthRefreshFailed   = errors.New("auth refresh failed")
	ErrAuthUnauthorized    = errors.New("auth unauthorized")
)

func IsNotInitialized(err error) bool {
	return errors.Is(err, ErrAuthNotInitialized)
}

func IsUnauthorized(err error) bool {
	return errors.Is(err, ErrAuthUnauthorized)
}

func IsModeLocked(err error) bool {
	return errors.Is(err, ErrAuthModeLocked)
}
