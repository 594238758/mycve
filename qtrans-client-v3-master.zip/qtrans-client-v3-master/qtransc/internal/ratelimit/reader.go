package ratelimit

import (
	"context"
	"io"

	"golang.org/x/time/rate"
)

const (
	minChunkSize = 1
	maxChunkSize = 256 * 1024
)

type Limiter struct {
	limiter *rate.Limiter
	quantum int
}

func New(bytesPerSec int64) *Limiter {
	if bytesPerSec <= 0 {
		return nil
	}
	quantum := recommendedChunkSize(bytesPerSec)
	return &Limiter{
		limiter: rate.NewLimiter(rate.Limit(bytesPerSec), quantum),
		quantum: quantum,
	}
}

func (l *Limiter) WrapReader(ctx context.Context, reader io.Reader) io.Reader {
	if l == nil || l.limiter == nil || reader == nil {
		return reader
	}
	if ctx == nil {
		ctx = context.Background()
	}
	return &Reader{
		ctx:     ctx,
		reader:  reader,
		limiter: l.limiter,
		quantum: l.quantum,
	}
}

type Reader struct {
	ctx     context.Context
	reader  io.Reader
	limiter *rate.Limiter
	quantum int
}

func (r *Reader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	if err := r.ctx.Err(); err != nil {
		return 0, err
	}
	if len(p) > r.quantum {
		p = p[:r.quantum]
	}

	n, err := r.reader.Read(p)
	if n > 0 {
		if waitErr := r.limiter.WaitN(r.ctx, n); waitErr != nil {
			return n, waitErr
		}
	}
	return n, err
}

func recommendedChunkSize(bytesPerSec int64) int {
	if bytesPerSec <= 0 {
		return maxChunkSize
	}
	chunk := bytesPerSec / 10
	if chunk < minChunkSize {
		return minChunkSize
	}
	if chunk > maxChunkSize {
		return maxChunkSize
	}
	return int(chunk)
}
