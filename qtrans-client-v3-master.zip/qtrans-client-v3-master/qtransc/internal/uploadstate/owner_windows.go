//go:build windows

package uploadstate

import "os"

func validateOwner(os.FileInfo) error { return nil }
