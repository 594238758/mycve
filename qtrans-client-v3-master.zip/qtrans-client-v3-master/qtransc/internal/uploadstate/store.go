package uploadstate

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	_ "modernc.org/sqlite"
)

const SchemaVersion = 1

type FileState struct {
	ID                 int64
	LocalAbsolutePath  string
	Server             string
	RemoteAbsolutePath string
	SessionID          string
	Size               int64
	MTimeNS            int64
	CTimeNS            int64
	FileID             string
	FileHash           string
	HashAlgorithm      string
	UpdatedAt          time.Time
}

type Store struct {
	db   *sql.DB
	path string
}

func DefaultPath() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", fmt.Errorf("resolve home directory: %w", err)
	}
	return filepath.Join(home, ".qtrans", "state", "upload.db"), nil
}

func ResolvePath(explicit string) (string, error) {
	explicit = strings.TrimSpace(explicit)
	if explicit == "" {
		return DefaultPath()
	}
	if !filepath.IsAbs(explicit) {
		return "", fmt.Errorf("state-db must be an absolute path")
	}
	return filepath.Clean(explicit), nil
}

func Open(ctx context.Context, rawPath string) (*Store, error) {
	path, err := ResolvePath(rawPath)
	if err != nil {
		return nil, err
	}
	if err := validateFinalNode(path); err != nil {
		return nil, err
	}
	parent := filepath.Dir(path)
	if err := os.MkdirAll(parent, 0o700); err != nil {
		return nil, fmt.Errorf("create state-db parent: %w", err)
	}
	if err := os.Chmod(parent, 0o700); err != nil {
		return nil, fmt.Errorf("secure state-db parent: %w", err)
	}
	created, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_RDWR, 0o600)
	if err == nil {
		if closeErr := created.Close(); closeErr != nil {
			return nil, fmt.Errorf("create state-db: %w", closeErr)
		}
	} else if !os.IsExist(err) {
		return nil, fmt.Errorf("create state-db: %w", err)
	}
	if err := validateFinalNode(path); err != nil {
		return nil, err
	}

	dsn := sqliteFileDSN(path)
	db, err := sql.Open("sqlite", dsn)
	if err != nil {
		return nil, fmt.Errorf("open state-db: %w", err)
	}
	db.SetMaxOpenConns(1)
	store := &Store{db: db, path: path}
	if err := store.initialize(ctx); err != nil {
		_ = db.Close()
		return nil, err
	}
	if err := store.secureFiles(); err != nil {
		_ = db.Close()
		return nil, err
	}
	return store, nil
}

func sqliteFileDSN(path string) string {
	uriPath := filepath.ToSlash(path)
	if filepath.VolumeName(path) != "" && !strings.HasPrefix(uriPath, "/") {
		uriPath = "/" + uriPath
	}
	return (&url.URL{Scheme: "file", Path: uriPath}).String()
}

func validateFinalNode(path string) error {
	info, err := os.Lstat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return fmt.Errorf("inspect state-db: %w", err)
	}
	if info.Mode()&os.ModeSymlink != 0 {
		return fmt.Errorf("state-db final path must not be a symlink")
	}
	if !info.Mode().IsRegular() {
		return fmt.Errorf("state-db must be a regular file")
	}
	if err := validateOwner(info); err != nil {
		return err
	}
	return nil
}

func (s *Store) initialize(ctx context.Context) error {
	if _, err := s.db.ExecContext(ctx, "PRAGMA busy_timeout=5000"); err != nil {
		return fmt.Errorf("configure state-db busy timeout: %w", err)
	}
	var version int
	if err := s.db.QueryRowContext(ctx, "PRAGMA user_version").Scan(&version); err != nil {
		return fmt.Errorf("read state-db schema version: %w", err)
	}
	if version > SchemaVersion {
		return fmt.Errorf("state-db schema version %d is newer than supported version %d", version, SchemaVersion)
	}
	if version == 0 {
		tx, err := s.db.BeginTx(ctx, nil)
		if err != nil {
			return fmt.Errorf("begin state-db migration: %w", err)
		}
		defer tx.Rollback()
		if _, err := tx.ExecContext(ctx, `CREATE TABLE upload_files (
			id INTEGER PRIMARY KEY,
			local_absolute_path TEXT NOT NULL,
			server TEXT NOT NULL,
			remote_absolute_path TEXT NOT NULL,
			session_id TEXT NOT NULL,
			size INTEGER NOT NULL,
			mtime_ns INTEGER NOT NULL,
			ctime_ns INTEGER NOT NULL,
			file_id TEXT NOT NULL DEFAULT '',
			file_hash TEXT NOT NULL DEFAULT '',
			hash_algorithm TEXT NOT NULL DEFAULT '',
			updated_at TEXT NOT NULL,
			UNIQUE(local_absolute_path, server, remote_absolute_path)
		)`); err != nil {
			return fmt.Errorf("create upload_files: %w", err)
		}
		if _, err := tx.ExecContext(ctx, "PRAGMA user_version=1"); err != nil {
			return fmt.Errorf("set state-db schema version: %w", err)
		}
		if err := tx.Commit(); err != nil {
			return fmt.Errorf("commit state-db migration: %w", err)
		}
	}
	rows, err := s.db.QueryContext(ctx, `SELECT id, local_absolute_path, server, remote_absolute_path,
		session_id, size, mtime_ns, ctime_ns, file_id, file_hash, hash_algorithm, updated_at
		FROM upload_files LIMIT 0`)
	if err != nil {
		return fmt.Errorf("state-db schema is incompatible: %w", err)
	}
	_ = rows.Close()
	pragmas := []string{
		"PRAGMA journal_mode=WAL",
		"PRAGMA synchronous=FULL",
		"PRAGMA foreign_keys=ON",
		"PRAGMA wal_autocheckpoint=1000",
	}
	for _, statement := range pragmas {
		if _, err := s.db.ExecContext(ctx, statement); err != nil {
			return fmt.Errorf("configure state-db: %w", err)
		}
	}
	var integrity string
	if err := s.db.QueryRowContext(ctx, "PRAGMA quick_check").Scan(&integrity); err != nil {
		return fmt.Errorf("check state-db integrity: %w", err)
	}
	if integrity != "ok" {
		return fmt.Errorf("state-db integrity check failed: %s", integrity)
	}
	return nil
}

func (s *Store) secureFiles() error {
	for _, suffix := range []string{"", "-wal", "-shm"} {
		path := s.path + suffix
		if _, err := os.Lstat(path); err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return err
		}
		if err := os.Chmod(path, 0o600); err != nil {
			return fmt.Errorf("secure state-db file %s: %w", filepath.Base(path), err)
		}
	}
	return nil
}

func (s *Store) Close() error {
	if s == nil || s.db == nil {
		return nil
	}
	return s.db.Close()
}

func (s *Store) Get(ctx context.Context, local, server, remote string) (FileState, bool, error) {
	var state FileState
	var updated string
	err := s.db.QueryRowContext(ctx, `SELECT id, local_absolute_path, server, remote_absolute_path,
		session_id, size, mtime_ns, ctime_ns, file_id, file_hash, hash_algorithm, updated_at
		FROM upload_files WHERE local_absolute_path=? AND server=? AND remote_absolute_path=?`, local, server, remote).
		Scan(&state.ID, &state.LocalAbsolutePath, &state.Server, &state.RemoteAbsolutePath, &state.SessionID,
			&state.Size, &state.MTimeNS, &state.CTimeNS, &state.FileID, &state.FileHash, &state.HashAlgorithm, &updated)
	if errors.Is(err, sql.ErrNoRows) {
		return FileState{}, false, nil
	}
	if err != nil {
		return FileState{}, false, fmt.Errorf("read upload state: %w", err)
	}
	state.UpdatedAt, _ = time.Parse(time.RFC3339Nano, updated)
	return state, true, nil
}

func (s *Store) Put(ctx context.Context, state FileState) error {
	updated := time.Now().UTC().Format(time.RFC3339Nano)
	_, err := s.db.ExecContext(ctx, `INSERT INTO upload_files
		(local_absolute_path, server, remote_absolute_path, session_id, size, mtime_ns, ctime_ns, file_id, file_hash, hash_algorithm, updated_at)
		VALUES(?,?,?,?,?,?,?,?,?,?,?)
		ON CONFLICT(local_absolute_path, server, remote_absolute_path) DO UPDATE SET
		session_id=excluded.session_id,size=excluded.size,mtime_ns=excluded.mtime_ns,ctime_ns=excluded.ctime_ns,
		file_id=excluded.file_id,file_hash=excluded.file_hash,hash_algorithm=excluded.hash_algorithm,updated_at=excluded.updated_at`,
		state.LocalAbsolutePath, state.Server, state.RemoteAbsolutePath, state.SessionID, state.Size,
		state.MTimeNS, state.CTimeNS, state.FileID, state.FileHash, state.HashAlgorithm, updated)
	if err != nil {
		return fmt.Errorf("write upload state: %w", err)
	}
	return s.secureFiles()
}

func (s *Store) Delete(ctx context.Context, local, server, remote string) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM upload_files WHERE local_absolute_path=? AND server=? AND remote_absolute_path=?`, local, server, remote)
	if err != nil {
		return fmt.Errorf("delete upload state: %w", err)
	}
	return nil
}

func (s *Store) DeleteSession(ctx context.Context, sessionID string) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM upload_files WHERE session_id=?`, sessionID)
	if err != nil {
		return fmt.Errorf("delete upload session state: %w", err)
	}
	return nil
}
