package taskidclient

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"strings"
	"time"

	"qtransc/internal/netclient"
	"qtransc/internal/qtserverapi"
)

const (
	maxResponseBytes = 1 << 20
	requestTimeout   = 30 * time.Second
	maxTaskIDBytes   = 128
)

type ErrorKind string

const (
	ErrorTimeout  ErrorKind = "timeout"
	ErrorUpstream ErrorKind = "upstream"
)

type RequestError struct {
	Kind       ErrorKind
	StatusCode int
	Err        error
}

func (e *RequestError) Error() string {
	if e == nil {
		return ""
	}
	if e.StatusCode > 0 {
		return fmt.Sprintf("request taskid failed with status %d: %v", e.StatusCode, e.Err)
	}
	return fmt.Sprintf("request taskid failed: %v", e.Err)
}

func (e *RequestError) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.Err
}

func IsTimeout(err error) bool {
	var requestErr *RequestError
	return errors.As(err, &requestErr) && requestErr.Kind == ErrorTimeout
}

type response struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	TaskID  string `json:"taskid"`
}

func Request(ctx context.Context, serverBase string, network *netclient.Client) (string, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	requestCtx := ctx
	cancel := func() {}
	if _, hasDeadline := ctx.Deadline(); !hasDeadline {
		requestCtx, cancel = context.WithTimeout(ctx, requestTimeout)
	}
	defer cancel()

	status, _, body, err := qtserverapi.DoJSONWithHeaders(requestCtx, serverBase, "/taskid", "POST", "", "", nil, nil, network, qtserverapi.IdempotentRetry)
	if err != nil {
		kind := ErrorUpstream
		if isTimeoutError(err) || errors.Is(requestCtx.Err(), context.DeadlineExceeded) {
			kind = ErrorTimeout
		}
		return "", &RequestError{Kind: kind, StatusCode: status, Err: err}
	}
	if len(body) > maxResponseBytes {
		return "", &RequestError{Kind: ErrorUpstream, StatusCode: status, Err: errors.New("taskid response is too large")}
	}

	var payload response
	if err := json.Unmarshal(body, &payload); err != nil {
		return "", &RequestError{Kind: ErrorUpstream, StatusCode: status, Err: fmt.Errorf("decode taskid response: %w", err)}
	}
	taskID := strings.TrimSpace(payload.TaskID)
	if taskID == "" || len(taskID) > maxTaskIDBytes {
		return "", &RequestError{Kind: ErrorUpstream, StatusCode: status, Err: errors.New("taskid response contains an invalid taskid")}
	}
	return taskID, nil
}

func isTimeoutError(err error) bool {
	if errors.Is(err, context.DeadlineExceeded) {
		return true
	}
	var netErr net.Error
	return errors.As(err, &netErr) && netErr.Timeout()
}
