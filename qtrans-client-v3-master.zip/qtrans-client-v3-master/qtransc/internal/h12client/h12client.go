package h12client

import (
	"crypto/tls"
	"errors"
	"log"
	"net/http"
	"qtransc/internal/sslkeylog"
	"sync"
	"sync/atomic"
	"time"
)

var clientPool *ConnectionPool

type ConnectionPool struct {
	clients    chan *http.Client
	lookup     map[*http.Client]*clientSlot
	transports []*http.Transport
	closeOnce  sync.Once
	closed     int32
	closedCh   chan struct{}
}

func NewConnectionPool(connCount int) (*ConnectionPool, error) {
	if connCount <= 0 {
		connCount = 1
	}

	pool := &ConnectionPool{
		clients:    make(chan *http.Client, connCount),
		lookup:     make(map[*http.Client]*clientSlot, connCount),
		transports: make([]*http.Transport, connCount),
		closedCh:   make(chan struct{}),
	}

	for i := range connCount {
		pool.transports[i] = newHTTPTransport()
	}

	for connIdx := range connCount {
		slot := &clientSlot{pool: pool, connIndex: connIdx}
		client := &http.Client{Transport: pool.transports[connIdx]}
		slot.client = client
		pool.lookup[client] = slot
		pool.clients <- client
	}

	return pool, nil
}

func (p *ConnectionPool) Get() *http.Client {
	if p == nil {
		return nil
	}
	select {
	case client := <-p.clients:
		return client
	case <-p.closedCh:
		return nil
	}
}

func (p *ConnectionPool) GetChan() <-chan *http.Client {
	if p == nil {
		ch := make(chan *http.Client)
		close(ch)
		return ch
	}
	return p.clients
}

func (p *ConnectionPool) Release(client *http.Client) {
	if p == nil || client == nil {
		return
	}
	slot, ok := p.lookup[client]
	if !ok {
		return
	}
	slot.release()
}

func (p *ConnectionPool) Close() {
	if p == nil {
		return
	}
	p.closeOnce.Do(func() {
		atomic.StoreInt32(&p.closed, 1)
		close(p.closedCh)
		for _, transport := range p.transports {
			transport.CloseIdleConnections()
		}
	})
}

func (p *ConnectionPool) isClosed() bool {
	return atomic.LoadInt32(&p.closed) == 1
}

type clientSlot struct {
	client    *http.Client
	pool      *ConnectionPool
	connIndex int
	released  bool
	mu        sync.Mutex
}

func (s *clientSlot) release() {
	s.mu.Lock()
	if s.released {
		s.mu.Unlock()
		return
	}
	s.released = true
	s.mu.Unlock()

	if s.pool == nil || s.pool.isClosed() {
		return
	}

	select {
	case s.pool.clients <- s.client:
		s.mu.Lock()
		s.released = false
		s.mu.Unlock()
	default:
		log.Printf("http1/2 client pool slot is full, dropping client: %p", s.client)
	}
}

func newHTTPTransport() *http.Transport {
	return &http.Transport{
		Proxy:                 http.ProxyFromEnvironment,
		ForceAttemptHTTP2:     true,
		MaxIdleConns:          100,
		MaxIdleConnsPerHost:   1,
		MaxConnsPerHost:       1,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   10 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,
			KeyLogWriter:       sslkeylog.Writer(),
		},
	}
}

func InitClientPool(transports int) error {
	if clientPool != nil {
		return errors.New("connection pool already initialized")
	}
	pool, err := NewConnectionPool(transports)
	if err != nil {
		return err
	}
	clientPool = pool
	return nil
}

func CloseClientPool() {
	if clientPool == nil {
		return
	}
	clientPool.Close()
	clientPool = nil
}

func GetClient() <-chan *http.Client {
	if clientPool == nil {
		ch := make(chan *http.Client)
		close(ch)
		return ch
	}
	return clientPool.GetChan()
}

func GetClientSync() *http.Client {
	if clientPool == nil {
		return nil
	}
	return clientPool.Get()
}

func ReleaseClient(client *http.Client) {
	if clientPool == nil {
		return
	}
	clientPool.Release(client)
}
