package filehash

import (
	"context"
	"encoding/hex"
	"errors"
	"io"
	"os"

	"github.com/zeebo/xxh3"
)

const ChunkSize = 100 * 1024 * 1024

type LayeredHasher struct {
	chunk        *xxh3.Hasher
	overall      *xxh3.Hasher
	chunkBytes   int64
	finalized    bool
	finalizedSum string
}

func NewLayeredHasher() *LayeredHasher {
	return &LayeredHasher{chunk: xxh3.New(), overall: xxh3.New()}
}

func (h *LayeredHasher) Write(p []byte) (int, error) {
	if h == nil {
		return 0, errors.New("nil layered hasher")
	}
	if h.finalized {
		return 0, errors.New("layered hasher already finalized")
	}
	written := 0
	for len(p) > 0 {
		remaining := int64(ChunkSize) - h.chunkBytes
		take := len(p)
		if int64(take) > remaining {
			take = int(remaining)
		}
		n, err := h.chunk.Write(p[:take])
		written += n
		h.chunkBytes += int64(n)
		p = p[n:]
		if err != nil {
			return written, err
		}
		if n != take {
			return written, io.ErrShortWrite
		}
		if h.chunkBytes == int64(ChunkSize) {
			if err := h.commitChunk(); err != nil {
				return written, err
			}
		}
	}
	return written, nil
}

func (h *LayeredHasher) Finalize() (string, error) {
	if h == nil {
		return "", errors.New("nil layered hasher")
	}
	if h.finalized {
		return h.finalizedSum, nil
	}
	if h.chunkBytes > 0 {
		if err := h.commitChunk(); err != nil {
			return "", err
		}
	}
	sum := h.overall.Sum128().Bytes()
	h.finalizedSum = hex.EncodeToString(sum[:])
	h.finalized = true
	return h.finalizedSum, nil
}

func (h *LayeredHasher) commitChunk() error {
	sum := h.chunk.Sum128().Bytes()
	if _, err := h.overall.Write(sum[:]); err != nil {
		return err
	}
	h.chunk = xxh3.New()
	h.chunkBytes = 0
	return nil
}

func CalculateFileHash(filePath string) (string, error) {
	return CalculateFileHashWithBuffer(filePath, make([]byte, ChunkSize))
}

func CalculateFileHashWithBuffer(filePath string, buf []byte) (string, error) {
	return CalculateFileHashWithBufferContext(context.Background(), filePath, buf)
}

func CalculateFileHashWithContext(ctx context.Context, filePath string) (string, error) {
	return CalculateFileHashWithBufferContext(ctx, filePath, make([]byte, ChunkSize))
}

func CalculateFileHashWithBufferContext(ctx context.Context, filePath string, buf []byte) (string, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	overallHasher := xxh3.New()
	if len(buf) < ChunkSize {
		buf = make([]byte, ChunkSize)
	} else {
		buf = buf[:ChunkSize]
	}

	for {
		if err := ctx.Err(); err != nil {
			return "", err
		}
		n, err := io.ReadFull(file, buf)
		if err != nil && err != io.ErrUnexpectedEOF && err != io.EOF {
			return "", err
		}
		if ctxErr := ctx.Err(); ctxErr != nil {
			return "", ctxErr
		}
		if n > 0 {
			chunkHasher := xxh3.New()
			if _, err := chunkHasher.Write(buf[:n]); err != nil {
				return "", err
			}
			chunkBytes := chunkHasher.Sum128().Bytes()
			if _, err := overallHasher.Write(chunkBytes[:]); err != nil {
				return "", err
			}
		}
		if err == io.ErrUnexpectedEOF || err == io.EOF {
			break
		}
	}

	finalBytes := overallHasher.Sum128().Bytes()
	return hex.EncodeToString(finalBytes[:]), nil
}

func CalculateLayeredReaderAt(ctx context.Context, reader io.ReaderAt, size int64) (string, []string, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	chunkCount64 := size / ChunkSize
	if size%ChunkSize != 0 {
		chunkCount64++
	}
	chunkCount := int(chunkCount64)
	chunkHashes := make([]string, 0, chunkCount)
	overallHasher := xxh3.New()
	for index := 0; index < chunkCount; index++ {
		if err := ctx.Err(); err != nil {
			return "", nil, err
		}
		length := int64(ChunkSize)
		if remaining := size - int64(index)*ChunkSize; remaining < length {
			length = remaining
		}
		chunkHash, err := CalculateChunkHashReader(io.NewSectionReader(reader, int64(index)*ChunkSize, length))
		if err != nil {
			return "", nil, err
		}
		chunkHashes = append(chunkHashes, chunkHash)
		decoded, err := hex.DecodeString(chunkHash)
		if err != nil {
			return "", nil, err
		}
		if _, err := overallHasher.Write(decoded); err != nil {
			return "", nil, err
		}
	}
	finalBytes := overallHasher.Sum128().Bytes()
	return hex.EncodeToString(finalBytes[:]), chunkHashes, nil
}

func CalculateChunkHashBytes(content []byte) string {
	hasher := xxh3.New()
	hasher.Write(content)
	sum := hasher.Sum128().Bytes()
	return hex.EncodeToString(sum[:])
}

func CalculateChunkHashReader(r io.Reader) (string, error) {
	hasher := xxh3.New()
	if _, err := io.Copy(hasher, r); err != nil {
		return "", err
	}
	sum := hasher.Sum128().Bytes()
	return hex.EncodeToString(sum[:]), nil
}
