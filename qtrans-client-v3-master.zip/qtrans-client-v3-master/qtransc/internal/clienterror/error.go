// Package clienterror provides the stable, user-facing error contract shared
// by qtransc commands and serve-mode task views.
package clienterror

import (
	"errors"
	"fmt"
	"net/http"
	"regexp"
	"strings"

	"qtransc/internal/authmanager"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/transferlimits"
	"qtransc/internal/transferretry"
)

const (
	CodeClientError               = "CLIENT_ERROR"
	CodeInvalidArgument           = "CLI_INVALID_ARGUMENT"
	CodeAuthConfigInvalid         = "AUTH_CONFIG_INVALID"
	CodeAuthLoginRejected         = "AUTH_LOGIN_REJECTED"
	CodeAuthLoginFailed           = "AUTH_LOGIN_FAILED"
	CodeAuthRefreshFailed         = "AUTH_REFRESH_FAILED"
	CodeAnonymousReadUnavailable  = "ANONYMOUS_READ_UNAVAILABLE"
	CodeAnonymousWriteUnavailable = "ANONYMOUS_WRITE_UNAVAILABLE"
	CodeCapabilityUnavailable     = "CAPABILITY_UNAVAILABLE"
	CodeServerUnavailable         = "SERVER_UNAVAILABLE"
	CodeMutationResultUnknown     = "MUTATION_RESULT_UNKNOWN"
	CodeRecursiveDeletePartial    = "RECURSIVE_DELETE_PARTIAL"
	CodeFileTooLarge              = transferlimits.ReasonFileTooLarge
	CodeTaskFileLimitExceeded     = transferlimits.ReasonTaskFileLimitExceeded
	CodeLocalFileNotFound         = "LOCAL_FILE_NOT_FOUND"
	CodeLocalPathInvalid          = "LOCAL_PATH_INVALID"
	CodeTaskSizeLimitExceeded     = transferlimits.ReasonTaskSizeLimitExceeded
)

// Error contains a stable machine-readable reason and a safe human message.
// Cause is retained only for error matching and optional sanitized diagnostics.
type Error struct {
	ReasonCode string
	Message    string
	Cause      error
}

func (e *Error) Error() string {
	if e == nil {
		return ""
	}
	return e.Message
}

func (e *Error) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.Cause
}

// New preserves a chosen stable code while adding command-specific context.
func New(reasonCode, message string, cause error) *Error {
	return &Error{
		ReasonCode: normalizeCode(reasonCode, CodeClientError),
		Message:    strings.TrimSpace(message),
		Cause:      cause,
	}
}

// Normalize converts known service, authentication and capability errors into
// a safe client-facing representation. Existing Error values are not renamed.
func Normalize(err error) *Error {
	if err == nil {
		return nil
	}

	var known *Error
	if errors.As(err, &known) && known != nil {
		if strings.TrimSpace(known.Message) == "" {
			known.Message = defaultMessage(known.ReasonCode)
		}
		return known
	}

	var limitErr *transferlimits.Error
	if errors.As(err, &limitErr) && limitErr != nil {
		return New(limitErr.ReasonCode, limitErr.Message, err)
	}

	var localIOErr *transferretry.LocalIOError
	if errors.As(err, &localIOErr) && localIOErr != nil {
		return New(CodeLocalPathInvalid, "本地文件系统操作失败，请检查目标路径、权限和可用空间", err)
	}

	var apiErr *qtserverapi.APIError
	if errors.As(err, &apiErr) && apiErr != nil {
		code := normalizeCode(apiErr.ReasonCode, codeForHTTPStatus(apiErr.Status))
		return New(code, apiMessage(code, apiErr.Status), err)
	}

	var capabilitiesErr *qtserverapi.CapabilitiesAccessError
	if errors.As(err, &capabilitiesErr) {
		return New(CodeServerUnavailable, "无法访问 qtserver，请检查服务地址、端口和网关配置", err)
	}
	var versionErr *qtserverapi.UnsupportedAPIVersionError
	if errors.As(err, &versionErr) {
		return New("UNSUPPORTED_API_VERSION", "qtserver API 版本不兼容", err)
	}
	var capabilityErr *qtserverapi.CapabilityUnavailableError
	if errors.As(err, &capabilityErr) {
		return New(CodeCapabilityUnavailable, "服务器未提供所需功能："+strings.TrimSpace(capabilityErr.Name), err)
	}
	var anonymousErr *qtserverapi.AnonymousAccessUnavailableError
	if errors.As(err, &anonymousErr) {
		if anonymousErr.Write {
			return New(CodeAnonymousWriteUnavailable, "当前服务器未启用匿名写入，请使用 --auth-token 或 --auth-username/--auth-password 进行认证", err)
		}
		return New(CodeAnonymousReadUnavailable, "当前服务器未启用匿名读取，请使用 --auth-token 或 --auth-username/--auth-password 进行认证", err)
	}

	switch {
	case authmanager.IsNotInitialized(err), errors.Is(err, authmanager.ErrAccessTokenMissing):
		return New(CodeAuthConfigInvalid, "未配置可用认证信息，请使用 --auth-token 或 --auth-username/--auth-password", err)
	case authmanager.IsModeLocked(err), errors.Is(err, authmanager.ErrAuthModeUnsupported):
		return New(CodeAuthConfigInvalid, "认证配置无效或认证模式已锁定", err)
	case errors.Is(err, authmanager.ErrAuthUnauthorized):
		return New(CodeAuthLoginRejected, "认证被拒绝，请检查认证信息", err)
	case errors.Is(err, authmanager.ErrAuthLoginFailed):
		return New(CodeAuthLoginFailed, "无法完成认证登录，请检查认证服务和认证配置", err)
	case errors.Is(err, authmanager.ErrAuthRefreshFailed):
		return New(CodeAuthRefreshFailed, "无法刷新认证令牌，请重新认证后再试", err)
	}

	message := strings.TrimSpace(err.Error())
	if isConnectionFailure(message) {
		return New(CodeServerUnavailable, "无法连接 qtserver，请检查服务是否启动、地址和端口是否正确", err)
	}
	if looksLikeInvalidArgument(message) {
		return New(CodeInvalidArgument, "命令参数无效；使用 --help 查看用法", err)
	}
	return New(CodeClientError, "客户端执行失败", err)
}

func ReasonCode(err error) string {
	if normalized := Normalize(err); normalized != nil {
		return normalized.ReasonCode
	}
	return ""
}

func Message(err error) string {
	if normalized := Normalize(err); normalized != nil {
		return normalized.Message
	}
	return ""
}

func Diagnostic(err error) string {
	if err == nil {
		return ""
	}
	var normalized *Error
	if errors.As(err, &normalized) && normalized != nil && normalized.Cause != nil {
		err = normalized.Cause
	}
	return redact(err.Error())
}

func normalizeCode(value, fallback string) string {
	value = strings.ToUpper(strings.TrimSpace(value))
	if value == "" {
		return fallback
	}
	return value
}

func codeForHTTPStatus(status int) string {
	switch status {
	case http.StatusBadRequest:
		return "INVALID_REQUEST"
	case http.StatusUnauthorized:
		return "UNAUTHORIZED"
	case http.StatusForbidden:
		return "FORBIDDEN"
	case http.StatusNotFound:
		return "NOT_FOUND"
	case http.StatusConflict:
		return "CONFLICT"
	case http.StatusTooManyRequests:
		return "RATE_LIMITED"
	case http.StatusBadGateway, http.StatusServiceUnavailable, http.StatusGatewayTimeout:
		return CodeServerUnavailable
	default:
		return CodeClientError
	}
}

func apiMessage(code string, status int) string {
	switch code {
	case "NOT_FOUND":
		return "未找到请求的远端路径或资源"
	case "NOT_A_DIRECTORY":
		return "远端路径不是目录"
	case "DAMAGED_SYMLINK":
		return "远端路径是损坏的符号链接"
	case "SYMLINK_LOOP":
		return "远端路径存在符号链接循环"
	case "INVALID_PATH", "INVALID_OBJECT_KEY", "INVALID_REQUEST":
		return "请求路径或参数无效"
	case "UNAUTHORIZED", "INVALID_TOKEN":
		return "认证失败，请检查认证信息"
	case "FORBIDDEN":
		return "没有执行该操作的权限"
	case "ROUTE_NOT_FOUND", CodeCapabilityUnavailable:
		return "服务器未启用所需功能"
	case "DEPENDENCY_UNAVAILABLE", CodeServerUnavailable:
		return "qtserver 暂时不可用，请稍后重试"
	case "NAMESPACE_BUSY", "NAMESPACE_LOCK_LOST", "CONFLICT":
		return "远端状态发生冲突，请稍后重试"
	case "RATE_LIMITED":
		return "请求过于频繁，请稍后重试"
	case "DIRECTORY_NOT_EMPTY":
		return "目录非空，无法删除"
	case CodeFileTooLarge:
		return "文件大小超过服务器允许的单文件上限"
	case CodeTaskFileLimitExceeded:
		return taskFileLimitMessage()
	case CodeLocalFileNotFound:
		return "指定的本地文件或目录不存在"
	case CodeLocalPathInvalid:
		return "本地路径无效或无法用于当前操作"
	case CodeTaskSizeLimitExceeded:
		return "单次传输任务总量超过用户配置的上限"
	case "UNSUPPORTED_FILE_TYPE":
		return "不支持操作此类文件"
	case "INTERNAL_ERROR", "NAMESPACE_OPERATION_PARTIAL", CodeMutationResultUnknown:
		return "操作结果未确认，请检查远端状态后再决定是否重试"
	}
	if status >= http.StatusInternalServerError {
		return "qtserver 返回内部错误，请稍后重试"
	}
	return defaultMessage(code)
}

func defaultMessage(code string) string {
	switch code {
	case CodeInvalidArgument:
		return "命令参数无效；使用 --help 查看用法"
	case CodeAuthConfigInvalid:
		return "认证配置无效"
	case CodeAuthLoginRejected:
		return "认证被拒绝，请检查认证信息"
	case CodeAuthLoginFailed:
		return "无法完成认证登录"
	case CodeAuthRefreshFailed:
		return "无法刷新认证令牌"
	case CodeAnonymousReadUnavailable:
		return "当前服务器未启用匿名读取"
	case CodeAnonymousWriteUnavailable:
		return "当前服务器未启用匿名写入"
	case CodeCapabilityUnavailable:
		return "服务器未提供所需功能"
	case CodeServerUnavailable:
		return "qtserver 暂时不可用，请稍后重试"
	case CodeMutationResultUnknown:
		return "操作结果未确认，请检查远端状态"
	case CodeRecursiveDeletePartial:
		return "递归删除未完成，部分节点可能已删除"
	case CodeFileTooLarge:
		return "文件大小超过服务器允许的单文件上限"
	case CodeTaskFileLimitExceeded:
		return taskFileLimitMessage()
	case CodeLocalFileNotFound:
		return "指定的本地文件或目录不存在"
	case CodeLocalPathInvalid:
		return "本地路径无效或无法用于当前操作"
	case CodeTaskSizeLimitExceeded:
		return "单次传输任务总量超过用户配置的上限"
	default:
		return "客户端执行失败"
	}
}

func taskFileLimitMessage() string {
	return fmt.Sprintf("单次传输任务的普通文件数超过 %d 个上限", transferlimits.MaxTaskFiles)
}

func isConnectionFailure(message string) bool {
	lower := strings.ToLower(message)
	for _, marker := range []string{
		"connection refused", "no route to host", "network is unreachable", "no such host",
		"server misbehaving", "context deadline exceeded", "i/o timeout", "tls handshake timeout",
	} {
		if strings.Contains(lower, marker) {
			return true
		}
	}
	return false
}

func looksLikeInvalidArgument(message string) bool {
	lower := strings.ToLower(message)
	return strings.Contains(lower, "--") || strings.Contains(lower, "accepts ") ||
		strings.Contains(lower, "requires ") || strings.Contains(lower, "invalid argument") ||
		strings.Contains(lower, "must not be empty")
}

var (
	bearerPattern = regexp.MustCompile(`(?i)(bearer\s+)[^\s,;]+`)
	secretPattern = regexp.MustCompile(`(?i)((?:username|password|token|secret|authorization)\s*[=:]\s*)[^\s,;]+`)
)

func redact(value string) string {
	value = bearerPattern.ReplaceAllString(value, "${1}[REDACTED]")
	value = secretPattern.ReplaceAllString(value, "${1}[REDACTED]")
	return strings.TrimSpace(value)
}

func Format(err error, debug bool) string {
	normalized := Normalize(err)
	if normalized == nil {
		return ""
	}
	line := fmt.Sprintf("Error [%s]: %s", normalized.ReasonCode, normalized.Message)
	if !debug {
		return line
	}
	diagnostic := Diagnostic(err)
	if diagnostic == "" || diagnostic == normalized.Message {
		return line
	}
	return line + "\n详细信息: " + diagnostic
}
