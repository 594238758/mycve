package transportpool

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"sync"
	"time"

	"golang.org/x/net/http2"
)

type HTTPDriverConfig struct {
	TLSClientConfig *tls.Config
	Proxy           func(*http.Request) (*url.URL, error)
	ConnectTimeout  time.Duration
}

type httpProtocol uint8

const (
	protocolHTTP1 httpProtocol = iota
	protocolHTTP2TLS
)

type httpDriver struct {
	name      string
	protocol  httpProtocol
	transport *http.Transport
	timeout   time.Duration
}

func NewHTTP1TLSDriver(config HTTPDriverConfig) Driver {
	protocols := new(http.Protocols)
	protocols.SetHTTP1(true)
	return &httpDriver{
		name: "stdlib-http1-tls-v1", protocol: protocolHTTP1,
		transport: newDirectHTTPTransport(config, protocols, []string{"http/1.1"}, func(protocol string) error {
			if protocol == "" || protocol == "http/1.1" {
				return nil
			}
			return &ProtocolNegotiationError{Transport: "v1", Expected: "HTTP/1.1 or no", Actual: protocol}
		}),
		timeout: normalizedConnectTimeout(config.ConnectTimeout),
	}
}

func NewHTTP2TLSDriver(config HTTPDriverConfig) Driver {
	protocols := new(http.Protocols)
	protocols.SetHTTP2(true)
	return &httpDriver{
		name: "stdlib-http2-tls-v1", protocol: protocolHTTP2TLS,
		transport: newDirectHTTPTransport(config, protocols, []string{"h2"}, func(protocol string) error {
			if protocol == "h2" {
				return nil
			}
			return &ProtocolNegotiationError{Transport: "v2", Expected: "h2", Actual: protocol}
		}),
		timeout: normalizedConnectTimeout(config.ConnectTimeout),
	}
}

func newDirectHTTPTransport(
	config HTTPDriverConfig,
	protocols *http.Protocols,
	nextProtos []string,
	validateALPN func(string) error,
) *http.Transport {
	tlsConfig := cloneTLSConfig(config.TLSClientConfig)
	tlsConfig.NextProtos = append([]string(nil), nextProtos...)
	previousVerifyConnection := tlsConfig.VerifyConnection
	tlsConfig.VerifyConnection = func(state tls.ConnectionState) error {
		if previousVerifyConnection != nil {
			if err := previousVerifyConnection(state); err != nil {
				return err
			}
		}
		return validateALPN(state.NegotiatedProtocol)
	}
	transport := &http.Transport{
		Proxy:               config.Proxy,
		Protocols:           protocols,
		TLSClientConfig:     tlsConfig,
		DisableCompression:  true,
		ForceAttemptHTTP2:   protocols.HTTP2(),
		TLSHandshakeTimeout: normalizedConnectTimeout(config.ConnectTimeout),
		MaxIdleConns:        1,
		MaxIdleConnsPerHost: 1,
		MaxConnsPerHost:     1,
	}
	if protocols.HTTP2() {
		transport.HTTP2 = &http.HTTP2Config{StrictMaxConcurrentRequests: true}
	}
	return transport
}

func (d *httpDriver) Name() string {
	return d.name
}

func (d *httpDriver) Validate(limits Limits) error {
	if d.protocol == protocolHTTP1 && limits.MaxLeasesPerConnection != 1 {
		return errors.New("HTTP/1.1 requires MaxLeasesPerConnection == 1")
	}
	return nil
}

func (d *httpDriver) Open(
	_ context.Context,
	origin Origin,
	limits Limits,
) (OriginPool, error) {
	switch d.protocol {
	case protocolHTTP1:
		if origin.Scheme != "https" {
			return nil, errors.New("HTTP/1.1 over TLS requires an https origin")
		}
	case protocolHTTP2TLS:
		if origin.Scheme != "https" {
			return nil, errors.New("HTTP/2 over TLS requires an https origin")
		}
		return newManagedOriginPool(origin, d.name, limits, &http2ConnectionFactory{
			transport: d.transport,
			timeout:   d.timeout,
		}), nil
	}
	return newManagedOriginPool(origin, d.name, limits, &httpConnectionFactory{
		transport: d.transport,
		timeout:   d.timeout,
	}), nil
}

type httpConnectionFactory struct {
	transport *http.Transport
	timeout   time.Duration
}

func (f *httpConnectionFactory) Connect(ctx context.Context, origin Origin) (connection, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	transport := f.transport.Clone()
	transport.IdleConnTimeout = f.timeout
	tracker := newHTTPConnectionTracker()
	dialer := &net.Dialer{Timeout: f.timeout, KeepAlive: 30 * time.Second}
	transport.DialContext = func(ctx context.Context, network, address string) (net.Conn, error) {
		conn, err := dialer.DialContext(ctx, network, address)
		if err != nil {
			return nil, err
		}
		return tracker.Track(conn)
	}
	return &managedHTTPTransport{transport: transport, tracker: tracker}, nil
}

type managedHTTPTransport struct {
	transport *http.Transport
	tracker   *httpConnectionTracker
	closeOnce sync.Once
}

func (c *managedHTTPTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	return c.transport.RoundTrip(req)
}

func (c *managedHTTPTransport) Close() error {
	c.closeOnce.Do(func() {
		c.transport.CloseIdleConnections()
		c.tracker.Close()
	})
	return nil
}

func (c *managedHTTPTransport) Healthy() bool {
	return !c.tracker.Closed()
}

type http2ConnectionFactory struct {
	transport *http.Transport
	timeout   time.Duration
}

func (f *http2ConnectionFactory) Connect(ctx context.Context, origin Origin) (connection, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	transport := f.transport.Clone()
	transport.IdleConnTimeout = f.timeout
	if _, err := http2.ConfigureTransports(transport); err != nil {
		return nil, fmt.Errorf("configure HTTP/2 lane: %w", err)
	}
	tracker := newHTTPConnectionTracker()
	dialer := &net.Dialer{Timeout: f.timeout, KeepAlive: 30 * time.Second}
	transport.DialContext = func(ctx context.Context, network, address string) (net.Conn, error) {
		conn, err := dialer.DialContext(ctx, network, address)
		if err != nil {
			return nil, err
		}
		return tracker.Track(conn)
	}
	return &managedHTTP2Connection{transport: transport, tracker: tracker, origin: origin}, nil
}

// managedHTTP2Connection owns exactly one lazily established HTTP/2 client
// connection. http.Transport.NewClientConn preserves proxy and TLS handling
// while avoiding Transport's shared connection cache and its extra dials.
type managedHTTP2Connection struct {
	transport *http.Transport
	tracker   *httpConnectionTracker
	origin    Origin

	mu         sync.Mutex
	clientConn *http.ClientConn
	connectCh  chan struct{}
	connectErr error
	closed     bool
	closeOnce  sync.Once
}

func (c *managedHTTP2Connection) RoundTrip(req *http.Request) (*http.Response, error) {
	if req == nil {
		return nil, errors.New("HTTP/2 request is nil")
	}
	clientConn, err := c.ensureConnected(req.Context())
	if err != nil {
		return nil, err
	}
	return clientConn.RoundTrip(req)
}

func (c *managedHTTP2Connection) ensureConnected(ctx context.Context) (*http.ClientConn, error) {
	for {
		c.mu.Lock()
		if c.closed {
			c.mu.Unlock()
			return nil, ErrPoolClosed
		}
		if c.clientConn != nil {
			clientConn := c.clientConn
			if err := clientConn.Err(); err != nil {
				c.clientConn = nil
				c.connectCh = nil
				c.connectErr = nil
				c.mu.Unlock()
				_ = clientConn.Close()
				continue
			}
			c.mu.Unlock()
			return clientConn, nil
		}
		if c.connectErr != nil {
			err := c.connectErr
			c.mu.Unlock()
			return nil, err
		}
		if c.connectCh == nil {
			c.connectCh = make(chan struct{})
			connectCh := c.connectCh
			c.mu.Unlock()

			clientConn, err := c.transport.NewClientConn(ctx, c.origin.Scheme, c.origin.HostPort)
			c.mu.Lock()
			if c.closed && clientConn != nil {
				_ = clientConn.Close()
				clientConn = nil
				err = ErrPoolClosed
			}
			if err != nil {
				c.connectErr = err
			} else {
				c.clientConn = clientConn
			}
			close(connectCh)
			c.mu.Unlock()
			if err != nil {
				return nil, err
			}
			return clientConn, nil
		}
		connectCh := c.connectCh
		c.mu.Unlock()

		select {
		case <-connectCh:
		case <-ctx.Done():
			return nil, ctx.Err()
		}
	}
}

func (c *managedHTTP2Connection) Close() error {
	c.closeOnce.Do(func() {
		c.mu.Lock()
		c.closed = true
		clientConn := c.clientConn
		c.mu.Unlock()
		if clientConn != nil {
			_ = clientConn.Close()
		}
		c.transport.CloseIdleConnections()
		c.tracker.Close()
	})
	return nil
}

func (c *managedHTTP2Connection) Healthy() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.closed || c.connectErr != nil || c.tracker.Closed() {
		return false
	}
	return c.clientConn == nil || c.clientConn.Err() == nil
}

type httpConnectionTracker struct {
	mu     sync.Mutex
	closed bool
	conns  map[*trackedHTTPConn]struct{}
}

func newHTTPConnectionTracker() *httpConnectionTracker {
	return &httpConnectionTracker{conns: make(map[*trackedHTTPConn]struct{})}
}

func (t *httpConnectionTracker) Track(conn net.Conn) (net.Conn, error) {
	tracked := &trackedHTTPConn{Conn: conn, owner: t}
	t.mu.Lock()
	if t.closed {
		t.mu.Unlock()
		_ = conn.Close()
		return nil, ErrPoolClosed
	}
	t.conns[tracked] = struct{}{}
	t.mu.Unlock()
	return tracked, nil
}

func (t *httpConnectionTracker) remove(conn *trackedHTTPConn) {
	t.mu.Lock()
	delete(t.conns, conn)
	t.mu.Unlock()
}

func (t *httpConnectionTracker) Close() {
	t.mu.Lock()
	if t.closed {
		t.mu.Unlock()
		return
	}
	t.closed = true
	conns := make([]*trackedHTTPConn, 0, len(t.conns))
	for conn := range t.conns {
		conns = append(conns, conn)
	}
	t.mu.Unlock()
	for _, conn := range conns {
		_ = conn.Close()
	}
}

func (t *httpConnectionTracker) Closed() bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.closed
}

type trackedHTTPConn struct {
	net.Conn
	owner *httpConnectionTracker
	once  sync.Once
}

func (c *trackedHTTPConn) Close() error {
	err := c.Conn.Close()
	c.once.Do(func() { c.owner.remove(c) })
	return err
}

func cloneTLSConfig(config *tls.Config) *tls.Config {
	if config == nil {
		return &tls.Config{}
	}
	return config.Clone()
}

func normalizedConnectTimeout(timeout time.Duration) time.Duration {
	if timeout <= 0 {
		return 30 * time.Second
	}
	return timeout
}
