package transportpool

import (
	"context"
	"errors"
	"io"
	"net/http"
	"sync"
	"time"
)

type connection interface {
	RoundTrip(*http.Request) (*http.Response, error)
	Close() error
	Healthy() bool
}

type connectionFactory interface {
	Connect(context.Context, Origin) (connection, error)
}

type connectionState uint8

const (
	connectionNew connectionState = iota
	connectionConnecting
	connectionReady
	connectionFailed
	connectionClosed
)

type managedOriginPool struct {
	origin  Origin
	driver  string
	limits  Limits
	factory connectionFactory

	ctx    context.Context
	cancel context.CancelCauseFunc

	mu      sync.Mutex
	closed  bool
	lanes   []*connectionLane
	waiters []*acquireWaiter
	next    int
	wake    chan struct{}

	closeOnce sync.Once
	closeErr  error
	connectWG sync.WaitGroup
}

type connectionLane struct {
	owner *managedOriginPool

	state      connectionState
	active     int
	conn       connection
	connectCh  chan struct{}
	connectErr error
	idleSince  time.Time
}

type acquireWaiter struct {
	ch chan leaseResult
}

type leaseResult struct {
	lease Lease
	err   error
}

func newManagedOriginPool(
	origin Origin,
	driver string,
	limits Limits,
	factory connectionFactory,
) *managedOriginPool {
	ctx, cancel := context.WithCancelCause(context.Background())
	p := &managedOriginPool{
		origin: origin, driver: driver, limits: limits, factory: factory,
		ctx: ctx, cancel: cancel, wake: make(chan struct{}, 1),
	}
	if limits.ConnectionIdleTimeout > 0 {
		go p.reapIdle()
	}
	return p
}

func (p *managedOriginPool) Acquire(ctx context.Context) (Lease, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	p.mu.Lock()
	if p.closed {
		p.mu.Unlock()
		return nil, p.newError("acquire", ErrorPoolClosed, RequestNotSent, ErrPoolClosed)
	}
	if len(p.waiters) == 0 {
		if lane := p.reserveLaneLocked(); lane != nil {
			p.mu.Unlock()
			return newManagedLease(p, lane), nil
		}
	}
	waiter := &acquireWaiter{ch: make(chan leaseResult, 1)}
	p.waiters = append(p.waiters, waiter)
	p.mu.Unlock()

	select {
	case result := <-waiter.ch:
		return result.lease, result.err
	case <-ctx.Done():
		p.mu.Lock()
		for i, candidate := range p.waiters {
			if candidate == waiter {
				p.waiters = append(p.waiters[:i], p.waiters[i+1:]...)
				p.mu.Unlock()
				return nil, ctx.Err()
			}
		}
		p.mu.Unlock()
		result := <-waiter.ch
		if result.lease != nil {
			result.lease.Release()
		}
		return nil, ctx.Err()
	}
}

func (p *managedOriginPool) reserveLaneLocked() *connectionLane {
	// Spread the first concurrent requests across lanes so multiple physical
	// connections can be established before stacking streams on a lane.
	if lane := p.selectLaneLocked(true); lane != nil {
		return p.reserveSelectedLaneLocked(lane)
	}
	if len(p.lanes) < p.limits.MaxConnections {
		lane := &connectionLane{owner: p, state: connectionNew, active: 1}
		p.lanes = append(p.lanes, lane)
		p.next = len(p.lanes) % p.limits.MaxConnections
		return lane
	}
	if lane := p.selectLaneLocked(false); lane != nil {
		return p.reserveSelectedLaneLocked(lane)
	}
	return nil
}

func (p *managedOriginPool) selectLaneLocked(idleOnly bool) *connectionLane {
	if len(p.lanes) == 0 {
		return nil
	}
	var selected *connectionLane
	start := p.next % len(p.lanes)
	for offset := range len(p.lanes) {
		lane := p.lanes[(start+offset)%len(p.lanes)]
		if lane.state != connectionNew && lane.state != connectionConnecting && lane.state != connectionReady {
			continue
		}
		if lane.active >= p.limits.MaxLeasesPerConnection || (idleOnly && lane.active != 0) {
			continue
		}
		if selected == nil || lane.active < selected.active {
			selected = lane
		}
	}
	return selected
}

func (p *managedOriginPool) reserveSelectedLaneLocked(lane *connectionLane) *connectionLane {
	lane.active++
	lane.idleSince = time.Time{}
	for i, candidate := range p.lanes {
		if candidate == lane {
			p.next = (i + 1) % len(p.lanes)
			break
		}
	}
	return lane
}

func (p *managedOriginPool) dispatchLocked() {
	for len(p.waiters) > 0 {
		lane := p.reserveLaneLocked()
		if lane == nil {
			return
		}
		waiter := p.waiters[0]
		p.waiters = p.waiters[1:]
		waiter.ch <- leaseResult{lease: newManagedLease(p, lane)}
	}
}

func (p *managedOriginPool) ensureConnected(ctx context.Context, lane *connectionLane) (connection, error) {
	p.mu.Lock()
	switch lane.state {
	case connectionReady:
		conn := lane.conn
		p.mu.Unlock()
		return conn, nil
	case connectionNew:
		lane.state = connectionConnecting
		lane.connectCh = make(chan struct{})
		p.connectWG.Add(1)
		go p.connect(lane)
	case connectionConnecting:
	case connectionFailed, connectionClosed:
		err := lane.connectErr
		if err == nil {
			err = errors.New("connection is not usable")
		}
		p.mu.Unlock()
		return nil, p.newError("connect", ErrorConnect, RequestNotSent, err)
	}
	wait := lane.connectCh
	p.mu.Unlock()

	select {
	case <-wait:
	case <-ctx.Done():
		return nil, p.newError("connect", errorKindForContext(ctx.Err()), RequestNotSent, ctx.Err())
	case <-p.ctx.Done():
		return nil, p.newError("connect", ErrorPoolClosed, RequestNotSent, ErrPoolClosed)
	}

	p.mu.Lock()
	conn, err := lane.conn, lane.connectErr
	state := lane.state
	p.mu.Unlock()
	if state != connectionReady || conn == nil {
		if err == nil {
			err = errors.New("connection failed")
		}
		return nil, p.newError("connect", ErrorConnect, RequestNotSent, err)
	}
	return conn, nil
}

func (p *managedOriginPool) connect(lane *connectionLane) {
	defer p.connectWG.Done()
	conn, err := p.factory.Connect(p.ctx, p.origin)
	var closeConn connection
	p.mu.Lock()
	if p.closed {
		lane.state = connectionClosed
		lane.connectErr = ErrPoolClosed
		closeConn = conn
	} else if err != nil {
		lane.state = connectionFailed
		lane.connectErr = err
		if lane.active == 0 {
			p.removeLaneLocked(lane)
		}
	} else {
		lane.state = connectionReady
		lane.conn = conn
		if lane.active == 0 {
			lane.idleSince = time.Now()
			p.signalReaperLocked()
		}
	}
	close(lane.connectCh)
	p.dispatchLocked()
	p.mu.Unlock()
	if closeConn != nil {
		_ = closeConn.Close()
	}
}

func (p *managedOriginPool) releaseLane(lane *connectionLane, requestErr error) {
	var closeConn connection
	p.mu.Lock()
	if lane.active > 0 {
		lane.active--
	}
	if p.closed {
		p.mu.Unlock()
		return
	}
	if requestErr != nil && lane.conn != nil && !lane.conn.Healthy() {
		lane.state = connectionFailed
		lane.connectErr = requestErr
	}
	if lane.active == 0 {
		switch lane.state {
		case connectionFailed, connectionClosed:
			lane.state = connectionClosed
			closeConn = lane.conn
			lane.conn = nil
			p.removeLaneLocked(lane)
		case connectionNew:
			p.removeLaneLocked(lane)
		case connectionConnecting:
		case connectionReady:
			lane.idleSince = time.Now()
			p.signalReaperLocked()
		}
	}
	p.dispatchLocked()
	p.mu.Unlock()
	if closeConn != nil {
		_ = closeConn.Close()
	}
}

func (p *managedOriginPool) removeLaneLocked(target *connectionLane) {
	for i, lane := range p.lanes {
		if lane == target {
			p.lanes = append(p.lanes[:i], p.lanes[i+1:]...)
			if len(p.lanes) == 0 {
				p.next = 0
			} else {
				p.next %= len(p.lanes)
			}
			return
		}
	}
}

func (p *managedOriginPool) signalReaperLocked() {
	select {
	case p.wake <- struct{}{}:
	default:
	}
}

func (p *managedOriginPool) reapIdle() {
	for {
		p.mu.Lock()
		if p.closed {
			p.mu.Unlock()
			return
		}
		var deadline time.Time
		for _, lane := range p.lanes {
			if lane.state != connectionReady || lane.active != 0 || lane.idleSince.IsZero() {
				continue
			}
			candidate := lane.idleSince.Add(p.limits.ConnectionIdleTimeout)
			if deadline.IsZero() || candidate.Before(deadline) {
				deadline = candidate
			}
		}
		p.mu.Unlock()

		var timer <-chan time.Time
		var t *time.Timer
		if !deadline.IsZero() {
			wait := time.Until(deadline)
			if wait < 0 {
				wait = 0
			}
			t = time.NewTimer(wait)
			timer = t.C
		}
		select {
		case <-p.ctx.Done():
			if t != nil {
				t.Stop()
			}
			return
		case <-p.wake:
			if t != nil {
				t.Stop()
			}
		case <-timer:
			p.closeExpiredIdle()
		}
	}
}

func (p *managedOriginPool) closeExpiredIdle() {
	var conns []connection
	now := time.Now()
	p.mu.Lock()
	for index := len(p.lanes) - 1; index >= 0; index-- {
		lane := p.lanes[index]
		if lane.state == connectionReady && lane.active == 0 &&
			!lane.idleSince.IsZero() &&
			!now.Before(lane.idleSince.Add(p.limits.ConnectionIdleTimeout)) {
			lane.state = connectionClosed
			conns = append(conns, lane.conn)
			p.lanes = append(p.lanes[:index], p.lanes[index+1:]...)
		}
	}
	if len(p.lanes) == 0 {
		p.next = 0
	} else {
		p.next %= len(p.lanes)
	}
	p.dispatchLocked()
	p.mu.Unlock()
	for _, conn := range conns {
		if conn != nil {
			_ = conn.Close()
		}
	}
}

func (p *managedOriginPool) Close() error {
	p.closeOnce.Do(func() {
		p.mu.Lock()
		p.closed = true
		p.cancel(ErrPoolClosed)
		var conns []connection
		for _, lane := range p.lanes {
			lane.state = connectionClosed
			if lane.conn != nil {
				conns = append(conns, lane.conn)
			}
		}
		for _, waiter := range p.waiters {
			waiter.ch <- leaseResult{err: p.newError("acquire", ErrorPoolClosed, RequestNotSent, ErrPoolClosed)}
		}
		p.waiters = nil
		p.lanes = nil
		p.mu.Unlock()
		var errs []error
		for _, conn := range conns {
			if err := conn.Close(); err != nil {
				errs = append(errs, err)
			}
		}
		p.connectWG.Wait()
		p.closeErr = errors.Join(errs...)
	})
	return p.closeErr
}

func (p *managedOriginPool) snapshot() OriginSnapshot {
	p.mu.Lock()
	defer p.mu.Unlock()
	s := OriginSnapshot{
		Origin: p.origin, Connections: len(p.lanes),
		WaitingAcquires: len(p.waiters),
	}
	for _, lane := range p.lanes {
		s.ActiveLeases += lane.active
		switch lane.state {
		case connectionNew:
			s.New++
		case connectionConnecting:
			s.Connecting++
		case connectionReady:
			s.Ready++
		case connectionFailed:
			s.Failed++
		}
	}
	return s
}

func (p *managedOriginPool) newError(op string, kind ErrorKind, state RequestState, cause error) error {
	return &Error{
		Kind: kind, Op: op, Origin: p.origin, Driver: p.driver,
		State: state, Cause: cause,
	}
}

type managedLease struct {
	pool *managedOriginPool
	lane *connectionLane

	mu       sync.Mutex
	used     bool
	released bool
	cancel   context.CancelCauseFunc
	body     io.Closer
	doneOnce sync.Once
}

func newManagedLease(pool *managedOriginPool, lane *connectionLane) *managedLease {
	return &managedLease{pool: pool, lane: lane}
}

func (l *managedLease) RoundTrip(req *http.Request) (*http.Response, error) {
	l.mu.Lock()
	if l.used {
		l.mu.Unlock()
		return nil, l.pool.newError("round-trip", ErrorLeaseUsed, RequestNotSent, ErrLeaseUsed)
	}
	if l.released {
		l.mu.Unlock()
		return nil, l.pool.newError("round-trip", ErrorLeaseReleased, RequestNotSent, ErrLeaseReleased)
	}
	l.used = true
	l.mu.Unlock()

	if req == nil || req.URL == nil || !req.URL.IsAbs() {
		err := errors.New("request URL must be absolute")
		l.finish(err)
		return nil, l.pool.newError("round-trip", ErrorOriginMismatch, RequestNotSent, err)
	}
	requestOrigin, err := OriginFromURL(req.URL)
	if err != nil || requestOrigin != l.pool.origin {
		if err == nil {
			err = ErrOriginMismatch
		}
		l.finish(err)
		return nil, l.pool.newError("round-trip", ErrorOriginMismatch, RequestNotSent, err)
	}

	reqCtx, cancel := context.WithCancelCause(req.Context())
	reqCopy := req.Clone(reqCtx)
	reqCopy.Body = req.Body
	l.mu.Lock()
	if l.released {
		l.mu.Unlock()
		cancel(ErrLeaseReleased)
		l.finish(ErrLeaseReleased)
		return nil, l.pool.newError("round-trip", ErrorLeaseReleased, RequestNotSent, ErrLeaseReleased)
	}
	l.cancel = cancel
	l.mu.Unlock()

	conn, err := l.pool.ensureConnected(reqCtx, l.lane)
	if err != nil {
		cancel(nil)
		if req.Body != nil {
			_ = req.Body.Close()
		}
		l.finish(err)
		return nil, err
	}
	l.mu.Lock()
	if l.released {
		l.mu.Unlock()
		l.finish(ErrLeaseReleased)
		return nil, l.pool.newError("round-trip", ErrorLeaseReleased, RequestNotSent, ErrLeaseReleased)
	}
	l.mu.Unlock()

	resp, err := conn.RoundTrip(reqCopy)
	if req.Body != nil {
		_ = req.Body.Close()
	}
	if err != nil {
		cancel(nil)
		l.finish(err)
		return nil, l.pool.newError("round-trip", errorKindForContext(err), RequestPossiblySent, err)
	}
	if resp == nil || resp.Body == nil {
		cancel(nil)
		l.finish(nil)
		return resp, nil
	}

	body := &leaseBody{ReadCloser: resp.Body, lease: l}
	l.mu.Lock()
	if l.released {
		l.mu.Unlock()
		_ = body.Close()
		return nil, l.pool.newError("round-trip", ErrorLeaseReleased, ResponseStarted, ErrLeaseReleased)
	}
	l.body = body
	l.mu.Unlock()
	resp.Body = body
	return resp, nil
}

func (l *managedLease) Release() {
	l.mu.Lock()
	if l.released {
		l.mu.Unlock()
		return
	}
	l.released = true
	cancel, body := l.cancel, l.body
	l.mu.Unlock()
	if cancel != nil {
		cancel(ErrLeaseReleased)
	}
	if body != nil {
		_ = body.Close()
	}
	l.finish(nil)
}

func (l *managedLease) finish(err error) {
	l.doneOnce.Do(func() {
		l.mu.Lock()
		l.released = true
		cancel := l.cancel
		l.mu.Unlock()
		if cancel != nil {
			cancel(nil)
		}
		l.pool.releaseLane(l.lane, err)
	})
}

type leaseBody struct {
	io.ReadCloser
	lease *managedLease
	once  sync.Once
}

func (b *leaseBody) Read(p []byte) (int, error) {
	n, err := b.ReadCloser.Read(p)
	if err != nil {
		resultErr := err
		b.once.Do(func() {
			if errors.Is(err, io.EOF) {
				b.lease.finish(nil)
			} else {
				resultErr = b.lease.pool.newError(
					"read-response", ErrorResponseRead, ResponseStarted, err,
				)
				b.lease.finish(resultErr)
			}
		})
		return n, resultErr
	}
	return n, err
}

func (b *leaseBody) Close() error {
	err := b.ReadCloser.Close()
	b.once.Do(func() {
		if err != nil {
			err = b.lease.pool.newError("close-response", ErrorResponseRead, ResponseStarted, err)
		}
		b.lease.finish(err)
	})
	return err
}

var _ OriginPool = (*managedOriginPool)(nil)
var _ Lease = (*managedLease)(nil)
