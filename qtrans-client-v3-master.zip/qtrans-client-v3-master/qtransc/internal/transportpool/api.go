package transportpool

import (
	"context"
	"net/http"
	"time"
)

type Config struct {
	MaxOrigins int
	PerOrigin  Limits
}

type Limits struct {
	MaxConnections         int
	MaxLeasesPerConnection int
	ConnectionIdleTimeout  time.Duration
}

type Pool interface {
	Acquire(ctx context.Context, origin Origin) (Lease, error)
	Close() error
}

type Lease interface {
	RoundTrip(req *http.Request) (*http.Response, error)
	Release()
}

type Driver interface {
	Name() string
	Validate(limits Limits) error
	Open(ctx context.Context, origin Origin, limits Limits) (OriginPool, error)
}

type OriginPool interface {
	Acquire(ctx context.Context) (Lease, error)
	Close() error
}

type Inspector interface {
	Snapshot() Snapshot
}

type Snapshot struct {
	Driver  string
	Closed  bool
	Origins []OriginSnapshot
}

type OriginSnapshot struct {
	Origin Origin

	Connections int
	New         int
	Connecting  int
	Ready       int
	Draining    int
	Failed      int

	ActiveLeases    int
	WaitingAcquires int
}
