package transportpool

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"net"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/quic-go/quic-go"
)

type http3OriginResources struct {
	ctx    context.Context
	cancel context.CancelCauseFunc

	permits chan struct{}
	closed  atomic.Bool

	mu       sync.Mutex
	active   map[*http3PhysicalConnection]struct{}
	closeErr []error
	wg       sync.WaitGroup

	closeOnce sync.Once
	resultErr error
}

func newHTTP3OriginResources(maxConnections int) *http3OriginResources {
	ctx, cancel := context.WithCancelCause(context.Background())
	return &http3OriginResources{
		ctx:     ctx,
		cancel:  cancel,
		permits: make(chan struct{}, maxConnections),
		active:  make(map[*http3PhysicalConnection]struct{}),
	}
}

func (r *http3OriginResources) Closed() bool {
	return r.closed.Load()
}

func (r *http3OriginResources) Dial(
	ctx context.Context,
	addr string,
	tlsConfig *tls.Config,
	quicConfig *quic.Config,
	timeout time.Duration,
) (*quic.Conn, error) {
	resource, err := r.reserve(ctx)
	if err != nil {
		return nil, err
	}

	dialCtx, cancel := context.WithTimeout(ctx, timeout)
	stopOriginCancel := context.AfterFunc(r.ctx, cancel)
	defer func() {
		stopOriginCancel()
		cancel()
	}()

	udpAddr, err := resolveHTTP3UDPAddr(dialCtx, addr)
	if err != nil {
		resource.release()
		return nil, err
	}
	if err := dialCtx.Err(); err != nil {
		resource.release()
		return nil, err
	}

	packetConn, err := net.ListenUDP("udp", nil)
	if err != nil {
		resource.release()
		return nil, err
	}
	resource.packetConn = packetConn
	resource.transport = &quic.Transport{Conn: packetConn}

	if tlsConfig == nil {
		tlsConfig = &tls.Config{}
	} else {
		tlsConfig = tlsConfig.Clone()
	}
	if quicConfig == nil {
		quicConfig = &quic.Config{}
	} else {
		quicConfig = quicConfig.Clone()
	}

	quicConn, err := resource.transport.DialEarly(dialCtx, udpAddr, tlsConfig, quicConfig)
	if err != nil {
		resource.release()
		return nil, err
	}
	resource.conn = quicConn
	if !r.register(resource) {
		_ = quicConn.CloseWithError(0, "")
		resource.release()
		return nil, ErrPoolClosed
	}

	go func() {
		<-quicConn.Context().Done()
		resource.release()
	}()
	return quicConn, nil
}

func resolveHTTP3UDPAddr(ctx context.Context, addr string) (*net.UDPAddr, error) {
	host, portText, err := net.SplitHostPort(addr)
	if err != nil {
		return nil, err
	}
	port, err := strconv.ParseUint(portText, 10, 16)
	if err != nil {
		return nil, fmt.Errorf("invalid UDP port %q: %w", portText, err)
	}

	zone := ""
	if index := strings.LastIndexByte(host, '%'); index >= 0 {
		zone = host[index+1:]
		host = host[:index]
	}
	if ip := net.ParseIP(host); ip != nil {
		return &net.UDPAddr{IP: ip, Port: int(port), Zone: zone}, nil
	}

	addresses, err := net.DefaultResolver.LookupIPAddr(ctx, host)
	if err != nil {
		return nil, err
	}
	if len(addresses) == 0 {
		return nil, fmt.Errorf("no IP address found for %q", host)
	}
	return &net.UDPAddr{IP: addresses[0].IP, Port: int(port), Zone: addresses[0].Zone}, nil
}

func (r *http3OriginResources) reserve(ctx context.Context) (*http3PhysicalConnection, error) {
	select {
	case r.permits <- struct{}{}:
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-r.ctx.Done():
		return nil, ErrPoolClosed
	}

	r.mu.Lock()
	if r.closed.Load() {
		r.mu.Unlock()
		<-r.permits
		return nil, ErrPoolClosed
	}
	if err := ctx.Err(); err != nil {
		r.mu.Unlock()
		<-r.permits
		return nil, err
	}
	r.wg.Add(1)
	r.mu.Unlock()
	return &http3PhysicalConnection{owner: r}, nil
}

func (r *http3OriginResources) register(resource *http3PhysicalConnection) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.closed.Load() {
		return false
	}
	r.active[resource] = struct{}{}
	return true
}

func (r *http3OriginResources) finish(resource *http3PhysicalConnection, err error) {
	r.mu.Lock()
	delete(r.active, resource)
	if err != nil && !errors.Is(err, net.ErrClosed) && !errors.Is(err, context.Canceled) {
		r.closeErr = append(r.closeErr, err)
	}
	r.mu.Unlock()
	<-r.permits
	r.wg.Done()
}

func (r *http3OriginResources) recordError(err error) {
	if err == nil || errors.Is(err, net.ErrClosed) || errors.Is(err, context.Canceled) {
		return
	}
	r.mu.Lock()
	r.closeErr = append(r.closeErr, err)
	r.mu.Unlock()
}

func (r *http3OriginResources) Close() error {
	r.closeOnce.Do(func() {
		r.mu.Lock()
		r.closed.Store(true)
		r.cancel(ErrPoolClosed)
		active := make([]*http3PhysicalConnection, 0, len(r.active))
		for resource := range r.active {
			active = append(active, resource)
		}
		r.mu.Unlock()

		for _, resource := range active {
			resource.close()
		}
		r.wg.Wait()

		r.mu.Lock()
		r.resultErr = errors.Join(r.closeErr...)
		r.mu.Unlock()
	})
	return r.resultErr
}

type http3PhysicalConnection struct {
	owner       *http3OriginResources
	conn        *quic.Conn
	transport   *quic.Transport
	packetConn  net.PacketConn
	releaseOnce sync.Once
}

func (c *http3PhysicalConnection) close() {
	if c.conn != nil {
		c.owner.recordError(c.conn.CloseWithError(0, ""))
	}
	c.release()
}

func (c *http3PhysicalConnection) release() {
	c.releaseOnce.Do(func() {
		var errs []error
		if c.transport != nil {
			errs = append(errs, c.transport.Close())
		}
		if c.packetConn != nil {
			errs = append(errs, c.packetConn.Close())
		}
		c.owner.finish(c, errors.Join(errs...))
	})
}
