package transportpool

import (
	"fmt"
	"net"
	"net/url"
	"strconv"
	"strings"
)

type Origin struct {
	Scheme   string
	HostPort string
}

func ParseOrigin(rawURL string) (Origin, error) {
	u, err := url.Parse(rawURL)
	if err != nil {
		return Origin{}, fmt.Errorf("parse origin URL: %w", err)
	}
	return OriginFromURL(u)
}

func OriginFromURL(u *url.URL) (Origin, error) {
	if u == nil {
		return Origin{}, fmt.Errorf("origin URL is nil")
	}
	scheme := strings.ToLower(strings.TrimSpace(u.Scheme))
	var defaultPort string
	switch scheme {
	case "http":
		defaultPort = "80"
	case "https":
		defaultPort = "443"
	default:
		return Origin{}, fmt.Errorf("unsupported URL scheme %q", u.Scheme)
	}

	host := strings.ToLower(strings.TrimSpace(u.Hostname()))
	if host == "" {
		return Origin{}, fmt.Errorf("origin host is empty")
	}
	port := u.Port()
	if port == "" {
		port = defaultPort
	}
	n, err := strconv.Atoi(port)
	if err != nil || n < 1 || n > 65535 {
		return Origin{}, fmt.Errorf("invalid origin port %q", port)
	}
	return Origin{Scheme: scheme, HostPort: net.JoinHostPort(host, port)}, nil
}

func (o Origin) normalize() (Origin, error) {
	return ParseOrigin(o.String())
}

func (o Origin) String() string {
	return strings.ToLower(strings.TrimSpace(o.Scheme)) + "://" + strings.TrimSpace(o.HostPort)
}
