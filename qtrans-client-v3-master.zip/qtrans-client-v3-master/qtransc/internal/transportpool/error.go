package transportpool

import (
	"context"
	"errors"
	"fmt"
)

var (
	ErrPoolClosed     = errors.New("transport pool closed")
	ErrOriginLimit    = errors.New("origin pool limit reached")
	ErrOriginMismatch = errors.New("request origin does not match lease origin")
	ErrLeaseUsed      = errors.New("lease already used")
	ErrLeaseReleased  = errors.New("lease already released")
)

type ProtocolNegotiationError struct {
	Transport string
	Expected  string
	Actual    string
}

func (e *ProtocolNegotiationError) Error() string {
	return fmt.Sprintf("%s requires %s ALPN, got %q", e.Transport, e.Expected, e.Actual)
}

type RequestState uint8

const (
	RequestNotSent RequestState = iota
	RequestPossiblySent
	ResponseStarted
)

type ErrorKind uint8

const (
	ErrorPoolClosed ErrorKind = iota
	ErrorOriginLimit
	ErrorOriginMismatch
	ErrorLeaseUsed
	ErrorLeaseReleased
	ErrorOpenOrigin
	ErrorConnect
	ErrorHandshake
	ErrorRoundTrip
	ErrorResponseRead
	ErrorCanceled
	ErrorTimeout
)

type Error struct {
	Kind   ErrorKind
	Op     string
	Origin Origin
	Driver string
	State  RequestState
	Cause  error
}

func (e *Error) Error() string {
	if e == nil {
		return "<nil>"
	}
	if e.Cause == nil {
		return fmt.Sprintf("%s %s via %s", e.Op, e.Origin.String(), e.Driver)
	}
	return fmt.Sprintf("%s %s via %s: %v", e.Op, e.Origin.String(), e.Driver, e.Cause)
}

func (e *Error) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.Cause
}

func (e *Error) Is(target error) bool {
	if e == nil {
		return false
	}
	switch target {
	case ErrPoolClosed:
		return e.Kind == ErrorPoolClosed
	case ErrOriginLimit:
		return e.Kind == ErrorOriginLimit
	case ErrOriginMismatch:
		return e.Kind == ErrorOriginMismatch
	case ErrLeaseUsed:
		return e.Kind == ErrorLeaseUsed
	case ErrLeaseReleased:
		return e.Kind == ErrorLeaseReleased
	default:
		return false
	}
}

func errorKindForContext(err error) ErrorKind {
	if errors.Is(err, context.DeadlineExceeded) {
		return ErrorTimeout
	}
	if errors.Is(err, context.Canceled) {
		return ErrorCanceled
	}
	return ErrorRoundTrip
}
