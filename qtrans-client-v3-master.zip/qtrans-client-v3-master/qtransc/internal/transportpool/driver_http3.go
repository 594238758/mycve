package transportpool

import (
	"context"
	"crypto/tls"
	"errors"
	"net/http"
	"sync"
	"sync/atomic"
	"time"

	"github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3"
)

type HTTP3DriverConfig struct {
	TLSClientConfig *tls.Config
	QUICConfig      *quic.Config
	ConnectTimeout  time.Duration
}

type http3Driver struct {
	name       string
	tlsConfig  *tls.Config
	quicConfig *quic.Config
	timeout    time.Duration
}

func NewHTTP3Driver(config HTTP3DriverConfig) Driver {
	tlsConfig := cloneTLSConfig(config.TLSClientConfig)
	tlsConfig.NextProtos = []string{http3.NextProtoH3}
	quicConfig := config.QUICConfig
	if quicConfig == nil {
		quicConfig = &quic.Config{
			Allow0RTT:            true,
			KeepAlivePeriod:      10 * time.Second,
			MaxIdleTimeout:       300 * time.Second,
			HandshakeIdleTimeout: 30 * time.Second,
		}
	} else {
		quicConfig = quicConfig.Clone()
	}
	return &http3Driver{
		name:       "quic-go-http3-transport-v2",
		tlsConfig:  tlsConfig,
		quicConfig: quicConfig,
		timeout:    normalizedConnectTimeout(config.ConnectTimeout),
	}
}

func (d *http3Driver) Name() string {
	return d.name
}

func (d *http3Driver) Validate(Limits) error {
	return nil
}

func (d *http3Driver) Open(
	_ context.Context,
	origin Origin,
	limits Limits,
) (OriginPool, error) {
	if origin.Scheme != "https" {
		return nil, errors.New("HTTP/3 requires an https origin")
	}
	resources := newHTTP3OriginResources(limits.MaxConnections)
	inner := newManagedOriginPool(origin, d.name, limits, &http3ConnectionFactory{
		tlsConfig:  d.tlsConfig,
		quicConfig: d.quicConfig,
		timeout:    d.timeout,
		resources:  resources,
	})
	return &http3OriginPool{OriginPool: inner, resources: resources}, nil
}

type http3ConnectionFactory struct {
	tlsConfig  *tls.Config
	quicConfig *quic.Config
	timeout    time.Duration
	resources  *http3OriginResources
}

func (f *http3ConnectionFactory) Connect(ctx context.Context, origin Origin) (connection, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if f.resources.Closed() {
		return nil, ErrPoolClosed
	}
	h3Transport := &http3.Transport{
		TLSClientConfig:    f.tlsConfig.Clone(),
		QUICConfig:         f.quicConfig.Clone(),
		DisableCompression: true,
	}
	h3Transport.Dial = func(
		dialCtx context.Context,
		addr string,
		tlsConfig *tls.Config,
		quicConfig *quic.Config,
	) (*quic.Conn, error) {
		return f.resources.Dial(dialCtx, addr, tlsConfig, quicConfig, f.timeout)
	}
	return &managedHTTP3Connection{transport: h3Transport, resources: f.resources}, nil
}

type http3OriginPool struct {
	OriginPool
	resources *http3OriginResources
	closeOnce sync.Once
	closeErr  error
}

func (p *http3OriginPool) Close() error {
	p.closeOnce.Do(func() {
		p.closeErr = errors.Join(p.OriginPool.Close(), p.resources.Close())
	})
	return p.closeErr
}

type managedHTTP3Connection struct {
	transport *http3.Transport
	resources *http3OriginResources
	closed    atomic.Bool
	closeOnce sync.Once
	closeErr  error
}

func (c *managedHTTP3Connection) RoundTrip(req *http.Request) (*http.Response, error) {
	if c.closed.Load() || c.resources.Closed() {
		return nil, ErrPoolClosed
	}
	return c.transport.RoundTrip(req)
}

func (c *managedHTTP3Connection) Close() error {
	c.closeOnce.Do(func() {
		c.closed.Store(true)
		c.closeErr = c.transport.Close()
	})
	return c.closeErr
}

func (c *managedHTTP3Connection) Healthy() bool {
	return !c.closed.Load() && !c.resources.Closed()
}
