package transportpool

import (
	"context"
	"errors"
	"io"
	"net/http"
	"sort"
	"sync"
	"time"
)

type pool struct {
	driver Driver
	config Config

	ctx    context.Context
	cancel context.CancelCauseFunc

	mu      sync.Mutex
	closed  bool
	origins map[Origin]*originEntry
	open    chan struct{}
	openWG  sync.WaitGroup

	closeOnce sync.Once
	closeErr  error
}

type originEntry struct {
	pool     OriginPool
	active   int
	waiting  int
	lastUsed time.Time
}

type originPoolInspector interface {
	snapshot() OriginSnapshot
}

func New(driver Driver, config Config) (Pool, error) {
	if driver == nil {
		return nil, errors.New("transport pool driver is nil")
	}
	if config.MaxOrigins <= 0 {
		return nil, errors.New("MaxOrigins must be positive")
	}
	if config.PerOrigin.MaxConnections <= 0 {
		return nil, errors.New("MaxConnections must be positive")
	}
	if config.PerOrigin.MaxLeasesPerConnection <= 0 {
		return nil, errors.New("MaxLeasesPerConnection must be positive")
	}
	if config.PerOrigin.ConnectionIdleTimeout < 0 {
		return nil, errors.New("ConnectionIdleTimeout cannot be negative")
	}
	if err := driver.Validate(config.PerOrigin); err != nil {
		return nil, err
	}

	ctx, cancel := context.WithCancelCause(context.Background())
	return &pool{
		driver:  driver,
		config:  config,
		ctx:     ctx,
		cancel:  cancel,
		origins: make(map[Origin]*originEntry),
		open:    make(chan struct{}, 1),
	}, nil
}

func (p *pool) Acquire(ctx context.Context, origin Origin) (Lease, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	normalized, err := origin.normalize()
	if err != nil {
		return nil, err
	}

	for {
		p.mu.Lock()
		if p.closed {
			p.mu.Unlock()
			return nil, p.poolError("acquire", normalized, ErrorPoolClosed, ErrPoolClosed)
		}
		if entry := p.origins[normalized]; entry != nil {
			entry.waiting++
			p.mu.Unlock()
			return p.acquireFromEntry(ctx, normalized, entry)
		}
		p.mu.Unlock()

		select {
		case p.open <- struct{}{}:
		case <-ctx.Done():
			return nil, p.poolError("acquire", normalized, errorKindForContext(ctx.Err()), ctx.Err())
		case <-p.ctx.Done():
			return nil, p.poolError("acquire", normalized, ErrorPoolClosed, ErrPoolClosed)
		}

		opened, openErr := p.openOrigin(ctx, normalized)
		<-p.open
		if openErr != nil {
			return nil, openErr
		}
		if !opened {
			continue
		}
	}
}

func (p *pool) openOrigin(ctx context.Context, origin Origin) (bool, error) {
	var evicted OriginPool

	p.mu.Lock()
	if p.closed {
		p.mu.Unlock()
		return false, p.poolError("open-origin", origin, ErrorPoolClosed, ErrPoolClosed)
	}
	if p.origins[origin] != nil {
		p.mu.Unlock()
		return false, nil
	}
	if len(p.origins) >= p.config.MaxOrigins {
		var victim Origin
		var victimEntry *originEntry
		for candidate, entry := range p.origins {
			if entry.active != 0 || entry.waiting != 0 {
				continue
			}
			if victimEntry == nil || entry.lastUsed.Before(victimEntry.lastUsed) {
				victim, victimEntry = candidate, entry
			}
		}
		if victimEntry == nil {
			p.mu.Unlock()
			return false, p.poolError("open-origin", origin, ErrorOriginLimit, ErrOriginLimit)
		}
		delete(p.origins, victim)
		evicted = victimEntry.pool
	}
	p.openWG.Add(1)
	p.mu.Unlock()

	if evicted != nil {
		_ = evicted.Close()
	}

	openCtx, cancel := context.WithCancelCause(ctx)
	stop := context.AfterFunc(p.ctx, func() {
		cancel(ErrPoolClosed)
	})
	originPool, err := p.driver.Open(openCtx, origin, p.config.PerOrigin)
	stop()
	cancel(nil)
	p.openWG.Done()
	if err != nil {
		kind := ErrorOpenOrigin
		if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
			kind = errorKindForContext(err)
		}
		return false, p.poolError("open-origin", origin, kind, err)
	}

	p.mu.Lock()
	if p.closed {
		p.mu.Unlock()
		_ = originPool.Close()
		return false, p.poolError("open-origin", origin, ErrorPoolClosed, ErrPoolClosed)
	}
	if existing := p.origins[origin]; existing != nil {
		p.mu.Unlock()
		_ = originPool.Close()
		return false, nil
	}
	p.origins[origin] = &originEntry{pool: originPool, lastUsed: time.Now()}
	p.mu.Unlock()
	return false, nil
}

func (p *pool) acquireFromEntry(ctx context.Context, origin Origin, entry *originEntry) (Lease, error) {
	lease, err := entry.pool.Acquire(ctx)
	p.mu.Lock()
	entry.waiting--
	if err == nil {
		entry.active++
	}
	p.mu.Unlock()
	if err != nil {
		if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
			return nil, p.poolError("acquire", origin, errorKindForContext(err), err)
		}
		return nil, err
	}
	return &trackedLease{
		Lease:  lease,
		origin: origin,
		done: func() {
			p.mu.Lock()
			entry.active--
			entry.lastUsed = time.Now()
			p.mu.Unlock()
		},
	}, nil
}

func (p *pool) Close() error {
	p.closeOnce.Do(func() {
		p.mu.Lock()
		p.closed = true
		p.cancel(ErrPoolClosed)
		originPools := make([]OriginPool, 0, len(p.origins))
		for _, entry := range p.origins {
			originPools = append(originPools, entry.pool)
		}
		p.origins = make(map[Origin]*originEntry)
		p.mu.Unlock()

		var errs []error
		for _, originPool := range originPools {
			if err := originPool.Close(); err != nil {
				errs = append(errs, err)
			}
		}
		p.openWG.Wait()
		p.closeErr = errors.Join(errs...)
	})
	return p.closeErr
}

func (p *pool) Snapshot() Snapshot {
	p.mu.Lock()
	result := Snapshot{Driver: p.driver.Name(), Closed: p.closed}
	for origin, entry := range p.origins {
		item := OriginSnapshot{Origin: origin}
		if inspector, ok := entry.pool.(originPoolInspector); ok {
			item = inspector.snapshot()
		}
		item.Origin = origin
		item.ActiveLeases = entry.active
		item.WaitingAcquires = entry.waiting
		result.Origins = append(result.Origins, item)
	}
	p.mu.Unlock()
	sort.Slice(result.Origins, func(i, j int) bool {
		return result.Origins[i].Origin.String() < result.Origins[j].Origin.String()
	})
	return result
}

func (p *pool) poolError(op string, origin Origin, kind ErrorKind, cause error) error {
	return &Error{
		Kind: kind, Op: op, Origin: origin, Driver: p.driver.Name(),
		State: RequestNotSent, Cause: cause,
	}
}

type trackedLease struct {
	Lease
	origin Origin
	done   func()
	once   sync.Once
}

func (l *trackedLease) RoundTrip(req *http.Request) (*http.Response, error) {
	resp, err := l.Lease.RoundTrip(req)
	if err != nil {
		l.finish()
		return nil, err
	}
	if resp == nil || resp.Body == nil {
		l.finish()
		return resp, nil
	}
	resp.Body = &trackedBody{ReadCloser: resp.Body, done: l.finish}
	return resp, nil
}

func (l *trackedLease) Release() {
	l.Lease.Release()
	l.finish()
}

func (l *trackedLease) finish() {
	l.once.Do(l.done)
}

type trackedBody struct {
	io.ReadCloser
	done func()
	once sync.Once
}

func (b *trackedBody) Read(p []byte) (int, error) {
	n, err := b.ReadCloser.Read(p)
	if err != nil {
		b.once.Do(b.done)
	}
	return n, err
}

func (b *trackedBody) Close() error {
	err := b.ReadCloser.Close()
	b.once.Do(b.done)
	return err
}

var _ Pool = (*pool)(nil)
var _ Inspector = (*pool)(nil)
