package sslkeylog

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sync"
)

const FileName = "sslkeys.log"

var (
	mu       sync.RWMutex
	file     *os.File
	writer   io.Writer
	filePath string
)

// Enable opens sslkeys.log in the current working directory and exposes it as
// the TLS key log writer used by HTTP/3 and HTTPS clients.
func Enable() error {
	mu.Lock()
	defer mu.Unlock()

	if writer != nil {
		return nil
	}

	wd, err := os.Getwd()
	if err != nil {
		return fmt.Errorf("get working directory: %w", err)
	}

	path := filepath.Join(wd, FileName)
	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
	if err != nil {
		return fmt.Errorf("open TLS key log file %q: %w", path, err)
	}

	file = f
	writer = f
	filePath = path
	return nil
}

// Writer returns the shared TLS key log writer, or nil when export is disabled.
func Writer() io.Writer {
	mu.RLock()
	defer mu.RUnlock()
	return writer
}

// Path returns the absolute path to sslkeys.log after Enable succeeds.
func Path() string {
	mu.RLock()
	defer mu.RUnlock()
	return filePath
}

// Enabled reports whether TLS key export is active.
func Enabled() bool {
	return Writer() != nil
}

// Close releases the underlying log file. It is primarily used by tests.
func Close() error {
	mu.Lock()
	defer mu.Unlock()

	var err error
	if file != nil {
		err = file.Close()
	}
	file = nil
	writer = nil
	filePath = ""
	return err
}
