package h3client

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"log"
	"net"
	"net/http"
	"qtransc/internal/sslkeylog"
	"sync"
	"sync/atomic"
	"time"

	"github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3"
)

/*
http3client结构中,有Transport字段, 可以让用同一个Transport来复用底层的QUIC连接.
但是http3.Transport没有连接池的概念, 也没有控制并发流数量的功能.
所以需要自己实现一个连接池, 来维护多个http3.Transport实例, 每个实例对应一个QUIC连接.
然后通过一个阻塞队列来控制并发流的数量, 这样就可以实现连接池的功能.
*/

var (
	// clientPool 保存全局唯一的连接池实例, 便于各调用方共享。
	clientPool *ConnectionPool
	// listenUDPConn 允许测试替换底层 UDP socket 创建逻辑。
	listenUDPConn = func() (udpPacketConn, error) {
		return net.ListenUDP("udp", nil)
	}
	defaultMaxConnectionReceiveWindow int64 = 256 << 20
)

func SetMaxConnectionReceiveWindow(bytes int64) {
	if bytes > 0 {
		atomic.StoreInt64(&defaultMaxConnectionReceiveWindow, bytes)
	}
}

func MaxConnectionReceiveWindow() int64 {
	return atomic.LoadInt64(&defaultMaxConnectionReceiveWindow)
}

type udpPacketConn interface {
	net.PacketConn
}

// ConnectionPool 维护 HTTP/3 client 槽位, 每个槽位对应一个 QUIC 流。
type ConnectionPool struct {
	// clients 存放空闲的 http.Client，调用方直接从此 channel 接收客户端
	clients chan *http.Client
	// lookup 记录 client 到槽位的映射, 使得调用方可以在必要时主动归还。
	lookup map[*http.Client]*clientSlot
	// transports 存放底层 QUIC 连接的 http3.Transport, 一个连接对应一份 Transport。
	transports []*http3.Transport
	// quicTransports 保存每个 http3.Transport 绑定的 quic.Transport, 便于关闭时释放自建 UDP socket。
	quicTransports []*quic.Transport
	// packetConns 保存每个 quic.Transport 绑定的 UDPConn, 关闭时与 quic.Transport 一并释放。
	packetConns []udpPacketConn
	// closeOnce 确保 Close 逻辑只执行一次, 避免并发情况下重复关闭。
	closeOnce sync.Once
	// closed 表示连接池是否已经关闭。
	closed int32
	// closedCh 在关闭时关闭 channel, Get 的调用方收到信号后立即返回。
	closedCh chan struct{}
}

// NewConnectionPool 创建连接池。
func NewConnectionPool(connCount, streamsPerConn int) (*ConnectionPool, error) {
	if connCount <= 0 {
		return nil, errors.New("connCount must be positive")
	}
	if streamsPerConn <= 0 {
		return nil, errors.New("streamsPerConn must be positive")
	}

	totalSlots := connCount * streamsPerConn
	// totalSlots 控制池内总的并发流数量, 队列容量与之保持一致确保公平排队。
	pool := &ConnectionPool{
		clients:        make(chan *http.Client, totalSlots),
		lookup:         make(map[*http.Client]*clientSlot, totalSlots),
		transports:     make([]*http3.Transport, connCount),
		quicTransports: make([]*quic.Transport, connCount),
		packetConns:    make([]udpPacketConn, connCount),
		closedCh:       make(chan struct{}),
	}

	// 先按连接数量创建底层 http3.Transport, 确保每个连接独立复用。
	for i := range connCount {
		transport, quicTransport, packetConn, err := newHTTP3Transport()
		if err != nil {
			pool.Close()
			return nil, err
		}
		pool.transports[i] = transport
		pool.quicTransports[i] = quicTransport
		pool.packetConns[i] = packetConn
	}

	// 以流索引为外层, 连接索引为内层的顺序填充槽位, 保证队列轮询时流量平均分配到每条连接。
	for range streamsPerConn {
		for connIdx := range connCount {
			slot := &clientSlot{pool: pool, connIndex: connIdx}
			client := &http.Client{Transport: pool.transports[connIdx]}
			slot.client = client
			pool.lookup[client] = slot
			pool.clients <- client
		}
	}

	return pool, nil
}

// Get 从连接池获取一个可用客户端, 若无可用槽位则阻塞等待。
// 调用方应在请求完成后调用 Release 归还客户端, 常见用法: client := pool.Get(); defer ReleaseClient(client)。
func (p *ConnectionPool) Get() *http.Client {
	if p == nil {
		return nil
	}
	select {
	case client := <-p.clients:
		return client
	case <-p.closedCh:
		return nil
	}
}

// GetChan 返回客户端 channel，调用方直接从中接收客户端。
// 这允许调用方使用 select 同时等待客户端和其他信号（如超时、取消等）。
// 调用方应在请求完成后调用 Release 归还客户端。
//
// 示例用法:
//
//	select {
//	case client := <-pool.GetChan():
//	    if client != nil {
//	        defer ReleaseClient(client)
//	        // 使用 client...
//	    }
//	case <-ctx.Done():
//	    // 处理取消...
//	case <-time.After(10 * time.Second):
//	    // 处理超时...
//	}
func (p *ConnectionPool) GetChan() <-chan *http.Client {
	if p == nil {
		ch := make(chan *http.Client)
		close(ch)
		return ch
	}
	return p.clients
}

// Release 主动归还客户端, 适用于请求尚未发出的情况。
func (p *ConnectionPool) Release(client *http.Client) {
	if p == nil || client == nil {
		return
	}
	slot, ok := p.lookup[client]
	if !ok {
		return
	}
	slot.release()
}

// Close 关闭连接池并释放底层 QUIC 连接。
func (p *ConnectionPool) Close() {
	if p == nil {
		return
	}
	p.closeOnce.Do(func() {
		atomic.StoreInt32(&p.closed, 1)
		close(p.closedCh)
		for _, transport := range p.transports {
			if transport != nil {
				_ = transport.Close()
			}
		}
		for _, quicTransport := range p.quicTransports {
			if quicTransport != nil {
				_ = quicTransport.Close()
			}
		}
		for _, packetConn := range p.packetConns {
			if packetConn != nil {
				_ = packetConn.Close()
			}
		}
	})
}

func (p *ConnectionPool) isClosed() bool {
	return atomic.LoadInt32(&p.closed) == 1
}

type clientSlot struct {
	client    *http.Client    // 当前槽位对应的客户端/QUIC连接
	pool      *ConnectionPool // 所属连接池
	connIndex int             // 连接索引
	released  bool            // 是否已归还
	mu        sync.Mutex      // 保护 released 字段的互斥锁
}

func (s *clientSlot) release() {
	s.mu.Lock()
	if s.released {
		s.mu.Unlock()
		return
	}
	s.released = true
	s.mu.Unlock()

	if s.pool == nil || s.pool.isClosed() {
		return
	}
	select {
	case s.pool.clients <- s.client:
		// 成功放回池后，重置 released 标志，允许下次使用后再次归还
		s.mu.Lock()
		s.released = false
		s.mu.Unlock()
	default:
		log.Printf("连接池槽位已满，丢弃客户端: %p", s.client)
		// 注意：如果池已满，保持 released=true，防止后续重复尝试放回
	}
}

func newHTTP3Transport() (*http3.Transport, *quic.Transport, udpPacketConn, error) {
	udpConn, err := listenUDPConn()
	if err != nil {
		return nil, nil, nil, fmt.Errorf("listen udp for http3 transport: %w", err)
	}

	quicTransport := &quic.Transport{Conn: udpConn}
	maxConnectionReceiveWindow := MaxConnectionReceiveWindow()
	initialConnectionReceiveWindow := int64(64 << 20)
	if maxConnectionReceiveWindow > 0 && maxConnectionReceiveWindow < initialConnectionReceiveWindow {
		initialConnectionReceiveWindow = maxConnectionReceiveWindow
	}

	// 每条连接复用同一份 quic.Config, 并绑定独立的 UDP socket 与缓冲区。
	transport := &http3.Transport{
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,                              // 测试用，生产环境应使用有效证书
			ClientSessionCache: tls.NewLRUClientSessionCache(100), // 启用会话缓存以支持 0-RTT
			KeyLogWriter:       sslkeylog.Writer(),
		},
		QUICConfig: &quic.Config{
			Allow0RTT:                      true, // 启用 0-RTT
			MaxIncomingStreams:             2048,
			KeepAlivePeriod:                10 * time.Second, // 心跳间隔
			MaxIdleTimeout:                 300 * time.Second,
			HandshakeIdleTimeout:           30 * time.Second,
			InitialStreamReceiveWindow:     16 << 20,  // 16MB
			MaxStreamReceiveWindow:         64 << 20,  // 64MB
			InitialConnectionReceiveWindow: uint64(initialConnectionReceiveWindow),
			MaxConnectionReceiveWindow:     uint64(maxConnectionReceiveWindow),
			TokenStore:                     quic.NewLRUTokenStore(100, 5),
			DisablePathMTUDiscovery:        false,
		},
		Dial: func(ctx context.Context, addr string, tlsCfg *tls.Config, cfg *quic.Config) (*quic.Conn, error) {
			udpAddr, err := net.ResolveUDPAddr("udp", addr)
			if err != nil {
				return nil, fmt.Errorf("resolve udp addr %q: %w", addr, err)
			}
			return quicTransport.DialEarly(ctx, udpAddr, tlsCfg, cfg)
		},
		DisableCompression: true,
	}
	return transport, quicTransport, udpConn, nil
}

// InitClientPool 初始化全局连接池。
func InitClientPool(Transports, streamsPerConn int) error {
	if clientPool != nil {
		return errors.New("connection pool already initialized")
	}
	pool, err := NewConnectionPool(Transports, streamsPerConn)
	if err != nil {
		return err
	}
	clientPool = pool
	return nil
}

// CloseClientPool 关闭全局连接池。
func CloseClientPool() {
	if clientPool == nil {
		return
	}
	clientPool.Close()
	clientPool = nil
}

// GetClient 返回一个 channel，调用方可以从中接收客户端。
// 这是主要的外部接口，支持异步获取客户端，允许调用方使用 select 同时等待客户端和其他信号。
// 调用方应在请求完成后调用 ReleaseClient 归还客户端。
//
// 示例用法:
//
//	clientCh := h3client.GetClient()
//	select {
//	case client := <-clientCh:
//	    if client != nil {
//	        defer h3client.ReleaseClient(client)
//	        // 使用 client 发送请求...
//	    }
//	case <-ctx.Done():
//	    return ctx.Err()
//	case <-time.After(10 * time.Second):
//	    return errors.New("获取客户端超时")
//	}
func GetClient() <-chan *http.Client {
	if clientPool == nil {
		ch := make(chan *http.Client)
		close(ch)
		return ch
	}
	return clientPool.GetChan()
}

// GetClientSync 同步获取客户端，会阻塞直到获取到客户端或超时。
// 这是为了向后兼容保留的接口，新代码建议使用 GetClient() 配合 select。
func GetClientSync() *http.Client {
	if clientPool == nil {
		return nil
	}
	return clientPool.Get()
}

// ReleaseClient 手动归还客户端。
func ReleaseClient(client *http.Client) {
	if clientPool == nil {
		return
	}
	clientPool.Release(client)
}
