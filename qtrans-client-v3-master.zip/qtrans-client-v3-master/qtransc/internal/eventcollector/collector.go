package eventcollector

import (
	"sync"
	"sync/atomic"
	"time"

	"qtransc/internal/eventlog"
	"qtransc/internal/types"
)

const (
	DefaultSubscriberBuffer  int           = 2048
	DefaultHeartbeatInterval time.Duration = 5 * time.Second
	DefaultProgressInterval  time.Duration = 1 * time.Second
)

type Publisher interface {
	Publish(event types.TaskEvent) bool
}

type RuntimeConfig struct {
	Publisher          Publisher
	ProgressInterval   time.Duration
	CompletionNotifier func()
}

type RuntimeOption func(*RuntimeConfig)

type Bus struct {
	mu            sync.RWMutex
	subscribers   map[chan types.TaskEvent]struct{}
	defaultBuffer int
	closed        bool
}

type noopPublisher struct{}

func NewBus(buffer int) *Bus {
	if buffer <= 0 {
		buffer = DefaultSubscriberBuffer
	}
	return &Bus{
		subscribers:   make(map[chan types.TaskEvent]struct{}),
		defaultBuffer: buffer,
	}
}

func NewNoopPublisher() Publisher {
	return noopPublisher{}
}

func DefaultRuntimeConfig() RuntimeConfig {
	return RuntimeConfig{
		Publisher:        NewNoopPublisher(),
		ProgressInterval: DefaultProgressInterval,
	}
}

func ApplyRuntimeOptions(opts ...RuntimeOption) RuntimeConfig {
	config := DefaultRuntimeConfig()
	for _, opt := range opts {
		if opt == nil {
			continue
		}
		opt(&config)
	}
	if config.Publisher == nil {
		config.Publisher = NewNoopPublisher()
	}
	if config.ProgressInterval <= 0 {
		config.ProgressInterval = DefaultProgressInterval
	}
	return config
}

func WithPublisher(publisher Publisher) RuntimeOption {
	return func(config *RuntimeConfig) {
		if config == nil || publisher == nil {
			return
		}
		config.Publisher = publisher
	}
}

func WithProgressInterval(interval time.Duration) RuntimeOption {
	return func(config *RuntimeConfig) {
		if config == nil || interval <= 0 {
			return
		}
		config.ProgressInterval = interval
	}
}

// WithCompletionNotifier installs the internal execution-exit notification used
// by the manager to release an execution slot. It is deliberately separate from
// the lossy SSE event bus.
func WithCompletionNotifier(notifier func()) RuntimeOption {
	return func(config *RuntimeConfig) {
		if config == nil || notifier == nil {
			return
		}
		config.CompletionNotifier = notifier
	}
}

func (noopPublisher) Publish(types.TaskEvent) bool {
	return false
}

func (b *Bus) Subscribe(buffer int) (<-chan types.TaskEvent, func()) {
	if b == nil {
		ch := make(chan types.TaskEvent)
		close(ch)
		return ch, func() {}
	}
	if buffer <= 0 {
		buffer = b.defaultBuffer
	}
	ch := make(chan types.TaskEvent, buffer)

	b.mu.Lock()
	if b.closed {
		b.mu.Unlock()
		close(ch)
		return ch, func() {}
	}
	b.subscribers[ch] = struct{}{}
	b.mu.Unlock()

	var once sync.Once
	unsubscribe := func() {
		once.Do(func() {
			b.mu.Lock()
			defer b.mu.Unlock()
			if _, ok := b.subscribers[ch]; !ok {
				return
			}
			delete(b.subscribers, ch)
			close(ch)
		})
	}

	return ch, unsubscribe
}

func (b *Bus) Publish(event types.TaskEvent) bool {
	if b == nil {
		logDroppedEvent(event, "nil_bus", 0, 0, 0)
		return false
	}

	b.mu.RLock()
	defer b.mu.RUnlock()

	if b.closed {
		logDroppedEvent(event, "bus_closed", 0, 0, 0)
		return false
	}

	subscriberCount := len(b.subscribers)
	if subscriberCount == 0 {
		logDroppedEvent(event, "no_subscribers", 0, 0, 0)
		return false
	}

	delivered := 0
	dropped := 0
	for subscriber := range b.subscribers {
		select {
		case subscriber <- event:
			delivered++
		default:
			dropped++
		}
	}

	if dropped > 0 {
		logDroppedEvent(event, "subscriber_buffer_full", subscriberCount, delivered, dropped)
	}

	return delivered > 0
}

func logDroppedEvent(event types.TaskEvent, reason string, subscriberCount, delivered, dropped int) {
	if !eventlog.Enabled() {
		return
	}
	eventlog.Warn("SSE event dropped",
		"reason", reason,
		"event_lost", true,
		"event_type", event.EventType,
		"subscriber_count", subscriberCount,
		"delivered_subscribers", delivered,
		"dropped_subscribers", dropped,
		"payload", string(event.Bytes()))
}

func (b *Bus) Close() {
	if b == nil {
		return
	}

	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed {
		return
	}
	b.closed = true
	for subscriber := range b.subscribers {
		close(subscriber)
		delete(b.subscribers, subscriber)
	}
}

func ShouldPublishProgress(lastPublishedAt *atomic.Int64, interval time.Duration, force bool) bool {
	if force || lastPublishedAt == nil {
		if lastPublishedAt != nil {
			lastPublishedAt.Store(time.Now().UnixNano())
		}
		return true
	}
	if interval <= 0 {
		return true
	}

	nowUnixNano := time.Now().UnixNano()
	minInterval := interval.Nanoseconds()
	for {
		previous := lastPublishedAt.Load()
		if previous != 0 && nowUnixNano-previous < minInterval {
			return false
		}
		if lastPublishedAt.CompareAndSwap(previous, nowUnixNano) {
			return true
		}
	}
}
