package downloadtask

import (
	"errors"
	"fmt"

	"qtransc/internal/types"
)

var (
	ErrPlanning          = errors.New("download planning failed")
	ErrRemoteNotFound    = errors.New("未找到该文件")
	ErrRemoteFileChanged = errors.New("远端文件在下载期间已变化")
)

type TaskError struct {
	Code    int
	Message string
	Data    interface{}
}

// Error implements the error interface
func (e *TaskError) Error() string {
	if e.Data != nil {
		return fmt.Sprintf("%s: %v", e.Message, e.Data)
	}
	return e.Message
}

func (e *TaskError) WithData(d interface{}) *TaskError {
	// 返回接收者的拷贝并在拷贝上设置 Data，避免修改原始的 TaskError 对象
	ne := *e
	ne.Data = d
	return &ne
}

func (e *TaskError) Is(target error) bool {
	t, ok := target.(*TaskError)
	if !ok {
		return false
	}
	return e.Code == t.Code
}

func (e *TaskError) Unwrap() error {
	if err, ok := e.Data.(error); ok {
		return err
	}
	return nil
}

// ToResponse converts TaskError to types.GeneralResponse
func (e *TaskError) ToGeneralResponse() types.GeneralResponse {
	return types.GeneralResponse{
		Code:    e.Code,
		Message: e.Message,
		Data:    nil,
	}
}

type permanentDownloadError struct {
	err error
}

type downloadGrantExpiredError struct {
	err error
}

func (e *permanentDownloadError) Error() string {
	return e.err.Error()
}

func (e *permanentDownloadError) Unwrap() error {
	return e.err
}

func (e *downloadGrantExpiredError) Error() string {
	return e.err.Error()
}

func (e *downloadGrantExpiredError) Unwrap() error {
	return e.err
}

func markPermanentDownloadError(err error) error {
	if err == nil {
		return nil
	}
	var permanentErr *permanentDownloadError
	if errors.As(err, &permanentErr) {
		return err
	}
	return &permanentDownloadError{err: err}
}

func markDownloadGrantExpiredError(err error) error {
	if err == nil {
		return nil
	}
	var expiredErr *downloadGrantExpiredError
	if errors.As(err, &expiredErr) {
		return err
	}
	return &downloadGrantExpiredError{err: err}
}

func isPermanentDownloadError(err error) bool {
	var permanentErr *permanentDownloadError
	return errors.As(err, &permanentErr)
}

func isDownloadGrantExpiredError(err error) bool {
	var expiredErr *downloadGrantExpiredError
	return errors.As(err, &expiredErr)
}

var (
	// 通用错误
	ErrInvalidJSON = &TaskError{Code: 10001, Message: "invalid JSON format"}
	// taskadd
	ErrTaskAlreadyExists = &TaskError{Code: 20101, Message: "task already exists"}
	ErrTaskCreateFailed  = &TaskError{Code: 20102, Message: "failed to create task"}
	// taskget
	ErrTaskNotFound = &TaskError{Code: 20201, Message: "task not found"}
	// taskstatus
	ErrTaskStatusTransitionFailed = &TaskError{Code: 20301, Message: "task status transition failed"}

	// runtime errors
	ErrAlreadyRunning        = &TaskError{Code: 30001, Message: "task is already running"}
	ErrAuthFailed            = &TaskError{Code: 30002, Message: "task authorization failed"}
	ErrTargetDirNotAvailable = &TaskError{Code: 30003, Message: "target directory not available"}
	ErrTargetDirNoSpace      = &TaskError{Code: 30004, Message: "target directory does not have enough space"}
	ErrServerError           = &TaskError{Code: 30005, Message: "server request failed"}
	ErrInternalError         = &TaskError{Code: 30006, Message: "internal error"}
)
