package downloadtask

import (
	"encoding/hex"
	"errors"
	"os"

	"qtransc/internal/transferretry"

	"github.com/zeebo/xxh3"
)

var HasherError = errors.New("hasher error")

const discardDownloadWriteEnv = "QTRANSC_DOWNLOAD_DISCARD_WRITE"

// offsetWriter 包装文件，支持并发安全地写入指定偏移量
// 使用 WriteAt 避免 Seek + Write 的竞态条件
type offsetWriter struct {
	file         *os.File
	offset       int64
	buf          []byte // 写缓冲区
	n            int    // 缓冲区中的数据量
	hash         *string
	hasher       *xxh3.Hasher
	discardWrite bool
}

// NewOffsetWriter 创建带缓冲的 offsetWriter (缓冲区 1MB, 使用 xxh3-128 哈希)
func NewOffsetWriter(file *os.File,
	offset int64,
	bufferSize int,
	checksum *string,
	hasher *xxh3.Hasher) *offsetWriter {

	if hasher == nil {
		panic("cannot create xxh3-128 hasher")
	}
	return &offsetWriter{
		file:         file,
		offset:       offset,
		buf:          make([]byte, bufferSize),
		n:            0,
		hash:         checksum,
		hasher:       hasher,
		discardWrite: os.Getenv(discardDownloadWriteEnv) == "1",
	}
}

func (ow *offsetWriter) Write(p []byte) (written int, err error) {
	written = 0
	for len(p) > 0 {
		// 如果缓冲区已满，先刷新
		if ow.n >= len(ow.buf) {
			if err := ow.Flush(); err != nil {
				return written, err
			}
		}

		// 拷贝数据到缓冲区
		n := copy(ow.buf[ow.n:], p)
		ow.n += n
		p = p[n:]
		written += n
	}

	return written, nil
}

// Flush 将缓冲区数据写入文件
func (ow *offsetWriter) Flush() error {
	if ow.n == 0 {
		return nil
	}

	n := ow.n
	if !ow.discardWrite {
		written, err := ow.file.WriteAt(ow.buf[:ow.n], ow.offset)
		if err != nil {
			return transferretry.WrapLocalIO("write download target", err)
		}
		n = written
	}

	// 计算已写入部分的哈希值
	if ow.hasher != nil {
		ow.hasher.Write(ow.buf[:n])
	} else {
		return HasherError
	}

	ow.offset += int64(n)
	ow.n = 0
	return nil
}

func (ow *offsetWriter) Close() error {
	// 确保缓冲区中的所有数据都已写入并计入hash
	if err := ow.Flush(); err != nil {
		return err
	}

	if ow.hasher != nil {
		if ow.hash != nil {
			bytes := ow.hasher.Sum128().Bytes()
			*ow.hash = hex.EncodeToString(bytes[:])
		}
	} else {
		return HasherError
	}
	return nil
}
