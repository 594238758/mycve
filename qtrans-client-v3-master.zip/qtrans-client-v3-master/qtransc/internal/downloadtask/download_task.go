package downloadtask

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"qtransc/internal/authmanager"
	"qtransc/internal/average"
	"qtransc/internal/clienterror"
	"qtransc/internal/domain"
	"qtransc/internal/eventcollector"
	"qtransc/internal/localfs"
	"qtransc/internal/netclient"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/ratelimit"
	"qtransc/internal/transferlimits"
	"qtransc/internal/types"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/sync/errgroup"
)

type DownloadTask struct {
	pathMappings         []types.PathMapping
	pathMappingsExpanded bool // FileList and DirPaths contain the committed expansion.

	networkConfig      netclient.Config
	client             *netclient.Client
	chunkSlots         netclient.ChunkSlots
	stopRequested      bool
	finalErr           error
	mu                 sync.Mutex
	roundDone          chan struct{}
	logger             *slog.Logger
	publisher          eventcollector.Publisher `json:"-"`
	completionNotifier func()                   `json:"-"`
	Status             types.TaskStatus         `json:"status,omitempty"`
	Err                error                    `json:"error,omitempty"`
	Started            bool                     `json:"started,omitempty"`

	// pctx    context.Context // parent context
	ctx    context.Context // task context
	cancel context.CancelFunc
	// control chan controlMessage
	//egctx   context.Context // errgroup context
	//eg      *errgroup.Group

	TaskID            string              `json:"task_id,omitempty"`
	TaskPID           string              `json:"-"`
	EnterpriseID      string              `json:"-"`
	CallerVersion     string              `json:"-"`
	ServerTaskID      string              `json:"server_task_id,omitempty"`
	TaskName          string              `json:"task_name,omitempty"`
	Mode              string              `json:"mode,omitempty"`
	Transport         types.TransportMode `json:"transport,omitempty"`
	downloadUserMode  types.DownloadUser  `json:"-"`
	bearerToken       string              `json:"-"`
	useAuthManager    bool                `json:"-"`
	ServerAddr        string              `json:"server_addr,omitempty"`
	TargetDir         string              `json:"target_dir,omitempty"` // download specific
	DirPaths          []string            `json:"dir_paths,omitempty"`  // v1: 相对 TargetDir；pathMappings: 完整目标目录路径
	TransferingFiles  sync.Map            `json:"transferring_files"`   // 正在传输的文件列表
	smallTempFiles    sync.Map            `json:"-"`
	FileList          []*FileInfo         `json:"file_list,omitempty"`          // 任务下发时的所有文件
	AuthorizedFiles   []*FileInfo         `json:"authorized_files,omitempty"`   // 授权成功的文件
	SmallFiles        []*FileInfo         `json:"small_files,omitempty"`        // 小于 SmallFileMaxBytes 的文件
	LargeFiles        []*FileInfo         `json:"large_files,omitempty"`        // 大于等于 SmallFileMaxBytes 的文件
	UnAuthorizedFiles []*FileInfo         `json:"unauthorized_files,omitempty"` // 未授权的文件

	VerifiedFileNum             atomic.Int64 `json:"verified_file_num,omitempty"`      // 已验证完成的文件数
	Transferred                 atomic.Int64 `json:"transferred_bytes,omitempty"`      // 已经完成传输的字节数(恢复,重试)
	NetworkReceived             atomic.Int64 `json:"network_received_bytes,omitempty"` // 本次会话通过网络实际接收的字节数
	TotalSize                   atomic.Int64 `json:"total_size,omitempty"`             // 需要下载的文件总大小
	Rate                        atomic.Int64 `json:"transfer_rate,omitempty"`          // 当前传输速率（字节/秒）
	LimitRate                   int64        `json:"limit_rate_bytes_per_sec,omitempty"`
	rateLimiter                 *ratelimit.Limiter
	lastTaskProgressPublishedAt atomic.Int64 `json:"-"`

	CreatedAt  time.Time `json:"created_at"`            // 任务创建时间
	UpdatedAt  time.Time `json:"updated_at"`            // 任务更新时间
	StartedAt  time.Time `json:"started_at,omitempty"`  // 任务开始时间
	FinishedAt time.Time `json:"finished_at,omitempty"` // 任务结束时间

	FileConcurrency       int           `json:"file_concurrency,omitempty"` // 文件并发下载数
	progressEventInterval time.Duration `json:"-"`
	requestedFiles        []requestedDownloadFile
	requestedDirPaths     []string
	preflightOnExecute    bool
	maxFileBytes          int64
	smallDownloadV2       bool
	smallBatchFiles       int
	smallFileBytes        int64
	smallBatchBytes       int64
	stateDBPath           string
}

type requestedDownloadFile struct {
	localPath string
	objectKey string
}

var errDownloadGrantSelectionTooLarge = errors.New("download grant selection too large")

var (
	downloadAuthRetryMaxRefreshes = 1
)

func resolveDownloadUserMode(raw string, authenticated bool) (types.DownloadUser, error) {
	switch strings.TrimSpace(raw) {
	case string(types.DownloadUserSelf):
		return types.DownloadUserSelf, nil
	case string(types.DownloadUserAnonymous), "":
		if authenticated {
			return types.DownloadUserSelf, nil
		}
		return types.DownloadUserAnonymous, nil
	default:
		return "", fmt.Errorf("unsupported download user %q", raw)
	}
}

// NewDownloadTask preserves synchronous preflight for direct CLI callers.
func NewDownloadTask(req *types.TaskCreateRequest, network netclient.Config, firstClient *netclient.Client, opts ...eventcollector.RuntimeOption) (*DownloadTask, error) {
	return newDownloadTask(req, false, network, firstClient, opts...)
}

// NewPendingDownloadTask defers filesystem and network preflight until the
// accepted task starts its execution round.
func NewPendingDownloadTask(req *types.TaskCreateRequest, network netclient.Config, firstClient *netclient.Client, opts ...eventcollector.RuntimeOption) (*DownloadTask, error) {
	return newDownloadTask(req, true, network, firstClient, opts...)
}

func newDownloadTask(req *types.TaskCreateRequest, preflightOnExecute bool, network netclient.Config, firstClient *netclient.Client, opts ...eventcollector.RuntimeOption) (*DownloadTask, error) {
	if err := transferlimits.ValidateTaskFileCount(len(req.FileList)); err != nil {
		return nil, err
	}
	transportMode, err := types.ParseTransportMode(req.Transport)
	if err != nil {
		return nil, err
	}
	if err := network.Validate(transportMode); err != nil {
		return nil, err
	}
	if firstClient != nil && (firstClient.Mode() != transportMode || firstClient.Config() != network) {
		return nil, fmt.Errorf("initial network client does not match task configuration")
	}
	if !preflightOnExecute && firstClient == nil {
		return nil, fmt.Errorf("synchronous task preflight requires a network client")
	}

	var capabilities qtserverapi.Capabilities
	if !preflightOnExecute {
		capabilities, err = qtserverapi.RequireCapabilities(context.Background(), req.ServerAddr, firstClient, "read", "download", "file_management")
		if err != nil {
			return nil, fmt.Errorf("qtserver capability preflight failed: %w", err)
		}
	}
	smallV2Limits, smallDownloadV2, err := capabilities.SmallDownloadV2()
	if err != nil {
		return nil, fmt.Errorf("qtserver capability preflight failed: %w", err)
	}
	eventConfig := eventcollector.ApplyRuntimeOptions(opts...)
	requestToken := strings.TrimSpace(req.BearerToken)
	useAuthManager := req.UseAuthManager && !req.UseExactToken
	if requestToken != "" && !useAuthManager && !req.UseExactToken {
		if err := authmanager.SetStaticToken(requestToken); err == nil {
			useAuthManager = true
			requestToken = ""
		} else if !authmanager.IsModeLocked(err) {
			return nil, err
		}
	}
	user, err := resolveDownloadUserMode(req.DownloadUser, requestToken != "" || useAuthManager)
	if err != nil {
		return nil, err
	}
	if user == types.DownloadUserAnonymous && !preflightOnExecute {
		if err := capabilities.RequireAnonymousRead(); err != nil {
			return nil, err
		}
	}

	dt := &DownloadTask{
		pathMappings:          append([]types.PathMapping(nil), req.PathMappings...),
		networkConfig:         network,
		client:                firstClient,
		Status:                types.StatusPending,
		logger:                slog.Default().With("taskid", req.TaskID, "taskpid", req.TaskPID, "enterprise_id", req.EnterpriseID),
		publisher:             eventConfig.Publisher,
		completionNotifier:    eventConfig.CompletionNotifier,
		progressEventInterval: eventConfig.ProgressInterval,

		TaskID:             req.TaskID,
		TaskPID:            req.TaskPID,
		EnterpriseID:       req.EnterpriseID,
		CallerVersion:      req.CallerVersion,
		ServerTaskID:       strings.TrimSpace(req.ServerTaskID),
		TaskName:           req.TaskName,
		LimitRate:          req.LimitRate,
		Mode:               req.Mode,
		Transport:          transportMode,
		downloadUserMode:   user,
		stateDBPath:        req.StateDBPath,
		bearerToken:        requestToken,
		useAuthManager:     useAuthManager,
		preflightOnExecute: preflightOnExecute,
		FileList:           make([]*FileInfo, len(req.FileList)),
		TargetDir:          req.TargetDir,
		DirPaths:           append([]string(nil), req.DirPaths...),
		ServerAddr:         strings.TrimRight(req.ServerAddr, "/"),
		FileConcurrency:    types.DefaultFileConcurrency,

		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}
	dt.applyCapabilities(capabilities, smallV2Limits, smallDownloadV2)
	dt.requestedFiles = make([]requestedDownloadFile, len(req.FileList))
	dt.requestedDirPaths = append([]string(nil), req.DirPaths...)
	if dt.ServerTaskID == "" {
		dt.ServerTaskID = dt.TaskID
	}
	for i := range req.FileList {
		objectKey := req.FileList[i].RemoteURL
		if !strings.HasPrefix(objectKey, "/") {
			objectKey = "/" + objectKey
		}
		fi := NewFileInfo(dt, req.FileList[i].LocalRelPath, objectKey)
		dt.FileList[i] = fi
		dt.requestedFiles[i] = requestedDownloadFile{localPath: req.FileList[i].LocalRelPath, objectKey: objectKey}
	}

	return dt, nil
}

func (dt *DownloadTask) prepareCapabilities(ctx context.Context) error {
	capabilities, err := qtserverapi.RequireCapabilities(ctx, dt.ServerAddr, dt.client, "read", "download", "file_management")
	if err != nil {
		return fmt.Errorf("qtserver capability preflight failed: %w", err)
	}
	limits, smallV2, err := capabilities.SmallDownloadV2()
	if err != nil {
		return fmt.Errorf("qtserver capability preflight failed: %w", err)
	}
	if dt.downloadUserMode == types.DownloadUserAnonymous {
		if err := capabilities.RequireAnonymousRead(); err != nil {
			return err
		}
	}
	dt.applyCapabilities(capabilities, limits, smallV2)
	return nil
}

func (dt *DownloadTask) applyCapabilities(capabilities qtserverapi.Capabilities, limits qtserverapi.SmallDownloadV2Limits, smallV2 bool) {
	dt.maxFileBytes = capabilities.MaxFileBytes()
	dt.smallDownloadV2 = smallV2
	dt.smallBatchFiles = SmallBatchSize
	dt.smallFileBytes = SmallFileMaxBytes
	dt.smallBatchBytes = SmallBatchMaxBytes
	if smallV2 {
		dt.smallBatchFiles = minPositiveInt(SmallBatchSize, limits.Files)
		dt.smallFileBytes = minPositiveInt64(SmallFileMaxBytes, limits.FileBytes)
		dt.smallBatchBytes = minPositiveInt64(defaultSmallV2BatchBytes, limits.TotalBytes)
		if dt.smallFileBytes > dt.smallBatchBytes {
			dt.smallFileBytes = dt.smallBatchBytes
		}
	}
}

func (dt *DownloadTask) acquireClient(ctx context.Context, requestURL string) (*http.Client, netclient.ReleaseFunc, error) {
	return dt.client.Acquire(ctx, requestURL)
}

func (dt *DownloadTask) taskCorrelation() qtserverapi.TaskCorrelation {
	return qtserverapi.TaskCorrelation{
		TaskID:       dt.qtserverTaskID(),
		TaskPID:      dt.TaskPID,
		EnterpriseID: dt.EnterpriseID,
	}
}

func (dt *DownloadTask) requestContext() context.Context {
	if dt.ctx != nil {
		return dt.ctx
	}
	return context.Background()
}

func setBearerAuthorizationHeader(req *http.Request, token string) {
	if strings.TrimSpace(token) == "" {
		return
	}
	req.Header.Set("Authorization", "Bearer "+token)
}

func (dt *DownloadTask) currentBearerToken() (string, error) {
	if dt == nil {
		return "", nil
	}
	if strings.TrimSpace(dt.bearerToken) != "" {
		return dt.bearerToken, nil
	}
	if !dt.useAuthManager {
		return "", nil
	}
	return authmanager.Get()
}

func isHTTPAuthorizationFailure(statusCode int) bool {
	return statusCode == http.StatusUnauthorized || statusCode == http.StatusForbidden
}

type authorizationHTTPError struct {
	statusCode int
	cause      error
}

func (e *authorizationHTTPError) Error() string { return e.cause.Error() }
func (e *authorizationHTTPError) Unwrap() error { return e.cause }

func authorizationFailureStatus(err error) int {
	var authorizationErr *authorizationHTTPError
	if errors.As(err, &authorizationErr) {
		return authorizationErr.statusCode
	}
	return 0
}

func (dt *DownloadTask) refreshAuthorizationAfter401(ctx context.Context, statusCode int) bool {
	if dt == nil || statusCode != http.StatusUnauthorized || !dt.useAuthManager || strings.TrimSpace(dt.bearerToken) != "" {
		return false
	}
	if authmanager.Mode() != authmanager.AuthModeUserAndPass {
		return false
	}
	if err := authmanager.ForceRefresh(ctx); err != nil {
		dt.logger.Error("401 后刷新凭据失败", "err", err)
		return false
	}
	return true
}

// authFailedErr 构造 ErrAuthFailed 错误并记录日志。
func (dt *DownloadTask) authFailedErr(cause error, token string, statusCode ...int) error {
	if len(statusCode) > 0 {
		cause = &authorizationHTTPError{statusCode: statusCode[0], cause: cause}
	}
	dt.logger.Error("鉴权失败", "credential_present", token != "", "err", cause)
	return ErrAuthFailed.WithData(cause)
}

func checkTargetDirAvailable(targetDir string, wanted int64) error {
	report, err := localfs.ValidateTargetDir(targetDir, wanted)
	if err != nil {
		if errors.Is(err, localfs.ErrInsufficientSpace) {
			slog.Error("Not enough disk space in target directory",
				"path", report.TargetDir,
				"resolved_path", report.ResolvedTargetDir,
				"available", report.AvailableBytes,
				"required", report.WantedBytes,
				"reserve", report.ReserveBytes)
			return clienterror.New(
				clienterror.CodeLocalPathInvalid,
				"本地下载目标可用空间不足："+report.TargetDir,
				err,
			)
		}
		return clienterror.New(
			clienterror.CodeLocalPathInvalid,
			"本地下载目标不可用："+targetDir,
			err,
		)
	}

	if report.Created {
		slog.Info("Target directory created and verified",
			"path", report.TargetDir,
			"resolved_path", report.ResolvedTargetDir,
			"available_space", report.AvailableBytes)
	} else {
		slog.Debug("Target directory verified",
			"path", report.TargetDir,
			"resolved_path", report.ResolvedTargetDir,
			"available_space", report.AvailableBytes)
	}
	return nil
}

// 任务主循环
func (dt *DownloadTask) run() error {
	if err := dt.prepareTransferSchedule(); err != nil {
		dt.logger.Error("准备显式下载文件列表失败", "err", err)
		if errors.Is(err, ErrRemoteNotFound) {
			return err
		}
		var taskErr *TaskError
		if errors.As(err, &taskErr) {
			return err
		}
		var limitErr *transferlimits.Error
		if errors.As(err, &limitErr) {
			return err
		}
		var clientErr *clienterror.Error
		if errors.As(err, &clientErr) {
			return err
		}
		// 不要将非鉴权错误伪装成鉴权失败，避免 GUI 误判
		return ErrInternalError.WithData(err)
	}

	// 创建浏览过程中发现的空目录
	if err := dt.createLocalDirectories(); err != nil {
		dt.logger.Error("create empty directories after browse failed", "err", err)
		return err
	}

	return dt.runScheduledTransfers()
}

func (dt *DownloadTask) resetRequestedSelections() {
	if len(dt.pathMappings) > 0 {
		// Keep the committed membership and directories. Only per-run state
		// (grants, chunks, progress, errors) is reset; sources are not rescanned.
		for i, file := range dt.FileList {
			if file != nil {
				dt.FileList[i] = file.newRunFile()
			}
		}
		return
	}
	dt.DirPaths = append(dt.DirPaths[:0], dt.requestedDirPaths...)
	dt.FileList = make([]*FileInfo, len(dt.requestedFiles))
	for index, requested := range dt.requestedFiles {
		dt.FileList[index] = NewFileInfo(dt, requested.localPath, requested.objectKey)
	}
}

// beginRun performs the complete pending -> running transition. Round-scoped
// data is initialized before running becomes visible, so snapshots never mix
// two rounds.
func (dt *DownloadTask) beginRun(ctx context.Context) (context.Context, context.CancelFunc, chan struct{}, error) {
	dt.mu.Lock()
	defer dt.mu.Unlock()
	if dt.Status != types.StatusPending {
		return nil, nil, nil, fmt.Errorf("%w: cannot run download task in %s", domain.ErrInvalidTaskState, dt.Status)
	}
	dt.prepareRunLocked()
	roundCtx, cancel := context.WithCancel(ctx)
	roundDone := make(chan struct{})
	dt.ctx, dt.cancel, dt.roundDone = roundCtx, cancel, roundDone
	now := time.Now()
	dt.Status = types.StatusRunning
	dt.UpdatedAt = now
	dt.StartedAt = now
	dt.FinishedAt = time.Time{}
	dt.Started = true
	dt.Err = nil
	dt.finalErr = nil
	dt.stopRequested = false
	dt.logger.Debug("download task status changed", "from", types.StatusPending, "to", types.StatusRunning)
	dt.publishStatusLocked(types.NewTaskStatusEvent(dt.TaskID, types.TaskStatusToEventStatus(types.StatusRunning), ""))
	dt.publishProgressLocked(true)
	return roundCtx, cancel, roundDone, nil
}

// Run starts one execution round without blocking. Preparation and transfer
// errors are part of this round and finish as failed.
func (dt *DownloadTask) Run(ctx context.Context) error {
	roundCtx, cancel, roundDone, err := dt.beginRun(ctx)
	if err != nil {
		return err
	}
	go func() {
		defer dt.notifyCompletion()
		dt.executeRound(roundCtx, cancel, roundDone)
	}()
	return nil
}

func (dt *DownloadTask) executeRound(ctx context.Context, cancel context.CancelFunc, roundDone chan struct{}) error {
	defer close(roundDone)
	defer cancel()

	if err := ctx.Err(); err != nil {
		dt.releaseExecutionResources()
		return dt.finishExecution(err, false)
	}

	if dt.client == nil {
		client, err := netclient.New(dt.Transport, dt.networkConfig)
		if err != nil {
			dt.releaseExecutionResources()
			return dt.finishExecution(err, false)
		}
		dt.client = client
	}
	dt.chunkSlots = make(netclient.ChunkSlots, dt.client.Capacity())

	if dt.preflightOnExecute {
		if err := dt.prepareCapabilities(ctx); err != nil {
			dt.releaseExecutionResources()
			return dt.finishExecution(err, false)
		}
	}

	err := dt.run()
	dt.Rate.Store(0)
	completed := int(dt.VerifiedFileNum.Load()) == len(dt.AuthorizedFiles)
	// All business goroutines and this round's resources converge before the
	// terminal status becomes visible.
	dt.releaseExecutionResources()
	return dt.finishExecution(err, completed)
}

func (dt *DownloadTask) releaseExecutionResources() {
	if dt.client != nil {
		_ = dt.client.Close()
		dt.client = nil
	}
	dt.chunkSlots = nil
	dt.rateLimiter = nil
}

func (dt *DownloadTask) notifyCompletion() {
	if dt.completionNotifier != nil {
		dt.completionNotifier()
	}
}

func (dt *DownloadTask) Stop() error {
	dt.mu.Lock()
	status := dt.Status
	if status != types.StatusPending && status != types.StatusRunning {
		dt.mu.Unlock()
		return nil
	}
	dt.stopRequested = true
	cancel := dt.cancel
	var roundDone <-chan struct{}
	if status == types.StatusRunning {
		roundDone = dt.roundDone
	} else {
		dt.Err = nil
		dt.FinishedAt = time.Now()
		for _, files := range [][]*FileInfo{dt.FileList, dt.AuthorizedFiles, dt.UnAuthorizedFiles} {
			for _, file := range files {
				if file != nil {
					file.failure.Clear()
				}
			}
		}
		if err := dt.transitionTo(types.StatusStopped); err != nil {
			dt.mu.Unlock()
			return err
		}
	}
	dt.mu.Unlock()
	if cancel != nil {
		cancel()
	}
	if roundDone != nil {
		<-roundDone
	}
	return nil
}

func (dt *DownloadTask) Abandon() error {
	if dt == nil {
		return nil
	}
	dt.mu.Lock()
	cancel := dt.cancel
	roundDone := dt.roundDone
	dt.mu.Unlock()
	if cancel != nil {
		cancel()
	}
	if roundDone != nil {
		<-roundDone
	}

	var joined error
	dt.smallTempFiles.Range(func(key, _ any) bool {
		path, ok := key.(string)
		if ok && path != "" {
			if err := os.Remove(path); err != nil && !os.IsNotExist(err) {
				joined = errors.Join(joined, fmt.Errorf("remove small download temp file %q: %w", path, err))
				return true
			}
			dt.smallTempFiles.Delete(key)
		}
		return true
	})
	for _, file := range dt.FileList {
		if file == nil {
			continue
		}
		progressPath := file.ProgressPath
		if progressPath == "" && file.LocalPath != "" {
			progressPath = filepath.Join(dt.TargetDir, file.LocalPath+".progress")
		}
		if progressPath == "" {
			continue
		}
		if err := os.Remove(progressPath); err != nil && !os.IsNotExist(err) {
			joined = errors.Join(joined, fmt.Errorf("remove progress file %q: %w", progressPath, err))
		}
	}
	return joined
}

func (dt *DownloadTask) ReportDeleted(context.Context) error { return nil }

// 更新任务总传输速率
func (dt *DownloadTask) updateTransferRate(ctx context.Context) error {
	interval := 300 * time.Millisecond
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	swa := average.NewSMA(20)
	lastNetworkReceived := dt.NetworkReceived.Load()
	lastAt := time.Now()

	for {
		select {
		case <-ctx.Done():
			dt.sampleTransferRates(swa, &lastNetworkReceived, &lastAt, time.Now())
			return nil
		case <-ticker.C:
			dt.sampleTransferRates(swa, &lastNetworkReceived, &lastAt, time.Now())
		}

		// dt.logger.Debug("Transfer rate updated",
		// 	"task_id", dt.TaskID,
		// 	"rate_bytes_per_sec", dt.Rate,
		// 	"percent_complete", fmt.Sprintf("%.2f%%", float64(dt.Transferred)*100/float64(dt.TotalSize)),
		// )
	}
}

func (dt *DownloadTask) sampleTransferRates(swa *average.SMA, lastNetworkReceived *int64, lastAt *time.Time, now time.Time) {
	elapsed := now.Sub(*lastAt)
	if elapsed <= 0 {
		return
	}
	current := dt.NetworkReceived.Load()
	delta := current - *lastNetworkReceived
	if delta < 0 {
		delta = 0
	}
	dt.Rate.Store(int64(swa.Update(float64(delta) / elapsed.Seconds())))
	*lastNetworkReceived = current
	*lastAt = now

	dt.TransferingFiles.Range(func(_, value any) bool {
		if file, ok := value.(*FileInfo); ok && file != nil {
			file.sampleTransferRates(elapsed)
		}
		return true
	})
}

func (dt *DownloadTask) reportProgress(ctx context.Context) error {
	interval := dt.progressEventInterval
	if interval <= 0 {
		interval = eventcollector.DefaultProgressInterval
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			dt.publishProgressSnapshot()
			return nil
		case <-ticker.C:
			dt.publishProgressSnapshot()
		}
	}
}

func (dt *DownloadTask) publishProgressSnapshot() {
	dt.publishProgress(true)
	dt.TransferingFiles.Range(func(_, value any) bool {
		if file, ok := value.(*FileInfo); ok && file != nil {
			file.publishProgressEvents(true)
		}
		return true
	})
}

func (dt *DownloadTask) ToGrantRequest() *types.DownloadGrantRequest {
	return dt.grantRequestForFiles(dt.FileList)
}

func (dt *DownloadTask) grantRequestForFiles(files []*FileInfo) *types.DownloadGrantRequest {
	req := types.DownloadGrantRequest{
		TaskID: dt.qtserverTaskID(),
		Items:  make([]types.DownloadObjectRequest, 0, len(files)),
	}
	for _, file := range files {
		req.Items = append(req.Items, types.DownloadObjectRequest{
			ObjectKey: file.ObjectKey,
		})
	}
	return &req
}

func (dt *DownloadTask) qtserverTaskID() string {
	if strings.TrimSpace(dt.ServerTaskID) != "" {
		return dt.ServerTaskID
	}
	return dt.TaskID
}

func resolveLocalRelPathForObjectKey(objectKey string, selections []*FileInfo) (string, error) {
	bestPrefixLen := -1
	bestLocalPath := ""

	for _, selection := range selections {
		if selection == nil {
			continue
		}
		switch {
		case objectKey == selection.ObjectKey:
			if len(selection.ObjectKey) > bestPrefixLen {
				bestPrefixLen = len(selection.ObjectKey)
				bestLocalPath = selection.LocalPath
			}
		case selection.ObjectKey != "" && strings.HasPrefix(objectKey, selection.ObjectKey+"/"):
			suffix := strings.TrimPrefix(objectKey, selection.ObjectKey+"/")
			localPath := filepath.Join(selection.LocalPath, filepath.FromSlash(suffix))
			if len(selection.ObjectKey) > bestPrefixLen {
				bestPrefixLen = len(selection.ObjectKey)
				bestLocalPath = localPath
			}
		}
	}

	if bestPrefixLen < 0 {
		return "", fmt.Errorf("download task response contains unexpected object_key %q", objectKey)
	}
	return bestLocalPath, nil
}

func (dt *DownloadTask) materializeTaskFiles(selections []*FileInfo, responseFiles []types.DownloadGrantFileResponse) ([]*FileInfo, error) {
	if len(dt.pathMappings) > 0 {
		return dt.materializeMappedFiles(selections, responseFiles)
	}
	files := make([]*FileInfo, 0, len(responseFiles))
	for _, responseFile := range responseFiles {
		if strings.TrimSpace(responseFile.Grant) == "" {
			return nil, fmt.Errorf("download grant response missing grant for object_key %q", responseFile.ObjectKey)
		}
		if responseFile.Size < 0 {
			return nil, fmt.Errorf("download grant response contains negative size for object_key %q", responseFile.ObjectKey)
		}
		localRelPath, err := resolveLocalRelPathForObjectKey(responseFile.ObjectKey, selections)
		if err != nil {
			return nil, err
		}
		file := NewFileInfo(dt, localRelPath, responseFile.ObjectKey)
		file.Authorized = true
		file.Size = responseFile.Size
		file.Grant = responseFile.Grant
		files = append(files, file)
	}
	return files, nil
}

// createLocalDirectories 从 FileList 的本地相对路径和 DirPaths 中提取所有目录路径，
// 并在 TargetDir 下预先创建这些目录。
func (dt *DownloadTask) createLocalDirectories() error {
	if len(dt.pathMappings) > 0 {
		return dt.createMappedDirectories()
	}
	dirs := make(map[string]bool)
	for _, fi := range dt.FileList {
		// LocalPath 如 "path/to/file.txt"，提取 "path/" 和 "path/to/"
		for p := filepath.Dir(fi.LocalPath); p != "." && p != string(filepath.Separator); p = filepath.Dir(p) {
			dirs[p] = true
		}
	}
	// 也加入显式指定的空目录路径
	for _, d := range dt.DirPaths {
		normalized := strings.ReplaceAll(d, "\\", "/")
		normalized = strings.Trim(normalized, "/")
		if normalized == "" {
			continue
		}
		dirs[normalized] = true
	}

	for d := range dirs {
		fullPath := filepath.Join(dt.TargetDir, d)
		if err := os.MkdirAll(fullPath, 0755); err != nil {
			return clienterror.New(clienterror.CodeLocalPathInvalid, "无法创建本地下载目录："+fullPath, err)
		}
		dt.logger.Debug("local directory created", "dir", fullPath)
	}
	return nil
}

func isGrantSelectionTooLarge(statusCode int, body []byte) bool {
	if statusCode != http.StatusBadRequest {
		return false
	}
	return strings.Contains(strings.ToLower(string(body)), "expanded selection exceeds maximum of 1000 files")
}

func (dt *DownloadTask) authorizeSelections(selections []*FileInfo) ([]*FileInfo, error) {
	reqCtx := dt.requestContext()
	authRetryCount := 0
	retryState := newDownloadControlRetryState()
	var lastTransportErr error

	for {
		grantReq := dt.grantRequestForFiles(selections)
		grantReqBytes, err := json.Marshal(grantReq)
		if err != nil {
			return nil, fmt.Errorf("failed to marshal grant request: %w", err)
		}

		requestURL, err := qtserverurl.JoinEndpoint(dt.ServerAddr, "/d/grant")
		if err != nil {
			return nil, err
		}

		req, err := http.NewRequestWithContext(reqCtx, "POST", requestURL, bytes.NewBuffer(grantReqBytes))
		if err != nil {
			return nil, fmt.Errorf("failed to create request: %w", err)
		}
		req.Header.Set("Content-Type", "application/json")
		qtserverapi.SetTaskCorrelationHeaders(req.Header, dt.taskCorrelation())

		client, releaseClient, err := dt.acquireClient(reqCtx, req.URL.String())
		if err != nil {
			return nil, err
		}
		usedToken := ""
		if dt.downloadUser() == types.DownloadUserSelf {
			usedToken, err = dt.currentBearerToken()
			if err != nil {
				releaseClient()
				return nil, err
			}
			setBearerAuthorizationHeader(req, usedToken)
		}

		resp, err := client.Do(req)
		releaseClient()
		if err != nil {
			requestErr := fmt.Errorf("failed to send request: %w", err)
			retry, waitErr := retryDownloadControlTransport(reqCtx, dt.logger, "request download grant", &retryState, requestErr)
			if waitErr != nil {
				return nil, waitErr
			}
			if retry {
				lastTransportErr = requestErr
				continue
			}
			return nil, requestErr
		}
		logDownloadControlTransportRecovered(dt.logger, "request download grant", retryState, lastTransportErr)

		body, readErr := io.ReadAll(resp.Body)
		_ = resp.Body.Close()
		if readErr != nil {
			requestErr := fmt.Errorf("failed to read grant response: %w", readErr)
			retry, waitErr := retryDownloadControlTransport(reqCtx, dt.logger, "request download grant", &retryState, requestErr)
			if waitErr != nil {
				return nil, waitErr
			}
			if retry {
				lastTransportErr = requestErr
				continue
			}
			return nil, requestErr
		}

		slog.Debug("Grant response status", "status", resp.Status, "code", resp.StatusCode)
		if resp.StatusCode != http.StatusOK {
			if retry, waitErr := retryDownloadControlHTTP(reqCtx, &retryState, resp.StatusCode, resp.Header); waitErr != nil {
				return nil, waitErr
			} else if retry {
				continue
			}
			if len(dt.pathMappings) > 0 && !isHTTPAuthorizationFailure(resp.StatusCode) {
				var envelope struct {
					ReasonCode string `json:"reason_code"`
					Message    string `json:"message"`
				}
				_ = json.Unmarshal(body, &envelope)
				return nil, &qtserverapi.APIError{Status: resp.StatusCode, ReasonCode: envelope.ReasonCode, Message: envelope.Message}
			}
			httpErr := fmt.Errorf("grant creation failed with status code: %d, body: %s", resp.StatusCode, strings.TrimSpace(string(body)))
			if isGrantSelectionTooLarge(resp.StatusCode, body) {
				return nil, fmt.Errorf("%w: %v", errDownloadGrantSelectionTooLarge, httpErr)
			}
			if isHTTPAuthorizationFailure(resp.StatusCode) {
				if authRetryCount < downloadAuthRetryMaxRefreshes && dt.refreshAuthorizationAfter401(reqCtx, resp.StatusCode) {
					authRetryCount++
					continue
				}
				return nil, dt.authFailedErr(httpErr, usedToken, resp.StatusCode)
			}
			return nil, httpErr
		}

		var taskResp types.DownloadGrantResponse
		if err := json.Unmarshal(body, &taskResp); err != nil {
			slog.Error("JSON解析 grant 响应失败", "err", err)
			return nil, fmt.Errorf("failed to parse response")
		}
		slog.Debug("Grant response parsed", "file_count", len(taskResp.Files))

		if strings.TrimSpace(taskResp.TaskID) == "" {
			return nil, fmt.Errorf("download grant response missing taskid")
		}
		files, err := dt.materializeTaskFiles(selections, taskResp.Files)
		if err != nil {
			return nil, err
		}
		return files, nil
	}
}

func (dt *DownloadTask) appendAuthorizationResults(files []*FileInfo) []*FileInfo {
	authorized := make([]*FileInfo, 0, len(files))
	for _, f := range files {
		if f.Authorized {
			dt.AuthorizedFiles = append(dt.AuthorizedFiles, f)
			authorized = append(authorized, f)
		} else {
			dt.UnAuthorizedFiles = append(dt.UnAuthorizedFiles, f)
		}
	}
	return authorized
}

// 请求文件下载准备信息 (qtserver API: POST /d/grant)
func (dt *DownloadTask) GetAuthorization() error {
	// 清空之前的授权结果，避免重复添加
	dt.AuthorizedFiles = nil
	dt.UnAuthorizedFiles = nil

	files, err := dt.authorizeSelections(dt.FileList)
	if err != nil {
		return err
	}
	dt.FileList = files
	dt.appendAuthorizationResults(files)
	return nil
}

func (dt *DownloadTask) runAuthorizedDownloads() error {
	// 按 4 MiB 阈值将 AuthorizedFiles 分成 SmallFiles 和 LargeFiles
	dt.splitAuthorizedFiles()

	// 计算已授权文件的总下载大小
	if err := dt.calcTotalSize(); err != nil {
		return err
	}

	// 检查目录是否可用
	if err := checkTargetDirAvailable(dt.TargetDir, dt.TotalSize.Load()); err != nil {
		dt.logger.Error("目标目录不可用", "err", err)
		if te, ok := err.(*TaskError); ok {
			return te
		}
		return ErrTargetDirNotAvailable.WithData(err)
	}

	// 先执行小文件批量下载
	if len(dt.SmallFiles) > 0 {
		if err := dt.downloadSmallFiles(); err != nil {
			dt.logger.Error("小文件批量下载失败", "err", err)
			return err
		}
	}

	// 再执行大文件标准下载
	if len(dt.LargeFiles) == 0 {
		return nil
	}

	eg, egctx := errgroup.WithContext(dt.ctx)
	eg.Go(func() error { // 更新总传输速率
		return dt.updateTransferRate(egctx)
	})
	eg.Go(func() error {
		return dt.reportProgress(egctx)
	})

	eg.Go(func() error { // 执行文件下载
		err := dt.DownloadFiles(egctx)
		dt.cancel()
		return err
	})

	// Wait：返回第一个非 nil error，并且会 cancel ctx
	if err := eg.Wait(); err != nil {
		dt.logger.Error("任务运行出错", "err", err)
		return err
	}
	dt.logger.Debug("任务运行结束", "task_id", dt.TaskID, "status", dt.Status)
	return nil
}

func (dt *DownloadTask) runBatchedGrantFallback() error {
	expandedFiles, err := dt.expandSelectionsViaBrowse(dt.FileList)
	if err != nil {
		dt.logger.Error("browse 展开下载选择失败", "err", err)
		return dt.authFailedErr(err, "")
	}
	if len(expandedFiles) == 0 {
		return dt.authFailedErr(fmt.Errorf("download selection expanded to zero files"), "")
	}

	dt.FileList = expandedFiles
	dt.AuthorizedFiles = nil
	dt.SmallFiles = nil
	dt.LargeFiles = nil
	dt.UnAuthorizedFiles = nil

	plannedTotalSize, err := sumFileSizes(expandedFiles)
	if err != nil {
		return err
	}
	if err := checkTargetDirAvailable(dt.TargetDir, plannedTotalSize); err != nil {
		dt.logger.Error("目标目录不可用", "err", err)
		if te, ok := err.(*TaskError); ok {
			return te
		}
		return ErrTargetDirNotAvailable.WithData(err)
	}
	dt.TotalSize.Store(plannedTotalSize)

	eg, egctx := errgroup.WithContext(dt.ctx)
	eg.Go(func() error {
		return dt.updateTransferRate(egctx)
	})
	eg.Go(func() error {
		return dt.reportProgress(egctx)
	})
	eg.Go(func() error {
		defer dt.cancel()

		for _, batch := range chunkFileInfos(expandedFiles, GrantBatchSize) {
			if err := egctx.Err(); err != nil {
				return err
			}

			batchFiles, err := dt.authorizeSelections(batch)
			if err != nil {
				dt.logger.Error("分批 grant 失败", "err", err)
				return dt.authFailedErr(err, "")
			}

			authorizedFiles := dt.appendAuthorizationResults(batchFiles)
			smallFiles, largeFiles := dt.splitPlannedFilesBySize(authorizedFiles)
			dt.SmallFiles = append(dt.SmallFiles, smallFiles...)
			dt.LargeFiles = append(dt.LargeFiles, largeFiles...)

			if len(smallFiles) > 0 {
				if err := dt.downloadSmallFilesBatch(smallFiles); err != nil {
					dt.logger.Error("分批小文件下载失败", "err", err)
					return err
				}
			}
			if len(largeFiles) > 0 {
				if err := dt.downloadLargeFiles(egctx, largeFiles); err != nil {
					dt.logger.Error("分批大文件下载失败", "err", err)
					return err
				}
			}
		}

		return dt.calcTotalSize()
	})

	if err := eg.Wait(); err != nil {
		dt.logger.Error("分批下载任务运行出错", "err", err)
		return err
	}
	dt.logger.Debug("分批下载任务运行结束", "task_id", dt.TaskID, "status", dt.Status)
	return nil
}

// 程序的主要下载逻辑（仅处理大文件）
func (dt *DownloadTask) DownloadFiles(ctx context.Context) error {
	return dt.downloadLargeFiles(ctx, dt.LargeFiles)
}

func (dt *DownloadTask) downloadLargeFiles(ctx context.Context, files []*FileInfo) error {
	dt.logger.Debug("DownloadFiles started", slog.Any("task", dt))
	fileSem := make(chan struct{}, max(1, dt.FileConcurrency))
	var g errgroup.Group
	var errorMu sync.Mutex
	var joinedErr error

Loop:
	for i := range files {
		fi := files[i]

		select {
		case <-ctx.Done():
			dt.logger.Debug("下载任务已取消")
			break Loop
		case fileSem <- struct{}{}:
			g.Go(func() error {
				defer func() {
					<-fileSem
				}() // 释放令牌
				if err := fi.Download(ctx); err != nil && !errors.Is(err, context.Canceled) {
					errorMu.Lock()
					joinedErr = errors.Join(joinedErr, fmt.Errorf("download %s: %w", fi.ObjectKey, err))
					errorMu.Unlock()
				}
				return nil
			})
		}
	}
	_ = g.Wait()
	if err := ctx.Err(); err != nil {
		return err
	}
	dt.logger.Debug("下载任务完成", "task_id", dt.TaskID)
	return joinedErr
}

// 计算已授权文件的总下载大小
func (dt *DownloadTask) calcTotalSize() error {
	total, err := sumFileSizes(dt.AuthorizedFiles)
	if err != nil {
		return err
	}
	dt.TotalSize.Store(total)
	return nil
}

// splitAuthorizedFiles 按照 SmallFileMaxBytes 将 AuthorizedFiles 分成
// SmallFiles（< 阈值）和 LargeFiles（>= 阈值）。
func (dt *DownloadTask) splitAuthorizedFiles() {
	dt.SmallFiles, dt.LargeFiles = dt.splitPlannedFilesBySize(dt.AuthorizedFiles)
	dt.logger.Debug("splitAuthorizedFiles",
		"small", len(dt.SmallFiles),
		"large", len(dt.LargeFiles),
		"threshold", SmallFileMaxBytes)
}

func (dt *DownloadTask) splitPlannedFilesBySize(files []*FileInfo) ([]*FileInfo, []*FileInfo) {
	if dt == nil || !dt.smallDownloadV2 {
		return splitFilesBySize(files)
	}
	limit := dt.smallFileBytes
	if limit <= 0 {
		limit = SmallFileMaxBytes
	}
	var smallFiles []*FileInfo
	var largeFiles []*FileInfo
	for _, file := range files {
		if file != nil && file.Size <= limit {
			smallFiles = append(smallFiles, file)
		} else {
			largeFiles = append(largeFiles, file)
		}
	}
	return smallFiles, largeFiles
}

func splitFilesBySize(files []*FileInfo) ([]*FileInfo, []*FileInfo) {
	var smallFiles []*FileInfo
	var largeFiles []*FileInfo
	for _, f := range files {
		if f.Size < SmallFileMaxBytes {
			smallFiles = append(smallFiles, f)
		} else {
			largeFiles = append(largeFiles, f)
		}
	}
	return smallFiles, largeFiles
}

// ToDownloadTaskSummary converts a task to summary view.
func (dt *DownloadTask) ToDownloadTaskSummary() *types.DownloadTaskSummary {
	if dt == nil {
		return &types.DownloadTaskSummary{}
	}
	dt.mu.Lock()
	status, cause, started := dt.Status, dt.Err, dt.Started
	dt.mu.Unlock()

	// Extract transferring files from sync.Map
	var transferringFiles []*types.FileInfoSummary
	dt.TransferingFiles.Range(func(key, value any) bool {
		if fileInfo, ok := value.(*FileInfo); ok {
			transferringFiles = append(transferringFiles, fileInfo.ToFileInfoSummary())
		}
		return true
	})

	return &types.DownloadTaskSummary{
		Cause:            cause,
		TaskID:           dt.TaskID,
		TaskName:         dt.TaskName,
		Mode:             dt.Mode,
		Status:           status,
		Err:              errString(cause),
		ReasonCode:       clienterror.ReasonCode(cause),
		Started:          started,
		Transferred:      dt.Transferred.Load(),
		TotalSize:        dt.TotalSize.Load(),
		Rate:             dt.Rate.Load(),
		TransferingFiles: transferringFiles,
	}
}

// Snapshot returns a stable complete view for the detail API.
func (dt *DownloadTask) Snapshot() domain.TaskSnapshot {
	if dt == nil {
		return &types.DownloadTaskDetail{}
	}
	dt.mu.Lock()
	defer dt.mu.Unlock()
	status, cause, started := dt.Status, dt.Err, dt.Started
	createdAt, updatedAt, startedAt, finishedAt := dt.CreatedAt, dt.UpdatedAt, dt.StartedAt, dt.FinishedAt
	snapshotFiles := dt.AuthorizedFiles
	if len(dt.pathMappings) > 0 {
		snapshotFiles = dt.FileList
	}
	files := make([]*types.FileInfoDetail, 0, len(snapshotFiles))
	for _, file := range snapshotFiles {
		if file == nil {
			continue
		}
		files = append(files, file.ToFileInfoDetail())
	}
	unauthorizedFiles := make([]*types.FileInfoDetail, 0, len(dt.UnAuthorizedFiles))
	for _, file := range dt.UnAuthorizedFiles {
		if file == nil {
			continue
		}
		unauthorizedFiles = append(unauthorizedFiles, file.ToFileInfoDetail())
	}

	return &types.DownloadTaskDetail{
		PathMappings:      append([]types.PathMapping(nil), dt.pathMappings...),
		Transport:         dt.Transport,
		Connections:       dt.networkConfig.Pool.Connections,
		Streams:           dt.networkConfig.Pool.StreamsPerConnection,
		FileConcurrency:   dt.FileConcurrency,
		Cause:             cause,
		TaskID:            dt.TaskID,
		TaskName:          dt.TaskName,
		Mode:              dt.Mode,
		ServerAddr:        dt.ServerAddr,
		TargetDir:         dt.TargetDir,
		Status:            status,
		Err:               errString(cause),
		ReasonCode:        clienterror.ReasonCode(cause),
		Started:           started,
		Files:             files,
		UnauthorizedFiles: unauthorizedFiles,
		Transferred:       dt.Transferred.Load(),
		NetworkReceived:   dt.NetworkReceived.Load(),
		TotalSize:         dt.TotalSize.Load(),
		Rate:              dt.Rate.Load(),
		CreatedAt:         createdAt,
		UpdatedAt:         updatedAt,
		StartedAt:         startedAt,
		FinishedAt:        finishedAt,
	}
}

// errString converts an error to a string pointer for JSON serialization.
func errString(err error) string {
	if err == nil {
		return ""
	}
	return clienterror.Message(err)
}

// ============================================
// 实现 domain.Task 接口
// ============================================

// GetID 返回任务ID
func (dt *DownloadTask) GetID() string {
	return dt.TaskID
}

func (dt *DownloadTask) GetTaskPID() string {
	return dt.TaskPID
}

func (dt *DownloadTask) GetEnterpriseID() string {
	return dt.EnterpriseID
}

// GetName 返回任务名称
func (dt *DownloadTask) GetName() string {
	return dt.TaskName
}

// GetType 返回任务类型
func (dt *DownloadTask) GetType() domain.TaskType {
	return domain.TaskTypeDownload
}

// GetStatus returns a lock-consistent basic status for manager decisions.
func (dt *DownloadTask) GetStatus() domain.TaskBasicStatus {
	dt.mu.Lock()
	defer dt.mu.Unlock()
	return domain.TaskBasicStatus{
		Status:     dt.Status,
		Error:      dt.Err,
		Started:    dt.Started,
		StartedAt:  dt.StartedAt,
		FinishedAt: dt.FinishedAt,
	}
}

// Retry only changes a terminal status back to pending. It deliberately keeps
// the previous error, progress, files and execution control fields until the
// next Run initializes a new round.
func (dt *DownloadTask) Retry() error {
	dt.mu.Lock()
	defer dt.mu.Unlock()
	if !isTerminalDownloadTaskStatus(dt.Status) {
		return fmt.Errorf("%w: cannot retry download task in %s", domain.ErrInvalidTaskState, dt.Status)
	}
	if !types.IsValidTransition(dt.Status, types.StatusPending) {
		return fmt.Errorf("%w: invalid transition to pending", domain.ErrInvalidTaskState)
	}
	// Retry only changes the status. UpdatedAt, error, progress, times, files and
	// execution control fields stay as the previous round left them.
	dt.Status = types.StatusPending
	dt.publishStatusLocked(types.NewTaskStatusEvent(
		dt.TaskID,
		types.TaskStatusToEventStatus(types.StatusPending),
		"",
	))
	return nil
}

func (dt *DownloadTask) prepareRunLocked() {
	dt.resetRequestedSelections()
	dt.rateLimiter = ratelimit.New(dt.LimitRate)
	dt.Transferred.Store(0)
	dt.NetworkReceived.Store(0)
	dt.TotalSize.Store(0)
	dt.Rate.Store(0)
	if strings.TrimSpace(dt.ServerTaskID) == "" {
		dt.ServerTaskID = dt.TaskID
	}
	dt.VerifiedFileNum.Store(0)
	dt.TransferingFiles.Clear()
	dt.AuthorizedFiles = nil
	dt.SmallFiles = nil
	dt.LargeFiles = nil
	dt.UnAuthorizedFiles = nil
	dt.lastTaskProgressPublishedAt.Store(0)
}

func (dt *DownloadTask) publishProgress(force bool) {
	if dt == nil || dt.publisher == nil {
		return
	}
	dt.mu.Lock()
	running := dt.Status == types.StatusRunning
	dt.mu.Unlock()
	// 周期事件只在运行中发布；生命周期边界可强制发布最终快照。
	if !force && !running {
		return
	}
	dt.publishProgressEvent(force)
}

func (dt *DownloadTask) publishProgressLocked(force bool) {
	if dt == nil || dt.publisher == nil {
		return
	}
	if !force && dt.Status != types.StatusRunning {
		return
	}
	dt.publishProgressEvent(force)
}

func (dt *DownloadTask) publishProgressEvent(force bool) {
	if !eventcollector.ShouldPublishProgress(&dt.lastTaskProgressPublishedAt, dt.progressEventInterval, force) {
		return
	}
	dt.publisher.Publish(types.NewTaskProgressEvent(
		dt.TaskID,
		dt.TotalSize.Load(),
		dt.Transferred.Load(),
		dt.Rate.Load(),
	))
}

// SetError 设置错误信息
func (dt *DownloadTask) setError(err error) {
	dt.Err = clienterror.Normalize(err)
	dt.UpdatedAt = time.Now()
}

// ToSummary 返回任务摘要信息
func (dt *DownloadTask) ToSummary() domain.TaskSummary {
	return dt.ToDownloadTaskSummary()
}

// ==================== 状态转换方法 ====================
// 这些方法封装了状态机的使用，确保状态由Task内部控制
// 状态转换成功后，会发送事件通知外界

// transitionTo 内部状态转换方法
func (dt *DownloadTask) transitionTo(newStatus types.TaskStatus) error {
	if !types.IsValidTransition(dt.Status, newStatus) {
		return ErrTaskStatusTransitionFailed.WithData(
			fmt.Errorf("invalid status transition from %s to %s", dt.Status, newStatus))
	}
	dt.UpdatedAt = time.Now()
	dt.Status = newStatus
	statusEvent := types.NewTaskStatusEventWithCause(
		dt.TaskID,
		types.TaskStatusToEventStatus(dt.Status),
		errString(dt.Err),
		clienterror.ReasonCode(dt.Err),
		dt.Err,
	)
	// 生命周期边界强制发布一次最终快照，周期事件由独立 reporter 负责。
	if isTerminalDownloadTaskStatus(newStatus) {
		dt.publishProgressLocked(true)
		dt.publishStatusLocked(statusEvent)
	} else {
		dt.publishStatusLocked(statusEvent)
		dt.publishProgressLocked(true)
	}
	return nil
}

func (dt *DownloadTask) publishStatusLocked(event types.TaskEvent) {
	if dt.publisher != nil {
		dt.publisher.Publish(event)
	}
}

func isTerminalDownloadTaskStatus(status types.TaskStatus) bool {
	return status == types.StatusCompleted || status == types.StatusFailed || status == types.StatusStopped
}

// func (dt *DownloadTask) publishStatus() {
// 	e := types.TaskEvent{
// 		EventType: types.EventTypeTaskStatus,
// 		TaskID:    dt.TaskID,
// 		Status:    dt.Status,
// 		Error:     dt.Err,
// 	}
// 	eventcollector.PublishEvent(e)
// }
