package downloadtask

import (
	"context"
	"errors"
	"fmt"
	"sync"

	"golang.org/x/sync/errgroup"
)

func (dt *DownloadTask) prepareTransferSchedule() error {
	var explicitFiles []*FileInfo
	var err error
	if len(dt.pathMappings) > 0 {
		// A fresh expansion already has browse metadata and validated targets.
		// Subsequent rounds refresh only the committed files, without browsing.
		reuseFiles := dt.pathMappingsExpanded
		if err := dt.preparePathMappings(); err != nil {
			return err
		}
		explicitFiles = dt.FileList
		if reuseFiles {
			if err := dt.checkMappedTargets(); err != nil {
				return err
			}
			explicitFiles, err = dt.refreshFileMetadata(explicitFiles)
		}
	} else {
		explicitFiles, err = dt.expandSelectionsViaBrowse(dt.FileList)
	}
	if err != nil {
		return err
	}
	if len(explicitFiles) == 0 {
		// Both input forms can produce a directory-only task. Keep DirPaths
		// and the mapping expansion flag even when the file list is empty.
		if len(dt.DirPaths) == 0 {
			return fmt.Errorf("%w: download selection expanded to zero files and no empty directories found", ErrPlanning)
		}
		// 空目录下载：无文件需要传输，仅创建目录即可
		dt.mu.Lock()
		dt.FileList = nil
		dt.AuthorizedFiles = nil
		dt.SmallFiles = nil
		dt.LargeFiles = nil
		dt.UnAuthorizedFiles = nil
		dt.TotalSize.Store(0)
		dt.mu.Unlock()
		dt.logger.Info("empty directory download: no files to transfer, will create directories only",
			"dir_count", len(dt.DirPaths))
		return nil
	}

	authorized := make([]*FileInfo, 0, len(explicitFiles))
	for _, file := range explicitFiles {
		if file == nil {
			continue
		}
		file.Authorized = true
		authorized = append(authorized, file)
	}
	smallFiles, largeFiles := dt.splitPlannedFilesBySize(authorized)
	totalSize, err := sumFileSizes(explicitFiles)
	if err != nil {
		return err
	}

	dt.mu.Lock()
	dt.FileList = explicitFiles
	dt.AuthorizedFiles = authorized
	dt.SmallFiles = smallFiles
	dt.LargeFiles = largeFiles
	dt.UnAuthorizedFiles = nil
	dt.TotalSize.Store(totalSize)
	dt.mu.Unlock()
	dt.logger.Debug("prepared transfer schedule",
		"files", len(dt.FileList),
		"small", len(dt.SmallFiles),
		"large", len(dt.LargeFiles),
		"total_size", dt.TotalSize.Load())
	return nil
}

func (dt *DownloadTask) activeConcurrencyBudget() int {
	if dt.FileConcurrency <= 0 {
		return 1
	}
	return dt.FileConcurrency
}

func (dt *DownloadTask) workerCountForPending(pending int) int {
	if pending <= 0 {
		return 0
	}
	budget := dt.activeConcurrencyBudget()
	if budget > pending {
		return pending
	}
	return budget
}

func (dt *DownloadTask) runScheduledTransfers() error {
	if err := dt.checkTransferTargets(); err != nil {
		dt.logger.Error("目标目录不可用", "err", err)
		if te, ok := err.(*TaskError); ok {
			return te
		}
		return ErrTargetDirNotAvailable.WithData(err)
	}

	if len(dt.SmallFiles) == 0 && len(dt.LargeFiles) == 0 {
		return nil
	}

	eg, egctx := errgroup.WithContext(dt.ctx)
	eg.Go(func() error {
		return dt.updateTransferRate(egctx)
	})
	eg.Go(func() error {
		return dt.reportProgress(egctx)
	})
	eg.Go(func() error {
		defer dt.cancel()

		smallErr := dt.downloadScheduledSmallFiles(egctx, dt.SmallFiles)
		largeErr := dt.downloadScheduledLargeFiles(egctx, dt.LargeFiles)
		return errors.Join(smallErr, largeErr)
	})

	if err := eg.Wait(); err != nil {
		dt.logger.Error("任务运行出错", "err", err)
		return err
	}
	dt.logger.Debug("任务运行结束", "task_id", dt.TaskID, "status", dt.Status)
	return nil
}

func (dt *DownloadTask) grantLargeFile(ctx context.Context, file *FileInfo) error {
	if ctx.Err() != nil {
		return nil
	}
	if file.Authorized && file.Grant != "" {
		// Metadata preparation may already have obtained this round's grant.
		// Expired grants are refreshed by the existing download retry path.
		return nil
	}
	files, err := dt.authorizeSelections([]*FileInfo{file})
	if err != nil {
		return err
	}
	if len(files) != 1 {
		return fmt.Errorf("expected exactly 1 grant file for %s, got %d", file.ObjectKey, len(files))
	}
	granted := files[0]
	if !granted.Authorized {
		return fmt.Errorf("large file %s was not authorized", file.ObjectKey)
	}
	file.Size = granted.Size
	file.Grant = granted.Grant
	file.Authorized = true
	return nil
}

func (dt *DownloadTask) downloadScheduledLargeFiles(ctx context.Context, files []*FileInfo) error {
	workerCount := dt.workerCountForPending(len(files))
	if workerCount == 0 {
		return nil
	}

	fileCh := make(chan *FileInfo)
	var g errgroup.Group
	var errorMu sync.Mutex
	var joinedErr error
	recordError := func(err error) {
		if err == nil {
			return
		}
		errorMu.Lock()
		joinedErr = errors.Join(joinedErr, err)
		errorMu.Unlock()
	}

	for range workerCount {
		g.Go(func() error {
			for file := range fileCh {
				if ctx.Err() != nil {
					return nil
				}
				if err := dt.grantLargeFile(ctx, file); err != nil {
					recordError(fmt.Errorf("grant %s: %w", file.ObjectKey, err))
					continue
				}

				err := file.Download(ctx)
				if err != nil && !errors.Is(err, context.Canceled) {
					recordError(fmt.Errorf("download %s: %w", file.ObjectKey, err))
				}
			}
			return nil
		})
	}

	for _, file := range files {
		select {
		case <-ctx.Done():
			close(fileCh)
			_ = g.Wait()
			return ctx.Err()
		case fileCh <- file:
		}
	}
	close(fileCh)

	_ = g.Wait()
	if err := ctx.Err(); err != nil {
		return err
	}
	return joinedErr
}
