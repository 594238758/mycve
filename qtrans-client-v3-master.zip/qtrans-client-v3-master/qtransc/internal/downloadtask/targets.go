package downloadtask

import (
	"os"
	"path/filepath"

	"qtransc/internal/clienterror"
	"qtransc/internal/localfs"
	"qtransc/internal/pathplan"
)

// checkMappedTargets rechecks the committed destinations before a new round.
// This temporary check input is derived from FileList; it is not task state.
func (dt *DownloadTask) checkMappedTargets() error {
	plan := &pathplan.Plan{Dirs: dt.DirPaths, Files: make([]pathplan.File, 0, len(dt.FileList))}
	for _, file := range dt.FileList {
		plan.Files = append(plan.Files, pathplan.File{Src: file.ObjectKey, Dst: file.FullPath, Size: file.Size})
	}
	return pathplan.CheckLocalTargets(dt.ctx, plan)
}

func (dt *DownloadTask) createMappedDirectories() error {
	for _, d := range dt.DirPaths {
		if err := dt.ctx.Err(); err != nil {
			return err
		}
		if err := os.MkdirAll(d, 0755); err != nil {
			return clienterror.New(clienterror.CodeLocalPathInvalid, "cannot create local directory: "+d, err)
		}
	}
	for _, f := range dt.FileList {
		if err := dt.ctx.Err(); err != nil {
			return err
		}
		if err := os.MkdirAll(filepath.Dir(f.FullPath), 0755); err != nil {
			return clienterror.New(clienterror.CodeLocalPathInvalid, "cannot create local parent", err)
		}
	}
	return nil
}

func (dt *DownloadTask) checkTransferTargets() error {
	if len(dt.pathMappings) == 0 {
		return checkTargetDirAvailable(dt.TargetDir, dt.TotalSize.Load())
	}

	// Include every copy in its volume's aggregate requirement. Checking each
	// mapping separately would undercount copies that share the same disk.
	type volumeUsage struct {
		dir   string
		bytes int64
	}
	volumes := map[string]volumeUsage{}
	dirVolumes := map[string]string{}
	for _, f := range dt.FileList {
		if err := dt.ctx.Err(); err != nil {
			return err
		}
		dir := filepath.Dir(f.FullPath)
		id, ok := dirVolumes[dir]
		if !ok {
			var err error
			id, err = localfs.FilesystemID(dir)
			if err != nil {
				return clienterror.New(clienterror.CodeLocalPathInvalid, "cannot inspect destination filesystem", err)
			}
			dirVolumes[dir] = id
			if err := checkTargetDirAvailable(dir, 0); err != nil {
				return err
			}
		}
		usage := volumes[id]
		usage.dir = dir
		usage.bytes += f.Size
		volumes[id] = usage
	}
	for _, usage := range volumes {
		if err := dt.ctx.Err(); err != nil {
			return err
		}
		if err := checkTargetDirAvailable(usage.dir, usage.bytes); err != nil {
			return err
		}
	}
	return nil
}
