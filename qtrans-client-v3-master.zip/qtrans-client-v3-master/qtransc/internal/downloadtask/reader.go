package downloadtask

import (
	"io"
)

// chunkReader 包装一个 Reader 并使用 atomic 操作统计读取的字节数
// 同时边接收边计算 xxh3-128 校验和
type chunkReader struct {
	reader io.Reader
	onRead func(int64)
}

// NewChunkReader 创建一个新的 chunkReader，支持边接收边计算 xxh3-128 校验和
func NewChunkReader(reader io.Reader, onRead func(int64)) *chunkReader {
	return &chunkReader{
		reader: reader,
		onRead: onRead,
	}
}

func (cr *chunkReader) Read(p []byte) (n int, err error) {
	n, err = cr.reader.Read(p)
	if n > 0 && cr.onRead != nil {
		cr.onRead(int64(n))
	}

	return n, err
}
