package downloadtask

import (
	"context"
	"errors"
	"io/fs"

	"qtransc/internal/clienterror"
	"qtransc/internal/pathplan"
	"qtransc/internal/types"
)

func (dt *DownloadTask) mappedFile(f pathplan.File) *FileInfo {
	fi := NewFileInfo(dt, f.Dst, f.Src)
	fi.FullPath = f.Dst
	fi.ProgressPath = pathplan.ProgressPath(f)
	fi.Size = f.Size
	return fi
}

// preparePathMappings expands input once and atomically publishes the result.
// Later rounds keep FileList and DirPaths and skip source enumeration.
func (dt *DownloadTask) preparePathMappings() error {
	if dt.pathMappingsExpanded {
		return nil
	}
	// RemoteSource owns the bounded per-expansion cache. The existing browse
	// adapter receives a temporary cache to avoid retaining a second copy.
	remote := &pathplan.RemoteSource{Logger: dt.logger, Browse: func(ctx context.Context, p string) ([]types.DownloadBrowseEntry, error) {
		entries, err := dt.browseEntries(make(map[string][]types.DownloadBrowseEntry), p)
		if errors.Is(err, ErrPlanning) {
			return nil, pathplan.Invalid("remote source planning failed: %v", err)
		}
		if errors.Is(err, ErrRemoteNotFound) {
			return nil, fs.ErrNotExist
		}
		return entries, err
	}}
	plan, err := pathplan.Build(dt.ctx, dt.pathMappings, remote, true, dt.maxFileBytes)
	if errors.Is(err, fs.ErrNotExist) {
		return clienterror.New("NOT_FOUND", "remote source not found", err)
	}
	if err != nil {
		return err
	}
	if err := pathplan.CheckLocalTargets(dt.ctx, plan); err != nil {
		return err
	}
	files := make([]*FileInfo, 0, len(plan.Files))
	for _, f := range plan.Files {
		files = append(files, dt.mappedFile(f))
	}
	dt.mu.Lock()
	defer dt.mu.Unlock()
	if err := dt.ctx.Err(); err != nil {
		return err
	}
	dt.FileList = files
	dt.DirPaths = plan.Dirs
	dt.pathMappingsExpanded = true
	return nil
}
