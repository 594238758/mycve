package downloadtask

import (
	"context"
	"errors"
	"qtransc/internal/clienterror"
	"qtransc/internal/types"
	"time"
)

// recordFinalError is called only once a file's own retry policy has ended.
func (dt *DownloadTask) recordFinalError(err error) {
	if err == nil || errors.Is(err, context.Canceled) {
		return
	}
	dt.mu.Lock()
	defer dt.mu.Unlock()

	if dt.finalErr == nil {
		dt.finalErr = clienterror.Normalize(err)
	}
}

func (dt *DownloadTask) finishExecution(err error, completed bool) error {
	dt.mu.Lock()
	defer dt.mu.Unlock()
	return dt.finishExecutionLocked(err, completed)
}

func (dt *DownloadTask) finishExecutionLocked(err error, completed bool) error {
	if dt.Status != types.StatusPending && dt.Status != types.StatusRunning {
		return nil
	}

	if err != nil && !errors.Is(err, context.Canceled) && dt.finalErr == nil {
		dt.finalErr = clienterror.Normalize(err)
	}
	dt.FinishedAt = time.Now()
	if dt.finalErr != nil {
		dt.setError(dt.finalErr)
		if transitionErr := dt.transitionTo(types.StatusFailed); transitionErr != nil {
			return transitionErr
		}
		return dt.Err
	}
	if dt.stopRequested {
		dt.Err = nil
		return dt.transitionTo(types.StatusStopped)
	}
	if err == nil && completed {
		dt.Err = nil
		return dt.transitionTo(types.StatusCompleted)
	}
	if err == nil {
		err = errors.New("task execution ended before all files completed")
	}
	dt.finalErr = clienterror.Normalize(err)
	dt.setError(dt.finalErr)
	if transitionErr := dt.transitionTo(types.StatusFailed); transitionErr != nil {
		return transitionErr
	}
	return dt.Err
}
