package downloadtask

import (
	"strings"

	"qtransc/internal/pathplan"
	"qtransc/internal/transferlimits"
	"qtransc/internal/types"
)

// refreshFileMetadata refreshes only the fixed files selected for this round.
// It never browses directories or changes their source/destination mappings.
func (dt *DownloadTask) refreshFileMetadata(files []*FileInfo) ([]*FileInfo, error) {
	refreshed := make([]*FileInfo, 0, len(files))
	for _, batch := range chunkFileInfos(files, 1000) {
		granted, err := dt.authorizeSelections(batch)
		if err != nil {
			return nil, err
		}
		for _, file := range granted {
			if err := transferlimits.ValidateFileSize(file.Size, dt.maxFileBytes); err != nil {
				return nil, err
			}
		}
		refreshed = append(refreshed, granted...)
	}
	if _, err := sumFileSizes(refreshed); err != nil {
		return nil, err
	}
	return refreshed, nil
}

// materializeMappedFiles joins grants by source while preserving each
// selected destination as an independent download record.
func (dt *DownloadTask) materializeMappedFiles(selections []*FileInfo, response []types.DownloadGrantFileResponse) ([]*FileInfo, error) {
	byKey := map[string]types.DownloadGrantFileResponse{}
	wanted := map[string]bool{}
	for _, f := range selections {
		wanted[f.ObjectKey] = true
	}
	for _, r := range response {
		if !wanted[r.ObjectKey] || strings.TrimSpace(r.Grant) == "" || r.Size < 0 {
			return nil, pathplan.Invalid("invalid grant response for %q", r.ObjectKey)
		}
		if _, ok := byKey[r.ObjectKey]; ok {
			return nil, pathplan.Invalid("duplicate grant response for %q", r.ObjectKey)
		}
		byKey[r.ObjectKey] = r
	}
	files := make([]*FileInfo, 0, len(selections))
	for _, s := range selections {
		r, ok := byKey[s.ObjectKey]
		if !ok {
			return nil, pathplan.Invalid("missing grant for %q", s.ObjectKey)
		}
		f := s.newRunFile()
		f.Size = r.Size
		f.Grant = r.Grant
		f.Authorized = true
		files = append(files, f)
	}
	return files, nil
}
