package downloadtask

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"qtransc/internal/average"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/transferretry"
	"qtransc/internal/types"
	"qtransc/internal/version"
	"runtime"
	"strconv"
	"sync/atomic"
	"time"

	"github.com/zeebo/xxh3"
)

const (
	// 分片状态：未开始
	ChunkStatusNotStarted = "not_started"
	// 分片状态：进行中
	ChunkStatusInProgress = "in_progress"
	// 分片状态：已完成
	ChunkStatusCompleted = "completed"
	// 分片状态：失败
	ChunkStatusFailed = "failed"
	//

	FileStatusNotStarted   = "not_started"
	FileStatusInProgress   = "in_progress"
	FileStatusCompleted    = "completed"
	FileStatusFailed       = "failed"
	FileStatusVerifying    = "verifyed"
	FileStatusAuthorized   = "authorized"
	FileStatusUnauthorized = "unauthorized"
)

type ChunkInfo struct {
	fi      *FileInfo    `json:"-"` // 所属文件信息
	hasher  *xxh3.Hasher `json:"-"` // 分片哈希计算器
	logger  *slog.Logger `json:"-"` // 分片日志记录器
	LastErr error        `json:"-"` // 分片错误信息

	Index               int          `json:"index"`             // 分片索引，从0开始
	StartOffset         int64        `json:"start_offset"`      // 分片起始偏移
	EndOffset           int64        `json:"end_offset"`        // 分片结束偏移
	Transferred         int64        `json:"transferred_bytes"` // 已传输的字节数
	NetworkReceived     int64        `json:"-"`
	Checksum            string       `json:"checksum"`  // 分片校验和
	ChunkSize           int64        `json:"size"`      // 分片大小，单位字节
	Completed           bool         `json:"completed"` // 分片是否已完成
	lastNetworkReceived int64        `json:"-"`
	Rate                int64        `json:"-"`
	rateAverage         *average.SMA `json:"-"`
	Active              atomic.Bool  `json:"-"`
}

type downloadGrantErrorResponse struct {
	Message    string `json:"message"`
	ReasonCode string `json:"reason_code,omitempty"`
}

func NewChunkInfo(fi *FileInfo, index int, startOffset, endOffset int64) *ChunkInfo {
	return &ChunkInfo{
		fi:          fi,
		logger:      nil,
		Index:       index,
		StartOffset: startOffset,
		EndOffset:   endOffset,
		ChunkSize:   endOffset - startOffset + 1,
		Transferred: 0,
		Checksum:    "",
		Completed:   false,
		rateAverage: average.NewSMA(20),
	}
}

func (chunk *ChunkInfo) publishStatus(status string) {
	if chunk == nil || chunk.fi == nil || chunk.fi.dt == nil || chunk.fi.dt.publisher == nil {
		return
	}
	chunk.fi.dt.publisher.Publish(types.NewChunkStatusEvent(
		chunk.fi.dt.TaskID,
		chunk.fi.eventFileKey(),
		chunk.Index,
		status,
	))
}

func (chunk *ChunkInfo) sampleTransferRate(elapsed time.Duration) {
	if chunk == nil || elapsed <= 0 {
		return
	}
	current := atomic.LoadInt64(&chunk.NetworkReceived)
	delta := current - chunk.lastNetworkReceived
	if delta < 0 {
		delta = 0
	}
	if chunk.rateAverage == nil {
		chunk.rateAverage = average.NewSMA(20)
	}
	atomic.StoreInt64(&chunk.Rate, int64(chunk.rateAverage.Update(float64(delta)/elapsed.Seconds())))
	chunk.lastNetworkReceived = current
}

// 下载策略
type chunkDownloadStrategy int

const (
	ChunkVerify  chunkDownloadStrategy = iota // 跳过下载（文件完整）
	ChunkResume                               // 断点续传
	ChunkRestart                              // 重新下载
)

// 决定分片的下载策略
func (chunk *ChunkInfo) determineDownloadStrategy() chunkDownloadStrategy {
	// 检查分片是否已完整下载
	if chunk.Transferred == chunk.ChunkSize {
		return ChunkVerify
	}

	// 检查是否有部分进度可以恢复
	if chunk.Transferred > 0 && chunk.Transferred < chunk.ChunkSize {
		return ChunkResume
	}

	// 默认重新下载
	return ChunkRestart
}

func (chunk *ChunkInfo) init(fi *FileInfo) {
	chunk.fi = fi
	chunk.logger = chunk.fi.logger.With("chunk_index", chunk.Index,
		"chunk_range", fmt.Sprintf("(%d~%d)", chunk.StartOffset, chunk.EndOffset))
	chunk.hasher = xxh3.New()
}

// 计算已下载部分的分片哈希
// 算法: 使用 XXH3-128 对已下载的分片数据进行哈希计算，结果转为十六进制字符串
// 注意: 这是分片级别的哈希，最终文件哈希需通过 genHashByChunkInfo 方法计算
func (chunk *ChunkInfo) loadDownloaded(ctx context.Context) error {
	if ctx == nil {
		ctx = context.Background()
	}
	// 使用 1MB 缓冲区逐块读取已下载数据并计算哈希
	buf := make([]byte, 1024*1024) // 1MB缓冲区
	var totalRead int64 = 0
	for totalRead < chunk.Transferred {
		if err := ctx.Err(); err != nil {
			return err
		}
		toRead := int64(len(buf))
		remaining := chunk.Transferred - totalRead
		if remaining < toRead {
			toRead = remaining
		}
		n, err := chunk.fi.File.ReadAt(buf[:toRead], chunk.StartOffset+totalRead)
		if err != nil && err != io.EOF {
			return fmt.Errorf("读取已下载数据失败: %v", err)
		}
		if n == 0 {
			break
		}
		chunk.hasher.Write(buf[:n])
		totalRead += int64(n)
	}
	if totalRead != chunk.Transferred {
		return fmt.Errorf("读取已下载数据字节数不匹配, 预期: %d, 实际: %d", chunk.Transferred, totalRead)
	} else if chunk.Transferred == chunk.ChunkSize {
		// 计算 XXH3-128 哈希值（16字节二进制）并转为十六进制字符串
		hashBytes := chunk.hasher.Sum128().Bytes()
		chunk.Checksum = hex.EncodeToString(hashBytes[:])
	}
	return nil
}

// 判断分片是否需要下载
// 在没有抢到client前可以做的准备工作, 返回值为是否需要传输
// TODO: 如果已经下载完成,重新计算分片hash,并比对已经缓存的hash,不一致则重新下载.
func (chunk *ChunkInfo) DownloadPrepare(ctx context.Context, fi *FileInfo) (bool, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	chunk.init(fi)

	strategy := chunk.determineDownloadStrategy()
	// 计算已下载部分的hash
	if err := chunk.loadDownloaded(ctx); err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return false, ctxErr
		}
		chunk.logger.Error("计算已下载分片hash失败,准备重新下载", "err", err)
		strategy = ChunkRestart
	}

	switch strategy {
	case ChunkVerify:
		chunk.Completed = true
		chunk.publishStatus(types.ChunkEventStatusCompleted)
		chunk.logger.Debug("分片已完整下载，跳过下载,但计算hash", slog.Any("chunk", chunk))
		return true, nil
	case ChunkResume:
		chunk.logger.Debug("分片支持断点续传,继续下载, 加载已下载部分hash", slog.Any("chunk", chunk))
		return false, nil
	case ChunkRestart:
		chunk.resetTransferred()
		chunk.logger.Debug("分片需要重新下载", slog.Any("chunk", chunk))
		return false, nil
	default:
		chunk.logger.Error("未知的分片下载策略")
		return false, fmt.Errorf("未知的分片下载策略: %d", strategy)
	}
}

func (chunk *ChunkInfo) resolveDownloadURL() (string, error) {
	downloadURL, err := qtserverurl.BuildDownloadURL(chunk.fi.dt.ServerAddr, chunk.fi.ObjectKey, chunk.fi.Grant)
	if err != nil {
		return "", err
	}
	if downloadURL == "" {
		return "", fmt.Errorf("download URL is empty for file %s", chunk.fi.LocalPath)
	}
	return downloadURL, nil
}

func (chunk *ChunkInfo) acquireDownloadClient(ctx context.Context) (string, *http.Client, func(), error) {
	downloadURL, err := chunk.resolveDownloadURL()
	if err != nil {
		return "", nil, nil, err
	}
	client, releaseClient, err := chunk.fi.dt.acquireClient(ctx, downloadURL)
	if err != nil {
		return "", nil, nil, err
	}
	return downloadURL, client, releaseClient, nil
}

func (chunk *ChunkInfo) downloadRun(ctx context.Context, downloadURL string, client *http.Client, bearerToken string, includeMetadata bool, onResponseHeaders func()) (bool, error) {
	// 计算实际需要下载的起始位置（支持断点续传）
	transferred := atomic.LoadInt64(&chunk.Transferred)
	actualStartOffset := chunk.StartOffset + transferred

	// 如果分片已完整下载，直接返回
	if transferred == chunk.ChunkSize {
		chunk.logger.Error("unexpected: chunk already completed before download")
		return false, fmt.Errorf("chunk already completed before download")
	} else if transferred > chunk.ChunkSize {
		return false, fmt.Errorf("chunk transferred bytes exceed chunk size")
	}

	req, err := http.NewRequestWithContext(ctx, "GET", downloadURL, nil)
	if err != nil {
		chunk.LastErr = err
		return false, err
	}

	// 请求剩余未下载的部分
	req.Header.Set("Range", fmt.Sprintf("bytes=%d-%d", actualStartOffset, chunk.EndOffset))

	// 标记客户端
	if includeMetadata {
		clientID, err := version.CurrentClientID()
		if err != nil {
			return false, fmt.Errorf("load client id: %w", err)
		}
		req.Header.Set("Client-ID", clientID)
		req.Header.Set("Client-OS", runtime.GOOS)
		req.Header.Set("Client-Version", version.Version)
		req.Header.Set("Caller-Version", chunk.fi.dt.CallerVersion)
	}
	qtserverapi.SetTaskCorrelationHeaders(req.Header, chunk.fi.dt.taskCorrelation())
	req.Header.Set("X-QT-Chunk-Index", strconv.Itoa(chunk.Index))

	// 用户下载需要携带 Bearer token
	setBearerAuthorizationHeader(req, bearerToken)

	resp, err := client.Do(req)
	if err != nil {
		chunk.LastErr = fmt.Errorf("download chunk request: %w", err)
		return false, chunk.LastErr
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusPartialContent {
		body, _ := io.ReadAll(resp.Body)
		httpErr := buildDownloadHTTPError(resp.StatusCode, resp.Header, body)
		switch {
		case isHTTPAuthorizationFailure(resp.StatusCode):
			chunk.LastErr = chunk.fi.dt.authFailedErr(httpErr, bearerToken, resp.StatusCode)
		case isDownloadGrantExpiredResponse(resp.StatusCode, body):
			chunk.LastErr = markDownloadGrantExpiredError(httpErr)
		case resp.StatusCode == http.StatusOK && resp.Header.Get("X-Accel-Redirect") != "":
			chunk.LastErr = markPermanentDownloadError(fmt.Errorf("download endpoint returned X-Accel-Redirect; use the nginx/public endpoint instead of the qtserver backend"))
		case resp.StatusCode == http.StatusOK:
			chunk.LastErr = markPermanentDownloadError(fmt.Errorf("range download requires HTTP 206 but got 200; target endpoint does not support ranged data access"))
		case resp.StatusCode >= http.StatusBadRequest && resp.StatusCode < http.StatusInternalServerError &&
			resp.StatusCode != http.StatusRequestTimeout && resp.StatusCode != http.StatusTooManyRequests:
			chunk.LastErr = markPermanentDownloadError(httpErr)
		default:
			chunk.LastErr = httpErr
		}
		return false, chunk.LastErr
	}
	responseHeadersAccepted := true
	if onResponseHeaders != nil {
		onResponseHeaders()
	}

	limitedBody := chunk.fi.dt.wrapRateLimitedReader(ctx, resp.Body)

	// 创建一个计数器 reader 来统计传输的字节数
	cr := NewChunkReader(limitedBody, chunk.addPayloadBytes)

	// 创建带缓冲的 writer，从实际需要写入的位置开始
	// 使用 1MB 缓冲区减少系统调用
	ow := NewOffsetWriter(chunk.fi.File, actualStartOffset, 1024*1024, &chunk.Checksum, chunk.hasher)

	// 直接拷贝数据：resp.Body -> counter -> bufferedWriter
	// _, err = io.Copy(ow, cr)
	readBuf := make([]byte, 8*1024*1024)
	_, err = io.CopyBuffer(ow, cr, readBuf)

	if owErr := ow.Close(); owErr != nil {
		chunk.LastErr = fmt.Errorf("close offset writer: %w", owErr)
		return responseHeadersAccepted, chunk.LastErr
	}
	if err != nil {
		chunk.LastErr = fmt.Errorf("copy download chunk: %w", err)
		// 检查是否是因为 context 取消导致的错误
		switch {
		case errors.Is(ctx.Err(), context.Canceled):
			chunk.logger.Debug("分片下载取消(context canceled)", slog.Any("chunk", chunk))
			return responseHeadersAccepted, context.Canceled
		case errors.Is(err, HasherError):
			return responseHeadersAccepted, fmt.Errorf("hash计算发生异常: %w", err)
		default:
			return responseHeadersAccepted, chunk.LastErr
		}
	}
	transferred = atomic.LoadInt64(&chunk.Transferred)
	if chunk.ChunkSize != transferred {
		chunk.LastErr = fmt.Errorf("分片下载失败，传输字节数不匹配, ChunkSize: %d, Transferred: %d: %w",
			chunk.ChunkSize, transferred, io.ErrUnexpectedEOF)
		return responseHeadersAccepted, chunk.LastErr
	}
	return responseHeadersAccepted, nil
}

func shouldRetryDownloadChunkTransportError(err error) bool {
	return transferretry.IsAvailabilityError(context.Background(), err)
}

func shouldRetryDownloadChunkHTTPError(err error) bool {
	var apiErr *qtserverapi.APIError
	return errors.As(err, &apiErr) && transferretry.IsAvailabilityStatus(apiErr.Status)
}

func shouldRetryDownloadChunkError(err error) bool {
	return shouldRetryDownloadChunkTransportError(err) || shouldRetryDownloadChunkHTTPError(err)
}

func (chunk *ChunkInfo) Download(ctx context.Context, register bool, registered func()) error {
	if ctx == nil {
		ctx = chunk.fi.ctx
	}
	if ctx == nil {
		ctx = context.Background()
	}
	chunk.logger.Debug("开始分片下载", slog.Any("chunk", chunk))
	if chunk.Completed {
		return nil
	}
	chunk.publishStatus(types.ChunkEventStatusStarted)
	chunk.Active.Store(true)
	chunk.fi.activeChunks.Store(chunk.Index, chunk)
	finalProgressPublished := false
	defer func() {
		if !finalProgressPublished {
			chunk.publishProgress()
		}
		chunk.fi.activeChunks.Delete(chunk.Index)
		chunk.Active.Store(false)
		atomic.StoreInt64(&chunk.Rate, 0)
	}()

	authRetryCount := 0
	retryCount := 0
	fallbackRetryCount := 0
	var http500Budget transferretry.HTTP500Budget
	backoff := transferretry.NewBackoff()
	var lastRetryErr error
	includeMetadata := register && !chunk.fi.logRegistrationConfirmed.Load()
	confirmRegistration := func() {
		if !includeMetadata {
			return
		}
		chunk.fi.logRegistrationConfirmed.Store(true)
		includeMetadata = false
		if registered != nil {
			registered()
		}
	}
	// 如果是分片下载失败,继续重试
	for {
		if err := ctx.Err(); err != nil {
			if errors.Is(err, context.Canceled) {
				chunk.logger.Debug("分片下载取消(context canceled)", slog.Any("chunk", chunk))
				return err
			}
			return err
		}

		bearerToken := ""
		downloadURL, client, releaseClient, err := chunk.acquireDownloadClient(ctx)
		if err != nil {
			chunk.LastErr = err
		} else {
			if chunk.fi.dt.downloadUser() == types.DownloadUserSelf {
				bearerToken, err = chunk.fi.dt.currentBearerToken()
				if err != nil {
					releaseClient()
					chunk.LastErr = err
				} else {
					accepted, runErr := chunk.downloadRun(ctx, downloadURL, client, bearerToken, includeMetadata, confirmRegistration)
					if accepted && includeMetadata {
						chunk.fi.logRegistrationConfirmed.Store(true)
						includeMetadata = false
					}
					chunk.LastErr = runErr
					releaseClient()
				}
			} else {
				accepted, runErr := chunk.downloadRun(ctx, downloadURL, client, bearerToken, includeMetadata, confirmRegistration)
				if accepted && includeMetadata {
					chunk.fi.logRegistrationConfirmed.Store(true)
					includeMetadata = false
				}
				chunk.LastErr = runErr
				releaseClient()
			}
		}
		if chunk.LastErr != nil {
			if errors.Is(chunk.LastErr, context.Canceled) || errors.Is(ctx.Err(), context.Canceled) {
				chunk.logger.Debug("分片下载取消(context canceled)", slog.Any("chunk", chunk))
				return context.Canceled
			}
			if errors.Is(chunk.LastErr, ErrAuthFailed) {
				if authRetryCount < downloadAuthRetryMaxRefreshes && chunk.fi.dt.refreshAuthorizationAfter401(ctx, authorizationFailureStatus(chunk.LastErr)) {
					authRetryCount++
					continue
				}
				chunk.logger.Error("分片下载鉴权失败", "err", chunk.LastErr)
				return chunk.LastErr
			}
			if isDownloadGrantExpiredError(chunk.LastErr) {
				chunk.logger.Debug("分片下载授权已过期，等待文件级重新申请")
				return chunk.LastErr
			}
			if isPermanentDownloadError(chunk.LastErr) {
				chunk.logger.Error("分片下载失败，错误不可重试", "err", chunk.LastErr)
				return chunk.LastErr
			}

			var apiErr *qtserverapi.APIError
			isAPIError := errors.As(chunk.LastErr, &apiErr)
			availabilityFailure := shouldRetryDownloadChunkError(chunk.LastErr)
			switch {
			case isAPIError && apiErr.Status == http.StatusInternalServerError:
				if !http500Budget.Take() {
					chunk.logger.Error("分片下载失败，HTTP 500 已达到重试上限",
						"retry_limit", transferretry.MaxHTTP500Retries,
						"err", chunk.LastErr)
					return chunk.LastErr
				}
			case availabilityFailure:
			case !isAPIError:
				fallbackRetryCount++
				if fallbackRetryCount > downloadChunkFallbackRetryCount {
					chunk.logger.Error("分片下载失败，已达到兜底重试上限",
						"retry_count", fallbackRetryCount-1,
						"fallback_retry_limit", downloadChunkFallbackRetryCount,
						"err", chunk.LastErr)
					return chunk.LastErr
				}
			default:
				return chunk.LastErr
			}

			retryCount++
			lastRetryErr = chunk.LastErr
			var retryHeader http.Header
			if isAPIError {
				retryHeader = apiErr.Header
			}
			delay := backoff.Next(retryHeader, time.Now())
			logArgs := []any{"retry_count", retryCount, "delay", delay.String(), "err", chunk.LastErr}
			if !availabilityFailure && !isAPIError {
				logArgs = append(logArgs, "fallback_retry", true)
			}
			if retryCount == 1 || retryCount%downloadChunkRetryLogInterval == 0 || (!availabilityFailure && !isAPIError) {
				chunk.logger.Warn("分片下载出错，准备重试", logArgs...)
			} else {
				chunk.logger.Debug("分片下载出错，准备重试", logArgs...)
			}
			chunk.publishStatus(types.ChunkEventStatusRetried)
			if waitErr := transferretry.Wait(ctx, delay); waitErr != nil {
				chunk.logger.Debug("分片下载取消(context canceled)", slog.Any("chunk", chunk))
				return waitErr
			}
			continue
		}

		if retryCount > 0 {
			chunk.logger.Info("分片下载重试后恢复",
				"retries", retryCount,
				"last_error", lastRetryErr)
		}

		chunk.logger.Debug("分片下载完成", slog.Any("chunk", chunk))
		chunk.Completed = true
		chunk.publishProgress()
		finalProgressPublished = true
		chunk.publishStatus(types.ChunkEventStatusCompleted)

		return nil
		// TODO: chunk verify ???

	}
}

// publishProgress 发布当前分片的进度快照事件。
func (chunk *ChunkInfo) publishProgress() {
	if chunk.fi == nil || chunk.fi.dt == nil || chunk.fi.dt.publisher == nil {
		return
	}
	chunk.fi.dt.publisher.Publish(types.NewChunkProgressEvent(
		chunk.fi.dt.TaskID,
		chunk.fi.eventFileKey(),
		chunk.Index,
		chunk.ChunkSize,
		atomic.LoadInt64(&chunk.Transferred),
		atomic.LoadInt64(&chunk.Rate),
	))
}

func buildDownloadHTTPError(statusCode int, header http.Header, body []byte) error {
	var payload downloadGrantErrorResponse
	_ = json.Unmarshal(body, &payload)
	return &qtserverapi.APIError{
		Status:     statusCode,
		ReasonCode: payload.ReasonCode,
		Message:    payload.Message,
		Body:       body,
		Header:     header.Clone(),
	}
}

func isDownloadGrantExpiredResponse(statusCode int, body []byte) bool {
	if statusCode == http.StatusGone {
		return true
	}
	var payload downloadGrantErrorResponse
	if err := json.Unmarshal(body, &payload); err == nil {
		if payload.ReasonCode == "GRANT_EXPIRED" {
			return true
		}
	}
	return false
}

func (chunk *ChunkInfo) AddTransferred(n int64) {
	chunk.addPayloadBytes(n)
}

func (chunk *ChunkInfo) RestoreTransferred(n int64) {
	if n <= 0 {
		return
	}
	delta := addBoundedDownloadInt64(&chunk.Transferred, n, chunk.ChunkSize)
	chunk.fi.addTransferred(delta)
}

func (chunk *ChunkInfo) resetTransferred() {
	transferred := atomic.SwapInt64(&chunk.Transferred, 0)
	chunk.fi.addTransferred(-transferred)
}

func (chunk *ChunkInfo) addPayloadBytes(bytes int64) {
	if chunk == nil || chunk.fi == nil || bytes <= 0 {
		return
	}
	atomic.AddInt64(&chunk.NetworkReceived, bytes)
	chunk.fi.addNetworkReceived(bytes)
	delta := addBoundedDownloadInt64(&chunk.Transferred, bytes, chunk.ChunkSize)
	chunk.fi.addTransferred(delta)
}

// ToChunkInfoDetail converts a task chunk to API view.
func (chunk *ChunkInfo) ToChunkInfoDetail() *types.ChunkInfoDetail {
	return &types.ChunkInfoDetail{
		Index:       chunk.Index,
		StartOffset: chunk.StartOffset,
		EndOffset:   chunk.EndOffset,
		Transferred: atomic.LoadInt64(&chunk.Transferred),
		ChunkSize:   chunk.ChunkSize,
		Completed:   chunk.Completed,
	}
}
