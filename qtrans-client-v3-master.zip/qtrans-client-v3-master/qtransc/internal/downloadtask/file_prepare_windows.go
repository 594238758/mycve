//go:build windows

package downloadtask

import (
	"os"

	"qtransc/internal/transferretry"

	"golang.org/x/sys/windows"
)

// prepareLocalFile avoids zero-filling unwritten gaps during out-of-order writes.
// It runs before chunk I/O and must preserve existing bytes when resuming.
func (fi *FileInfo) prepareLocalFile(file *os.File) error {
	raw, err := file.SyscallConn()
	if err != nil {
		return transferretry.WrapLocalIO("access download target handle", err)
	}

	var sparseErr error
	err = raw.Control(func(fd uintptr) {
		var returned uint32
		sparseErr = windows.DeviceIoControl(windows.Handle(fd), windows.FSCTL_SET_SPARSE,
			nil, 0, nil, 0, &returned, nil)
	})
	if err != nil {
		return transferretry.WrapLocalIO("access download target handle", err)
	}
	if sparseErr != nil {
		fi.logger.Warn("无法启用稀疏文件，使用普通文件写入", "path", file.Name(), "err", sparseErr)
		return nil
	}

	// Set EOF only after enabling sparse storage. This does not count as progress
	// and does not clear already downloaded ranges, unlike Truncate(0).
	if err := file.Truncate(fi.Size); err != nil {
		return transferretry.WrapLocalIO("set sparse download target size", err)
	}
	fi.logger.Debug("已准备稀疏下载文件", "path", file.Name(), "logical_size", fi.Size)
	return nil
}
