package downloadtask

import (
	"encoding/json"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/url"
	"os"
	"path"
	"path/filepath"
	"qtransc/internal/clienterror"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/transferlimits"
	"qtransc/internal/types"
	"sort"
	"strings"
)

type expandedFileSelection struct {
	ObjectKey string
	Size      int64
}

type mappedLocalDirectory struct {
	LocalPath string
	ObjectKey string
}

func (dt *DownloadTask) downloadUser() types.DownloadUser {
	if dt.downloadUserMode == types.DownloadUserSelf {
		return types.DownloadUserSelf
	}
	return types.DownloadUserAnonymous
}

func buildDownloadBrowseURL(serverURL string, user types.DownloadUser, path string) (string, error) {
	requestTarget, err := qtserverurl.JoinEndpoint(serverURL, "/files/list")
	if err != nil {
		return "", err
	}
	parsed, err := url.Parse(requestTarget)
	if err != nil {
		return "", fmt.Errorf("invalid server URL %q: %w", serverURL, err)
	}
	query := parsed.Query()
	query.Set("path", path)
	parsed.RawQuery = query.Encode()
	return parsed.String(), nil
}

func (dt *DownloadTask) browseEntries(cache map[string][]types.DownloadBrowseEntry, path string) ([]types.DownloadBrowseEntry, error) {
	if entries, ok := cache[path]; ok {
		return entries, nil
	}
	reqCtx := dt.requestContext()
	authRetryCount := 0
	retryState := newDownloadControlRetryState()
	var lastTransportErr error

	for {
		requestURL, err := buildDownloadBrowseURL(dt.ServerAddr, dt.downloadUser(), path)
		if err != nil {
			return nil, err
		}

		req, err := http.NewRequestWithContext(reqCtx, http.MethodGet, requestURL, nil)
		if err != nil {
			return nil, fmt.Errorf("create browse request: %w", err)
		}

		client, releaseClient, err := dt.acquireClient(reqCtx, req.URL.String())
		if err != nil {
			return nil, err
		}
		usedToken := ""
		if dt.downloadUser() == types.DownloadUserSelf {
			usedToken, err = dt.currentBearerToken()
			if err != nil {
				releaseClient()
				return nil, err
			}
			setBearerAuthorizationHeader(req, usedToken)
		}
		qtserverapi.SetTaskCorrelationHeaders(req.Header, dt.taskCorrelation())

		resp, err := client.Do(req)
		if err != nil {
			releaseClient()
			requestErr := fmt.Errorf("browse request failed for %q: %w", path, err)
			retry, waitErr := retryDownloadControlTransport(reqCtx, dt.logger, "browse download entries", &retryState, requestErr)
			if waitErr != nil {
				return nil, waitErr
			}
			if retry {
				lastTransportErr = requestErr
				continue
			}
			return nil, requestErr
		}
		logDownloadControlTransportRecovered(dt.logger, "browse download entries", retryState, lastTransportErr)

		body, err := io.ReadAll(resp.Body)
		_ = resp.Body.Close()
		releaseClient()
		if err != nil {
			requestErr := fmt.Errorf("read browse response for %q: %w", path, err)
			retry, waitErr := retryDownloadControlTransport(reqCtx, dt.logger, "browse download entries", &retryState, requestErr)
			if waitErr != nil {
				return nil, waitErr
			}
			if retry {
				lastTransportErr = requestErr
				continue
			}
			return nil, requestErr
		}
		if resp.StatusCode != http.StatusOK {
			if resp.StatusCode == http.StatusNotFound {
				dt.logger.Warn("remote download path not found", "object_key", path)
				return nil, ErrRemoteNotFound
			}
			if retry, waitErr := retryDownloadControlHTTP(reqCtx, &retryState, resp.StatusCode, resp.Header); waitErr != nil {
				return nil, waitErr
			} else if retry {
				continue
			}
			browseErr := fmt.Errorf("browse failed for %q: status=%d body=%s", path, resp.StatusCode, strings.TrimSpace(string(body)))
			if isHTTPAuthorizationFailure(resp.StatusCode) {
				if authRetryCount < downloadAuthRetryMaxRefreshes && dt.refreshAuthorizationAfter401(reqCtx, resp.StatusCode) {
					authRetryCount++
					continue
				}
				return nil, dt.authFailedErr(browseErr, usedToken, resp.StatusCode)
			}
			if len(dt.pathMappings) > 0 {
				var envelope struct {
					ReasonCode string `json:"reason_code"`
					Message    string `json:"message"`
				}
				_ = json.Unmarshal(body, &envelope)
				return nil, &qtserverapi.APIError{Status: resp.StatusCode, ReasonCode: envelope.ReasonCode, Message: envelope.Message}
			}
			return nil, browseErr
		}

		var browseResp types.DownloadBrowseResponse
		if err := json.Unmarshal(body, &browseResp); err != nil {
			return nil, fmt.Errorf("decode browse response for %q: %w", path, err)
		}
		if browseResp.Truncated {
			return nil, fmt.Errorf("%w: 目录超过10万条目，无法启动任务: %q", ErrPlanning, path)
		}
		cache[path] = browseResp.Entries
		return browseResp.Entries, nil
	}
}

func parentObjectKey(objectKey string) string {
	index := strings.LastIndex(objectKey, "/")
	if index <= 0 {
		return "/"
	}
	return objectKey[:index]
}

func (dt *DownloadTask) resolveSelectedBrowseEntry(cache map[string][]types.DownloadBrowseEntry, objectKey string) (types.DownloadBrowseEntry, error) {
	parent := parentObjectKey(objectKey)
	entries, err := dt.browseEntries(cache, parent)
	if err != nil {
		return types.DownloadBrowseEntry{}, err
	}
	for _, entry := range entries {
		if entry.ObjectKey() == objectKey {
			return entry, nil
		}
	}
	dt.logger.Warn("remote download selection not found", "object_key", objectKey)
	return types.DownloadBrowseEntry{}, ErrRemoteNotFound
}

func (dt *DownloadTask) collectDirectoryFiles(
	cache map[string][]types.DownloadBrowseEntry,
	objectKey string,
	depth int,
	files map[string]expandedFileSelection,
	dirs map[string]bool,
	entryCount *int,
) error {
	if depth > downloadBrowseMaxDepth {
		return fmt.Errorf("%w: browse expansion exceeded max depth at %q", ErrPlanning, objectKey)
	}

	entries, err := dt.browseEntries(cache, objectKey)
	if err != nil {
		return err
	}
	if len(entries) == 0 {
		// 空目录 — 记录以便在本地创建
		dirs[objectKey] = true
		return nil
	}
	for _, entry := range entries {
		*entryCount++
		if *entryCount > downloadBrowseMaxEntries {
			return fmt.Errorf("%w: download planning exceeds %d total entries", ErrPlanning, downloadBrowseMaxEntries)
		}
		entryType := entry.TransferType()
		if entry.Status != "normal" || entryType == "special" || entryType == "unknown" {
			dt.logger.Warn("skipped unsupported remote entry", "path", entry.Path, "type", entry.EntryType, "status", entry.Status, "reason_code", entry.ReasonCode)
			continue
		}
		switch entryType {
		case types.DownloadBrowseEntryFile:
			if _, ok := files[entry.ObjectKey()]; !ok {
				if len(files) >= downloadBrowseMaxFiles {
					return fmt.Errorf("%w: %w", ErrPlanning, transferlimits.TaskFileLimitExceeded(len(files)+1))
				}
				if err := transferlimits.ValidateFileSize(entry.Size, dt.maxFileBytes); err != nil {
					return err
				}
				files[entry.ObjectKey()] = expandedFileSelection{
					ObjectKey: entry.ObjectKey(),
					Size:      entry.Size,
				}
			}
		case types.DownloadBrowseEntryDirectory:
			if err := dt.collectDirectoryFiles(cache, entry.ObjectKey(), depth+1, files, dirs, entryCount); err != nil {
				return err
			}
		}
	}
	// 经过递归后，如果该目录下所有子目录也都是空的，该目录本身也应保留
	// 检查该目录下是否没有任何文件被收集
	prefix := objectKey + "/"
	hasFiles := false
	for key := range files {
		if strings.HasPrefix(key, prefix) {
			hasFiles = true
			break
		}
	}
	if !hasFiles {
		dirs[objectKey] = true
	}
	return nil
}

func (dt *DownloadTask) expandSelectionsViaBrowse(selections []*FileInfo) ([]*FileInfo, error) {
	cache := make(map[string][]types.DownloadBrowseEntry)
	expanded := make(map[string]expandedFileSelection)
	dirs := make(map[string]bool)
	entryCount := 0

	for _, selection := range selections {
		if selection == nil {
			continue
		}
		entry, err := dt.resolveSelectedBrowseEntry(cache, selection.ObjectKey)
		if err != nil {
			return nil, err
		}
		entryCount++
		if entryCount > downloadBrowseMaxEntries {
			return nil, fmt.Errorf("%w: download planning exceeds %d total entries", ErrPlanning, downloadBrowseMaxEntries)
		}
		entryType := entry.TransferType()
		if entry.Status != "normal" || entryType == "special" || entryType == "unknown" {
			return nil, fmt.Errorf("%w: download selection %q is not transferable: type=%s status=%s reason=%s", ErrPlanning, selection.ObjectKey, entry.EntryType, entry.Status, entry.ReasonCode)
		}
		switch entryType {
		case types.DownloadBrowseEntryFile:
			if _, ok := expanded[entry.ObjectKey()]; !ok {
				if len(expanded) >= downloadBrowseMaxFiles {
					return nil, fmt.Errorf("%w: %w", ErrPlanning, transferlimits.TaskFileLimitExceeded(len(expanded)+1))
				}
				if err := transferlimits.ValidateFileSize(entry.Size, dt.maxFileBytes); err != nil {
					return nil, err
				}
				expanded[entry.ObjectKey()] = expandedFileSelection{
					ObjectKey: entry.ObjectKey(),
					Size:      entry.Size,
				}
			}
		case types.DownloadBrowseEntryDirectory:
			if err := dt.collectDirectoryFiles(cache, entry.ObjectKey(), 1, expanded, dirs, &entryCount); err != nil {
				return nil, err
			}
		default:
			return nil, fmt.Errorf("unsupported browse entry type %q for %q", entry.EntryType, entry.ObjectKey())
		}
	}

	// 将发现的空目录路径映射到本地相对路径，避免把远端 object key 直接当成本地目录。
	localDirSet := make(map[string]string, len(dirs))
	for objectKey := range dirs {
		localRelPath, err := resolveLocalRelPathForObjectKey(objectKey, selections)
		if err != nil {
			return nil, err
		}
		if previous, exists := localDirSet[localRelPath]; exists && previous != objectKey {
			return nil, fmt.Errorf("%w: remote directories %q and %q both map to local path %q", ErrPlanning, previous, objectKey, localRelPath)
		}
		localDirSet[localRelPath] = objectKey
	}
	dirList := make([]string, 0, len(localDirSet))
	for d := range localDirSet {
		dirList = append(dirList, d)
	}
	sort.Strings(dirList)

	objectKeys := make([]string, 0, len(expanded))
	for objectKey := range expanded {
		objectKeys = append(objectKeys, objectKey)
	}
	sort.Strings(objectKeys)

	files := make([]*FileInfo, 0, len(objectKeys))
	for _, objectKey := range objectKeys {
		localRelPath, err := resolveLocalRelPathForObjectKey(objectKey, selections)
		if err != nil {
			return nil, err
		}
		file := NewFileInfo(dt, localRelPath, objectKey)
		file.Size = expanded[objectKey].Size
		files = append(files, file)
	}
	mappedDirs := make([]mappedLocalDirectory, 0, len(localDirSet)+len(dt.DirPaths))
	for localPath, objectKey := range localDirSet {
		mappedDirs = append(mappedDirs, mappedLocalDirectory{LocalPath: localPath, ObjectKey: objectKey})
	}
	for _, localPath := range dt.DirPaths {
		mappedDirs = append(mappedDirs, mappedLocalDirectory{LocalPath: localPath, ObjectKey: "[preplanned]" + localPath})
	}
	if err := validateLocalDownloadMappings(dt.TargetDir, files, mappedDirs); err != nil {
		return nil, fmt.Errorf("%w: %w", ErrPlanning, err)
	}
	dt.DirPaths = append(dt.DirPaths, dirList...)
	return files, nil
}

func validateLocalDownloadMappings(targetDir string, files []*FileInfo, emptyDirs []mappedLocalDirectory) error {
	caseInsensitive, err := localFilesystemCaseInsensitive(targetDir)
	if err != nil {
		return clienterror.New(
			clienterror.CodeLocalPathInvalid,
			"本地下载目标不可用："+targetDir,
			fmt.Errorf("detect destination filesystem case behavior: %w", err),
		)
	}
	type mapping struct {
		kind      string
		objectKey string
		localPath string
	}
	seen := make(map[string]mapping)
	register := func(kind, localPath, objectKey string) error {
		clean := filepath.Clean(localPath)
		if clean == "." || !filepath.IsLocal(clean) {
			return fmt.Errorf("remote object %q maps to invalid local path %q", objectKey, localPath)
		}
		key := clean
		if caseInsensitive {
			key = strings.ToLower(key)
		}
		if previous, exists := seen[key]; exists {
			if previous.kind == kind && previous.objectKey == objectKey {
				return nil
			}
			// Multiple explicitly mapped files may intentionally share the same
			// directory. The conflict is when distinct spellings collapse under
			// the destination filesystem's case rules, or when a file and a
			// directory occupy the same target.
			if previous.kind == "directory" && kind == "directory" && previous.localPath == clean {
				return nil
			}
			return fmt.Errorf("remote objects %q and %q map to conflicting local paths %q and %q", previous.objectKey, objectKey, previous.localPath, localPath)
		}
		seen[key] = mapping{kind: kind, objectKey: objectKey, localPath: clean}
		return nil
	}

	for _, directory := range emptyDirs {
		if err := register("directory", directory.LocalPath, directory.ObjectKey); err != nil {
			return err
		}
	}
	for _, file := range files {
		if file == nil {
			continue
		}
		if err := register("file", file.LocalPath, file.ObjectKey); err != nil {
			return err
		}
		localParent := filepath.Dir(file.LocalPath)
		remoteParent := path.Dir(file.ObjectKey)
		for localParent != "." && localParent != string(filepath.Separator) && remoteParent != "." && remoteParent != "/" {
			if err := register("directory", localParent, remoteParent); err != nil {
				return err
			}
			localParent = filepath.Dir(localParent)
			remoteParent = path.Dir(remoteParent)
		}
	}
	return nil
}

func localFilesystemCaseInsensitive(targetDir string) (bool, error) {
	probeDir := filepath.Clean(targetDir)
	for {
		info, err := os.Stat(probeDir)
		if err == nil {
			if !info.IsDir() {
				return false, fmt.Errorf("destination ancestor %q is not a directory", probeDir)
			}
			break
		}
		if !os.IsNotExist(err) {
			return false, err
		}
		parent := filepath.Dir(probeDir)
		if parent == probeDir {
			return false, err
		}
		probeDir = parent
	}
	probe, err := os.CreateTemp(probeDir, ".qtrans-Case-Probe-Aa-*")
	if err != nil {
		return false, err
	}
	probePath := probe.Name()
	if err := probe.Close(); err != nil {
		_ = os.Remove(probePath)
		return false, err
	}
	defer os.Remove(probePath)

	base := filepath.Base(probePath)
	alternateBase := toggleFirstASCIINameCase(base)
	if alternateBase == base {
		return false, nil
	}
	originalInfo, err := os.Stat(probePath)
	if err != nil {
		return false, err
	}
	alternateInfo, err := os.Stat(filepath.Join(filepath.Dir(probePath), alternateBase))
	if os.IsNotExist(err) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return os.SameFile(originalInfo, alternateInfo), nil
}

func toggleFirstASCIINameCase(value string) string {
	bytes := []byte(value)
	for index, char := range bytes {
		switch {
		case char >= 'a' && char <= 'z':
			bytes[index] = char - ('a' - 'A')
			return string(bytes)
		case char >= 'A' && char <= 'Z':
			bytes[index] = char + ('a' - 'A')
			return string(bytes)
		}
	}
	return value
}

func sumFileSizes(files []*FileInfo) (int64, error) {
	var total int64
	for _, file := range files {
		if file == nil {
			continue
		}
		if file.Size < 0 || file.Size > math.MaxInt64-total {
			return 0, fmt.Errorf("download total size exceeds int64")
		}
		total += file.Size
	}
	return total, nil
}

func chunkFileInfos(files []*FileInfo, batchSize int) [][]*FileInfo {
	if batchSize <= 0 {
		batchSize = 1
	}
	var batches [][]*FileInfo
	for i := 0; i < len(files); i += batchSize {
		end := i + batchSize
		if end > len(files) {
			end = len(files)
		}
		batches = append(batches, files[i:end])
	}
	return batches
}
