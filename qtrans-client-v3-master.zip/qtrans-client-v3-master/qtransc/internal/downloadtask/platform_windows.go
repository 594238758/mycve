//go:build windows

package downloadtask

import (
	"fmt"
	"syscall"
	"unsafe"
)

// checkAccessWritable is a no-op on Windows; the subsequent trial-write
// in checkTargetDirAvailable already covers permission verification.
func checkAccessWritable(_ string) error {
	return nil
}

// availableDiskSpace returns the number of bytes available on the
// volume containing dir, using the Win32 GetDiskFreeSpaceExW API.
func availableDiskSpace(dir string) (int64, error) {
	kernel32 := syscall.NewLazyDLL("kernel32.dll")
	getDiskFreeSpaceEx := kernel32.NewProc("GetDiskFreeSpaceExW")

	dirPtr, err := syscall.UTF16PtrFromString(dir)
	if err != nil {
		return 0, fmt.Errorf("invalid path: %w", err)
	}

	var freeBytesAvailable int64
	r1, _, e1 := getDiskFreeSpaceEx.Call(
		uintptr(unsafe.Pointer(dirPtr)),
		uintptr(unsafe.Pointer(&freeBytesAvailable)),
		0,
		0,
	)
	if r1 == 0 {
		return 0, fmt.Errorf("GetDiskFreeSpaceExW failed: %w", e1)
	}
	return freeBytesAvailable, nil
}
