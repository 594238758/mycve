package downloadtask

import "qtransc/internal/transferlimits"

const (
	CHUNKSIZE                 = 100 * 1024 * 1024 // 100MB
	defaultSmallBatchSize     = 100
	defaultSmallBatchMaxBytes = 128 * 1024 * 1024
	defaultSmallV2BatchBytes  = 32 * 1024 * 1024
)

// SmallFileMaxBytes is the size threshold below which a file is considered
// "small" and eligible for the batched /d/small download path.
// Files with Size < SmallFileMaxBytes go to the small-file batch pipeline.
// This is a var so tests can override it.
var SmallFileMaxBytes int64 = 4 * 1024 * 1024 // 4 MiB

// SmallBatchSize is the maximum number of small files per batch request.
var SmallBatchSize = defaultSmallBatchSize

// SmallBatchMaxBytes is the maximum total size of files in one batched
// /d/small request.
var SmallBatchMaxBytes int64 = defaultSmallBatchMaxBytes // 128 MiB (v1 compatibility)

// GrantBatchSize is the maximum number of explicit files per qtserver grant request.
var GrantBatchSize = 1000

func minPositiveInt(local, remote int) int {
	if local <= 0 {
		return remote
	}
	if remote <= 0 || local < remote {
		return local
	}
	return remote
}

func minPositiveInt64(local, remote int64) int64 {
	if local <= 0 {
		return remote
	}
	if remote <= 0 || local < remote {
		return local
	}
	return remote
}

const (
	downloadBrowseMaxDepth          = 128
	downloadBrowseMaxFiles          = transferlimits.MaxTaskFiles
	downloadBrowseMaxEntries        = 200000
	downloadChunkFallbackRetryCount = 3
	downloadChunkRetryLogInterval   = 10
)
