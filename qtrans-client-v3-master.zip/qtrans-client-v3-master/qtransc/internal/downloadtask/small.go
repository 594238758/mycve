package downloadtask

import (
	"archive/tar"
	"bytes"
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"sync"
	"sync/atomic"

	"qtransc/internal/clienterror"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/types"
	"qtransc/internal/version"
	"runtime"

	"github.com/zeebo/xxh3"
	"golang.org/x/sync/errgroup"
)

const smallPayloadPrefix = "payload/"

// ---------------------------------------------------------------------------
// Batch-based small file download (used by the new split-based flow)
// ---------------------------------------------------------------------------

// downloadSmallFiles splits dt.SmallFiles into batches constrained by both
// SmallBatchSize and SmallBatchMaxBytes, then downloads each batch concurrently
// via POST /d/small.
func (dt *DownloadTask) downloadSmallFiles() error {
	return dt.downloadScheduledSmallFiles(dt.ctx, dt.SmallFiles)
}

func (dt *DownloadTask) downloadSmallFilesBatch(files []*FileInfo) error {
	return dt.downloadScheduledSmallFiles(dt.ctx, files)
}

func (dt *DownloadTask) downloadScheduledSmallFiles(ctx context.Context, files []*FileInfo) error {
	if dt.smallDownloadV2 {
		return dt.downloadScheduledSmallFilesV2(ctx, files)
	}
	batches := chunkSmallDownloadFiles(files, SmallBatchSize, SmallBatchMaxBytes)
	workerCount := dt.workerCountForPending(len(batches))
	if workerCount == 0 {
		return nil
	}

	batchCh := make(chan []*FileInfo)
	var g errgroup.Group
	var errorMu sync.Mutex
	var joinedErr error
	recordError := func(err error) {
		if err == nil {
			return
		}
		errorMu.Lock()
		joinedErr = errors.Join(joinedErr, err)
		errorMu.Unlock()
	}

	for range workerCount {
		g.Go(func() error {
			for batch := range batchCh {
				if ctx.Err() != nil {
					return nil
				}
				if err := dt.downloadSmallBatch(ctx, batch); err != nil && !errors.Is(err, context.Canceled) {
					recordError(err)
				}
			}
			return nil
		})
	}

	for _, batch := range batches {
		select {
		case <-ctx.Done():
			close(batchCh)
			_ = g.Wait()
			return ctx.Err()
		case batchCh <- batch:
		}
	}
	close(batchCh)

	_ = g.Wait()
	if err := ctx.Err(); err != nil {
		return err
	}
	return joinedErr
}

// chunkSmallDownloadFiles splits files into groups constrained by both file
// count and total file size.
func chunkSmallDownloadFiles(files []*FileInfo, batchSize int, maxBatchBytes int64) [][]*FileInfo {
	if batchSize <= 0 {
		batchSize = defaultSmallBatchSize
	}
	if maxBatchBytes <= 0 {
		maxBatchBytes = defaultSmallBatchMaxBytes
	}

	batches := make([][]*FileInfo, 0, (len(files)+batchSize-1)/batchSize)
	current := make([]*FileInfo, 0, batchSize)
	var currentBytes int64
	keys := map[string]bool{}

	flush := func() {
		if len(current) == 0 {
			return
		}
		batches = append(batches, current)
		current = make([]*FileInfo, 0, batchSize)
		currentBytes = 0
		keys = map[string]bool{}
	}

	for _, file := range files {
		var fileSize int64
		if file != nil && file.Size > 0 {
			fileSize = file.Size
		}

		reachesFileLimit := len(current) >= batchSize
		exceedsByteLimit := len(current) > 0 && fileSize > maxBatchBytes-currentBytes
		if reachesFileLimit || exceedsByteLimit || (file != nil && keys[file.ObjectKey]) {
			flush()
		}

		if file != nil {
			keys[file.ObjectKey] = true
		}
		current = append(current, file)
		currentBytes += fileSize
	}
	flush()

	return batches
}

// downloadSmallBatch downloads a single batch of files via /d/small.
func (dt *DownloadTask) downloadSmallBatch(ctx context.Context, batch []*FileInfo) error {
	authRetryCount := 0
	retryState := newDownloadControlRetryState()
	var lastTransportErr error

	for {
		reqBody := types.DownloadSmallRequest{
			TaskID: dt.qtserverTaskID(),
			Files:  make([]types.DownloadObjectRequest, 0, len(batch)),
		}
		for _, file := range batch {
			reqBody.Files = append(reqBody.Files, types.DownloadObjectRequest{ObjectKey: file.ObjectKey})
		}

		reqBodyBytes, err := json.Marshal(reqBody)
		if err != nil {
			return fmt.Errorf("marshal small batch request: %w", err)
		}

		requestURL, err := qtserverurl.JoinEndpoint(dt.ServerAddr, "/d/small")
		if err != nil {
			return err
		}

		req, err := http.NewRequestWithContext(ctx, http.MethodPost, requestURL, bytes.NewReader(reqBodyBytes))
		if err != nil {
			return fmt.Errorf("create small batch request: %w", err)
		}
		req.Header.Set("Content-Type", "application/json")
		qtserverapi.SetTaskCorrelationHeaders(req.Header, dt.taskCorrelation())
		clientID, clientIDErr := version.CurrentClientID()
		if clientIDErr != nil {
			return fmt.Errorf("load client id: %w", clientIDErr)
		}
		req.Header.Set("Client-ID", clientID)
		req.Header.Set("Client-OS", runtime.GOOS)
		req.Header.Set("Client-Version", version.Version)
		req.Header.Set("Caller-Version", dt.CallerVersion)

		client, releaseClient, err := dt.acquireClient(ctx, req.URL.String())
		if err != nil {
			return err
		}
		usedToken := ""
		if dt.downloadUser() == types.DownloadUserSelf {
			usedToken, err = dt.currentBearerToken()
			if err != nil {
				releaseClient()
				return err
			}
			setBearerAuthorizationHeader(req, usedToken)
		}

		resp, err := client.Do(req)
		releaseClient()
		if err != nil {
			requestErr := fmt.Errorf("request small batch download: %w", err)
			retry, waitErr := retryDownloadControlTransport(ctx, dt.logger, "download small batch", &retryState, requestErr)
			if waitErr != nil {
				return waitErr
			}
			if retry {
				lastTransportErr = requestErr
				continue
			}
			return requestErr
		}
		logDownloadControlTransportRecovered(dt.logger, "download small batch", retryState, lastTransportErr)

		if resp.StatusCode != http.StatusOK {
			body, _ := io.ReadAll(resp.Body)
			_ = resp.Body.Close()
			if retry, waitErr := retryDownloadControlHTTP(ctx, &retryState, resp.StatusCode, resp.Header); waitErr != nil {
				return waitErr
			} else if retry {
				continue
			}
			httpErr := fmt.Errorf("small batch download failed: status=%d body=%s", resp.StatusCode, strings.TrimSpace(string(body)))
			if isHTTPAuthorizationFailure(resp.StatusCode) {
				if authRetryCount < downloadAuthRetryMaxRefreshes && dt.refreshAuthorizationAfter401(ctx, resp.StatusCode) {
					authRetryCount++
					continue
				}
				return dt.authFailedErr(httpErr, usedToken, resp.StatusCode)
			}
			dt.logger.Warn("small batch preparation failed, falling back to ordinary downloads",
				"err", httpErr,
				"file_count", len(batch))
			if fallbackErr := dt.downloadScheduledLargeFiles(ctx, batch); fallbackErr != nil {
				return fmt.Errorf("small batch preparation failed (%v) and ordinary download fallback failed: %w", httpErr, fallbackErr)
			}
			return nil
		}

		err = dt.consumeSmallTarForBatch(dt.wrapRateLimitedReader(ctx, resp.Body), batch)
		_ = resp.Body.Close()
		if err == nil {
			return dt.finalizeSmallClientResults(ctx, batch)
		}

		fallbackFiles := batch
		var integrityErr *smallBatchIntegrityError
		if errors.As(err, &integrityErr) {
			fallbackFiles = integrityErr.files
			failed := make(map[*FileInfo]struct{}, len(fallbackFiles))
			for _, file := range fallbackFiles {
				failed[file] = struct{}{}
			}
			completedFiles := make([]*FileInfo, 0, len(batch)-len(fallbackFiles))
			for _, file := range batch {
				if _, isFailed := failed[file]; !isFailed {
					completedFiles = append(completedFiles, file)
				}
			}
			if finalizeErr := dt.finalizeSmallClientResults(ctx, completedFiles); finalizeErr != nil {
				return finalizeErr
			}
			for _, file := range fallbackFiles {
				// The failed small transfer is the first integrity mismatch. A
				// mismatch after the ordinary re-download must be terminal.
				file.hashMismatchRetries = 1
			}
		}
		dt.logger.Warn("small batch failed, falling back to ordinary download",
			"err", err,
			"file_count", len(fallbackFiles))
		if resetErr := dt.resetSmallFallbackFiles(fallbackFiles); resetErr != nil {
			return fmt.Errorf("small batch failed (%v) and cleanup failed: %w", err, resetErr)
		}
		if fallbackErr := dt.downloadScheduledLargeFiles(ctx, fallbackFiles); fallbackErr != nil {
			return fmt.Errorf("small batch failed (%v) and ordinary download fallback failed: %w", err, fallbackErr)
		}
		return nil
	}
}

func (dt *DownloadTask) finalizeSmallClientResults(ctx context.Context, files []*FileInfo) error {
	// writeSmallFile already publishes the final progress/status before removing
	// the file from the active set. Keep this hook for the existing call flow.
	_ = ctx
	_ = files
	return nil
}

type smallFileIntegrityError struct {
	err error
}

func (e *smallFileIntegrityError) Error() string { return e.err.Error() }
func (e *smallFileIntegrityError) Unwrap() error { return e.err }
func (e *smallFileIntegrityError) Is(target error) bool {
	return target == ErrIntegrityCheckFailed
}

type smallBatchIntegrityError struct {
	files []*FileInfo
}

func (e *smallBatchIntegrityError) Error() string {
	return fmt.Sprintf("small download integrity mismatch for %d file(s)", len(e.files))
}

func (dt *DownloadTask) resetSmallFallbackFiles(files []*FileInfo) error {
	for _, file := range files {
		if file == nil {
			continue
		}
		file.setTransferred(0)
		atomic.StoreInt64(&file.Rate, 0)
		if file.Verified {
			dt.VerifiedFileNum.Add(-1)
		}
		file.Received = false
		file.Verified = false
		file.OverallChecksum = ""
		file.replaceChunks(nil)
		if err := os.Remove(file.FullPath); err != nil && !errors.Is(err, os.ErrNotExist) {
			return fmt.Errorf("remove failed small download %s: %w", file.FullPath, err)
		}
		if err := os.Remove(file.ProgressPath); err != nil && !errors.Is(err, os.ErrNotExist) {
			return fmt.Errorf("remove failed small progress %s: %w", file.ProgressPath, err)
		}
	}
	return nil
}

// consumeSmallTarForBatch processes a manifest-first tar stream and writes
// files to disk using the batch's FileInfo objects for progress tracking.
func (dt *DownloadTask) consumeSmallTarForBatch(body io.Reader, batch []*FileInfo) error {
	tr := tar.NewReader(body)

	// 1. session.json
	header, err := tr.Next()
	if err != nil {
		return fmt.Errorf("read small session entry: %w", err)
	}
	if header.Name != ".qtrans/session.json" {
		return fmt.Errorf("unexpected first tar entry %q", header.Name)
	}
	if _, err := io.ReadAll(tr); err != nil {
		return fmt.Errorf("read small session payload: %w", err)
	}

	// 2. manifest.json
	header, err = tr.Next()
	if err != nil {
		return fmt.Errorf("read small manifest entry: %w", err)
	}
	if header.Name != ".qtrans/manifest.json" {
		return fmt.Errorf("unexpected second tar entry %q", header.Name)
	}
	manifestBytes, err := io.ReadAll(tr)
	if err != nil {
		return fmt.Errorf("read small manifest payload: %w", err)
	}
	var manifest types.DownloadSmallManifest
	if err := json.Unmarshal(manifestBytes, &manifest); err != nil {
		return fmt.Errorf("decode small manifest: %w", err)
	}

	// Build bindings from manifest entries to batch FileInfo objects.
	bindings, err := bindSmallFiles(dt, batch, manifest)
	if err != nil {
		return err
	}

	// 3. payload entries
	seen := 0
	failedFiles := make([]*FileInfo, 0)
	for {
		header, err = tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return fmt.Errorf("read small payload entry: %w", err)
		}
		if !strings.HasPrefix(header.Name, smallPayloadPrefix) {
			return fmt.Errorf("unexpected tar payload entry %q", header.Name)
		}
		entry, ok := bindings[header.Name]
		if !ok {
			return fmt.Errorf("unexpected tar payload entry %q", header.Name)
		}
		if err := writeSmallFile(tr, entry.file, entry.expected); err != nil {
			var integrityErr *smallFileIntegrityError
			if errors.As(err, &integrityErr) {
				failedFiles = append(failedFiles, entry.file)
				seen++
				continue
			}
			return err
		}
		seen++
	}
	if seen != len(bindings) {
		return fmt.Errorf("small download missing payload files: got %d want %d", seen, len(bindings))
	}
	if len(failedFiles) > 0 {
		return &smallBatchIntegrityError{files: failedFiles}
	}
	return nil
}

// ---------------------------------------------------------------------------
// Legacy TrySmallDownload (retained for test backward compatibility)
// ---------------------------------------------------------------------------

// TrySmallDownload sends ALL FileList files to /d/small as a single
// request. Returns (true, nil) if the server handled it, (false, nil) if the
// server returned 400 (not applicable), or (false/true, err) on failure.
// NOTE: This is the old all-or-nothing path, kept for backward compat.
func (dt *DownloadTask) TrySmallDownload() (bool, error) {
	reqCtx := dt.requestContext()
	authRetryCount := 0
	retryState := newDownloadControlRetryState()
	var lastTransportErr error

	for {
		reqBody := types.DownloadSmallRequest{
			TaskID: dt.qtserverTaskID(),
			Files:  make([]types.DownloadObjectRequest, 0, len(dt.FileList)),
		}
		for _, file := range dt.FileList {
			reqBody.Files = append(reqBody.Files, types.DownloadObjectRequest{ObjectKey: file.ObjectKey})
		}

		reqBodyBytes, err := json.Marshal(reqBody)
		if err != nil {
			return false, fmt.Errorf("failed to marshal small request: %w", err)
		}

		requestURL, err := qtserverurl.JoinEndpoint(dt.ServerAddr, "/d/small")
		if err != nil {
			return false, err
		}

		req, err := http.NewRequestWithContext(reqCtx, http.MethodPost, requestURL, bytes.NewReader(reqBodyBytes))
		if err != nil {
			return false, fmt.Errorf("failed to create small request: %w", err)
		}
		req.Header.Set("Content-Type", "application/json")
		qtserverapi.SetTaskCorrelationHeaders(req.Header, dt.taskCorrelation())
		clientID, clientIDErr := version.CurrentClientID()
		if clientIDErr != nil {
			return false, fmt.Errorf("load client id: %w", clientIDErr)
		}
		req.Header.Set("Client-ID", clientID)
		req.Header.Set("Client-OS", runtime.GOOS)
		req.Header.Set("Client-Version", version.Version)
		req.Header.Set("Caller-Version", dt.CallerVersion)

		client, releaseClient, err := dt.acquireClient(reqCtx, req.URL.String())
		if err != nil {
			return false, err
		}
		usedToken := ""
		if dt.downloadUser() == types.DownloadUserSelf {
			usedToken, err = dt.currentBearerToken()
			if err != nil {
				releaseClient()
				return false, err
			}
			setBearerAuthorizationHeader(req, usedToken)
		}

		resp, err := client.Do(req)
		releaseClient()
		if err != nil {
			requestErr := fmt.Errorf("failed to request small download: %w", err)
			retry, waitErr := retryDownloadControlTransport(reqCtx, dt.logger, "try small download", &retryState, requestErr)
			if waitErr != nil {
				return false, waitErr
			}
			if retry {
				lastTransportErr = requestErr
				continue
			}
			return false, requestErr
		}
		logDownloadControlTransportRecovered(dt.logger, "try small download", retryState, lastTransportErr)

		if resp.StatusCode == http.StatusBadRequest {
			body, _ := io.ReadAll(resp.Body)
			_ = resp.Body.Close()
			dt.logger.Debug("small download not applicable, fallback to grant", "body", strings.TrimSpace(string(body)))
			return false, nil
		}
		if resp.StatusCode != http.StatusOK {
			body, _ := io.ReadAll(resp.Body)
			_ = resp.Body.Close()
			if retry, waitErr := retryDownloadControlHTTP(reqCtx, &retryState, resp.StatusCode, resp.Header); waitErr != nil {
				return false, waitErr
			} else if retry {
				continue
			}
			httpErr := fmt.Errorf("small download failed with status code: %d, body: %s", resp.StatusCode, strings.TrimSpace(string(body)))
			if isHTTPAuthorizationFailure(resp.StatusCode) {
				if authRetryCount < downloadAuthRetryMaxRefreshes && dt.refreshAuthorizationAfter401(reqCtx, resp.StatusCode) {
					authRetryCount++
					continue
				}
				return false, dt.authFailedErr(httpErr, usedToken, resp.StatusCode)
			}
			return false, httpErr
		}

		if err := dt.consumeSmallTar(dt.wrapRateLimitedReader(reqCtx, resp.Body)); err != nil {
			_ = resp.Body.Close()
			return true, err
		}
		_ = resp.Body.Close()
		if err := dt.finalizeSmallClientResults(reqCtx, dt.FileList); err != nil {
			return true, err
		}
		return true, nil
	}
}

func (dt *DownloadTask) consumeSmallTar(body io.Reader) error {
	selections := append([]*FileInfo(nil), dt.FileList...)
	tr := tar.NewReader(body)

	header, err := tr.Next()
	if err != nil {
		return fmt.Errorf("read small session entry: %w", err)
	}
	if header.Name != ".qtrans/session.json" {
		return fmt.Errorf("unexpected first tar entry %q", header.Name)
	}
	sessionBytes, err := io.ReadAll(tr)
	if err != nil {
		return fmt.Errorf("read small session payload: %w", err)
	}
	var session types.DownloadSmallSession
	if err := json.Unmarshal(sessionBytes, &session); err != nil {
		return fmt.Errorf("decode small session: %w", err)
	}

	header, err = tr.Next()
	if err != nil {
		return fmt.Errorf("read small manifest entry: %w", err)
	}
	if header.Name != ".qtrans/manifest.json" {
		return fmt.Errorf("unexpected second tar entry %q", header.Name)
	}
	manifestBytes, err := io.ReadAll(tr)
	if err != nil {
		return fmt.Errorf("read small manifest payload: %w", err)
	}
	var manifest types.DownloadSmallManifest
	if err := json.Unmarshal(manifestBytes, &manifest); err != nil {
		return fmt.Errorf("decode small manifest: %w", err)
	}

	dt.ServerTaskID = session.TaskID
	dt.TotalSize.Store(session.TotalUnpackedBytes)

	if err := checkTargetDirAvailable(dt.TargetDir, dt.TotalSize.Load()); err != nil {
		return err
	}

	files, manifestByArchivePath, err := dt.materializeSmallFiles(selections, manifest)
	if err != nil {
		return err
	}
	dt.FileList = files
	dt.AuthorizedFiles = files

	seen := make(map[string]struct{}, len(files))
	for {
		header, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return fmt.Errorf("read small payload entry: %w", err)
		}
		if !strings.HasPrefix(header.Name, smallPayloadPrefix) {
			return fmt.Errorf("unexpected tar payload entry %q", header.Name)
		}
		entry, ok := manifestByArchivePath[header.Name]
		if !ok {
			return fmt.Errorf("unexpected tar payload entry %q", header.Name)
		}
		file := entry.file
		if err := writeSmallFile(tr, file, entry.expected); err != nil {
			return err
		}
		seen[header.Name] = struct{}{}
	}

	if len(seen) != len(files) {
		return fmt.Errorf("small download missing payload files: got %d want %d", len(seen), len(files))
	}
	return nil
}

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

type smallManifestBinding struct {
	file     *FileInfo
	expected types.DownloadSmallManifestEntry
}

// bindSmallFiles matches manifest entries to batch FileInfo objects by ObjectKey.
func bindSmallFiles(dt *DownloadTask, batch []*FileInfo, manifest types.DownloadSmallManifest) (map[string]smallManifestBinding, error) {
	byKey := make(map[string]*FileInfo, len(batch))
	for _, f := range batch {
		byKey[f.ObjectKey] = f
	}
	bindings := make(map[string]smallManifestBinding, len(manifest.Files))
	for _, entry := range manifest.Files {
		f, ok := byKey[entry.ObjectKey]
		if !ok {
			return nil, fmt.Errorf("manifest entry %q not found in batch", entry.ObjectKey)
		}
		f.Size = entry.Size
		bindings[entry.ArchivePath] = smallManifestBinding{file: f, expected: entry}
	}
	return bindings, nil
}

func (dt *DownloadTask) materializeSmallFiles(selections []*FileInfo, manifest types.DownloadSmallManifest) ([]*FileInfo, map[string]smallManifestBinding, error) {
	files := make([]*FileInfo, 0, len(manifest.Files))
	bindings := make(map[string]smallManifestBinding, len(manifest.Files))
	for _, entry := range manifest.Files {
		localRelPath, err := resolveLocalRelPathForObjectKey(entry.ObjectKey, selections)
		if err != nil {
			return nil, nil, err
		}
		file := NewFileInfo(dt, localRelPath, entry.ObjectKey)
		file.Authorized = true
		file.Size = entry.Size
		files = append(files, file)
		bindings[entry.ArchivePath] = smallManifestBinding{file: file, expected: entry}
	}
	return files, bindings, nil
}

func writeSmallFile(r io.Reader, file *FileInfo, expected types.DownloadSmallManifestEntry) (returnErr error) {
	if err := file.CreateParentDirIfNotExist(); err != nil {
		return err
	}

	out, err := os.OpenFile(file.FullPath, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0o644)
	if err != nil {
		return clienterror.New(clienterror.CodeLocalPathInvalid, "无法打开本地小文件下载目标："+file.FullPath, err)
	}
	defer out.Close()

	file.dt.TransferingFiles.Store(file.LocalPath, file)
	file.publishStatus(types.FileEventStatusStarted)
	completed := false
	defer func() {
		if !completed {
			file.publishProgressEvents(true)
			file.publishStatus(types.FileEventStatusFailed, returnErr)
		}
		file.dt.TransferingFiles.Delete(file.LocalPath)
		atomic.StoreInt64(&file.Rate, 0)
	}()

	overallHasher := xxh3.New()
	chunkHasher := xxh3.New()
	buf := make([]byte, 32*1024)
	var (
		written      int64
		chunkWritten int64
	)

	for {
		n, err := r.Read(buf)
		if n > 0 {
			if _, werr := out.Write(buf[:n]); werr != nil {
				_ = os.Remove(file.FullPath)
				return fmt.Errorf("write small payload: %w", werr)
			}
			file.addSmallPayload(int64(n))
			written += int64(n)
			chunkWritten += int64(n)
			_, _ = chunkHasher.Write(buf[:n])

			if chunkWritten >= CHUNKSIZE {
				sum := chunkHasher.Sum128().Bytes()
				_, _ = overallHasher.Write(sum[:])
				chunkHasher = xxh3.New()
				chunkWritten = 0
			}
		}
		if err == io.EOF {
			break
		}
		if err != nil {
			_ = os.Remove(file.FullPath)
			return fmt.Errorf("read small payload: %w", err)
		}
	}

	if chunkWritten > 0 {
		sum := chunkHasher.Sum128().Bytes()
		_, _ = overallHasher.Write(sum[:])
	}
	finalSum := overallHasher.Sum128().Bytes()
	file.OverallChecksum = hex.EncodeToString(finalSum[:])

	if written != expected.Size {
		_ = os.Remove(file.FullPath)
		return &smallFileIntegrityError{err: fmt.Errorf("small payload size mismatch for %s: got %d want %d", file.ObjectKey, written, expected.Size)}
	}
	if file.OverallChecksum != expected.Hash {
		_ = os.Remove(file.FullPath)
		return &smallFileIntegrityError{err: fmt.Errorf("small payload hash mismatch for %s", file.ObjectKey)}
	}

	file.Received = true
	file.Verified = true
	file.dt.VerifiedFileNum.Add(1)
	file.publishProgressEvents(true)
	file.publishStatus(types.FileEventStatusCompleted)
	completed = true

	return nil
}
