//go:build !windows

package downloadtask

import "os"

func (fi *FileInfo) prepareLocalFile(file *os.File) error {
	return nil
}
