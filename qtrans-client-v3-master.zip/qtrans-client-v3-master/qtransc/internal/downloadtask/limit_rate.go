package downloadtask

import (
	"context"
	"io"
)

func (dt *DownloadTask) wrapRateLimitedReader(ctx context.Context, reader io.Reader) io.Reader {
	if dt == nil || dt.rateLimiter == nil {
		return reader
	}
	return dt.rateLimiter.WrapReader(ctx, reader)
}
