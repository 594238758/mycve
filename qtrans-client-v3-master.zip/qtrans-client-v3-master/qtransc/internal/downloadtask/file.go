package downloadtask

import (
	"bytes"
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"qtransc/internal/average"
	"qtransc/internal/clienterror"
	"qtransc/internal/eventcollector"
	"qtransc/internal/netclient"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/types"
	"qtransc/internal/version"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/zeebo/xxh3"
)

// 文件信息
type FileInfo struct {
	failure       types.FileFailure  `json:"-"`
	ctx           context.Context    `json:"-"` // 上下文，用于取消操作
	cancel        context.CancelFunc `json:"-"` // 取消函数
	logger        *slog.Logger       `json:"-"` // 日志记录器
	dt            *DownloadTask      `json:"-"` // 所属下载任务
	File          *os.File           `json:"-"` // 本地文件句柄
	LastErr       error              `json:"-"` // 最近一次操作的错误
	trackInterval int64              `json:"-"` // 进度保存和速率计算的时间间隔，单位秒
	chunksMu      sync.RWMutex       `json:"-"`
	activeChunks  sync.Map           `json:"-"`

	FullPath     string `json:"full_path,omitempty"`     // 本地的绝对路径
	ProgressPath string `json:"progress_path,omitempty"` // 进度文件的路径

	LocalPath                string       `json:"local_rel_path,omitempty"`    // 本地存储的相对路径
	ObjectKey                string       `json:"object_key,omitempty"`        // qtserver object_key
	Grant                    string       `json:"grant,omitempty"`             // qtserver 返回的不透明临时授权
	RemotePath               string       `json:"remote_url,omitempty"`        // 兼容字段，与 ObjectKey 相同
	Authorized               bool         `json:"authorized,omitempty"`        // 是否授权
	Size                     int64        `json:"size,omitempty"`              // 文件大小，单位字节
	Transferred              int64        `json:"transferred_bytes,omitempty"` // 已传输的字节数
	NetworkReceived          int64        `json:"-"`
	Rate                     int64        `json:"transfer_rate,omitempty"` // 当前传输速率，单位字节/秒
	lastNetworkReceived      int64        `json:"-"`
	rateAverage              *average.SMA `json:"-"`
	lastProgressPublishedAt  atomic.Int64 `json:"-"`
	OverallChecksum          string       `json:"overall_checksum,omitempty"` // 整体校验和
	Received                 bool         `json:"received,omitempty"`         // 是否已接收
	Verified                 bool         `json:"verified,omitempty"`         // 是否已校验
	Chunks                   []*ChunkInfo `json:"chunks,omitempty"`           // 分片信息列表
	hashMismatchRetries      int          `json:"-"`
	logRegistrationConfirmed atomic.Bool  `json:"-"`
	grantGeneration          uint64       `json:"-"`
}

var ErrIntegrityCheckFailed = errors.New("download file hash mismatch")

func NewFileInfo(dt *DownloadTask,
	localPath, objectKey string,
) *FileInfo {
	return &FileInfo{
		ctx:           nil,
		logger:        dt.logger.With("file", localPath),
		dt:            dt,
		trackInterval: 1, // 默认1秒，便于 CLI 及时显示当前文件速率
		rateAverage:   average.NewSMA(20),
		FullPath:      filepath.Join(dt.TargetDir, localPath),
		ProgressPath:  filepath.Join(dt.TargetDir, localPath+".progress"),
		LocalPath:     localPath,
		ObjectKey:     objectKey,
		RemotePath:    objectKey,
	}
}

// newRunFile preserves the selected source, destination and metadata without
// carrying grants, chunks or other execution state into a new round.
func (fi *FileInfo) newRunFile() *FileInfo {
	file := NewFileInfo(fi.dt, fi.LocalPath, fi.ObjectKey)
	file.FullPath = fi.FullPath
	file.ProgressPath = fi.ProgressPath
	file.Size = fi.Size
	return file
}

func clampDownloadTransfer(value, total int64) int64 {
	if value < 0 {
		return 0
	}
	if total > 0 && value > total {
		return total
	}
	return value
}

func addBoundedDownloadInt64(target *int64, delta, total int64) int64 {
	if target == nil || delta == 0 {
		return 0
	}
	for {
		current := atomic.LoadInt64(target)
		next := clampDownloadTransfer(current+delta, total)
		if atomic.CompareAndSwapInt64(target, current, next) {
			return next - current
		}
	}
}

func addBoundedDownloadAtomic(target *atomic.Int64, delta, total int64) int64 {
	if target == nil || delta == 0 {
		return 0
	}
	for {
		current := target.Load()
		next := clampDownloadTransfer(current+delta, total)
		if target.CompareAndSwap(current, next) {
			return next - current
		}
	}
}

func (fi *FileInfo) chunksSnapshot() []*ChunkInfo {
	if fi == nil {
		return nil
	}
	fi.chunksMu.RLock()
	defer fi.chunksMu.RUnlock()
	return append([]*ChunkInfo(nil), fi.Chunks...)
}

func (fi *FileInfo) replaceChunks(chunks []*ChunkInfo) {
	fi.chunksMu.Lock()
	fi.Chunks = chunks
	fi.chunksMu.Unlock()
}

func (fi *FileInfo) setTransferred(transferred int64) {
	if fi == nil || fi.dt == nil {
		return
	}
	transferred = clampDownloadTransfer(transferred, fi.Size)
	previous := atomic.SwapInt64(&fi.Transferred, transferred)
	addBoundedDownloadAtomic(&fi.dt.Transferred, transferred-previous, fi.dt.TotalSize.Load())
}

func (fi *FileInfo) addTransferred(bytes int64) int64 {
	if fi == nil || fi.dt == nil || bytes == 0 {
		return 0
	}
	delta := addBoundedDownloadInt64(&fi.Transferred, bytes, fi.Size)
	addBoundedDownloadAtomic(&fi.dt.Transferred, delta, fi.dt.TotalSize.Load())
	return delta
}

func (fi *FileInfo) addNetworkReceived(bytes int64) {
	if fi == nil || fi.dt == nil || bytes <= 0 {
		return
	}
	atomic.AddInt64(&fi.NetworkReceived, bytes)
	fi.dt.NetworkReceived.Add(bytes)
}

func (fi *FileInfo) addSmallPayload(bytes int64) {
	if bytes <= 0 {
		return
	}
	fi.addNetworkReceived(bytes)
	fi.addTransferred(bytes)
}

func (fi *FileInfo) sampleTransferRates(elapsed time.Duration) {
	if fi == nil || elapsed <= 0 {
		return
	}
	current := atomic.LoadInt64(&fi.NetworkReceived)
	delta := current - fi.lastNetworkReceived
	if delta < 0 {
		delta = 0
	}
	if fi.rateAverage == nil {
		fi.rateAverage = average.NewSMA(20)
	}
	atomic.StoreInt64(&fi.Rate, int64(fi.rateAverage.Update(float64(delta)/elapsed.Seconds())))
	fi.lastNetworkReceived = current

	fi.activeChunks.Range(func(_, value any) bool {
		if chunk, ok := value.(*ChunkInfo); ok && chunk != nil {
			chunk.sampleTransferRate(elapsed)
		}
		return true
	})
}

func (fi *FileInfo) eventFileKey() string {
	if fi == nil {
		return ""
	}
	if dst := fi.copyDestination(); dst != "" {
		return dst
	}
	if strings.TrimSpace(fi.ObjectKey) != "" {
		// 临时兼容旧版 Agent 的匹配格式，仅在事件上报时移除前导斜杠。
		return strings.TrimPrefix(fi.ObjectKey, "/")
	}
	return fi.LocalPath
}

func (fi *FileInfo) publishStatus(status string, causes ...error) {
	if fi == nil || fi.dt == nil {
		return
	}
	var cause error
	if len(causes) > 0 {
		cause = causes[0]
	}
	switch status {
	case types.FileEventStatusFailed:
		if errors.Is(cause, context.Canceled) {
			return
		}
		var first bool
		cause, first = fi.failure.Record(cause)
		fi.dt.recordFinalError(cause)
		if !first {
			return
		}
	case types.FileEventStatusStarted, types.FileEventStatusCompleted:
		fi.failure.Clear()
	}
	if fi.dt.publisher == nil {
		return
	}

	fi.dt.publisher.Publish(types.NewFileStatusEventWithCause(
		fi.dt.TaskID,
		fi.eventFileKey(),
		status,
		cause,
	))
}

func (fi *FileInfo) publishProgressEvents(force bool) {
	if fi == nil || fi.dt == nil || fi.dt.publisher == nil {
		return
	}
	if !eventcollector.ShouldPublishProgress(&fi.lastProgressPublishedAt, fi.dt.progressEventInterval, force) {
		return
	}
	fi.dt.publisher.Publish(types.NewFileProgressEvent(
		fi.dt.TaskID,
		fi.eventFileKey(),
		fi.Size,
		atomic.LoadInt64(&fi.Transferred),
		atomic.LoadInt64(&fi.Rate),
	))

	fi.activeChunks.Range(func(_, value any) bool {
		if chunk, ok := value.(*ChunkInfo); ok && chunk != nil {
			chunk.publishProgress()
		}
		return true
	})
}

// 将文件切分成指定大小的分片
func (fi *FileInfo) loadChunks(chunkSize int, strategy downloadStrategy) {
	if atomic.LoadInt64(&fi.Transferred) != 0 {
		fi.setTransferred(0)
	}
	chunks := make([]*ChunkInfo, 0)

	if strategy == strategyResume {
		progress, err := loadProgress(fi.ProgressPath)
		if err == nil {
			loadedChunks := normalizeProgressChunks(fi, progress.Chunks, chunkSize)
			for _, chunk := range loadedChunks {
				transferred := chunk.Transferred
				chunk.Transferred = 0
				chunk.RestoreTransferred(transferred)
			}
			fi.replaceChunks(loadedChunks)
			return
		}
		fi.logger.Warn("加载进度文件失败", "progress_file", fi.ProgressPath, "err", err)
	}

	fileSize := fi.Size
	if fileSize < 0 || chunkSize <= 0 {
		return
	}
	numChunks := int(fileSize / int64(chunkSize))
	if fileSize%int64(chunkSize) != 0 {
		numChunks++
	}
	for i := 0; i < numChunks; i++ {
		start := int64(i * chunkSize)
		end := start + int64(chunkSize) - 1
		if end >= fileSize {
			end = fileSize - 1
		}
		chunk := NewChunkInfo(fi, i, start, end)
		chunks = append(chunks, chunk)

		if strategy == strategyVerify {
			chunk.RestoreTransferred(chunk.ChunkSize)
		}
	}
	fi.replaceChunks(chunks)
}

func normalizeProgressChunks(fi *FileInfo, progressChunks []*ChunkInfo, chunkSize int) []*ChunkInfo {
	chunks := buildFreshChunks(fi, chunkSize)
	if len(chunks) == 0 {
		return chunks
	}

	byIndex := make(map[int]*ChunkInfo, len(chunks))
	for _, chunk := range chunks {
		byIndex[chunk.Index] = chunk
	}

	for _, saved := range progressChunks {
		if saved == nil {
			continue
		}
		chunk, ok := byIndex[saved.Index]
		if !ok || saved.StartOffset != chunk.StartOffset || saved.EndOffset != chunk.EndOffset {
			fi.logger.Warn("忽略不匹配的进度分片",
				"progress_file", fi.ProgressPath,
				"index", saved.Index,
				"start_offset", saved.StartOffset,
				"end_offset", saved.EndOffset)
			continue
		}

		transferred := saved.Transferred
		if transferred < 0 {
			transferred = 0
		}
		if transferred > chunk.ChunkSize {
			fi.logger.Warn("进度分片已传输字节超过分片大小，已截断",
				"progress_file", fi.ProgressPath,
				"index", saved.Index,
				"transferred", saved.Transferred,
				"chunk_size", chunk.ChunkSize)
			transferred = chunk.ChunkSize
		}
		chunk.Transferred = transferred
		chunk.Checksum = saved.Checksum
		chunk.Completed = transferred == chunk.ChunkSize && saved.Completed
	}

	return chunks
}

func buildFreshChunks(fi *FileInfo, chunkSize int) []*ChunkInfo {
	fileSize := fi.Size
	if fileSize < 0 || chunkSize <= 0 {
		return nil
	}

	numChunks := int(fileSize / int64(chunkSize))
	if fileSize%int64(chunkSize) != 0 {
		numChunks++
	}
	chunks := make([]*ChunkInfo, 0, numChunks)
	for i := 0; i < numChunks; i++ {
		start := int64(i * chunkSize)
		end := start + int64(chunkSize) - 1
		if end >= fileSize {
			end = fileSize - 1
		}
		chunks = append(chunks, NewChunkInfo(fi, i, start, end))
	}
	return chunks
}

// 根据分片信息生成整体文件的校验和
// 算法: 对所有分片checksum(hex字符串)解码为原始二进制hash值,按序写入hasher再计算最终hash
func (fi *FileInfo) genHashByChunkInfo() error {
	hasher := xxh3.New()
	for _, chunk := range fi.chunksSnapshot() {
		// 将hex字符串解码为原始二进制hash值 (16字节)
		hashBytes, err := hex.DecodeString(chunk.Checksum)
		if err != nil {
			return fmt.Errorf("failed to decode chunk checksum: %w", err)
		}
		// 将原始二进制hash值写入最终hasher
		hasher.Write(hashBytes)
	}
	hashBytes := hasher.Sum128().Bytes()
	fi.OverallChecksum = hex.EncodeToString(hashBytes[:])
	return nil
}

type downloadStrategy int

const (
	strategyRestart downloadStrategy = iota // 重新下载
	strategyResume                          // 断点续传，
	strategyVerify                          // 跳过下载，但是需要校验
)

// pathExists 检查路径是否存在
func pathExists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

// isFileComplete 只检查是否具有预期大小，用于选择后续校验策略。
// 稀疏文件可能在下载前已有完整逻辑大小，成功状态仍须由内容校验决定。
func isFileComplete(fullpath string, file *FileInfo) bool {
	fi, err := os.Stat(fullpath)
	if err != nil {
		return false
	}
	return fi.Size() == file.Size
}
func (fi *FileInfo) retryPrepare() error {
	fi.setTransferred(0) // 校验失败，重置已传输字节数
	fi.Verified = false
	_ = os.Remove(fi.ProgressPath)
	if fi.File != nil {
		if err := fi.File.Truncate(0); err != nil {
			return err
		}
		if err := fi.prepareLocalFile(fi.File); err != nil {
			return err
		}
	}
	fi.loadChunks(CHUNKSIZE, strategyRestart)
	return nil
}

func (fi *FileInfo) hasIntegrityResult() bool {
	return fi.Verified
}

func (fi *FileInfo) refreshDownloadGrant(ctx context.Context) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	files, err := fi.dt.authorizeSelections([]*FileInfo{fi})
	if err != nil {
		return fmt.Errorf("refresh download grant for %s: %w", fi.ObjectKey, err)
	}
	if len(files) != 1 {
		return fmt.Errorf("refresh download grant for %s: expected exactly 1 file, got %d", fi.ObjectKey, len(files))
	}
	granted := files[0]
	if !granted.Authorized {
		return fmt.Errorf("refresh download grant for %s: file was not authorized", fi.ObjectKey)
	}
	if granted.ObjectKey != fi.ObjectKey {
		return fmt.Errorf("refresh download grant for %s: response object_key changed to %s", fi.ObjectKey, granted.ObjectKey)
	}
	if granted.Size != fi.Size {
		return fmt.Errorf("%w: %s size changed from %d to %d", ErrRemoteFileChanged, fi.ObjectKey, fi.Size, granted.Size)
	}
	fi.Grant = granted.Grant
	fi.Authorized = true
	fi.grantGeneration++
	fi.logger.Warn("下载临时授权已刷新", "object_key", fi.ObjectKey, "generation", fi.grantGeneration)
	return nil
}

// determineDownloadStrategy 决定下载策略
// 逻辑:
// 1. 文件不存在 -> 重新下载（清理可能存在的进度文件）
// 2. 文件存在 + 进度存在 -> 断点续传
// 3. 文件存在 + 无进度 -> 检查完整性
//   - 大小匹配 -> 先校验内容，失败后重新下载
//   - 大小不匹配 -> 重新下载
func (fi *FileInfo) determineDownloadStrategy() downloadStrategy {
	fileExists := pathExists(fi.FullPath)
	progressExists := pathExists(fi.ProgressPath)

	// 文件不存在 -> 重新下载（清理可能存在的进度文件）
	if !fileExists {
		if progressExists {
			if err := os.Remove(fi.ProgressPath); err != nil {
				fi.logger.Warn("删除旧进度文件失败", "progress_file", fi.ProgressPath, "err", err)
			}
		}
		return strategyRestart
	}

	// 文件存在 + 进度存在 -> 断点续传
	if progressExists {
		return strategyResume
	}

	// 文件存在 + 无进度 -> 检查完整性
	if isFileComplete(fi.FullPath, fi) {
		return strategyVerify
	} else {
		// 文件存在但不完整，无进度 -> 重新下载
		fi.logger.Debug("文件存在但不完整且无进度文件，将重新下载", "file", fi.LocalPath)
		return strategyRestart
	}
}

func (fi *FileInfo) CreateParentDirIfNotExist() error {
	if dir := filepath.Dir(fi.FullPath); dir != "" {
		if err := os.MkdirAll(dir, 0755); err != nil {
			fi.logger.Error("create parent directory failed", "dir", dir, "err", err)
			fi.LastErr = clienterror.New(clienterror.CodeLocalPathInvalid, "无法创建本地下载目录："+dir, err)
			return fi.LastErr
		}
	}
	return nil
}
func (fi *FileInfo) downloadAndVerify(ctx context.Context) error {
	prepared := false
	for {
		if ctx.Err() != nil {
			return context.Canceled
		}
		if !prepared {
			if err := fi.prepareDownloadChunks(ctx); err != nil {
				return err
			}
			prepared = true
		}

		// 执行下载
		err := fi.download(ctx)
		if err != nil {
			if errors.Is(err, context.Canceled) {
				return context.Canceled
			}
			fi.logger.Error("downloadRun failed", "err", err)
			if errors.Is(err, ErrAuthFailed) {
				return err
			}
			if isDownloadGrantExpiredError(err) {
				fi.publishStatus(types.FileEventStatusRetrying)
				if refreshErr := fi.refreshDownloadGrant(ctx); refreshErr != nil {
					return refreshErr
				}
				if !sleepWithContext(ctx, 200*time.Millisecond) {
					return context.Canceled
				}
				continue
			}
			if isPermanentDownloadError(err) {
				return err
			}
			// Chunk and control requests already apply the bounded retry policy.
			// Returning here prevents a file-level loop from silently starting a
			// fresh, unbounded retry window.
			return err
		}

		if ctx.Err() != nil {
			return context.Canceled
		}

		err = fi.verify()
		if err != nil {
			if errors.Is(err, context.Canceled) {
				return context.Canceled
			}
			fi.logger.Error("verify failed", "err", err, "file hash", fi.OverallChecksum)
			if errors.Is(err, ErrAuthFailed) {
				return err
			}
			if !errors.Is(err, ErrIntegrityCheckFailed) {
				return err
			}
			if fi.hashMismatchRetries >= 1 {
				return fmt.Errorf("%w after one full retry: %s", ErrIntegrityCheckFailed, fi.ObjectKey)
			}
			fi.hashMismatchRetries++
			fi.publishStatus(types.FileEventStatusRetrying)
			if retryErr := fi.retryPrepare(); retryErr != nil {
				return retryErr
			}
			prepared = false
			continue // 校验出错就重新下载
		}
		if fi.hasIntegrityResult() {
			fi.dt.VerifiedFileNum.Add(1)
			return nil
		} else {
			if !sleepWithContext(ctx, 5*time.Second) {
				return context.Canceled
			}
		}
	}
}

/*
流程梳理:
1. 加载进度, 决定下载策略
2. 启动进度保存tracker
3. 执行下载
4. 校验文件
*/
func (fi *FileInfo) Download(ctx context.Context) error {
	defer atomic.StoreInt64(&fi.Rate, 0)
	defer func() {
		if fi.File != nil {
			fi.File.Close()
		}
	}()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	fi.ctx = ctx
	fi.cancel = cancel

	err := fi.downloadPrepare()
	if err != nil {
		fi.logger.Error("downloadPrepare failed", "err", err)
		if !errors.Is(err, context.Canceled) {
			fi.publishStatus(types.FileEventStatusFailed, err)
		}
		return err
	}
	fi.dt.TransferingFiles.Store(fi.LocalPath, fi)
	defer fi.dt.TransferingFiles.Delete(fi.LocalPath)

	trackwg := sync.WaitGroup{}
	trackwg.Add(1)
	go func() {
		defer trackwg.Done()
		if err := fi.trackProgress(); err != nil {
			fi.logger.Error("trackProgress failed", "err", err)
		}
	}()

	defer func() {
		trackwg.Wait()
	}()
	fi.publishStatus(types.FileEventStatusStarted)

	err = fi.downloadAndVerify(ctx)
	cancel() // 通知 tracker 退出
	trackwg.Wait()
	if err != nil {
		if errors.Is(err, context.Canceled) {
			return err
		}
		fi.logger.Error("downloadRun failed", "err", err)
		fi.publishStatus(types.FileEventStatusFailed, err)
		return err
	}
	fi.publishStatus(types.FileEventStatusCompleted)
	return nil
}

func (fi *FileInfo) downloadPrepare() error {
	err := fi.CreateParentDirIfNotExist()
	if err != nil {
		return err
	}

	// 决定下载策略
	strategy := fi.determineDownloadStrategy()
	fi.logger.Info("文件下载策略确定", "file", fi.LocalPath, "strategy", strategy)
	fi.loadChunks(CHUNKSIZE, strategy)
	fi.logger.Debug("文件分片信息已加载", slog.Any("chunks", fi.chunksSnapshot()))

	f, err := os.OpenFile(fi.FullPath, os.O_RDWR|os.O_CREATE, 0644)
	if err != nil {
		fi.logger.Error("open file failed", "file", fi.FullPath, "err", err)
		return clienterror.New(clienterror.CodeLocalPathInvalid, "无法打开本地下载目标："+fi.FullPath, err)
	}
	if err := fi.prepareLocalFile(f); err != nil {
		_ = f.Close()
		return err
	}
	fi.File = f

	return nil
}

func (fi *FileInfo) prepareDownloadChunks(ctx context.Context) error {
	for _, chunk := range fi.chunksSnapshot() {
		if _, err := chunk.DownloadPrepare(ctx, fi); err != nil {
			return err
		}
	}
	return nil
}

// executeDownload 执行一轮实际下载。每轮拥有独立context，首个错误只取消本轮请求。
func (fi *FileInfo) download(ctx context.Context) error {
	chunks := fi.chunksSnapshot()
	pending := make([]*ChunkInfo, 0, len(chunks))
	for _, chunk := range chunks {
		if chunk.Completed {
			continue
		}
		if atomic.LoadInt64(&chunk.Transferred) == chunk.ChunkSize {
			chunk.Completed = true
			chunk.publishProgress()
			chunk.publishStatus(types.ChunkEventStatusCompleted)
			continue
		}
		pending = append(pending, chunk)
	}
	roundCtx, cancelRound := context.WithCancelCause(ctx)
	defer cancelRound(nil)
	download := func(chunk *ChunkInfo, register bool, registered func()) error {
		err := chunk.Download(roundCtx, register, registered)
		if err != nil {
			cancelRound(err)
		}
		return err
	}
	firstErr := runDownloadChunkSchedule(roundCtx, pending, fi.dt.chunkSlots, !fi.logRegistrationConfirmed.Load(), download)
	fi.logger.Debug("executeDownload completed")
	if err := ctx.Err(); err != nil {
		return err
	}
	if cause := context.Cause(roundCtx); cause != nil {
		return cause
	}
	if firstErr != nil {
		return firstErr
	}
	return nil
}

func runDownloadChunkSchedule(
	ctx context.Context,
	chunks []*ChunkInfo,
	slots netclient.ChunkSlots,
	needsRegistration bool,
	download func(*ChunkInfo, bool, func()) error,
) error {
	if len(chunks) == 0 {
		return nil
	}
	pending := append([]*ChunkInfo(nil), chunks...)
	results := make(chan error, len(chunks))
	var wait sync.WaitGroup
	consumedResults := 0
	launch := func(chunk *ChunkInfo, register bool, registered func()) bool {
		if err := slots.Acquire(ctx); err != nil {
			return false
		}
		wait.Add(1)
		go func() {
			defer wait.Done()
			defer slots.Release()
			results <- download(chunk, register, registered)
		}()
		return true
	}
	launched := 0
	if needsRegistration {
		registrationIndex := 0
		for index := 1; index < len(pending); index++ {
			if pending[index].Index < pending[registrationIndex].Index {
				registrationIndex = index
			}
		}
		registrationChunk := pending[registrationIndex]
		pending = append(pending[:registrationIndex], pending[registrationIndex+1:]...)
		registered := make(chan struct{})
		var registeredOnce sync.Once
		if !launch(registrationChunk, true, func() { registeredOnce.Do(func() { close(registered) }) }) {
			return ctx.Err()
		}
		launched++
		select {
		case <-ctx.Done():
			wait.Wait()
			return ctx.Err()
		case err := <-results:
			consumedResults++
			if err != nil {
				wait.Wait()
				return err
			}
		case <-registered:
		}
	}
	for _, chunk := range pending {
		if !launch(chunk, false, nil) {
			break
		}
		launched++
	}
	wait.Wait()
	close(results)
	var firstErr error
	for index := consumedResults; index < launched; index++ {
		if err := <-results; err != nil && firstErr == nil {
			firstErr = err
		}
	}
	if firstErr != nil {
		return firstErr
	}
	return ctx.Err()
}

// 信任分片已经下载并正确计算hash
func (fi *FileInfo) verify() error {
	err := fi.genHashByChunkInfo()
	if err != nil {
		return err
	}
	return fi.verifyKnownHash(fi.ctx)
}

func (fi *FileInfo) verifyKnownHash(ctx context.Context) error {
	if ctx == nil {
		ctx = context.Background()
	}
	authRetryCount := 0
	retryState := newDownloadControlRetryState()
	var lastTransportErr error
	for {
		select {
		case <-ctx.Done():
			fi.logger.Debug("下载文件已取消, 校验退出")
			return context.Canceled
		default:
		}

		url, err := qtserverurl.JoinEndpoint(fi.dt.ServerAddr, "/d/verify")
		if err != nil {
			return err
		}
		client, releaseClient, err := fi.dt.acquireClient(ctx, url)
		if err != nil {
			fi.logger.Error("Verify获取客户端失败", slog.String("error", err.Error()))
			return err
		}
		bearerToken := ""
		if fi.dt.downloadUser() == types.DownloadUserSelf {
			bearerToken, err = fi.dt.currentBearerToken()
			if err != nil {
				releaseClient()
				return err
			}
		}
		reqBody := types.DownloadVerifyRequest{
			TaskID:    fi.dt.qtserverTaskID(),
			ObjectKey: fi.ObjectKey,
			FileHash:  fi.OverallChecksum,
		}
		reqBodyBytes, err := json.Marshal(reqBody)
		if err != nil {
			releaseClient()
			fi.logger.Error("Verify请求体序列化失败", slog.String("error", err.Error()))
			return err
		}

		req, err := http.NewRequestWithContext(ctx, "POST", url, bytes.NewReader(reqBodyBytes))
		if err != nil {
			releaseClient()
			fi.logger.Error("Verify创建请求失败", slog.String("error", err.Error()))
			return err
		}
		req.Header.Set("Content-Type", "application/json")
		qtserverapi.SetTaskCorrelationHeaders(req.Header, fi.dt.taskCorrelation())
		includeMetadata := !fi.logRegistrationConfirmed.Load()
		if includeMetadata {
			clientID, clientIDErr := version.CurrentClientID()
			if clientIDErr != nil {
				releaseClient()
				return fmt.Errorf("load client id: %w", clientIDErr)
			}
			req.Header.Set("Client-ID", clientID)
			req.Header.Set("Client-OS", runtime.GOOS)
			req.Header.Set("Client-Version", version.Version)
			req.Header.Set("Caller-Version", fi.dt.CallerVersion)
		}
		setBearerAuthorizationHeader(req, bearerToken)

		resp, err := client.Do(req)
		releaseClient()
		if err != nil {
			requestErr := fmt.Errorf("verify request failed: %w", err)
			retry, waitErr := retryDownloadControlTransport(ctx, fi.logger, "verify downloaded file", &retryState, requestErr)
			if waitErr != nil {
				return waitErr
			}
			if retry {
				lastTransportErr = requestErr
				continue
			}
			fi.logger.Error("Verify请求失败", slog.String("error", requestErr.Error()))
			return requestErr
		}
		logDownloadControlTransportRecovered(fi.logger, "verify downloaded file", retryState, lastTransportErr)

		body, err := io.ReadAll(resp.Body)
		_ = resp.Body.Close()
		if err != nil {
			requestErr := fmt.Errorf("read verify response: %w", err)
			retry, waitErr := retryDownloadControlTransport(ctx, fi.logger, "verify downloaded file", &retryState, requestErr)
			if waitErr != nil {
				return waitErr
			}
			if retry {
				lastTransportErr = requestErr
				continue
			}
			fi.logger.Error("读取Verify响应失败", slog.String("error", requestErr.Error()))
			return requestErr
		}

		if isHTTPAuthorizationFailure(resp.StatusCode) {
			retryState.reset()
			lastTransportErr = nil
			message := strings.TrimSpace(string(body))
			var authResp types.DownloadVerifyResponse
			if err := json.Unmarshal(body, &authResp); err == nil && strings.TrimSpace(authResp.Message) != "" {
				message = strings.TrimSpace(authResp.Message)
			}
			httpErr := fmt.Errorf("verify failed with status %d: %s", resp.StatusCode, message)
			if authRetryCount < downloadAuthRetryMaxRefreshes && fi.dt.refreshAuthorizationAfter401(ctx, resp.StatusCode) {
				authRetryCount++
				continue
			}
			return fi.dt.authFailedErr(httpErr, bearerToken, resp.StatusCode)
		}
		if includeMetadata && (resp.StatusCode == http.StatusOK || resp.StatusCode == http.StatusAccepted) {
			fi.logRegistrationConfirmed.Store(true)
		}
		if retry, waitErr := retryDownloadControlHTTP(ctx, &retryState, resp.StatusCode, resp.Header); waitErr != nil {
			return waitErr
		} else if retry {
			continue
		}
		retryState.reset()
		lastTransportErr = nil

		var verifyResp types.DownloadVerifyResponse
		if err := json.Unmarshal(body, &verifyResp); err != nil {
			fi.logger.Error("解析Verify响应失败", slog.String("error", err.Error()))
			return err
		}
		if resp.StatusCode == http.StatusAccepted && verifyResp.ReasonCode == "HASH_PENDING" {
			if !sleepWithContext(ctx, 5*time.Second) {
				return context.Canceled
			}
			continue
		}

		if resp.StatusCode == http.StatusOK && verifyResp.Match {
			fi.Verified = true
			fi.logger.Debug("文件校验成功")
			return nil
		}
		if resp.StatusCode == http.StatusOK && !verifyResp.Match {
			return ErrIntegrityCheckFailed
		}

		fi.logger.Error("文件校验失败",
			"status", resp.StatusCode,
			"match", verifyResp.Match,
			"expected", verifyResp.ExpectedHash,
			"calculated", verifyResp.CalculatedHash)
		return fmt.Errorf("verify failed: %s", verifyResp.Message)
	}
}

func sleepWithContext(ctx context.Context, d time.Duration) bool {
	timer := time.NewTimer(d)
	defer timer.Stop()

	select {
	case <-ctx.Done():
		return false
	case <-timer.C:
		return true
	}
}

// 保存文件的传输进度
// TODO: 文件进度有选择性的保存
func (fi *FileInfo) saveProgressFile() error {
	fi.chunksMu.RLock()
	defer fi.chunksMu.RUnlock()
	data, err := json.MarshalIndent(fi, "", "  ")
	if err != nil {
		return err
	}
	err = os.WriteFile(fi.ProgressPath, data, 0644)
	if err != nil {
		return err
	}
	return nil
}

// TODO: 文件进度有选择性的保存
func loadProgress(progressPath string) (*FileInfo, error) {
	fi := &FileInfo{}
	data, err := os.ReadFile(progressPath)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(data, fi)
	if err != nil {
		return nil, err
	}
	return fi, nil
}

//// 定时任务: 1. 保存进度 2. 计算传输速率
//func (fi *FileInfo) trackProgress() error {
//	saveTicker := time.NewTicker(time.Duration(fi.trackInterval) * time.Second)
//	reportTicker := time.NewTicker(5 * time.Second) // 定期上报进度事件
//	defer saveTicker.Stop()
//	defer reportTicker.Stop()
//
//	for {
//		select {
//		case <-reportTicker.C:
//			eventcollector.PublishEvent(types.TaskEvent{
//				EventType:       types.EventTypeFileStatus,
//				TaskID:          fi.dt.TaskID,
//				FilePath:        fi.LocalPath,
//				FileTransferred: fi.Transferred,
//				FileSize:        fi.Size,
//				FileRate:        fi.Rate,
//			})
//		case <-saveTicker.C:
//			if err := fi.saveProgressFile(); err != nil {
//				fi.logger.Error("定期保存文件进度失败", "err", err)
//				// 不返回，继续尝试下次保存
//			}
//			fi.updateRate()
//
//		case <-fi.ctx.Done():
//			if fi.hasIntegrityResult() { // 文件下载成功完成，删除进度文件
//				if err := os.Remove(fi.ProgressPath); err != nil && !os.IsNotExist(err) {
//					fi.logger.Error("删除进度文件失败",
//						"file", fi.LocalPath,
//						"progress_file", fi.ProgressPath,
//						"err", err)
//				}
//			} else { // 文件未下载完成，保存最终进度
//				if err := fi.saveProgressFile(); err != nil {
//					fi.logger.Error("保存最终文件进度失败", "err", err)
//				}
//			}
//			return nil
//		}
//	}
//}

// 定时保存断点续传进度；实时速率由任务级采样器维护。
func (fi *FileInfo) trackProgress() error {
	saveTicker := time.NewTicker(time.Duration(fi.trackInterval) * time.Second)
	defer saveTicker.Stop()

	for {
		select {
		case <-saveTicker.C:
			if err := fi.saveProgressFile(); err != nil {
				fi.logger.Error("定期保存文件进度失败", "err", err)
				// 不返回，继续尝试下次保存
			}

		case <-fi.ctx.Done():
			fi.publishProgressEvents(true)
			if fi.hasIntegrityResult() { // 文件下载成功完成，删除进度文件
				if err := os.Remove(fi.ProgressPath); err != nil && !os.IsNotExist(err) {
					fi.logger.Error("删除进度文件失败",
						"file", fi.LocalPath,
						"progress_file", fi.ProgressPath,
						"err", err)
				}
			} else { // 文件未下载完成，保存最终进度
				if err := fi.saveProgressFile(); err != nil {
					fi.logger.Error("保存最终文件进度失败", "err", err)
				}
			}
			return nil
		}
	}
}

// ToFileInfoDetail converts a task file to API view.
func (fi *FileInfo) ToFileInfoDetail() *types.FileInfoDetail {
	chunkSnapshot := fi.chunksSnapshot()
	chunks := make([]*types.ChunkInfoDetail, 0, len(chunkSnapshot))
	for _, chunk := range chunkSnapshot {
		chunks = append(chunks, chunk.ToChunkInfoDetail())
	}

	return &types.FileInfoDetail{
		Src: fi.copySource(), Dst: fi.copyDestination(),
		Cause:           fi.failure.Cause(),
		LocalPath:       fi.LocalPath,
		RemotePath:      fi.RemotePath,
		Authorized:      fi.Authorized,
		Size:            fi.Size,
		Transferred:     atomic.LoadInt64(&fi.Transferred),
		Rate:            atomic.LoadInt64(&fi.Rate),
		OverallChecksum: fi.OverallChecksum,
		Received:        fi.Received,
		Verified:        fi.Verified,
		Chunks:          chunks,
	}
}

func (fi *FileInfo) ToFileInfoSummary() *types.FileInfoSummary {
	return &types.FileInfoSummary{
		Src: fi.copySource(), Dst: fi.copyDestination(),
		Cause:           fi.failure.Cause(),
		LocalPath:       fi.LocalPath,
		RemotePath:      fi.RemotePath,
		Authorized:      fi.Authorized,
		Size:            fi.Size,
		Transferred:     atomic.LoadInt64(&fi.Transferred),
		Rate:            atomic.LoadInt64(&fi.Rate),
		OverallChecksum: fi.OverallChecksum,
		Received:        fi.Received,
		Verified:        fi.Verified,
	}
}

func (fi *FileInfo) copySource() string {
	if fi.dt != nil && len(fi.dt.pathMappings) > 0 {
		return fi.ObjectKey
	}
	return ""
}
func (fi *FileInfo) copyDestination() string {
	if fi.dt != nil && len(fi.dt.pathMappings) > 0 {
		return fi.FullPath
	}
	return ""
}
