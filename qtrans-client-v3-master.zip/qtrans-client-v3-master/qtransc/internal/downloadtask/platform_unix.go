//go:build !windows

package downloadtask

import (
	"fmt"
	"syscall"

	"golang.org/x/sys/unix"
)

// checkAccessWritable uses unix.Access to verify write permission efficiently.
func checkAccessWritable(dir string) error {
	if err := unix.Access(dir, unix.W_OK); err != nil {
		return fmt.Errorf("target dir is not writable: %w", err)
	}
	return nil
}

// availableDiskSpace returns the number of bytes available on the
// filesystem containing dir.
func availableDiskSpace(dir string) (int64, error) {
	var st syscall.Statfs_t
	if err := syscall.Statfs(dir, &st); err != nil {
		return 0, fmt.Errorf("statfs failed: %w", err)
	}
	return int64(st.Bavail) * int64(st.Bsize), nil
}
