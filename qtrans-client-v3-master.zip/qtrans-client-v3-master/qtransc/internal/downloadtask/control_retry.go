package downloadtask

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"
	"time"

	"qtransc/internal/transferretry"
)

type downloadControlRetryState struct {
	backoff       *transferretry.Backoff
	attempts      int
	http500Budget transferretry.HTTP500Budget
}

func newDownloadControlRetryState() downloadControlRetryState {
	return downloadControlRetryState{backoff: transferretry.NewBackoff()}
}

func (s *downloadControlRetryState) reset() {
	s.attempts = 0
	s.http500Budget.Reset()
	s.backoff = transferretry.NewBackoff()
}

func (s *downloadControlRetryState) nextDelay(header http.Header) time.Duration {
	if s.backoff == nil {
		s.backoff = transferretry.NewBackoff()
	}
	s.attempts++
	return s.backoff.Next(header, time.Now())
}

func retryDownloadControlTransport(ctx context.Context, logger *slog.Logger, operation string, retryState *downloadControlRetryState, err error) (bool, error) {
	if err == nil || !transferretry.IsAvailabilityError(ctx, err) {
		return false, nil
	}

	delay := retryState.nextDelay(nil)
	if logger != nil && (retryState.attempts == 1 || retryState.attempts%downloadChunkRetryLogInterval == 0) {
		logger.Warn("control request failed with retryable transport error, retrying",
			"operation", operation,
			"retry_count", retryState.attempts,
			"delay", delay.String(),
			"err", err)
	}

	if waitErr := transferretry.Wait(ctx, delay); waitErr != nil {
		return false, waitErr
	}
	return true, nil
}

func retryDownloadControlHTTP(ctx context.Context, retryState *downloadControlRetryState, status int, header http.Header) (bool, error) {
	if status == http.StatusInternalServerError {
		if !retryState.http500Budget.Take() {
			return false, fmt.Errorf("HTTP 500 retry limit reached after %d retries", retryState.http500Budget.Retries())
		}
	} else if !transferretry.IsAvailabilityStatus(status) {
		return false, nil
	}
	delay := retryState.nextDelay(header)
	if err := transferretry.Wait(ctx, delay); err != nil {
		return false, err
	}
	return true, nil
}

func logDownloadControlTransportRecovered(logger *slog.Logger, operation string, retryState downloadControlRetryState, lastErr error) {
	if logger == nil || retryState.attempts == 0 {
		return
	}
	logger.Info("control request recovered after retryable transport errors",
		"operation", operation,
		"retries", retryState.attempts,
		"last_error", lastErr)
}
