package downloadtask

import (
	"archive/tar"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	"qtransc/internal/filehash"
	"qtransc/internal/netclient"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/transferretry"
	"qtransc/internal/types"
	"qtransc/internal/version"

	"github.com/google/uuid"
)

const (
	smallV2Version         = 2
	smallV2ManifestPath    = ".qtrans/manifest.json"
	smallV2ChecksumsPath   = ".qtrans/checksums.json"
	smallV2MaxControlBytes = 1 << 20
	smallV2MaxHashFailures = 3
	smallV2BatchIDHeader   = "X-QT-Small-Batch-ID"
	smallV2AttemptHeader   = "X-QT-Small-Batch-Attempt"
)

const smallV2LayeredHashAlgorithm = types.UploadHashAlgorithmLayeredXXH3_128

type smallV2ResultKind uint8

const (
	smallV2Completed smallV2ResultKind = iota
	smallV2Retry
	smallV2RerouteLarge
	smallV2Terminal
)

type smallV2BatchState struct {
	files             []*FileInfo
	batchID           string
	attempt           int
	authRefreshes     int
	integrityFailures int
	http500Budget     transferretry.HTTP500Budget
	backoff           *transferretry.Backoff
}

type smallV2BatchResult struct {
	state       *smallV2BatchState
	kind        smallV2ResultKind
	err         error
	retryAt     time.Time
	retryClass  string
	rerouteFile *FileInfo
	rerouteSize int64
}

type smallV2DelayedBatch struct {
	state   *smallV2BatchState
	retryAt time.Time
}

type smallV2ProtocolError struct{ err error }

func (e *smallV2ProtocolError) Error() string { return "small v2 protocol error: " + e.err.Error() }
func (e *smallV2ProtocolError) Unwrap() error { return e.err }

type smallV2IncompleteError struct{ err error }

func (e *smallV2IncompleteError) Error() string {
	return "small v2 response incomplete: " + e.err.Error()
}
func (e *smallV2IncompleteError) Unwrap() error { return io.ErrUnexpectedEOF }

type smallV2IntegrityError struct{ err error }

func (e *smallV2IntegrityError) Error() string {
	return "small v2 integrity mismatch: " + e.err.Error()
}
func (e *smallV2IntegrityError) Unwrap() error { return e.err }

type smallV2AttemptFile struct {
	file      *FileInfo
	expected  types.DownloadSmallV2ManifestEntry
	tempPath  string
	temp      *os.File
	hash      string
	active    bool
	published bool
}

func newSmallV2BatchState(files []*FileInfo) *smallV2BatchState {
	return &smallV2BatchState{
		files:   append([]*FileInfo(nil), files...),
		batchID: uuid.NewString(),
		backoff: transferretry.NewBackoff(),
	}
}

func (s *smallV2BatchState) nextRetry(header http.Header) time.Time {
	if s.backoff == nil {
		s.backoff = transferretry.NewBackoff()
	}
	return time.Now().Add(s.backoff.Next(header, time.Now()))
}

func (dt *DownloadTask) downloadScheduledSmallFilesV2(ctx context.Context, files []*FileInfo) error {
	batchFiles := dt.smallBatchFiles
	if batchFiles <= 0 {
		batchFiles = defaultSmallBatchSize
	}
	batchBytes := dt.smallBatchBytes
	if batchBytes <= 0 {
		batchBytes = defaultSmallV2BatchBytes
	}
	batches := chunkSmallDownloadFiles(files, batchFiles, batchBytes)
	if len(batches) == 0 {
		return nil
	}

	ready := make([]*smallV2BatchState, 0, len(batches))
	for _, batch := range batches {
		ready = append(ready, newSmallV2BatchState(batch))
	}
	delayed := make([]smallV2DelayedBatch, 0)
	results := make(chan smallV2BatchResult, max(1, len(batches)))
	active := 0
	var terminalErr error
	var rerouted []*FileInfo

	for len(ready) > 0 || len(delayed) > 0 || active > 0 {
		now := time.Now()
		for len(delayed) > 0 && !delayed[0].retryAt.After(now) {
			ready = append(ready, delayed[0].state)
			delayed = delayed[1:]
		}

		if len(ready) > 0 {
			state := ready[0]
			ready = ready[1:]
			requestURL, err := qtserverurl.JoinEndpoint(dt.ServerAddr, "/d/small-v2")
			if err != nil {
				dt.markSmallV2Terminal(state.files, err)
				terminalErr = errors.Join(terminalErr, err)
				continue
			}
			client, release, err := dt.acquireClient(ctx, requestURL)
			if err != nil {
				if ctx.Err() != nil {
					dt.waitForSmallV2Workers(results, active)
					return ctx.Err()
				}
				dt.markSmallV2Terminal(state.files, err)
				terminalErr = errors.Join(terminalErr, err)
				continue
			}
			state.attempt++
			active++
			go func() {
				result := dt.runSmallV2Attempt(ctx, requestURL, state, client, release)
				// Preserve final failures even when cancellation wins the scheduler select.
				if result.kind == smallV2Terminal && !errors.Is(result.err, context.Canceled) {
					dt.markSmallV2Terminal(result.state.files, result.err)
				}
				results <- result
			}()
			continue
		}

		var retryTimer *time.Timer
		var retryC <-chan time.Time
		if len(delayed) > 0 {
			delay := time.Until(delayed[0].retryAt)
			if delay < 0 {
				delay = 0
			}
			retryTimer = time.NewTimer(delay)
			retryC = retryTimer.C
		}

		select {
		case <-ctx.Done():
			if retryTimer != nil {
				retryTimer.Stop()
			}
			dt.waitForSmallV2Workers(results, active)
			return ctx.Err()
		case <-retryC:
			// The next loop moves all due retries into ready.
		case result := <-results:
			if retryTimer != nil {
				retryTimer.Stop()
			}
			active--
			if ctx.Err() != nil {
				dt.waitForSmallV2Workers(results, active)
				return ctx.Err()
			}
			switch result.kind {
			case smallV2Completed:
				dt.logger.Info("small v2 batch completed",
					"result", "completed",
					"small_batch_id", result.state.batchID,
					"small_attempt", result.state.attempt,
					"file_count", len(result.state.files),
					"total_bytes", sumSmallV2BatchBytes(result.state.files),
					"transport", dt.Transport)
			case smallV2Retry:
				dt.logger.Warn("small v2 batch retry scheduled",
					"result", "retry",
					"small_batch_id", result.state.batchID,
					"small_attempt", result.state.attempt,
					"file_count", len(result.state.files),
					"total_bytes", sumSmallV2BatchBytes(result.state.files),
					"transport", dt.Transport,
					"retry_class", result.retryClass,
					"retry_at", result.retryAt,
					"error", result.err)
				delayed = append(delayed, smallV2DelayedBatch{state: result.state, retryAt: result.retryAt})
				sort.Slice(delayed, func(i, j int) bool { return delayed[i].retryAt.Before(delayed[j].retryAt) })
			case smallV2RerouteLarge:
				if result.rerouteFile == nil {
					err := &smallV2ProtocolError{err: errors.New("NOT_SMALL response omitted a known object_key")}
					dt.markSmallV2Terminal(result.state.files, err)
					terminalErr = errors.Join(terminalErr, err)
					continue
				}
				if result.rerouteSize >= 0 && result.rerouteSize != result.rerouteFile.Size {
					delta := result.rerouteSize - result.rerouteFile.Size
					result.rerouteFile.Size = result.rerouteSize
					dt.TotalSize.Add(delta)
				}
				// A NOT_SMALL response may reflect a changed remote file. Obtain
				// a new grant for the ordinary download instead of reusing metadata's.
				result.rerouteFile.Grant = ""
				rerouted = append(rerouted, result.rerouteFile)
				remaining := make([]*FileInfo, 0, len(result.state.files)-1)
				for _, file := range result.state.files {
					if file != result.rerouteFile {
						remaining = append(remaining, file)
					}
				}
				for _, batch := range chunkSmallDownloadFiles(remaining, batchFiles, batchBytes) {
					ready = append(ready, newSmallV2BatchState(batch))
				}
				dt.logger.Info("small v2 file rerouted to ordinary download",
					"result", "reroute_large",
					"small_batch_id", result.state.batchID,
					"small_attempt", result.state.attempt,
					"file_count", len(result.state.files),
					"total_bytes", sumSmallV2BatchBytes(result.state.files),
					"transport", dt.Transport,
					"rerouted_size", result.rerouteSize)
			case smallV2Terminal:
				dt.logger.Error("small v2 batch reached terminal error",
					"result", "terminal",
					"small_batch_id", result.state.batchID,
					"small_attempt", result.state.attempt,
					"file_count", len(result.state.files),
					"total_bytes", sumSmallV2BatchBytes(result.state.files),
					"transport", dt.Transport,
					"error", result.err)
				dt.markSmallV2Terminal(result.state.files, result.err)
				terminalErr = errors.Join(terminalErr, result.err)
			}
		}
	}

	if len(rerouted) > 0 {
		dt.LargeFiles = append(dt.LargeFiles, rerouted...)
	}
	return terminalErr
}

func (dt *DownloadTask) waitForSmallV2Workers(results <-chan smallV2BatchResult, active int) {
	for active > 0 {
		<-results
		active--
	}
}

func (dt *DownloadTask) runSmallV2Attempt(ctx context.Context, requestURL string, state *smallV2BatchState, client *http.Client, release netclient.ReleaseFunc) smallV2BatchResult {
	defer release()
	result := smallV2BatchResult{state: state}
	reqBody := types.DownloadSmallRequest{TaskID: dt.qtserverTaskID(), Files: make([]types.DownloadObjectRequest, 0, len(state.files))}
	for _, file := range state.files {
		reqBody.Files = append(reqBody.Files, types.DownloadObjectRequest{ObjectKey: file.ObjectKey})
	}
	body, err := json.Marshal(reqBody)
	if err != nil {
		result.kind, result.err = smallV2Terminal, err
		return result
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, requestURL, bytes.NewReader(body))
	if err != nil {
		result.kind, result.err = smallV2Terminal, err
		return result
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set(smallV2BatchIDHeader, state.batchID)
	req.Header.Set(smallV2AttemptHeader, strconv.Itoa(state.attempt))
	qtserverapi.SetTaskCorrelationHeaders(req.Header, dt.taskCorrelation())
	clientID, err := version.CurrentClientID()
	if err != nil {
		result.kind, result.err = smallV2Terminal, err
		return result
	}
	req.Header.Set("Client-ID", clientID)
	req.Header.Set("Client-OS", runtime.GOOS)
	req.Header.Set("Client-Version", version.Version)
	req.Header.Set("Caller-Version", dt.CallerVersion)
	usedToken := ""
	if dt.downloadUser() == types.DownloadUserSelf {
		usedToken, err = dt.currentBearerToken()
		if err != nil {
			result.kind, result.err = smallV2Terminal, err
			return result
		}
		setBearerAuthorizationHeader(req, usedToken)
	}

	dt.logger.Debug("small v2 batch attempt started",
		"small_batch_id", state.batchID,
		"small_attempt", state.attempt,
		"file_count", len(state.files),
		"total_bytes", sumSmallV2BatchBytes(state.files),
		"transport", dt.Transport)
	resp, err := client.Do(req)
	if err != nil {
		if transferretry.IsAvailabilityError(ctx, err) {
			return state.retryResult(err, "availability", nil)
		}
		result.kind, result.err = smallV2Terminal, err
		return result
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		responseBody, readErr := io.ReadAll(io.LimitReader(resp.Body, smallV2MaxControlBytes+1))
		closeErr := resp.Body.Close()
		if readErr == nil {
			readErr = closeErr
		}
		if readErr != nil {
			if transferretry.IsAvailabilityError(ctx, readErr) {
				return state.retryResult(readErr, "availability", resp.Header)
			}
			result.kind, result.err = smallV2Terminal, readErr
			return result
		}
		apiErr, objectKey, fileSize := decodeSmallV2APIError(resp.StatusCode, resp.Header, responseBody)
		if resp.StatusCode == http.StatusUnauthorized {
			if state.authRefreshes < downloadAuthRetryMaxRefreshes && dt.refreshAuthorizationAfter401(ctx, resp.StatusCode) {
				state.authRefreshes++
				return state.retryResult(apiErr, "authorization_refresh", nil)
			}
			result.kind, result.err = smallV2Terminal, dt.authFailedErr(apiErr, usedToken, resp.StatusCode)
			return result
		}
		if resp.StatusCode == http.StatusConflict && qtserverapi.IsReason(apiErr, "NOT_SMALL") {
			if fileSize < 0 {
				result.kind, result.err = smallV2Terminal, &smallV2ProtocolError{err: errors.New("NOT_SMALL response omitted file_size")}
				return result
			}
			for _, file := range state.files {
				if file.ObjectKey == objectKey {
					result.kind, result.rerouteFile, result.rerouteSize = smallV2RerouteLarge, file, fileSize
					return result
				}
			}
			result.kind, result.err = smallV2Terminal, &smallV2ProtocolError{err: fmt.Errorf("NOT_SMALL object_key %q is not in batch", objectKey)}
			return result
		}
		if resp.StatusCode == http.StatusInternalServerError {
			if state.http500Budget.Take() {
				return state.retryResult(apiErr, "http_500", resp.Header)
			}
			result.kind, result.err = smallV2Terminal, fmt.Errorf("small v2 HTTP 500 retry limit reached after %d retries: %w", state.http500Budget.Retries(), apiErr)
			return result
		}
		if transferretry.IsAvailabilityStatus(resp.StatusCode) {
			return state.retryResult(apiErr, "availability", resp.Header)
		}
		result.kind, result.err = smallV2Terminal, apiErr
		return result
	}

	err = dt.consumeSmallV2Tar(ctx, dt.wrapRateLimitedReader(ctx, resp.Body), state)
	if err == nil {
		result.kind = smallV2Completed
		return result
	}
	var integrityErr *smallV2IntegrityError
	if errors.As(err, &integrityErr) {
		state.integrityFailures++
		if state.integrityFailures < smallV2MaxHashFailures {
			return state.retryResult(err, "integrity", nil)
		}
		result.kind = smallV2Terminal
		result.err = fmt.Errorf("%w after three small v2 attempts: %v", ErrIntegrityCheckFailed, err)
		return result
	}
	var protocolErr *smallV2ProtocolError
	var localErr *transferretry.LocalIOError
	if errors.As(err, &protocolErr) || errors.As(err, &localErr) {
		result.kind, result.err = smallV2Terminal, err
		return result
	}
	if transferretry.IsAvailabilityError(ctx, err) {
		return state.retryResult(err, "availability", nil)
	}
	result.kind, result.err = smallV2Terminal, err
	return result
}

func (s *smallV2BatchState) retryResult(err error, retryClass string, header http.Header) smallV2BatchResult {
	return smallV2BatchResult{
		state:      s,
		kind:       smallV2Retry,
		err:        err,
		retryAt:    s.nextRetry(header),
		retryClass: retryClass,
	}
}

func decodeSmallV2APIError(status int, header http.Header, body []byte) (error, string, int64) {
	var envelope struct {
		Code       int    `json:"code"`
		ReasonCode string `json:"reason_code"`
		Message    string `json:"message"`
		ObjectKey  string `json:"object_key"`
		FileSize   *int64 `json:"file_size"`
	}
	if err := json.Unmarshal(body, &envelope); err != nil {
		return &qtserverapi.APIError{Status: status, Body: body, Header: header.Clone()}, "", -1
	}
	fileSize := int64(-1)
	if envelope.FileSize != nil {
		fileSize = *envelope.FileSize
	}
	return &qtserverapi.APIError{
		Status:     status,
		ReasonCode: envelope.ReasonCode,
		Message:    envelope.Message,
		Body:       body,
		Header:     header.Clone(),
	}, envelope.ObjectKey, fileSize
}

func (dt *DownloadTask) consumeSmallV2Tar(ctx context.Context, body io.Reader, state *smallV2BatchState) (returnErr error) {
	stream := &smallV2TarStream{reader: body}
	tr := tar.NewReader(stream)
	header, err := nextSmallV2Header(ctx, tr, "manifest")
	if err != nil {
		return err
	}
	if err := validateSmallV2RegularHeader(header); err != nil {
		return err
	}
	if header.Name != smallV2ManifestPath {
		return &smallV2ProtocolError{err: fmt.Errorf("first entry is %q, want %q", header.Name, smallV2ManifestPath)}
	}
	var manifest types.DownloadSmallV2Manifest
	if err := decodeSmallV2JSONEntry(tr, header, &manifest); err != nil {
		return err
	}
	if err := validateSmallV2Manifest(manifest, dt.qtserverTaskID(), state.files); err != nil {
		return &smallV2ProtocolError{err: err}
	}

	attemptFiles := make([]*smallV2AttemptFile, 0, len(state.files))
	defer func() {
		if returnErr != nil {
			dt.cleanupSmallV2Attempt(attemptFiles)
		}
	}()
	for index, expected := range manifest.Files {
		header, err = nextSmallV2Header(ctx, tr, fmt.Sprintf("payload %d", index))
		if err != nil {
			return err
		}
		if err := validateSmallV2RegularHeader(header); err != nil {
			return err
		}
		if header.Name != expected.ArchivePath || header.Size != expected.Size {
			return &smallV2ProtocolError{err: fmt.Errorf("payload %d header mismatch", index)}
		}
		item, err := dt.receiveSmallV2Payload(ctx, tr, state.files[index], expected)
		if item != nil {
			attemptFiles = append(attemptFiles, item)
		}
		if err != nil {
			return err
		}
	}

	header, err = nextSmallV2Header(ctx, tr, "checksum footer")
	if err != nil {
		return err
	}
	if err := validateSmallV2RegularHeader(header); err != nil {
		return err
	}
	if header.Name != smallV2ChecksumsPath {
		return &smallV2ProtocolError{err: fmt.Errorf("entry after payloads is %q, want %q", header.Name, smallV2ChecksumsPath)}
	}
	var footer types.DownloadSmallV2Checksums
	if err := decodeSmallV2JSONEntry(tr, header, &footer); err != nil {
		return err
	}
	footerErr := validateSmallV2Footer(footer, manifest, attemptFiles)
	if extra, err := tr.Next(); err != io.EOF {
		if err != nil {
			return classifySmallV2StreamError(ctx, "read tar end", err)
		}
		return &smallV2ProtocolError{err: fmt.Errorf("unexpected entry after checksum footer: %q", extra.Name)}
	}
	if !stream.hasEndMarker() {
		return &smallV2IncompleteError{err: errors.New("tar end marker is missing")}
	}
	var trailing [1]byte
	for {
		n, readErr := stream.Read(trailing[:])
		if n > 0 {
			return &smallV2ProtocolError{err: errors.New("unexpected bytes after tar end marker")}
		}
		if errors.Is(readErr, io.EOF) {
			break
		}
		if readErr != nil {
			return classifySmallV2StreamError(ctx, "read response end", readErr)
		}
	}
	if footerErr != nil {
		return footerErr
	}

	for index, item := range attemptFiles {
		if err := ctx.Err(); err != nil {
			return err
		}
		if err := os.Chmod(item.tempPath, 0o644); err != nil {
			return transferretry.WrapLocalIO("chmod small v2 temp file", err)
		}
		if err := os.Rename(item.tempPath, item.file.FullPath); err != nil {
			return transferretry.WrapLocalIO("publish small v2 file", err)
		}
		item.published = true
		dt.smallTempFiles.Delete(item.tempPath)
		item.file.OverallChecksum = item.hash
		item.file.Received = true
		item.file.Verified = true
		dt.VerifiedFileNum.Add(1)
		item.file.publishProgressEvents(true)
		item.file.publishStatus(types.FileEventStatusCompleted)
		dt.TransferingFiles.Delete(item.file.LocalPath)
		atomic.StoreInt64(&item.file.Rate, 0)
		dt.logger.Debug("small v2 file published", "small_batch_id", state.batchID, "small_attempt", state.attempt, "index", index)
	}
	return nil
}

type smallV2TarStream struct {
	reader io.Reader
	tail   [2 * 512]byte
	filled int
	offset int
}

func (s *smallV2TarStream) Read(p []byte) (int, error) {
	n, err := s.reader.Read(p)
	for _, value := range p[:n] {
		s.tail[s.offset] = value
		s.offset = (s.offset + 1) % len(s.tail)
		if s.filled < len(s.tail) {
			s.filled++
		}
	}
	return n, err
}

func (s *smallV2TarStream) hasEndMarker() bool {
	if s == nil || s.filled < len(s.tail) {
		return false
	}
	for _, value := range s.tail {
		if value != 0 {
			return false
		}
	}
	return true
}

func (dt *DownloadTask) receiveSmallV2Payload(ctx context.Context, tr *tar.Reader, file *FileInfo, expected types.DownloadSmallV2ManifestEntry) (*smallV2AttemptFile, error) {
	if err := file.CreateParentDirIfNotExist(); err != nil {
		return nil, transferretry.WrapLocalIO("create small v2 target directory", err)
	}
	temp, err := os.CreateTemp(filepath.Dir(file.FullPath), ".qtrans-small-*")
	if err != nil {
		return nil, transferretry.WrapLocalIO("create small v2 temp file", err)
	}
	item := &smallV2AttemptFile{file: file, expected: expected, tempPath: temp.Name(), temp: temp, active: true}
	dt.smallTempFiles.Store(item.tempPath, struct{}{})
	dt.TransferingFiles.Store(file.LocalPath, file)
	file.publishStatus(types.FileEventStatusStarted)
	hasher := filehash.NewLayeredHasher()
	buffer := make([]byte, 64*1024)
	var written int64
	for {
		if err := ctx.Err(); err != nil {
			_ = temp.Close()
			item.temp = nil
			return item, err
		}
		n, readErr := tr.Read(buffer)
		if n > 0 {
			if _, writeErr := temp.Write(buffer[:n]); writeErr != nil {
				_ = temp.Close()
				item.temp = nil
				return item, transferretry.WrapLocalIO("write small v2 temp file", writeErr)
			}
			if _, hashErr := hasher.Write(buffer[:n]); hashErr != nil {
				_ = temp.Close()
				item.temp = nil
				return item, hashErr
			}
			file.addSmallPayload(int64(n))
			written += int64(n)
		}
		if readErr == io.EOF {
			break
		}
		if readErr != nil {
			_ = temp.Close()
			item.temp = nil
			return item, classifySmallV2StreamError(ctx, "read payload", readErr)
		}
	}
	if err := temp.Close(); err != nil {
		item.temp = nil
		return item, transferretry.WrapLocalIO("close small v2 temp file", err)
	}
	item.temp = nil
	if written != expected.Size {
		return item, &smallV2IntegrityError{err: fmt.Errorf("payload %d size is %d, want %d", expected.Index, written, expected.Size)}
	}
	hash, err := hasher.Finalize()
	if err != nil {
		return item, err
	}
	item.hash = hash
	return item, nil
}

func (dt *DownloadTask) cleanupSmallV2Attempt(files []*smallV2AttemptFile) {
	for _, item := range files {
		if item == nil || item.published {
			continue
		}
		if item.temp != nil {
			_ = item.temp.Close()
			item.temp = nil
		}
		if item.tempPath != "" {
			_ = os.Remove(item.tempPath)
			dt.smallTempFiles.Delete(item.tempPath)
		}
		if item.file != nil && !item.file.Verified {
			item.file.setTransferred(0)
			atomic.StoreInt64(&item.file.Rate, 0)
			if item.active {
				item.file.publishProgressEvents(true)
			}
			dt.TransferingFiles.Delete(item.file.LocalPath)
		}
	}
}

func (dt *DownloadTask) markSmallV2Terminal(files []*FileInfo, err error) {
	for _, file := range files {
		if file == nil || file.Verified {
			continue
		}
		file.LastErr = err
		file.publishProgressEvents(true)
		file.publishStatus(types.FileEventStatusFailed, err)
		dt.TransferingFiles.Delete(file.LocalPath)
		atomic.StoreInt64(&file.Rate, 0)
	}
}

func nextSmallV2Header(ctx context.Context, tr *tar.Reader, stage string) (*tar.Header, error) {
	header, err := tr.Next()
	if err == nil {
		return header, nil
	}
	if errors.Is(err, io.EOF) {
		return nil, &smallV2IncompleteError{err: fmt.Errorf("missing %s", stage)}
	}
	return nil, classifySmallV2StreamError(ctx, "read "+stage, err)
}

func validateSmallV2RegularHeader(header *tar.Header) error {
	if header == nil {
		return &smallV2ProtocolError{err: errors.New("tar entry header is missing")}
	}
	if header.Typeflag != tar.TypeReg && header.Typeflag != tar.TypeRegA {
		return &smallV2ProtocolError{err: fmt.Errorf("tar entry %q has unsupported type %d", header.Name, header.Typeflag)}
	}
	return nil
}

func classifySmallV2StreamError(ctx context.Context, operation string, err error) error {
	if transferretry.IsAvailabilityError(ctx, err) || errors.Is(err, io.ErrUnexpectedEOF) {
		return err
	}
	return &smallV2ProtocolError{err: fmt.Errorf("%s: %w", operation, err)}
}

func decodeSmallV2JSONEntry(tr *tar.Reader, header *tar.Header, target any) error {
	if header.Size < 0 || header.Size > smallV2MaxControlBytes {
		return &smallV2ProtocolError{err: fmt.Errorf("control entry %q has invalid size %d", header.Name, header.Size)}
	}
	data, err := io.ReadAll(tr)
	if err != nil {
		return &smallV2IncompleteError{err: err}
	}
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		return &smallV2ProtocolError{err: fmt.Errorf("decode %s: %w", header.Name, err)}
	}
	if err := decoder.Decode(&struct{}{}); err != io.EOF {
		return &smallV2ProtocolError{err: fmt.Errorf("decode %s: trailing JSON value", header.Name)}
	}
	return nil
}

func validateSmallV2Manifest(manifest types.DownloadSmallV2Manifest, taskID string, files []*FileInfo) error {
	if manifest.Version != smallV2Version || manifest.TaskID != taskID || manifest.HashAlgorithm != smallV2LayeredHashAlgorithm {
		return errors.New("manifest version, taskid, or hash_algorithm mismatch")
	}
	if manifest.FileCount != len(files) || len(manifest.Files) != len(files) {
		return errors.New("manifest file_count mismatch")
	}
	var total int64
	for index, entry := range manifest.Files {
		expectedPath := fmt.Sprintf("payload/%06d", index)
		if entry.Index != index || entry.ArchivePath != expectedPath || entry.ObjectKey != files[index].ObjectKey || entry.Size != files[index].Size || entry.Size < 0 {
			return fmt.Errorf("manifest file %d does not match requested batch", index)
		}
		if entry.Size > int64(^uint64(0)>>1)-total {
			return errors.New("manifest total size overflow")
		}
		total += entry.Size
	}
	if manifest.TotalUnpackedBytes != total {
		return errors.New("manifest total_unpacked_bytes mismatch")
	}
	return nil
}

func validateSmallV2Footer(footer types.DownloadSmallV2Checksums, manifest types.DownloadSmallV2Manifest, files []*smallV2AttemptFile) error {
	if footer.Version != manifest.Version || footer.TaskID != manifest.TaskID || footer.HashAlgorithm != manifest.HashAlgorithm || footer.FileCount != manifest.FileCount || footer.TotalUnpackedBytes != manifest.TotalUnpackedBytes || len(footer.Files) != len(manifest.Files) {
		return &smallV2ProtocolError{err: errors.New("checksum footer metadata mismatch")}
	}
	for index, entry := range footer.Files {
		manifestEntry := manifest.Files[index]
		if entry.Index != manifestEntry.Index || entry.ObjectKey != manifestEntry.ObjectKey || entry.ArchivePath != manifestEntry.ArchivePath || entry.Size != manifestEntry.Size {
			return &smallV2ProtocolError{err: fmt.Errorf("checksum footer file %d mismatch", index)}
		}
		if strings.TrimSpace(entry.Hash) == "" || !strings.EqualFold(entry.Hash, files[index].hash) {
			return &smallV2IntegrityError{err: fmt.Errorf("checksum footer hash mismatch for file %d", index)}
		}
	}
	return nil
}

func sumSmallV2BatchBytes(files []*FileInfo) int64 {
	var total int64
	for _, file := range files {
		if file != nil && file.Size > 0 {
			total += file.Size
		}
	}
	return total
}
