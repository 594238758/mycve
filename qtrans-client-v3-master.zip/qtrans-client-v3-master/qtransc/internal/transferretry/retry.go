package transferretry

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"io"
	"math/rand/v2"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"

	"qtransc/internal/transportpool"

	"github.com/quic-go/quic-go"
)

const MaxHTTP500Retries = 3

type HTTP500Budget struct {
	retries int
}

func (b *HTTP500Budget) Take() bool {
	if b == nil || b.retries >= MaxHTTP500Retries {
		return false
	}
	b.retries++
	return true
}

func (b *HTTP500Budget) Retries() int {
	if b == nil {
		return 0
	}
	return b.retries
}

func (b *HTTP500Budget) Reset() {
	b.retries = 0
}

type LocalIOError struct {
	Op  string
	Err error
}

func (e *LocalIOError) Error() string {
	if e == nil {
		return "local I/O error"
	}
	if e.Op == "" {
		return "local I/O error: " + e.Err.Error()
	}
	return e.Op + ": " + e.Err.Error()
}

func (e *LocalIOError) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.Err
}

func WrapLocalIO(op string, err error) error {
	if err == nil || errors.Is(err, io.EOF) {
		return err
	}
	var localErr *LocalIOError
	if errors.As(err, &localErr) {
		return err
	}
	return &LocalIOError{Op: op, Err: err}
}

func IsAvailabilityStatus(status int) bool {
	switch status {
	case http.StatusRequestTimeout, http.StatusTooManyRequests,
		http.StatusBadGateway, http.StatusServiceUnavailable, http.StatusGatewayTimeout:
		return true
	default:
		return false
	}
}

func IsAvailabilityError(ctx context.Context, err error) bool {
	if err == nil {
		return false
	}
	if ctx != nil && ctx.Err() != nil {
		return false
	}
	if errors.Is(err, context.Canceled) {
		return false
	}
	if errors.Is(err, context.DeadlineExceeded) {
		return true
	}
	var localErr *LocalIOError
	if errors.As(err, &localErr) {
		return false
	}
	var certVerificationErr *tls.CertificateVerificationError
	if errors.As(err, &certVerificationErr) {
		return false
	}
	var unknownAuthorityErr x509.UnknownAuthorityError
	if errors.As(err, &unknownAuthorityErr) {
		return false
	}
	var hostnameErr x509.HostnameError
	if errors.As(err, &hostnameErr) {
		return false
	}
	var tlsAlert tls.AlertError
	if errors.As(err, &tlsAlert) {
		return false
	}
	var protocolErr *transportpool.ProtocolNegotiationError
	if errors.As(err, &protocolErr) {
		return false
	}
	var dnsErr *net.DNSError
	if errors.As(err, &dnsErr) {
		return dnsErr.IsTimeout || dnsErr.IsTemporary
	}
	var poolErr *transportpool.Error
	if errors.As(err, &poolErr) {
		switch poolErr.Kind {
		case transportpool.ErrorConnect, transportpool.ErrorHandshake,
			transportpool.ErrorRoundTrip, transportpool.ErrorResponseRead,
			transportpool.ErrorTimeout:
			return true
		default:
			return false
		}
	}
	if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
		return true
	}
	var versionErr *quic.VersionNegotiationError
	if errors.As(err, &versionErr) {
		return false
	}
	var statelessResetErr *quic.StatelessResetError
	var idleTimeoutErr *quic.IdleTimeoutError
	var handshakeTimeoutErr *quic.HandshakeTimeoutError
	var applicationErr *quic.ApplicationError
	var transportErr *quic.TransportError
	if errors.As(err, &statelessResetErr) || errors.As(err, &idleTimeoutErr) ||
		errors.As(err, &handshakeTimeoutErr) || errors.As(err, &applicationErr) ||
		errors.As(err, &transportErr) {
		return true
	}
	var opErr *net.OpError
	if errors.As(err, &opErr) {
		return true
	}
	var netErr net.Error
	return errors.As(err, &netErr) && (netErr.Timeout() || netErr.Temporary())
}

type Backoff struct {
	attempt int
	random  func() float64
}

func NewBackoff() *Backoff {
	return &Backoff{random: rand.Float64}
}

func (b *Backoff) Reset() {
	b.attempt = 0
}

func (b *Backoff) Attempts() int {
	return b.attempt
}

func (b *Backoff) Next(header http.Header, now time.Time) time.Duration {
	b.attempt++
	base := time.Second
	for index := 1; index < b.attempt && base < 5*time.Second; index++ {
		base *= 2
		if base > 5*time.Second {
			base = 5 * time.Second
		}
	}
	random := b.random
	if random == nil {
		random = rand.Float64
	}
	delay := time.Duration(float64(base) * (0.8 + random()*0.4))
	if retryAfter, ok := ParseRetryAfter(header, now); ok && retryAfter > delay {
		delay = retryAfter
	}
	return delay
}

func ParseRetryAfter(header http.Header, now time.Time) (time.Duration, bool) {
	if header == nil {
		return 0, false
	}
	raw := strings.TrimSpace(header.Get("Retry-After"))
	if raw == "" {
		return 0, false
	}
	if seconds, err := strconv.Atoi(raw); err == nil && seconds >= 0 {
		return time.Duration(seconds) * time.Second, true
	}
	if parsed, err := http.ParseTime(raw); err == nil {
		if !parsed.After(now) {
			return 0, true
		}
		return parsed.Sub(now), true
	}
	return 0, false
}

func Wait(ctx context.Context, delay time.Duration) error {
	if delay <= 0 {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
			return nil
		}
	}
	timer := time.NewTimer(delay)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-timer.C:
		return nil
	}
}
