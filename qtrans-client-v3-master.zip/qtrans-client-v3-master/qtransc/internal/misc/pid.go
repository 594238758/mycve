package misc

import "os"

var Pid int

func init() {
	Pid = os.Getpid()
}
