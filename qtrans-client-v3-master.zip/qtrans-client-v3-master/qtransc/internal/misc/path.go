package misc

import (
	"os"
	"path/filepath"
)

var PortPath string = ".qtrans/bin/engine.port"
var LogPath string = ".qtrans/logs/engine.log"
var GinLogPath string = ".qtrans/logs/engine_gin.log"
var EventsLogPath string = ".qtrans/logs/engine_events.log"
var DaemonWorkDir string = ".qtrans/bin/"

var UserHome string

func init() {
	homeDir, err := os.UserHomeDir()
	if err != nil {
		panic("failed to get user home directory: " + err.Error())
	}
	UserHome = homeDir

	PortPath = filepath.Join(UserHome, PortPath)
	LogPath = filepath.Join(UserHome, LogPath)
	GinLogPath = filepath.Join(UserHome, GinLogPath)
	EventsLogPath = filepath.Join(UserHome, EventsLogPath)
	DaemonWorkDir = filepath.Join(UserHome, DaemonWorkDir)

	if err := os.MkdirAll(DaemonWorkDir, 0755); err != nil {
		panic("failed to create directory for PID file: " + err.Error())
	}

	if err := os.MkdirAll(filepath.Dir(LogPath), 0755); err != nil {
		panic("failed to create directory for log file: " + err.Error())
	}
}
