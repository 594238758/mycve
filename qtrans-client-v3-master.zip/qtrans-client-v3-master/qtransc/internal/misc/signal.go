package misc

import (
	"context"
	"log/slog"
	"os"
	"os/signal"
	"syscall"
)

func StartSignalHandler(ctx context.Context, cancel context.CancelFunc) error {
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	select {
	case s := <-sigChan:
		// Treat received signals as normal shutdown — cancel context and return nil.
		// Previously this returned an error which caused the caller to log an ERROR
		// and trigger error notifications. Receiving SIGINT/SIGTERM is a normal
		// shutdown path, so record at Info level and return nil.
		cancel()
		slog.Info("Received signal, saving progress and exiting...", "signal", s)
		return nil
	case <-ctx.Done():
		slog.Info("signal listener graceful exit...")
		return nil
	}
}
