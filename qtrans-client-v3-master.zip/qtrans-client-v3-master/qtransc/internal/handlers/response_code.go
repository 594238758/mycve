package handlers

// 业务错误码常量
const (
	CodeSuccess = 0

	// 通用错误 10000-19999
	CodeInvalidJSON = 10001

	// 任务模块错误 20000-29999
	CodeTaskCreateFailed = 20001

	// 系统级错误 50000-59999
	CodeDatabaseError    = 50001
	CodeExternalAPIError = 50002
	CodeInternalError    = 50003
)
