package handlers

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"strings"
	"time"

	"qtransc/internal/authmanager"
	"qtransc/internal/eventcollector"
	"qtransc/internal/eventlog"
	"qtransc/internal/misc"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/serveapi"
	"qtransc/internal/taskmanager"
	"qtransc/internal/types"
	"qtransc/internal/version"

	"github.com/gin-gonic/gin"
)

const maxTaskIDBytes = 128

// TaskHandler HTTP请求处理器（重构版）
type TaskHandler struct {
	ctx               context.Context
	manager           *taskmanager.TaskManager
	logger            *slog.Logger
	eventBus          *eventcollector.Bus
	heartbeatInterval time.Duration
	stateDBPath       string
}

type Option func(*TaskHandler)

func WithEventBus(eventBus *eventcollector.Bus) Option {
	return func(handler *TaskHandler) {
		if handler == nil || eventBus == nil {
			return
		}
		handler.eventBus = eventBus
	}
}

func WithHeartbeatInterval(interval time.Duration) Option {
	return func(handler *TaskHandler) {
		if handler == nil || interval <= 0 {
			return
		}
		handler.heartbeatInterval = interval
	}
}

func WithStateDBPath(path string) Option {
	return func(handler *TaskHandler) {
		handler.stateDBPath = path
	}
}

// NewTaskHandler 创建新的任务处理器
func NewTaskHandler(ctx context.Context, mgr *taskmanager.TaskManager, opts ...Option) *TaskHandler {
	handler := &TaskHandler{
		ctx:               ctx,
		manager:           mgr,
		logger:            slog.Default().With("component", "TaskHandler"),
		eventBus:          eventcollector.NewBus(eventcollector.DefaultSubscriberBuffer),
		heartbeatInterval: eventcollector.DefaultHeartbeatInterval,
	}
	for _, opt := range opts {
		if opt == nil {
			continue
		}
		opt(handler)
	}
	return handler
}

// CreateAndStartTaskV2 accepts source/destination-directory mappings.
func (h *TaskHandler) CreateAndStartTaskV2(c *gin.Context) {
	if h.manager.IsClosing() {
		h.respondFailure(c, serveapi.CodeServiceShuttingDown, taskmanager.ErrServiceShuttingDown)
		return
	}
	var wireRequest serveapi.TaskCreateV2Request
	if err := serveapi.DecodeStrict(c.Request.Body, &wireRequest); err != nil {
		h.respondFailure(c, serveapi.CodeRequestInvalid, err)
		return
	}
	h.createAndStartTask(c, wireRequest.Internal(), wireRequest.TransferOverrides())
}

// CreateAndStartTask 创建并启动任务
func (h *TaskHandler) CreateAndStartTask(c *gin.Context) {
	if h.manager.IsClosing() {
		h.respondFailure(c, serveapi.CodeServiceShuttingDown, taskmanager.ErrServiceShuttingDown)
		return
	}

	var wireRequest serveapi.TaskCreateRequest
	if err := serveapi.DecodeStrict(c.Request.Body, &wireRequest); err != nil {
		h.respondFailure(c, serveapi.CodeRequestInvalid, err)
		return
	}
	h.createAndStartTask(c, wireRequest.Internal(), wireRequest.TransferOverrides())
}

func (h *TaskHandler) createAndStartTask(c *gin.Context, req *types.TaskCreateRequest, overrides types.TransferOverrides) {
	req.TaskID = strings.TrimSpace(req.TaskID)
	if req.TaskID == "" || len(req.TaskID) > maxTaskIDBytes {
		h.respondFailure(c, serveapi.CodeRequestInvalid, taskmanager.ErrTaskIDInvalid)
		return
	}
	settings, err := h.manager.ResolveTransferSettings(req.Transport, overrides)
	if err != nil {
		h.respondFailure(c, serveapi.CodeRequestInvalid, err)
		return
	}
	req.Transport = settings.Transport.String()
	h.applyTaskAuthDefaults(req)
	if req.Mode == "upload" {
		req.StateDBPath = h.stateDBPath
	}
	if err := req.Validate(); err != nil {
		h.respondFailure(c, validationCode(err), err)
		return
	}
	req.ServerTaskID = req.TaskID

	t, err := h.manager.CreateAndStartTask(req, settings)
	if err != nil {
		h.respondFailure(c, taskManagerCode(err), err)
		return
	}

	h.respondSuccess(c, serveapi.TaskView(t.Snapshot()))
}

func validationCode(err error) serveapi.Code {
	code := serveapi.ClassifyAPI(err)
	switch code {
	case serveapi.CodeTaskFileLimitExceeded:
		return code
	default:
		return serveapi.CodeRequestInvalid
	}
}

func (h *TaskHandler) applyTaskAuthDefaults(req *types.TaskCreateRequest) {
	if h == nil || req == nil {
		return
	}
	req.BearerToken = strings.TrimSpace(req.BearerToken)
	req.UseAuthManager = false
	req.UseExactToken = true
	if strings.TrimSpace(req.Mode) == "upload" && req.BearerToken == "" {
		req.BearerToken = qtserverapi.AnonymousWriteToken
	}
}

// GetTaskDetail 获取任务详情
func (h *TaskHandler) GetTaskDetail(c *gin.Context) {
	taskID := c.Param("task_id")

	t, err := h.manager.GetTask(taskID)
	if err != nil {
		h.respondFailure(c, taskManagerCode(err), err)
		return
	}

	h.respondSuccess(c, serveapi.TaskView(t.Snapshot()))
}

// GetTaskSummary 获取任务摘要
func (h *TaskHandler) GetTaskSummary(c *gin.Context) {
	taskID := c.Param("task_id")

	t, err := h.manager.GetTask(taskID)
	if err != nil {
		h.respondFailure(c, taskManagerCode(err), err)
		return
	}

	h.respondSuccess(c, serveapi.TaskView(t.ToSummary()))
}

// GetTasksSummary 获取所有任务摘要
func (h *TaskHandler) GetTasksSummary(c *gin.Context) {
	tasks, err := h.manager.ListAllTasks()
	if err != nil {
		h.respondFailure(c, serveapi.CodeInternalError, err)
		return
	}

	summaries := make([]any, 0, len(tasks))
	for _, t := range tasks {
		summaries = append(summaries, serveapi.TaskView(t.ToSummary()))
	}

	h.respondSuccess(c, summaries)
}

// StartTask 启动任务
func (h *TaskHandler) StartTask(c *gin.Context) {
	if h.manager.IsClosing() {
		h.respondFailure(c, serveapi.CodeServiceShuttingDown, taskmanager.ErrServiceShuttingDown)
		return
	}

	taskID := c.Param("task_id")

	task, err := h.manager.StartTask(taskID)
	if err != nil {
		taskPID := ""
		enterpriseID := ""
		if task != nil {
			taskPID = task.GetTaskPID()
			enterpriseID = task.GetEnterpriseID()
		}
		h.logger.Error("Failed to start task", "task_id", taskID, "taskpid", taskPID, "enterprise_id", enterpriseID, "error", err)
		h.respondFailure(c, taskManagerCode(err), err)
		return
	}

	h.respondSuccess(c, nil)
}

// StopTask 停止任务
func (h *TaskHandler) StopTask(c *gin.Context) {
	taskID := c.Param("task_id")

	task, err := h.manager.StopTask(taskID)
	if err != nil {
		taskPID := ""
		enterpriseID := ""
		if task != nil {
			taskPID = task.GetTaskPID()
			enterpriseID = task.GetEnterpriseID()
		}
		h.logger.Error("Failed to stop task", "task_id", taskID, "taskpid", taskPID, "enterprise_id", enterpriseID, "error", err)
		h.respondFailure(c, taskManagerCode(err), err)
		return
	}

	h.respondSuccess(c, nil)
}

// DeleteTask 删除任务
func (h *TaskHandler) DeleteTask(c *gin.Context) {
	taskID := c.Param("task_id")

	err := h.manager.DeleteTask(taskID)
	if err != nil {
		h.respondFailure(c, taskManagerCode(err), err)
		return
	}

	h.respondSuccess(c, nil)
}

// Health 健康检查
func (h *TaskHandler) Health(c *gin.Context) {
	data := serveapi.HealthData{
		Me:      "qtransc",
		PID:     misc.Pid,
		Version: version.Version,
	}
	h.respondSuccess(c, data)
}

// GetConfig returns the public subset of the service's effective configuration.
func (h *TaskHandler) GetConfig(c *gin.Context) {
	config := h.manager.GetConfig()
	data := serveapi.ConfigData{
		Limits: serveapi.ConfigLimits{
			MaxConcurrentTasks: config.MaxConcurrentTasks,
			MaxAdmittedTasks:   config.MaxAdmittedTasks,
		},
		Defaults: serveapi.ConfigDefaults{
			Transport:       config.TransferDefaults.Transport.String(),
			Connections:     config.TransferDefaults.Connections,
			Streams:         config.TransferDefaults.Streams,
			FileConcurrency: config.TransferDefaults.FileConcurrency,
		},
	}
	h.respondSuccess(c, data)
}

// GetStats 获取统计信息
func (h *TaskHandler) GetStats(c *gin.Context) {
	stats := h.manager.GetStats()
	h.respondSuccess(c, stats)
}

// UpdateToken updates the in-memory bearer token used by server mode.
func (h *TaskHandler) UpdateToken(c *gin.Context) {
	var wireRequest serveapi.TokenConfigRequest

	if err := serveapi.DecodeStrict(c.Request.Body, &wireRequest); err != nil {
		h.respondFailure(c, serveapi.CodeRequestInvalid, err)
		return
	}
	req := wireRequest.Internal()
	if err := req.Validate(); err != nil {
		h.respondFailure(c, serveapi.CodeRequestInvalid, err)
		return
	}

	if err := authmanager.SetStaticToken(req.BearerToken); err != nil {
		h.respondFailure(c, serveapi.ClassifyAPI(err), err)
		return
	}
	h.logger.Info("Bearer token updated",
		"token_length", len(req.BearerToken))
	h.respondSuccess(c, nil)
}

// respondSuccess 统一成功响应
func (h *TaskHandler) respondSuccess(c *gin.Context, data any) {
	c.JSON(http.StatusOK, serveapi.Success(data))
}

func (h *TaskHandler) respondFailure(c *gin.Context, code serveapi.Code, cause error) {
	if code == serveapi.CodeSuccess {
		code = serveapi.CodeInternalError
	}
	h.logger.Error("serve request failed", "code", code, "error", cause)
	c.JSON(http.StatusOK, serveapi.Failure(code))
}

func taskManagerCode(err error) serveapi.Code {
	switch {
	case errors.Is(err, taskmanager.ErrServiceShuttingDown):
		return serveapi.CodeServiceShuttingDown
	case errors.Is(err, taskmanager.ErrTaskAlreadyExists):
		return serveapi.CodeTaskAlreadyExists
	case errors.Is(err, taskmanager.ErrTaskNotFound):
		return serveapi.CodeTaskNotFound
	case errors.Is(err, taskmanager.ErrTaskStateConflict):
		return serveapi.CodeTaskStateConflict
	case errors.Is(err, taskmanager.ErrTaskCapacity):
		return serveapi.CodeTaskCapacityExceeded
	case errors.Is(err, taskmanager.ErrTaskIDRequired), errors.Is(err, taskmanager.ErrTaskIDInvalid):
		return serveapi.CodeRequestInvalid
	default:
		return serveapi.ClassifyAPI(err)
	}
}

func (h *TaskHandler) Events(c *gin.Context) {
	// 设置 SSE 响应头
	c.Header("Content-Type", "text/event-stream")
	c.Header("Cache-Control", "no-cache")
	c.Header("Connection", "keep-alive")
	c.Status(http.StatusOK)
	// 立即 flush 响应头，避免客户端等待心跳间隔才收到 200 OK
	c.Writer.Flush()

	// 连接建立后立即发送一个初始心跳，确认 SSE 通道可用
	writeSSEEvent(c, types.NewHeartbeatEvent(time.Now()))

	eventlog.Info("SSE connection established", "client", c.ClientIP())
	eventBus := h.eventBus
	if eventBus == nil {
		eventBus = eventcollector.NewBus(eventcollector.DefaultSubscriberBuffer)
	}
	eventsCh, unsubscribe := eventBus.Subscribe(eventcollector.DefaultSubscriberBuffer)
	defer unsubscribe()

	// 每 5 秒发送一次心跳事件
	ticker := time.NewTicker(h.heartbeatInterval)
	defer ticker.Stop()

	// 获取客户端断开通知
	clientGone := c.Request.Context().Done()

	for {
		select {
		case <-h.ctx.Done():
			// 服务端上下文被取消
			return
		case <-clientGone:
			// 客户端断开连接
			eventlog.Info("SSE client disconnected", "client", c.ClientIP())
			return
		case <-ticker.C:
			writeSSEEvent(c, types.NewHeartbeatEvent(time.Now()))

		case e, ok := <-eventsCh:
			if !ok {
				return
			}
			writeSSEEvent(c, e)
		}
	}
}

func writeSSEEvent(c *gin.Context, event types.TaskEvent) {
	envelope, err := serveapi.EventEnvelope(event)
	if err != nil {
		eventlog.Warn("SSE event conversion failed", "client", c.ClientIP(), "event_type", event.EventType, "error", err)
		return
	}
	payload, err := json.Marshal(envelope)
	if err != nil {
		eventlog.Warn("SSE event marshal failed", "client", c.ClientIP(), "event_type", event.EventType, "error", err)
		return
	}
	if _, err := fmt.Fprintf(c.Writer, "data: %s\n\n", payload); err != nil {
		eventlog.Warn("SSE event write failed", "client", c.ClientIP(), "event_type", event.EventType, "payload", string(payload), "error", err)
		return
	}
	eventlog.Info("SSE event", "client", c.ClientIP(), "event_type", event.EventType, "payload", string(payload))
	c.Writer.Flush()
}
