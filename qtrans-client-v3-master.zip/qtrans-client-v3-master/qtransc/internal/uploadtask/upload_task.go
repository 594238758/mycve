package uploadtask

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"math"
	"net/http"
	"os"
	"qtransc/internal/authmanager"
	"qtransc/internal/average"
	"qtransc/internal/clienterror"
	"qtransc/internal/domain"
	"qtransc/internal/eventcollector"
	"qtransc/internal/filehash"
	"qtransc/internal/netclient"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/ratelimit"
	"qtransc/internal/transferlimits"
	"qtransc/internal/types"
	"qtransc/internal/uploadstate"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/google/uuid"
	"golang.org/x/sync/errgroup"
)

var (
	defaultUploadChunkSize      int64 = filehash.ChunkSize
	uploadAuthRetryMaxRefreshes       = 1
)

// IsLocalStateError reports whether an upload failed because its local
// resumable-upload state could not be read, written, or cleaned up.
func IsLocalStateError(err error) bool {
	if err == nil {
		return false
	}
	message := err.Error()
	return strings.Contains(message, "LOCAL_STATE_ERROR") ||
		strings.Contains(message, "LOCAL_STATE_CLEANUP_FAILED")
}

type UploadTask struct {
	pathMappings         []types.PathMapping
	pathMappingsExpanded bool // FileList and DirPaths contain the committed expansion.

	networkConfig      netclient.Config
	client             *netclient.Client
	chunkSlots         netclient.ChunkSlots
	stopRequested      bool
	finalErr           error
	mu                 sync.Mutex
	roundDone          chan struct{}
	logger             *slog.Logger
	publisher          eventcollector.Publisher `json:"-"`
	completionNotifier func()                   `json:"-"`
	Status             types.TaskStatus         `json:"status,omitempty"`
	Err                error                    `json:"error,omitempty"`
	Started            bool                     `json:"started,omitempty"`

	ctx    context.Context
	cancel context.CancelFunc

	TaskID                 string              `json:"task_id,omitempty"`
	TaskPID                string              `json:"-"`
	EnterpriseID           string              `json:"-"`
	CallerVersion          string              `json:"-"`
	TaskName               string              `json:"task_name,omitempty"`
	Mode                   string              `json:"mode,omitempty"`
	Transport              types.TransportMode `json:"transport,omitempty"`
	ServerAddr             string              `json:"server_addr,omitempty"`
	SourceDir              string              `json:"source_dir,omitempty"`
	bearerToken            string              `json:"-"`
	useAuthManager         bool                `json:"-"`
	preflightOnExecute     bool
	requiresAnonymousWrite bool

	RequestedServerTaskID string `json:"requested_server_task_id,omitempty"`
	ServerTaskID          string `json:"server_task_id,omitempty"`
	requiresNewTaskID     bool   `json:"-"`
	autoRetry             bool
	DirPaths              []string          `json:"dir_paths,omitempty"` // 需在服务端预先创建的空目录 object key 列表
	UploadChunkSize       int64             `json:"upload_chunk_size,omitempty"`
	UploadHashAlgorithm   string            `json:"upload_hash_algorithm,omitempty"`
	maxFileBytes          int64             `json:"-"`
	TransferingFiles      sync.Map          `json:"transfering_files"`
	FileList              []*UploadFileInfo `json:"file_list,omitempty"`
	ReadyFiles            []*UploadFileInfo `json:"ready_files,omitempty"`
	ConflictFiles         []*UploadFileInfo `json:"conflict_files,omitempty"`
	RejectedFiles         []*UploadFileInfo `json:"rejected_files,omitempty"`
	HashedBytes           int64             `json:"-"`
	PreparedSessionFiles  int64             `json:"-"`

	Transferred                 int64 `json:"transferred_bytes,omitempty"`
	Confirmed                   int64 `json:"-"`
	NetworkSent                 int64 `json:"network_sent_bytes,omitempty"`
	TotalSize                   int64 `json:"total_size,omitempty"`
	Rate                        int64 `json:"transfer_rate,omitempty"`
	LimitRate                   int64 `json:"limit_rate_bytes_per_sec,omitempty"`
	rateLimiter                 *ratelimit.Limiter
	lastTaskProgressPublishedAt atomic.Int64 `json:"-"`

	CreatedAt             time.Time     `json:"created_at"`
	UpdatedAt             time.Time     `json:"updated_at"`
	StartedAt             time.Time     `json:"started_at,omitempty"`
	FinishedAt            time.Time     `json:"finished_at,omitempty"`
	FileConcurrency       int           `json:"file_concurrency,omitempty"`
	Phase                 string        `json:"phase,omitempty"`
	progressEventInterval time.Duration `json:"-"`
	stateMu               sync.Mutex
	state                 *uploadstate.Store
	stateDBPath           string
}

type UploadFileInfo struct {
	failure           types.FileFailure      `json:"-"`
	mu                sync.Mutex             `json:"-"`
	progressMu        sync.Mutex             `json:"-"`
	ctx               context.Context        `json:"-"`
	cancel            context.CancelFunc     `json:"-"`
	logger            *slog.Logger           `json:"-"`
	task              *UploadTask            `json:"-"`
	LastErr           error                  `json:"-"`
	lastNetworkSent   int64                  `json:"-"`
	rateAverage       *average.SMA           `json:"-"`
	modTime           time.Time              `json:"-"`
	uploadedChunks    map[int]struct{}       `json:"-"`
	verifiedChunks    map[int]struct{}       `json:"-"`
	chunkStoredBytes  map[int]int64          `json:"-"`
	chunkProgress     []*uploadChunkProgress `json:"-"`
	sessionRecoveryMu sync.Mutex             `json:"-"`
	source            *os.File               `json:"-"`
	fingerprint       sourceFingerprint      `json:"-"`
	chunkHashes       []string               `json:"-"`
	registered        bool                   `json:"-"`
	stateOwned        bool                   `json:"-"`

	FullPath                string       `json:"full_path,omitempty"`
	LocalPath               string       `json:"local_rel_path,omitempty"`
	ObjectKey               string       `json:"object_key,omitempty"`
	ObjectKeyHash           string       `json:"object_key_hash,omitempty"`
	Size                    int64        `json:"size,omitempty"`
	FileHash                string       `json:"file_hash,omitempty"`
	HashAlgorithm           string       `json:"hash_algorithm,omitempty"`
	SessionID               string       `json:"session_id,omitempty"`
	LeaseUntil              string       `json:"lease_until,omitempty"`
	UploadURL               string       `json:"upload_url,omitempty"`
	Status                  string       `json:"status,omitempty"`
	ChunkSize               int64        `json:"chunk_size,omitempty"`
	ChunkCount              int          `json:"chunk_count,omitempty"`
	Ready                   bool         `json:"ready,omitempty"`
	Exists                  bool         `json:"exists,omitempty"`
	Transferred             int64        `json:"transferred_bytes,omitempty"`
	Confirmed               int64        `json:"-"`
	NetworkSent             int64        `json:"-"`
	Rate                    int64        `json:"transfer_rate,omitempty"`
	Uploaded                bool         `json:"uploaded,omitempty"`
	Verified                bool         `json:"verified,omitempty"`
	ReasonCode              string       `json:"reason_code,omitempty"`
	Message                 string       `json:"message,omitempty"`
	lastProgressPublishedAt atomic.Int64 `json:"-"`
}

type uploadChunkProgress struct {
	Total           int64
	Transferred     atomic.Int64
	Confirmed       atomic.Int64
	NetworkSent     atomic.Int64
	Rate            atomic.Int64
	Active          atomic.Bool
	Started         atomic.Bool
	lastNetworkSent int64
	rateAverage     *average.SMA
}

func errString(err error) string {
	if err == nil {
		return ""
	}
	return clienterror.Message(err)
}

func applyBearerTokenHeader(req *http.Request, token string) {
	req.Header.Set("Authorization", "Bearer "+token)
}

func isHTTPAuthorizationFailure(statusCode int) bool {
	return statusCode == http.StatusUnauthorized || statusCode == http.StatusForbidden
}

func (ut *UploadTask) refreshAuthorizationAfter401(ctx context.Context, statusCode int) bool {
	if ut == nil || statusCode != http.StatusUnauthorized || !ut.useAuthManager || strings.TrimSpace(ut.bearerToken) != "" {
		return false
	}
	if authmanager.Mode() != authmanager.AuthModeUserAndPass {
		return false
	}
	if err := authmanager.ForceRefresh(ctx); err != nil {
		ut.logger.Error("401 后刷新凭据失败", "err", err)
		return false
	}
	return true
}

func (ut *UploadTask) requestContext() context.Context {
	if ut != nil && ut.ctx != nil {
		return ut.ctx
	}
	return context.Background()
}

func (ut *UploadTask) ensureUploadState(ctx context.Context) error {
	ut.stateMu.Lock()
	defer ut.stateMu.Unlock()
	if ut.state != nil {
		return nil
	}
	state, err := uploadstate.Open(ctx, ut.stateDBPath)
	if err != nil {
		return fmt.Errorf("LOCAL_STATE_ERROR: %w", err)
	}
	ut.state = state
	return nil
}

func (ut *UploadTask) closeUploadState() {
	ut.stateMu.Lock()
	state := ut.state
	ut.state = nil
	ut.stateMu.Unlock()
	if state == nil {
		return
	}
	if err := state.Close(); err != nil && ut.logger != nil {
		ut.logger.Warn("close upload state failed", "err", err)
	}
}

func (ut *UploadTask) currentBearerToken() (string, error) {
	if ut == nil {
		return "", nil
	}
	if strings.TrimSpace(ut.bearerToken) != "" {
		return ut.bearerToken, nil
	}
	if !ut.useAuthManager {
		return "", authmanager.ErrAccessTokenMissing
	}
	return authmanager.Get()
}

func (ut *UploadTask) doJSONWithCorrelation(ctx context.Context, endpoint, method, token string, payload any, retry qtserverapi.RetryMode) (int, http.Header, []byte, error) {
	if ut.useAuthManager {
		return qtserverapi.DoJSONWithCorrelation(ctx, ut.ServerAddr, endpoint, method, token, ut.taskCorrelation(), payload, ut.client, retry)
	}
	return qtserverapi.DoJSONWithCorrelationWithoutAuthRefresh(ctx, ut.ServerAddr, endpoint, method, token, ut.taskCorrelation(), payload, ut.client, retry)
}

func (ut *UploadTask) doJSONWithHeadersAndCorrelation(ctx context.Context, endpoint, method, token string, payload any, requestHeaders http.Header, retry qtserverapi.RetryMode) (int, http.Header, []byte, error) {
	if ut.useAuthManager {
		return qtserverapi.DoJSONWithHeadersAndCorrelation(ctx, ut.ServerAddr, endpoint, method, token, ut.taskCorrelation(), payload, requestHeaders, ut.client, retry)
	}
	return qtserverapi.DoJSONWithHeadersAndCorrelationWithoutAuthRefresh(ctx, ut.ServerAddr, endpoint, method, token, ut.taskCorrelation(), payload, requestHeaders, ut.client, retry)
}

// NewUploadTask preserves synchronous preflight for direct CLI callers.
func NewUploadTask(req *types.TaskCreateRequest, network netclient.Config, firstClient *netclient.Client, opts ...eventcollector.RuntimeOption) (*UploadTask, error) {
	return newUploadTask(req, false, network, firstClient, opts...)
}

// NewPendingUploadTask constructs an in-memory task without filesystem or network
// preflight. The accepted task performs these checks in each execution round.
func NewPendingUploadTask(req *types.TaskCreateRequest, network netclient.Config, firstClient *netclient.Client, opts ...eventcollector.RuntimeOption) (*UploadTask, error) {
	return newUploadTask(req, true, network, firstClient, opts...)
}

func newUploadTask(req *types.TaskCreateRequest, preflightOnExecute bool, network netclient.Config, firstClient *netclient.Client, opts ...eventcollector.RuntimeOption) (*UploadTask, error) {
	if err := transferlimits.ValidateTaskFileCount(len(req.FileList)); err != nil {
		return nil, err
	}
	transportMode, err := types.ParseTransportMode(req.Transport)
	if err != nil {
		return nil, err
	}
	if err := network.Validate(transportMode); err != nil {
		return nil, err
	}
	if firstClient != nil && (firstClient.Mode() != transportMode || firstClient.Config() != network) {
		return nil, fmt.Errorf("initial network client does not match task configuration")
	}
	if !preflightOnExecute && firstClient == nil {
		return nil, fmt.Errorf("synchronous task preflight requires a network client")
	}

	requiredCapabilities := []string{"upload"}
	if len(req.DirPaths) > 0 || len(req.PathMappings) > 0 {
		requiredCapabilities = append(requiredCapabilities, "file_management")
	}
	var capabilities qtserverapi.Capabilities
	if !preflightOnExecute {
		capabilities, err = qtserverapi.RequireCapabilities(context.Background(), req.ServerAddr, firstClient, requiredCapabilities...)
		if err != nil {
			return nil, fmt.Errorf("qtserver capability preflight failed: %w", err)
		}
	}
	stateDBPath := req.StateDBPath
	if !preflightOnExecute {
		stateDBPath, err = uploadstate.ResolvePath(stateDBPath)
		if err != nil {
			return nil, fmt.Errorf("invalid state-db: %w", err)
		}
	}
	eventConfig := eventcollector.ApplyRuntimeOptions(opts...)
	requestToken := strings.TrimSpace(req.BearerToken)
	useAuthManager := req.UseAuthManager && !req.UseExactToken
	requiresAnonymousWrite := requestToken == qtserverapi.AnonymousWriteToken && !useAuthManager
	if requiresAnonymousWrite && !preflightOnExecute {
		if err := capabilities.RequireAnonymousWrite(); err != nil {
			return nil, err
		}
	}
	if requestToken != "" && !useAuthManager && !req.UseExactToken {
		if err := authmanager.SetStaticToken(requestToken); err == nil {
			useAuthManager = true
			requestToken = ""
		} else if !authmanager.IsModeLocked(err) {
			return nil, err
		}
	}
	ut := &UploadTask{
		pathMappings:           append([]types.PathMapping(nil), req.PathMappings...),
		networkConfig:          network,
		client:                 firstClient,
		Status:                 types.StatusPending,
		logger:                 slog.Default().With("taskid", req.TaskID, "taskpid", req.TaskPID, "enterprise_id", req.EnterpriseID),
		publisher:              eventConfig.Publisher,
		completionNotifier:     eventConfig.CompletionNotifier,
		TaskID:                 req.TaskID,
		TaskPID:                req.TaskPID,
		EnterpriseID:           req.EnterpriseID,
		CallerVersion:          req.CallerVersion,
		TaskName:               req.TaskName,
		LimitRate:              req.LimitRate,
		autoRetry:              req.AutoRetry,
		Mode:                   req.Mode,
		Transport:              transportMode,
		ServerAddr:             strings.TrimRight(req.ServerAddr, "/"),
		SourceDir:              req.SourceDir,
		bearerToken:            requestToken,
		useAuthManager:         useAuthManager,
		preflightOnExecute:     preflightOnExecute,
		requiresAnonymousWrite: requiresAnonymousWrite,
		DirPaths:               req.DirPaths,
		RequestedServerTaskID:  strings.TrimSpace(req.ServerTaskID),
		ServerTaskID:           strings.TrimSpace(req.ServerTaskID),
		UploadChunkSize:        defaultUploadChunkSize,
		UploadHashAlgorithm:    types.UploadHashAlgorithmLayeredXXH3_128,
		maxFileBytes:           capabilities.MaxFileBytes(),
		FileList:               make([]*UploadFileInfo, len(req.FileList)),
		CreatedAt:              time.Now(),
		UpdatedAt:              time.Now(),
		FileConcurrency:        types.DefaultFileConcurrency,
		progressEventInterval:  eventConfig.ProgressInterval,
		stateDBPath:            stateDBPath,
	}
	if ut.ServerTaskID == "" {
		ut.ServerTaskID = ut.TaskID
	}
	for i := range req.FileList {
		ut.FileList[i] = NewUploadFileInfo(ut, req.FileList[i].LocalRelPath, req.FileList[i].ObjectKey)
	}
	if !preflightOnExecute {
		if err := ut.validateLocalFileSizes(); err != nil {
			return nil, err
		}
	}

	return ut, nil
}

func (ut *UploadTask) prepareCapabilities(ctx context.Context) error {
	required := []string{"upload"}
	if len(ut.DirPaths) > 0 || len(ut.pathMappings) > 0 {
		required = append(required, "file_management")
	}
	capabilities, err := qtserverapi.RequireCapabilities(ctx, ut.ServerAddr, ut.client, required...)
	if err != nil {
		return fmt.Errorf("qtserver capability preflight failed: %w", err)
	}
	if ut.requiresAnonymousWrite {
		if err := capabilities.RequireAnonymousWrite(); err != nil {
			return err
		}
	}
	ut.maxFileBytes = capabilities.MaxFileBytes()
	return nil
}

func (ut *UploadTask) acquireClient(ctx context.Context, requestURL string) (*http.Client, netclient.ReleaseFunc, error) {
	return ut.client.Acquire(ctx, requestURL)
}

func (ut *UploadTask) run() error {
	ut.setPhase("preparing_files")
	if err := ut.prepareLocalFiles(); err != nil {
		return err
	}

	ut.setPhase("creating_directories")
	if err := ut.createRemoteDirectories(); err != nil {
		return err
	}

	progressCtx, stopProgress := context.WithCancel(ut.ctx)
	var progressWG sync.WaitGroup
	progressWG.Add(2)
	go func() {
		defer progressWG.Done()
		if err := ut.updateTransferRate(progressCtx); err != nil {
			ut.logger.Error("updateTransferRate failed", "err", err)
		}
	}()
	go func() {
		defer progressWG.Done()
		ut.reportProgress(progressCtx)
	}()
	defer func() {
		stopProgress()
		progressWG.Wait()
	}()

	ut.setPhase("uploading_files")
	if err := ut.uploadFiles(ut.ctx, ut.FileList); err != nil {
		return err
	}
	if len(ut.RejectedFiles) > 0 {
		return ut.buildAuthorizeFilesError()
	}
	return nil
}

// beginRun performs the complete pending -> running transition. Round-scoped
// data is initialized before running becomes visible, so snapshots never mix
// two rounds.
func (ut *UploadTask) beginRun(ctx context.Context) (context.Context, context.CancelFunc, chan struct{}, error) {
	ut.mu.Lock()
	defer ut.mu.Unlock()
	if ut.Status != types.StatusPending {
		return nil, nil, nil, fmt.Errorf("%w: cannot run upload task in %s", domain.ErrInvalidTaskState, ut.Status)
	}
	ut.prepareRunLocked()
	roundCtx, cancel := context.WithCancel(ctx)
	roundDone := make(chan struct{})
	ut.ctx, ut.cancel, ut.roundDone = roundCtx, cancel, roundDone
	now := time.Now()
	ut.Status = types.StatusRunning
	ut.UpdatedAt = now
	ut.StartedAt = now
	ut.FinishedAt = time.Time{}
	ut.Started = true
	ut.Err = nil
	ut.finalErr = nil
	ut.stopRequested = false
	ut.logger.Debug("upload task status changed", "from", types.StatusPending, "to", types.StatusRunning)
	ut.publishStatusLocked(types.NewTaskStatusEvent(ut.TaskID, types.TaskStatusToEventStatus(types.StatusRunning), ""))
	ut.publishProgress(true)
	return roundCtx, cancel, roundDone, nil
}

// Run starts one execution round without blocking. Preparation and transfer
// errors are part of this round and finish as failed.
func (ut *UploadTask) Run(ctx context.Context) error {
	roundCtx, cancel, roundDone, err := ut.beginRun(ctx)
	if err != nil {
		return err
	}
	go func() {
		defer ut.notifyCompletion()
		ut.executeRound(roundCtx, cancel, roundDone)
	}()
	return nil
}

func (ut *UploadTask) executeRound(ctx context.Context, cancel context.CancelFunc, roundDone chan struct{}) error {
	defer close(roundDone)
	defer cancel()

	if err := ctx.Err(); err != nil {
		ut.releaseExecutionResources()
		return ut.finishExecution(err, false)
	}

	if ut.client == nil {
		client, err := netclient.New(ut.Transport, ut.networkConfig)
		if err != nil {
			ut.releaseExecutionResources()
			return ut.finishExecution(err, false)
		}
		ut.client = client
	}
	ut.chunkSlots = make(netclient.ChunkSlots, ut.client.Capacity())

	if ut.preflightOnExecute {
		if err := ut.prepareCapabilities(ctx); err != nil {
			ut.releaseExecutionResources()
			return ut.finishExecution(err, false)
		}
	}
	if len(ut.pathMappings) > 0 {
		var err error
		if ut.pathMappingsExpanded {
			err = ut.checkMappedTargets()
		} else {
			err = ut.preparePathMappings()
		}
		if err != nil {
			ut.releaseExecutionResources()
			return ut.finishExecution(err, false)
		}
	}
	if err := ut.ensureUploadState(ctx); err != nil {
		ut.releaseExecutionResources()
		return ut.finishExecution(err, false)
	}

	err := ut.run()
	atomic.StoreInt64(&ut.Rate, 0)
	completed := ut.allFilesFinished()
	// All business goroutines and this round's resources converge before the
	// terminal status becomes visible.
	ut.releaseExecutionResources()
	return ut.finishExecution(err, completed)
}

func (ut *UploadTask) releaseExecutionResources() {
	if ut.client != nil {
		_ = ut.client.Close()
		ut.client = nil
	}
	ut.chunkSlots = nil
	ut.rateLimiter = nil
	ut.closeUploadState()
}

func (ut *UploadTask) notifyCompletion() {
	if ut.completionNotifier != nil {
		ut.completionNotifier()
	}
}

func (ut *UploadTask) Stop() error {
	ut.mu.Lock()
	status := ut.Status
	if status != types.StatusPending && status != types.StatusRunning {
		ut.mu.Unlock()
		return nil
	}
	ut.stopRequested = true
	cancel := ut.cancel
	var roundDone <-chan struct{}
	if status == types.StatusRunning {
		roundDone = ut.roundDone
	} else {
		ut.Err = nil
		ut.FinishedAt = time.Now()
		for _, file := range ut.FileList {
			if file != nil {
				file.failure.Clear()
			}
		}
		if err := ut.transitionTo(types.StatusStopped); err != nil {
			ut.mu.Unlock()
			return err
		}
	}
	ut.mu.Unlock()
	if cancel != nil {
		cancel()
	}
	if roundDone != nil {
		<-roundDone
	}
	return nil
}

func (ut *UploadTask) setPhase(phase string) {
	ut.mu.Lock()
	ut.Phase = phase
	ut.UpdatedAt = time.Now()
	ut.mu.Unlock()
	ut.logger.Debug("upload task phase changed", "phase", phase)

}

func (ut *UploadTask) GetPhase() string {
	ut.mu.Lock()
	defer ut.mu.Unlock()
	return ut.Phase
}

// calculate total size
func (ut *UploadTask) prepareLocalFiles() error {
	if len(ut.pathMappings) == 0 {
		sourceDir := ut.SourceDir
		if sourceDir == "" {
			return clienterror.New(clienterror.CodeLocalPathInvalid, "本地上传根目录不能为空", nil)
		}
		info, err := os.Stat(sourceDir)
		if err != nil {
			return localUploadPathError(sourceDir, err)
		}
		if !info.IsDir() {
			return clienterror.New(clienterror.CodeLocalPathInvalid, "本地上传根路径不是目录："+sourceDir, nil)
		}
	}

	var total int64
	for _, file := range ut.FileList {
		if err := ut.ctx.Err(); err != nil {
			return err
		}
		stat := os.Stat
		if len(ut.pathMappings) > 0 {
			stat = os.Lstat
		}
		fileInfo, err := stat(file.FullPath)
		if err != nil {
			return file.recordExecutionError(localUploadPathError(file.FullPath, err))
		}
		if !fileInfo.Mode().IsRegular() {
			return file.recordExecutionError(clienterror.New(clienterror.CodeLocalPathInvalid, "本地上传源不是普通文件："+file.FullPath, nil))
		}
		if err := transferlimits.ValidateFileSize(fileInfo.Size(), ut.maxFileBytes); err != nil {
			return file.recordExecutionError(err)
		}
		file.Size = fileInfo.Size()
		file.modTime = fileInfo.ModTime()
		if fileInfo.Size() > math.MaxInt64-total {
			return fmt.Errorf("upload total size exceeds int64")
		}
		total += fileInfo.Size()
	}
	atomic.StoreInt64(&ut.TotalSize, total)
	return nil
}

// validateLocalFileSizes performs the constructor-time preflight before any
// remote directory is created. prepareLocalFiles repeats the stat immediately
// before transfer to guard against local files changing in the interim.
func (ut *UploadTask) validateLocalFileSizes() error {
	for _, file := range ut.FileList {
		fileInfo, err := os.Stat(file.FullPath)
		if err != nil {
			return localUploadPathError(file.FullPath, err)
		}
		if !fileInfo.Mode().IsRegular() {
			return clienterror.New(clienterror.CodeLocalPathInvalid, "本地上传源不是普通文件："+file.FullPath, nil)
		}
		if err := transferlimits.ValidateFileSize(fileInfo.Size(), ut.maxFileBytes); err != nil {
			return err
		}
	}
	return nil
}

func localUploadPathError(path string, err error) error {
	if os.IsNotExist(err) {
		return clienterror.New(clienterror.CodeLocalFileNotFound, "本地上传源不存在："+path, err)
	}
	return clienterror.New(clienterror.CodeLocalPathInvalid, "无法读取本地上传源："+path, err)
}

func (ut *UploadTask) GetProgressPercent() float64 {
	if ut.GetStatus().Status == types.StatusCompleted {
		return 100
	}

	return progressPercent(atomic.LoadInt64(&ut.Transferred), atomic.LoadInt64(&ut.TotalSize))
}

func progressPercent(done, total int64) float64 {
	if total <= 0 {
		return 0
	}
	pct := float64(done) / float64(total) * 100
	return clampPercent(pct)
}

func clampPercent(pct float64) float64 {
	if pct < 0 {
		return 0
	}
	if pct > 100 {
		return 100
	}
	return pct
}

func (ut *UploadTask) qtserverTaskID() string {
	if strings.TrimSpace(ut.ServerTaskID) != "" {
		return ut.ServerTaskID
	}
	return ut.TaskID
}

func (ut *UploadTask) taskCorrelation() qtserverapi.TaskCorrelation {
	return qtserverapi.TaskCorrelation{
		TaskID:       ut.qtserverTaskID(),
		TaskPID:      ut.TaskPID,
		EnterpriseID: ut.EnterpriseID,
	}
}

// createRemoteDirectories 在服务端预先创建所有空目录。
// 从 DirPaths 获取需要创建的目录 object key 列表，依次调用 /u/mkdir。
func (ut *UploadTask) createRemoteDirectories() error {
	if len(ut.DirPaths) == 0 {
		return nil
	}

	for _, dirPath := range ut.DirPaths {
		if dirPath == "/" && len(ut.pathMappings) > 0 {
			continue
		}
		usedToken, err := ut.currentBearerToken()
		if err != nil {
			return err
		}
		_, _, _, err = ut.doJSONWithCorrelation(
			ut.requestContext(),
			"/files/mkdir",
			http.MethodPost,
			usedToken,
			map[string]string{"path": dirPath},
			qtserverapi.IdempotentRetry,
		)
		if err != nil {
			return fmt.Errorf("mkdir %q: %w", dirPath, err)
		}
		ut.logger.Debug("remote directory created", "dir", dirPath)
	}

	return nil
}

func (ut *UploadTask) buildAuthorizeFilesError() error {
	if len(ut.RejectedFiles) == 0 {
		return fmt.Errorf("no files ready for upload")
	}
	reasons := make([]string, 0, len(ut.RejectedFiles))
	for _, file := range ut.RejectedFiles {
		message := strings.TrimSpace(file.Message)
		if message == "" {
			message = "upload session init rejected"
		}
		reasons = append(reasons, fmt.Sprintf("%s: %s", file.ObjectKey, message))
	}
	return fmt.Errorf("upload init rejected: %s", strings.Join(reasons, "; "))
}

type uploadFileAttemptResult struct {
	file *UploadFileInfo
	err  error
}

func (ut *UploadTask) runUploadFileAttempts(ctx context.Context, files []*UploadFileInfo) []uploadFileAttemptResult {
	fileSem := make(chan struct{}, max(1, ut.FileConcurrency))
	var g errgroup.Group
	var resultMu sync.Mutex
	results := make([]uploadFileAttemptResult, 0, len(files))

loop:
	for _, file := range files {
		fi := file
		select {
		case <-ctx.Done():
			break loop
		case fileSem <- struct{}{}:
			g.Go(func() error {
				defer func() {
					<-fileSem
				}()
				err := fi.Upload(ctx)
				if err != nil && !errors.Is(err, context.Canceled) {
					fi.recordExecutionError(err)
				}
				resultMu.Lock()
				results = append(results, uploadFileAttemptResult{
					file: fi,
					err:  err,
				})
				resultMu.Unlock()
				return nil
			})
		}
	}

	_ = g.Wait()
	return results
}

func (ut *UploadTask) uploadFiles(ctx context.Context, files []*UploadFileInfo) error {
	results := ut.runUploadFileAttempts(ctx, files)
	if err := ctx.Err(); err != nil {
		return err
	}

	var finalFailures []uploadFileAttemptResult
	for _, result := range results {
		if result.err != nil {
			finalFailures = append(finalFailures, result)
		}
	}

	var joinedErr error
	for _, failure := range finalFailures {
		if failure.file == nil || failure.err == nil || errors.Is(failure.err, context.Canceled) {
			continue
		}
		joinedErr = errors.Join(joinedErr, fmt.Errorf("upload %s: %w", failure.file.ObjectKey, failure.err))
	}
	return joinedErr
}

func (ut *UploadTask) workerCountForPending(pending int) int {
	if pending <= 0 {
		return 0
	}
	workers := ut.FileConcurrency
	if workers <= 0 {
		workers = 1
	}
	if pending < workers {
		return pending
	}
	return workers
}

func (ut *UploadTask) registerInitializedFile(file *UploadFileInfo) {
	if file == nil {
		return
	}
	file.mu.Lock()
	if file.registered {
		file.mu.Unlock()
		return
	}
	file.registered = true
	file.mu.Unlock()
	atomic.AddInt64(&ut.PreparedSessionFiles, 1)

	desiredTransferred := file.resumeTransferredBytes()
	if file.Exists || file.Status == string(types.UploadFileStatusExists) || file.Status == string(types.UploadFileStatusCommitted) {
		desiredTransferred = file.Size
		file.Uploaded = true
		file.Verified = true
	}
	if desiredTransferred < 0 {
		desiredTransferred = 0
	}
	if file.Size > 0 && desiredTransferred > file.Size {
		desiredTransferred = file.Size
	}
	file.setConfirmedTransferred(desiredTransferred)
	file.setLiveTransferred(desiredTransferred)

	classification := "rejected"
	ut.mu.Lock()
	switch {
	case file.Ready:
		ut.ReadyFiles = append(ut.ReadyFiles, file)
		classification = "ready"
	case file.Exists || file.Status == string(types.UploadFileStatusExists) || file.Status == string(types.UploadFileStatusCommitted):
		ut.ConflictFiles = append(ut.ConflictFiles, file)
		classification = "conflict"
	default:
		if file.ReasonCode == "CONFLICT" && ut.logger != nil {
			ut.logger.Warn("upload init rejected by active conflict",
				"object_key", file.ObjectKey,
				"status", file.Status,
				"message", file.Message)
		}
		ut.RejectedFiles = append(ut.RejectedFiles, file)
	}
	readyFiles := len(ut.ReadyFiles)
	conflictFiles := len(ut.ConflictFiles)
	rejectedFiles := len(ut.RejectedFiles)
	ut.mu.Unlock()

	if ut.logger != nil {
		ut.logger.Debug("upload file registered after init",
			"object_key", file.ObjectKey,
			"classification", classification,
			"ready", file.Ready,
			"exists", file.Exists,
			"status", file.Status,
			"uploaded", file.Uploaded,
			"verified", file.Verified,
			"transferred", atomic.LoadInt64(&file.Transferred),
			"ready_files", readyFiles,
			"conflict_files", conflictFiles,
			"rejected_files", rejectedFiles)
	}
}

func (ut *UploadTask) updateTransferRate(ctx context.Context) error {
	interval := 300 * time.Millisecond
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	swa := average.NewSMA(20)
	lastNetworkSent := atomic.LoadInt64(&ut.NetworkSent)
	lastAt := time.Now()

	for {
		select {
		case <-ctx.Done():
			ut.sampleTransferRates(swa, &lastNetworkSent, &lastAt, time.Now())
			return nil
		case <-ticker.C:
			ut.sampleTransferRates(swa, &lastNetworkSent, &lastAt, time.Now())
		}
	}
}

func (ut *UploadTask) sampleTransferRates(swa *average.SMA, lastNetworkSent *int64, lastAt *time.Time, now time.Time) {
	elapsed := now.Sub(*lastAt)
	if elapsed <= 0 {
		return
	}
	currentNetworkSent := atomic.LoadInt64(&ut.NetworkSent)
	delta := currentNetworkSent - *lastNetworkSent
	if delta < 0 {
		delta = 0
	}
	atomic.StoreInt64(&ut.Rate, int64(swa.Update(float64(delta)/elapsed.Seconds())))
	*lastNetworkSent = currentNetworkSent
	*lastAt = now

	ut.TransferingFiles.Range(func(_, value any) bool {
		if file, ok := value.(*UploadFileInfo); ok && file != nil {
			file.sampleTransferRates(elapsed)
		}
		return true
	})
}

func (ut *UploadTask) reportProgress(ctx context.Context) {
	interval := ut.progressEventInterval
	if interval <= 0 {
		interval = eventcollector.DefaultProgressInterval
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			ut.publishProgressSnapshot()
			return
		case <-ticker.C:
			ut.publishProgressSnapshot()
		}
	}
}

func (ut *UploadTask) publishProgressSnapshot() {
	ut.publishProgress(true)
	ut.TransferingFiles.Range(func(_, value any) bool {
		if file, ok := value.(*UploadFileInfo); ok && file != nil {
			file.publishProgressEvents(true)
		}
		return true
	})
}

func (ut *UploadTask) publishProgress(force bool) {
	if ut == nil || ut.publisher == nil {
		return
	}
	if !eventcollector.ShouldPublishProgress(&ut.lastTaskProgressPublishedAt, ut.progressEventInterval, force) {
		return
	}
	ut.publisher.Publish(types.NewTaskProgressEvent(
		ut.TaskID,
		atomic.LoadInt64(&ut.TotalSize),
		atomic.LoadInt64(&ut.Transferred),
		atomic.LoadInt64(&ut.Rate),
	))
}

func uploadFileFinished(file *UploadFileInfo) bool {
	if file == nil {
		return false
	}
	return file.Verified || file.Uploaded || file.Exists ||
		file.Status == string(types.UploadFileStatusExists) ||
		file.Status == string(types.UploadFileStatusCommitted)
}

func (ut *UploadTask) allFilesFinished() bool {
	if len(ut.RejectedFiles) > 0 {
		return false
	}
	if len(ut.FileList) == 0 {
		return true
	}
	for _, file := range ut.FileList {
		if uploadFileFinished(file) {
			continue
		}
		return false
	}
	return true
}

func (ut *UploadTask) ToUploadTaskSummary() *types.UploadTaskSummary {

	ut.mu.Lock()
	status, cause, started := ut.Status, ut.Err, ut.Started
	ut.mu.Unlock()
	var transferringFiles []*types.UploadFileInfoSummary
	ut.TransferingFiles.Range(func(key, value any) bool {
		if fileInfo, ok := value.(*UploadFileInfo); ok {
			transferringFiles = append(transferringFiles, fileInfo.ToFileInfoSummary())
		}
		return true
	})

	return &types.UploadTaskSummary{
		Cause:            cause,
		TaskID:           ut.TaskID,
		TaskName:         ut.TaskName,
		Mode:             ut.Mode,
		Status:           status,
		Err:              errString(cause),
		ReasonCode:       clienterror.ReasonCode(cause),
		Started:          started,
		Transferred:      atomic.LoadInt64(&ut.Transferred),
		TotalSize:        atomic.LoadInt64(&ut.TotalSize),
		Rate:             atomic.LoadInt64(&ut.Rate),
		TransferingFiles: transferringFiles,
	}
}

// Snapshot returns a stable complete view for the detail API.
func (ut *UploadTask) Snapshot() domain.TaskSnapshot {
	ut.mu.Lock()
	defer ut.mu.Unlock()
	status, cause, started := ut.Status, ut.Err, ut.Started
	createdAt, updatedAt, startedAt, finishedAt := ut.CreatedAt, ut.UpdatedAt, ut.StartedAt, ut.FinishedAt
	snapshotFiles := ut.ReadyFiles
	if len(ut.pathMappings) > 0 {
		snapshotFiles = ut.FileList
	}
	files := make([]*types.UploadFileInfoDetail, 0, len(snapshotFiles))
	for _, file := range snapshotFiles {
		if file == nil {
			continue
		}
		files = append(files, file.ToFileInfoDetail())
	}
	conflictFiles := make([]*types.UploadFileInfoDetail, 0, len(ut.ConflictFiles))
	for _, file := range ut.ConflictFiles {
		if file == nil {
			continue
		}
		conflictFiles = append(conflictFiles, file.ToFileInfoDetail())
	}
	rejectedFiles := make([]*types.UploadFileInfoDetail, 0, len(ut.RejectedFiles))
	for _, file := range ut.RejectedFiles {
		if file == nil {
			continue
		}
		rejectedFiles = append(rejectedFiles, file.ToFileInfoDetail())
	}

	return &types.UploadTaskDetail{
		PathMappings:    append([]types.PathMapping(nil), ut.pathMappings...),
		Transport:       ut.Transport,
		Connections:     ut.networkConfig.Pool.Connections,
		Streams:         ut.networkConfig.Pool.StreamsPerConnection,
		FileConcurrency: ut.FileConcurrency,
		Cause:           cause,
		TaskID:          ut.TaskID,
		TaskName:        ut.TaskName,
		Mode:            ut.Mode,
		ServerAddr:      ut.ServerAddr,
		SourceDir:       ut.SourceDir,
		ServerTaskID:    ut.ServerTaskID,
		Status:          status,
		Err:             errString(cause),
		ReasonCode:      clienterror.ReasonCode(cause),
		Started:         started,
		Files:           files,
		ConflictFiles:   conflictFiles,
		RejectedFiles:   rejectedFiles,
		Transferred:     atomic.LoadInt64(&ut.Transferred),
		NetworkSent:     atomic.LoadInt64(&ut.NetworkSent),
		TotalSize:       atomic.LoadInt64(&ut.TotalSize),
		Rate:            atomic.LoadInt64(&ut.Rate),
		CreatedAt:       createdAt,
		UpdatedAt:       updatedAt,
		StartedAt:       startedAt,
		FinishedAt:      finishedAt,
	}
}

func (ut *UploadTask) GetID() string {
	return ut.TaskID
}

func (ut *UploadTask) GetTaskPID() string {
	return ut.TaskPID
}

func (ut *UploadTask) GetEnterpriseID() string {
	return ut.EnterpriseID
}

func (ut *UploadTask) GetName() string {
	return ut.TaskName
}

func (ut *UploadTask) GetType() domain.TaskType {
	return domain.TaskTypeUpload
}

// GetStatus returns a lock-consistent basic status for manager decisions.
func (ut *UploadTask) GetStatus() domain.TaskBasicStatus {
	ut.mu.Lock()
	defer ut.mu.Unlock()
	return domain.TaskBasicStatus{
		Status:     ut.Status,
		Error:      ut.Err,
		Started:    ut.Started,
		StartedAt:  ut.StartedAt,
		FinishedAt: ut.FinishedAt,
	}
}

// Retry only changes a terminal status back to pending. It deliberately keeps
// the previous error, progress, files and execution control fields until the
// next Run initializes a new round.
func (ut *UploadTask) Retry() error {
	ut.mu.Lock()
	defer ut.mu.Unlock()
	if !isTerminalTaskStatus(ut.Status) {
		return fmt.Errorf("%w: cannot retry upload task in %s", domain.ErrInvalidTaskState, ut.Status)
	}
	if ut.requiresNewTaskID && !ut.autoRetry {
		return fmt.Errorf("%w; create a new upload task to obtain a new server task ID", ErrLocalFileChanged)
	}
	if !types.IsValidTransition(ut.Status, types.StatusPending) {
		return fmt.Errorf("%w: invalid transition to pending", domain.ErrInvalidTaskState)
	}
	// Retry only changes the status. UpdatedAt, error, progress, times, files and
	// execution control fields stay as the previous round left them.
	ut.Status = types.StatusPending
	ut.publishStatusLocked(types.NewTaskStatusEvent(
		ut.TaskID,
		types.TaskStatusToEventStatus(types.StatusPending),
		"",
	))
	return nil
}

func (ut *UploadTask) prepareRunLocked() {
	ut.rateLimiter = ratelimit.New(ut.LimitRate)
	atomic.StoreInt64(&ut.Transferred, 0)
	atomic.StoreInt64(&ut.Confirmed, 0)
	atomic.StoreInt64(&ut.NetworkSent, 0)
	atomic.StoreInt64(&ut.TotalSize, 0)
	atomic.StoreInt64(&ut.Rate, 0)
	atomic.StoreInt64(&ut.HashedBytes, 0)
	atomic.StoreInt64(&ut.PreparedSessionFiles, 0)
	if ut.requiresNewTaskID {
		// Keep the client task identity, but never correlate changed content with
		// the previous server execution.
		ut.ServerTaskID = uuid.NewString()
		ut.requiresNewTaskID = false
	}
	if strings.TrimSpace(ut.ServerTaskID) == "" {
		ut.ServerTaskID = strings.TrimSpace(ut.RequestedServerTaskID)
		if ut.ServerTaskID == "" {
			ut.ServerTaskID = ut.TaskID
		}
	}
	ut.TransferingFiles.Clear()
	ut.ReadyFiles = nil
	ut.ConflictFiles = nil
	ut.RejectedFiles = nil
	for _, file := range ut.FileList {
		if file != nil {
			file.reset()
		}
	}
	ut.lastTaskProgressPublishedAt.Store(0)
	ut.Phase = ""
}

func (ut *UploadTask) setError(err error) {
	ut.Err = clienterror.Normalize(err)
	ut.UpdatedAt = time.Now()
}

func (ut *UploadTask) ToSummary() domain.TaskSummary {
	return ut.ToUploadTaskSummary()
}

func (ut *UploadTask) transitionTo(newStatus types.TaskStatus) error {
	if !types.IsValidTransition(ut.Status, newStatus) {
		return fmt.Errorf("invalid status transition from %s to %s", ut.Status, newStatus)
	}
	oldStatus := ut.Status
	ut.UpdatedAt = time.Now()
	ut.Status = newStatus
	ut.logger.Debug("upload task status changed", "from", oldStatus, "to", newStatus)
	statusEvent := types.NewTaskStatusEventWithCause(
		ut.TaskID,
		types.TaskStatusToEventStatus(ut.Status),
		errString(ut.Err),
		clienterror.ReasonCode(ut.Err),
		ut.Err,
	)
	if isTerminalTaskStatus(newStatus) {
		ut.publishProgress(true)
		ut.publishStatusLocked(statusEvent)
	} else {
		ut.publishStatusLocked(statusEvent)
		ut.publishProgress(true)
	}
	return nil
}

func (ut *UploadTask) publishStatusLocked(event types.TaskEvent) {
	if ut.publisher != nil {
		ut.publisher.Publish(event)
	}
}

func isTerminalTaskStatus(status types.TaskStatus) bool {
	return status == types.StatusCompleted || status == types.StatusFailed || status == types.StatusStopped
}
