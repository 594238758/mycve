package uploadtask

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"

	"qtransc/internal/clienterror"
	"qtransc/internal/netclient"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/transferretry"
	"qtransc/internal/types"
	"qtransc/internal/uploadstate"
	"qtransc/internal/version"
)

var errUploadSessionReinitialized = errors.New("upload session reinitialized")

func (ut *UploadTask) initUploadSession(ctx context.Context, file *UploadFileInfo) error {
	if ut.state == nil {
		return fmt.Errorf("LOCAL_STATE_ERROR: upload state database is not open")
	}
	local, err := filepath.Abs(file.FullPath)
	if err != nil {
		return fmt.Errorf("LOCAL_STATE_ERROR: normalize local path: %w", err)
	}
	local = filepath.Clean(local)
	file.FullPath = local
	state, exists, err := ut.state.Get(ctx, local, ut.ServerAddr, file.ObjectKey)
	if err != nil {
		return fmt.Errorf("LOCAL_STATE_ERROR: %w", err)
	}
	if exists {
		storedFingerprint := sourceFingerprint{Size: state.Size, MTimeNS: state.MTimeNS, CTimeNS: state.CTimeNS, FileID: state.FileID}
		if !storedFingerprint.equal(file.fingerprint) {
			if err := ut.state.Delete(ctx, local, ut.ServerAddr, file.ObjectKey); err != nil {
				return fmt.Errorf("LOCAL_STATE_ERROR: %w", err)
			}
			file.stateOwned = false
			_ = file.cancelSessionID(context.Background(), state.SessionID)
		} else {
			file.stateOwned = true
			file.SessionID = state.SessionID
			if state.FileHash != "" {
				file.FileHash = state.FileHash
			}
			resumed, err := file.resumeCanonicalSession(ctx)
			if err != nil && !qtserverapi.IsReason(err, "SESSION_NOT_FOUND") {
				return err
			}
			if resumed {
				return nil
			}
			if err := ut.state.Delete(ctx, local, ut.ServerAddr, file.ObjectKey); err != nil {
				return fmt.Errorf("LOCAL_STATE_ERROR: %w", err)
			}
			file.stateOwned = false
		}
	}
	return file.createCanonicalSession(ctx, false)
}

func (fi *UploadFileInfo) createCanonicalSession(ctx context.Context, overwrite bool) error {
	token, err := fi.task.currentBearerToken()
	if err != nil {
		return err
	}
	clientID, err := version.CurrentClientID()
	if err != nil {
		return fmt.Errorf("read client id: %w", err)
	}
	requestHeaders := make(http.Header)
	requestHeaders.Set("Client-ID", clientID)
	requestHeaders.Set("Client-OS", runtime.GOOS)
	requestHeaders.Set("Client-Version", version.Version)
	requestHeaders.Set("Caller-Version", fi.task.CallerVersion)
	request := types.CanonicalUploadInitRequest{
		ObjectKey: fi.ObjectKey, FileSize: fi.Size, FileHash: fi.FileHash,
		HashAlgorithm: types.UploadHashAlgorithmLayeredXXH3_128, Overwrite: overwrite,
	}
	for {
		status, header, body, err := fi.task.doJSONWithHeadersAndCorrelation(ctx, "/uploads", http.MethodPost, token, request, requestHeaders, qtserverapi.IdempotentRetry)
		if err != nil {
			return fmt.Errorf("initialize canonical upload: %w", err)
		}
		if status == http.StatusAccepted {
			wait := 5 * time.Second
			if retryAfter := strings.TrimSpace(header.Get("Retry-After")); retryAfter != "" {
				if seconds, parseErr := strconv.Atoi(retryAfter); parseErr == nil && seconds >= 0 {
					wait = time.Duration(seconds) * time.Second
				} else if at, parseErr := http.ParseTime(retryAfter); parseErr == nil && at.After(time.Now()) {
					wait = time.Until(at)
				}
			}
			timer := time.NewTimer(wait)
			select {
			case <-ctx.Done():
				timer.Stop()
				return ctx.Err()
			case <-timer.C:
				continue
			}
		}
		var response types.CanonicalUploadResponse
		if err := json.Unmarshal(body, &response); err != nil {
			return fmt.Errorf("decode canonical upload init: %w", err)
		}
		if response.Status == "target_exists" {
			if response.TargetSize == fi.Size && response.TargetHash != "" && response.TargetHash == fi.FileHash {
				fi.Exists, fi.Uploaded, fi.Verified = true, true, true
				fi.Status, fi.Message = string(types.UploadFileStatusExists), "remote target already has identical content"
				if err := fi.deleteUploadState(ctx); err != nil {
					return fmt.Errorf("LOCAL_STATE_CLEANUP_FAILED: %w", err)
				}
				return nil
			}
			if overwrite {
				return fmt.Errorf("upload init returned target_exists despite overwrite")
			}
			overwrite = true
			request.Overwrite = true
			continue
		}
		if status != http.StatusCreated || response.Status != "active" || response.SessionID == "" {
			return fmt.Errorf("unexpected canonical upload init response: status=%d state=%q", status, response.Status)
		}
		if response.ChunkSize != int64(fileChunkSize()) || response.ChunkCount != len(fi.chunkHashes) {
			_ = fi.cancelSessionID(context.Background(), response.SessionID)
			return fmt.Errorf("canonical upload parameters are incompatible: chunk_size=%d chunk_count=%d", response.ChunkSize, response.ChunkCount)
		}
		fi.applyCanonicalSession(response)
		state := uploadstate.FileState{
			LocalAbsolutePath: fi.FullPath, Server: fi.task.ServerAddr, RemoteAbsolutePath: fi.ObjectKey,
			SessionID: response.SessionID, Size: fi.fingerprint.Size, MTimeNS: fi.fingerprint.MTimeNS,
			CTimeNS: fi.fingerprint.CTimeNS, FileID: fi.fingerprint.FileID,
			FileHash: fi.FileHash, HashAlgorithm: types.UploadHashAlgorithmLayeredXXH3_128,
		}
		if err := fi.task.state.Put(ctx, state); err != nil {
			_ = fi.cancelSessionID(context.Background(), response.SessionID)
			return fmt.Errorf("LOCAL_STATE_ERROR: %w", err)
		}
		fi.stateOwned = true
		return nil
	}
}

func fileChunkSize() int { return 100 * 1024 * 1024 }

func (fi *UploadFileInfo) resumeCanonicalSession(ctx context.Context) (bool, error) {
	token, err := fi.task.currentBearerToken()
	if err != nil {
		return false, err
	}
	endpoint := "/uploads/" + fi.SessionID
	_, _, body, err := fi.task.doJSONWithCorrelation(ctx, endpoint, http.MethodGet, token, nil, qtserverapi.IdempotentRetry)
	if err != nil {
		return false, err
	}
	var response types.CanonicalUploadResponse
	if err := json.Unmarshal(body, &response); err != nil {
		return false, fmt.Errorf("decode canonical upload state: %w", err)
	}
	if response.Status == "committed" {
		fi.SessionID = response.SessionID
		fi.Status, fi.Exists, fi.Uploaded, fi.Verified = string(types.UploadFileStatusCommitted), true, true, true
		if err := fi.deleteUploadState(ctx); err != nil {
			return false, fmt.Errorf("LOCAL_STATE_CLEANUP_FAILED: %w", err)
		}
		fi.bestEffortRelease()
		return true, nil
	}
	if response.Status != "active" || response.ObjectKey != fi.ObjectKey || response.FileSize != fi.Size {
		return false, fmt.Errorf("canonical upload session does not match local business key")
	}
	fi.applyCanonicalSession(response)
	return true, nil
}

func (fi *UploadFileInfo) applyCanonicalSession(response types.CanonicalUploadResponse) {
	// A GET/create response is the authoritative replacement for any in-flight
	// local estimate left by the previous session.
	fi.progressMu.Lock()
	defer fi.progressMu.Unlock()
	fi.setLiveTransferred(0)
	fi.setConfirmedTransferred(0)
	fi.mu.Lock()
	fi.SessionID = response.SessionID
	fi.Status = string(types.UploadFileStatusActive)
	fi.Ready = true
	fi.Exists = false
	fi.ChunkSize = response.ChunkSize
	fi.ChunkCount = response.ChunkCount
	fi.HashAlgorithm = types.UploadHashAlgorithmLayeredXXH3_128
	fi.uploadedChunks = nil
	fi.verifiedChunks = nil
	fi.chunkStoredBytes = nil
	for rawIndex, chunk := range response.Chunks {
		index, err := strconv.Atoi(rawIndex)
		if err != nil || index < 0 || index >= fi.ChunkCount {
			continue
		}
		fi.setConfirmedChunkStoredBytesLocked(index, chunk.Stored)
		if chunk.State == "verified" {
			fi.setConfirmedChunkStoredBytesLocked(index, chunkByteSize(fi.Size, fi.ChunkSize, fi.ChunkCount, index))
			if fi.verifiedChunks == nil {
				fi.verifiedChunks = make(map[int]struct{})
			}
			fi.verifiedChunks[index] = struct{}{}
		}
	}
	fi.UploadURL, _ = qtserverurl.JoinEndpoint(fi.task.ServerAddr, "/uploads/"+fi.SessionID)
	fi.mu.Unlock()
	fi.rebuildChunkProgress()
	fi.syncTransferredWithConfirmedStateLocked()
}

func (fi *UploadFileInfo) uploadChunkSession(ctx context.Context, file *os.File, chunkIndex int) error {
	if err := fi.ensureSourceUnchanged(ctx); err != nil {
		return err
	}
	chunkProgressStarted := false
	chunkProgressEnded := false
	defer func() {
		if chunkProgressStarted && !chunkProgressEnded {
			fi.endChunkProgress(chunkIndex)
		}
	}()
	availabilityBackoff := transferretry.NewBackoff()
	var semanticRecoveryStarted time.Time
	var http500Budget transferretry.HTTP500Budget
	for {
		chunk, err := fi.fetchCanonicalChunk(ctx, chunkIndex)
		if err != nil {
			if qtserverapi.IsReason(err, "SESSION_NOT_FOUND") {
				if recoveryErr := fi.reinitializeMissingSession(ctx, fi.SessionID); recoveryErr != nil {
					return recoveryErr
				}
				return errUploadSessionReinitialized
			}
			return err
		}
		chunkBytes := chunkByteSize(fi.Size, fi.ChunkSize, fi.ChunkCount, chunkIndex)
		if chunk.State == "verified" {
			fi.reconcileChunkWithConfirmedState(chunkIndex, chunkBytes)
			return nil
		}
		if chunk.Stored < 0 || chunk.Stored > chunkBytes {
			return fmt.Errorf("server returned invalid chunk offset %d", chunk.Stored)
		}
		fi.reconcileChunkWithConfirmedState(chunkIndex, chunk.Stored)
		if !chunkProgressStarted {
			fi.beginChunkProgress(chunkIndex)
			chunkProgressStarted = true
		}
		if chunk.Stored < chunkBytes {
			if err := fi.patchCanonicalChunk(ctx, file, chunkIndex, chunk.Stored, chunkBytes-chunk.Stored); err != nil {
				var apiErr *qtserverapi.APIError
				isAPIError := errors.As(err, &apiErr)
				semanticFailure := false
				switch {
				case isAPIError && apiErr.Status == http.StatusInternalServerError:
					if !http500Budget.Take() {
						return err
					}
				case isCanonicalAvailabilityError(ctx, err):
				case qtserverapi.IsReason(err, "CHUNK_OFFSET_MISMATCH") || qtserverapi.IsReason(err, "CHUNK_HASH_MISMATCH"):
					if semanticRecoveryStarted.IsZero() {
						semanticRecoveryStarted = time.Now()
					}
					semanticFailure = true
				default:
					return err
				}
				delay := availabilityBackoff.Next(apiHeader(err), time.Now())
				if semanticFailure && !semanticRecoveryStarted.IsZero() && time.Since(semanticRecoveryStarted)+delay > 30*time.Second {
					return fmt.Errorf("%w: %w", qtserverapi.ErrRetryWindowExhausted, err)
				}
				if err := transferretry.Wait(ctx, delay); err != nil {
					return err
				}
				continue
			}
			availabilityBackoff.Reset()
			semanticRecoveryStarted = time.Time{}
			http500Budget.Reset()
			fi.reconcileChunkWithConfirmedState(chunkIndex, chunkBytes)
		}
		if err := fi.ensureSourceUnchanged(ctx); err != nil {
			return err
		}
		if err := fi.finalizeCanonicalChunk(ctx, chunkIndex); err != nil {
			if qtserverapi.IsReason(err, "SESSION_NOT_FOUND") {
				if recoveryErr := fi.reinitializeMissingSession(ctx, fi.SessionID); recoveryErr != nil {
					return recoveryErr
				}
				return errUploadSessionReinitialized
			}
			if !qtserverapi.IsReason(err, "CHUNK_HASH_MISMATCH") {
				return err
			}
			if semanticRecoveryStarted.IsZero() {
				semanticRecoveryStarted = time.Now()
			}
			delay := availabilityBackoff.Next(apiHeader(err), time.Now())
			if time.Since(semanticRecoveryStarted)+delay > 30*time.Second {
				return fmt.Errorf("%w: %w", qtserverapi.ErrRetryWindowExhausted, err)
			}
			if err := transferretry.Wait(ctx, delay); err != nil {
				return err
			}
			continue
		}
		fi.markChunkCompleted(chunkIndex)
		if err := fi.ensureSourceUnchanged(ctx); err != nil {
			return err
		}
		fi.endChunkProgress(chunkIndex)
		chunkProgressEnded = true
		fi.publishChunkStatus(chunkIndex, types.ChunkEventStatusCompleted)
		return nil
	}
}

func (fi *UploadFileInfo) fetchCanonicalChunk(ctx context.Context, index int) (types.CanonicalUploadChunk, error) {
	token, err := fi.task.currentBearerToken()
	if err != nil {
		return types.CanonicalUploadChunk{}, err
	}
	endpoint := fmt.Sprintf("/uploads/%s/chunks/%d", fi.SessionID, index)
	_, _, body, err := fi.task.doJSONWithCorrelation(ctx, endpoint, http.MethodGet, token, nil, qtserverapi.IdempotentRetry)
	if err != nil {
		return types.CanonicalUploadChunk{}, err
	}
	var response struct {
		State  string `json:"state"`
		Stored int64  `json:"stored"`
		Hash   string `json:"hash"`
	}
	if err := json.Unmarshal(body, &response); err != nil {
		return types.CanonicalUploadChunk{}, err
	}
	return types.CanonicalUploadChunk{State: response.State, Stored: response.Stored, Hash: response.Hash}, nil
}

func (fi *UploadFileInfo) patchCanonicalChunk(ctx context.Context, file *os.File, index int, offset, length int64) (returnErr error) {
	defer func() {
		if returnErr != nil {
			fi.setChunkLiveTransferred(index, fi.currentChunkStoredBytes(index))
		}
	}()
	requestURL, err := qtserverurl.JoinEndpoint(fi.task.ServerAddr, fmt.Sprintf("/uploads/%s/chunks/%d", fi.SessionID, index))
	if err != nil {
		return err
	}
	authRefreshAttempted := false
	for {
		fi.setChunkLiveTransferred(index, offset)
		newBody := fi.newPatchBody(ctx, file, index, offset, length)
		bodyReader, bodyErr := newBody()
		if bodyErr != nil {
			return bodyErr
		}
		request, requestErr := http.NewRequestWithContext(ctx, http.MethodPatch, requestURL, bodyReader)
		if requestErr != nil {
			return requestErr
		}
		request.GetBody = newBody
		request.ContentLength = length
		request.Header["Idempotency-Key"] = []string{}
		request.Header.Set("Content-Type", "application/octet-stream")
		request.Header.Set("Upload-Offset", strconv.FormatInt(offset, 10))
		qtserverapi.SetTaskCorrelationHeaders(request.Header, fi.task.taskCorrelation())
		token, tokenErr := fi.task.currentBearerToken()
		if tokenErr != nil {
			return tokenErr
		}
		applyBearerTokenHeader(request, token)
		client, release, acquireErr := fi.task.acquireClient(ctx, requestURL)
		if acquireErr != nil {
			return acquireErr
		}
		response, responseErr := client.Do(request)
		if responseErr != nil {
			release()
			return fmt.Errorf("patch canonical chunk: %w", responseErr)
		}
		body, readErr := io.ReadAll(io.LimitReader(response.Body, 2<<20))
		_ = response.Body.Close()
		release()
		if readErr != nil {
			return fmt.Errorf("read patch response: %w", readErr)
		}
		if response.StatusCode == http.StatusUnauthorized && !authRefreshAttempted && fi.task.refreshAuthorizationAfter401(ctx, response.StatusCode) {
			authRefreshAttempted = true
			continue
		}
		if response.StatusCode != http.StatusNoContent {
			return canonicalAPIError(response.StatusCode, response.Header, body)
		}
		return nil
	}
}

func (fi *UploadFileInfo) newPatchBody(ctx context.Context, file *os.File, index int, offset, length int64) func() (io.ReadCloser, error) {
	return func() (io.ReadCloser, error) {
		var attemptRead int64
		reader := io.NewSectionReader(file, int64(index)*fi.ChunkSize+offset, length)
		limited := fi.task.wrapRateLimitedReader(ctx, reader)
		progress := &progressReader{
			r: limited,
			onRead: func(n int) {
				bytes := int64(n)
				attemptRead += bytes
				fi.recordChunkRead(index, offset+attemptRead, bytes)
			},
			wrapError: func(err error) error {
				if os.IsNotExist(err) {
					return clienterror.New(clienterror.CodeLocalFileNotFound, "本地上传源不存在："+fi.FullPath, err)
				}
				return clienterror.New(clienterror.CodeLocalPathInvalid, "读取本地上传源失败："+fi.FullPath, err)
			},
		}
		return io.NopCloser(progress), nil
	}
}

func (fi *UploadFileInfo) finalizeCanonicalChunk(ctx context.Context, index int) error {
	token, err := fi.task.currentBearerToken()
	if err != nil {
		return err
	}
	endpoint := fmt.Sprintf("/uploads/%s/chunks/%d/finalize", fi.SessionID, index)
	payload := map[string]string{"chunk_hash": fi.chunkHashes[index]}
	_, _, _, err = fi.task.doJSONWithCorrelation(ctx, endpoint, http.MethodPost, token, payload, qtserverapi.IdempotentRetry)
	return err
}

func (fi *UploadFileInfo) completeUploadSession(ctx context.Context) error {
	if err := fi.ensureSourceUnchanged(ctx); err != nil {
		return err
	}
	token, err := fi.task.currentBearerToken()
	if err != nil {
		return err
	}
	endpoint := "/uploads/" + fi.SessionID + "/complete"
	_, _, body, err := fi.task.doJSONWithCorrelation(ctx, endpoint, http.MethodPost, token, struct{}{}, qtserverapi.PersistentBusyRetry)
	if err != nil {
		if qtserverapi.IsReason(err, "SESSION_NOT_FOUND") {
			if recoveryErr := fi.reinitializeMissingSession(ctx, fi.SessionID); recoveryErr != nil {
				return recoveryErr
			}
			return errUploadSessionReinitialized
		}
		return fmt.Errorf("complete canonical upload: %w", err)
	}
	var response types.CanonicalUploadResponse
	if err := json.Unmarshal(body, &response); err != nil {
		return err
	}
	if response.FileHash != fi.FileHash || response.HashAlgorithm != types.UploadHashAlgorithmLayeredXXH3_128 {
		return fmt.Errorf("canonical upload committed with unexpected hash")
	}
	fi.Status = string(types.UploadFileStatusCommitted)
	if err := fi.deleteUploadState(ctx); err != nil {
		return fmt.Errorf("LOCAL_STATE_CLEANUP_FAILED: %w", err)
	}
	fi.bestEffortRelease()
	return nil
}

func (fi *UploadFileInfo) reinitializeMissingSession(ctx context.Context, missingSessionID string) error {
	fi.sessionRecoveryMu.Lock()
	defer fi.sessionRecoveryMu.Unlock()
	if fi.SessionID != missingSessionID {
		return nil
	}
	if err := fi.deleteUploadState(ctx); err != nil {
		return fmt.Errorf("LOCAL_STATE_ERROR: %w", err)
	}
	fi.SessionID = ""
	fi.Ready = false
	return fi.createCanonicalSession(ctx, false)
}

func (fi *UploadFileInfo) deleteUploadState(ctx context.Context) error {
	if fi.task == nil || fi.task.state == nil {
		return nil
	}
	if err := fi.task.state.Delete(ctx, fi.FullPath, fi.task.ServerAddr, fi.ObjectKey); err != nil {
		return err
	}
	fi.stateOwned = false
	return nil
}

func (fi *UploadFileInfo) bestEffortRelease() {
	if fi.SessionID == "" {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	token, err := fi.task.currentBearerToken()
	if err != nil {
		return
	}
	_, _, _, _ = fi.task.doJSONWithCorrelation(ctx, "/uploads/"+fi.SessionID+"/release", http.MethodPost, token, nil, qtserverapi.IdempotentRetry)
}

// Abandon stops execution and removes local resumable state only. The manager
// holds its admission lock until this succeeds and deletion is committed.
func (ut *UploadTask) Abandon() error {
	ut.mu.Lock()
	cancel := ut.cancel
	roundDone := ut.roundDone
	ut.mu.Unlock()
	if cancel != nil {
		cancel()
	}
	if roundDone != nil {
		<-roundDone
	}

	hasState := false
	for _, file := range ut.FileList {
		if file != nil && (file.stateOwned || file.SessionID != "") {
			hasState = true
			break
		}
	}
	if hasState {
		cleanupCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		err := ut.ensureUploadState(cleanupCtx)
		cancel()
		if err != nil {
			return fmt.Errorf("LOCAL_STATE_CLEANUP_FAILED: %w", err)
		}
	}

	var joined error
	for _, file := range ut.FileList {
		if file == nil || (!file.stateOwned && file.SessionID == "") {
			continue
		}
		cleanupCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		if err := file.deleteUploadState(cleanupCtx); err != nil {
			joined = errors.Join(joined, fmt.Errorf("LOCAL_STATE_CLEANUP_FAILED: %w", err))
		}
		cancel()
	}
	ut.closeUploadState()
	return joined
}

// ReportDeleted cancels only this task's remote sessions after local deletion.
// A replacement task may already be using the same local state database.
func (ut *UploadTask) ReportDeleted(ctx context.Context) error {
	client, err := netclient.New(ut.Transport, ut.networkConfig)
	if err != nil {
		return err
	}
	defer client.Close()
	var joined error
	for _, file := range ut.FileList {
		if file == nil || file.SessionID == "" {
			continue
		}
		abortCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
		if err := file.cancelSessionIDWithClient(abortCtx, file.SessionID, client); err != nil {
			joined = errors.Join(joined, err)
		}
		cancel()
	}
	return joined
}

func (fi *UploadFileInfo) cancelSessionID(ctx context.Context, sessionID string) error {
	return fi.cancelSessionIDWithClient(ctx, sessionID, fi.task.client)
}

func (fi *UploadFileInfo) cancelSessionIDWithClient(ctx context.Context, sessionID string, client *netclient.Client) error {
	if sessionID == "" {
		return nil
	}
	token, err := fi.task.currentBearerToken()
	if err != nil {
		return err
	}
	if fi.task.useAuthManager {
		_, _, _, err = qtserverapi.DoJSONWithCorrelation(ctx, fi.task.ServerAddr, "/uploads/"+sessionID+"/cancel", http.MethodPost, token, fi.task.taskCorrelation(), nil, client, qtserverapi.IdempotentRetry)
	} else {
		_, _, _, err = qtserverapi.DoJSONWithCorrelationWithoutAuthRefresh(ctx, fi.task.ServerAddr, "/uploads/"+sessionID+"/cancel", http.MethodPost, token, fi.task.taskCorrelation(), nil, client, qtserverapi.IdempotentRetry)
	}
	return err
}

func canonicalAPIError(status int, header http.Header, body []byte) error {
	var envelope struct {
		ReasonCode string `json:"reason_code"`
		Message    string `json:"message"`
	}
	_ = json.Unmarshal(body, &envelope)
	return &qtserverapi.APIError{Status: status, ReasonCode: envelope.ReasonCode, Message: envelope.Message, Body: body, Header: header.Clone()}
}

func isCanonicalAvailabilityError(ctx context.Context, err error) bool {
	var apiErr *qtserverapi.APIError
	if errors.As(err, &apiErr) {
		return transferretry.IsAvailabilityStatus(apiErr.Status)
	}
	return transferretry.IsAvailabilityError(ctx, err)
}

func apiHeader(err error) http.Header {
	var apiErr *qtserverapi.APIError
	if errors.As(err, &apiErr) {
		return apiErr.Header
	}
	return nil
}
