//go:build !linux && !windows && !darwin

package uploadtask

import "os"

func openUploadSource(path string) (*os.File, error) {
	info, err := os.Lstat(path)
	if err != nil {
		return nil, err
	}
	if info.Mode()&os.ModeSymlink != 0 {
		return nil, os.ErrInvalid
	}
	return os.Open(path)
}

func platformFingerprint(_ *os.File, info os.FileInfo) (int64, string) {
	return info.ModTime().UnixNano(), ""
}
