package uploadtask

import (
	"context"
	"errors"
	"qtransc/internal/clienterror"
	"qtransc/internal/types"
	"time"
)

// recordFinalError is called only once a file's own retry policy has ended.
func (ut *UploadTask) recordFinalError(err error) {
	if err == nil || errors.Is(err, context.Canceled) {
		return
	}
	ut.mu.Lock()
	defer ut.mu.Unlock()
	if errors.Is(err, ErrLocalFileChanged) {
		ut.requiresNewTaskID = true
	}
	if ut.finalErr == nil {
		ut.finalErr = clienterror.Normalize(err)
	}
}

func (ut *UploadTask) finishExecution(err error, completed bool) error {
	ut.mu.Lock()
	defer ut.mu.Unlock()
	return ut.finishExecutionLocked(err, completed)
}

func (ut *UploadTask) finishExecutionLocked(err error, completed bool) error {
	if ut.Status != types.StatusPending && ut.Status != types.StatusRunning {
		return nil
	}
	if errors.Is(err, ErrLocalFileChanged) {
		ut.requiresNewTaskID = true
	}
	if err != nil && !errors.Is(err, context.Canceled) && ut.finalErr == nil {
		ut.finalErr = clienterror.Normalize(err)
	}
	ut.FinishedAt = time.Now()
	if ut.finalErr != nil {
		ut.setError(ut.finalErr)
		if transitionErr := ut.transitionTo(types.StatusFailed); transitionErr != nil {
			return transitionErr
		}
		return ut.Err
	}
	if ut.stopRequested {
		ut.Err = nil
		return ut.transitionTo(types.StatusStopped)
	}
	if err == nil && completed {
		ut.Err = nil
		return ut.transitionTo(types.StatusCompleted)
	}
	if err == nil {
		err = errors.New("task execution ended before all files completed")
	}
	ut.finalErr = clienterror.Normalize(err)
	ut.setError(ut.finalErr)
	if transitionErr := ut.transitionTo(types.StatusFailed); transitionErr != nil {
		return transitionErr
	}
	return ut.Err
}
