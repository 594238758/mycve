package uploadtask

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"qtransc/internal/average"
	"qtransc/internal/clienterror"
	"qtransc/internal/eventcollector"
	"qtransc/internal/filehash"
	"qtransc/internal/types"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	"golang.org/x/sync/errgroup"
)

var (
	ErrLocalFileChanged = errors.New("local file changed during transfer")
	// Keep the package-private alias for existing in-package callers and tests.
	errLocalFileChanged = ErrLocalFileChanged
)

func NewUploadFileInfo(task *UploadTask, localPath, objectKey string) *UploadFileInfo {
	return &UploadFileInfo{
		logger:      task.logger.With("file", localPath, "object_key", objectKey),
		task:        task,
		rateAverage: average.NewSMA(20),
		FullPath:    filepath.Join(task.SourceDir, localPath),
		LocalPath:   localPath,
		ObjectKey:   objectKey,
	}
}

func clampTransferValue(value, total int64) int64 {
	if value < 0 {
		return 0
	}
	if total > 0 && value > total {
		return total
	}
	return value
}

func addBoundedAtomic(target *int64, delta, total int64) {
	if target == nil || delta == 0 {
		return
	}
	for {
		current := atomic.LoadInt64(target)
		next := clampTransferValue(current+delta, total)
		if atomic.CompareAndSwapInt64(target, current, next) {
			return
		}
	}
}

func (fi *UploadFileInfo) eventFileKey() string {
	if fi == nil {
		return ""
	}
	if dst := fi.copyDestination(); dst != "" {
		return dst
	}
	if fi.ObjectKey != "" {
		// 临时兼容旧版 Agent 的匹配格式，仅在事件上报时移除前导斜杠。
		return strings.TrimPrefix(fi.ObjectKey, "/")
	}
	return fi.LocalPath
}

func (fi *UploadFileInfo) publishLifecycleStatus(status string, causes ...error) {
	if fi == nil || fi.task == nil {
		return
	}
	var cause error
	if len(causes) > 0 {
		cause = causes[0]
	}
	switch status {
	case types.FileEventStatusFailed:
		if errors.Is(cause, context.Canceled) {
			return
		}
		var first bool
		cause, first = fi.failure.Record(cause)
		fi.task.recordFinalError(cause)
		if !first {
			return
		}
	case types.FileEventStatusStarted, types.FileEventStatusCompleted:
		fi.failure.Clear()
	}
	if fi.task.publisher == nil {
		return
	}

	fi.task.publisher.Publish(types.NewFileStatusEventWithCause(
		fi.task.TaskID,
		fi.eventFileKey(),
		status,
		cause,
	))
}

func (fi *UploadFileInfo) recordExecutionError(err error) error {
	fi.LastErr = err
	if err != nil && !errors.Is(err, context.Canceled) {
		fi.publishProgressEvents(true)
		fi.publishLifecycleStatus(types.FileEventStatusFailed, err)
	}
	return err
}

func (fi *UploadFileInfo) setAttemptError(err error) error {
	fi.LastErr = err
	return err
}

func (fi *UploadFileInfo) publishChunkStatus(chunkIndex int, status string) {
	if fi == nil || fi.task == nil || fi.task.publisher == nil {
		return
	}
	fi.task.publisher.Publish(types.NewChunkStatusEvent(
		fi.task.TaskID,
		fi.eventFileKey(),
		chunkIndex,
		status,
	))
}

func (fi *UploadFileInfo) rebuildChunkProgress() {
	fi.mu.Lock()
	defer fi.mu.Unlock()
	if fi.ChunkCount <= 0 || fi.ChunkSize <= 0 {
		fi.chunkProgress = nil
		return
	}
	progress := make([]*uploadChunkProgress, fi.ChunkCount)
	allCompleted := fi.Exists || fi.Status == string(types.UploadFileStatusExists) || fi.Status == string(types.UploadFileStatusCommitted)
	for index := 0; index < fi.ChunkCount; index++ {
		state := &uploadChunkProgress{
			Total:       chunkByteSize(fi.Size, fi.ChunkSize, fi.ChunkCount, index),
			rateAverage: average.NewSMA(20),
		}
		transferred := int64(0)
		if allCompleted {
			transferred = state.Total
		} else {
			transferred = fi.confirmedChunkStoredBytesLocked(index)
		}
		if transferred < 0 {
			transferred = 0
		}
		if state.Total > 0 && transferred > state.Total {
			transferred = state.Total
		}
		if transferred > 0 {
			state.Confirmed.Store(transferred)
		}
		progress[index] = state
	}
	fi.chunkProgress = progress
}

func (fi *UploadFileInfo) confirmedChunkStoredBytesLocked(chunkIndex int) int64 {
	if fi == nil || fi.ChunkCount <= 0 || chunkIndex < 0 || chunkIndex >= fi.ChunkCount {
		return 0
	}
	total := chunkByteSize(fi.Size, fi.ChunkSize, fi.ChunkCount, chunkIndex)
	if fi.chunkStoredBytes != nil {
		if storedBytes, ok := fi.chunkStoredBytes[chunkIndex]; ok {
			if storedBytes < 0 {
				return 0
			}
			if total > 0 && storedBytes > total {
				return total
			}
			return storedBytes
		}
	}
	if _, ok := fi.uploadedChunks[chunkIndex]; ok {
		return total
	}
	return 0
}

func (fi *UploadFileInfo) setConfirmedChunkStoredBytesLocked(chunkIndex int, storedBytes int64) {
	if fi == nil || fi.ChunkCount <= 0 || chunkIndex < 0 || chunkIndex >= fi.ChunkCount {
		return
	}
	total := chunkByteSize(fi.Size, fi.ChunkSize, fi.ChunkCount, chunkIndex)
	if storedBytes < 0 {
		storedBytes = 0
	}
	if total > 0 && storedBytes > total {
		storedBytes = total
	}
	if storedBytes <= 0 {
		if fi.chunkStoredBytes != nil {
			delete(fi.chunkStoredBytes, chunkIndex)
			if len(fi.chunkStoredBytes) == 0 {
				fi.chunkStoredBytes = nil
			}
		}
		if fi.uploadedChunks != nil {
			delete(fi.uploadedChunks, chunkIndex)
			if len(fi.uploadedChunks) == 0 {
				fi.uploadedChunks = nil
			}
		}
	} else {
		if fi.chunkStoredBytes == nil {
			fi.chunkStoredBytes = make(map[int]int64)
		}
		fi.chunkStoredBytes[chunkIndex] = storedBytes
		if storedBytes >= total {
			if fi.uploadedChunks == nil {
				fi.uploadedChunks = make(map[int]struct{})
			}
			fi.uploadedChunks[chunkIndex] = struct{}{}
		} else if fi.uploadedChunks != nil {
			delete(fi.uploadedChunks, chunkIndex)
			if len(fi.uploadedChunks) == 0 {
				fi.uploadedChunks = nil
			}
		}
	}
	if chunkIndex >= 0 && chunkIndex < len(fi.chunkProgress) {
		if state := fi.chunkProgress[chunkIndex]; state != nil {
			state.Confirmed.Store(storedBytes)
		}
	}
}

func (fi *UploadFileInfo) setConfirmedChunkStoredBytes(chunkIndex int, storedBytes int64) {
	fi.mu.Lock()
	defer fi.mu.Unlock()
	fi.setConfirmedChunkStoredBytesLocked(chunkIndex, storedBytes)
}

func (fi *UploadFileInfo) currentChunkStoredBytes(chunkIndex int) int64 {
	fi.mu.Lock()
	defer fi.mu.Unlock()
	return fi.confirmedChunkStoredBytesLocked(chunkIndex)
}

func (fi *UploadFileInfo) syncTransferredWithConfirmedState() {
	if fi == nil || fi.task == nil {
		return
	}
	fi.progressMu.Lock()
	defer fi.progressMu.Unlock()
	fi.syncTransferredWithConfirmedStateLocked()
}

func (fi *UploadFileInfo) syncTransferredWithConfirmedStateLocked() {
	fi.mu.Lock()
	desiredTransferred := fi.resumeTransferredBytesLocked()
	chunkStates := append([]*uploadChunkProgress(nil), fi.chunkProgress...)
	fi.mu.Unlock()

	fi.setConfirmedTransferred(desiredTransferred)
	if len(chunkStates) == 0 {
		fi.setLiveTransferred(desiredTransferred)
		return
	}
	for index, state := range chunkStates {
		if state == nil {
			continue
		}
		fi.setChunkLiveTransferredLocked(index, state.Confirmed.Load())
	}
}

func (fi *UploadFileInfo) reconcileChunkWithConfirmedState(chunkIndex int, storedBytes int64) {
	if fi == nil || fi.task == nil {
		return
	}
	fi.progressMu.Lock()
	defer fi.progressMu.Unlock()
	fi.setConfirmedChunkStoredBytes(chunkIndex, storedBytes)
	fi.setConfirmedTransferred(fi.resumeTransferredBytes())
	fi.setChunkLiveTransferredLocked(chunkIndex, storedBytes)
}

func (fi *UploadFileInfo) chunkProgressState(chunkIndex int) *uploadChunkProgress {
	fi.mu.Lock()
	defer fi.mu.Unlock()
	if chunkIndex < 0 || chunkIndex >= len(fi.chunkProgress) {
		return nil
	}
	return fi.chunkProgress[chunkIndex]
}

func (fi *UploadFileInfo) setLiveTransferred(transferred int64) {
	if fi == nil || fi.task == nil {
		return
	}
	transferred = clampTransferValue(transferred, fi.Size)
	previous := atomic.SwapInt64(&fi.Transferred, transferred)
	addBoundedAtomic(&fi.task.Transferred, transferred-previous, atomic.LoadInt64(&fi.task.TotalSize))
}

func (fi *UploadFileInfo) setConfirmedTransferred(confirmed int64) {
	if fi == nil || fi.task == nil {
		return
	}
	confirmed = clampTransferValue(confirmed, fi.Size)
	previous := atomic.SwapInt64(&fi.Confirmed, confirmed)
	addBoundedAtomic(&fi.task.Confirmed, confirmed-previous, atomic.LoadInt64(&fi.task.TotalSize))
}

func (fi *UploadFileInfo) setChunkLiveTransferred(chunkIndex int, transferred int64) {
	fi.progressMu.Lock()
	defer fi.progressMu.Unlock()
	fi.setChunkLiveTransferredLocked(chunkIndex, transferred)
}

func (fi *UploadFileInfo) setChunkLiveTransferredLocked(chunkIndex int, transferred int64) {
	state := fi.chunkProgressState(chunkIndex)
	if state == nil {
		return
	}
	transferred = clampTransferValue(transferred, state.Total)
	previous := state.Transferred.Swap(transferred)
	delta := transferred - previous
	addBoundedAtomic(&fi.Transferred, delta, fi.Size)
	addBoundedAtomic(&fi.task.Transferred, delta, atomic.LoadInt64(&fi.task.TotalSize))
}

func (fi *UploadFileInfo) recordChunkRead(chunkIndex int, liveTransferred, bytes int64) {
	if fi == nil || fi.task == nil || bytes <= 0 {
		return
	}
	fi.progressMu.Lock()
	defer fi.progressMu.Unlock()
	state := fi.chunkProgressState(chunkIndex)
	if state != nil {
		state.NetworkSent.Add(bytes)
	}
	atomic.AddInt64(&fi.NetworkSent, bytes)
	atomic.AddInt64(&fi.task.NetworkSent, bytes)
	fi.setChunkLiveTransferredLocked(chunkIndex, liveTransferred)
}

func (fi *UploadFileInfo) beginChunkProgress(chunkIndex int) {
	state := fi.chunkProgressState(chunkIndex)
	if state == nil {
		return
	}
	state.Started.Store(true)
	state.Active.Store(true)
	fi.publishChunkStatus(chunkIndex, types.ChunkEventStatusStarted)
}

func (fi *UploadFileInfo) endChunkProgress(chunkIndex int) {
	state := fi.chunkProgressState(chunkIndex)
	if state == nil {
		return
	}
	fi.publishChunkProgress(chunkIndex, state)
	state.Active.Store(false)
	state.Rate.Store(0)
}

func (fi *UploadFileInfo) sampleTransferRates(elapsed time.Duration) {
	if fi == nil || elapsed <= 0 {
		return
	}
	currentNetworkSent := atomic.LoadInt64(&fi.NetworkSent)
	delta := currentNetworkSent - fi.lastNetworkSent
	if delta < 0 {
		delta = 0
	}
	if fi.rateAverage == nil {
		fi.rateAverage = average.NewSMA(20)
	}
	atomic.StoreInt64(&fi.Rate, int64(fi.rateAverage.Update(float64(delta)/elapsed.Seconds())))
	fi.lastNetworkSent = currentNetworkSent

	fi.mu.Lock()
	chunkStates := append([]*uploadChunkProgress(nil), fi.chunkProgress...)
	fi.mu.Unlock()
	for _, state := range chunkStates {
		if state == nil || !state.Active.Load() {
			continue
		}
		current := state.NetworkSent.Load()
		chunkDelta := current - state.lastNetworkSent
		if chunkDelta < 0 {
			chunkDelta = 0
		}
		if state.rateAverage == nil {
			state.rateAverage = average.NewSMA(20)
		}
		state.Rate.Store(int64(state.rateAverage.Update(float64(chunkDelta) / elapsed.Seconds())))
		state.lastNetworkSent = current
	}
}

func (fi *UploadFileInfo) markChunkCompleted(chunkIndex int) {
	fi.setConfirmedChunkStoredBytes(chunkIndex, chunkByteSize(fi.Size, fi.ChunkSize, fi.ChunkCount, chunkIndex))
	fi.mu.Lock()
	if fi.verifiedChunks == nil {
		fi.verifiedChunks = make(map[int]struct{})
	}
	fi.verifiedChunks[chunkIndex] = struct{}{}
	fi.mu.Unlock()
}

func (fi *UploadFileInfo) reset() {
	fi.failure.Clear()
	fi.LastErr = nil
	fi.Size = 0
	fi.FileHash = ""
	fi.ObjectKeyHash = ""
	fi.HashAlgorithm = ""
	fi.SessionID = ""
	fi.LeaseUntil = ""
	fi.UploadURL = ""
	fi.Status = ""
	fi.ChunkSize = 0
	fi.ChunkCount = 0
	fi.Ready = false
	fi.Exists = false
	atomic.StoreInt64(&fi.Transferred, 0)
	atomic.StoreInt64(&fi.Confirmed, 0)
	atomic.StoreInt64(&fi.NetworkSent, 0)
	atomic.StoreInt64(&fi.Rate, 0)
	fi.Uploaded = false
	fi.Verified = false
	fi.ReasonCode = ""
	fi.Message = ""
	fi.lastNetworkSent = 0
	if fi.rateAverage == nil {
		fi.rateAverage = average.NewSMA(20)
	} else {
		fi.rateAverage.Reset()
	}
	fi.modTime = time.Time{}
	fi.uploadedChunks = nil
	fi.verifiedChunks = nil
	fi.chunkStoredBytes = nil
	fi.chunkProgress = nil
	fi.registered = false
}

func (fi *UploadFileInfo) Upload(ctx context.Context) error {
	return fi.executeUploadAttempt(ctx, true)
}

func (fi *UploadFileInfo) executeUploadAttempt(ctx context.Context, prepare bool) error {
	ctx, cancel := context.WithCancel(ctx)
	fi.ctx = ctx
	fi.cancel = cancel
	fi.logger.Debug("upload file execution started", "prepare", prepare)
	active := false

	defer func() {
		if active {
			fi.task.TransferingFiles.Delete(fi.activityKey())
		}
		if fi.source != nil {
			_ = fi.source.Close()
			fi.source = nil
		}
		cancel()
		fi.logger.Debug("upload file execution finished",
			"ready", fi.Ready,
			"exists", fi.Exists,
			"status", fi.Status,
			"uploaded", fi.Uploaded,
			"verified", fi.Verified,
			"transferred", atomic.LoadInt64(&fi.Transferred))
		atomic.StoreInt64(&fi.Rate, 0)
	}()

	if prepare {
		if err := fi.prepareUpload(ctx); err != nil {
			return fi.setAttemptError(err)
		}
	} else if err := fi.reopenPreparedUpload(ctx); err != nil {
		return fi.setAttemptError(err)
	}
	if !fi.Ready {
		if err := ctx.Err(); err != nil {
			return fi.setAttemptError(err)
		}
		fi.logger.Debug("upload file skipped after init",
			"ready", fi.Ready,
			"exists", fi.Exists,
			"status", fi.Status,
			"reason_code", fi.ReasonCode,
			"message", fi.Message,
			"transferred", atomic.LoadInt64(&fi.Transferred))
		switch {
		case fi.Exists || fi.Status == string(types.UploadFileStatusExists) || fi.Status == string(types.UploadFileStatusCommitted):
			fi.LastErr = nil
			fi.publishLifecycleStatus(types.FileEventStatusCompleted)
		default:
			cause := fi.LastErr
			if cause == nil && strings.TrimSpace(fi.ReasonCode) != "" {
				cause = clienterror.New(fi.ReasonCode, fi.Message, nil)
			}
			fi.publishLifecycleStatus(types.FileEventStatusFailed, cause)
		}
		fi.publishProgressEvents(true)
		return nil
	}
	fi.task.TransferingFiles.Store(fi.activityKey(), fi)
	active = true
	if prepare {
		fi.publishLifecycleStatus(types.FileEventStatusStarted)
	}

	fi.logger.Debug("upload file data transfer starting",
		"session_id", fi.SessionID,
		"chunk_size", fi.ChunkSize,
		"chunk_count", fi.ChunkCount)
	err := fi.uploadOnce(ctx)
	if err != nil {
		return fi.setAttemptError(err)
	}

	fi.LastErr = nil
	fi.Uploaded = true
	fi.Verified = true
	fi.logger.Debug("upload file data transfer finished",
		"transferred", atomic.LoadInt64(&fi.Transferred))
	fi.publishProgressEvents(true)
	fi.publishLifecycleStatus(types.FileEventStatusCompleted)
	return nil
}

func (fi *UploadFileInfo) reopenPreparedUpload(ctx context.Context) error {
	source, err := openUploadSource(fi.FullPath)
	if err != nil {
		return localUploadPathError(fi.FullPath, err)
	}
	fi.source = source
	if err := fi.ensureSourceUnchanged(ctx); err != nil {
		return err
	}
	if fi.SessionID == "" && !fi.Exists && fi.Status != string(types.UploadFileStatusExists) && fi.Status != string(types.UploadFileStatusCommitted) {
		if err := fi.task.initUploadSession(ctx, fi); err != nil {
			return err
		}
		fi.task.registerInitializedFile(fi)
	}
	return nil
}

func (fi *UploadFileInfo) prepareUpload(ctx context.Context) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	absolutePath, err := filepath.Abs(fi.FullPath)
	if err != nil {
		return clienterror.New(clienterror.CodeLocalPathInvalid, "无法解析本地上传源："+fi.FullPath, err)
	}
	fi.FullPath = filepath.Clean(absolutePath)
	source, err := openUploadSource(fi.FullPath)
	if err != nil {
		return localUploadPathError(fi.FullPath, err)
	}
	fi.source = source
	fingerprint, err := fingerprintOpenFile(source)
	if err != nil {
		return fmt.Errorf("fingerprint upload file %s: %w", fi.LocalPath, err)
	}
	fi.fingerprint = fingerprint

	oldSize := fi.Size
	fi.Size = fingerprint.Size
	fi.modTime = time.Unix(0, fingerprint.MTimeNS)
	if oldSize != fi.Size {
		atomic.AddInt64(&fi.task.TotalSize, fi.Size-oldSize)
	}

	hash, chunkHashes, err := filehash.CalculateLayeredReaderAt(ctx, source, fi.Size)
	if err != nil {
		return fmt.Errorf("calculate hash for %s: %w", fi.LocalPath, err)
	}
	fi.FileHash = hash
	fi.chunkHashes = chunkHashes
	atomic.AddInt64(&fi.task.HashedBytes, fi.Size)
	if err := fi.ensureSourceUnchanged(ctx); err != nil {
		return err
	}

	if err := fi.task.initUploadSession(ctx, fi); err != nil {
		return err
	}
	fi.task.registerInitializedFile(fi)
	return nil
}

func (fi *UploadFileInfo) uploadOnce(ctx context.Context) error {
	if fi.source == nil {
		return fmt.Errorf("upload source handle is not open")
	}
	if err := fi.ensureSourceUnchanged(ctx); err != nil {
		return err
	}
	for {
		if err := fi.uploadChunkIndexes(ctx, fi.source, fi.allChunkIndexes()); err != nil {
			if errors.Is(err, errUploadSessionReinitialized) {
				if fi.Exists {
					return nil
				}
				continue
			}
			return err
		}

		if err := fi.ensureSourceUnchanged(ctx); err != nil {
			return err
		}
		if err := fi.completeUploadSession(ctx); err != nil {
			if errors.Is(err, errUploadSessionReinitialized) {
				if fi.Exists {
					return nil
				}
				continue
			}
			return err
		}
		break
	}

	fi.Message = "upload completed"
	return nil
}

func (fi *UploadFileInfo) ensureSourceUnchanged(ctx context.Context) error {
	current, err := fingerprintOpenFile(fi.source)
	if err == nil && fi.fingerprint.equal(current) {
		return nil
	}
	sessionID := fi.SessionID
	if fi.task.state != nil {
		if state, exists, stateErr := fi.task.state.Get(context.Background(), fi.FullPath, fi.task.ServerAddr, fi.ObjectKey); stateErr != nil {
			return fmt.Errorf("LOCAL_STATE_ERROR while handling changed source: %w", stateErr)
		} else if exists && sessionID == "" {
			sessionID = state.SessionID
		}
		if stateErr := fi.task.state.Delete(context.Background(), fi.FullPath, fi.task.ServerAddr, fi.ObjectKey); stateErr != nil {
			return fmt.Errorf("LOCAL_STATE_ERROR while handling changed source: %w", stateErr)
		}
		fi.stateOwned = false
	}
	abortCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	_ = fi.cancelSessionID(abortCtx, sessionID)
	cancel()
	if err != nil {
		return fmt.Errorf("%w: cannot fingerprint %s: %v", ErrLocalFileChanged, fi.LocalPath, err)
	}
	return fmt.Errorf("%w: %s", ErrLocalFileChanged, fi.LocalPath)
}

func (fi *UploadFileInfo) publishProgressEvents(force bool) {
	if fi == nil || fi.task == nil || fi.task.publisher == nil {
		return
	}
	if !eventcollector.ShouldPublishProgress(&fi.lastProgressPublishedAt, fi.task.progressEventInterval, force) {
		return
	}
	fi.task.publisher.Publish(types.NewFileProgressEvent(
		fi.task.TaskID,
		fi.eventFileKey(),
		fi.Size,
		atomic.LoadInt64(&fi.Transferred),
		atomic.LoadInt64(&fi.Rate),
	))
	fi.mu.Lock()
	chunkStates := append([]*uploadChunkProgress(nil), fi.chunkProgress...)
	fi.mu.Unlock()
	for index, state := range chunkStates {
		if state == nil || !state.Active.Load() {
			continue
		}
		fi.publishChunkProgress(index, state)
	}
}

func (fi *UploadFileInfo) publishChunkProgress(index int, state *uploadChunkProgress) {
	if fi == nil || fi.task == nil || fi.task.publisher == nil || state == nil {
		return
	}
	fi.task.publisher.Publish(types.NewChunkProgressEvent(
		fi.task.TaskID,
		fi.eventFileKey(),
		index,
		state.Total,
		state.Transferred.Load(),
		state.Rate.Load(),
	))
}

type progressReader struct {
	r         io.Reader
	onRead    func(int)
	wrapError func(error) error
}

func (pr *progressReader) Read(p []byte) (int, error) {
	n, err := pr.r.Read(p)
	if n > 0 && pr.onRead != nil {
		pr.onRead(n)
	}
	if err != nil && !errors.Is(err, io.EOF) && pr.wrapError != nil {
		err = pr.wrapError(err)
	}
	return n, err
}

func chunkByteSize(fileSize, chunkSize int64, chunkCount, chunkIndex int) int64 {
	if chunkCount <= 0 || chunkIndex < 0 || chunkIndex >= chunkCount {
		return 0
	}
	if chunkIndex == chunkCount-1 {
		remainder := fileSize - int64(chunkIndex)*chunkSize
		if remainder > 0 {
			return remainder
		}
	}
	return chunkSize
}

func (fi *UploadFileInfo) setChunkStatesLocked(chunkStates map[string]types.UploadChunkStateInfo, uploadedChunks []int) {
	if fi == nil {
		return
	}
	fi.uploadedChunks = nil
	fi.chunkStoredBytes = nil
	if fi.ChunkCount <= 0 {
		return
	}
	if len(chunkStates) > 0 {
		for rawIndex, state := range chunkStates {
			chunkIndex, err := strconv.Atoi(rawIndex)
			if err != nil || chunkIndex < 0 || chunkIndex >= fi.ChunkCount {
				continue
			}
			storedBytes := state.StoredBytes
			if state.State == types.UploadChunkStateComplete {
				storedBytes = chunkByteSize(fi.Size, fi.ChunkSize, fi.ChunkCount, chunkIndex)
			}
			fi.setConfirmedChunkStoredBytesLocked(chunkIndex, storedBytes)
		}
		return
	}
	for _, chunkIndex := range uploadedChunks {
		if chunkIndex < 0 || chunkIndex >= fi.ChunkCount {
			continue
		}
		fi.setConfirmedChunkStoredBytesLocked(chunkIndex, chunkByteSize(fi.Size, fi.ChunkSize, fi.ChunkCount, chunkIndex))
	}
}

func (fi *UploadFileInfo) setUploadedChunksLocked(uploadedChunks []int) {
	fi.setChunkStatesLocked(nil, uploadedChunks)
}

func (fi *UploadFileInfo) resumeTransferredBytes() int64 {
	fi.mu.Lock()
	defer fi.mu.Unlock()
	return fi.resumeTransferredBytesLocked()
}

func (fi *UploadFileInfo) resumeTransferredBytesLocked() int64 {
	if fi == nil || fi.ChunkSize <= 0 || fi.ChunkCount <= 0 || len(fi.chunkStoredBytes) == 0 {
		return 0
	}

	var transferred int64
	for _, storedBytes := range fi.chunkStoredBytes {
		if storedBytes > 0 {
			transferred += storedBytes
		}
	}
	if fi.Size > 0 && transferred > fi.Size {
		return fi.Size
	}
	return transferred
}

func (fi *UploadFileInfo) allChunkIndexes() []int {
	fi.mu.Lock()
	defer fi.mu.Unlock()
	if fi.ChunkCount <= 0 {
		return nil
	}
	chunks := make([]int, 0, fi.ChunkCount)
	for index := 0; index < fi.ChunkCount; index++ {
		if _, verified := fi.verifiedChunks[index]; verified {
			continue
		}
		chunks = append(chunks, index)
	}
	return chunks
}

func (fi *UploadFileInfo) uploadChunkIndexes(ctx context.Context, file *os.File, chunkIndexes []int) error {
	if len(chunkIndexes) == 0 {
		return nil
	}
	fi.logger.Debug("upload chunk dispatch prepared", "pending_chunks", len(chunkIndexes))

	parentCtx := ctx
	g, workerCtx := errgroup.WithContext(ctx)

	for _, chunkIndex := range chunkIndexes {
		if err := fi.task.chunkSlots.Acquire(workerCtx); err != nil {
			if workerErr := g.Wait(); workerErr != nil {
				return workerErr
			}
			return err
		}

		chunkIndex := chunkIndex
		g.Go(func() error {
			defer fi.task.chunkSlots.Release()
			return fi.uploadChunkSession(workerCtx, file, chunkIndex)
		})
	}

	if err := g.Wait(); err != nil {
		return err
	}
	return parentCtx.Err()
}

func (fi *UploadFileInfo) ToFileInfoDetail() *types.UploadFileInfoDetail {
	return &types.UploadFileInfoDetail{
		Src: fi.copySource(), Dst: fi.copyDestination(),
		Cause:        fi.failure.Cause(),
		LocalPath:    fi.LocalPath,
		ObjectKey:    fi.ObjectKey,
		Size:         fi.Size,
		FileHash:     fi.FileHash,
		UploadURL:    fi.UploadURL,
		Status:       fi.Status,
		ChunkSize:    fi.ChunkSize,
		ChunkCount:   fi.ChunkCount,
		Ready:        fi.Ready,
		Exists:       fi.Exists,
		Transferred:  atomic.LoadInt64(&fi.Transferred),
		Rate:         atomic.LoadInt64(&fi.Rate),
		Uploaded:     fi.Uploaded,
		Verified:     fi.Verified,
		ReasonCode:   fi.ReasonCode,
		Message:      fi.Message,
		LastModified: fi.modTime.Format(time.RFC3339Nano),
	}
}

func (fi *UploadFileInfo) ToFileInfoSummary() *types.UploadFileInfoSummary {
	return &types.UploadFileInfoSummary{
		Src: fi.copySource(), Dst: fi.copyDestination(),
		Cause:       fi.failure.Cause(),
		LocalPath:   fi.LocalPath,
		ObjectKey:   fi.ObjectKey,
		Size:        fi.Size,
		Status:      fi.Status,
		Transferred: atomic.LoadInt64(&fi.Transferred),
		Rate:        atomic.LoadInt64(&fi.Rate),
		Uploaded:    fi.Uploaded,
		Verified:    fi.Verified,
		ReasonCode:  fi.ReasonCode,
		Message:     fi.Message,
	}
}

func (fi *UploadFileInfo) activityKey() string {
	if dst := fi.copyDestination(); dst != "" {
		return dst
	}
	return fi.LocalPath
}

func (fi *UploadFileInfo) copySource() string {
	if fi.task != nil && len(fi.task.pathMappings) > 0 {
		return fi.FullPath
	}
	return ""
}
func (fi *UploadFileInfo) copyDestination() string {
	if fi.task != nil && len(fi.task.pathMappings) > 0 {
		return fi.ObjectKey
	}
	return ""
}
