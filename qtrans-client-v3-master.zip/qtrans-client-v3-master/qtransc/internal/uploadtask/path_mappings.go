package uploadtask

import "qtransc/internal/pathplan"

// preparePathMappings expands input once and atomically publishes the result.
func (ut *UploadTask) preparePathMappings() error {
	if ut.pathMappingsExpanded {
		return nil
	}
	ut.setPhase("planning_files")
	plan, err := pathplan.Build(ut.ctx, ut.pathMappings, pathplan.LocalSource{Logger: ut.logger}, false, ut.maxFileBytes)
	if err != nil {
		return err
	}
	if err := pathplan.CheckRemoteTargets(ut.ctx, plan, ut.remotePlanSource()); err != nil {
		return err
	}
	files := make([]*UploadFileInfo, 0, len(plan.Files))
	for _, f := range plan.Files {
		fi := NewUploadFileInfo(ut, f.Src, f.Dst)
		fi.FullPath = f.Src
		files = append(files, fi)
	}
	ut.mu.Lock()
	defer ut.mu.Unlock()
	if err := ut.ctx.Err(); err != nil {
		return err
	}
	ut.FileList = files
	ut.DirPaths = plan.Dirs
	ut.pathMappingsExpanded = true
	return nil
}
