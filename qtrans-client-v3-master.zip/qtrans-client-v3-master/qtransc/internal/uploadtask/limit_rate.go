package uploadtask

import (
	"context"
	"io"
)

func (ut *UploadTask) wrapRateLimitedReader(ctx context.Context, reader io.Reader) io.Reader {
	if ut == nil || ut.rateLimiter == nil {
		return reader
	}
	return ut.rateLimiter.WrapReader(ctx, reader)
}
