package uploadtask

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"net/http"
	"net/url"

	"qtransc/internal/pathplan"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/types"
)

func (ut *UploadTask) remotePlanSource() *pathplan.RemoteSource {
	return &pathplan.RemoteSource{Logger: ut.logger, Browse: func(ctx context.Context, p string) ([]types.DownloadBrowseEntry, error) {
		token, err := ut.currentBearerToken()
		if err != nil {
			return nil, err
		}
		_, _, body, err := ut.doJSONWithCorrelation(ctx, "/files/list?path="+url.QueryEscape(p), http.MethodGet, token, nil, qtserverapi.IdempotentRetry)
		if err != nil {
			var apiErr *qtserverapi.APIError
			if errors.As(err, &apiErr) && apiErr.Status == http.StatusNotFound {
				return nil, fmt.Errorf("remote directory %q: %w", p, fs.ErrNotExist)
			}
			return nil, err
		}
		var response types.DownloadBrowseResponse
		if err := json.Unmarshal(body, &response); err != nil {
			return nil, err
		}
		if response.Truncated {
			return nil, pathplan.Invalid("remote directory list truncated: %q", p)
		}
		return response.Entries, nil
	}}
}

// checkMappedTargets validates current target types using the fixed file list.
func (ut *UploadTask) checkMappedTargets() error {
	ut.setPhase("planning_files")
	plan := &pathplan.Plan{Dirs: ut.DirPaths, Files: make([]pathplan.File, 0, len(ut.FileList))}
	for _, file := range ut.FileList {
		plan.Files = append(plan.Files, pathplan.File{Src: file.FullPath, Dst: file.ObjectKey, Size: file.Size})
	}
	return pathplan.CheckRemoteTargets(ut.ctx, plan, ut.remotePlanSource())
}
