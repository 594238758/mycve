//go:build darwin

package uploadtask

import (
	"os"
	"syscall"

	"golang.org/x/sys/unix"
)

func openUploadSource(path string) (*os.File, error) {
	fd, err := unix.Open(path, unix.O_RDONLY|unix.O_CLOEXEC|unix.O_NOFOLLOW, 0)
	if err != nil {
		return nil, err
	}
	return os.NewFile(uintptr(fd), path), nil
}

func platformFingerprint(_ *os.File, info os.FileInfo) (int64, string) {
	stat, ok := info.Sys().(*syscall.Stat_t)
	if !ok {
		return info.ModTime().UnixNano(), ""
	}
	return stat.Ctimespec.Sec*1_000_000_000 + stat.Ctimespec.Nsec, ""
}
