package uploadtask

import (
	"fmt"
	"os"
)

type sourceFingerprint struct {
	Size    int64
	MTimeNS int64
	CTimeNS int64
	FileID  string
}

func fingerprintOpenFile(file *os.File) (sourceFingerprint, error) {
	info, err := file.Stat()
	if err != nil {
		return sourceFingerprint{}, err
	}
	if !info.Mode().IsRegular() {
		return sourceFingerprint{}, fmt.Errorf("source is not a regular file")
	}
	ctime, fileID := platformFingerprint(file, info)
	return sourceFingerprint{Size: info.Size(), MTimeNS: info.ModTime().UnixNano(), CTimeNS: ctime, FileID: fileID}, nil
}

func (f sourceFingerprint) equal(other sourceFingerprint) bool {
	return f.Size == other.Size && f.MTimeNS == other.MTimeNS && f.CTimeNS == other.CTimeNS && f.FileID == other.FileID
}
