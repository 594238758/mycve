package version

import (
	"fmt"
	"regexp"

	"qtransc/internal/clientid"
)

var (
	Version     = "dev"
	Commit      = "none"
	BuildTime   = "unknown"
	MachineID   = "unknown"
	clientIDErr error
)

func Text() string {
	return fmt.Sprintf("BuildTime: %s\nVersion: %s\nClient ID: %s\n", BuildTime, Version, MachineID)
}

func CurrentClientID() (string, error) {
	if clientIDErr != nil {
		return "", clientIDErr
	}
	return MachineID, nil
}

func init() {
	MachineID, clientIDErr = clientid.LoadOrCreate()

	// 客户端版本号
	re := regexp.MustCompile(`^(\d+\.\d+\.\d+)`)
	match := re.FindStringSubmatch(Version)
	if len(match) > 1 {
		Version = match[1]
	}
}
