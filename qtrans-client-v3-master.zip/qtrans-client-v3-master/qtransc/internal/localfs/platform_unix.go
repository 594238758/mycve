//go:build !windows

package localfs

import (
	"fmt"
	"syscall"

	"golang.org/x/sys/unix"
)

func ListRoots() ([]string, error) {
	return []string{"/"}, nil
}

func checkAccessWritable(dir string) error {
	if err := unix.Access(dir, unix.W_OK); err != nil {
		return fmt.Errorf("target dir is not writable: %w", err)
	}
	return nil
}

func availableDiskSpace(dir string) (int64, error) {
	var st syscall.Statfs_t
	if err := syscall.Statfs(dir, &st); err != nil {
		return 0, fmt.Errorf("statfs failed: %w", err)
	}
	return int64(st.Bavail) * int64(st.Bsize), nil
}

// FilesystemID groups independent destination directories for space checks.
func FilesystemID(dir string) (string, error) {
	var st syscall.Stat_t
	if err := syscall.Stat(dir, &st); err != nil {
		return "", err
	}
	return fmt.Sprintf("%d", st.Dev), nil
}
