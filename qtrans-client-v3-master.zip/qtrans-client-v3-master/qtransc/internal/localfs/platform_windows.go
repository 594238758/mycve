//go:build windows

package localfs

import (
	"fmt"
	"syscall"
	"unsafe"
)

func ListRoots() ([]string, error) {
	kernel32 := syscall.NewLazyDLL("kernel32.dll")
	getLogicalDrives := kernel32.NewProc("GetLogicalDrives")
	mask, _, err := getLogicalDrives.Call()
	if mask == 0 {
		return nil, fmt.Errorf("GetLogicalDrives failed: %w", err)
	}
	roots := make([]string, 0, 8)
	for i := 0; i < 26; i++ {
		if mask&(1<<uint(i)) == 0 {
			continue
		}
		roots = append(roots, fmt.Sprintf("%c:\\", 'A'+i))
	}
	return roots, nil
}

func checkAccessWritable(_ string) error {
	return nil
}

func availableDiskSpace(dir string) (int64, error) {
	kernel32 := syscall.NewLazyDLL("kernel32.dll")
	getDiskFreeSpaceEx := kernel32.NewProc("GetDiskFreeSpaceExW")

	dirPtr, err := syscall.UTF16PtrFromString(dir)
	if err != nil {
		return 0, fmt.Errorf("invalid path: %w", err)
	}

	var freeBytesAvailable int64
	r1, _, e1 := getDiskFreeSpaceEx.Call(
		uintptr(unsafe.Pointer(dirPtr)),
		uintptr(unsafe.Pointer(&freeBytesAvailable)),
		0,
		0,
	)
	if r1 == 0 {
		return 0, fmt.Errorf("GetDiskFreeSpaceExW failed: %w", e1)
	}
	return freeBytesAvailable, nil
}

// FilesystemID uses the volume GUID when available, falling back to the
// volume path for network shares where GetVolumeNameForVolumeMountPoint fails.
func FilesystemID(dir string) (string, error) {
	kernel32 := syscall.NewLazyDLL("kernel32.dll")
	input, err := syscall.UTF16PtrFromString(dir)
	if err != nil {
		return "", err
	}
	buffer := make([]uint16, 32768)
	ok, _, callErr := kernel32.NewProc("GetVolumePathNameW").Call(uintptr(unsafe.Pointer(input)), uintptr(unsafe.Pointer(&buffer[0])), uintptr(len(buffer)))
	if ok == 0 {
		return "", fmt.Errorf("GetVolumePathNameW failed: %w", callErr)
	}
	volume := make([]uint16, 32768)
	ok, _, _ = kernel32.NewProc("GetVolumeNameForVolumeMountPointW").Call(uintptr(unsafe.Pointer(&buffer[0])), uintptr(unsafe.Pointer(&volume[0])), uintptr(len(volume)))
	if ok != 0 {
		return syscall.UTF16ToString(volume), nil
	}
	return syscall.UTF16ToString(buffer), nil
}
