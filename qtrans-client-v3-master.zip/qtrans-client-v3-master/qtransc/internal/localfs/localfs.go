package localfs

import (
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

const (
	EntryTypeFile      = "file"
	EntryTypeDirectory = "directory"
	targetDirReserve   = int64(100 * 1024 * 1024)
)

var ErrInsufficientSpace = errors.New("insufficient disk space")

type Entry struct {
	Name         string `json:"name"`
	Path         string `json:"path"`
	EntryType    string `json:"entry_type"`
	Size         int64  `json:"size,omitempty"`
	LastModified string `json:"last_modified,omitempty"`
}

type ScannedFile struct {
	AbsolutePath string `json:"absolute_path"`
	LocalRelPath string `json:"local_rel_path"`
	Size         int64  `json:"size"`
	LastModified string `json:"last_modified,omitempty"`
}

type ScanResult struct {
	SourceDir string        `json:"source_dir"`
	Files     []ScannedFile `json:"files"`
}

type TargetValidation struct {
	TargetDir         string `json:"target_dir"`
	ResolvedTargetDir string `json:"resolved_target_dir,omitempty"`
	Created           bool   `json:"created"`
	Writable          bool   `json:"writable"`
	EnoughSpace       bool   `json:"enough_space"`
	WantedBytes       int64  `json:"wanted_bytes"`
	ReserveBytes      int64  `json:"reserve_bytes"`
	AvailableBytes    int64  `json:"available_bytes"`
}

func ListDir(rawPath string) ([]Entry, error) {
	dir, err := normalizeAbsoluteDirectory(rawPath)
	if err != nil {
		return nil, err
	}

	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, fmt.Errorf("read directory: %w", err)
	}

	result := make([]Entry, 0, len(entries))
	for _, entry := range entries {
		fullPath := filepath.Join(dir, entry.Name())
		info, err := os.Lstat(fullPath)
		if err != nil {
			continue
		}
		if info.Mode()&os.ModeSymlink != 0 {
			continue
		}

		switch {
		case info.IsDir():
			result = append(result, Entry{
				Name:         entry.Name(),
				Path:         fullPath,
				EntryType:    EntryTypeDirectory,
				LastModified: formatTimestamp(info.ModTime()),
			})
		case info.Mode().IsRegular():
			result = append(result, Entry{
				Name:         entry.Name(),
				Path:         fullPath,
				EntryType:    EntryTypeFile,
				Size:         info.Size(),
				LastModified: formatTimestamp(info.ModTime()),
			})
		}
	}

	sort.Slice(result, func(i, j int) bool {
		if result[i].EntryType != result[j].EntryType {
			return result[i].EntryType == EntryTypeDirectory
		}
		return strings.ToLower(result[i].Name) < strings.ToLower(result[j].Name)
	})
	return result, nil
}

func ScanSelections(basePath string, selections []string) (*ScanResult, error) {
	baseDir, err := normalizeAbsoluteDirectory(basePath)
	if err != nil {
		return nil, err
	}
	if len(selections) == 0 {
		return nil, fmt.Errorf("selections must not be empty")
	}

	seen := make(map[string]struct{})
	files := make([]ScannedFile, 0)
	for _, rawSelection := range selections {
		selection, err := normalizeSelection(baseDir, rawSelection)
		if err != nil {
			return nil, err
		}
		if err := walkSelection(baseDir, selection, seen, &files); err != nil {
			return nil, err
		}
	}

	if len(files) == 0 {
		return nil, fmt.Errorf("no regular files found under selections")
	}

	sort.Slice(files, func(i, j int) bool {
		return files[i].LocalRelPath < files[j].LocalRelPath
	})

	return &ScanResult{
		SourceDir: baseDir,
		Files:     files,
	}, nil
}

func ValidateTargetDir(targetDir string, wanted int64) (*TargetValidation, error) {
	if strings.TrimSpace(targetDir) == "" {
		return nil, fmt.Errorf("target dir is empty")
	}

	absPath, err := filepath.Abs(targetDir)
	if err != nil {
		return nil, fmt.Errorf("get absolute path failed: %w", err)
	}

	report := &TargetValidation{
		TargetDir:    absPath,
		WantedBytes:  wanted,
		ReserveBytes: targetDirReserve,
	}

	created := false
	if fi, err := os.Lstat(absPath); err != nil {
		if !os.IsNotExist(err) {
			return report, fmt.Errorf("stat target dir failed: %w", err)
		}
		if err := os.MkdirAll(absPath, 0o755); err != nil {
			return report, fmt.Errorf("create target dir failed: %w", err)
		}
		created = true
	} else {
		if fi.Mode()&os.ModeSymlink == 0 && !fi.IsDir() {
			return report, fmt.Errorf("target path is not a directory")
		}
	}
	report.Created = created

	resolvedPath, err := filepath.EvalSymlinks(absPath)
	if err != nil {
		return report, fmt.Errorf("resolve target dir failed: %w", err)
	}
	report.ResolvedTargetDir = resolvedPath

	info, err := os.Stat(resolvedPath)
	if err != nil {
		return report, fmt.Errorf("stat resolved target dir failed: %w", err)
	}
	if !info.IsDir() {
		return report, fmt.Errorf("target path is not a directory")
	}

	if err := checkAccessWritable(resolvedPath); err != nil {
		return report, err
	}
	report.Writable = true

	f, err := os.CreateTemp(resolvedPath, ".qtransc-write-test-*")
	if err != nil {
		return report, fmt.Errorf("cannot create file in target dir: %w", err)
	}
	testFile := f.Name()
	_ = f.Close()
	_ = os.Remove(testFile)

	testSubDir, err := os.MkdirTemp(resolvedPath, ".qtransc-dir-test-*")
	if err != nil {
		return report, fmt.Errorf("cannot create subdirectory in target dir: %w", err)
	}
	testSubFile := filepath.Join(testSubDir, "probe")
	sf, err := os.Create(testSubFile)
	if err != nil {
		_ = os.RemoveAll(testSubDir)
		return report, fmt.Errorf("cannot create file in subdirectory: %w", err)
	}
	_ = sf.Close()
	_ = os.RemoveAll(testSubDir)

	available, err := availableDiskSpace(resolvedPath)
	if err != nil {
		return report, err
	}
	report.AvailableBytes = available
	report.EnoughSpace = true

	if wanted > 0 && (available < targetDirReserve || wanted > available-targetDirReserve) {
		report.EnoughSpace = false
		return report, fmt.Errorf("%w: available=%d required=%d reserve=%d", ErrInsufficientSpace, available, wanted, targetDirReserve)
	}

	return report, nil
}

func normalizeAbsoluteDirectory(rawPath string) (string, error) {
	trimmed := strings.TrimSpace(rawPath)
	if trimmed == "" {
		return "", fmt.Errorf("path is required")
	}

	absPath, err := filepath.Abs(trimmed)
	if err != nil {
		return "", fmt.Errorf("resolve path: %w", err)
	}

	info, err := os.Lstat(absPath)
	if err != nil {
		return "", fmt.Errorf("stat path: %w", err)
	}
	if info.Mode()&os.ModeSymlink != 0 {
		return "", fmt.Errorf("path must not be a symlink")
	}
	if !info.IsDir() {
		return "", fmt.Errorf("path is not a directory")
	}
	return absPath, nil
}

func normalizeSelection(baseDir, rawPath string) (string, error) {
	trimmed := strings.TrimSpace(rawPath)
	if trimmed == "" {
		return "", fmt.Errorf("selection path must not be empty")
	}
	absPath, err := filepath.Abs(trimmed)
	if err != nil {
		return "", fmt.Errorf("resolve selection path: %w", err)
	}
	relPath, err := filepath.Rel(baseDir, absPath)
	if err != nil {
		return "", fmt.Errorf("resolve selection path: %w", err)
	}
	if relPath == ".." || strings.HasPrefix(relPath, ".."+string(filepath.Separator)) {
		return "", fmt.Errorf("selection %q is outside base path %q", absPath, baseDir)
	}
	return absPath, nil
}

func walkSelection(baseDir, selection string, seen map[string]struct{}, files *[]ScannedFile) error {
	info, err := os.Lstat(selection)
	if err != nil {
		return fmt.Errorf("stat selection: %w", err)
	}
	if info.Mode()&os.ModeSymlink != 0 {
		return nil
	}
	if info.Mode().IsRegular() {
		return appendScannedFile(baseDir, selection, info, seen, files)
	}
	if !info.IsDir() {
		return nil
	}

	return filepath.WalkDir(selection, func(current string, dirEntry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		entryInfo, err := dirEntry.Info()
		if err != nil {
			return err
		}
		if entryInfo.Mode()&os.ModeSymlink != 0 {
			if dirEntry.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}
		if dirEntry.IsDir() {
			return nil
		}
		if !entryInfo.Mode().IsRegular() {
			return nil
		}
		return appendScannedFile(baseDir, current, entryInfo, seen, files)
	})
}

func appendScannedFile(baseDir, absPath string, info fs.FileInfo, seen map[string]struct{}, files *[]ScannedFile) error {
	relPath, err := filepath.Rel(baseDir, absPath)
	if err != nil {
		return fmt.Errorf("build relative path: %w", err)
	}
	relPath = filepath.Clean(relPath)
	if relPath == ".." || strings.HasPrefix(relPath, ".."+string(filepath.Separator)) {
		return fmt.Errorf("file %q is outside base path %q", absPath, baseDir)
	}
	if _, ok := seen[relPath]; ok {
		return nil
	}
	seen[relPath] = struct{}{}
	*files = append(*files, ScannedFile{
		AbsolutePath: absPath,
		LocalRelPath: relPath,
		Size:         info.Size(),
		LastModified: formatTimestamp(info.ModTime()),
	})
	return nil
}

func formatTimestamp(ts time.Time) string {
	if ts.IsZero() {
		return ""
	}
	return ts.UTC().Format(time.RFC3339)
}
