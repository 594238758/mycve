package pathplan

import (
	"context"
	"crypto/sha256"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"os"
	"path/filepath"
	"strings"

	"qtransc/internal/clienterror"
)

type LocalSource struct{ Logger *slog.Logger }

func localError(p string, err error) error {
	code := clienterror.CodeLocalPathInvalid
	if os.IsNotExist(err) {
		code = clienterror.CodeLocalFileNotFound
	}
	return clienterror.New(code, "local path unavailable: "+p, err)
}
func (s LocalSource) Stat(ctx context.Context, p string) (Node, error) {
	if err := ctx.Err(); err != nil {
		return Node{}, err
	}
	info, err := os.Lstat(p)
	if err != nil {
		return Node{}, localError(p, err)
	}
	n := Node{Path: p, Kind: "skip", Size: info.Size()}
	if info.IsDir() {
		n.Kind = "directory"
	} else if info.Mode().IsRegular() {
		n.Kind = "file"
	}
	return n, nil
}
func (s LocalSource) List(ctx context.Context, p string) ([]Node, error) {
	// Reject a directory replaced by a symlink after it was observed.
	n, err := s.Stat(ctx, p)
	if err != nil {
		return nil, err
	}
	if n.Kind != "directory" {
		return nil, localError(p, fmt.Errorf("source directory changed"))
	}
	f, err := os.Open(p)
	if err != nil {
		return nil, localError(p, err)
	}
	defer f.Close()
	// Detect replacement with a symlink or a different directory between stat
	// and open; use the opened directory for enumeration only after this check.
	opened, err := f.Stat()
	if err != nil {
		return nil, localError(p, err)
	}
	current, err := os.Lstat(p)
	if err != nil {
		return nil, localError(p, err)
	}
	if !current.IsDir() || !os.SameFile(opened, current) {
		return nil, localError(p, fmt.Errorf("source directory changed"))
	}
	entries, err := f.ReadDir(MaxEntries + 1)
	if err != nil && !errors.Is(err, io.EOF) {
		return nil, localError(p, err)
	}
	if len(entries) > MaxEntries {
		return nil, Invalid("directory exceeds planning entry limit: %q", p)
	}
	nodes := make([]Node, 0, len(entries))
	for _, e := range entries {
		n, err := s.Stat(ctx, filepath.Join(p, e.Name()))
		if err != nil {
			return nil, err
		}
		if n.Kind == "skip" && s.Logger != nil {
			s.Logger.Warn("skipped unsupported local source", "path", n.Path)
		}
		nodes = append(nodes, n)
	}
	return nodes, nil
}

// Resolve an existing ancestor before comparing paths, so directory symlink
// aliases do not bypass destination collision detection.
func canonicalLocal(p string) (string, string, error) {
	current := p
	var suffix []string
	for {
		info, err := os.Lstat(current)
		if err == nil {
			resolved, err := filepath.EvalSymlinks(current)
			if err != nil {
				return "", "", localError(current, err)
			}
			if len(suffix) > 0 && !info.IsDir() {
				followed, e := os.Stat(current)
				if e != nil || !followed.IsDir() {
					return "", "", localError(current, fmt.Errorf("ancestor is not a directory"))
				}
			}
			nearest := resolved
			if st, e := os.Stat(resolved); e != nil {
				return "", "", localError(current, e)
			} else if !st.IsDir() {
				nearest = filepath.Dir(resolved)
			}
			for i := len(suffix) - 1; i >= 0; i-- {
				resolved = filepath.Join(resolved, suffix[i])
			}
			return resolved, nearest, nil
		}
		if !os.IsNotExist(err) {
			return "", "", localError(current, err)
		}
		parent := filepath.Dir(current)
		if parent == current {
			return "", "", localError(current, err)
		}
		suffix = append(suffix, filepath.Base(current))
		current = parent
	}
}
func newLocalKey() func(string) (string, error) {
	cases := map[string]bool{}
	keys := map[string]string{}
	return func(p string) (string, error) {
		if key, ok := keys[p]; ok {
			return key, nil
		}
		resolved, nearest, err := canonicalLocal(p)
		if err != nil {
			return "", err
		}
		insensitive, ok := cases[nearest]
		if !ok {
			insensitive, err = CaseInsensitive(nearest)
			if err != nil {
				return "", localError(nearest, err)
			}
			cases[nearest] = insensitive
		}
		if insensitive {
			resolved = strings.ToLower(resolved)
		}
		keys[p] = resolved
		return resolved, nil
	}
}

// CaseInsensitive probes the actual destination filesystem without creating a
// destination directory. The temporary probe is always removed.
func CaseInsensitive(dir string) (bool, error) {
	// Existing names permit probing read-only ancestors (including filesystem
	// roots) without requiring write access outside the chosen destinations.
	fdir, readErr := os.Open(dir)
	if readErr == nil {
		entries, _ := fdir.ReadDir(32)
		_ = fdir.Close()
		for _, entry := range entries {
			name := entry.Name()
			alternate := toggleCase(name)
			if alternate == name {
				continue
			}
			original, e := os.Lstat(filepath.Join(dir, name))
			if e != nil {
				continue
			}
			other, e := os.Lstat(filepath.Join(dir, alternate))
			if os.IsNotExist(e) {
				return false, nil
			}
			if e != nil {
				return false, e
			}
			return os.SameFile(original, other), nil
		}
	}

	f, err := os.CreateTemp(dir, ".qtrans-Case-Probe-Aa-*")
	if err != nil {
		return false, err
	}
	name := f.Name()
	defer os.Remove(name)
	if err := f.Close(); err != nil {
		return false, err
	}
	st, err := os.Stat(name)
	if err != nil {
		return false, err
	}
	alternate := filepath.Join(filepath.Dir(name), strings.Replace(filepath.Base(name), "Case", "case", 1))
	other, err := os.Stat(alternate)
	if os.IsNotExist(err) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return os.SameFile(st, other), nil
}

// CheckLocalTargets is read-only except for the case probe. It checks all
// existing ancestors before any MkdirAll or file writes are attempted.
func CheckLocalTargets(ctx context.Context, p *Plan) error {
	reserved := &Plan{Dirs: p.Dirs, Files: append([]File(nil), p.Files...)}
	for _, f := range p.Files {
		reserved.Files = append(reserved.Files, File{Dst: ProgressPath(f)})
	}
	if err := CheckConflicts(ctx, reserved, true); err != nil {
		return err
	}
	checked := map[string]bool{}
	var checkDir func(string) error
	checkDir = func(d string) error {
		if checked[d] {
			return nil
		}
		checked[d] = true
		if err := ctx.Err(); err != nil {
			return err
		}
		info, err := os.Stat(d)
		if err == nil {
			if !info.IsDir() {
				return localError(d, fmt.Errorf("destination is not a directory"))
			}
			return nil
		}
		if !os.IsNotExist(err) {
			return localError(d, err)
		}
		if _, e := os.Lstat(d); e == nil {
			return localError(d, fmt.Errorf("invalid destination symlink"))
		}
		if parent := filepath.Dir(d); parent != d {
			return checkDir(parent)
		}
		return localError(d, err)
	}
	for _, d := range p.Dirs {
		if err := checkDir(d); err != nil {
			return err
		}
	}
	for _, f := range reserved.Files {
		if err := ctx.Err(); err != nil {
			return err
		}
		if err := checkDir(filepath.Dir(f.Dst)); err != nil {
			return err
		}
		info, err := os.Lstat(f.Dst)
		if err != nil && !os.IsNotExist(err) {
			return localError(f.Dst, err)
		}
		if err == nil && !info.Mode().IsRegular() {
			return localError(f.Dst, fmt.Errorf("destination is not a regular file"))
		}
	}
	return nil
}

func toggleCase(s string) string {
	b := []byte(s)
	for i, c := range b {
		if c >= 'a' && c <= 'z' {
			b[i] = c - 32
			return string(b)
		}
		if c >= 'A' && c <= 'Z' {
			b[i] = c + 32
			return string(b)
		}
	}
	return s
}

// ProgressPath avoids basename length limits and collisions with ordinary
// names such as a.txt.progress. The hash is only a filesystem-safe filename;
// task records and events are identified by the final destination path.
func ProgressPath(f File) string {
	name := sha256.Sum256([]byte(f.Src + "\x00" + f.Dst))
	return filepath.Join(filepath.Dir(f.Dst), fmt.Sprintf(".qtrans-%x.progress", name))
}
