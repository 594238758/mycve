// Package pathplan builds an immutable, complete copy plan before any transfer.
package pathplan

import (
	"context"
	"fmt"
	"math"
	"path"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"unicode/utf8"

	"qtransc/internal/clienterror"
	"qtransc/internal/transferlimits"
	"qtransc/internal/types"
)

const MaxEntries = 200000
const MaxDepth = 128

type File struct {
	Src  string
	Dst  string
	Size int64
}
type Plan struct {
	Files []File
	Dirs  []string
}

type Node struct {
	Link bool
	Path string
	Kind string // file, directory, or skip (unsupported nested node)
	Size int64
}
type Source interface {
	Stat(context.Context, string) (Node, error)
	List(context.Context, string) ([]Node, error)
}

func Invalid(format string, args ...any) error {
	return clienterror.New("INVALID_REQUEST", fmt.Sprintf(format, args...), nil)
}

// Logical validates generated paths too: an otherwise valid input may expand
// into an unrepresentable remote name or exceed the remote path length limit.
func Logical(p string) error {
	if !utf8.ValidString(p) || !strings.HasPrefix(p, "/") || strings.ContainsAny(p, "\\\x00") || len(p) > 1024 {
		return Invalid("invalid logical path %q", p)
	}
	for _, s := range strings.Split(strings.TrimPrefix(p, "/"), "/") {
		if s == "." || s == ".." || len(s) > 255 || (s == "" && p != "/") {
			return Invalid("invalid logical path %q", p)
		}
	}
	return nil
}

func Build(ctx context.Context, mappings []types.PathMapping, source Source, localTarget bool, maxFileBytes int64) (*Plan, error) {
	plan := &Plan{}
	dirs := map[string]bool{}
	pairs := map[types.PathMapping]bool{}
	entries := 0
	var total int64
	join := path.Join
	if localTarget {
		join = filepath.Join
	}
	var walk func(Node, string, int) error
	walk = func(n Node, dst string, depth int) error {
		if err := ctx.Err(); err != nil {
			return err
		}
		entries++
		if entries > MaxEntries || (n.Kind == "directory" && depth > MaxDepth) {
			return Invalid("copy plan exceeds entry/depth limit at %q", n.Path)
		}
		if n.Kind == "skip" {
			return nil
		}
		if !localTarget {
			if err := Logical(dst); err != nil {
				return err
			}
		}
		switch n.Kind {
		case "skip":
			return nil
		case "directory":
			dirs[dst] = true
			children, err := source.List(ctx, n.Path)
			if err != nil {
				return err
			}
			for _, c := range children {
				if c.Kind == "skip" {
					if err := walk(c, dst, depth+1); err != nil {
						return err
					}
					continue
				}
				name := path.Base(c.Path)
				if !localTarget {
					name = filepath.Base(c.Path)
				}
				if localTarget && !validLocalName(name) {
					return Invalid("remote name cannot be represented locally: %q", name)
				}
				if err := walk(c, join(dst, name), depth+1); err != nil {
					return err
				}
			}
		case "file":
			if err := transferlimits.ValidateTaskFileCount(len(plan.Files) + 1); err != nil {
				return err
			}
			if err := transferlimits.ValidateFileSize(n.Size, maxFileBytes); err != nil {
				return err
			}
			if n.Size < 0 || n.Size > math.MaxInt64-total {
				return Invalid("invalid copy plan size")
			}
			total += n.Size
			plan.Files = append(plan.Files, File{Src: n.Path, Dst: dst, Size: n.Size})
		default:
			return Invalid("source %q is not transferable", n.Path)
		}
		return nil
	}
	for _, m := range mappings {
		if pairs[m] {
			return nil, Invalid("duplicate mapping: %q -> %q", m.Src, m.Dst)
		}
		pairs[m] = true
		n, err := source.Stat(ctx, m.Src)
		if err != nil {
			return nil, err
		}
		if n.Kind != "file" && n.Kind != "directory" {
			return nil, Invalid("source %q is not transferable", m.Src)
		}
		dirs[m.Dst] = true
		dst := m.Dst
		if n.Kind == "file" {
			name := path.Base(m.Src)
			if !localTarget {
				name = filepath.Base(m.Src)
			}
			if localTarget && !validLocalName(name) {
				return nil, Invalid("remote name cannot be represented locally: %q", name)
			}
			dst = join(dst, name)
		}
		if err := walk(n, dst, 1); err != nil {
			return nil, err
		}
	}
	for d := range dirs {
		plan.Dirs = append(plan.Dirs, d)
	}
	sort.Strings(plan.Dirs)
	sort.Slice(plan.Files, func(i, j int) bool { return plan.Files[i].Dst < plan.Files[j].Dst })
	if err := CheckConflicts(ctx, plan, localTarget); err != nil {
		return nil, err
	}
	return plan, nil
}

// CheckConflicts includes implicit parent directories, so a file can never
// occupy a directory needed by another mapping (including empty directories).
func CheckConflicts(ctx context.Context, plan *Plan, local bool) error {
	parent := path.Dir
	key := func(p string) (string, error) { return p, nil }
	if local {
		parent = filepath.Dir
		key = newLocalKey()
	}
	type target struct {
		dir  bool
		path string
	}
	seen := map[string]target{}
	register := func(p string, dir bool) error {
		if err := ctx.Err(); err != nil {
			return err
		}
		k, err := key(p)
		if err != nil {
			return err
		}
		if old, ok := seen[k]; ok {
			if old.dir && dir {
				return nil
			}
			return Invalid("conflicting destinations %q and %q", old.path, p)
		}
		seen[k] = target{dir, p}
		return nil
	}
	parentsDone := map[string]bool{}
	addParents := func(p string) error {
		for d := parent(p); ; d = parent(d) {
			if parentsDone[d] {
				return nil
			}
			parentsDone[d] = true
			if err := register(d, true); err != nil {
				return err
			}
			if parent(d) == d {
				return nil
			}
		}
	}
	for _, d := range plan.Dirs {
		if err := register(d, true); err != nil {
			return err
		}
		if err := addParents(d); err != nil {
			return err
		}
	}
	for _, f := range plan.Files {
		if err := register(f.Dst, false); err != nil {
			return err
		}
		if err := addParents(f.Dst); err != nil {
			return err
		}
	}
	return nil
}

func validLocalName(name string) bool {
	if !filepath.IsLocal(name) || strings.ContainsAny(name, "/\\") || filepath.Base(name) != name {
		return false
	}
	if runtime.GOOS == "windows" && (strings.ContainsAny(name, `<>:"|?*`) || strings.HasSuffix(name, ".") || strings.HasSuffix(name, " ")) {
		return false
	}
	return true
}
