package pathplan

import (
	"context"
	"errors"
	"fmt"
	"io/fs"
	"log/slog"
	"path"

	"qtransc/internal/clienterror"
	"qtransc/internal/types"
)

// RemoteSource caches single-level directory responses only during one plan
// or target check. It never shares metadata across execution rounds.
type RemoteSource struct {
	cachedEntries int
	Browse        func(context.Context, string) ([]types.DownloadBrowseEntry, error)
	Logger        *slog.Logger
	cache         map[string]map[string]types.DownloadBrowseEntry
}

func (s *RemoteSource) entries(ctx context.Context, p string) (map[string]types.DownloadBrowseEntry, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if s.cache == nil {
		s.cache = map[string]map[string]types.DownloadBrowseEntry{}
	}
	if result, ok := s.cache[p]; ok {
		return result, nil
	}
	entries, err := s.Browse(ctx, p)
	if err != nil {
		if errors.Is(err, fs.ErrNotExist) {
			s.remember(p, map[string]types.DownloadBrowseEntry{})
		}
		return nil, err
	}
	result := make(map[string]types.DownloadBrowseEntry, len(entries))
	for _, e := range entries {
		if err := Logical(e.Path); err != nil {
			return nil, err
		}
		if path.Dir(e.Path) != p || e.Path == p || path.Base(e.Path) != e.Name {
			return nil, Invalid("invalid child returned for %q", p)
		}
		if _, ok := result[e.Path]; ok {
			return nil, Invalid("duplicate remote entry %q", e.Path)
		}
		result[e.Path] = e
	}
	s.remember(p, result)
	return result, nil
}
func remoteNode(e types.DownloadBrowseEntry) (Node, error) {
	if e.Status == "unavailable" || e.ReasonCode == "ENTRY_CHANGED" || e.ReasonCode == "ENTRY_UNREADABLE" {
		return Node{}, clienterror.New("CONFLICT", "remote entry changed: "+e.Path, nil)
	}
	n := Node{Path: e.Path, Size: e.Size, Kind: e.TransferType(), Link: e.EntryType == "symlink"}
	if e.Status != "normal" || (n.Kind != "file" && n.Kind != "directory") {
		n.Kind = "skip"
	}
	return n, nil
}
func (s *RemoteSource) Stat(ctx context.Context, p string) (Node, error) {
	if p == "/" {
		return Node{Path: p, Kind: "directory"}, nil
	}
	entries, err := s.entries(ctx, path.Dir(p))
	if err != nil {
		return Node{}, err
	}
	e, ok := entries[p]
	if !ok {
		return Node{}, fmt.Errorf("remote path %q: %w", p, fs.ErrNotExist)
	}
	return remoteNode(e)
}
func (s *RemoteSource) List(ctx context.Context, p string) ([]Node, error) {
	entries, err := s.entries(ctx, p)
	if err != nil {
		return nil, err
	}
	nodes := make([]Node, 0, len(entries))
	for _, e := range entries {
		n, err := remoteNode(e)
		if err != nil {
			return nil, err
		}
		if n.Kind == "skip" && s.Logger != nil {
			s.Logger.Warn("skipped unsupported remote source", "path", e.Path, "status", e.Status)
		}
		nodes = append(nodes, n)
	}
	return nodes, nil
}
func CheckRemoteTargets(ctx context.Context, p *Plan, remote *RemoteSource) error {
	checked := map[string]bool{}
	var checkDir func(string) error
	checkDir = func(d string) error {
		if checked[d] || d == "/" {
			return nil
		}
		checked[d] = true
		if err := checkDir(path.Dir(d)); err != nil {
			return err
		}
		n, err := remote.Stat(ctx, d)
		if errors.Is(err, fs.ErrNotExist) {
			return nil
		}
		if err != nil {
			return err
		}
		if n.Kind != "directory" {
			return clienterror.New("CONFLICT", "remote target is not a directory: "+d, nil)
		}
		return nil
	}
	for _, d := range p.Dirs {
		if err := checkDir(d); err != nil {
			return err
		}
	}
	for _, f := range p.Files {
		if err := checkDir(path.Dir(f.Dst)); err != nil {
			return err
		}
		n, err := remote.Stat(ctx, f.Dst)
		if errors.Is(err, fs.ErrNotExist) {
			continue
		}
		if err != nil {
			return err
		}
		if n.Kind != "file" || n.Link {
			return clienterror.New("CONFLICT", "remote target is not a file: "+f.Dst, nil)
		}
	}
	return nil
}

func (s *RemoteSource) remember(p string, entries map[string]types.DownloadBrowseEntry) {
	// Parent lookups can enumerate unrelated siblings. Bound cached metadata
	// without treating those siblings as copies or silently dropping plan nodes.
	cost := len(entries) + 1
	if s.cachedEntries+cost > MaxEntries {
		s.cache = make(map[string]map[string]types.DownloadBrowseEntry)
		s.cachedEntries = 0
	}
	s.cache[p] = entries
	s.cachedEntries += cost
}
