// Package transferlimits centralizes qtransc's client-side transfer planning
// limits. qtserver remains the authority for final transfer enforcement.
package transferlimits

import "fmt"

const (
	DefaultMaxFileBytes int64 = 1 << 40
	MaxTaskFiles              = 100000

	ReasonFileTooLarge          = "FILE_TOO_LARGE"
	ReasonTaskFileLimitExceeded = "TASK_FILE_LIMIT_EXCEEDED"
	ReasonTaskSizeLimitExceeded = "TASK_SIZE_LIMIT_EXCEEDED"
)

// Error is a stable client-side transfer planning error.
type Error struct {
	ReasonCode string
	Message    string
}

func (e *Error) Error() string {
	if e == nil {
		return ""
	}
	return e.Message
}

func EffectiveMaxFileBytes(configured int64) int64 {
	if configured > 0 {
		return configured
	}
	return DefaultMaxFileBytes
}

func TaskFileLimitExceeded(fileCount int) error {
	return &Error{
		ReasonCode: ReasonTaskFileLimitExceeded,
		Message:    fmt.Sprintf("单次传输任务的普通文件数超过 %d 个上限（当前 %d 个）", MaxTaskFiles, fileCount),
	}
}

func FileTooLarge(fileSize, maxFileBytes int64) error {
	return &Error{
		ReasonCode: ReasonFileTooLarge,
		Message:    fmt.Sprintf("文件大小 %d 字节超过服务器允许的单文件上限 %d 字节", fileSize, EffectiveMaxFileBytes(maxFileBytes)),
	}
}

func TaskSizeLimitExceeded(totalSize, limitSize int64) error {
	return &Error{
		ReasonCode: ReasonTaskSizeLimitExceeded,
		Message:    fmt.Sprintf("单次传输任务总量 %d 字节超过用户配置的 %d 字节上限", totalSize, limitSize),
	}
}

func ValidateTaskFileCount(fileCount int) error {
	if fileCount > MaxTaskFiles {
		return TaskFileLimitExceeded(fileCount)
	}
	return nil
}

func ValidateFileSize(fileSize, maxFileBytes int64) error {
	if fileSize > EffectiveMaxFileBytes(maxFileBytes) {
		return FileTooLarge(fileSize, maxFileBytes)
	}
	return nil
}
