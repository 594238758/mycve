package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"qtransc/internal/misc"
	"qtransc/internal/netclient"
	"qtransc/internal/types"
	"strings"
	"time"

	"github.com/spf13/pflag"
	"github.com/spf13/viper"
)

const (
	defaultSSEHeartbeatInterval = 5 * time.Second
	defaultSSEProgressInterval  = 1 * time.Second
)

// LogRotationConfig 日志切分配置
type LogRotationConfig struct {
	Enable     bool `json:"enable"`
	MaxSize    int  `json:"maxSize"`
	MaxBackups int  `json:"maxBackups"`
	MaxAge     int  `json:"maxAge"`
	Compress   bool `json:"compress"`
}

type EventLogConfig struct {
	Enable  bool   `json:"enable"`
	Path    string `json:"path"`
	MaxSize int    `json:"maxSize"`
}

// LogConfig 日志配置选项
type LogConfig struct {
	Level         string            `json:"level"`         // 日志级别: debug, info, warn, error
	Directory     string            `json:"directory"`     // 日志文件目录
	EngineLogPath string            `json:"engineLogPath"` // 应用日志文件路径
	GINLogPath    string            `json:"ginLogPath"`    // Gin 日志文件路径
	Rotation      LogRotationConfig `json:"rotation"`      // 日志切分配置
	Events        EventLogConfig    `json:"events"`
}

type SSEConfig struct {
	HeartbeatInterval time.Duration `json:"-"`
	ProgressInterval  time.Duration `json:"-"`
}

func (c SSEConfig) MarshalJSON() ([]byte, error) {
	type alias struct {
		HeartbeatInterval string `json:"heartbeatInterval"`
		ProgressInterval  string `json:"progressInterval"`
	}
	return json.Marshal(alias{
		HeartbeatInterval: c.HeartbeatInterval.String(),
		ProgressInterval:  c.ProgressInterval.String(),
	})
}

// 应用配置
type AppConfig struct {
	Port         int // API服务器端口
	ExportSSLKey bool
	Debug        bool
	SecretKey    string `json:"-"`

	LogConfig        LogConfig
	TransferDefaults types.TransferSettings
	SSEConfig        SSEConfig
}

// RegisterServeFlags adds only serve-specific flags. Shared flags are inherited
// from the root Cobra command and parsed together with these flags.
func RegisterServeFlags(flags *pflag.FlagSet) {
	flags.IntP("port", "p", 10000, "Port to run the server on")
	flags.String("secret-key", "", "Optional bearer secret for the server API")

	// 日志相关参数
	flags.StringP("loglevel", "", "debug", "Log level: debug, info, warn, error")
	flags.Bool("events-log", false, "Enable SSE event logs in engine_events.log")
	flags.Duration("sse-heartbeat-interval", defaultSSEHeartbeatInterval, "SSE heartbeat interval (e.g. 5s, 500ms)")
	flags.Duration("sse-progress-interval", defaultSSEProgressInterval, "SSE task/file/chunk progress report interval (e.g. 1s, 300ms)")
}

// 设置默认值
func setDefaults(v *viper.Viper) {
	v.SetDefault("port", 10000)
	v.SetDefault("secret-key", "")
	v.SetDefault("export-sslkey", false)
	v.SetDefault("debug", false)

	// 日志相关默认值
	v.SetDefault("log.level", "debug")
	v.SetDefault("log.path", "")
	v.SetDefault("log.rotation.enable", true)
	v.SetDefault("log.rotation.maxSize", 100)
	v.SetDefault("log.rotation.maxBackups", 3)
	v.SetDefault("log.rotation.maxAge", 28)
	v.SetDefault("log.rotation.compress", true)
	v.SetDefault("log.events.enable", false)
	v.SetDefault("log.events.maxSize", 512)

	v.SetDefault("sse.heartbeatInterval", defaultSSEHeartbeatInterval.String())
	v.SetDefault("sse.progressInterval", defaultSSEProgressInterval.String())
}

func bindCompatibilityFlags(v *viper.Viper, flagset *pflag.FlagSet) error {
	if flagset.Lookup("loglevel") != nil {
		if err := v.BindPFlag("log.level", flagset.Lookup("loglevel")); err != nil {
			return fmt.Errorf("绑定 loglevel 到 viper 键 log.level 失败: %w", err)
		}
	}
	if flagset.Lookup("log-path") != nil {
		if err := v.BindPFlag("log.path", flagset.Lookup("log-path")); err != nil {
			return fmt.Errorf("绑定 log-path 到 viper 键 log.path 失败: %w", err)
		}
	}
	if flagset.Lookup("events-log") != nil {
		if err := v.BindPFlag("log.events.enable", flagset.Lookup("events-log")); err != nil {
			return fmt.Errorf("绑定 events-log 到 viper 键 log.events.enable 失败: %w", err)
		}
	}
	if flagset.Lookup("connections") != nil {
		if err := v.BindPFlag("quic.transports", flagset.Lookup("connections")); err != nil {
			return fmt.Errorf("绑定 connections 到 viper 键 quic.transports 失败: %w", err)
		}
	}
	if flagset.Lookup("streams") != nil {
		if err := v.BindPFlag("quic.streamspertransport", flagset.Lookup("streams")); err != nil {
			return fmt.Errorf("绑定 streams 到 viper 键 quic.streamspertransport 失败: %w", err)
		}
	}
	if flagset.Lookup("sse-heartbeat-interval") != nil {
		if err := v.BindPFlag("sse.heartbeatInterval", flagset.Lookup("sse-heartbeat-interval")); err != nil {
			return fmt.Errorf("绑定 sse-heartbeat-interval 到 viper 键 sse.heartbeatInterval 失败: %w", err)
		}
	}
	if flagset.Lookup("sse-progress-interval") != nil {
		if err := v.BindPFlag("sse.progressInterval", flagset.Lookup("sse-progress-interval")); err != nil {
			return fmt.Errorf("绑定 sse-progress-interval 到 viper 键 sse.progressInterval 失败: %w", err)
		}
	}
	return nil
}

func buildConfigFromViper(v *viper.Viper) *AppConfig {
	config := &AppConfig{}

	config.Port = v.GetInt("port")
	config.SecretKey = strings.TrimSpace(v.GetString("secret-key"))
	config.ExportSSLKey = v.GetBool("export-sslkey")
	config.Debug = v.GetBool("debug")

	config.LogConfig.Level = v.GetString("log.level")
	config.LogConfig.Directory = strings.TrimSpace(v.GetString("log.path"))
	if config.LogConfig.Directory != "" {
		logDir := config.LogConfig.Directory
		config.LogConfig.EngineLogPath = filepath.Join(logDir, "qtransc.log")
		config.LogConfig.GINLogPath = config.LogConfig.EngineLogPath
		config.LogConfig.Events.Path = filepath.Join(logDir, "engine_events.log")
	} else {
		config.LogConfig.EngineLogPath = ""
		config.LogConfig.GINLogPath = ""
		config.LogConfig.Events.Path = misc.EventsLogPath
	}
	config.LogConfig.Rotation.Enable = v.GetBool("log.rotation.enable")
	config.LogConfig.Rotation.MaxSize = v.GetInt("log.rotation.maxSize")
	config.LogConfig.Rotation.MaxBackups = v.GetInt("log.rotation.maxBackups")
	config.LogConfig.Rotation.MaxAge = v.GetInt("log.rotation.maxAge")
	config.LogConfig.Rotation.Compress = v.GetBool("log.rotation.compress")
	config.LogConfig.Events.Enable = v.GetBool("log.events.enable")
	config.LogConfig.Events.MaxSize = v.GetInt("log.events.maxSize")

	config.TransferDefaults = types.TransferSettings{
		Transport:       types.TransportMode(v.GetString("transport")),
		Connections:     v.GetInt("quic.transports"),
		Streams:         v.GetInt("quic.streamspertransport"),
		FileConcurrency: v.GetInt("transfers"),
	}
	config.SSEConfig.HeartbeatInterval = v.GetDuration("sse.heartbeatInterval")
	config.SSEConfig.ProgressInterval = v.GetDuration("sse.progressInterval")

	return config
}

// Load merges the already parsed Cobra flags with engine.toml. Explicit flags
// take precedence over the file; unconfigured settings use the flag defaults.
func Load(flagset *pflag.FlagSet) (*AppConfig, error) {
	// 初始化viper
	v := viper.New()
	v.SetConfigName("engine")
	v.SetConfigType("toml")
	exePath, err := os.Executable()
	if err == nil {
		exeDir := filepath.Dir(exePath)
		v.AddConfigPath(exeDir)
		v.AddConfigPath(filepath.Join(exeDir, "../conf"))
	}

	// 设置配置文件默认值
	setDefaults(v)

	// 绑定命令行参数到viper
	if err := v.BindPFlags(flagset); err != nil {
		return nil, fmt.Errorf("绑定命令行参数失败: %w", err)
	}

	if err := bindCompatibilityFlags(v, flagset); err != nil {
		return nil, err
	}

	// 读取配置文件
	if err := v.ReadInConfig(); err != nil {
		// 配置文件不存在不是错误
		if _, ok := err.(viper.ConfigFileNotFoundError); !ok {
			return nil, fmt.Errorf("读取配置文件失败: %w", err)
		}
		//fmt.Println("配置文件未找到，使用默认值和命令行参数: ", err)
	} else {
		//fmt.Println("使用配置文件:", v.ConfigFileUsed())
	}

	config := buildConfigFromViper(v)
	if err := checkConfig(config); err != nil {
		return nil, err
	}
	return config, nil
}

func checkConfig(c *AppConfig) error {
	mode, err := types.ParseTransportMode(c.TransferDefaults.Transport.String())
	if err != nil {
		return err
	}
	c.TransferDefaults.Transport = mode
	if _, err := netclient.NormalizePoolConfig(mode, c.TransferDefaults.Connections, c.TransferDefaults.Streams); err != nil {
		return err
	}
	if c.TransferDefaults.FileConcurrency <= 0 {
		return fmt.Errorf("transfers must be greater than 0")
	}
	if c.Port == 0 {
		return fmt.Errorf("Port number is required and must be greater than 0")
	}
	if c.LogConfig.Level != "debug" &&
		c.LogConfig.Level != "info" &&
		c.LogConfig.Level != "warn" &&
		c.LogConfig.Level != "error" {
		return fmt.Errorf("Invalid log level: %s. Must be one of: debug, info, warn, error", c.LogConfig.Level)
	}
	if c.LogConfig.Events.Enable && c.LogConfig.Events.MaxSize <= 0 {
		return fmt.Errorf("Invalid events log max size: %d. Must be greater than 0", c.LogConfig.Events.MaxSize)
	}
	if c.SSEConfig.HeartbeatInterval <= 0 {
		return fmt.Errorf("Invalid SSE heartbeat interval: %s. Must be greater than 0", c.SSEConfig.HeartbeatInterval)
	}
	if c.SSEConfig.ProgressInterval <= 0 {
		return fmt.Errorf("Invalid SSE progress interval: %s. Must be greater than 0", c.SSEConfig.ProgressInterval)
	}
	return nil
}

func (c *AppConfig) ToJSON() string {
	b, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return fmt.Sprintf("Error marshaling config to JSON: %v", err)
	}
	return string(b)
}
