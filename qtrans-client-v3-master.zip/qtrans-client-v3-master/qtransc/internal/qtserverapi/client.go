package qtserverapi

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"

	"qtransc/internal/authmanager"
	"qtransc/internal/netclient"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/transferlimits"
	"qtransc/internal/transferretry"
	"qtransc/internal/types"
)

type APIError struct {
	Status     int
	ReasonCode string
	Message    string
	Body       []byte
	Header     http.Header
}

var ErrRetryWindowExhausted = errors.New("qtserver retry window exhausted")

var (
	newRetryBackoff     = transferretry.NewBackoff
	waitForRetry        = transferretry.Wait
	semanticRetryWindow = 30 * time.Second
)

const AnonymousWriteToken = "00000000-0000-4000-8000-000000000000"

const capabilitiesPreflightTimeout = 15 * time.Second

func (e *APIError) Error() string {
	if e.ReasonCode != "" {
		if e.Message != "" {
			return fmt.Sprintf("qtserver status=%d reason=%s: %s", e.Status, e.ReasonCode, e.Message)
		}
		return fmt.Sprintf("qtserver status=%d reason=%s", e.Status, e.ReasonCode)
	}
	if e.Message != "" {
		return fmt.Sprintf("qtserver status=%d: %s", e.Status, e.Message)
	}

	details := []string{fmt.Sprintf("status=%d", e.Status)}
	if contentType := strings.TrimSpace(e.Header.Get("Content-Type")); contentType != "" {
		details = append(details, fmt.Sprintf("content-type=%q", contentType))
	}
	if server := strings.TrimSpace(e.Header.Get("Server")); server != "" {
		details = append(details, fmt.Sprintf("server=%q", server))
	}
	return "qtserver returned an unexpected response: " + strings.Join(details, " ")
}

type CapabilitiesAccessError struct {
	Server    string
	Transport types.TransportMode
	Err       error
}

func (e *CapabilitiesAccessError) Error() string {
	if e == nil {
		return "access qtserver capabilities failed"
	}
	prefix := fmt.Sprintf("access qtserver capabilities at %s via %s failed", e.Server, e.Transport)
	if e.Err == nil {
		return prefix
	}
	return fmt.Sprintf("%s: %v", prefix, e.Err)
}

func (e *CapabilitiesAccessError) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.Err
}

type UnsupportedAPIVersionError struct {
	Version string
}

func (e *UnsupportedAPIVersionError) Error() string {
	if e == nil {
		return "unsupported qtserver API major version"
	}
	return fmt.Sprintf("unsupported qtserver API major version %q", e.Version)
}

type CapabilityUnavailableError struct {
	Name string
}

func (e *CapabilityUnavailableError) Error() string {
	if e == nil {
		return "qtserver capability is unavailable"
	}
	return fmt.Sprintf("qtserver capability %q is unavailable", e.Name)
}

type AnonymousAccessUnavailableError struct {
	Write bool
}

func (e *AnonymousAccessUnavailableError) Error() string {
	if e != nil && e.Write {
		return "qtserver anonymous write access is unavailable"
	}
	return "qtserver anonymous read access is unavailable"
}

type RetryMode int

const (
	NoRetry RetryMode = iota
	IdempotentRetry
	// PersistentBusyRetry is reserved for an idempotent operation whose
	// SESSION_BUSY and NAMESPACE_BUSY responses may be retried until its
	// context is canceled. Other retry classifications retain their budgets.
	PersistentBusyRetry
)

func (mode RetryMode) allowsRetry() bool {
	return mode == IdempotentRetry || mode == PersistentBusyRetry
}

func (mode RetryMode) persistsBusyRetry() bool {
	return mode == PersistentBusyRetry
}

type TaskCorrelation struct {
	TaskID       string
	TaskPID      string
	EnterpriseID string
}

func DoJSON(ctx context.Context, server, endpoint, method, token, taskID string, payload any, network *netclient.Client, retry RetryMode) (int, http.Header, []byte, error) {
	return DoJSONWithHeaders(ctx, server, endpoint, method, token, taskID, payload, nil, network, retry)
}

func DoJSONWithCorrelation(ctx context.Context, server, endpoint, method, token string, correlation TaskCorrelation, payload any, network *netclient.Client, retry RetryMode) (int, http.Header, []byte, error) {
	return DoJSONWithHeadersAndCorrelation(ctx, server, endpoint, method, token, correlation, payload, nil, network, retry)
}

func DoJSONWithCorrelationWithoutAuthRefresh(ctx context.Context, server, endpoint, method, token string, correlation TaskCorrelation, payload any, network *netclient.Client, retry RetryMode) (int, http.Header, []byte, error) {
	return doJSONWithHeadersAndCorrelation(ctx, server, endpoint, method, token, correlation, payload, nil, network, retry, false)
}

func DoJSONWithHeaders(ctx context.Context, server, endpoint, method, token, taskID string, payload any, requestHeaders http.Header, network *netclient.Client, retry RetryMode) (int, http.Header, []byte, error) {
	return DoJSONWithHeadersAndCorrelation(ctx, server, endpoint, method, token, TaskCorrelation{TaskID: taskID}, payload, requestHeaders, network, retry)
}

func DoJSONWithHeadersAndCorrelation(ctx context.Context, server, endpoint, method, token string, correlation TaskCorrelation, payload any, requestHeaders http.Header, network *netclient.Client, retry RetryMode) (int, http.Header, []byte, error) {
	return doJSONWithHeadersAndCorrelation(ctx, server, endpoint, method, token, correlation, payload, requestHeaders, network, retry, true)
}

func DoJSONWithHeadersAndCorrelationWithoutAuthRefresh(ctx context.Context, server, endpoint, method, token string, correlation TaskCorrelation, payload any, requestHeaders http.Header, network *netclient.Client, retry RetryMode) (int, http.Header, []byte, error) {
	return doJSONWithHeadersAndCorrelation(ctx, server, endpoint, method, token, correlation, payload, requestHeaders, network, retry, false)
}

func doJSONWithHeadersAndCorrelation(ctx context.Context, server, endpoint, method, token string, correlation TaskCorrelation, payload any, requestHeaders http.Header, network *netclient.Client, retry RetryMode, allowAuthRefresh bool) (int, http.Header, []byte, error) {
	requestURL, err := qtserverurl.JoinEndpoint(server, endpoint)
	if err != nil {
		return 0, nil, nil, err
	}
	var encoded []byte
	if payload != nil {
		encoded, err = json.Marshal(payload)
		if err != nil {
			return 0, nil, nil, err
		}
	}
	backoff := newRetryBackoff()
	var semanticRetryStarted time.Time
	var http500Budget transferretry.HTTP500Budget
	authRefreshAttempted := false
	for {
		status, header, body, requestErr := doOnce(ctx, requestURL, method, token, correlation, encoded, requestHeaders, network)
		if requestErr == nil && status < 400 {
			return status, header, body, nil
		}
		if requestErr == nil {
			requestErr = decodeAPIError(status, header, body)
			if allowAuthRefresh && status == http.StatusUnauthorized && token != "" && !authRefreshAttempted && authmanager.Mode() == authmanager.AuthModeUserAndPass {
				authRefreshAttempted = true
				if refreshErr := authmanager.ForceRefresh(ctx); refreshErr != nil {
					return status, header, body, errors.Join(requestErr, fmt.Errorf("refresh credentials after 401: %w", refreshErr))
				}
				freshToken, tokenErr := authmanager.Get()
				if tokenErr != nil {
					return status, header, body, errors.Join(requestErr, fmt.Errorf("read refreshed credentials after 401: %w", tokenErr))
				}
				token = freshToken
				continue
			}
		}
		if !retry.allowsRetry() {
			return status, header, body, requestErr
		}

		retryRequest := false
		semanticRetry := false
		switch {
		case status == http.StatusInternalServerError:
			if !http500Budget.Take() {
				return status, header, body, requestErr
			}
			retryRequest = true
		case status == http.StatusConflict && isBusyConflict(requestErr):
			if semanticRetryStarted.IsZero() {
				semanticRetryStarted = time.Now()
			}
			retryRequest = true
			semanticRetry = true
		case transferretry.IsAvailabilityStatus(status):
			retryRequest = true
		case status == 0 && transferretry.IsAvailabilityError(ctx, requestErr):
			retryRequest = true
		}
		if !retryRequest {
			return status, header, body, requestErr
		}

		wait := backoff.Next(header, time.Now())
		if semanticRetry && !retry.persistsBusyRetry() && !semanticRetryStarted.IsZero() && time.Since(semanticRetryStarted)+wait > semanticRetryWindow {
			return status, header, body, fmt.Errorf("%w: %w", ErrRetryWindowExhausted, requestErr)
		}
		if err := waitForRetry(ctx, wait); err != nil {
			return status, header, body, err
		}
	}
}

func doOnce(ctx context.Context, requestURL, method, token string, correlation TaskCorrelation, body []byte, headers http.Header, network *netclient.Client) (int, http.Header, []byte, error) {
	request, err := http.NewRequestWithContext(ctx, method, requestURL, bytes.NewReader(body))
	if err != nil {
		return 0, nil, nil, err
	}
	for name, values := range headers {
		for _, value := range values {
			request.Header.Add(name, value)
		}
	}
	if token != "" {
		request.Header.Set("Authorization", "Bearer "+token)
	}
	SetTaskCorrelationHeaders(request.Header, correlation)
	if body != nil {
		request.Header.Set("Content-Type", "application/json")
	}
	client, release, err := network.Acquire(ctx, requestURL)
	if err != nil {
		return 0, nil, nil, err
	}
	response, err := client.Do(request)
	if err != nil {
		release()
		return 0, nil, nil, err
	}
	defer release()
	defer response.Body.Close()
	// Canonical list responses can legitimately contain up to 100,000 entries.
	// The server-side entry limit is the protocol bound; truncating here would
	// turn a valid response (including truncated=true) into invalid JSON.
	responseBody, err := io.ReadAll(response.Body)
	return response.StatusCode, response.Header.Clone(), responseBody, err
}

func SetTaskCorrelationHeaders(header http.Header, correlation TaskCorrelation) {
	if correlation.TaskID == "" {
		return
	}
	header.Set("X-Task-ID", correlation.TaskID)
	header.Set("X-Task-PID", correlation.TaskPID)
	header.Set("X-Enterprise-ID", correlation.EnterpriseID)
}

func decodeAPIError(status int, header http.Header, body []byte) error {
	var envelope struct {
		Code       int    `json:"code"`
		ReasonCode string `json:"reason_code"`
		Message    string `json:"message"`
	}
	if err := json.Unmarshal(body, &envelope); err != nil || envelope.Code == 0 || strings.TrimSpace(envelope.ReasonCode) == "" || strings.TrimSpace(envelope.Message) == "" {
		return &APIError{Status: status, Body: body, Header: header.Clone()}
	}
	return &APIError{Status: status, ReasonCode: envelope.ReasonCode, Message: envelope.Message, Body: body, Header: header.Clone()}
}

func isBusyConflict(err error) bool {
	var apiErr *APIError
	return errors.As(err, &apiErr) &&
		(apiErr.ReasonCode == "SESSION_BUSY" || apiErr.ReasonCode == "NAMESPACE_BUSY")
}

type CapabilityState struct {
	Enabled   bool `json:"enabled"`
	Available bool `json:"available"`
}

type AnonymousCapabilities struct {
	Read  bool `json:"read"`
	Write bool `json:"write"`
}

type Capabilities struct {
	APIVersion   string                     `json:"api_version"`
	Capabilities map[string]CapabilityState `json:"capabilities"`
	Anonymous    *AnonymousCapabilities     `json:"anonymous"`
	Limits       map[string]int64           `json:"limits"`
	Algorithms   []string                   `json:"algorithms"`
}

type SmallDownloadV2Limits struct {
	Files      int
	FileBytes  int64
	TotalBytes int64
}

func (c Capabilities) SmallDownloadV2() (SmallDownloadV2Limits, bool, error) {
	state, exists := c.Capabilities["small_download_v2"]
	if !exists || !state.Enabled || !state.Available {
		return SmallDownloadV2Limits{}, false, nil
	}
	algorithmFound := false
	for _, algorithm := range c.Algorithms {
		if algorithm == types.UploadHashAlgorithmLayeredXXH3_128 {
			algorithmFound = true
			break
		}
	}
	if !algorithmFound {
		return SmallDownloadV2Limits{}, false, errors.New("small_download_v2 is available but layered_xxh3_128_v1 is not advertised")
	}
	files := c.Limits["small_files"]
	fileBytes := c.Limits["small_file_bytes"]
	totalBytes := c.Limits["small_total_bytes"]
	if files <= 0 || files > int64(^uint(0)>>1) || fileBytes <= 0 || totalBytes <= 0 {
		return SmallDownloadV2Limits{}, false, errors.New("small_download_v2 is available but its limits are invalid")
	}
	return SmallDownloadV2Limits{
		Files:      int(files),
		FileBytes:  fileBytes,
		TotalBytes: totalBytes,
	}, true, nil
}

// MaxFileBytes returns the effective single-file limit advertised by qtserver.
// API v1 servers that predate this capability field retain the 1 TiB default.
func (c Capabilities) MaxFileBytes() int64 {
	return transferlimits.EffectiveMaxFileBytes(c.Limits["max_file_bytes"])
}

func (c Capabilities) RequireAnonymousRead() error {
	if c.Anonymous == nil || !c.Anonymous.Read {
		return &AnonymousAccessUnavailableError{}
	}
	return nil
}

func (c Capabilities) RequireAnonymousWrite() error {
	if c.Anonymous == nil || !c.Anonymous.Write {
		return &AnonymousAccessUnavailableError{Write: true}
	}
	return nil
}

type cachedCapabilities struct {
	value   Capabilities
	expires time.Time
}

var capabilityCache struct {
	sync.Mutex
	values map[string]cachedCapabilities
}

func FetchCapabilities(ctx context.Context, server string, network *netclient.Client) (Capabilities, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	ctx, cancel := context.WithTimeout(ctx, capabilitiesPreflightTimeout)
	defer cancel()

	key := server + "|" + network.Mode().String()
	capabilityCache.Lock()
	if item, ok := capabilityCache.values[key]; ok && time.Now().Before(item.expires) {
		capabilityCache.Unlock()
		return item.value, nil
	}
	capabilityCache.Unlock()
	_, _, body, err := DoJSON(ctx, server, "/capabilities", http.MethodGet, "", "", nil, network, IdempotentRetry)
	if err != nil {
		return Capabilities{}, &CapabilitiesAccessError{Server: server, Transport: network.Mode(), Err: err}
	}
	var result Capabilities
	if err := json.Unmarshal(body, &result); err != nil {
		return Capabilities{}, &CapabilitiesAccessError{
			Server:    server,
			Transport: network.Mode(),
			Err:       fmt.Errorf("decode capabilities response: %w", err),
		}
	}
	if strings.TrimSpace(result.APIVersion) == "" {
		return Capabilities{}, &CapabilitiesAccessError{
			Server:    server,
			Transport: network.Mode(),
			Err:       errors.New("capabilities response is missing api_version"),
		}
	}
	if result.APIVersion != "1" {
		return Capabilities{}, &UnsupportedAPIVersionError{Version: result.APIVersion}
	}
	if result.Capabilities == nil {
		return Capabilities{}, &CapabilitiesAccessError{
			Server:    server,
			Transport: network.Mode(),
			Err:       errors.New("capabilities response is missing capabilities"),
		}
	}
	if result.Anonymous == nil {
		return Capabilities{}, &CapabilitiesAccessError{
			Server:    server,
			Transport: network.Mode(),
			Err:       errors.New("capabilities response is missing anonymous access state"),
		}
	}
	capabilityCache.Lock()
	if capabilityCache.values == nil {
		capabilityCache.values = make(map[string]cachedCapabilities)
	}
	capabilityCache.values[key] = cachedCapabilities{value: result, expires: time.Now().Add(5 * time.Second)}
	capabilityCache.Unlock()
	return result, nil
}

func RequireCapabilities(ctx context.Context, server string, network *netclient.Client, names ...string) (Capabilities, error) {
	result, err := FetchCapabilities(ctx, server, network)
	if err != nil {
		return Capabilities{}, err
	}
	for _, name := range names {
		state, ok := result.Capabilities[name]
		if !ok || !state.Enabled || !state.Available {
			return Capabilities{}, &CapabilityUnavailableError{Name: name}
		}
	}
	return result, nil
}

func IsReason(err error, reason string) bool {
	var apiErr *APIError
	return errors.As(err, &apiErr) && strings.EqualFold(apiErr.ReasonCode, reason)
}
