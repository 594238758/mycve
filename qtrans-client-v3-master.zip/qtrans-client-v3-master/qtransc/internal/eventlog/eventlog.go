package eventlog

import (
	"io"
	"log/slog"
	"sync"

	"qtransc/internal/config"

	"gopkg.in/natefinch/lumberjack.v2"
)

var (
	loggerMu sync.RWMutex
	logger   = newDiscardLogger()
	enabled  bool
	closer   io.Closer
)

func Logger() *slog.Logger {
	loggerMu.RLock()
	current := logger
	loggerMu.RUnlock()
	return current
}

func Enabled() bool {
	loggerMu.RLock()
	current := enabled
	loggerMu.RUnlock()
	return current
}

func SetLogger(l *slog.Logger, on bool) {
	setLoggerWithCloser(l, on, nil)
}

func setLoggerWithCloser(l *slog.Logger, on bool, c io.Closer) {
	var previousCloser io.Closer
	loggerMu.Lock()
	previousCloser = closer
	if l == nil {
		l = newDiscardLogger()
		on = false
		c = nil
	}
	logger = l
	enabled = on
	closer = c
	loggerMu.Unlock()

	if previousCloser != nil {
		_ = previousCloser.Close()
	}
}

func Info(msg string, args ...any) {
	if !Enabled() {
		return
	}
	Logger().Info(msg, args...)
}

func Warn(msg string, args ...any) {
	if !Enabled() {
		return
	}
	Logger().Warn(msg, args...)
}

// Init 初始化事件日志，使用 LogConfig 中的 Events 和 Rotation 配置。
func Init(conf config.LogConfig) {
	if !conf.Events.Enable {
		SetLogger(nil, false)
		return
	}
	maxSize := conf.Events.MaxSize
	if maxSize <= 0 {
		maxSize = conf.Rotation.MaxSize
	}
	if maxSize <= 0 {
		maxSize = 100
	}
	writer := &lumberjack.Logger{
		Filename:   conf.Events.Path,
		MaxSize:    maxSize,
		MaxBackups: conf.Rotation.MaxBackups,
		MaxAge:     conf.Rotation.MaxAge,
		Compress:   conf.Rotation.Compress,
	}
	setLoggerWithCloser(slog.New(slog.NewJSONHandler(writer, &slog.HandlerOptions{Level: slog.LevelInfo})), true, writer)
}

func newDiscardLogger() *slog.Logger {
	return slog.New(slog.NewJSONHandler(io.Discard, &slog.HandlerOptions{Level: slog.LevelInfo}))
}
