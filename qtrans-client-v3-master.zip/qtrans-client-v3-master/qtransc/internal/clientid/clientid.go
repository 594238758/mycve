package clientid

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/base32"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/denisbrodbeck/machineid"
)

const (
	clientIDPrefix   = "qtc1_"
	clientIDDigest   = 52
	maxClientIDBytes = 128
)

func LoadOrCreate() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", fmt.Errorf("resolve user home for client id: %w", err)
	}
	dir := filepath.Join(home, ".qtrans")
	path := filepath.Join(dir, "client_id")

	id, err := read(path)
	if err == nil {
		return id, nil
	}
	if !errors.Is(err, fs.ErrNotExist) {
		return "", err
	}
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", fmt.Errorf("create client id directory: %w", err)
	}

	id, err = generate()
	if err != nil {
		return "", err
	}
	if err := create(path, id); err != nil {
		if !os.IsExist(err) {
			return "", err
		}
		return readAfterConcurrentCreate(path)
	}
	return id, nil
}

func generate() (string, error) {
	source, value := hardwareIdentity()
	if value == "" {
		if machineValue, err := machineid.ID(); err == nil {
			if normalized := normalizeIdentity(machineValue); normalized != "" {
				source, value = "os_installation", normalized
			}
		}
	}
	if value == "" {
		var random [16]byte
		if _, err := rand.Read(random[:]); err != nil {
			return "", fmt.Errorf("generate client id seed: %w", err)
		}
		source, value = "random", hex.EncodeToString(random[:])
	}
	sum := sha256.Sum256([]byte("qtrans-client-id/v1\x00" + source + "\x00" + value))
	digest := strings.ToLower(base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(sum[:]))
	return clientIDPrefix + digest, nil
}

func normalizeIdentity(raw string) string {
	value := strings.ToLower(strings.TrimSpace(raw))
	for _, invalid := range []string{
		"unknown", "not specified", "not available", "to be filled by o.e.m.",
		"default string", "system serial number", "none", "null",
	} {
		if value == invalid {
			return ""
		}
	}
	var normalized strings.Builder
	for _, char := range value {
		if (char >= 'a' && char <= 'z') || (char >= '0' && char <= '9') {
			normalized.WriteRune(char)
		}
	}
	value = normalized.String()
	switch value {
	case "unknown", "notspecified", "notavailable", "tobefilledbyoem",
		"defaultstring", "systemserialnumber", "none", "null":
		return ""
	}
	if len(value) < 8 || allByte(value, '0') || allByte(value, 'f') {
		return ""
	}
	return value
}

func allByte(value string, expected byte) bool {
	for index := range value {
		if value[index] != expected {
			return false
		}
	}
	return value != ""
}

func read(path string) (string, error) {
	info, err := os.Lstat(path)
	if err != nil {
		return "", fmt.Errorf("inspect client id file: %w", err)
	}
	if info.Mode()&os.ModeSymlink != 0 || !info.Mode().IsRegular() {
		return "", fmt.Errorf("client id path must be a regular non-symlink file")
	}
	file, err := os.Open(path)
	if err != nil {
		return "", fmt.Errorf("open client id file: %w", err)
	}
	defer file.Close()
	data, err := io.ReadAll(io.LimitReader(file, maxClientIDBytes+1))
	if err != nil {
		return "", fmt.Errorf("read client id file: %w", err)
	}
	if len(data) > maxClientIDBytes {
		return "", fmt.Errorf("client id file is too large")
	}
	id := strings.TrimSpace(string(data))
	if !valid(id) {
		return "", fmt.Errorf("client id file contains an invalid id")
	}
	if err := os.Chmod(path, 0o600); err != nil {
		return "", fmt.Errorf("secure client id file: %w", err)
	}
	return id, nil
}

func valid(id string) bool {
	if len(id) != len(clientIDPrefix)+clientIDDigest || !strings.HasPrefix(id, clientIDPrefix) {
		return false
	}
	for _, char := range id[len(clientIDPrefix):] {
		if (char < 'a' || char > 'z') && (char < '2' || char > '7') {
			return false
		}
	}
	return true
}

func create(path, id string) (resultErr error) {
	file, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if err != nil {
		return fmt.Errorf("create client id file: %w", err)
	}
	created := true
	defer func() {
		if resultErr != nil && created {
			_ = os.Remove(path)
		}
	}()
	if _, err := io.WriteString(file, id+"\n"); err != nil {
		_ = file.Close()
		return fmt.Errorf("write client id file: %w", err)
	}
	if err := file.Sync(); err != nil {
		_ = file.Close()
		return fmt.Errorf("sync client id file: %w", err)
	}
	if err := file.Close(); err != nil {
		return fmt.Errorf("close client id file: %w", err)
	}
	created = false
	return nil
}

func readAfterConcurrentCreate(path string) (string, error) {
	var lastErr error
	for range 10 {
		if id, err := read(path); err == nil {
			return id, nil
		} else {
			lastErr = err
		}
		time.Sleep(10 * time.Millisecond)
	}
	return "", fmt.Errorf("read concurrently created client id: %w", lastErr)
}
