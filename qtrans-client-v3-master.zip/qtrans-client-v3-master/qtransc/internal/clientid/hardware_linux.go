//go:build linux

package clientid

import "os"

func hardwareIdentity() (string, string) {
	for _, candidate := range []struct {
		source string
		path   string
	}{
		{source: "system_uuid", path: "/sys/class/dmi/id/product_uuid"},
		{source: "board_serial", path: "/sys/class/dmi/id/board_serial"},
	} {
		data, err := os.ReadFile(candidate.path)
		if err != nil {
			continue
		}
		if value := normalizeIdentity(string(data)); value != "" {
			return candidate.source, value
		}
	}
	return "", ""
}
