//go:build darwin

package clientid

import "github.com/denisbrodbeck/machineid"

func hardwareIdentity() (string, string) {
	value, err := machineid.ID()
	if err != nil {
		return "", ""
	}
	return "platform_uuid", normalizeIdentity(value)
}
