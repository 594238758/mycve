//go:build !darwin && !linux && !windows

package clientid

func hardwareIdentity() (string, string) {
	return "", ""
}
