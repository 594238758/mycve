//go:build windows

package clientid

import (
	"context"
	"os/exec"
	"strings"
	"time"
)

func hardwareIdentity() (string, string) {
	commands := [][]string{
		{"powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", `[Console]::OutputEncoding = [Text.UTF8Encoding]::new(); (Get-CimInstance -ClassName Win32_ComputerSystemProduct).UUID`},
		{"wmic.exe", "csproduct", "get", "uuid", "/value"},
	}
	for _, arguments := range commands {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		output, err := exec.CommandContext(ctx, arguments[0], arguments[1:]...).Output()
		cancel()
		if err != nil {
			continue
		}
		for _, line := range strings.Split(string(output), "\n") {
			line = strings.TrimSpace(strings.TrimPrefix(line, "UUID="))
			if value := normalizeIdentity(line); value != "" {
				return "system_uuid", value
			}
		}
	}
	return "", ""
}
