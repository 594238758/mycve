package qtserverurl

import (
	"fmt"
	"net/url"
	"strings"
)

const (
	APIBasePath         = "/qtserver/v1"
	DownloadContentPath = APIBasePath + "/d/down"
)

// NormalizeServerOrigin validates the address supplied through --server.
// A qtransc server address is deliberately limited to scheme://host[:port];
// the qtserver API prefix is a protocol constant, not deployment input.
func NormalizeServerOrigin(raw string) (string, error) {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" {
		return "", fmt.Errorf("qtserver origin is empty")
	}

	parsed, err := url.Parse(trimmed)
	if err != nil {
		return "", fmt.Errorf("invalid qtserver origin %q: %w", raw, err)
	}
	if (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
		return "", fmt.Errorf("qtserver origin must be an absolute http or https URL")
	}
	if parsed.User != nil || parsed.RawQuery != "" || parsed.Fragment != "" || parsed.Opaque != "" {
		return "", fmt.Errorf("qtserver origin must not contain userinfo, query, or fragment")
	}
	if parsed.Path != "" && parsed.Path != "/" {
		return "", fmt.Errorf("qtserver origin must not contain a path")
	}

	return fmt.Sprintf("%s://%s", parsed.Scheme, parsed.Host), nil
}

// JoinEndpoint builds a qtserver API URL from an origin-only server address.
func JoinEndpoint(serverOrigin, endpoint string) (string, error) {
	origin, err := NormalizeServerOrigin(serverOrigin)
	if err != nil {
		return "", err
	}
	return origin + APIBasePath + normalizeEndpoint(endpoint), nil
}

// BuildDownloadURL builds the fixed download-content endpoint from the opaque
// grant returned by POST /d/grant.
func BuildDownloadURL(serverOrigin, objectKey, grant string) (string, error) {
	origin, err := NormalizeServerOrigin(serverOrigin)
	if err != nil {
		return "", err
	}
	escapedObjectKey, err := escapeObjectKey(objectKey)
	if err != nil {
		return "", err
	}
	grant = strings.TrimSpace(grant)
	if grant == "" {
		return "", fmt.Errorf("download grant is empty")
	}

	query := url.Values{}
	query.Set("grant", grant)
	return origin + DownloadContentPath + "/" + escapedObjectKey + "?" + query.Encode(), nil
}

// ExtractDownloadBaseAndObjectKey parses the fixed qtserver download-content
// URL used by the compatibility download command.
func ExtractDownloadBaseAndObjectKey(raw string) (string, string, error) {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil {
		return "", "", fmt.Errorf("invalid remote_url %q: %w", raw, err)
	}
	if (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
		return "", "", fmt.Errorf("remote_url must be an absolute http or https URL: %q", raw)
	}
	if parsed.User != nil || parsed.Fragment != "" || parsed.Opaque != "" {
		return "", "", fmt.Errorf("invalid remote_url %q", raw)
	}

	escapedPath := parsed.EscapedPath()
	marker := DownloadContentPath + "/"
	if !strings.HasPrefix(escapedPath, marker) {
		return "", "", fmt.Errorf("remote_url must use %s", marker)
	}
	escapedObjectKey := strings.TrimPrefix(escapedPath, marker)
	if escapedObjectKey == "" {
		return "", "", fmt.Errorf("empty object key in remote_url %q", raw)
	}
	objectKey, err := url.PathUnescape("/" + escapedObjectKey)
	if err != nil {
		return "", "", fmt.Errorf("invalid object key in remote_url %q: %w", raw, err)
	}
	if _, err := escapeObjectKey(objectKey); err != nil {
		return "", "", err
	}

	return fmt.Sprintf("%s://%s", parsed.Scheme, parsed.Host), objectKey, nil
}

func escapeObjectKey(objectKey string) (string, error) {
	if objectKey == "" || objectKey == "/" {
		return "", fmt.Errorf("object key is empty")
	}
	if !strings.HasPrefix(objectKey, "/") || strings.HasSuffix(objectKey, "/") {
		return "", fmt.Errorf("object key must be an absolute non-directory logical path")
	}

	segments := strings.Split(strings.TrimPrefix(objectKey, "/"), "/")
	escaped := make([]string, 0, len(segments))
	for _, segment := range segments {
		if segment == "" || segment == "." || segment == ".." {
			return "", fmt.Errorf("object key contains invalid path segment %q", segment)
		}
		escaped = append(escaped, url.PathEscape(segment))
	}
	return strings.Join(escaped, "/"), nil
}

func normalizeEndpoint(endpoint string) string {
	trimmed := strings.TrimSpace(endpoint)
	if trimmed == "" {
		return ""
	}
	if strings.HasPrefix(trimmed, "/") {
		return trimmed
	}
	return "/" + trimmed
}
