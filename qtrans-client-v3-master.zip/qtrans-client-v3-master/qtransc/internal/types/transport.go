package types

import (
	"fmt"
	"net/url"
	"strings"
)

type TransportMode string

const (
	TransportHTTPS  TransportMode = "v1"
	TransportHTTPS2 TransportMode = "v2"
	TransportHTTPS3 TransportMode = "v3"

	DefaultServerPort      = "23500"
	DefaultConnections     = 10
	DefaultStreams         = 1
	DefaultFileConcurrency = 5
)

// TransferOverrides preserves which concurrency settings a request supplies.
// Nil means omitted; supplied values must be validated before task admission.
type TransferOverrides struct {
	Connections *int
	Streams     *int
	Transfers   *int
}

// TransferSettings is an internal snapshot of resolved task settings or service defaults.
type TransferSettings struct {
	Transport       TransportMode `json:"transport"`
	Connections     int           `json:"connections"`
	Streams         int           `json:"streams"`
	FileConcurrency int           `json:"fileConcurrency"`
}

func ParseTransportMode(raw string) (TransportMode, error) {
	mode := TransportMode(strings.ToLower(strings.TrimSpace(raw)))
	if mode == "" {
		return TransportHTTPS3, nil
	}

	switch mode {
	case TransportHTTPS, TransportHTTPS2, TransportHTTPS3:
		return mode, nil
	// Keep existing configurations and requests compatible with the renamed modes.
	case "https":
		return TransportHTTPS, nil
	case "https2":
		return TransportHTTPS2, nil
	case "https3":
		return TransportHTTPS3, nil
	default:
		return "", fmt.Errorf("unsupported transport %q, expected one of: v1, v2, v3", raw)
	}
}

func (m TransportMode) String() string {
	if m == "" {
		return string(TransportHTTPS3)
	}
	return string(m)
}

func (m TransportMode) ServerScheme() string {
	return "https"
}

func (m TransportMode) UsesHTTP3() bool {
	return m == TransportHTTPS3
}

func (m TransportMode) ValidateServerURL(raw string) error {
	parsed, err := url.Parse(raw)
	if err != nil {
		return fmt.Errorf("invalid URL: %w", err)
	}
	if parsed.Scheme == "" || parsed.Host == "" {
		return fmt.Errorf("must be an absolute URL with scheme and host")
	}

	scheme := strings.ToLower(parsed.Scheme)
	if m == "" {
		m = TransportHTTPS3
	}
	switch m {
	case TransportHTTPS, TransportHTTPS2, TransportHTTPS3:
		if scheme != "https" {
			return fmt.Errorf("transport %s requires an https:// server_addr", m)
		}
	default:
		return fmt.Errorf("unsupported transport %q", m)
	}

	return nil
}
