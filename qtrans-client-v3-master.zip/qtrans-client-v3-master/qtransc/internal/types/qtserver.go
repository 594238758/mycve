package types

type DownloadUser string

const (
	DownloadUserAnonymous DownloadUser = "anonymous"
	DownloadUserSelf      DownloadUser = "self"
)

const (
	DownloadBrowseEntryFile      = "file"
	DownloadBrowseEntryDirectory = "directory"
)

type DownloadBrowseEntry struct {
	Name         string  `json:"name"`
	Path         string  `json:"path"`
	EntryType    string  `json:"type"`
	Status       string  `json:"status"`
	TargetType   *string `json:"target_type,omitempty"`
	SpecialType  string  `json:"special_type,omitempty"`
	ReasonCode   string  `json:"reason_code,omitempty"`
	Size         int64   `json:"size,omitempty"`
	LastModified string  `json:"last_modified,omitempty"`
}

func (e DownloadBrowseEntry) ObjectKey() string { return e.Path }

func (e DownloadBrowseEntry) TransferType() string {
	if e.EntryType == "symlink" && e.Status == "normal" && e.TargetType != nil {
		return *e.TargetType
	}
	return e.EntryType
}

type DownloadBrowseResponse struct {
	Code       int                   `json:"code"`
	Path       string                `json:"path"`
	ObjectPath string                `json:"object_path,omitempty"`
	Truncated  bool                  `json:"truncated"`
	Entries    []DownloadBrowseEntry `json:"entries"`
}

type DownloadObjectRequest struct {
	ObjectKey string `json:"object_key"`
}

type DownloadGrantRequest struct {
	TaskID string                  `json:"taskid"`
	Items  []DownloadObjectRequest `json:"items"`
}

type DownloadGrantFileResponse struct {
	ObjectKey string `json:"object_key"`
	Size      int64  `json:"size"`
	Grant     string `json:"grant"`
}

type DownloadGrantResponse struct {
	Code    int                         `json:"code"`
	Message string                      `json:"message"`
	TaskID  string                      `json:"taskid"`
	Files   []DownloadGrantFileResponse `json:"files"`
}

type DownloadSmallRequest struct {
	TaskID string                  `json:"taskid"`
	Files  []DownloadObjectRequest `json:"files"`
}

type DownloadSmallSession struct {
	Version            int    `json:"version"`
	TaskID             string `json:"taskid"`
	UserID             string `json:"user_id"`
	FileCount          int    `json:"file_count"`
	TotalUnpackedBytes int64  `json:"total_unpacked_bytes"`
	HashAlgorithm      string `json:"hash_algorithm"`
}

type DownloadSmallManifestEntry struct {
	ObjectKey   string `json:"object_key"`
	ArchivePath string `json:"archive_path"`
	Size        int64  `json:"size"`
	Hash        string `json:"hash"`
}

type DownloadSmallManifest struct {
	Version       int                          `json:"version"`
	TaskID        string                       `json:"taskid"`
	UserID        string                       `json:"user_id"`
	HashAlgorithm string                       `json:"hash_algorithm"`
	Files         []DownloadSmallManifestEntry `json:"files"`
}

type DownloadSmallV2ManifestEntry struct {
	Index       int    `json:"index"`
	ObjectKey   string `json:"object_key"`
	ArchivePath string `json:"archive_path"`
	Size        int64  `json:"size"`
}

type DownloadSmallV2Manifest struct {
	Version            int                            `json:"version"`
	TaskID             string                         `json:"taskid"`
	FileCount          int                            `json:"file_count"`
	TotalUnpackedBytes int64                          `json:"total_unpacked_bytes"`
	HashAlgorithm      string                         `json:"hash_algorithm"`
	Files              []DownloadSmallV2ManifestEntry `json:"files"`
}

type DownloadSmallV2ChecksumEntry struct {
	Index       int    `json:"index"`
	ObjectKey   string `json:"object_key"`
	ArchivePath string `json:"archive_path"`
	Size        int64  `json:"size"`
	Hash        string `json:"hash"`
}

type DownloadSmallV2Checksums struct {
	Version            int                            `json:"version"`
	TaskID             string                         `json:"taskid"`
	FileCount          int                            `json:"file_count"`
	TotalUnpackedBytes int64                          `json:"total_unpacked_bytes"`
	HashAlgorithm      string                         `json:"hash_algorithm"`
	Files              []DownloadSmallV2ChecksumEntry `json:"files"`
}

// DownloadVerifyRequest is the request body for POST /d/verify.
type DownloadVerifyRequest struct {
	TaskID    string `json:"taskid"`
	ObjectKey string `json:"object_key"`
	FileHash  string `json:"file_hash"`
}

// DownloadVerifyResponse is the response body from POST /d/verify.
type DownloadVerifyResponse struct {
	Code           int    `json:"code"`
	Message        string `json:"message"`
	TaskID         string `json:"taskid"`
	ObjectKey      string `json:"object_key"`
	ExpectedHash   string `json:"expected_hash"`
	CalculatedHash string `json:"calculated_hash"`
	Match          bool   `json:"match"`
	ReasonCode     string `json:"reason_code,omitempty"`
}
