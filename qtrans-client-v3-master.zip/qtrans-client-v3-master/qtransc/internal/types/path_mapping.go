package types

import (
	"fmt"
	"net"
	"path/filepath"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf8"
)

// PathMapping describes a source file/directory and a destination directory.
type PathMapping struct {
	Src string `json:"src"`
	Dst string `json:"dst"`
}

func (r *TaskCreateRequest) validatePathMappings() error {
	if r.Mode != "upload" && r.Mode != "download" {
		return fmt.Errorf("invalid mode %q", r.Mode)
	}
	if len(r.PathMappings) == 0 {
		return fmt.Errorf("pathMappings must not be empty")
	}
	if len(r.FileList) != 0 || r.SourceDir != "" || r.TargetDir != "" || len(r.DirPaths) != 0 {
		return fmt.Errorf("cannot mix pathMappings with legacy paths")
	}
	mode, err := ParseTransportMode(r.Transport)
	if err != nil {
		return err
	}
	r.Transport = mode.String()
	addr := strings.TrimSpace(r.ServerAddr)
	if strings.ContainsAny(addr, "/\\?#@") || strings.IndexFunc(addr, unicode.IsSpace) >= 0 {
		return fmt.Errorf("serverAddr must be host[:port]")
	}
	if !strings.Contains(addr, ":") {
		addr = net.JoinHostPort(addr, DefaultServerPort)
	} else if strings.HasPrefix(addr, "[") && strings.HasSuffix(addr, "]") {
		// Bracketed IPv6 without a port; an explicit trailing ':' remains invalid.
		addr += ":" + DefaultServerPort
	}
	host, port, err := net.SplitHostPort(addr)
	if err != nil || host == "" {
		return fmt.Errorf("serverAddr must be host[:port]")
	}
	if strings.HasPrefix(addr, "[") && !strings.Contains(host, ":") {
		return fmt.Errorf("brackets require an IPv6 address")
	}
	for _, c := range port {
		if c < '0' || c > '9' {
			return fmt.Errorf("invalid port")
		}
	}
	n, err := strconv.Atoi(port)
	if err != nil || n < 1 || n > 65535 {
		return fmt.Errorf("invalid port")
	}
	if net.ParseIP(host) == nil {
		if strings.ContainsAny(host, ":%[]") || len(host) > 253 {
			return fmt.Errorf("invalid host")
		}
		for _, label := range strings.Split(strings.TrimSuffix(host, "."), ".") {
			if label == "" || len(label) > 63 || label[0] == '-' || label[len(label)-1] == '-' {
				return fmt.Errorf("invalid host")
			}
			for _, c := range label {
				if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-') {
					return fmt.Errorf("invalid host")
				}
			}
		}
	}
	for i := range r.PathMappings {
		m := &r.PathMappings[i]
		local, remote := &m.Src, &m.Dst
		if r.Mode == "download" {
			local, remote = &m.Dst, &m.Src
		}
		if !utf8.ValidString(*local) || strings.ContainsRune(*local, 0) || !filepath.IsAbs(*local) {
			return fmt.Errorf("pathMappings[%d]: local path must be absolute", i)
		}
		if strings.ContainsAny(*local, "*?[]") || strings.ContainsAny(*remote, "*?[]") {
			return fmt.Errorf("pathMappings[%d]: wildcards are not supported", i)
		}
		*local = filepath.Clean(*local)
		if !strings.HasPrefix(*remote, "/") {
			return fmt.Errorf("pathMappings[%d]: remote path must be absolute", i)
		}
		*remote, err = normalizeLogicalAbsolute(*remote, r.Mode == "upload")
		if err != nil {
			return fmt.Errorf("pathMappings[%d]: %w", i, err)
		}
		if r.Mode == "upload" && filepath.Dir(*local) == *local {
			return fmt.Errorf("source root is not allowed")
		}
	}
	// Only the adapter constructs the URL consumed by the existing network layer.
	r.ServerAddr = mode.ServerScheme() + "://" + addr
	return nil
}
