package types

import (
	"regexp"
	"strings"
)

var canonicalUUIDPattern = regexp.MustCompile(`(?i)^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`)

func LooksLikeUUID(raw string) bool {
	return canonicalUUIDPattern.MatchString(strings.TrimSpace(raw))
}
