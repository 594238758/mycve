package types

type UploadFileStatus string

type UploadChunkState string

const (
	UploadHashAlgorithmLayeredXXH3_128 = "layered_xxh3_128_v1"
	UploadAbortModePause               = "pause"
	UploadAbortModeCancel              = "cancel"

	UploadChunkStatePartial  UploadChunkState = "partial"
	UploadChunkStateComplete UploadChunkState = "complete"

	UploadFileStatusExists     UploadFileStatus = "exists"
	UploadFileStatusCompleted  UploadFileStatus = "completed"
	UploadFileStatusActive     UploadFileStatus = "active"
	UploadFileStatusResumable  UploadFileStatus = "resumable"
	UploadFileStatusCompleting UploadFileStatus = "completing"
	UploadFileStatusCommitted  UploadFileStatus = "committed"
	UploadFileStatusCancelled  UploadFileStatus = "cancelled"
)

type CanonicalUploadInitRequest struct {
	ObjectKey     string `json:"object_key"`
	FileSize      int64  `json:"file_size"`
	FileHash      string `json:"file_hash"`
	HashAlgorithm string `json:"hash_algorithm"`
	Overwrite     bool   `json:"overwrite,omitempty"`
}

type CanonicalUploadChunk struct {
	State  string `json:"state"`
	Stored int64  `json:"stored"`
	Hash   string `json:"hash,omitempty"`
}

type CanonicalUploadResponse struct {
	Code               int                             `json:"code"`
	Status             string                          `json:"status"`
	SessionID          string                          `json:"session_id"`
	ObjectKey          string                          `json:"object_key"`
	FileSize           int64                           `json:"file_size"`
	ChunkSize          int64                           `json:"chunk_size"`
	ChunkCount         int                             `json:"chunk_count"`
	Chunks             map[string]CanonicalUploadChunk `json:"chunks,omitempty"`
	TargetSize         int64                           `json:"target_size,omitempty"`
	TargetHash         string                          `json:"target_hash,omitempty"`
	FileHash           string                          `json:"file_hash,omitempty"`
	HashAlgorithm      string                          `json:"hash_algorithm,omitempty"`
	ChunkHashAlgorithm string                          `json:"chunk_hash_algorithm,omitempty"`
	FileHashAlgorithm  string                          `json:"file_hash_algorithm,omitempty"`
}

type UploadChunkStateInfo struct {
	State       UploadChunkState `json:"state"`
	StoredBytes int64            `json:"stored_bytes,omitempty"`
	ChunkBytes  int64            `json:"chunk_bytes,omitempty"`
	ChunkHash   string           `json:"chunk_hash,omitempty"`
}

type UploadInitRequest struct {
	TaskID         string `json:"taskid"`
	ObjectKey      string `json:"object_key"`
	FileSize       int64  `json:"file_size"`
	FileHash       string `json:"file_hash"`
	HashAlgorithm  string `json:"hash_algorithm,omitempty"`
	ChunkSize      int64  `json:"chunk_size"`
	ConflictPolicy string `json:"conflict_policy,omitempty"`
}

type UploadInitResponse struct {
	Code           int                             `json:"code"`
	Message        string                          `json:"message"`
	TaskID         string                          `json:"taskid"`
	UserID         string                          `json:"user_id"`
	SessionID      string                          `json:"session_id,omitempty"`
	Status         UploadFileStatus                `json:"status,omitempty"`
	Authorized     bool                            `json:"authorized,omitempty"`
	Ready          bool                            `json:"ready,omitempty"`
	Exists         bool                            `json:"exists,omitempty"`
	ObjectKey      string                          `json:"object_key"`
	ObjectKeyHash  string                          `json:"object_key_hash,omitempty"`
	FileSize       int64                           `json:"file_size,omitempty"`
	FileHash       string                          `json:"file_hash,omitempty"`
	HashAlgorithm  string                          `json:"hash_algorithm,omitempty"`
	ChunkSize      int64                           `json:"chunk_size,omitempty"`
	ChunkCount     int                             `json:"chunk_count,omitempty"`
	UploadedChunks []int                           `json:"uploaded_chunks,omitempty"`
	ChunkHashes    map[string]string               `json:"chunk_hashes,omitempty"`
	ChunkStates    map[string]UploadChunkStateInfo `json:"chunk_states,omitempty"`
	LeaseUntil     string                          `json:"lease_until,omitempty"`
	ReasonCode     string                          `json:"reason_code,omitempty"`
}

type UploadCompleteRequest struct {
	TaskID    string `json:"taskid"`
	SessionID string `json:"session_id"`
	ObjectKey string `json:"object_key"`
	FileHash  string `json:"file_hash"`
}

type UploadCompleteResponse struct {
	Code           int              `json:"code"`
	Message        string           `json:"message"`
	TaskID         string           `json:"taskid"`
	SessionID      string           `json:"session_id,omitempty"`
	ObjectKey      string           `json:"object_key"`
	Status         UploadFileStatus `json:"status,omitempty"`
	ExpectedHash   string           `json:"expected_hash,omitempty"`
	CalculatedHash string           `json:"calculated_hash,omitempty"`
	Match          bool             `json:"match"`
	ReasonCode     string           `json:"reason_code,omitempty"`
}

type UploadAbortRequest struct {
	TaskID    string `json:"taskid"`
	SessionID string `json:"session_id"`
	ObjectKey string `json:"object_key"`
	AbortMode string `json:"abort_mode"`
}

type UploadAbortResponse struct {
	Code       int              `json:"code"`
	Message    string           `json:"message"`
	TaskID     string           `json:"taskid"`
	SessionID  string           `json:"session_id,omitempty"`
	ObjectKey  string           `json:"object_key"`
	Status     UploadFileStatus `json:"status,omitempty"`
	ReasonCode string           `json:"reason_code,omitempty"`
}

type UploadChunkResponse struct {
	Code           int              `json:"code"`
	Message        string           `json:"message"`
	TaskID         string           `json:"taskid"`
	SessionID      string           `json:"session_id,omitempty"`
	ObjectKey      string           `json:"object_key"`
	Status         UploadFileStatus `json:"status,omitempty"`
	ChunkIndex     int              `json:"chunk_index,omitempty"`
	StoredBytes    int64            `json:"stored_bytes,omitempty"`
	ChunkBytes     int64            `json:"chunk_bytes,omitempty"`
	State          UploadChunkState `json:"state,omitempty"`
	ChunkHash      string           `json:"chunk_hash,omitempty"`
	UploadedChunks []int            `json:"uploaded_chunks,omitempty"`
	ReasonCode     string           `json:"reason_code,omitempty"`
}

type UploadBrowseEntry struct {
	Name         string `json:"name"`
	ObjectKey    string `json:"object_key"`
	EntryType    string `json:"entry_type"`
	Size         int64  `json:"size,omitempty"`
	LastModified string `json:"last_modified,omitempty"`
}

type UploadBrowseResponse struct {
	Code       int                 `json:"code"`
	Message    string              `json:"message"`
	UserID     string              `json:"user_id"`
	Path       string              `json:"path"`
	ObjectPath string              `json:"object_path,omitempty"`
	Entries    []UploadBrowseEntry `json:"entries"`
}

type UploadMkdirRequest struct {
	Path string `json:"path"`
}

type UploadMkdirResponse struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	UserID  string `json:"user_id"`
	Path    string `json:"path"`
}

type UploadMoveRequest struct {
	SourcePath      string `json:"source_path"`
	DestinationPath string `json:"destination_path"`
}

type UploadMoveResponse struct {
	Code            int    `json:"code"`
	Message         string `json:"message"`
	UserID          string `json:"user_id"`
	SourcePath      string `json:"source_path"`
	DestinationPath string `json:"destination_path"`
}

type UploadDeleteRequest struct {
	Path string `json:"path"`
}

type UploadDeleteResponse struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	UserID  string `json:"user_id"`
	Path    string `json:"path"`
}
