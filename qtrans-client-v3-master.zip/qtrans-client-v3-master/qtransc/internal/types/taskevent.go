package types

import (
	"encoding/json"
	"strings"
	"time"
)

const (
	EventTypeHeartbeat     = "heartbeat"      // 心跳事件
	EventTypeTaskStatus    = "task_status"    // 任务生命周期事件
	EventTypeFileStatus    = "file_status"    // 文件生命周期事件
	EventTypeChunkStatus   = "chunk_status"   // 分片生命周期事件
	EventTypeTaskProgress  = "task_progress"  // 任务进度快照事件
	EventTypeFileProgress  = "file_progress"  // 文件进度快照事件
	EventTypeChunkProgress = "chunk_progress" // 分片进度快照事件
)

const (
	// TaskEventStatusDeleted is an internal lifecycle marker. The serve wire
	// converter exposes it as qtrans.task.delete rather than as a task status.
	TaskEventStatusDeleted = "deleted"
)

const (
	FileEventStatusStarted   = "started"
	FileEventStatusCompleted = "completed"
	FileEventStatusFailed    = "failed"
	FileEventStatusRetrying  = "retrying"
)

const (
	ChunkEventStatusStarted   = "started"
	ChunkEventStatusRetried   = "retried"
	ChunkEventStatusCompleted = "completed"
)

type TaskEvent struct {
	EventType string `json:"event_type"`
	Data      any    `json:"data"`
	Cause     error  `json:"-"`
}

// EventCause retains a structured internal reason without changing the event
// bus JSON shape or coupling shared types to the CLI error package.
type EventCause struct {
	ReasonCode string
	Message    string
}

func (cause *EventCause) Error() string {
	if cause == nil {
		return ""
	}
	return cause.Message
}

type HeartbeatEventData struct {
	Timestamp string `json:"timestamp"`
}

type TaskStatusEventData struct {
	TaskID     string  `json:"task_id"`
	Status     string  `json:"status"`
	Error      *string `json:"error"`
	ReasonCode string  `json:"reason_code,omitempty"`
}

type FileStatusEventData struct {
	TaskID  string `json:"task_id"`
	FileKey string `json:"file_key"`
	Status  string `json:"status"`
}

type ChunkStatusEventData struct {
	TaskID     string `json:"task_id"`
	FileKey    string `json:"file_key"`
	ChunkIndex int    `json:"chunk_index"`
	Status     string `json:"status"`
}

type TaskProgressEventData struct {
	TaskID     string `json:"task_id"`
	Total      int64  `json:"total"`
	Transfered int64  `json:"transfered"`
	Rate       int64  `json:"rate"`
}

type FileProgressEventData struct {
	TaskID     string `json:"task_id"`
	FileKey    string `json:"file_key"`
	Total      int64  `json:"total"`
	Transfered int64  `json:"transfered"`
	Rate       int64  `json:"rate"`
}

type ChunkProgressEventData struct {
	TaskID     string `json:"task_id"`
	FileKey    string `json:"file_key"`
	ChunkIndex int    `json:"chunk_index"`
	Total      int64  `json:"total"`
	Transfered int64  `json:"transfered"`
	Rate       int64  `json:"rate"`
}

func (e TaskEvent) Bytes() []byte {
	data, _ := json.Marshal(e)
	return data
}

func NewHeartbeatEvent(now time.Time) TaskEvent {
	return TaskEvent{
		EventType: EventTypeHeartbeat,
		Data: HeartbeatEventData{
			Timestamp: now.UTC().Format(time.RFC3339),
		},
	}
}

func NewTaskStatusEvent(taskID, status, errorText string) TaskEvent {
	return NewTaskStatusEventWithReason(taskID, status, errorText, "")
}

func NewTaskStatusEventWithReason(taskID, status, errorText, reasonCode string) TaskEvent {
	var cause error
	if strings.TrimSpace(errorText) != "" || strings.TrimSpace(reasonCode) != "" {
		cause = &EventCause{ReasonCode: reasonCode, Message: errorText}
	}
	return NewTaskStatusEventWithCause(taskID, status, errorText, reasonCode, cause)
}

func NewTaskStatusEventWithCause(taskID, status, errorText, reasonCode string, cause error) TaskEvent {
	return TaskEvent{
		EventType: EventTypeTaskStatus,
		Cause:     cause,
		Data: TaskStatusEventData{
			TaskID:     taskID,
			Status:     status,
			Error:      optionalString(errorText),
			ReasonCode: strings.TrimSpace(reasonCode),
		},
	}
}

func NewFileStatusEvent(taskID, fileKey, status string) TaskEvent {
	return NewFileStatusEventWithCause(taskID, fileKey, status, nil)
}

func NewFileStatusEventWithCause(taskID, fileKey, status string, cause error) TaskEvent {
	return TaskEvent{
		EventType: EventTypeFileStatus,
		Cause:     cause,
		Data: FileStatusEventData{
			TaskID:  taskID,
			FileKey: fileKey,
			Status:  status,
		},
	}
}

func NewChunkStatusEvent(taskID, fileKey string, chunkIndex int, status string) TaskEvent {
	return TaskEvent{
		EventType: EventTypeChunkStatus,
		Data: ChunkStatusEventData{
			TaskID:     taskID,
			FileKey:    fileKey,
			ChunkIndex: chunkIndex,
			Status:     status,
		},
	}
}

func NewTaskProgressEvent(taskID string, total, transfered, rate int64) TaskEvent {
	return TaskEvent{
		EventType: EventTypeTaskProgress,
		Data: TaskProgressEventData{
			TaskID:     taskID,
			Total:      total,
			Transfered: transfered,
			Rate:       rate,
		},
	}
}

func NewFileProgressEvent(taskID, fileKey string, total, transfered, rate int64) TaskEvent {
	return TaskEvent{
		EventType: EventTypeFileProgress,
		Data: FileProgressEventData{
			TaskID:     taskID,
			FileKey:    fileKey,
			Total:      total,
			Transfered: transfered,
			Rate:       rate,
		},
	}
}

func NewChunkProgressEvent(taskID, fileKey string, chunkIndex int, total, transfered, rate int64) TaskEvent {
	return TaskEvent{
		EventType: EventTypeChunkProgress,
		Data: ChunkProgressEventData{
			TaskID:     taskID,
			FileKey:    fileKey,
			ChunkIndex: chunkIndex,
			Total:      total,
			Transfered: transfered,
			Rate:       rate,
		},
	}
}

func TaskStatusToEventStatus(status TaskStatus) string {
	return string(status)
}

func optionalString(value string) *string {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return nil
	}
	return &trimmed
}
