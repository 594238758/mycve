package types

import "time"

// GeneralResponse represents a generic API response
type GeneralResponse struct {
	Code       int    `json:"code"`
	ReasonCode string `json:"reason_code,omitempty"`
	Message    string `json:"message"`
	Data       any    `json:"data,omitempty"`
}

// HealthData represents the health check response
type HealthResponse struct {
	// Static / semi-static fields
	Me      string `json:"me,omitempty"`
	Pid     int    `json:"pid,omitempty"`
	Version string `json:"version,omitempty"`
}

// ChunkInfoDetail is the API view for chunk details.
type ChunkInfoDetail struct {
	Index       int   `json:"index"`
	StartOffset int64 `json:"start_offset"`
	EndOffset   int64 `json:"end_offset"`
	Transferred int64 `json:"transferred_bytes"`
	ChunkSize   int64 `json:"size"`
	Completed   bool  `json:"completed,omitempty"`
}

// FileInfoDetail is the API view for file details.
type FileInfoDetail struct {
	Src             string             `json:"-"`
	Dst             string             `json:"-"`
	Cause           error              `json:"-"`
	LocalPath       string             `json:"local_rel_path,omitempty"`
	RemotePath      string             `json:"remote_url,omitempty"`
	Authorized      bool               `json:"authorized,omitempty"`
	Size            int64              `json:"size,omitempty"`
	Transferred     int64              `json:"transferred_bytes,omitempty"`
	Rate            int64              `json:"transfer_rate,omitempty"`
	OverallChecksum string             `json:"overall_checksum,omitempty"`
	Received        bool               `json:"received,omitempty"`
	Verified        bool               `json:"verified,omitempty"`
	Chunks          []*ChunkInfoDetail `json:"chunks,omitempty"`
}

// 文件摘要： 不带分片信息
type FileInfoSummary struct {
	Src             string `json:"-"`
	Dst             string `json:"-"`
	Cause           error  `json:"-"`
	LocalPath       string `json:"local_rel_path,omitempty"`
	RemotePath      string `json:"remote_url,omitempty"`
	Authorized      bool   `json:"authorized,omitempty"`
	Size            int64  `json:"size,omitempty"`
	Transferred     int64  `json:"transferred_bytes,omitempty"`
	Rate            int64  `json:"transfer_rate,omitempty"`
	OverallChecksum string `json:"overall_checksum,omitempty"`
	Received        bool   `json:"received,omitempty"`
	Verified        bool   `json:"verified,omitempty"`
}

// DownloadTaskSummary is the API view for listing tasks.
type DownloadTaskSummary struct {
	Cause            error              `json:"-"`
	TaskID           string             `json:"task_id,omitempty"`
	TaskName         string             `json:"task_name,omitempty"`
	Mode             string             `json:"mode,omitempty"`
	Status           TaskStatus         `json:"status,omitempty"`
	Err              string             `json:"error,omitempty"`
	ReasonCode       string             `json:"reason_code,omitempty"`
	Started          bool               `json:"started,omitempty"`
	Transferred      int64              `json:"transferred_bytes,omitempty"`
	TotalSize        int64              `json:"total_size,omitempty"`
	Rate             int64              `json:"transfer_rate,omitempty"`
	TransferingFiles []*FileInfoSummary `json:"transfering_files,omitempty"`
	// CreatedAt        time.Time          `json:"created_at"`
	// UpdatedAt        time.Time          `json:"updated_at"`
	// StartedAt        time.Time          `json:"started_at,omitempty"`
	// FinishedAt       time.Time          `json:"finished_at,omitempty"`
}

// DownloadTaskDetail is the API view for task details.
type DownloadTaskDetail struct {
	PathMappings []PathMapping `json:"-"`
	// Transport, Connections, and Streams are exposed only by the serve DTO.
	Transport         TransportMode     `json:"-"`
	Connections       int               `json:"-"`
	Streams           int               `json:"-"`
	FileConcurrency   int               `json:"file_concurrency,omitempty"`
	Cause             error             `json:"-"`
	TaskID            string            `json:"task_id,omitempty"`
	TaskName          string            `json:"task_name,omitempty"`
	Mode              string            `json:"mode,omitempty"`
	ServerAddr        string            `json:"server_addr,omitempty"`
	TargetDir         string            `json:"target_dir,omitempty"`
	Status            TaskStatus        `json:"status,omitempty"`
	Err               string            `json:"error,omitempty"`
	ReasonCode        string            `json:"reason_code,omitempty"`
	Started           bool              `json:"started,omitempty"`
	Files             []*FileInfoDetail `json:"authorized_files,omitempty"`
	UnauthorizedFiles []*FileInfoDetail `json:"unauthorized_files,omitempty"`
	Transferred       int64             `json:"transferred_bytes,omitempty"`
	NetworkReceived   int64             `json:"network_received_bytes,omitempty"`
	TotalSize         int64             `json:"total_size,omitempty"`
	Rate              int64             `json:"transfer_rate,omitempty"`
	CreatedAt         time.Time         `json:"created_at"`
	UpdatedAt         time.Time         `json:"updated_at"`
	StartedAt         time.Time         `json:"started_at,omitempty"`
	FinishedAt        time.Time         `json:"finished_at,omitempty"`
}

type UploadFileInfoDetail struct {
	Src          string `json:"-"`
	Dst          string `json:"-"`
	Cause        error  `json:"-"`
	LocalPath    string `json:"local_rel_path,omitempty"`
	ObjectKey    string `json:"object_key,omitempty"`
	Size         int64  `json:"size,omitempty"`
	FileHash     string `json:"file_hash,omitempty"`
	UploadURL    string `json:"upload_url,omitempty"`
	Status       string `json:"status,omitempty"`
	ChunkSize    int64  `json:"chunk_size,omitempty"`
	ChunkCount   int    `json:"chunk_count,omitempty"`
	Ready        bool   `json:"ready,omitempty"`
	Exists       bool   `json:"exists,omitempty"`
	Transferred  int64  `json:"transferred_bytes,omitempty"`
	Rate         int64  `json:"transfer_rate,omitempty"`
	Uploaded     bool   `json:"uploaded,omitempty"`
	Verified     bool   `json:"verified,omitempty"`
	ReasonCode   string `json:"reason_code,omitempty"`
	Message      string `json:"message,omitempty"`
	LastModified string `json:"last_modified,omitempty"`
}

type UploadFileInfoSummary struct {
	Src         string `json:"-"`
	Dst         string `json:"-"`
	Cause       error  `json:"-"`
	LocalPath   string `json:"local_rel_path,omitempty"`
	ObjectKey   string `json:"object_key,omitempty"`
	Size        int64  `json:"size,omitempty"`
	Status      string `json:"status,omitempty"`
	Transferred int64  `json:"transferred_bytes,omitempty"`
	Rate        int64  `json:"transfer_rate,omitempty"`
	Uploaded    bool   `json:"uploaded,omitempty"`
	Verified    bool   `json:"verified,omitempty"`
	ReasonCode  string `json:"reason_code,omitempty"`
	Message     string `json:"message,omitempty"`
}

type UploadTaskSummary struct {
	Cause            error                    `json:"-"`
	TaskID           string                   `json:"task_id,omitempty"`
	TaskName         string                   `json:"task_name,omitempty"`
	Mode             string                   `json:"mode,omitempty"`
	Status           TaskStatus               `json:"status,omitempty"`
	Err              string                   `json:"error,omitempty"`
	ReasonCode       string                   `json:"reason_code,omitempty"`
	Started          bool                     `json:"started,omitempty"`
	Transferred      int64                    `json:"transferred_bytes,omitempty"`
	TotalSize        int64                    `json:"total_size,omitempty"`
	Rate             int64                    `json:"transfer_rate,omitempty"`
	TransferingFiles []*UploadFileInfoSummary `json:"transfering_files,omitempty"`
}

type UploadTaskDetail struct {
	PathMappings []PathMapping `json:"-"`
	// Transport, Connections, and Streams are exposed only by the serve DTO.
	Transport       TransportMode           `json:"-"`
	Connections     int                     `json:"-"`
	Streams         int                     `json:"-"`
	FileConcurrency int                     `json:"file_concurrency,omitempty"`
	Cause           error                   `json:"-"`
	TaskID          string                  `json:"task_id,omitempty"`
	TaskName        string                  `json:"task_name,omitempty"`
	Mode            string                  `json:"mode,omitempty"`
	ServerAddr      string                  `json:"server_addr,omitempty"`
	SourceDir       string                  `json:"source_dir,omitempty"`
	ServerTaskID    string                  `json:"server_task_id,omitempty"`
	Status          TaskStatus              `json:"status,omitempty"`
	Err             string                  `json:"error,omitempty"`
	ReasonCode      string                  `json:"reason_code,omitempty"`
	Started         bool                    `json:"started,omitempty"`
	Files           []*UploadFileInfoDetail `json:"ready_files,omitempty"`
	ConflictFiles   []*UploadFileInfoDetail `json:"conflict_files,omitempty"`
	RejectedFiles   []*UploadFileInfoDetail `json:"rejected_files,omitempty"`
	Transferred     int64                   `json:"transferred_bytes,omitempty"`
	NetworkSent     int64                   `json:"network_sent_bytes,omitempty"`
	TotalSize       int64                   `json:"total_size,omitempty"`
	Rate            int64                   `json:"transfer_rate,omitempty"`
	CreatedAt       time.Time               `json:"created_at"`
	UpdatedAt       time.Time               `json:"updated_at"`
	StartedAt       time.Time               `json:"started_at,omitempty"`
	FinishedAt      time.Time               `json:"finished_at,omitempty"`
}
