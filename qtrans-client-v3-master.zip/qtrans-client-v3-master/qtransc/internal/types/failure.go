package types

import (
	"errors"
	"sync"
)

// FileFailure retains only the final cause; transient attempt errors stay private.
// Its cause is copied into internal views and events, never serialized directly.
type FileFailure struct {
	mu    sync.Mutex
	cause error
}

func (f *FileFailure) Record(err error) (error, bool) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.cause == nil {
		if err == nil {
			err = errors.New("file execution failed without a cause")
		}
		f.cause = err
		return f.cause, true
	}
	return f.cause, false
}
func (f *FileFailure) Cause() error {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.cause
}
func (f *FileFailure) Clear() {
	f.mu.Lock()
	f.cause = nil
	f.mu.Unlock()
}
