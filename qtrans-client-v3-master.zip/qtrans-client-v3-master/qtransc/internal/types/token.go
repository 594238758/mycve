package types

import (
	"fmt"
	"strings"
)

// TokenConfigRequest updates the in-memory bearer token used by the server mode.
type TokenConfigRequest struct {
	BearerToken string `json:"bearer_token"`
}

func (r *TokenConfigRequest) Validate() error {
	if r == nil {
		return fmt.Errorf("request is required")
	}

	r.BearerToken = strings.TrimSpace(r.BearerToken)
	if r.BearerToken == "" {
		return fmt.Errorf("bearer_token is required")
	}
	return nil
}
