package types

import (
	"encoding/json"
	"fmt"
	"path/filepath"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/transferlimits"
	"strings"
	"unicode/utf8"
)

type TaskFileSpec struct {
	LocalRelPath string `json:"local_rel_path" binding:"required"`
	RemoteURL    string `json:"remote_url,omitempty"`
	ObjectKey    string `json:"object_key,omitempty"`
}

// TaskCreateRequest is the common input to task management and execution.
// HTTP v1/v2 adapt into it; its JSON representation also serves legacy callers.
// A non-nil PathMappings selects mapping input, exclusively of the legacy path
// fields. UploadTask and DownloadTask support both input forms.
type TaskCreateRequest struct {
	PathMappings   []PathMapping  `json:"-"`
	BearerToken    string         `json:"bearer_token,omitempty"`
	TaskID         string         `json:"task_id,omitempty"`
	TaskPID        string         `json:"taskpid,omitempty"`
	EnterpriseID   string         `json:"enterprise_id,omitempty"`
	CallerVersion  string         `json:"caller_version,omitempty"`
	ServerTaskID   string         `json:"server_task_id,omitempty"`
	TaskName       string         `json:"task_name,omitempty" binding:"required"`
	Mode           string         `json:"mode" binding:"required,oneof=upload download"`
	Transport      string         `json:"transport,omitempty"`
	ServerAddr     string         `json:"server_addr" binding:"required"`
	FileList       []TaskFileSpec `json:"file_list" binding:"required,min=1"`
	TargetDir      string         `json:"target_dir,omitempty"` // download only
	SourceDir      string         `json:"source_dir,omitempty"` // upload only
	DirPaths       []string       `json:"dir_paths,omitempty"`  // 空目录路径列表（upload: 服务端创建，download: 本地创建）
	UseAuthManager bool           `json:"-"`
	UseExactToken  bool           `json:"-"`
	DownloadUser   string         `json:"-"`
	StateDBPath    string         `json:"-"`
	LimitRate      int64          `json:"-"`
	AutoRetry      bool           `json:"-"`
}

func (r *TaskCreateRequest) UnmarshalJSON(data []byte) error {
	if !utf8.Valid(data) {
		return fmt.Errorf("request body must be valid UTF-8")
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(data, &fields); err != nil {
		return err
	}
	for _, field := range []string{"taskpid", "enterprise_id", "caller_version"} {
		if raw, exists := fields[field]; exists && strings.TrimSpace(string(raw)) == "null" {
			return fmt.Errorf("%s must be a string", field)
		}
	}
	type requestAlias TaskCreateRequest
	var decoded requestAlias
	if err := json.Unmarshal(data, &decoded); err != nil {
		return err
	}
	*r = TaskCreateRequest(decoded)
	return nil
}

func (r *TaskCreateRequest) Validate() error {
	r.TaskID = strings.TrimSpace(r.TaskID)
	r.TaskName = strings.TrimSpace(r.TaskName)
	r.ServerAddr = strings.TrimSpace(r.ServerAddr)
	if r.PathMappings == nil {
		r.ServerAddr = strings.TrimRight(r.ServerAddr, "/")
	}
	r.ServerTaskID = strings.TrimSpace(r.ServerTaskID)
	r.TaskPID = strings.Trim(r.TaskPID, " \t")
	if err := validateCorrelationLabel(r.TaskPID); err != nil {
		return fmt.Errorf("taskpid: %w", err)
	}
	r.EnterpriseID = strings.Trim(r.EnterpriseID, " \t")
	if err := validateCorrelationLabel(r.EnterpriseID); err != nil {
		return fmt.Errorf("enterprise_id: %w", err)
	}
	r.CallerVersion = strings.Trim(r.CallerVersion, " \t")
	if err := validateCallerVersion(r.CallerVersion); err != nil {
		return fmt.Errorf("caller_version: %w", err)
	}

	if r.TaskName == "" {
		return fmt.Errorf("task_name is required")
	}
	if r.ServerAddr == "" {
		return fmt.Errorf("server_addr is required")
	}
	if err := transferlimits.ValidateTaskFileCount(len(r.FileList)); err != nil {
		return err
	}

	if r.PathMappings != nil {
		return r.validatePathMappings()
	}

	transportMode, err := ParseTransportMode(r.Transport)
	if err != nil {
		return fmt.Errorf("transport: %w", err)
	}
	r.Transport = transportMode.String()
	if err := transportMode.ValidateServerURL(r.ServerAddr); err != nil {
		return fmt.Errorf("server_addr: %w", err)
	}
	normalizedServerAddr, err := qtserverurl.NormalizeServerOrigin(r.ServerAddr)
	if err != nil {
		return fmt.Errorf("server_addr: %w", err)
	}
	r.ServerAddr = normalizedServerAddr

	switch r.Mode {
	case "download":
		if len(r.FileList) == 0 {
			return fmt.Errorf("file_list must contain at least one file")
		}
		if r.TargetDir == "" {
			return fmt.Errorf("target_dir is required for download tasks")
		}
		for i := range r.FileList {
			if err := validateLocalRelPath(r.FileList[i].LocalRelPath); err != nil {
				return fmt.Errorf("file_list[%d].local_rel_path: %w", i, err)
			}
			if r.FileList[i].RemoteURL == "" {
				return fmt.Errorf("file_list[%d].remote_url is required for download tasks", i)
			}
			normalized, err := normalizeLogicalAbsolute(r.FileList[i].RemoteURL, false)
			if err != nil {
				return fmt.Errorf("file_list[%d].remote_url: %w", i, err)
			}
			r.FileList[i].RemoteURL = normalized
		}
		switch strings.TrimSpace(r.DownloadUser) {
		case "", "anonymous", "self":
		default:
			return fmt.Errorf("download_user must be anonymous or self")
		}
	case "upload":
		if strings.TrimSpace(r.BearerToken) == "" && !r.UseAuthManager {
			return fmt.Errorf("bearer_token is required for upload tasks")
		}
		if r.SourceDir == "" {
			return fmt.Errorf("source_dir is required for upload tasks")
		}
		if len(r.FileList) == 0 && len(r.DirPaths) == 0 {
			return fmt.Errorf("upload task must contain at least one file or directory")
		}
		for i := range r.FileList {
			if err := validateLocalRelPath(r.FileList[i].LocalRelPath); err != nil {
				return fmt.Errorf("file_list[%d].local_rel_path: %w", i, err)
			}
			if r.FileList[i].ObjectKey == "" {
				return fmt.Errorf("file_list[%d].object_key is required for upload tasks", i)
			}
			normalized, err := normalizeLogicalAbsolute(r.FileList[i].ObjectKey, false)
			if err != nil {
				return fmt.Errorf("file_list[%d].object_key: %w", i, err)
			}
			r.FileList[i].ObjectKey = normalized
		}
		for i := range r.DirPaths {
			normalized, err := normalizeLogicalAbsolute(r.DirPaths[i], true)
			if err != nil {
				return fmt.Errorf("dir_paths[%d]: %w", i, err)
			}
			r.DirPaths[i] = normalized
		}
	default:
		return fmt.Errorf("unsupported mode %q", r.Mode)
	}

	return nil
}

func validateCorrelationLabel(value string) error {
	if len(value) > 128 {
		return fmt.Errorf("must not exceed 128 bytes")
	}
	if !utf8.ValidString(value) {
		return fmt.Errorf("must be valid UTF-8")
	}
	for index := 0; index < len(value); index++ {
		char := value[index]
		if (char < ' ' && char != '\t') || char == 0x7f {
			return fmt.Errorf("contains a character that is not allowed in an HTTP header value")
		}
	}
	return nil
}

func validateCallerVersion(value string) error {
	if len(value) > 256 {
		return fmt.Errorf("must not exceed 256 bytes")
	}
	if !utf8.ValidString(value) {
		return fmt.Errorf("must be valid UTF-8")
	}
	for index := 0; index < len(value); index++ {
		char := value[index]
		if (char < ' ' && char != '\t') || char == 0x7f {
			return fmt.Errorf("contains a character that is not allowed in an HTTP header value")
		}
	}
	return nil
}

func normalizeLogicalAbsolute(raw string, allowRoot bool) (string, error) {
	if raw == "" || !utf8.ValidString(raw) || strings.ContainsRune(raw, 0) || strings.Contains(raw, "\\") {
		return "", fmt.Errorf("must be a valid UTF-8 logical path without NUL or backslash")
	}
	parts := strings.Split(strings.Trim(raw, "/"), "/")
	normalized := make([]string, 0, len(parts))
	for _, part := range parts {
		if part == "" {
			continue
		}
		if part == "." || part == ".." {
			return "", fmt.Errorf("must not contain dot segments")
		}
		if len(part) > 255 {
			return "", fmt.Errorf("segment exceeds 255 bytes")
		}
		normalized = append(normalized, part)
	}
	result := "/" + strings.Join(normalized, "/")
	if result == "/" && !allowRoot {
		return "", fmt.Errorf("must not be root")
	}
	if len(result) > 1024 {
		return "", fmt.Errorf("path exceeds 1024 bytes")
	}
	return result, nil
}

func validateLocalRelPath(p string) error {
	if p == "" {
		return fmt.Errorf("must not be empty")
	}
	if filepath.IsAbs(p) {
		return fmt.Errorf("must be a relative path")
	}

	cleaned := filepath.Clean(p)
	if cleaned == "." || cleaned == ".." {
		return fmt.Errorf("must point to a file under the task root")
	}
	parentPrefix := ".." + string(filepath.Separator)
	if strings.HasPrefix(cleaned, parentPrefix) {
		return fmt.Errorf("must not escape the task root")
	}
	return nil
}
