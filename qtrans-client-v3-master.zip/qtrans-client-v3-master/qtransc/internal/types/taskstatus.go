package types

// TaskStatus represents the current state of a task
type TaskStatus string

const (
	StatusUnknown   TaskStatus = ""          // 未知状态
	StatusPending   TaskStatus = "pending"   // 任务排队中，等待调度
	StatusRunning   TaskStatus = "running"   // 任务正在进行中
	StatusCompleted TaskStatus = "completed" // 任务已完成
	StatusStopped   TaskStatus = "stopped"   // 任务已停止
	StatusFailed    TaskStatus = "failed"    // 任务执行失败
)

// isValidTransition checks whether a transition from curr to next status is allowed.
// 规则说明：
// - pending -> running | stopped
// - running -> completed | stopped | failed
// - completed/stopped/failed -> pending (允许重新调度)
func IsValidTransition(curr, next TaskStatus) bool {
	if curr == next {
		return true
	}

	switch curr {
	case StatusPending:
		return next == StatusRunning || next == StatusStopped
	case StatusRunning:
		return next == StatusCompleted || next == StatusStopped || next == StatusFailed
	case StatusStopped:
		return next == StatusPending
	case StatusFailed:
		return next == StatusPending
	case StatusCompleted:
		return next == StatusPending
	default:
		return false
	}
}
