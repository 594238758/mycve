package taskmanager

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"qtransc/internal/domain"
	"qtransc/internal/downloadtask"
	"qtransc/internal/eventcollector"
	"qtransc/internal/netclient"
	"qtransc/internal/types"
	"qtransc/internal/uploadtask"
)

var (
	ErrTaskIDRequired      = errors.New("task id is required")
	ErrTaskIDInvalid       = errors.New("task id is invalid")
	ErrTaskAlreadyExists   = errors.New("task already exists")
	ErrTaskNotFound        = errors.New("task not found")
	ErrTaskStateConflict   = errors.New("task state conflict")
	ErrTaskCapacity        = errors.New("task capacity exceeded")
	ErrServiceShuttingDown = errors.New("service shutting down")
)

const maxTaskIDBytes = 128

// TaskManager owns task registration, admission capacity, the waiting order
// and execution slots. It never writes Task status; it only calls Run/Stop/Retry.
type TaskManager struct {
	defaults     types.TransferSettings
	closing      atomic.Bool
	shutdownOnce sync.Once
	shutdownErr  error
	ctx          context.Context
	cancel       context.CancelFunc
	logger       *slog.Logger
	eventConfig  eventcollector.RuntimeConfig

	mu          sync.Mutex
	tasks       map[string]domain.Task
	taskOps     map[string]*sync.Mutex
	executions  map[string]*taskExecution
	waiting     []string
	waitingSet  map[string]struct{}
	active      int
	admitted    int
	maxActive   int
	maxAdmitted int
	autoRetries map[string]*taskRetry

	wake          chan struct{}
	schedulerDone chan struct{}
	retryDone     chan struct{}
}

// taskExecution tracks an accepted Run until its completion notification has
// released the execution and admission slots.
type taskExecution struct {
	complete bool
	done     chan struct{}
}

// NewTaskManager 创建新的任务管理器
// workerCount: 执行名额（最大同时执行任务数）
// maxTotal: 接纳上限（pending + 尚未结算的执行），<=0 表示不限制
func NewTaskManager(ctx context.Context, workerCount, maxTotal int, defaults types.TransferSettings, opts ...eventcollector.RuntimeOption) *TaskManager {
	ctx, cancel := context.WithCancel(ctx)
	logger := slog.Default().With("component", "TaskManager")
	eventConfig := eventcollector.ApplyRuntimeOptions(opts...)

	tm := &TaskManager{
		defaults:      defaults,
		ctx:           ctx,
		cancel:        cancel,
		logger:        logger,
		eventConfig:   eventConfig,
		tasks:         make(map[string]domain.Task),
		taskOps:       make(map[string]*sync.Mutex),
		executions:    make(map[string]*taskExecution),
		waitingSet:    make(map[string]struct{}),
		maxActive:     workerCount,
		maxAdmitted:   maxTotal,
		autoRetries:   make(map[string]*taskRetry),
		wake:          make(chan struct{}, 1),
		schedulerDone: make(chan struct{}),
		retryDone:     make(chan struct{}),
	}

	go tm.scheduleLoop()
	go tm.scheduleRetries()
	return tm
}

// Start 启动任务管理器
func (tm *TaskManager) Start() error {
	tm.logger.Info("Starting TaskManager", "max_active", tm.maxActive, "max_admitted", tm.maxAdmitted)
	return nil
}

// IsClosing is also checked before request validation and task admission.
func (tm *TaskManager) IsClosing() bool {
	return tm.closing.Load() || tm.ctx.Err() != nil
}

func (tm *TaskManager) Shutdown(timeout time.Duration) error {
	tm.shutdownOnce.Do(func() {
		// Closing and the task snapshot share the same critical section as task
		// admission so a start cannot be accepted after closure begins.
		tm.mu.Lock()
		tm.closing.Store(true)
		ids := make([]string, 0, len(tm.tasks))
		for id := range tm.tasks {
			ids = append(ids, id)
		}
		tm.mu.Unlock()
		tm.wakeScheduler()
		sort.Strings(ids)

		for _, id := range ids {
			task, err := tm.GetTask(id)
			if err != nil {
				continue
			}
			status := task.GetStatus().Status
			if status != types.StatusPending && status != types.StatusRunning {
				continue
			}
			if _, err := tm.StopTask(id); err != nil {
				status = task.GetStatus().Status
				if status == types.StatusPending || status == types.StatusRunning {
					tm.shutdownErr = errors.Join(tm.shutdownErr, err)
				}
			}
		}

		// Let completion notifications settle admission and execution slots before
		// the manager context and scheduling loops are torn down.
		if timeout > 0 {
			deadline := time.NewTimer(timeout)
			defer deadline.Stop()
			ticker := time.NewTicker(10 * time.Millisecond)
			defer ticker.Stop()
		waitLoop:
			for {
				tm.mu.Lock()
				settled := len(tm.executions) == 0
				tm.mu.Unlock()
				if settled {
					break
				}
				select {
				case <-deadline.C:
					tm.shutdownErr = errors.Join(tm.shutdownErr, errors.New("task manager shutdown timeout"))
					break waitLoop
				case <-ticker.C:
				}
			}
		}

		tm.cancel()
		tm.wakeScheduler()
		<-tm.schedulerDone
		<-tm.retryDone
	})
	return tm.shutdownErr
}

// ResolveTransferSettings merges and validates a request without changing service
// defaults or allocating network resources. It runs before task admission.
func (tm *TaskManager) ResolveTransferSettings(transport string, overrides types.TransferOverrides) (types.TransferSettings, error) {
	settings := tm.defaults
	if strings.TrimSpace(transport) == "" {
		transport = settings.Transport.String()
	}
	mode, err := types.ParseTransportMode(transport)
	if err != nil {
		return types.TransferSettings{}, err
	}
	settings.Transport = mode
	if overrides.Connections != nil {
		settings.Connections = *overrides.Connections
	}
	if overrides.Streams != nil {
		settings.Streams = *overrides.Streams
	} else if mode == types.TransportHTTPS {
		settings.Streams = 1
	}
	if overrides.Transfers != nil {
		settings.FileConcurrency = *overrides.Transfers
	}
	if _, err := netclient.NormalizePoolConfig(mode, settings.Connections, settings.Streams); err != nil {
		return types.TransferSettings{}, err
	}
	if settings.FileConcurrency <= 0 {
		return types.TransferSettings{}, fmt.Errorf("transfers must be greater than 0")
	}
	return settings, nil
}

// CreateAndStartTask accepts the validated request and resolved settings snapshot.
// The task is registered as pending, then the scheduling loop decides whether an
// execution slot is available.
func (tm *TaskManager) CreateAndStartTask(req *types.TaskCreateRequest, settings types.TransferSettings) (domain.Task, error) {
	tm.mu.Lock()
	defer tm.mu.Unlock()
	if tm.IsClosing() {
		return nil, ErrServiceShuttingDown
	}

	req.TaskID = strings.TrimSpace(req.TaskID)
	if req.TaskID == "" {
		return nil, ErrTaskIDRequired
	}
	if len(req.TaskID) > maxTaskIDBytes {
		return nil, ErrTaskIDInvalid
	}
	if _, exists := tm.tasks[req.TaskID]; exists {
		return nil, fmt.Errorf("%w: %s", ErrTaskAlreadyExists, req.TaskID)
	}
	if err := tm.reserveAdmissionLocked(); err != nil {
		return nil, err
	}

	req.Transport = settings.Transport.String()
	network := netclient.Config{Pool: netclient.PoolConfig{
		Connections:          settings.Connections,
		StreamsPerConnection: settings.Streams,
	}}
	t, err := tm.newTask(req, settings, network)
	if err != nil {
		tm.releaseAdmissionLocked()
		return nil, err
	}

	tm.tasks[t.GetID()] = t
	if tm.taskOps[t.GetID()] == nil {
		tm.taskOps[t.GetID()] = &sync.Mutex{}
	}
	if req.AutoRetry {
		tm.autoRetries[t.GetID()] = &taskRetry{task: t}
	}
	tm.enqueueTailLocked(t.GetID())
	// The manager owns the initial pending event; the constructor never publishes
	// it, so a rejected creation cannot leak a task event.
	tm.eventConfig.Publisher.Publish(types.NewTaskStatusEvent(t.GetID(), types.TaskStatusToEventStatus(types.StatusPending), ""))
	tm.logger.Info("Task created", "task_id", t.GetID(), "taskpid", t.GetTaskPID(), "enterprise_id", t.GetEnterpriseID())
	tm.wakeScheduler()
	return t, nil
}

func (tm *TaskManager) newTask(req *types.TaskCreateRequest, settings types.TransferSettings, network netclient.Config) (domain.Task, error) {
	var created domain.Task
	opts := []eventcollector.RuntimeOption{
		eventcollector.WithPublisher(tm.eventConfig.Publisher),
		eventcollector.WithProgressInterval(tm.eventConfig.ProgressInterval),
		eventcollector.WithCompletionNotifier(func() {
			if created != nil {
				tm.taskCompleted(created)
			}
		}),
	}
	switch req.Mode {
	case string(domain.TaskTypeDownload):
		task, err := downloadtask.NewPendingDownloadTask(req, network, nil, opts...)
		if err != nil {
			return nil, fmt.Errorf("failed to create download task: %w", err)
		}
		task.FileConcurrency = settings.FileConcurrency
		created = task
		return task, nil
	case string(domain.TaskTypeUpload):
		task, err := uploadtask.NewPendingUploadTask(req, network, nil, opts...)
		if err != nil {
			return nil, fmt.Errorf("failed to create upload task: %w", err)
		}
		task.FileConcurrency = settings.FileConcurrency
		created = task
		return task, nil
	default:
		return nil, fmt.Errorf("unsupported task mode: %s", req.Mode)
	}
}

// StartTask 启动已存在的终态任务。
func (tm *TaskManager) StartTask(taskID string) (domain.Task, error) {
	op := tm.taskOperation(taskID)
	if op == nil {
		return nil, fmt.Errorf("%w: %s", ErrTaskNotFound, taskID)
	}
	op.Lock()
	defer op.Unlock()

	// Admission, closure check, Retry and enqueue form one manager critical
	// section. Shutdown uses the same lock to publish closure, so either this
	// start is accepted before shutdown snapshots tasks or it is rejected without
	// touching the task's previous snapshot.
	tm.mu.Lock()
	if tm.IsClosing() {
		tm.mu.Unlock()
		return nil, ErrServiceShuttingDown
	}
	t, exists := tm.tasks[taskID]
	if !exists {
		tm.mu.Unlock()
		return nil, fmt.Errorf("%w: %s", ErrTaskNotFound, taskID)
	}
	status := t.GetStatus().Status
	if status != types.StatusCompleted && status != types.StatusStopped && status != types.StatusFailed {
		tm.mu.Unlock()
		return t, fmt.Errorf("%w: cannot start task in %s", ErrTaskStateConflict, status)
	}
	if tm.executions[taskID] != nil {
		tm.mu.Unlock()
		return t, fmt.Errorf("%w: previous execution is still releasing", ErrTaskStateConflict)
	}
	if err := tm.reserveAdmissionLocked(); err != nil {
		tm.mu.Unlock()
		return t, err
	}
	if err := t.Retry(); err != nil {
		tm.releaseAdmissionLocked()
		tm.mu.Unlock()
		// Includes the source-changed restart restriction, which remains a
		// request-level state conflict.
		return t, fmt.Errorf("%w: %w", ErrTaskStateConflict, err)
	}
	if retry := tm.autoRetries[taskID]; retry != nil {
		retry.suspended = false
	}
	tm.enqueueTailLocked(taskID)
	tm.mu.Unlock()
	tm.wakeScheduler()
	tm.logger.Info("Task queued for restart", "task_id", taskID, "taskpid", t.GetTaskPID(), "enterprise_id", t.GetEnterpriseID())
	return t, nil
}

// StopTask 停止任务
func (tm *TaskManager) StopTask(taskID string) (domain.Task, error) {
	op := tm.taskOperation(taskID)
	if op == nil {
		return nil, fmt.Errorf("%w: %s", ErrTaskNotFound, taskID)
	}
	op.Lock()
	defer op.Unlock()

	tm.mu.Lock()
	task, exists := tm.tasks[taskID]
	if !exists {
		tm.mu.Unlock()
		return nil, fmt.Errorf("%w: %s", ErrTaskNotFound, taskID)
	}
	status := task.GetStatus().Status
	retry := tm.autoRetries[taskID]
	canStopRetry := status == types.StatusFailed && retry != nil && !retry.suspended
	if status != types.StatusPending && status != types.StatusRunning && !canStopRetry {
		tm.mu.Unlock()
		return task, fmt.Errorf("%w: cannot stop task in %s", ErrTaskStateConflict, status)
	}
	if retry != nil {
		retry.suspended = true
	}
	tm.mu.Unlock()

	if err := task.Stop(); err != nil {
		return task, fmt.Errorf("%w: %w", ErrTaskStateConflict, err)
	}

	if status == types.StatusPending {
		tm.mu.Lock()
		tm.removeWaitingLocked(taskID)
		tm.releaseAdmissionLocked()
		tm.mu.Unlock()
	}
	return task, nil
}

// DeleteTask 删除任务（唯一清理资源的地方）
func (tm *TaskManager) DeleteTask(taskID string) error {
	op := tm.taskOperation(taskID)
	if op == nil {
		return fmt.Errorf("%w: %s", ErrTaskNotFound, taskID)
	}
	op.Lock()
	opUnlocked := false
	defer func() {
		if !opUnlocked {
			op.Unlock()
		}
	}()

	tm.mu.Lock()
	t, exists := tm.tasks[taskID]
	if !exists {
		tm.mu.Unlock()
		return fmt.Errorf("%w: %s", ErrTaskNotFound, taskID)
	}
	status := t.GetStatus().Status
	if retry := tm.autoRetries[taskID]; retry != nil {
		retry.suspended = true
	}
	tm.mu.Unlock()

	if err := t.Stop(); err != nil {
		return fmt.Errorf("stop task before deletion: %w", err)
	}
	// A task can publish its terminal status just before its completion
	// notification runs. Wait for that notification so it cannot be applied to a
	// re-created task with the same ID.
	tm.mu.Lock()
	execution := tm.executions[taskID]
	tm.mu.Unlock()
	if execution != nil && execution.done != nil {
		<-execution.done
	}
	if status == types.StatusPending {
		// The task is stopped; release its queue and admission slots even if
		// resumable-state cleanup below fails and the task record is retained.
		tm.mu.Lock()
		tm.removeWaitingLocked(taskID)
		tm.releaseAdmissionLocked()
		tm.mu.Unlock()
	}
	if abandoner, ok := t.(interface{ Abandon() error }); ok {
		if err := abandoner.Abandon(); err != nil {
			return fmt.Errorf("abandon task: %w", err)
		}
	}

	tm.mu.Lock()
	if execution := tm.executions[taskID]; execution != nil {
		if !execution.complete {
			execution.complete = true
			if tm.active > 0 {
				tm.active--
			}
			tm.releaseAdmissionLocked()
			if execution.done != nil {
				close(execution.done)
			}
		}
		delete(tm.executions, taskID)
	}
	delete(tm.tasks, taskID)
	delete(tm.autoRetries, taskID)
	delete(tm.taskOps, taskID)
	tm.eventConfig.Publisher.Publish(types.NewTaskStatusEvent(taskID, types.TaskEventStatusDeleted, ""))
	tm.mu.Unlock()

	// Local deletion is committed; remote cleanup must not keep other tasks
	// waiting on this task's operation lock.
	op.Unlock()
	opUnlocked = true

	tm.logger.Info("Task deleted and local resources cleaned up",
		"task_id", taskID,
		"taskpid", t.GetTaskPID(),
		"enterprise_id", t.GetEnterpriseID(),
		"final_status", t.GetStatus().Status)

	// Remote cleanup is best effort after the local deletion has committed.
	if reporter, ok := t.(interface{ ReportDeleted(context.Context) error }); ok {
		if err := reporter.ReportDeleted(context.Background()); err != nil {
			tm.logger.Warn("Failed to clean remote resources for deleted task", "task_id", taskID, "taskpid", t.GetTaskPID(), "enterprise_id", t.GetEnterpriseID(), "error", err)
		}
	}
	return nil
}

// GetTask 获取任务
func (tm *TaskManager) GetTask(taskID string) (domain.Task, error) {
	tm.mu.Lock()
	defer tm.mu.Unlock()

	t, exists := tm.tasks[taskID]
	if !exists {
		return nil, fmt.Errorf("%w: %s", ErrTaskNotFound, taskID)
	}
	return t, nil
}

// ListAllTasks 列出所有任务
func (tm *TaskManager) ListAllTasks() ([]domain.Task, error) {
	tm.mu.Lock()
	defer tm.mu.Unlock()

	tasks := make([]domain.Task, 0, len(tm.tasks))
	for _, t := range tm.tasks {
		tasks = append(tasks, t)
	}
	return tasks, nil
}

// GetConfig returns the manager's configured limits and transfer defaults by value.
func (tm *TaskManager) GetConfig() ManagerConfig {
	tm.mu.Lock()
	defer tm.mu.Unlock()
	return ManagerConfig{
		MaxConcurrentTasks: tm.maxActive,
		MaxAdmittedTasks:   tm.maxAdmitted,
		TransferDefaults:   tm.defaults,
	}
}

type ManagerConfig struct {
	MaxConcurrentTasks int
	MaxAdmittedTasks   int
	TransferDefaults   types.TransferSettings
}

// GetStats 获取统计信息
func (tm *TaskManager) GetStats() ManagerStats {
	tm.mu.Lock()
	defer tm.mu.Unlock()
	return ManagerStats{
		TotalTasks:       len(tm.tasks),
		RunningTasks:     tm.active,
		WaitingTasks:     len(tm.waiting),
		AdmittedTasks:    tm.admitted,
		MaxActiveTasks:   tm.maxActive,
		MaxAdmittedTasks: tm.maxAdmitted,
	}
}

// ManagerStats 管理器统计信息
type ManagerStats struct {
	TotalTasks       int
	RunningTasks     int
	WaitingTasks     int
	AdmittedTasks    int
	MaxActiveTasks   int
	MaxAdmittedTasks int
}
