package taskmanager

import (
	"errors"
	"sync"

	"qtransc/internal/domain"
	"qtransc/internal/types"
)

// taskOperation returns the per-task operation lock created at registration.
// The entry is removed with the task. Callers must not reuse a task ID while an
// older request may still hold the previous lock.
func (tm *TaskManager) taskOperation(taskID string) *sync.Mutex {
	tm.mu.Lock()
	defer tm.mu.Unlock()
	return tm.taskOps[taskID]
}

func (tm *TaskManager) wakeScheduler() {
	select {
	case tm.wake <- struct{}{}:
	default:
	}
}

// scheduleLoop is the single serial admission point for execution slots. The
// three lifecycle triggers only wake this loop, preserving waiting order.
func (tm *TaskManager) scheduleLoop() {
	defer close(tm.schedulerDone)
	for {
		select {
		case <-tm.ctx.Done():
			return
		case <-tm.wake:
		}
		tm.dispatch()
	}
}

func (tm *TaskManager) dispatch() {
	for {
		tm.mu.Lock()
		if tm.IsClosing() || len(tm.waiting) == 0 || (tm.maxActive > 0 && tm.active >= tm.maxActive) {
			tm.mu.Unlock()
			return
		}
		taskID := tm.waiting[0]
		task := tm.tasks[taskID]
		op := tm.taskOps[taskID]
		tm.mu.Unlock()

		if task == nil || op == nil {
			tm.mu.Lock()
			tm.removeWaitingLocked(taskID)
			tm.mu.Unlock()
			continue
		}

		op.Lock()
		tm.mu.Lock()
		if tm.IsClosing() {
			tm.mu.Unlock()
			op.Unlock()
			return
		}
		if _, queued := tm.waitingSet[taskID]; !queued {
			tm.mu.Unlock()
			op.Unlock()
			continue
		}
		if tm.tasks[taskID] != task || tm.executions[taskID] != nil {
			tm.removeWaitingLocked(taskID)
			tm.mu.Unlock()
			op.Unlock()
			continue
		}
		if task.GetStatus().Status != types.StatusPending {
			tm.removeWaitingLocked(taskID)
			tm.mu.Unlock()
			op.Unlock()
			continue
		}
		if tm.maxActive > 0 && tm.active >= tm.maxActive {
			tm.mu.Unlock()
			op.Unlock()
			return
		}

		tm.removeWaitingLocked(taskID)
		tm.active++
		tm.executions[taskID] = &taskExecution{done: make(chan struct{})}
		tm.mu.Unlock()

		err := task.Run(tm.ctx)
		op.Unlock()
		if err == nil {
			continue
		}

		tm.mu.Lock()
		if execution := tm.executions[taskID]; execution != nil && !execution.complete {
			if tm.active > 0 {
				tm.active--
			}
			// The task stays pending and keeps its admission slot; only the
			// execution reservation is withdrawn.
			if execution.done != nil {
				close(execution.done)
			}
			delete(tm.executions, taskID)
		}
		if tm.tasks[taskID] == task && task.GetStatus().Status == types.StatusPending && !tm.IsClosing() {
			tm.enqueueFrontLocked(taskID)
		}
		tm.mu.Unlock()

		if !errors.Is(err, domain.ErrInvalidTaskState) && !tm.IsClosing() {
			tm.logger.Error("Failed to start task", "task_id", taskID, "taskpid", task.GetTaskPID(), "enterprise_id", task.GetEnterpriseID(), "error", err)
		}
		// Retry the same head only on a later wake; this avoids a busy loop if a
		// task remains pending but repeatedly rejects Run.
		return
	}
}

func (tm *TaskManager) taskCompleted(task domain.Task) {
	// The completion callback must not take a task operation lock or wait for a
	// consumer; it only settles the execution record and wakes the scheduler.
	tm.mu.Lock()
	if execution := tm.executions[task.GetID()]; execution != nil && !execution.complete {
		execution.complete = true
		if tm.active > 0 {
			tm.active--
		}
		tm.releaseAdmissionLocked()
		if execution.done != nil {
			close(execution.done)
		}
		delete(tm.executions, task.GetID())
	}
	tm.mu.Unlock()
	tm.wakeScheduler()
}

func (tm *TaskManager) reserveAdmissionLocked() error {
	if tm.maxAdmitted > 0 && tm.admitted >= tm.maxAdmitted {
		return ErrTaskCapacity
	}
	tm.admitted++
	return nil
}

func (tm *TaskManager) releaseAdmissionLocked() {
	if tm.admitted > 0 {
		tm.admitted--
	}
}

func (tm *TaskManager) enqueueTailLocked(taskID string) {
	if _, exists := tm.waitingSet[taskID]; exists {
		return
	}
	tm.waiting = append(tm.waiting, taskID)
	tm.waitingSet[taskID] = struct{}{}
}

func (tm *TaskManager) enqueueFrontLocked(taskID string) {
	if _, exists := tm.waitingSet[taskID]; exists {
		return
	}
	tm.waiting = append([]string{taskID}, tm.waiting...)
	tm.waitingSet[taskID] = struct{}{}
}

func (tm *TaskManager) removeWaitingLocked(taskID string) bool {
	if _, exists := tm.waitingSet[taskID]; !exists {
		return false
	}
	delete(tm.waitingSet, taskID)
	for i, id := range tm.waiting {
		if id == taskID {
			tm.waiting = append(tm.waiting[:i], tm.waiting[i+1:]...)
			break
		}
	}
	return true
}
