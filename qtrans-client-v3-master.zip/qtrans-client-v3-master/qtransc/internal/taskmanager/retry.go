package taskmanager

import (
	"sort"
	"time"

	"qtransc/internal/domain"
	"qtransc/internal/types"
)

// Retry policy is protected by tm.mu. Eligibility is derived from the current
// task status and execution record instead of maintaining a separate retry queue.
type taskRetry struct {
	task      domain.Task
	suspended bool
}

// One loop scans all auto-retry tasks serially. A failed admission can simply
// wait for the next tick; it needs no scheduling capacity notifications.
func (tm *TaskManager) scheduleRetries() {
	defer close(tm.retryDone)
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-tm.ctx.Done():
			return
		case <-ticker.C:
		}
		tm.admitRetries()
	}
}

type retryCandidate struct {
	id       string
	task     domain.Task
	finished time.Time
}

func (tm *TaskManager) admitRetries() {
	tm.mu.Lock()
	if tm.IsClosing() {
		tm.mu.Unlock()
		return
	}
	candidates := make([]retryCandidate, 0, len(tm.autoRetries))
	for id, retry := range tm.autoRetries {
		if retry.suspended || tm.tasks[id] != retry.task || tm.executions[id] != nil {
			continue
		}
		basic := retry.task.GetStatus()
		if basic.Status != types.StatusFailed {
			continue
		}
		candidates = append(candidates, retryCandidate{id: id, task: retry.task, finished: basic.FinishedAt})
	}
	tm.mu.Unlock()

	sort.Slice(candidates, func(i, j int) bool {
		if candidates[i].finished.Equal(candidates[j].finished) {
			return candidates[i].id < candidates[j].id
		}
		return candidates[i].finished.Before(candidates[j].finished)
	})

	for _, candidate := range candidates {
		if tm.IsClosing() {
			return
		}
		tm.admitRetryCandidate(candidate)
	}
}

func (tm *TaskManager) admitRetryCandidate(candidate retryCandidate) {
	op := tm.taskOperation(candidate.id)
	if op == nil {
		return
	}
	op.Lock()
	defer op.Unlock()

	// Auto-retry uses the same admission critical section as manual start.
	// Shutdown either observes the candidate as failed before closure, or this
	// candidate is accepted and appears in the shutdown task snapshot.
	tm.mu.Lock()
	retry := tm.autoRetries[candidate.id]
	if tm.IsClosing() || retry == nil || retry.suspended ||
		tm.tasks[candidate.id] != candidate.task || tm.executions[candidate.id] != nil {
		tm.mu.Unlock()
		return
	}
	if candidate.task.GetStatus().Status != types.StatusFailed {
		tm.mu.Unlock()
		return
	}
	if err := tm.reserveAdmissionLocked(); err != nil {
		tm.mu.Unlock()
		return
	}
	if err := candidate.task.Retry(); err != nil {
		tm.releaseAdmissionLocked()
		tm.mu.Unlock()
		if !tm.IsClosing() {
			tm.logger.Error("Failed to requeue task", "task_id", candidate.id, "taskpid", candidate.task.GetTaskPID(), "enterprise_id", candidate.task.GetEnterpriseID(), "error", err)
		}
		return
	}
	tm.enqueueTailLocked(candidate.id)
	tm.mu.Unlock()
	tm.wakeScheduler()
	tm.logger.Info("Failed task automatically requeued", "task_id", candidate.id, "taskpid", candidate.task.GetTaskPID(), "enterprise_id", candidate.task.GetEnterpriseID())
}
