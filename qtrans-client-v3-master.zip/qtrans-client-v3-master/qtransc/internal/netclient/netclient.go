package netclient

import (
	"context"
	"crypto/tls"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"qtransc/internal/sslkeylog"
	"qtransc/internal/transportpool"
	"qtransc/internal/types"

	"github.com/quic-go/quic-go"
)

type ReleaseFunc func()

const (
	defaultMaxOrigins                     = 8
	defaultInitialConnectionReceiveWindow = int64(64 << 20)
	defaultMaxConnectionReceiveWindow     = int64(256 << 20)
	maxQUICVarint                         = int64(1<<62 - 1)
	maxConnections                        = 1024
	maxStreamsPerConnection               = 1024
)

// Client owns one transport pool. It is never shared between task executions.
type Client struct {
	mode      types.TransportMode
	config    Config
	pool      transportpool.Pool
	closeOnce sync.Once
	closeErr  error
}

// Config is an immutable snapshot, passed internally rather than through API JSON.
type Config struct {
	Pool    PoolConfig
	Options PoolOptions
}

func (c *Client) Mode() types.TransportMode { return c.mode }
func (c *Client) Config() Config            { return c.config }
func (c *Client) Capacity() int {
	return c.config.Pool.Connections * c.config.Pool.StreamsPerConnection
}

func (c *Client) Close() error {
	if c == nil {
		return nil
	}
	c.closeOnce.Do(func() { c.closeErr = c.pool.Close() })
	return c.closeErr
}

func (cfg Config) Validate(mode types.TransportMode) error {
	if _, err := NormalizePoolConfig(mode, cfg.Pool.Connections, cfg.Pool.StreamsPerConnection); err != nil {
		return err
	}
	window := cfg.Options.QUICMaxConnectionReceiveWindow
	if window < 0 || window > maxQUICVarint {
		return fmt.Errorf("QUIC MaxConnectionReceiveWindow must be between 1 and %d bytes", maxQUICVarint)
	}
	if window > 0 && mode != "" && mode != types.TransportHTTPS3 {
		return fmt.Errorf("QUIC MaxConnectionReceiveWindow override requires transport %s", types.TransportHTTPS3)
	}
	return nil
}

type PoolConfig struct {
	Connections          int
	StreamsPerConnection int
}

type PoolOptions struct {
	// QUICMaxConnectionReceiveWindow is an invocation-specific test override.
	// Zero preserves the production default.
	QUICMaxConnectionReceiveWindow int64
}

func NormalizePoolConfig(mode types.TransportMode, connections, streamsPerConnection int) (PoolConfig, error) {
	if mode == "" {
		mode = types.TransportHTTPS3
	}
	if connections < 1 || connections > maxConnections {
		return PoolConfig{}, fmt.Errorf("connections must be between 1 and %d", maxConnections)
	}

	switch mode {
	case types.TransportHTTPS:
		if streamsPerConnection != 1 {
			return PoolConfig{}, fmt.Errorf("streams must equal 1 when transport=%s", mode)
		}
		return PoolConfig{
			Connections:          connections,
			StreamsPerConnection: 1,
		}, nil
	case types.TransportHTTPS2, types.TransportHTTPS3:
		if streamsPerConnection < 1 || streamsPerConnection > maxStreamsPerConnection {
			return PoolConfig{}, fmt.Errorf("streams must be between 1 and %d when transport=%s", maxStreamsPerConnection, mode)
		}
		return PoolConfig{
			Connections:          connections,
			StreamsPerConnection: streamsPerConnection,
		}, nil
	default:
		return PoolConfig{}, fmt.Errorf("unsupported transport %q", mode)
	}
}

func New(mode types.TransportMode, config Config) (*Client, error) {
	if mode == "" {
		mode = types.TransportHTTPS3
	}
	if err := config.Validate(mode); err != nil {
		return nil, err
	}
	cfg, options := config.Pool, config.Options

	tlsConfig := &tls.Config{
		InsecureSkipVerify: true,
		ClientSessionCache: tls.NewLRUClientSessionCache(100),
		KeyLogWriter:       sslkeylog.Writer(),
	}
	var driver transportpool.Driver
	switch mode {
	case types.TransportHTTPS:
		driver = transportpool.NewHTTP1TLSDriver(transportpool.HTTPDriverConfig{
			TLSClientConfig: tlsConfig,
			Proxy:           http.ProxyFromEnvironment,
		})
	case types.TransportHTTPS2:
		driver = transportpool.NewHTTP2TLSDriver(transportpool.HTTPDriverConfig{
			TLSClientConfig: tlsConfig,
			Proxy:           http.ProxyFromEnvironment,
		})
	case types.TransportHTTPS3:
		maxConnectionReceiveWindow := defaultMaxConnectionReceiveWindow
		if options.QUICMaxConnectionReceiveWindow > 0 {
			maxConnectionReceiveWindow = options.QUICMaxConnectionReceiveWindow
		}
		initialConnectionReceiveWindow := defaultInitialConnectionReceiveWindow
		if maxConnectionReceiveWindow > 0 && maxConnectionReceiveWindow < initialConnectionReceiveWindow {
			initialConnectionReceiveWindow = maxConnectionReceiveWindow
		}
		driver = transportpool.NewHTTP3Driver(transportpool.HTTP3DriverConfig{
			TLSClientConfig: tlsConfig,
			QUICConfig: &quic.Config{
				Allow0RTT:                      true,
				MaxIncomingStreams:             2048,
				KeepAlivePeriod:                10 * time.Second,
				MaxIdleTimeout:                 300 * time.Second,
				HandshakeIdleTimeout:           30 * time.Second,
				InitialStreamReceiveWindow:     16 << 20,
				MaxStreamReceiveWindow:         64 << 20,
				InitialConnectionReceiveWindow: uint64(initialConnectionReceiveWindow),
				MaxConnectionReceiveWindow:     uint64(maxConnectionReceiveWindow),
				TokenStore:                     quic.NewLRUTokenStore(100, 5),
			},
		})
	default:
		return nil, fmt.Errorf("unsupported transport %q", mode)
	}

	pool, err := transportpool.New(driver, transportpool.Config{
		MaxOrigins: defaultMaxOrigins,
		PerOrigin: transportpool.Limits{
			MaxConnections:         cfg.Connections,
			MaxLeasesPerConnection: cfg.StreamsPerConnection,
			ConnectionIdleTimeout:  90 * time.Second,
		},
	})
	if err != nil {
		return nil, err
	}
	return &Client{mode: mode, config: config, pool: pool}, nil
}

func (c *Client) Acquire(ctx context.Context, requestURL string) (*http.Client, ReleaseFunc, error) {
	if c == nil {
		return nil, nil, fmt.Errorf("network client is not configured")
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		return nil, nil, err
	}
	origin, err := transportpool.ParseOrigin(requestURL)
	if err != nil {
		return nil, nil, err
	}
	if err := validateModeScheme(requestURL, c.mode); err != nil {
		return nil, nil, err
	}
	lease, err := c.pool.Acquire(ctx, origin)
	if err != nil {
		return nil, nil, err
	}

	adapter := &leaseRoundTripper{lease: lease}
	client := &http.Client{
		Transport: adapter,
		CheckRedirect: func(*http.Request, []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
	return client, adapter.releaseUnused, nil
}

func validateModeScheme(requestURL string, mode types.TransportMode) error {
	parsed, err := url.Parse(requestURL)
	if err != nil {
		return fmt.Errorf("parse request URL: %w", err)
	}
	if parsed.Scheme == "" || parsed.Host == "" {
		return fmt.Errorf("request URL must be absolute: %s", requestURL)
	}
	scheme := strings.ToLower(parsed.Scheme)
	if mode == "" {
		mode = types.TransportHTTPS3
	}
	switch mode {
	case types.TransportHTTPS, types.TransportHTTPS2, types.TransportHTTPS3:
		if scheme != "https" {
			return fmt.Errorf("transport %s requires an https URL, got %s", mode, requestURL)
		}
	default:
		return fmt.Errorf("unsupported transport %q", mode)
	}
	return nil
}

type leaseRoundTripper struct {
	lease   transportpool.Lease
	started atomic.Bool
}

func (r *leaseRoundTripper) RoundTrip(req *http.Request) (*http.Response, error) {
	if !r.started.CompareAndSwap(false, true) {
		return nil, transportpool.ErrLeaseUsed
	}
	return r.lease.RoundTrip(req)
}

func (r *leaseRoundTripper) releaseUnused() {
	if r.started.CompareAndSwap(false, true) {
		r.lease.Release()
	}
}
