package netclient

import "context"

// ChunkSlots bounds whole chunk operations, including their retry waits.
// It does not reserve an HTTP lease or a physical connection.
type ChunkSlots chan struct{}

func (s ChunkSlots) Acquire(ctx context.Context) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	select {
	case <-ctx.Done():
		return ctx.Err()
	case s <- struct{}{}:
	}
	if err := ctx.Err(); err != nil {
		s.Release()
		return err
	}
	return nil
}

func (s ChunkSlots) Release() { <-s }
