package serveapi

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"unicode/utf8"

	"qtransc/internal/types"
)

type strictString string

type strictBool bool

func (value *strictBool) UnmarshalJSON(data []byte) error {
	if bytes.Equal(bytes.TrimSpace(data), []byte("null")) {
		return fmt.Errorf("must be a boolean")
	}
	var decoded bool
	if err := json.Unmarshal(data, &decoded); err != nil {
		return fmt.Errorf("must be a boolean: %w", err)
	}
	*value = strictBool(decoded)
	return nil
}

// positiveInt64 permits omission but rejects explicit nonpositive values and null.
type positiveInt64 int64

func (value *positiveInt64) UnmarshalJSON(data []byte) error {
	var decoded int64
	if err := json.Unmarshal(data, &decoded); err != nil {
		return fmt.Errorf("must be a positive integer: %w", err)
	}
	if decoded <= 0 {
		return fmt.Errorf("must be a positive integer")
	}
	*value = positiveInt64(decoded)
	return nil
}

// optionalInt distinguishes omission from zero, while rejecting explicit null.
type optionalInt struct {
	value   int
	present bool
}

func (value *optionalInt) UnmarshalJSON(data []byte) error {
	if bytes.Equal(bytes.TrimSpace(data), []byte("null")) {
		return fmt.Errorf("must be an integer")
	}
	var decoded int
	if err := json.Unmarshal(data, &decoded); err != nil {
		return fmt.Errorf("must be an integer: %w", err)
	}
	*value = optionalInt{value: decoded, present: true}
	return nil
}

func (value optionalInt) pointer() *int {
	if !value.present {
		return nil
	}
	return &value.value
}

func (value *strictString) UnmarshalJSON(data []byte) error {
	if bytes.Equal(bytes.TrimSpace(data), []byte("null")) {
		return fmt.Errorf("must be a string")
	}
	var decoded string
	if err := json.Unmarshal(data, &decoded); err != nil {
		return fmt.Errorf("must be a string: %w", err)
	}
	*value = strictString(decoded)
	return nil
}

type TokenConfigRequest struct {
	BearerToken strictString `json:"bearerToken"`
}

func (request TokenConfigRequest) validateJSONFields(data []byte) error {
	return validateExactFields(data, "bearerToken")
}

func (request TokenConfigRequest) Internal() *types.TokenConfigRequest {
	return &types.TokenConfigRequest{BearerToken: string(request.BearerToken)}
}

// DecodeStrict accepts exactly one UTF-8 JSON object with no unknown fields.
func DecodeStrict(reader io.Reader, target any) error {
	body, err := io.ReadAll(reader)
	if err != nil {
		return err
	}
	if !utf8.Valid(body) {
		return fmt.Errorf("request body must be valid UTF-8")
	}
	trimmed := bytes.TrimSpace(body)
	if len(trimmed) == 0 || trimmed[0] != '{' {
		return fmt.Errorf("request body must be an object")
	}
	if request, ok := target.(interface{ validateJSONFields([]byte) error }); ok {
		if err := request.validateJSONFields(trimmed); err != nil {
			return err
		}
	}
	decoder := json.NewDecoder(bytes.NewReader(trimmed))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		return err
	}
	var trailing any
	if err := decoder.Decode(&trailing); err != io.EOF {
		if err == nil {
			return fmt.Errorf("request body must contain exactly one object")
		}
		return err
	}
	return nil
}

func validateExactFields(data []byte, allowed ...string) error {
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(data, &fields); err != nil {
		return err
	}
	allowedSet := make(map[string]struct{}, len(allowed))
	for _, field := range allowed {
		allowedSet[field] = struct{}{}
	}
	for field := range fields {
		if _, ok := allowedSet[field]; !ok {
			return fmt.Errorf("unknown field %q", field)
		}
	}
	return nil
}
