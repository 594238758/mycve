package serveapi

import (
	"strings"
	"time"

	"qtransc/internal/types"
)

type HealthData struct {
	Me      string `json:"me,omitempty"`
	PID     int    `json:"pid,omitempty"`
	Version string `json:"version,omitempty"`
}

type ConfigData struct {
	Limits   ConfigLimits   `json:"limits"`
	Defaults ConfigDefaults `json:"defaults"`
}

type ConfigLimits struct {
	MaxConcurrentTasks int `json:"maxConcurrentTasks"`
	MaxAdmittedTasks   int `json:"maxAdmittedTasks"`
}

type ConfigDefaults struct {
	Transport       string `json:"transport"`
	Connections     int    `json:"connections"`
	Streams         int    `json:"streams"`
	FileConcurrency int    `json:"fileConcurrency"`
}

type ChunkDetail struct {
	Index            int   `json:"index"`
	StartOffset      int64 `json:"startOffset"`
	EndOffset        int64 `json:"endOffset"`
	TransferredBytes int64 `json:"transferredBytes"`
	Size             int64 `json:"size"`
	Completed        bool  `json:"completed,omitempty"`
}

type DownloadFileDetail struct {
	Src              string         `json:"src,omitempty"`
	Dst              string         `json:"dst,omitempty"`
	Error            *ErrorInfo     `json:"error,omitempty"`
	LocalRelPath     string         `json:"localRelPath,omitempty"`
	RemoteURL        string         `json:"remoteUrl,omitempty"`
	Authorized       bool           `json:"authorized,omitempty"`
	Size             int64          `json:"size,omitempty"`
	TransferredBytes int64          `json:"transferredBytes,omitempty"`
	TransferRate     int64          `json:"transferRate,omitempty"`
	OverallChecksum  string         `json:"overallChecksum,omitempty"`
	Received         bool           `json:"received,omitempty"`
	Verified         bool           `json:"verified,omitempty"`
	Chunks           []*ChunkDetail `json:"chunks,omitempty"`
}

type DownloadFileSummary struct {
	Src              string     `json:"src,omitempty"`
	Dst              string     `json:"dst,omitempty"`
	Error            *ErrorInfo `json:"error,omitempty"`
	LocalRelPath     string     `json:"localRelPath,omitempty"`
	RemoteURL        string     `json:"remoteUrl,omitempty"`
	Authorized       bool       `json:"authorized,omitempty"`
	Size             int64      `json:"size,omitempty"`
	TransferredBytes int64      `json:"transferredBytes,omitempty"`
	TransferRate     int64      `json:"transferRate,omitempty"`
	OverallChecksum  string     `json:"overallChecksum,omitempty"`
	Received         bool       `json:"received,omitempty"`
	Verified         bool       `json:"verified,omitempty"`
}

type DownloadTaskSummary struct {
	TaskID            string                 `json:"taskId,omitempty"`
	TaskName          string                 `json:"taskName,omitempty"`
	Mode              string                 `json:"mode,omitempty"`
	Status            types.TaskStatus       `json:"status,omitempty"`
	Error             *ErrorInfo             `json:"error,omitempty"`
	Started           bool                   `json:"started,omitempty"`
	TransferredBytes  int64                  `json:"transferredBytes,omitempty"`
	TotalSize         int64                  `json:"totalSize,omitempty"`
	TransferRate      int64                  `json:"transferRate,omitempty"`
	TransferringFiles []*DownloadFileSummary `json:"transferringFiles,omitempty"`
}

type DownloadTaskDetail struct {
	FileList             []*DownloadFileDetail `json:"fileList,omitempty"`
	PathMappings         []types.PathMapping   `json:"pathMappings,omitempty"`
	Transport            types.TransportMode   `json:"transport"`
	Connections          int                   `json:"connections"`
	Streams              int                   `json:"streams"`
	FileConcurrency      int                   `json:"fileConcurrency,omitempty"`
	TaskID               string                `json:"taskId,omitempty"`
	TaskName             string                `json:"taskName,omitempty"`
	Mode                 string                `json:"mode,omitempty"`
	ServerAddr           string                `json:"serverAddr,omitempty"`
	TargetDir            string                `json:"targetDir,omitempty"`
	Status               types.TaskStatus      `json:"status,omitempty"`
	Error                *ErrorInfo            `json:"error,omitempty"`
	Started              bool                  `json:"started,omitempty"`
	AuthorizedFiles      []*DownloadFileDetail `json:"authorizedFiles,omitempty"`
	UnauthorizedFiles    []*DownloadFileDetail `json:"unauthorizedFiles,omitempty"`
	TransferredBytes     int64                 `json:"transferredBytes,omitempty"`
	NetworkReceivedBytes int64                 `json:"networkReceivedBytes,omitempty"`
	TotalSize            int64                 `json:"totalSize,omitempty"`
	TransferRate         int64                 `json:"transferRate,omitempty"`
	CreatedAt            time.Time             `json:"createdAt"`
	UpdatedAt            time.Time             `json:"updatedAt"`
	StartedAt            time.Time             `json:"startedAt,omitempty"`
	FinishedAt           time.Time             `json:"finishedAt,omitempty"`
}

type UploadFileDetail struct {
	Src              string     `json:"src,omitempty"`
	Dst              string     `json:"dst,omitempty"`
	Error            *ErrorInfo `json:"error,omitempty"`
	LocalRelPath     string     `json:"localRelPath,omitempty"`
	ObjectKey        string     `json:"objectKey,omitempty"`
	Size             int64      `json:"size,omitempty"`
	FileHash         string     `json:"fileHash,omitempty"`
	UploadURL        string     `json:"uploadUrl,omitempty"`
	Status           string     `json:"status,omitempty"`
	ChunkSize        int64      `json:"chunkSize,omitempty"`
	ChunkCount       int        `json:"chunkCount,omitempty"`
	Ready            bool       `json:"ready,omitempty"`
	Exists           bool       `json:"exists,omitempty"`
	TransferredBytes int64      `json:"transferredBytes,omitempty"`
	TransferRate     int64      `json:"transferRate,omitempty"`
	Uploaded         bool       `json:"uploaded,omitempty"`
	Verified         bool       `json:"verified,omitempty"`
	Message          string     `json:"message,omitempty"`
	LastModified     string     `json:"lastModified,omitempty"`
}

type UploadFileSummary struct {
	Src              string     `json:"src,omitempty"`
	Dst              string     `json:"dst,omitempty"`
	Error            *ErrorInfo `json:"error,omitempty"`
	LocalRelPath     string     `json:"localRelPath,omitempty"`
	ObjectKey        string     `json:"objectKey,omitempty"`
	Size             int64      `json:"size,omitempty"`
	Status           string     `json:"status,omitempty"`
	TransferredBytes int64      `json:"transferredBytes,omitempty"`
	TransferRate     int64      `json:"transferRate,omitempty"`
	Uploaded         bool       `json:"uploaded,omitempty"`
	Verified         bool       `json:"verified,omitempty"`
	Message          string     `json:"message,omitempty"`
}

type UploadTaskSummary struct {
	TaskID            string               `json:"taskId,omitempty"`
	TaskName          string               `json:"taskName,omitempty"`
	Mode              string               `json:"mode,omitempty"`
	Status            types.TaskStatus     `json:"status,omitempty"`
	Error             *ErrorInfo           `json:"error,omitempty"`
	Started           bool                 `json:"started,omitempty"`
	TransferredBytes  int64                `json:"transferredBytes,omitempty"`
	TotalSize         int64                `json:"totalSize,omitempty"`
	TransferRate      int64                `json:"transferRate,omitempty"`
	TransferringFiles []*UploadFileSummary `json:"transferringFiles,omitempty"`
}

type UploadTaskDetail struct {
	FileList         []*UploadFileDetail `json:"fileList,omitempty"`
	PathMappings     []types.PathMapping `json:"pathMappings,omitempty"`
	Transport        types.TransportMode `json:"transport"`
	Connections      int                 `json:"connections"`
	Streams          int                 `json:"streams"`
	FileConcurrency  int                 `json:"fileConcurrency,omitempty"`
	TaskID           string              `json:"taskId,omitempty"`
	TaskName         string              `json:"taskName,omitempty"`
	Mode             string              `json:"mode,omitempty"`
	ServerAddr       string              `json:"serverAddr,omitempty"`
	SourceDir        string              `json:"sourceDir,omitempty"`
	ServerTaskID     string              `json:"serverTaskId,omitempty"`
	Status           types.TaskStatus    `json:"status,omitempty"`
	Error            *ErrorInfo          `json:"error,omitempty"`
	Started          bool                `json:"started,omitempty"`
	ReadyFiles       []*UploadFileDetail `json:"readyFiles,omitempty"`
	ConflictFiles    []*UploadFileDetail `json:"conflictFiles,omitempty"`
	RejectedFiles    []*UploadFileDetail `json:"rejectedFiles,omitempty"`
	TransferredBytes int64               `json:"transferredBytes,omitempty"`
	NetworkSentBytes int64               `json:"networkSentBytes,omitempty"`
	TotalSize        int64               `json:"totalSize,omitempty"`
	TransferRate     int64               `json:"transferRate,omitempty"`
	CreatedAt        time.Time           `json:"createdAt"`
	UpdatedAt        time.Time           `json:"updatedAt"`
	StartedAt        time.Time           `json:"startedAt,omitempty"`
	FinishedAt       time.Time           `json:"finishedAt,omitempty"`
}

// TaskView explicitly converts shared internal task views into serve wire DTOs.
func TaskView(value any) any {
	switch view := value.(type) {
	case *types.DownloadTaskSummary:
		return downloadTaskSummary(view)
	case *types.DownloadTaskDetail:
		return downloadTaskDetail(view)
	case *types.UploadTaskSummary:
		return uploadTaskSummary(view)
	case *types.UploadTaskDetail:
		return uploadTaskDetail(view)
	default:
		return nil
	}
}

func downloadTaskSummary(view *types.DownloadTaskSummary) *DownloadTaskSummary {
	if view == nil {
		return &DownloadTaskSummary{}
	}
	files := make([]*DownloadFileSummary, 0, len(view.TransferingFiles))
	for _, file := range view.TransferingFiles {
		files = append(files, downloadFileSummary(view.Status, file))
	}
	return &DownloadTaskSummary{
		TaskID: view.TaskID, TaskName: view.TaskName, Mode: view.Mode, Status: view.Status,
		Error: taskError(view.Status, view.Cause), Started: view.Started,
		TransferredBytes: view.Transferred, TotalSize: view.TotalSize, TransferRate: view.Rate,
		TransferringFiles: files,
	}
}

func downloadTaskDetail(view *types.DownloadTaskDetail) *DownloadTaskDetail {
	if view == nil {
		return &DownloadTaskDetail{}
	}
	files := make([]*DownloadFileDetail, 0, len(view.Files))
	for _, file := range view.Files {
		files = append(files, downloadFileDetail(view.Status, file))
	}
	unauthorized := make([]*DownloadFileDetail, 0, len(view.UnauthorizedFiles))
	for _, file := range view.UnauthorizedFiles {
		unauthorized = append(unauthorized, downloadFileDetail(view.Status, file))
	}
	result := &DownloadTaskDetail{
		PathMappings: view.PathMappings,
		Transport:    view.Transport, Connections: view.Connections, Streams: view.Streams, FileConcurrency: view.FileConcurrency,
		TaskID: view.TaskID, TaskName: view.TaskName, Mode: view.Mode, ServerAddr: view.ServerAddr,
		TargetDir: view.TargetDir, Status: view.Status, Error: taskError(view.Status, view.Cause),
		Started: view.Started, AuthorizedFiles: files, UnauthorizedFiles: unauthorized,
		TransferredBytes: view.Transferred, NetworkReceivedBytes: view.NetworkReceived,
		TotalSize: view.TotalSize, TransferRate: view.Rate,
		CreatedAt: view.CreatedAt, UpdatedAt: view.UpdatedAt, StartedAt: view.StartedAt, FinishedAt: view.FinishedAt,
	}
	if len(view.PathMappings) > 0 {
		result.FileList = result.AuthorizedFiles
		result.AuthorizedFiles = nil
		result.UnauthorizedFiles = nil
		result.ServerAddr = strings.TrimPrefix(result.ServerAddr, "https://")
	}
	return result
}

func downloadFileDetail(status types.TaskStatus, view *types.FileInfoDetail) *DownloadFileDetail {
	if view == nil {
		return &DownloadFileDetail{}
	}
	chunks := make([]*ChunkDetail, 0, len(view.Chunks))
	for _, chunk := range view.Chunks {
		if chunk == nil {
			continue
		}
		chunks = append(chunks, &ChunkDetail{Index: chunk.Index, StartOffset: chunk.StartOffset, EndOffset: chunk.EndOffset, TransferredBytes: chunk.Transferred, Size: chunk.ChunkSize, Completed: chunk.Completed})
	}
	return &DownloadFileDetail{Src: view.Src, Dst: view.Dst, Error: fileError(status, view.Cause), LocalRelPath: legacyLocalPath(view.Dst, view.LocalPath), RemoteURL: view.RemotePath, Authorized: view.Authorized, Size: view.Size, TransferredBytes: view.Transferred, TransferRate: view.Rate, OverallChecksum: view.OverallChecksum, Received: view.Received, Verified: view.Verified, Chunks: chunks}
}

func downloadFileSummary(status types.TaskStatus, view *types.FileInfoSummary) *DownloadFileSummary {
	if view == nil {
		return &DownloadFileSummary{}
	}
	return &DownloadFileSummary{Src: view.Src, Dst: view.Dst, Error: fileError(status, view.Cause), LocalRelPath: legacyLocalPath(view.Dst, view.LocalPath), RemoteURL: view.RemotePath, Authorized: view.Authorized, Size: view.Size, TransferredBytes: view.Transferred, TransferRate: view.Rate, OverallChecksum: view.OverallChecksum, Received: view.Received, Verified: view.Verified}
}

func uploadTaskSummary(view *types.UploadTaskSummary) *UploadTaskSummary {
	if view == nil {
		return &UploadTaskSummary{}
	}
	files := make([]*UploadFileSummary, 0, len(view.TransferingFiles))
	for _, file := range view.TransferingFiles {
		files = append(files, uploadFileSummary(view.Status, file))
	}
	return &UploadTaskSummary{TaskID: view.TaskID, TaskName: view.TaskName, Mode: view.Mode, Status: view.Status, Error: taskError(view.Status, view.Cause), Started: view.Started, TransferredBytes: view.Transferred, TotalSize: view.TotalSize, TransferRate: view.Rate, TransferringFiles: files}
}

func uploadTaskDetail(view *types.UploadTaskDetail) *UploadTaskDetail {
	if view == nil {
		return &UploadTaskDetail{}
	}
	ready := uploadFileDetails(view.Status, view.Files)
	conflicts := uploadFileDetails(view.Status, view.ConflictFiles)
	rejected := uploadFileDetails(view.Status, view.RejectedFiles)
	result := &UploadTaskDetail{PathMappings: view.PathMappings, Transport: view.Transport, Connections: view.Connections, Streams: view.Streams, FileConcurrency: view.FileConcurrency, TaskID: view.TaskID, TaskName: view.TaskName, Mode: view.Mode, ServerAddr: view.ServerAddr, SourceDir: view.SourceDir, ServerTaskID: view.ServerTaskID, Status: view.Status, Error: taskError(view.Status, view.Cause), Started: view.Started, ReadyFiles: ready, ConflictFiles: conflicts, RejectedFiles: rejected, TransferredBytes: view.Transferred, NetworkSentBytes: view.NetworkSent, TotalSize: view.TotalSize, TransferRate: view.Rate, CreatedAt: view.CreatedAt, UpdatedAt: view.UpdatedAt, StartedAt: view.StartedAt, FinishedAt: view.FinishedAt}
	if len(view.PathMappings) > 0 {
		result.FileList = result.ReadyFiles
		result.ReadyFiles = nil
		result.ConflictFiles = nil
		result.RejectedFiles = nil
		result.ServerAddr = strings.TrimPrefix(result.ServerAddr, "https://")
	}
	return result
}

func uploadFileDetails(status types.TaskStatus, files []*types.UploadFileInfoDetail) []*UploadFileDetail {
	converted := make([]*UploadFileDetail, 0, len(files))
	for _, file := range files {
		if file == nil {
			continue
		}
		converted = append(converted, &UploadFileDetail{Src: file.Src, Dst: file.Dst, Error: fileError(status, file.Cause), LocalRelPath: legacyLocalPath(file.Dst, file.LocalPath), ObjectKey: file.ObjectKey, Size: file.Size, FileHash: file.FileHash, UploadURL: file.UploadURL, Status: file.Status, ChunkSize: file.ChunkSize, ChunkCount: file.ChunkCount, Ready: file.Ready, Exists: file.Exists, TransferredBytes: file.Transferred, TransferRate: file.Rate, Uploaded: file.Uploaded, Verified: file.Verified, Message: fileMessageForStatus(status, file.Message, file.ReasonCode, file.Cause), LastModified: file.LastModified})
	}
	return converted
}

func uploadFileSummary(status types.TaskStatus, file *types.UploadFileInfoSummary) *UploadFileSummary {
	if file == nil {
		return &UploadFileSummary{}
	}
	return &UploadFileSummary{Src: file.Src, Dst: file.Dst, Error: fileError(status, file.Cause), LocalRelPath: legacyLocalPath(file.Dst, file.LocalPath), ObjectKey: file.ObjectKey, Size: file.Size, Status: file.Status, TransferredBytes: file.Transferred, TransferRate: file.Rate, Uploaded: file.Uploaded, Verified: file.Verified, Message: fileMessageForStatus(status, file.Message, file.ReasonCode, file.Cause)}
}

func safeStoredError(raw, reason string) string {
	if strings.TrimSpace(raw) == "" {
		return ""
	}
	return Message(codeForReason(reason))
}

// fileError hides a previous round's file failure while the task is pending.
// The task keeps the internal error until Run initializes the next round.
func fileError(status types.TaskStatus, cause error) *ErrorInfo {
	if status == types.StatusPending || status == types.StatusStopped {
		return nil
	}
	return executionError(cause)
}

func fileMessage(raw, reason string, cause error) string {
	if value := executionError(cause); value != nil {
		return value.Message
	}
	return safeStoredError(raw, reason)
}

func fileMessageForStatus(status types.TaskStatus, raw, reason string, cause error) string {
	if (status == types.StatusPending || status == types.StatusStopped) && (cause != nil || strings.TrimSpace(reason) != "") {
		return ""
	}
	return fileMessage(raw, reason, cause)
}

func legacyLocalPath(destination, path string) string {
	if destination != "" {
		return ""
	}
	return path
}
