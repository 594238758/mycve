package serveapi

import (
	"bytes"
	"encoding/json"
	"fmt"

	"qtransc/internal/types"
)

// TaskCreateV2Request is the source/destination-directory creation schema.
// It converts directly to the common task input, independently of v1.
type TaskCreateV2Request struct {
	BearerToken          strictString        `json:"bearerToken,omitempty"`
	TaskID               strictString        `json:"taskId"`
	TaskPID              strictString        `json:"taskPid,omitempty"`
	EnterpriseID         strictString        `json:"enterpriseId,omitempty"`
	CallerVersion        strictString        `json:"callerVersion,omitempty"`
	ServerTaskID         strictString        `json:"serverTaskId,omitempty"`
	TaskName             strictString        `json:"taskName"`
	Mode                 strictString        `json:"mode"`
	Transport            strictString        `json:"transport,omitempty"`
	Connections          optionalInt         `json:"connections,omitempty"`
	Streams              optionalInt         `json:"streams,omitempty"`
	Transfers            optionalInt         `json:"transfers,omitempty"`
	LimitRateBytesPerSec positiveInt64       `json:"limitRateBytesPerSec,omitempty"`
	AutoRetry            strictBool          `json:"autoRetry,omitempty"`
	PathMappings         pathMappingRequests `json:"pathMappings"`
	ServerAddr           strictString        `json:"serverAddr"`
}

func (r TaskCreateV2Request) validateJSONFields(data []byte) error {
	return validateExactFields(data, "bearerToken", "taskId", "taskPid", "enterpriseId", "callerVersion", "serverTaskId", "taskName", "mode", "transport", "connections", "streams", "transfers", "limitRateBytesPerSec", "autoRetry", "serverAddr", "pathMappings")
}

type pathMappingRequest struct {
	Src strictString `json:"src"`
	Dst strictString `json:"dst"`
}

func (r *pathMappingRequest) UnmarshalJSON(data []byte) error {
	if bytes.Equal(bytes.TrimSpace(data), []byte("null")) {
		return fmt.Errorf("mapping must be an object")
	}
	if err := validateExactFields(data, "src", "dst"); err != nil {
		return err
	}
	type alias pathMappingRequest
	return json.Unmarshal(data, (*alias)(r))
}

type pathMappingRequests []pathMappingRequest

func (r *pathMappingRequests) UnmarshalJSON(data []byte) error {
	if bytes.Equal(bytes.TrimSpace(data), []byte("null")) {
		return fmt.Errorf("pathMappings must be an array")
	}
	type alias pathMappingRequests
	return json.Unmarshal(data, (*alias)(r))
}

func (r TaskCreateV2Request) TransferOverrides() types.TransferOverrides {
	return types.TransferOverrides{Connections: r.Connections.pointer(), Streams: r.Streams.pointer(), Transfers: r.Transfers.pointer()}
}

func (r TaskCreateV2Request) Internal() *types.TaskCreateRequest {
	// Keep an omitted/empty mapping array non-nil so common validation still
	// selects mapping input and rejects it, rather than falling back to v1.
	mappings := make([]types.PathMapping, len(r.PathMappings))
	for i, m := range r.PathMappings {
		mappings[i] = types.PathMapping{Src: string(m.Src), Dst: string(m.Dst)}
	}
	return &types.TaskCreateRequest{
		BearerToken:   string(r.BearerToken),
		TaskID:        string(r.TaskID),
		TaskPID:       string(r.TaskPID),
		EnterpriseID:  string(r.EnterpriseID),
		CallerVersion: string(r.CallerVersion),
		ServerTaskID:  string(r.ServerTaskID),
		TaskName:      string(r.TaskName),
		Mode:          string(r.Mode),
		Transport:     string(r.Transport),
		LimitRate:     int64(r.LimitRateBytesPerSec),
		AutoRetry:     bool(r.AutoRetry),
		ServerAddr:    string(r.ServerAddr),
		PathMappings:  mappings,
	}
}
