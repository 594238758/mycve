package serveapi

import (
	"context"
	"errors"
	"net"
	"net/http"
	"os"
	"strings"

	"qtransc/internal/authmanager"
	"qtransc/internal/clienterror"
	"qtransc/internal/downloadtask"
	"qtransc/internal/localfs"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/taskidclient"
	"qtransc/internal/transferlimits"
	"qtransc/internal/transferretry"
	"qtransc/internal/transportpool"
	"qtransc/internal/types"
	"qtransc/internal/uploadtask"
)

// classifyCause identifies structured failures using the execution registry.
// Request callers explicitly map only failures allowed before task admission.
func classifyCause(err error) Code {
	if err == nil {
		return CodeSuccess
	}

	switch {
	case errors.Is(err, localfs.ErrInsufficientSpace):
		return CodeInsufficientDiskSpace
	case errors.Is(err, uploadtask.ErrLocalFileChanged):
		return CodeLocalFileChanged
	case errors.Is(err, downloadtask.ErrIntegrityCheckFailed):
		return CodeIntegrityCheckFailed
	case errors.Is(err, downloadtask.ErrRemoteNotFound):
		return CodeRemoteResourceNotFound
	case errors.Is(err, downloadtask.ErrRemoteFileChanged):
		return CodeRemoteStateConflict
	case errors.Is(err, downloadtask.ErrAuthFailed):
		return CodeExecutionAuthRejected
	case errors.Is(err, downloadtask.ErrTargetDirNotAvailable):
		return CodeExecutionLocalPathUnavailable
	case errors.Is(err, downloadtask.ErrTargetDirNoSpace):
		return CodeInsufficientDiskSpace
	case errors.Is(err, downloadtask.ErrServerError):
		return CodeExecutionDownstreamUnavailable
	case os.IsNotExist(err):
		return CodeExecutionLocalResourceNotFound
	case os.IsPermission(err):
		return CodeExecutionLocalPathUnavailable
	case authmanager.IsNotInitialized(err), errors.Is(err, authmanager.ErrAccessTokenMissing), authmanager.IsModeLocked(err), errors.Is(err, authmanager.ErrAuthModeUnsupported):
		return CodeExecutionAuthConfigInvalid
	case errors.Is(err, authmanager.ErrAuthUnauthorized):
		return CodeExecutionAuthRejected
	case errors.Is(err, authmanager.ErrAuthLoginFailed), errors.Is(err, authmanager.ErrAuthRefreshFailed):
		return CodeExecutionDownstreamUnavailable
	case errors.Is(err, qtserverapi.ErrRetryWindowExhausted):
		return CodeExecutionDownstreamBusy
	}

	var localIO *transferretry.LocalIOError
	if errors.As(err, &localIO) {
		return CodeExecutionLocalPathUnavailable
	}
	var limit *transferlimits.Error
	if errors.As(err, &limit) {
		return codeForReason(limit.ReasonCode)
	}
	var clientErr *clienterror.Error
	if errors.As(err, &clientErr) {
		return codeForReason(clientErr.ReasonCode)
	}
	var eventCause *types.EventCause
	if errors.As(err, &eventCause) {
		return codeForReason(eventCause.ReasonCode)
	}
	var apiErr *qtserverapi.APIError
	if errors.As(err, &apiErr) {
		if code := codeForReason(apiErr.ReasonCode); code != CodeExecutionInternalError {
			return code
		}
		switch apiErr.Status {
		case http.StatusBadRequest:
			return CodeExecutionRequestInvalid
		case http.StatusUnauthorized, http.StatusForbidden:
			return CodeExecutionAuthRejected
		case http.StatusNotFound:
			return CodeRemoteResourceNotFound
		case http.StatusConflict:
			return CodeRemoteStateConflict
		case http.StatusTooManyRequests:
			return CodeExecutionDownstreamBusy
		case http.StatusBadGateway, http.StatusServiceUnavailable, http.StatusGatewayTimeout:
			return CodeExecutionDownstreamUnavailable
		}
		if apiErr.Status >= http.StatusInternalServerError {
			return CodeExecutionDownstreamUnavailable
		}
	}
	var capabilitiesErr *qtserverapi.CapabilitiesAccessError
	if errors.As(err, &capabilitiesErr) {
		return CodeExecutionDownstreamUnavailable
	}
	var versionErr *qtserverapi.UnsupportedAPIVersionError
	if errors.As(err, &versionErr) {
		return CodeExecutionCapabilityUnavailable
	}
	var capabilityErr *qtserverapi.CapabilityUnavailableError
	if errors.As(err, &capabilityErr) {
		return CodeExecutionCapabilityUnavailable
	}
	var anonymousErr *qtserverapi.AnonymousAccessUnavailableError
	if errors.As(err, &anonymousErr) {
		return CodeExecutionCapabilityUnavailable
	}
	var taskIDErr *taskidclient.RequestError
	if errors.As(err, &taskIDErr) {
		return CodeExecutionDownstreamUnavailable
	}
	var transportErr *transportpool.Error
	if errors.As(err, &transportErr) {
		if transportErr.State >= transportpool.RequestPossiblySent {
			return CodeOperationResultUnknown
		}
		switch transportErr.Kind {
		case transportpool.ErrorOriginLimit:
			return CodeExecutionDownstreamBusy
		case transportpool.ErrorConnect, transportpool.ErrorHandshake, transportpool.ErrorTimeout, transportpool.ErrorOpenOrigin, transportpool.ErrorPoolClosed:
			return CodeExecutionDownstreamUnavailable
		}
	}
	if errors.Is(err, context.DeadlineExceeded) {
		return CodeExecutionDownstreamUnavailable
	}
	var netErr net.Error
	if errors.As(err, &netErr) {
		return CodeExecutionDownstreamUnavailable
	}
	return CodeExecutionInternalError
}

func codeForReason(reason string) Code {
	switch strings.ToUpper(strings.TrimSpace(reason)) {
	case clienterror.CodeInvalidArgument, "INVALID_REQUEST", "INVALID_PATH", "INVALID_OBJECT_KEY":
		return CodeExecutionRequestInvalid
	case clienterror.CodeAuthConfigInvalid:
		return CodeExecutionAuthConfigInvalid
	case clienterror.CodeAuthLoginRejected, "UNAUTHORIZED", "INVALID_TOKEN", "FORBIDDEN":
		return CodeExecutionAuthRejected
	case clienterror.CodeAuthLoginFailed, clienterror.CodeAuthRefreshFailed, clienterror.CodeServerUnavailable, "DEPENDENCY_UNAVAILABLE":
		return CodeExecutionDownstreamUnavailable
	case clienterror.CodeAnonymousReadUnavailable, clienterror.CodeAnonymousWriteUnavailable, clienterror.CodeCapabilityUnavailable, "UNSUPPORTED_API_VERSION", "ROUTE_NOT_FOUND", "UNSUPPORTED_FILE_TYPE":
		return CodeExecutionCapabilityUnavailable
	case clienterror.CodeFileTooLarge:
		return CodeExecutionFileSizeLimitExceeded
	case clienterror.CodeTaskFileLimitExceeded:
		return CodeExecutionTaskFileLimitExceeded
	case clienterror.CodeTaskSizeLimitExceeded:
		return CodeExecutionTaskSizeLimitExceeded
	case clienterror.CodeLocalFileNotFound:
		return CodeExecutionLocalResourceNotFound
	case clienterror.CodeLocalPathInvalid:
		return CodeExecutionLocalPathUnavailable
	case "NOT_FOUND":
		return CodeRemoteResourceNotFound
	case "CONFLICT", "DIRECTORY_NOT_EMPTY":
		return CodeRemoteStateConflict
	case "NAMESPACE_BUSY", "NAMESPACE_LOCK_LOST", "RATE_LIMITED", "SESSION_BUSY":
		return CodeExecutionDownstreamBusy
	case clienterror.CodeMutationResultUnknown, clienterror.CodeRecursiveDeletePartial, "NAMESPACE_OPERATION_PARTIAL", "INTERNAL_ERROR":
		return CodeOperationResultUnknown
	default:
		return CodeExecutionInternalError
	}
}

// ClassifyAPI classifies a failed request without leaking execution-only codes.
func ClassifyAPI(err error) Code {
	if err == nil {
		return CodeSuccess
	}
	code := classifyCause(err)
	switch code {
	case CodeExecutionRequestInvalid:
		code = CodeRequestInvalid
	case CodeExecutionAuthConfigInvalid:
		code = CodeAuthConfigInvalid
	case CodeExecutionTaskFileLimitExceeded:
		code = CodeTaskFileLimitExceeded
	}
	code, _ = failureDefinition(code, false)
	return code
}

// ClassifyExecution classifies an accepted task or file execution failure.
func ClassifyExecution(err error) Code {
	if err == nil {
		return CodeSuccess
	}
	code, _ := failureDefinition(classifyCause(err), true)
	return code
}

// Classify is retained for internal callers of the request classifier.
func Classify(err error) Code { return ClassifyAPI(err) }
