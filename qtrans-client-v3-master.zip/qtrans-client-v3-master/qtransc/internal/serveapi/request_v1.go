package serveapi

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"

	"qtransc/internal/types"
)

type strictStrings []strictString

func (values *strictStrings) UnmarshalJSON(data []byte) error {
	if bytes.Equal(bytes.TrimSpace(data), []byte("null")) {
		return fmt.Errorf("must be an array")
	}
	var decoded []strictString
	if err := json.Unmarshal(data, &decoded); err != nil {
		return err
	}
	*values = decoded
	return nil
}

type taskFileRequests []TaskFileRequest

func (values *taskFileRequests) UnmarshalJSON(data []byte) error {
	if bytes.Equal(bytes.TrimSpace(data), []byte("null")) {
		return fmt.Errorf("must be an array")
	}
	var decoded []TaskFileRequest
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&decoded); err != nil {
		return err
	}
	var trailing any
	if err := decoder.Decode(&trailing); err != io.EOF {
		return fmt.Errorf("invalid file list")
	}
	*values = decoded
	return nil
}

// TaskFileRequest is the serve-only camelCase file schema.
type TaskFileRequest struct {
	LocalRelPath strictString `json:"localRelPath"`
	RemoteURL    strictString `json:"remoteUrl,omitempty"`
	ObjectKey    strictString `json:"objectKey,omitempty"`
}

func (request *TaskFileRequest) UnmarshalJSON(data []byte) error {
	if bytes.Equal(bytes.TrimSpace(data), []byte("null")) {
		return fmt.Errorf("file entry must be an object")
	}
	if err := validateExactFields(data, "localRelPath", "remoteUrl", "objectKey"); err != nil {
		return err
	}
	type alias TaskFileRequest
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	var decoded alias
	if err := decoder.Decode(&decoded); err != nil {
		return err
	}
	*request = TaskFileRequest(decoded)
	return nil
}

// TaskCreateRequest is the HTTP v1 task creation schema.
type TaskCreateRequest struct {
	BearerToken          strictString     `json:"bearerToken,omitempty"`
	TaskID               strictString     `json:"taskId"`
	TaskPID              strictString     `json:"taskPid,omitempty"`
	EnterpriseID         strictString     `json:"enterpriseId,omitempty"`
	CallerVersion        strictString     `json:"callerVersion,omitempty"`
	ServerTaskID         strictString     `json:"serverTaskId,omitempty"`
	TaskName             strictString     `json:"taskName"`
	Mode                 strictString     `json:"mode"`
	Transport            strictString     `json:"transport,omitempty"`
	Connections          optionalInt      `json:"connections,omitempty"`
	Streams              optionalInt      `json:"streams,omitempty"`
	Transfers            optionalInt      `json:"transfers,omitempty"`
	LimitRateBytesPerSec positiveInt64    `json:"limitRateBytesPerSec,omitempty"`
	AutoRetry            strictBool       `json:"autoRetry,omitempty"`
	ServerAddr           strictString     `json:"serverAddr"`
	FileList             taskFileRequests `json:"fileList"`
	TargetDir            strictString     `json:"targetDir,omitempty"`
	SourceDir            strictString     `json:"sourceDir,omitempty"`
	DirPaths             strictStrings    `json:"dirPaths,omitempty"`
}

func (request TaskCreateRequest) TransferOverrides() types.TransferOverrides {
	return types.TransferOverrides{
		Connections: request.Connections.pointer(),
		Streams:     request.Streams.pointer(),
		Transfers:   request.Transfers.pointer(),
	}
}

func (request TaskCreateRequest) Internal() *types.TaskCreateRequest {
	files := make([]types.TaskFileSpec, 0, len(request.FileList))
	for _, file := range request.FileList {
		files = append(files, types.TaskFileSpec{
			LocalRelPath: string(file.LocalRelPath),
			RemoteURL:    string(file.RemoteURL),
			ObjectKey:    string(file.ObjectKey),
		})
	}
	dirs := make([]string, 0, len(request.DirPaths))
	for _, path := range request.DirPaths {
		dirs = append(dirs, string(path))
	}
	return &types.TaskCreateRequest{
		BearerToken:   string(request.BearerToken),
		TaskID:        string(request.TaskID),
		TaskPID:       string(request.TaskPID),
		EnterpriseID:  string(request.EnterpriseID),
		CallerVersion: string(request.CallerVersion),
		ServerTaskID:  string(request.ServerTaskID),
		TaskName:      string(request.TaskName),
		Mode:          string(request.Mode),
		Transport:     string(request.Transport),
		LimitRate:     int64(request.LimitRateBytesPerSec),
		AutoRetry:     bool(request.AutoRetry),
		ServerAddr:    string(request.ServerAddr),
		FileList:      files,
		TargetDir:     string(request.TargetDir),
		SourceDir:     string(request.SourceDir),
		DirPaths:      dirs,
	}
}

func (request TaskCreateRequest) validateJSONFields(data []byte) error {
	return validateExactFields(data, "bearerToken", "taskId", "taskPid", "enterpriseId", "callerVersion", "serverTaskId", "taskName", "mode", "transport", "connections", "streams", "transfers", "limitRateBytesPerSec", "autoRetry", "serverAddr", "fileList", "targetDir", "sourceDir", "dirPaths")
}
