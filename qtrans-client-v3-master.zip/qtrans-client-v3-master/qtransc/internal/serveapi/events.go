package serveapi

import (
	"fmt"

	"qtransc/internal/types"
)

const (
	MessageTypeHeartbeat     = "qtrans.health.heartbeat"
	MessageTypeTaskStatus    = "qtrans.task.status"
	MessageTypeTaskDeleted   = "qtrans.task.delete"
	MessageTypeFileStatus    = "qtrans.file.status"
	MessageTypeChunkStatus   = "qtrans.chunk.status"
	MessageTypeTaskProgress  = "qtrans.task.progress"
	MessageTypeFileProgress  = "qtrans.file.progress"
	MessageTypeChunkProgress = "qtrans.chunk.progress"
)

type Envelope struct {
	MessageType string `json:"messageType"`
	Code        Code   `json:"code"`
	Message     string `json:"message"`
	Data        any    `json:"data"`
	Meta        *Meta  `json:"meta,omitempty"`
}

type heartbeatData struct {
	Timestamp string `json:"timestamp"`
}

type taskStatusData struct {
	TaskID string `json:"taskId"`
	Status string `json:"status"`
}

type taskDeletedData struct {
	TaskID string `json:"taskId"`
}

type fileStatusData struct {
	TaskID  string `json:"taskId"`
	FileKey string `json:"fileKey"`
	Status  string `json:"status"`
}

type chunkStatusData struct {
	TaskID     string `json:"taskId"`
	FileKey    string `json:"fileKey"`
	ChunkIndex int    `json:"chunkIndex"`
	Status     string `json:"status"`
}

type taskProgressData struct {
	TaskID      string `json:"taskId"`
	Total       int64  `json:"total"`
	Transferred int64  `json:"transferred"`
	Rate        int64  `json:"rate"`
}

type fileProgressData struct {
	TaskID      string `json:"taskId"`
	FileKey     string `json:"fileKey"`
	Total       int64  `json:"total"`
	Transferred int64  `json:"transferred"`
	Rate        int64  `json:"rate"`
}

type chunkProgressData struct {
	TaskID      string `json:"taskId"`
	FileKey     string `json:"fileKey"`
	ChunkIndex  int    `json:"chunkIndex"`
	Total       int64  `json:"total"`
	Transferred int64  `json:"transferred"`
	Rate        int64  `json:"rate"`
}

// EventEnvelope is the single internal-event to SSE-wire conversion point.
func EventEnvelope(event types.TaskEvent) (Envelope, error) {
	messageType, data, failed, err := eventData(event)
	if err != nil {
		return Envelope{}, err
	}
	envelope := Envelope{
		MessageType: messageType,
		Code:        CodeSuccess,
		Message:     Message(CodeSuccess),
		Data:        data,
	}
	if failed {
		code := CodeExecutionInternalError
		if event.Cause != nil {
			code = ClassifyExecution(event.Cause)
		}
		failure := ExecutionFailure(code)
		envelope.Code = failure.Code
		envelope.Message = failure.Message
		envelope.Meta = &failure.Meta
	}
	return envelope, nil
}

func eventData(event types.TaskEvent) (string, any, bool, error) {
	switch event.EventType {
	case types.EventTypeHeartbeat:
		data, ok := event.Data.(types.HeartbeatEventData)
		if !ok {
			return "", nil, false, fmt.Errorf("invalid heartbeat event data")
		}
		return MessageTypeHeartbeat, heartbeatData{Timestamp: data.Timestamp}, false, nil
	case types.EventTypeTaskStatus:
		data, ok := event.Data.(types.TaskStatusEventData)
		if !ok {
			return "", nil, false, fmt.Errorf("invalid task status event data")
		}
		if data.Status == types.TaskEventStatusDeleted {
			return MessageTypeTaskDeleted, taskDeletedData{TaskID: data.TaskID}, false, nil
		}
		if !isTaskStatus(data.Status) {
			return "", nil, false, fmt.Errorf("invalid task status %q", data.Status)
		}
		return MessageTypeTaskStatus, taskStatusData{TaskID: data.TaskID, Status: data.Status}, data.Status == string(types.StatusFailed), nil
	case types.EventTypeFileStatus:
		data, ok := event.Data.(types.FileStatusEventData)
		if !ok {
			return "", nil, false, fmt.Errorf("invalid file status event data")
		}
		return MessageTypeFileStatus, fileStatusData{TaskID: data.TaskID, FileKey: data.FileKey, Status: data.Status}, data.Status == types.FileEventStatusFailed, nil
	case types.EventTypeChunkStatus:
		data, ok := event.Data.(types.ChunkStatusEventData)
		if !ok {
			return "", nil, false, fmt.Errorf("invalid chunk status event data")
		}
		return MessageTypeChunkStatus, chunkStatusData{TaskID: data.TaskID, FileKey: data.FileKey, ChunkIndex: data.ChunkIndex, Status: data.Status}, false, nil
	case types.EventTypeTaskProgress:
		data, ok := event.Data.(types.TaskProgressEventData)
		if !ok {
			return "", nil, false, fmt.Errorf("invalid task progress event data")
		}
		return MessageTypeTaskProgress, taskProgressData{TaskID: data.TaskID, Total: data.Total, Transferred: data.Transfered, Rate: data.Rate}, false, nil
	case types.EventTypeFileProgress:
		data, ok := event.Data.(types.FileProgressEventData)
		if !ok {
			return "", nil, false, fmt.Errorf("invalid file progress event data")
		}
		return MessageTypeFileProgress, fileProgressData{TaskID: data.TaskID, FileKey: data.FileKey, Total: data.Total, Transferred: data.Transfered, Rate: data.Rate}, false, nil
	case types.EventTypeChunkProgress:
		data, ok := event.Data.(types.ChunkProgressEventData)
		if !ok {
			return "", nil, false, fmt.Errorf("invalid chunk progress event data")
		}
		return MessageTypeChunkProgress, chunkProgressData{TaskID: data.TaskID, FileKey: data.FileKey, ChunkIndex: data.ChunkIndex, Total: data.Total, Transferred: data.Transfered, Rate: data.Rate}, false, nil
	default:
		return "", nil, false, fmt.Errorf("unsupported event type %q", event.EventType)
	}
}

func isTaskStatus(status string) bool {
	switch types.TaskStatus(status) {
	case types.StatusPending, types.StatusRunning, types.StatusCompleted, types.StatusStopped, types.StatusFailed:
		return true
	default:
		return false
	}
}
