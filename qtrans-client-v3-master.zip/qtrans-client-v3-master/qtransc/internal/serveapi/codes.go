package serveapi

import "qtransc/internal/types"

// Error code values, messages, metadata, and classification boundaries implement
// the normative registry in qtransc/docs/qtransc-error-codes.md. When this file
// conflicts with that document, this implementation must be corrected.

// Code is the stable machine-readable result code exposed by qtransc serve.
type Code int

const (
	CodeSuccess Code = 0

	CodeRequestInvalid        Code = 30001
	CodeAccessDenied          Code = 30002
	CodeAuthConfigInvalid     Code = 30003
	CodeTaskAlreadyExists     Code = 30004
	CodeTaskNotFound          Code = 30005
	CodeTaskStateConflict     Code = 30006
	CodeTaskCapacityExceeded  Code = 30007
	CodeTaskFileLimitExceeded Code = 30008
	CodeServiceShuttingDown   Code = 30009
	CodeInternalError         Code = 30999

	CodeExecutionRequestInvalid        Code = 31001
	CodeExecutionAuthConfigInvalid     Code = 31002
	CodeExecutionAuthRejected          Code = 31003
	CodeExecutionFileSizeLimitExceeded Code = 31004
	CodeExecutionTaskFileLimitExceeded Code = 31005
	CodeExecutionTaskSizeLimitExceeded Code = 31006
	CodeExecutionLocalResourceNotFound Code = 31007
	CodeExecutionLocalPathUnavailable  Code = 31008
	CodeInsufficientDiskSpace          Code = 31009
	CodeLocalFileChanged               Code = 31010
	CodeRemoteResourceNotFound         Code = 31011
	CodeExecutionCapabilityUnavailable Code = 31012
	CodeIntegrityCheckFailed           Code = 31013
	CodeRemoteStateConflict            Code = 31014
	CodeExecutionDownstreamUnavailable Code = 31015
	CodeExecutionDownstreamBusy        Code = 31016
	CodeOperationResultUnknown         Code = 31017
	CodeExecutionInternalError         Code = 31999
)

// Meta is the stable caller guidance attached to every failed serve response.
type Meta struct {
	Retryable bool `json:"retryable"`
	Visible   bool `json:"visible"`
}

type codeDefinition struct {
	message string
	meta    Meta
}

// codeDefinitions is the compile-time implementation of the normative registry.
var codeDefinitions = map[Code]codeDefinition{
	CodeSuccess:                        {message: "Success"},
	CodeRequestInvalid:                 {message: "QTrans request invalid", meta: Meta{Retryable: false, Visible: false}},
	CodeAccessDenied:                   {message: "QTrans access denied", meta: Meta{Retryable: false, Visible: false}},
	CodeAuthConfigInvalid:              {message: "Authentication configuration invalid", meta: Meta{Retryable: false, Visible: false}},
	CodeTaskAlreadyExists:              {message: "Task already exists", meta: Meta{Retryable: false, Visible: false}},
	CodeTaskNotFound:                   {message: "Task not found", meta: Meta{Retryable: false, Visible: false}},
	CodeTaskStateConflict:              {message: "Task state conflict", meta: Meta{Retryable: false, Visible: false}},
	CodeTaskCapacityExceeded:           {message: "Task capacity exceeded", meta: Meta{Retryable: true, Visible: false}},
	CodeTaskFileLimitExceeded:          {message: "Task file limit exceeded", meta: Meta{Retryable: false, Visible: true}},
	CodeServiceShuttingDown:            {message: "QTrans service shutting down", meta: Meta{Retryable: false, Visible: false}},
	CodeInternalError:                  {message: "QTrans internal error", meta: Meta{Retryable: false, Visible: true}},
	CodeExecutionRequestInvalid:        {message: "QTrans request invalid", meta: Meta{Retryable: false, Visible: false}},
	CodeExecutionAuthConfigInvalid:     {message: "Authentication configuration invalid", meta: Meta{Retryable: false, Visible: false}},
	CodeExecutionAuthRejected:          {message: "Authentication rejected", meta: Meta{Retryable: false, Visible: false}},
	CodeExecutionFileSizeLimitExceeded: {message: "File size limit exceeded", meta: Meta{Retryable: false, Visible: true}},
	CodeExecutionTaskFileLimitExceeded: {message: "Task file limit exceeded", meta: Meta{Retryable: false, Visible: true}},
	CodeExecutionTaskSizeLimitExceeded: {message: "Task size limit exceeded", meta: Meta{Retryable: false, Visible: true}},
	CodeExecutionLocalResourceNotFound: {message: "Local resource not found", meta: Meta{Retryable: false, Visible: true}},
	CodeExecutionLocalPathUnavailable:  {message: "Local path unavailable", meta: Meta{Retryable: false, Visible: true}},
	CodeInsufficientDiskSpace:          {message: "Insufficient disk space", meta: Meta{Retryable: false, Visible: true}},
	CodeLocalFileChanged:               {message: "Local file changed", meta: Meta{Retryable: false, Visible: false}},
	CodeRemoteResourceNotFound:         {message: "Remote resource not found", meta: Meta{Retryable: true, Visible: true}},
	CodeExecutionCapabilityUnavailable: {message: "Required capability unavailable", meta: Meta{Retryable: false, Visible: true}},
	CodeIntegrityCheckFailed:           {message: "Integrity check failed", meta: Meta{Retryable: true, Visible: false}},
	CodeRemoteStateConflict:            {message: "Remote state conflict", meta: Meta{Retryable: true, Visible: false}},
	CodeExecutionDownstreamUnavailable: {message: "Downstream service unavailable", meta: Meta{Retryable: true, Visible: true}},
	CodeExecutionDownstreamBusy:        {message: "Downstream service busy", meta: Meta{Retryable: true, Visible: false}},
	CodeOperationResultUnknown:         {message: "Operation result unknown", meta: Meta{Retryable: false, Visible: true}},
	CodeExecutionInternalError:         {message: "QTrans internal error", meta: Meta{Retryable: false, Visible: true}},
}

// Message returns the fixed, safe wire message for code.
func Message(code Code) string {
	if definition, ok := codeDefinitions[code]; ok {
		return definition.message
	}
	return codeDefinitions[CodeInternalError].message
}

// Response is the only JSON response envelope emitted by qtransc serve.
type Response struct {
	Code    Code   `json:"code"`
	Message string `json:"message"`
	Data    any    `json:"data,omitempty"`
	Meta    *Meta  `json:"meta,omitempty"`
}

func Success(data any) Response {
	return Response{Code: CodeSuccess, Message: Message(CodeSuccess), Data: data}
}

// Failure constructs a failed API request, never an execution result.
func Failure(code Code) Response {
	code, definition := failureDefinition(code, false)
	meta := definition.meta
	return Response{Code: code, Message: definition.message, Meta: &meta}
}

// ErrorInfo is the execution error shared by task/file snapshots and SSE.
type ErrorInfo struct {
	Code    Code   `json:"code"`
	Message string `json:"message"`
	Meta    Meta   `json:"meta"`
}

func ExecutionFailure(code Code) ErrorInfo {
	code, definition := failureDefinition(code, true)
	return ErrorInfo{Code: code, Message: definition.message, Meta: definition.meta}
}

func executionError(cause error) *ErrorInfo {
	if cause == nil {
		return nil
	}
	value := ExecutionFailure(ClassifyExecution(cause))
	return &value
}

func taskError(status types.TaskStatus, cause error) *ErrorInfo {
	if status != types.StatusFailed {
		return nil
	}
	value := ExecutionFailure(ClassifyExecution(cause))
	return &value
}

func failureDefinition(code Code, execution bool) (Code, codeDefinition) {
	definition, ok := codeDefinitions[code]
	valid := code >= 30000 && code < 31000
	fallback := CodeInternalError
	if execution {
		valid = code >= 31000 && code < 32000
		fallback = CodeExecutionInternalError
	}
	if !ok || !valid || code == CodeExecutionTaskSizeLimitExceeded {
		code = fallback
		definition = codeDefinitions[code]
	}
	return code, definition
}
