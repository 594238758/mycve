// Package average provides various averaging algorithms including sliding window and exponential moving average.
// 平均算法包，提供滑动窗口平均和指数移动平均等算法
package average

import (
	"sync"
)

// SMA represents a Simple Moving Average calculator using sliding window
// 使用滑动窗口的简单移动平均算法
type SMA struct {
	mu         sync.Mutex
	values     []float64 // 存储窗口内的数值
	windowSize int       // 窗口大小
	index      int       // 当前写入位置
	count      int       // 当前已填充的数据数量
	sum        float64   // 当前窗口内数值之和（优化计算）
}

// NewSMA creates a new Simple Moving Average calculator using sliding window
// windowSize: 窗口大小，必须大于0
// 使用滑动窗口实现，时间复杂度 O(1)，空间复杂度 O(windowSize)
func NewSMA(windowSize int) *SMA {
	if windowSize <= 0 {
		windowSize = 10 // 默认窗口大小
	}

	return &SMA{
		values:     make([]float64, windowSize),
		windowSize: windowSize,
	}
}

// Update adds a new value to the sliding window and returns the current average
// 添加新数值到滑动窗口，如果超过窗口大小会移除最早的值，然后返回当前平均值
func (sma *SMA) Update(value float64) float64 {
	sma.mu.Lock()
	defer sma.mu.Unlock()

	// 如果窗口已满，减去即将被替换的值
	if sma.count == sma.windowSize {
		sma.sum -= sma.values[sma.index]
	}

	// 存储新值并更新总和
	sma.values[sma.index] = value
	sma.sum += value

	// 更新索引和计数
	sma.index = (sma.index + 1) % sma.windowSize
	if sma.count < sma.windowSize {
		sma.count++
	}

	// 返回当前平均值
	return sma.sum / float64(sma.count)
}

// Value returns the current average without adding a new sample
// 返回当前平均值，不添加新样本
func (sma *SMA) Value() float64 {
	sma.mu.Lock()
	defer sma.mu.Unlock()

	if sma.count == 0 {
		return 0
	}
	return sma.sum / float64(sma.count)
}

// Reset resets the SMA to its initial state
// 重置SMA到初始状态
func (sma *SMA) Reset() {
	sma.mu.Lock()
	defer sma.mu.Unlock()

	sma.index = 0
	sma.count = 0
	sma.sum = 0
	// 清空数组
	for i := range sma.values {
		sma.values[i] = 0
	}
}

// IsReady returns whether the SMA has received at least one value
// 返回SMA是否已接收至少一个值
func (sma *SMA) IsReady() bool {
	sma.mu.Lock()
	defer sma.mu.Unlock()
	return sma.count > 0
}

// IsFull returns whether the sliding window is full
// 返回滑动窗口是否已满 (SMA特有的附加方法)
func (sma *SMA) IsFull() bool {
	sma.mu.Lock()
	defer sma.mu.Unlock()
	return sma.count == sma.windowSize
}

// WindowSize returns the window size
// 返回窗口大小 (SMA特有的附加方法)
func (sma *SMA) WindowSize() int {
	return sma.windowSize
}

// Count returns the current number of values in the window
// 返回窗口中当前值的数量 (SMA特有的附加方法)
func (sma *SMA) Count() int {
	sma.mu.Lock()
	defer sma.mu.Unlock()
	return sma.count
}
