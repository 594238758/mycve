package average

import (
	"sync"
)

// ExponentialMovingAverage represents an Exponential Moving Average calculator
// 指数移动平均算法实现
type ExponentialMovingAverage struct {
	mu          sync.RWMutex
	alpha       float64 // 平滑因子 (0, 1]
	value       float64 // 当前平均值
	initialized bool    // 是否已初始化
}

// NewEMA creates a new Exponential Moving Average calculator
// alpha: 平滑因子，取值范围 (0, 1]
//   - 较小值 (0.1-0.2): 更平滑，响应较慢
//   - 较大值 (0.6-0.8): 较少平滑，响应较快
//   - 默认值: 0.2 提供良好的平滑性和响应性平衡
func NewEMA(alpha ...float64) *ExponentialMovingAverage {
	smoothingFactor := 0.2 // 默认平滑因子
	if len(alpha) > 0 && alpha[0] > 0 && alpha[0] <= 1 {
		smoothingFactor = alpha[0]
	}

	return &ExponentialMovingAverage{
		alpha: smoothingFactor,
	}
}

// Update adds a new value to the EMA and returns the smoothed result
// 添加新值到EMA并返回平滑后的结果
func (e *ExponentialMovingAverage) Update(value float64) float64 {
	e.mu.Lock()
	defer e.mu.Unlock()

	if !e.initialized {
		e.value = value
		e.initialized = true
	} else {
		// EMA公式: new_value = alpha * current + (1 - alpha) * previous
		e.value = e.alpha*value + (1-e.alpha)*e.value
	}

	return e.value
}

// Value returns the current smoothed value without adding a new sample
// 返回当前平滑值，不添加新样本
func (e *ExponentialMovingAverage) Value() float64 {
	e.mu.RLock()
	defer e.mu.RUnlock()
	return e.value
}

// Reset resets the EMA to its initial state
// 重置EMA到初始状态
func (e *ExponentialMovingAverage) Reset() {
	e.mu.Lock()
	defer e.mu.Unlock()

	e.value = 0
	e.initialized = false
}

// IsReady returns whether the EMA has received at least one value
// 返回EMA是否已接收至少一个值
func (e *ExponentialMovingAverage) IsReady() bool {
	e.mu.RLock()
	defer e.mu.RUnlock()
	return e.initialized
}

// SetAlpha updates the alpha value (additional method for EMA)
// 更新alpha值 (EMA特有的附加方法)
func (e *ExponentialMovingAverage) SetAlpha(alpha float64) {
	if alpha <= 0 || alpha > 1 {
		return // 无效alpha值，忽略
	}

	e.mu.Lock()
	defer e.mu.Unlock()
	e.alpha = alpha
}

// GetAlpha returns the current alpha value (additional method for EMA)
// 返回当前alpha值 (EMA特有的附加方法)
func (e *ExponentialMovingAverage) GetAlpha() float64 {
	e.mu.RLock()
	defer e.mu.RUnlock()
	return e.alpha
}
