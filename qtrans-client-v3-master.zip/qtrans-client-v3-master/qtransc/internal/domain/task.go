package domain

import (
	"context"
	"errors"
	"time"

	"qtransc/internal/types"
)

// TaskType 定义任务类型
type TaskType string

const (
	TaskTypeDownload TaskType = "download"
	TaskTypeUpload   TaskType = "upload"
)

// ErrInvalidTaskState reports a lifecycle operation that is not allowed from
// the task's current state. Managers translate it into their own contract error.
var ErrInvalidTaskState = errors.New("task state does not allow this operation")

// TaskBasicStatus is the lock-consistent status snapshot used by the manager.
// It deliberately does not include files, chunks or execution resources.
type TaskBasicStatus struct {
	Status     types.TaskStatus
	Error      error
	Started    bool
	StartedAt  time.Time
	FinishedAt time.Time
}

// TaskSnapshot is the stable detail view returned by Task.Snapshot. Concrete
// tasks return *types.DownloadTaskDetail or *types.UploadTaskDetail; the serve
// conversion layer maps those internal types to the wire DTO.
type TaskSnapshot = any

// TaskSummary is the concise view returned by Task.ToSummary.
type TaskSummary = any

// Task 是所有任务的抽象接口。
//
// Run/Stop/Retry are the only lifecycle operations. Task implementations are
// the sole owner of their status. Run starts one execution round without
// blocking; a task created by the manager starts as pending.
type Task interface {
	GetID() string
	GetTaskPID() string
	GetEnterpriseID() string
	GetName() string
	GetType() TaskType

	Run(ctx context.Context) error
	Stop() error
	Retry() error

	GetStatus() TaskBasicStatus
	Snapshot() TaskSnapshot
	ToSummary() TaskSummary
}
