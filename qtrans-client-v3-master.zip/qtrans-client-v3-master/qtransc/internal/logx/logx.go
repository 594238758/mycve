// Package logx 提供了基于slog库的日志封装
// 支持默认输出到终端，以及配置后输出到文件并进行日志切分
package logx

import (
	"log/slog"
	"sync"

	"qtransc/internal/config"

	"github.com/gin-gonic/gin"
	"gopkg.in/natefinch/lumberjack.v2"
)

var writerMu sync.Mutex
var currentWriter *lumberjack.Logger

// Init 初始化默认 logger，并让应用日志和 Gin 日志写入同一个轮转文件。
func Init(conf config.LogConfig) error {
	// 转换日志等级
	var level slog.Level
	if err := level.UnmarshalText([]byte(conf.Level)); err != nil {
		level = slog.LevelInfo
	}

	engineWriter := &lumberjack.Logger{
		Filename:   conf.EngineLogPath,
		MaxSize:    conf.Rotation.MaxSize,
		MaxBackups: conf.Rotation.MaxBackups,
		MaxAge:     conf.Rotation.MaxAge,
		Compress:   conf.Rotation.Compress,
	}

	handler := slog.NewJSONHandler(engineWriter, &slog.HandlerOptions{Level: level})
	slog.SetDefault(slog.New(handler))
	RedirectStdLogToSlog(slog.Default())

	gin.DefaultWriter = engineWriter
	gin.DefaultErrorWriter = engineWriter
	writerMu.Lock()
	currentWriter = engineWriter
	writerMu.Unlock()
	return nil
}

// Close releases the configured file writer after all producers have stopped.
func Close() error {
	writerMu.Lock()
	writer := currentWriter
	currentWriter = nil
	writerMu.Unlock()
	if writer != nil {
		return writer.Close()
	}
	return nil
}
