package logx

import (
	"log"
	"log/slog"
	"strings"
)

type stdLogBridge struct {
	logger *slog.Logger
}

func (w *stdLogBridge) Write(p []byte) (int, error) {
	if w != nil && w.logger != nil {
		if msg := strings.TrimSpace(string(p)); msg != "" {
			w.logger.Warn(msg)
		}
	}
	return len(p), nil
}

func RedirectStdLogToSlog(logger *slog.Logger) {
	if logger == nil {
		logger = slog.Default()
	}
	log.SetFlags(0)
	log.SetPrefix("")
	log.SetOutput(&stdLogBridge{logger: logger})
}
