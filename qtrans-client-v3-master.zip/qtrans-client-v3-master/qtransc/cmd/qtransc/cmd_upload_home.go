package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"strings"

	"qtransc/internal/netclient"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/types"

	"github.com/spf13/cobra"
)

var (
	ulistJSON bool
)

type uploadListOptions struct {
	RawURL    string
	Token     string
	JSON      bool
	Transport types.TransportMode
}

var ulistCmd = &cobra.Command{
	Use:   "ulist [remote-directory]",
	Short: "Browse the current user's upload home on qtserver",
	Args:  cobra.MaximumNArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		transportMode, err := types.ParseTransportMode(cliTransport)
		if err != nil {
			return sanitizeCLIError(err)
		}
		remotePath := "/"
		if len(args) == 1 {
			remotePath, err = normalizeRemoteAbsolutePath(args[0], true)
			if err != nil {
				return sanitizeCLIError(fmt.Errorf("remote directory: %w", err))
			}
		}
		remoteURL, err := canonicalRemoteAddress(cliServer, remotePath, transportMode)
		if err != nil {
			return sanitizeCLIError(err)
		}
		bearerToken, err := requiredCLIBearerToken()
		if err != nil {
			return sanitizeCLIError(err)
		}
		return formatBrowseCLIError(remotePath, executeUList(cmd.Context(), os.Stdout, uploadListOptions{
			RawURL:    remoteURL,
			Token:     bearerToken,
			JSON:      ulistJSON,
			Transport: transportMode,
		}))
	},
}

var umkdirCmd = &cobra.Command{
	Use:   "umkdir <remote-directory>",
	Short: "Create a directory in the current user's upload home",
	Args:  cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		transportMode, err := types.ParseTransportMode(cliTransport)
		if err != nil {
			return sanitizeCLIError(err)
		}
		remotePath, err := normalizeRemoteAbsolutePath(args[0], false)
		if err != nil {
			return sanitizeCLIError(fmt.Errorf("remote directory: %w", err))
		}
		remoteURL, err := canonicalRemoteAddress(cliServer, remotePath, transportMode)
		if err != nil {
			return sanitizeCLIError(err)
		}
		bearerToken, err := requiredCLIBearerToken()
		if err != nil {
			return sanitizeCLIError(err)
		}
		return sanitizeCLIError(executeUMkdir(cmd.Context(), os.Stdout, remoteURL, bearerToken, transportMode))
	},
}

var umoveCmd = &cobra.Command{
	Use:   "umove <remote-source> <remote-destination>",
	Short: "Move or rename a path in the current user's upload home",
	Args:  cobra.ExactArgs(2),
	RunE: func(cmd *cobra.Command, args []string) error {
		transportMode, err := types.ParseTransportMode(cliTransport)
		if err != nil {
			return sanitizeCLIError(err)
		}
		sourcePath, err := normalizeRemoteAbsolutePath(args[0], false)
		if err != nil {
			return sanitizeCLIError(fmt.Errorf("remote source: %w", err))
		}
		destinationPath, err := normalizeRemoteAbsolutePath(args[1], false)
		if err != nil {
			return sanitizeCLIError(fmt.Errorf("remote destination: %w", err))
		}
		sourceURL, err := canonicalRemoteAddress(cliServer, sourcePath, transportMode)
		if err != nil {
			return sanitizeCLIError(err)
		}
		destinationURL, err := canonicalRemoteAddress(cliServer, destinationPath, transportMode)
		if err != nil {
			return sanitizeCLIError(err)
		}
		bearerToken, err := requiredCLIBearerToken()
		if err != nil {
			return sanitizeCLIError(err)
		}
		return sanitizeCLIError(executeUMove(cmd.Context(), os.Stdout, sourceURL, destinationURL, bearerToken, transportMode))
	},
}

var udeleteCmd = &cobra.Command{
	Use:   "udelete <remote-path>",
	Short: "Delete a path in the current user's upload home",
	Args:  cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		transportMode, err := types.ParseTransportMode(cliTransport)
		if err != nil {
			return sanitizeCLIError(err)
		}
		remotePath, err := normalizeRemoteAbsolutePath(args[0], false)
		if err != nil {
			return sanitizeCLIError(fmt.Errorf("remote path: %w", err))
		}
		remoteURL, err := canonicalRemoteAddress(cliServer, remotePath, transportMode)
		if err != nil {
			return sanitizeCLIError(err)
		}
		bearerToken, err := requiredCLIBearerToken()
		if err != nil {
			return sanitizeCLIError(err)
		}
		return sanitizeCLIError(executeUDelete(cmd.Context(), os.Stdout, remoteURL, bearerToken, transportMode))
	},
}

func initUploadHomeFlags() {
	ulistCmd.Flags().BoolVar(&ulistJSON, "json", false, "write the upload browse response JSON to stdout")
}

func executeUList(ctx context.Context, out io.Writer, opts uploadListOptions) error {
	if ctx == nil {
		ctx = context.Background()
	}
	configureCLILogger(cliDebug)

	parsed, err := ParseQtransURL(opts.RawURL, opts.Transport)
	if err != nil {
		return err
	}
	location := formatBrowseLocation(parsed)
	effectiveToken, err := resolveUploadHomeAccess(parsed, opts.Token, false)
	if err != nil {
		return err
	}

	network, err := newClientForTransport(opts.Transport, 1, 1)
	if err != nil {
		return fmt.Errorf("failed to initialize %s client pool: %w", opts.Transport, err)
	}
	defer network.Close()

	requestURL, err := buildUploadBrowseURL(parsed.ServerURL, parsed.ObjectKey)
	if err != nil {
		return err
	}
	body, err := executeUploadHomeRequest(ctx, http.MethodGet, requestURL, effectiveToken, nil, network)
	if err != nil {
		return fmt.Errorf("upload browse request failed: %w", err)
	}

	if opts.JSON {
		var browseResp types.UploadBrowseResponse
		if err := json.Unmarshal(body, &browseResp); err != nil {
			var pretty bytes.Buffer
			if err := json.Indent(&pretty, body, "", "  "); err == nil {
				_, _ = fmt.Fprintln(out, pretty.String())
				return nil
			}
			_, _ = fmt.Fprintln(out, string(body))
			return nil
		}
		browseResp.ObjectPath = browseResp.Path
		browseResp.Path = location
		encoded, err := json.MarshalIndent(&browseResp, "", "  ")
		if err != nil {
			return fmt.Errorf("encode upload browse response: %w", err)
		}
		_, _ = fmt.Fprintln(out, string(encoded))
		return nil
	}

	var browseResp types.UploadBrowseResponse
	if err := json.Unmarshal(body, &browseResp); err != nil {
		return fmt.Errorf("decode upload browse response: %w", err)
	}
	renderUploadBrowseText(out, location, &browseResp)
	return nil
}

func executeUMkdir(ctx context.Context, out io.Writer, rawURL, token string, transport types.TransportMode) error {
	resp, host, err := executeUploadHomeMutation[types.UploadMkdirResponse](ctx, rawURL, token, transport, true, "/u/mkdir", types.UploadMkdirRequest{
		Path: mustUploadHomeObjectKey(rawURL, transport),
	})
	if err != nil {
		return err
	}
	_, _ = fmt.Fprintf(out, "directory ready: %s\n", formatUploadHomeLocation(host, resp.Path))
	return nil
}

func executeUMove(ctx context.Context, out io.Writer, sourceURL, destinationURL, token string, transport types.TransportMode) error {
	sourceParsed, err := ParseQtransURL(sourceURL, transport)
	if err != nil {
		return err
	}
	destinationParsed, err := ParseQtransURL(destinationURL, transport)
	if err != nil {
		return err
	}

	serverURL, effectiveToken, err := resolveUploadHomeAccessForURLs([]*QtransURL{sourceParsed, destinationParsed}, token, true)
	if err != nil {
		return err
	}
	if ctx == nil {
		ctx = context.Background()
	}
	configureCLILogger(cliDebug)

	network, err := newClientForTransport(transport, 1, 1)
	if err != nil {
		return fmt.Errorf("failed to initialize %s client pool: %w", transport, err)
	}
	defer network.Close()

	requestURL, err := qtserverurl.JoinEndpoint(serverURL, "/u/move")
	if err != nil {
		return err
	}
	body, err := executeUploadHomeRequest(ctx, http.MethodPost, requestURL, effectiveToken, types.UploadMoveRequest{
		SourcePath:      sourceParsed.ObjectKey,
		DestinationPath: destinationParsed.ObjectKey,
	}, network)
	if err != nil {
		return err
	}

	var resp types.UploadMoveResponse
	if err := json.Unmarshal(body, &resp); err != nil {
		return fmt.Errorf("decode upload move response: %w", err)
	}
	_, _ = fmt.Fprintf(out, "path moved: %s -> %s\n", formatUploadHomeLocation(sourceParsed.Host, resp.SourcePath), formatUploadHomeLocation(sourceParsed.Host, resp.DestinationPath))
	return nil
}

func executeUDelete(ctx context.Context, out io.Writer, rawURL, token string, transport types.TransportMode) error {
	resp, host, err := executeUploadHomeMutation[types.UploadDeleteResponse](ctx, rawURL, token, transport, true, "/u/delete", types.UploadDeleteRequest{
		Path: mustUploadHomeObjectKey(rawURL, transport),
	})
	if err != nil {
		return err
	}
	_, _ = fmt.Fprintf(out, "path deleted: %s\n", formatUploadHomeLocation(host, resp.Path))
	return nil
}

func executeUploadHomeMutation[T any](ctx context.Context, rawURL, token string, transport types.TransportMode, requirePath bool, apiPath string, payload any) (*T, string, error) {
	parsed, err := ParseQtransURL(rawURL, transport)
	if err != nil {
		return nil, "", err
	}
	effectiveToken, err := resolveUploadHomeAccess(parsed, token, requirePath)
	if err != nil {
		return nil, "", err
	}
	if ctx == nil {
		ctx = context.Background()
	}
	configureCLILogger(cliDebug)

	network, err := newClientForTransport(transport, 1, 1)
	if err != nil {
		return nil, "", fmt.Errorf("failed to initialize %s client pool: %w", transport, err)
	}
	defer network.Close()

	requestURL, err := qtserverurl.JoinEndpoint(parsed.ServerURL, apiPath)
	if err != nil {
		return nil, "", err
	}
	body, err := executeUploadHomeRequest(ctx, http.MethodPost, requestURL, effectiveToken, payload, network)
	if err != nil {
		return nil, "", err
	}

	var resp T
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil, "", fmt.Errorf("decode upload-home response: %w", err)
	}
	return &resp, parsed.Host, nil
}

func executeUploadHomeRequest(ctx context.Context, method, requestURL, token string, payload any, network *netclient.Client) ([]byte, error) {
	var bodyReader io.Reader
	if payload != nil {
		data, err := json.Marshal(payload)
		if err != nil {
			return nil, fmt.Errorf("encode request body: %w", err)
		}
		bodyReader = bytes.NewReader(data)
	}

	req, err := http.NewRequestWithContext(ctx, method, requestURL, bodyReader)
	if err != nil {
		return nil, fmt.Errorf("create request: %w", err)
	}
	req.Header.Set("Authorization", "Bearer "+token)
	if payload != nil {
		req.Header.Set("Content-Type", "application/json")
	}

	client, releaseClient, err := network.Acquire(ctx, req.URL.String())
	if err != nil {
		return nil, err
	}
	defer releaseClient()

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("read response: %w", err)
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("status=%d body=%s", resp.StatusCode, strings.TrimSpace(string(body)))
	}
	return body, nil
}

func buildUploadBrowseURL(serverURL string, path string) (string, error) {
	requestTarget, err := qtserverurl.JoinEndpoint(serverURL, "/u/browse")
	if err != nil {
		return "", err
	}
	parsed, err := url.Parse(requestTarget)
	if err != nil {
		return "", fmt.Errorf("invalid server URL %q: %w", serverURL, err)
	}
	query := parsed.Query()
	query.Set("path", path)
	parsed.RawQuery = query.Encode()
	return parsed.String(), nil
}

func renderUploadBrowseText(out io.Writer, location string, browseResp *types.UploadBrowseResponse) {
	if browseResp == nil {
		return
	}
	entries := make([]browseRenderEntry, 0, len(browseResp.Entries))
	for _, entry := range browseResp.Entries {
		entries = append(entries, browseRenderEntry{
			Name:         entry.Name,
			EntryType:    entry.EntryType,
			Size:         entry.Size,
			LastModified: entry.LastModified,
		})
	}
	renderBrowseTable(out, location, entries)
}

func formatUploadHomeLocation(host, objectPath string) string {
	parsed := &QtransURL{Host: host, ObjectKey: strings.Trim(objectPath, "/")}
	return formatBrowseLocation(parsed)
}

func mustUploadHomeObjectKey(rawURL string, transport types.TransportMode) string {
	parsed, err := ParseQtransURL(rawURL, transport)
	if err != nil {
		return ""
	}
	return parsed.ObjectKey
}
