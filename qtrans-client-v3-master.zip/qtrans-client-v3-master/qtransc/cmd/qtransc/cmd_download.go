package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/signal"
	"path"
	"qtransc/internal/downloadtask"
	"qtransc/internal/netclient"
	"qtransc/internal/taskidclient"
	"qtransc/internal/types"
	"strings"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/spf13/cobra"
)

var (
	dlSources     []string
	dlFileList    string
	dlDestination string
)

var downloadCmd = &cobra.Command{
	Use:   "download <remote-source> [local-destination]",
	Short: "Download files from qtserver",
	Long:  `Download files or directories from one qtserver instance.`,
	RunE:  runDownload,
}

func initDownloadFlags() {
	initDirectDownloadTestFlags()
	downloadCmd.Flags().StringArrayVarP(&dlSources, "source", "s", nil, "remote source path; may be specified multiple times")
	downloadCmd.Flags().Var(&singleStringFlagValue{name: "filelist", target: &dlFileList}, "filelist", "UTF-8 source list file")
	downloadCmd.Flags().VarP(&singleStringFlagValue{name: "destination", target: &dlDestination}, "destination", "d", "local destination directory (default ~/qtransdownload)")
}

func resolveDownloadAccess(parsedURLs []*QtransURL, token string) (types.DownloadUser, string, error) {
	resolvedUser, effectiveToken, err := resolveQtserverAccessForURLs(parsedURLs, token)
	if err != nil {
		return "", "", err
	}
	for _, parsed := range parsedURLs {
		if parsed.ObjectKey == "" {
			return "", "", fmt.Errorf("downloading the root directory is not supported")
		}
	}
	return resolvedUser, effectiveToken, nil
}

func runDownload(cmd *cobra.Command, args []string) error {
	transportMode, err := types.ParseTransportMode(cliTransport)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}
	inputs, err := resolveDownloadCLIInputs(cmd, args, dlSources, dlFileList, dlDestination)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}

	// ── 1. Parse remote paths ──
	parsedURLs, serverURL, err := ParseRemotePaths(cliServer, inputs.Sources, transportMode)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}
	availableToken, err := optionalCLIBearerToken()
	if err != nil {
		return sanitizeCLIError(err)
	}

	// ── 2. Resolve qtserver access space ──
	resolvedUser, effectiveToken, err := resolveDownloadAccess(parsedURLs, availableToken)
	if err != nil {
		return sanitizeCLIError(err)
	}

	// ── 4. Setup logger ──
	configurePendingTaskCLILogger(cliDebug, cliLogPath)

	limitRateBytes, err := parseLimitRate(cliLimitRate)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(fmt.Errorf("invalid --limit-rate: %w", err)), 2)
	}
	maxConnectionReceiveWindow, err := parseDownloadMCRWSize(dlMCRWSize, transportMode)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}
	effectiveConnections, effectiveStreams := cliConnections, cliStreams

	// ── 5. Init HTTP client pool ──
	poolCfg, err := netclient.NormalizePoolConfig(transportMode, effectiveConnections, effectiveStreams)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(fmt.Errorf("invalid transport concurrency config: %w", err)), 2)
	}
	fileConcurrency, err := resolveFileConcurrency(cliTransfers)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}
	client, err := netclient.New(transportMode, netclient.Config{Pool: poolCfg, Options: netclient.PoolOptions{QUICMaxConnectionReceiveWindow: maxConnectionReceiveWindow}})
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(fmt.Errorf("failed to initialize %s client pool: %w", transportMode, err)), 2)
	}
	defer client.Close()

	// ── 6. Build task request ──
	taskName := fmt.Sprintf("cli-download-%d", time.Now().Unix())
	serverBase := serverURL
	taskID, err := taskidclient.Request(context.Background(), serverBase, client)
	if err != nil {
		return sanitizeCLIError(err)
	}
	configureTaskCLILogger(cliDebug, cliLogPath, taskID, "debug")

	fileList := make([]types.TaskFileSpec, len(parsedURLs))
	for i, u := range parsedURLs {
		fileList[i] = types.TaskFileSpec{
			LocalRelPath: path.Base(u.ObjectKey),
			RemoteURL:    u.ObjectKey, // Object key for qtserver
		}
	}

	req := &types.TaskCreateRequest{
		TaskID:     taskID,
		TaskName:   taskName,
		Mode:       "download",
		Transport:  transportMode.String(),
		ServerAddr: serverBase,
		TargetDir:  inputs.Destination,
		FileList:   fileList,
	}
	req.DownloadUser = string(resolvedUser)
	if resolvedUser == types.DownloadUserSelf {
		req.UseAuthManager = strings.TrimSpace(cliAuthToken) == "" && strings.TrimSpace(cliAuthUsername) != ""
		if req.UseAuthManager {
			req.BearerToken = ""
		} else {
			req.BearerToken = effectiveToken
		}
	}
	if err := req.Validate(); err != nil {
		return withCommandExitCode(sanitizeCLIError(fmt.Errorf("invalid request: %w", err)), 2)
	}

	// ── 7. Create and execute task ──
	completionOption, taskCompleted := cliTaskCompletion()
	task, err := downloadtask.NewDownloadTask(req, client.Config(), client, completionOption)
	if err != nil {
		return sanitizeCLIError(fmt.Errorf("failed to create download task: %w", err))
	}
	task.LimitRate = limitRateBytes
	task.FileConcurrency = fileConcurrency

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Handle interrupts
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	defer signal.Stop(sigCh)
	var interruptedExitCode atomic.Int32
	go func() {
		received := <-sigCh
		interruptedExitCode.Store(int32(exitCodeForSignal(received)))
		_ = task.Stop()
		cancel()
	}()

	done := runCLITask(ctx, task, taskCompleted)

	// ── 8. Display progress or wait ──
	if cliDebug {
		taskErr := preferStoredTaskError(<-done, task.GetStatus().Error)
		printDownloadSummary(task, serverURL, inputs.Destination)
		exitCode := int(interruptedExitCode.Load())
		if exitCode == 0 && errors.Is(taskErr, downloadtask.ErrPlanning) {
			exitCode = 2
		}
		return withCommandExitCode(taskErr, exitCode)
	}

	taskErr := showSimpleDownloadProgress(task, serverURL, done)
	if taskErr == nil {
		fmt.Fprintf(os.Stderr, "Files saved to: %s\n", inputs.Destination)
	}
	exitCode := int(interruptedExitCode.Load())
	if exitCode == 0 && errors.Is(taskErr, downloadtask.ErrPlanning) {
		exitCode = 2
	}
	return withCommandExitCode(sanitizeCLIError(taskErr), exitCode)
}

func printDownloadSummary(task *downloadtask.DownloadTask, serverURL, targetDir string) {
	status := task.GetStatus().Status
	fmt.Fprintf(os.Stderr, "\n--- Download Summary ---\n")
	fmt.Fprintf(os.Stderr, "Server:    %s\n", serverURL)
	fmt.Fprintf(os.Stderr, "Target:    %s\n", targetDir)
	fmt.Fprintf(os.Stderr, "Status:    %s\n", status)
	fmt.Fprintf(os.Stderr, "Total:     %s\n", formatBytes(task.TotalSize.Load()))
	fmt.Fprintf(os.Stderr, "Received:  %s\n", formatBytes(task.Transferred.Load()))

	if taskErr := task.GetStatus().Error; taskErr != nil {
		fmt.Fprintf(os.Stderr, "Error:     %v\n", taskErr)
	}

	for _, fi := range task.AuthorizedFiles {
		if fi == nil {
			continue
		}
		mark := "PENDING"
		if fi.Verified {
			mark = "DONE"
		} else if fi.Transferred >= fi.Size && fi.Size > 0 {
			mark = "DONE"
		}
		fmt.Fprintf(os.Stderr, "  %s %s (%s)\n", mark, fi.LocalPath, formatBytes(fi.Size))
	}

	for _, fi := range task.UnAuthorizedFiles {
		if fi == nil {
			continue
		}
		fmt.Fprintf(os.Stderr, "  REJECTED %s (unauthorized)\n", fi.LocalPath)
	}

	fmt.Fprintf(os.Stderr, "---\nFiles saved to: %s\n", targetDir)
}
