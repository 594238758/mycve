package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io/fs"
	"log/slog"
	"os"
	"path"
	"path/filepath"
	"qtransc/internal/netclient"
	"qtransc/internal/types"
	"qtransc/internal/uploadtask"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gorilla/websocket"
	"github.com/spf13/cobra"
)

type legacyUpload2FileRequest struct {
	LocalAbsPath  string `json:"local_abs_path"`
	RemoteRelPath string `json:"remote_rel_path"`
}

type upload2CompatReporter struct {
	task         *uploadtask.UploadTask
	taskID       string
	wsURL        string
	absPathByRel map[string]string

	startCh       chan struct{}
	doneCh        chan error
	terminalAckCh chan struct{}

	startOnce       sync.Once
	terminalAckOnce sync.Once
}

func newUpload2CompatReporter(task *uploadtask.UploadTask, taskID, wsURL string, absPathByRel map[string]string) *upload2CompatReporter {
	return &upload2CompatReporter{
		task:          task,
		taskID:        taskID,
		wsURL:         strings.TrimSpace(wsURL),
		absPathByRel:  absPathByRel,
		startCh:       make(chan struct{}),
		doneCh:        make(chan error, 1),
		terminalAckCh: make(chan struct{}),
	}
}

func (r *upload2CompatReporter) usesWebSocket() bool {
	return r.taskID != "" && r.wsURL != ""
}

func (r *upload2CompatReporter) releaseStart() {
	r.startOnce.Do(func() {
		close(r.startCh)
	})
}

func (r *upload2CompatReporter) ackTerminal() {
	r.terminalAckOnce.Do(func() {
		close(r.terminalAckCh)
	})
}

func (r *upload2CompatReporter) Start(ctx context.Context, stop func()) (<-chan struct{}, <-chan error) {
	go r.run(ctx, stop)
	return r.startCh, r.doneCh
}

func (r *upload2CompatReporter) WaitTerminalAck(timeout time.Duration) {
	if !r.usesWebSocket() {
		return
	}
	select {
	case <-r.terminalAckCh:
	case <-time.After(timeout):
	}
}

func (r *upload2CompatReporter) run(ctx context.Context, stop func()) {
	if !r.usesWebSocket() {
		r.releaseStart()
		r.doneCh <- nil
		return
	}

	conn, _, err := websocket.DefaultDialer.Dial(r.wsURL, nil)
	if err != nil {
		if stop != nil {
			stop()
		}
		r.doneCh <- fmt.Errorf("dial websocket server failed: %w", err)
		return
	}
	defer conn.Close()

	if err := conn.WriteJSON(legacyUpload2WSResponse{
		TaskID: r.taskID,
		Code:   int(legacyUpload2TransNormalStatus),
	}); err != nil {
		if stop != nil {
			stop()
		}
		r.doneCh <- fmt.Errorf("write websocket server failed: %w", err)
		return
	}

	messageCh := make(chan []byte)
	errCh := make(chan error, 1)
	go func() {
		for {
			_, message, err := conn.ReadMessage()
			if err != nil {
				errCh <- err
				return
			}
			messageCh <- message
		}
	}()

	for {
		select {
		case <-ctx.Done():
			r.doneCh <- nil
			return
		case err := <-errCh:
			if websocket.IsCloseError(err, websocket.CloseNormalClosure, websocket.CloseGoingAway) {
				r.doneCh <- nil
				return
			}
			if isLegacyCoordinatorPauseClose(err) {
				if stop != nil {
					stop()
				}
				r.doneCh <- nil
				return
			}
			if stop != nil {
				stop()
			}
			r.doneCh <- fmt.Errorf("read websocket message failed: %w", err)
			return
		case message := <-messageCh:
			var req legacyUpload2WSRequest
			if err := json.Unmarshal(message, &req); err != nil {
				if stop != nil {
					stop()
				}
				r.doneCh <- fmt.Errorf("decode websocket request failed: %w", err)
				return
			}

			resp, err := handleLegacyCoordinatorRequest(r.taskID, req, r.buildResponse)
			if err != nil {
				if stop != nil {
					stop()
				}
				r.doneCh <- err
				return
			}
			if err := conn.WriteJSON(resp); err != nil {
				if stop != nil {
					stop()
				}
				r.doneCh <- fmt.Errorf("write websocket response failed: %w", err)
				return
			}
		}
	}
}

func (r *upload2CompatReporter) buildResponse() legacyUpload2WSResponse {
	status, data := r.currentStatus()
	if status == legacyUpload2TransStarting {
		r.releaseStart()
	}
	if status == legacyUpload2TransFinished || status >= legacyUpload2TransError {
		r.ackTerminal()
	}
	return legacyUpload2WSResponse{
		TaskID: r.taskID,
		Code:   int(status),
		Data:   data,
	}
}

func (r *upload2CompatReporter) currentStatus() (legacyUpload2Status, any) {
	basic := r.task.GetStatus()
	progress := r.snapshotProgress()

	switch basic.Status {
	case types.StatusPending:
		return legacyUpload2TransStarting, legacyUpload2TransStarting.String()
	case types.StatusRunning:
		progress.Status = 0
		return legacyUpload2TransRunning, progress
	case types.StatusCompleted:
		progress.Status = 1
		return legacyUpload2TransFinished, progress
	case types.StatusFailed:
		if isUpload2AuthError(basic.Error) {
			return legacyUpload2TransAuthFailed, legacyUpload2TransAuthFailed.String()
		}
		return legacyUpload2TransError, legacyUpload2TransError.String()
	case types.StatusStopped:
		if err := basic.Error; err != nil {
			if isUpload2AuthError(err) {
				return legacyUpload2TransAuthFailed, legacyUpload2TransAuthFailed.String()
			}
			return legacyUpload2TransError, legacyUpload2TransError.String()
		}
		progress.Status = 1
		return legacyUpload2TransFinished, progress
	default:
		progress.Status = -1
		return legacyUpload2TransError, progress
	}
}

func (r *upload2CompatReporter) snapshotProgress() legacyUpload2TotalProgressInfo {
	total := atomic.LoadInt64(&r.task.TotalSize)
	transferred := atomic.LoadInt64(&r.task.Transferred)
	rate := atomic.LoadInt64(&r.task.Rate)

	files := make([]legacyUpload2ProgressInfo, 0)
	r.task.TransferingFiles.Range(func(_, value any) bool {
		file, ok := value.(*uploadtask.UploadFileInfo)
		if !ok || file == nil {
			return true
		}
		fileTransferred := atomic.LoadInt64(&file.Transferred)
		if file.Uploaded || file.Verified {
			return true
		}
		pct := calcUpload2Percent(fileTransferred, file.Size)
		files = append(files, legacyUpload2ProgressInfo{
			File:            r.absoluteFilePath(file),
			ProgressPercent: pct,
			Transferred:     fileTransferred,
			Total:           file.Size,
			Rate:            formatUpload2KBRate(atomic.LoadInt64(&file.Rate)),
		})
		return true
	})

	return legacyUpload2TotalProgressInfo{
		Status:           0,
		ProgressPercent:  r.task.GetProgressPercent(),
		TotalTransferred: transferred,
		TotalFileSize:    total,
		Rate:             formatUpload2KBRate(rate),
		Files:            files,
	}
}

func (r *upload2CompatReporter) absoluteFilePath(file *uploadtask.UploadFileInfo) string {
	if file == nil {
		return ""
	}
	if abs, ok := r.absPathByRel[file.LocalPath]; ok {
		return abs
	}
	if filepath.IsAbs(file.FullPath) {
		return file.FullPath
	}
	return filepath.Join(r.task.SourceDir, file.LocalPath)
}

func loadUpload2CompatFiles(jsonFile string) ([]legacyUpload2FileRequest, error) {
	jsonFile = strings.TrimSpace(jsonFile)
	if jsonFile == "" {
		return nil, fmt.Errorf("--jf is required")
	}

	data, err := os.ReadFile(jsonFile)
	if err != nil {
		return nil, fmt.Errorf("read upload json file: %w", err)
	}

	var files []legacyUpload2FileRequest
	if err := json.Unmarshal(data, &files); err != nil {
		return nil, fmt.Errorf("parse upload task json: %w", err)
	}
	if len(files) == 0 {
		return nil, fmt.Errorf("upload task json is empty")
	}

	for i := range files {
		files[i].LocalAbsPath = strings.TrimSpace(files[i].LocalAbsPath)
		files[i].RemoteRelPath = strings.TrimSpace(files[i].RemoteRelPath)
		if files[i].LocalAbsPath == "" || files[i].RemoteRelPath == "" {
			return nil, fmt.Errorf("upload task file %d is missing local_abs_path or remote_rel_path", i)
		}
		absPath, err := filepath.Abs(files[i].LocalAbsPath)
		if err != nil {
			return nil, fmt.Errorf("resolve local_abs_path for %q: %w", files[i].LocalAbsPath, err)
		}
		files[i].LocalAbsPath = absPath
	}

	return files, nil
}

func resolveUpload2Server(raw string) (string, error) {
	parsed, err := ParseQtransServer(raw, types.TransportHTTPS3)
	if err != nil {
		return "", err
	}
	return parsed.ServerURL, nil
}

func normalizeLegacyUpload2ObjectKey(raw string) string {
	return "/" + strings.Trim(strings.TrimSpace(raw), "/")
}

func expandLegacyUpload2Directory(localAbsPath, remoteRoot string) ([]uploadSourceFile, []string, error) {
	files := make([]uploadSourceFile, 0)
	dirSet := map[string]bool{
		remoteRoot: true,
	}

	err := filepath.WalkDir(localAbsPath, func(current string, d fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if d.IsDir() {
			if current == localAbsPath {
				return nil
			}
			relDir, err := filepath.Rel(localAbsPath, current)
			if err != nil {
				return fmt.Errorf("build relative dir path for %s: %w", current, err)
			}
			if depth := len(strings.Split(filepath.ToSlash(relDir), "/")); depth > maxPlannedDepth {
				return fmt.Errorf("directory depth exceeds %d at %s", maxPlannedDepth, current)
			}
			dirSet[joinUploadObjectKey(remoteRoot, filepath.ToSlash(relDir))] = true
			if len(dirSet)+len(files) > maxPlannedEntries {
				return fmt.Errorf("upload planning exceeds %d total entries", maxPlannedEntries)
			}
			return nil
		}
		if d.Type()&os.ModeSymlink != 0 {
			fmt.Fprintf(os.Stderr, "warning: skipped local symbolic link %s\n", current)
			return nil
		}
		info, err := d.Info()
		if err != nil {
			return err
		}
		if !info.Mode().IsRegular() {
			fmt.Fprintf(os.Stderr, "warning: skipped local special node %s\n", current)
			return nil
		}
		relPath, err := filepath.Rel(localAbsPath, current)
		if err != nil {
			return fmt.Errorf("build relative path for %s: %w", current, err)
		}
		files = append(files, uploadSourceFile{
			LocalAbsPath: current,
			ObjectKey:    joinUploadObjectKey(remoteRoot, filepath.ToSlash(relPath)),
		})
		if err := validateUploadPlanLimits(len(files), len(dirSet)); err != nil {
			return err
		}
		return nil
	})
	if err != nil {
		return nil, nil, err
	}

	dirPaths := make([]string, 0, len(dirSet))
	for dirPath := range dirSet {
		dirPaths = append(dirPaths, dirPath)
	}
	sort.Strings(dirPaths)
	return files, dirPaths, nil
}

func expandLegacyUpload2Files(files []legacyUpload2FileRequest) ([]uploadSourceFile, []string, string, error) {
	sourceFiles := make([]uploadSourceFile, 0, len(files))
	sourceRoot := ""
	dirSet := make(map[string]bool)

	for _, file := range files {
		objectKey := normalizeLegacyUpload2ObjectKey(file.RemoteRelPath)
		info, err := os.Lstat(file.LocalAbsPath)
		if err != nil {
			return nil, nil, "", fmt.Errorf("stat upload source %s: %w", file.LocalAbsPath, err)
		}
		if info.Mode()&os.ModeSymlink != 0 {
			return nil, nil, "", fmt.Errorf("symbolic links are not supported as upload sources: %s", file.LocalAbsPath)
		}

		switch {
		case info.Mode().IsRegular():
			sourceFiles = append(sourceFiles, uploadSourceFile{
				LocalAbsPath: file.LocalAbsPath,
				ObjectKey:    objectKey,
			})
			fileRoot := filepath.Dir(file.LocalAbsPath)
			if sourceRoot == "" {
				sourceRoot = fileRoot
			} else {
				sourceRoot = commonPathDir(sourceRoot, fileRoot)
			}
		case info.IsDir():
			expandedFiles, dirPaths, err := expandLegacyUpload2Directory(file.LocalAbsPath, objectKey)
			if err != nil {
				return nil, nil, "", err
			}
			sourceFiles = append(sourceFiles, expandedFiles...)
			for _, dirPath := range dirPaths {
				dirSet[dirPath] = true
			}
			if sourceRoot == "" {
				sourceRoot = file.LocalAbsPath
			} else {
				sourceRoot = commonPathDir(sourceRoot, file.LocalAbsPath)
			}
		default:
			return nil, nil, "", fmt.Errorf("upload source is not a regular file or directory: %s", file.LocalAbsPath)
		}
	}
	if err := validateUploadPlanLimits(len(sourceFiles), len(dirSet)); err != nil {
		return nil, nil, "", err
	}

	for _, sf := range sourceFiles {
		for p := path.Dir(sf.ObjectKey); p != "." && p != "/"; p = path.Dir(p) {
			dirSet[p] = true
		}
	}

	dirPaths := make([]string, 0, len(dirSet))
	for dirPath := range dirSet {
		dirPaths = append(dirPaths, dirPath)
	}
	sort.Strings(dirPaths)
	return sourceFiles, dirPaths, sourceRoot, nil
}

func buildUpload2TaskRequest(taskID, bearerToken, callerVersion, serverURL string, files []legacyUpload2FileRequest) (*types.TaskCreateRequest, map[string]string, error) {
	taskID = resolveUpload2TaskID(taskID)

	sourceFiles, dirPaths, sourceDir, err := expandLegacyUpload2Files(files)
	if err != nil {
		return nil, nil, err
	}

	var (
		req          *types.TaskCreateRequest
		absPathByRel map[string]string
	)
	if len(sourceFiles) > 0 {
		var specs []types.TaskFileSpec
		sourceDir, specs, absPathByRel, err = buildUploadTaskFileSpecsUnderSourceDir(sourceDir, sourceFiles)
		if err != nil {
			return nil, nil, err
		}
		req = &types.TaskCreateRequest{
			BearerToken:   bearerToken,
			TaskID:        taskID,
			CallerVersion: callerVersion,
			TaskName:      "upload2-" + taskID,
			Mode:          "upload",
			Transport:     types.TransportHTTPS3.String(),
			ServerAddr:    serverURL,
			SourceDir:     sourceDir,
			FileList:      specs,
			DirPaths:      dirPaths,
			StateDBPath:   cliStateDB,
		}
	} else {
		req = &types.TaskCreateRequest{
			BearerToken:   bearerToken,
			TaskID:        taskID,
			CallerVersion: callerVersion,
			TaskName:      "upload2-" + taskID,
			Mode:          "upload",
			Transport:     types.TransportHTTPS3.String(),
			ServerAddr:    serverURL,
			SourceDir:     sourceDir,
			DirPaths:      dirPaths,
			StateDBPath:   cliStateDB,
		}
		absPathByRel = map[string]string{}
	}
	if err := req.Validate(); err != nil {
		return nil, nil, err
	}
	return req, absPathByRel, nil
}

func buildUpload2FileSpecs(files []legacyUpload2FileRequest) (string, []types.TaskFileSpec, map[string]string, error) {
	sourceFiles := make([]uploadSourceFile, 0, len(files))
	for _, file := range files {
		sourceFiles = append(sourceFiles, uploadSourceFile{
			LocalAbsPath: file.LocalAbsPath,
			ObjectKey:    normalizeLegacyUpload2ObjectKey(file.RemoteRelPath),
		})
	}
	return buildUploadTaskFileSpecs(sourceFiles)
}

var (
	upload2TaskID        string
	upload2WSSURL        string
	upload2JSONFile      string
	upload2CallerVersion string
)

var upload2Cmd = &cobra.Command{
	Use:   "upload2",
	Short: "Legacy-compatible upload command backed by the latest engine core",
	Long: `upload2 keeps the old qtrans-client upload contract:
- task JSON from --jf
- optional websocket progress query protocol via --wss-url/--taskid
- server address specified via --server

The actual transfer is executed by the current qtransc upload core.`,
	RunE: runUpload2,
}

func initUpload2Flags() {
	upload2Cmd.Flags().StringVarP(&upload2TaskID, "taskid", "t", "", "legacy task id used by the websocket coordinator")
	upload2Cmd.Flags().StringVar(&upload2WSSURL, "wss-url", "", "legacy websocket server URL for status queries")
	upload2Cmd.Flags().StringVarP(&upload2JSONFile, "jf", "j", "", "path to the legacy upload task JSON file")
	upload2Cmd.Flags().StringVar(&upload2CallerVersion, "callerversion", "", "version of the GUI or agent invoking upload2")
}

func runUpload2(_ *cobra.Command, _ []string) error {
	upload2TaskID = resolveUpload2TaskID(upload2TaskID)
	configureCompatTaskCLILogger(cliDebug, cliLogPath, upload2TaskID, "debug")
	slog.Debug("upload2 command started",
		"task_id", upload2TaskID,
		"taskpid", "",
		"enterprise_id", "",
		"wss_url", upload2WSSURL,
		"server", cliServer,
		"json_file", upload2JSONFile,
		"connections", cliConnections,
		"streams", cliStreams,
		"transfers", cliTransfers,
		"debug", cliDebug,
		"log_path", cliLogPath)
	if cliDebug {
		slog.Debug("upload2 compatibility mode keeps log-only output; terminal summaries are suppressed")
	}

	return runUpload2Upload()
}

func waitUpload2WithLogProgress(task *uploadtask.UploadTask, serverURL string, done <-chan error) error {
	startedAt := time.Now()
	slog.Info("upload2 upload transfer started",
		"task_id", task.TaskID,
		"taskpid", task.TaskPID,
		"enterprise_id", task.EnterpriseID,
		"server", serverURL,
		"files", len(task.FileList),
		"total_bytes", atomic.LoadInt64(&task.TotalSize),
		"total", formatBytes(atomic.LoadInt64(&task.TotalSize)))
	err := <-done
	logUpload2Progress(task, serverURL, startedAt, true, err)
	return err
}

func logUpload2Progress(task *uploadtask.UploadTask, serverURL string, startedAt time.Time, final bool, taskErr error) {
	total := atomic.LoadInt64(&task.TotalSize)
	transferred := atomic.LoadInt64(&task.Transferred)
	rate := atomic.LoadInt64(&task.Rate)
	completedFiles, activeFiles := upload2FileCounts(task.FileList)

	attrs := []any{
		"task_id", task.TaskID,
		"taskpid", task.TaskPID,
		"enterprise_id", task.EnterpriseID,
		"server", serverURL,
		"phase", task.GetPhase(),
		"status", task.GetStatus().Status,
		"progress_percent", fmt.Sprintf("%.1f", task.GetProgressPercent()),
		"transferred_bytes", transferred,
		"total_bytes", total,
		"transferred", formatBytes(transferred),
		"total", formatBytes(total),
		"rate_bytes_per_sec", rate,
		"rate", formatBytes(rate) + "/s",
		"completed_files", completedFiles,
		"total_files", len(task.FileList),
		"active_files", activeFiles,
		"elapsed", formatDuration(time.Since(startedAt)),
	}

	if !final {
		return
	}
	if taskErr != nil {
		attrs = append(attrs, "err", taskErr)
		slog.Error("upload2 upload transfer failed", attrs...)
		return
	}
	slog.Info("upload2 upload transfer finished", attrs...)
}

func upload2FileCounts(files []*uploadtask.UploadFileInfo) (completed int, active int) {
	for _, file := range files {
		if file == nil {
			continue
		}
		if file.Uploaded || file.Verified {
			completed++
			continue
		}
		if atomic.LoadInt64(&file.Transferred) > 0 {
			active++
		}
	}
	return completed, active
}

func runUpload2Upload() error {
	serverURL, err := resolveUpload2Server(cliServer)
	if err != nil {
		return err
	}

	legacyFiles, err := loadUpload2CompatFiles(upload2JSONFile)
	if err != nil {
		return err
	}
	bearerToken, err := requiredCLIBearerToken()
	if err != nil {
		return err
	}
	if bearerToken == anonymousCanonicalWriteToken {
		return fmt.Errorf("upload2 does not permit the anonymous write token")
	}
	req, absPathByRel, err := buildUpload2TaskRequest(upload2TaskID, bearerToken, upload2CallerVersion, serverURL, legacyFiles)
	if err != nil {
		return err
	}

	transportMode, err := types.ParseTransportMode(req.Transport)
	if err != nil {
		return fmt.Errorf("invalid transport: %w", err)
	}
	poolCfg, err := netclient.NormalizePoolConfig(transportMode, cliConnections, cliStreams)
	if err != nil {
		return fmt.Errorf("invalid upload concurrency config: %w", err)
	}
	fileConcurrency, err := resolveFileConcurrency(cliTransfers)
	if err != nil {
		return err
	}
	slog.Info("upload2 effective transfer settings",
		"transport", transportMode,
		"connections", poolCfg.Connections,
		"streams", poolCfg.StreamsPerConnection,
		"transfers", fileConcurrency)
	client, err := netclient.New(transportMode, netclient.Config{Pool: poolCfg})
	if err != nil {
		return fmt.Errorf("failed to initialize %s client pool: %w", transportMode, err)
	}
	defer client.Close()

	completionOption, taskCompleted := cliTaskCompletion()
	task, err := uploadtask.NewUploadTask(req, client.Config(), client, completionOption)
	if err != nil {
		return fmt.Errorf("failed to create upload task: %w", err)
	}
	task.FileConcurrency = fileConcurrency

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	shutdownController := newUploadTaskShutdownController(task, cancel)
	stopSignals := shutdownController.InstallSignalHandler()
	defer stopSignals()

	reporter := newUpload2CompatReporter(task, req.TaskID, upload2WSSURL, absPathByRel)
	startCh, wsDone := reporter.Start(ctx, shutdownController.StopGracefully)
	select {
	case <-startCh:
	case wsErr := <-wsDone:
		if wsErr != nil {
			return wsErr
		}
	case <-ctx.Done():
		if err := ctx.Err(); err != nil && err != context.Canceled {
			return err
		}
		return context.Canceled
	}

	done := runCLITask(ctx, task, taskCompleted)

	taskErr := waitUpload2WithLogProgress(task, serverURL, done)

	reporter.WaitTerminalAck(legacyTerminalAckTimeout)
	cancel()

	wsErr := <-wsDone
	if taskErr != nil {
		return taskErr
	}
	if wsErr != nil {
		return wsErr
	}
	return nil
}

func resolveUpload2TaskID(taskID string) string {
	taskID = strings.TrimSpace(taskID)
	if taskID != "" {
		return taskID
	}
	return fmt.Sprintf("compat-ul-%d", time.Now().UnixNano())
}
