package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"strings"

	"qtransc/internal/qtserverurl"
	"qtransc/internal/types"

	"github.com/spf13/cobra"
)

var (
	dlistJSON bool
)

type dlistOptions struct {
	Server     string
	RemotePath string
	Token      string
	JSON       bool
	Transport  types.TransportMode
}

var dlistCmd = &cobra.Command{
	Use:   "dlist [remote-directory]",
	Short: "Browse download paths from qtserver",
	Args:  cobra.MaximumNArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		transportMode, err := types.ParseTransportMode(cliTransport)
		if err != nil {
			return sanitizeCLIError(err)
		}
		bearerToken, err := optionalCLIBearerToken()
		if err != nil {
			return sanitizeCLIError(err)
		}
		remotePath := "/"
		if len(args) == 1 {
			remotePath, err = normalizeRemoteAbsolutePath(args[0], true)
			if err != nil {
				return sanitizeCLIError(fmt.Errorf("remote directory: %w", err))
			}
		}
		return formatBrowseCLIError(remotePath, executeDList(cmd.Context(), os.Stdout, dlistOptions{
			Server:     cliServer,
			RemotePath: remotePath,
			Token:      bearerToken,
			JSON:       dlistJSON,
			Transport:  transportMode,
		}))
	},
}

func initDListFlags() {
	dlistCmd.Flags().BoolVar(&dlistJSON, "json", false, "write the browse response JSON to stdout")
}

func executeDList(ctx context.Context, out io.Writer, opts dlistOptions) error {
	if ctx == nil {
		ctx = context.Background()
	}
	configureCLILogger(cliDebug)

	parsed, err := ParseRemotePath(opts.Server, opts.RemotePath, opts.Transport)
	if err != nil {
		return err
	}
	location := formatBrowseLocation(parsed)

	user, effectiveToken, err := resolveQtserverAccess(opts.Token)
	if err != nil {
		return err
	}

	network, err := newClientForTransport(opts.Transport, 1, 1)
	if err != nil {
		return fmt.Errorf("failed to initialize %s client pool: %w", opts.Transport, err)
	}
	defer network.Close()

	requestURL, err := buildBrowseURL(parsed.ServerURL, user, parsed.ObjectKey)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, requestURL, nil)
	if err != nil {
		return fmt.Errorf("create browse request: %w", err)
	}
	if effectiveToken != "" {
		req.Header.Set("Authorization", "Bearer "+effectiveToken)
	}

	client, releaseClient, err := network.Acquire(ctx, req.URL.String())
	if err != nil {
		return err
	}
	defer releaseClient()

	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("browse request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("read browse response: %w", err)
	}
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("browse failed: status=%d body=%s", resp.StatusCode, strings.TrimSpace(string(body)))
	}

	if opts.JSON {
		var browseResp types.DownloadBrowseResponse
		if err := json.Unmarshal(body, &browseResp); err != nil {
			var pretty bytes.Buffer
			if err := json.Indent(&pretty, body, "", "  "); err == nil {
				_, _ = fmt.Fprintln(out, pretty.String())
				return nil
			}
			_, _ = fmt.Fprintln(out, string(body))
			return nil
		}
		browseResp.ObjectPath = browseResp.Path
		browseResp.Path = location
		encoded, err := json.MarshalIndent(&browseResp, "", "  ")
		if err != nil {
			return fmt.Errorf("encode browse response: %w", err)
		}
		_, _ = fmt.Fprintln(out, string(encoded))
		return nil
	}

	var browseResp types.DownloadBrowseResponse
	if err := json.Unmarshal(body, &browseResp); err != nil {
		return fmt.Errorf("decode browse response: %w", err)
	}
	renderBrowseText(out, location, &browseResp)
	return nil
}

func buildBrowseURL(serverURL string, user types.DownloadUser, path string) (string, error) {
	requestTarget, err := qtserverurl.JoinEndpoint(serverURL, "/d/browse")
	if err != nil {
		return "", err
	}
	parsed, err := url.Parse(requestTarget)
	if err != nil {
		return "", fmt.Errorf("invalid server URL %q: %w", serverURL, err)
	}
	query := parsed.Query()
	query.Set("user", string(user))
	query.Set("path", path)
	parsed.RawQuery = query.Encode()
	return parsed.String(), nil
}

func formatBrowseLocation(parsed *QtransURL) string {
	if parsed == nil {
		return ""
	}
	var b strings.Builder
	b.WriteString("qtrans://")
	b.WriteString(parsed.Host)
	if parsed.ObjectKey == "" {
		b.WriteByte('/')
		return b.String()
	}
	b.WriteByte('/')
	b.WriteString(parsed.ObjectKey)
	return b.String()
}

func renderBrowseText(out io.Writer, location string, browseResp *types.DownloadBrowseResponse) {
	if browseResp == nil {
		return
	}
	entries := make([]browseRenderEntry, 0, len(browseResp.Entries))
	for _, entry := range browseResp.Entries {
		entries = append(entries, browseRenderEntry{
			Name:         entry.Name,
			EntryType:    entry.EntryType,
			Size:         entry.Size,
			LastModified: entry.LastModified,
		})
	}
	renderBrowseTable(out, location, entries)
}
