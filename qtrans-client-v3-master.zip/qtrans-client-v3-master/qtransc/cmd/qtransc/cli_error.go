package main

import (
	"errors"
	"fmt"
	"strings"

	"qtransc/internal/clienterror"
	"qtransc/internal/downloadtask"
)

// sanitizeCLIError keeps the existing command call sites while returning an
// error that carries the stable client-error contract.
func sanitizeCLIError(err error) error {
	if err == nil {
		return nil
	}
	if errors.Is(err, downloadtask.ErrRemoteNotFound) {
		return clienterror.New("NOT_FOUND", "未找到该文件", err)
	}
	return clienterror.Normalize(err)
}

func normalizeCobraError(err error) error {
	if err == nil {
		return nil
	}
	var typed *clienterror.Error
	if errors.As(err, &typed) {
		return err
	}
	lower := strings.ToLower(strings.TrimSpace(err.Error()))
	for _, marker := range []string{"unknown command", "unknown flag", "flag needs an argument", "requires at least", "requires exactly", "accepts ", "required flag"} {
		if strings.Contains(lower, marker) {
			return clienterror.New(clienterror.CodeInvalidArgument, "命令参数无效；使用 --help 查看用法", err)
		}
	}
	return err
}

func formatBrowseCLIError(location string, err error) error {
	if err == nil {
		return nil
	}
	normalized := clienterror.Normalize(err)
	switch normalized.ReasonCode {
	case "NOT_FOUND":
		return clienterror.New("NOT_FOUND", fmt.Sprintf("未找到远端目录：%s", location), err)
	case "NOT_A_DIRECTORY":
		return clienterror.New("NOT_A_DIRECTORY", fmt.Sprintf("远端路径不是目录：%s", location), err)
	case "UNSUPPORTED_FILE_TYPE":
		return clienterror.New("UNSUPPORTED_FILE_TYPE", fmt.Sprintf("远端路径不是可浏览的文件或目录：%s", location), err)
	default:
		return clienterror.New(normalized.ReasonCode, fmt.Sprintf("无法浏览 %s：%s", location, normalized.Message), err)
	}
}
