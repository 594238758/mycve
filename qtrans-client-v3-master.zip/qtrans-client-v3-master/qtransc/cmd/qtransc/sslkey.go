package main

import (
	"fmt"
	"io"

	"qtransc/internal/sslkeylog"

	"github.com/spf13/pflag"
)

const exportSSLKeyFlagName = "export-sslkey"

func configureSSLKeyExportFromArgs(args []string) error {
	enabled, err := resolveExportSSLKeyFromArgs(args)
	if err != nil {
		return err
	}
	return enableSSLKeyExportIfRequested(enabled)
}

func resolveExportSSLKeyFromArgs(args []string) (bool, error) {
	flags := pflag.NewFlagSet("sslkey", pflag.ContinueOnError)
	flags.SetOutput(io.Discard)
	flags.ParseErrorsWhitelist.UnknownFlags = true

	flags.BoolP("help", "h", false, "")
	enabled := flags.Bool(exportSSLKeyFlagName, false, "")
	if err := flags.Parse(args); err != nil {
		return false, fmt.Errorf("parse --%s: %w", exportSSLKeyFlagName, err)
	}
	return *enabled, nil
}

func enableSSLKeyExportIfRequested(enabled bool) error {
	if !enabled {
		return nil
	}
	if err := sslkeylog.Enable(); err != nil {
		return fmt.Errorf("enable --%s: %w", exportSSLKeyFlagName, err)
	}
	return nil
}
