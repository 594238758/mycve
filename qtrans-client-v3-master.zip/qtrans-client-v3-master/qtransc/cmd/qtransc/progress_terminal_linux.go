//go:build linux

package main

import "golang.org/x/sys/unix"

const (
	terminalGetAttributes     = unix.TCGETS
	terminalSetAttributes     = unix.TCSETS
	terminalRestoreAttributes = unix.TCSETSF
)
