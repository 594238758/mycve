package main

import (
	"fmt"
	"os"
	"qtransc/internal/downloadtask"
	"qtransc/internal/types"
	"qtransc/internal/uploadtask"
	"sync/atomic"
	"time"

	"github.com/mattn/go-runewidth"
	"github.com/vbauerster/mpb/v8"
	"github.com/vbauerster/mpb/v8/decor"
)

const (
	progressRefresh   = 120 * time.Millisecond
	progressNameWidth = 28
	progressBarCells  = 25
	// mpb.BarWidth includes the surrounding '[' and ']'.
	progressBarWidth = progressBarCells + 2
)

type transferProgressSnapshot struct {
	totalFiles   int
	doneFiles    int
	transferred  int64
	networkBytes int64
	totalSize    int64
	rate         int64
	active       []activeTransferSnapshot
}

type activeTransferSnapshot struct {
	key         string
	name        string
	transferred int64
	totalSize   int64
	rate        int64
}

type transferProgressDisplay struct {
	progress *mpb.Progress
	header   *mpb.Bar
	overall  *mpb.Bar
	summary  *mpb.Bar
	active   map[string]*activeTransferBar

	totalRate    atomic.Int64
	activeNum    atomic.Int64
	doneNum      atomic.Int64
	waitingNum   atomic.Int64
	nextPriority int
}

type activeTransferBar struct {
	bar  *mpb.Bar
	rate atomic.Int64
}

func newTransferProgressDisplay(direction, serverURL string) *transferProgressDisplay {
	p := mpb.New(
		mpb.WithOutput(os.Stderr),
		mpb.WithRefreshRate(progressRefresh),
	)
	display := &transferProgressDisplay{
		progress:     p,
		active:       make(map[string]*activeTransferBar),
		nextPriority: 10,
	}

	display.header = p.New(0, mpb.NopStyle(),
		mpb.BarPriority(0),
		mpb.PrependDecorators(decor.Name(fmt.Sprintf("%s  %s", direction, serverURL))),
	)
	display.overall = p.New(0, transferBarStyle(),
		mpb.BarPriority(1),
		mpb.BarWidth(progressBarWidth),
		mpb.PrependDecorators(decor.Name("Total ", decor.WCSyncWidthR)),
		mpb.AppendDecorators(
			decor.NewPercentage(" %5.1f"),
			decor.Any(func(stat decor.Statistics) string {
				return fmt.Sprintf("  %s / %s", formatBytes(stat.Current), formatBytes(stat.Total))
			}),
			decor.Any(func(decor.Statistics) string {
				rate := display.totalRate.Load()
				return "  " + formatBytes(rate) + "/s"
			}),
		),
	)
	display.summary = p.New(0, mpb.NopStyle(),
		mpb.BarPriority(2),
		mpb.PrependDecorators(decor.Any(func(decor.Statistics) string {
			return fmt.Sprintf(
				"Files  active: %d  done: %d  waiting: %d",
				display.activeNum.Load(),
				display.doneNum.Load(),
				display.waitingNum.Load(),
			)
		})),
	)
	return display
}

func transferBarStyle() mpb.BarStyleComposer {
	return mpb.BarStyle()
}

func (display *transferProgressDisplay) update(snapshot transferProgressSnapshot) {
	if snapshot.totalSize > 0 {
		display.overall.SetTotal(snapshot.totalSize, false)
	}
	display.overall.SetCurrent(snapshot.transferred)
	display.totalRate.Store(snapshot.rate)

	seen := make(map[string]struct{}, len(snapshot.active))
	for _, file := range snapshot.active {
		seen[file.key] = struct{}{}
		activeBar, ok := display.active[file.key]
		if !ok {
			activeBar = display.addActive(file)
			display.active[file.key] = activeBar
		}
		if file.totalSize > 0 {
			activeBar.bar.SetTotal(file.totalSize, false)
		}
		activeBar.bar.SetCurrent(file.transferred)
		activeBar.rate.Store(file.rate)
	}

	for key, activeBar := range display.active {
		if _, ok := seen[key]; ok {
			continue
		}
		activeBar.bar.Abort(true)
		delete(display.active, key)
	}

	activeFiles := len(snapshot.active)
	waitingFiles := snapshot.totalFiles - snapshot.doneFiles - activeFiles
	if waitingFiles < 0 {
		waitingFiles = 0
	}
	display.activeNum.Store(int64(activeFiles))
	display.doneNum.Store(int64(snapshot.doneFiles))
	display.waitingNum.Store(int64(waitingFiles))
}

func (display *transferProgressDisplay) addActive(file activeTransferSnapshot) *activeTransferBar {
	activeBar := &activeTransferBar{}
	name := runewidth.Truncate(file.name, progressNameWidth, "...")
	activeBar.bar = display.progress.New(0, transferBarStyle(),
		mpb.BarPriority(display.nextPriority),
		mpb.BarWidth(progressBarWidth),
		mpb.PrependDecorators(decor.Name("  "+name+" ", decor.WCSyncWidthR)),
		mpb.AppendDecorators(
			decor.NewPercentage(" %5.1f"),
			decor.Any(func(decor.Statistics) string {
				rate := activeBar.rate.Load()
				return "  " + formatBytes(rate) + "/s"
			}),
		),
	)
	display.nextPriority++
	return activeBar
}

func (display *transferProgressDisplay) close() {
	for _, activeBar := range display.active {
		activeBar.bar.Abort(true)
	}
	display.header.Abort(true)
	display.overall.Abort(true)
	display.summary.Abort(true)
	display.progress.Wait()
}

func showSimpleDownloadProgress(task *downloadtask.DownloadTask, serverURL string, done <-chan error) error {
	restoreInput := suppressTerminalInputEcho()
	defer restoreInput()

	display := newTransferProgressDisplay("Download", serverURL)
	startedAt := time.Now()
	ticker := time.NewTicker(progressRefresh)
	defer ticker.Stop()

	for {
		select {
		case err := <-done:
			err = preferStoredTaskError(err, task.GetStatus().Error)
			snapshot := snapshotDownloadProgress(task)
			display.update(snapshot)
			display.close()
			printDownloadProgressResult(task, startedAt, snapshot)
			return err
		case <-ticker.C:
			display.update(snapshotDownloadProgress(task))
		}
	}
}

func snapshotDownloadProgress(task *downloadtask.DownloadTask) transferProgressSnapshot {
	summary := task.ToDownloadTaskSummary()
	snapshot := transferProgressSnapshot{
		totalFiles:   len(task.AuthorizedFiles),
		doneFiles:    int(task.VerifiedFileNum.Load()),
		transferred:  summary.Transferred,
		networkBytes: task.NetworkReceived.Load(),
		totalSize:    summary.TotalSize,
		rate:         summary.Rate,
		active:       make([]activeTransferSnapshot, 0, len(summary.TransferingFiles)),
	}
	for _, file := range summary.TransferingFiles {
		if file == nil {
			continue
		}
		snapshot.active = append(snapshot.active, activeTransferSnapshot{
			key:         file.LocalPath,
			name:        file.LocalPath,
			transferred: file.Transferred,
			totalSize:   file.Size,
			rate:        file.Rate,
		})
	}
	return snapshot
}

func printDownloadProgressResult(
	task *downloadtask.DownloadTask,
	startedAt time.Time,
	snapshot transferProgressSnapshot,
) {
	basic := task.GetStatus()
	switch basic.Status {
	case types.StatusCompleted:
		fmt.Fprintln(os.Stderr, "Download completed")
	case types.StatusFailed:
		fmt.Fprintf(os.Stderr, "Download failed: %v\n", basic.Error)
	default:
		fmt.Fprintf(os.Stderr, "Download stopped (status: %s)\n", basic.Status)
	}
	printFinalTransferSummary(startedAt, snapshot)
}

func showSimpleUploadProgress(task *uploadtask.UploadTask, serverURL string, done <-chan error) error {
	restoreInput := suppressTerminalInputEcho()
	defer restoreInput()

	display := newTransferProgressDisplay("Upload", serverURL)
	startedAt := time.Now()
	ticker := time.NewTicker(progressRefresh)
	defer ticker.Stop()

	for {
		select {
		case err := <-done:
			err = preferStoredTaskError(err, task.GetStatus().Error)
			snapshot := snapshotUploadProgress(task)
			display.update(snapshot)
			display.close()
			printUploadProgressResult(task, startedAt, snapshot)
			return err
		case <-ticker.C:
			display.update(snapshotUploadProgress(task))
		}
	}
}

func preferStoredTaskError(returned, stored error) error {
	if stored != nil {
		return stored
	}
	return returned
}

func snapshotUploadProgress(task *uploadtask.UploadTask) transferProgressSnapshot {
	summary := task.ToUploadTaskSummary()
	snapshot := transferProgressSnapshot{
		totalFiles:   len(task.FileList),
		transferred:  summary.Transferred,
		networkBytes: atomic.LoadInt64(&task.NetworkSent),
		totalSize:    summary.TotalSize,
		rate:         summary.Rate,
		active:       make([]activeTransferSnapshot, 0, len(summary.TransferingFiles)),
	}
	for _, file := range task.FileList {
		if file == nil {
			continue
		}
		if file.Verified || file.Uploaded || file.Exists ||
			file.Status == string(types.UploadFileStatusExists) ||
			file.Status == string(types.UploadFileStatusCommitted) {
			snapshot.doneFiles++
		}
	}
	for _, file := range summary.TransferingFiles {
		if file == nil {
			continue
		}
		snapshot.active = append(snapshot.active, activeTransferSnapshot{
			key:         file.LocalPath,
			name:        file.LocalPath,
			transferred: file.Transferred,
			totalSize:   file.Size,
			rate:        file.Rate,
		})
	}
	return snapshot
}

func printUploadProgressResult(
	task *uploadtask.UploadTask,
	startedAt time.Time,
	snapshot transferProgressSnapshot,
) {
	basic := task.GetStatus()
	switch basic.Status {
	case types.StatusCompleted:
		fmt.Fprintln(os.Stderr, "Upload completed")
	case types.StatusFailed:
		fmt.Fprintf(os.Stderr, "Upload failed: %v\n", basic.Error)
	default:
		fmt.Fprintf(os.Stderr, "Upload stopped (status: %s)\n", basic.Status)
	}
	printFinalTransferSummary(startedAt, snapshot)
}

func printFinalTransferSummary(startedAt time.Time, snapshot transferProgressSnapshot) {
	elapsed := time.Since(startedAt)
	averageRate := int64(0)
	if elapsed > 0 && snapshot.networkBytes > 0 {
		averageRate = int64(float64(snapshot.networkBytes) / elapsed.Seconds())
	}

	fmt.Fprintf(os.Stderr, "  Progress: %s  %s / %s\n",
		percentage(snapshot.transferred, snapshot.totalSize),
		formatBytes(snapshot.transferred),
		formatBytes(snapshot.totalSize))
	fmt.Fprintf(os.Stderr, "  Files:    %d / %d\n",
		snapshot.doneFiles,
		snapshot.totalFiles)
	fmt.Fprintf(os.Stderr, "  Average:  %s/s\n", formatBytes(averageRate))
	fmt.Fprintf(os.Stderr, "  Elapsed:  %s\n", formatDuration(elapsed))
}

func percentage(current, total int64) string {
	if total <= 0 {
		return "  0.0%"
	}
	pct := float64(current) / float64(total) * 100
	if pct > 100 {
		pct = 100
	}
	return fmt.Sprintf("%5.1f%%", pct)
}

func formatBytes(b int64) string {
	const (
		KB = 1024
		MB = 1024 * KB
		GB = 1024 * MB
	)
	switch {
	case b >= GB:
		return fmt.Sprintf("%.1f GB", float64(b)/float64(GB))
	case b >= MB:
		return fmt.Sprintf("%.1f MB", float64(b)/float64(MB))
	case b >= KB:
		return fmt.Sprintf("%.1f KB", float64(b)/float64(KB))
	default:
		return fmt.Sprintf("%d B", b)
	}
}

func formatDuration(d time.Duration) string {
	if d < time.Second {
		return fmt.Sprintf("%dms", d.Milliseconds())
	}
	if d < time.Minute {
		return fmt.Sprintf("%.1fs", d.Seconds())
	}
	m := int(d.Minutes())
	s := int(d.Seconds()) % 60
	return fmt.Sprintf("%dm%ds", m, s)
}
