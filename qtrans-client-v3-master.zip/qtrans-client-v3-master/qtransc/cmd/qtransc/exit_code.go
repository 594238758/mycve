package main

import (
	"errors"
	"fmt"
	"os"
	"qtransc/internal/clienterror"
	"syscall"
)

type commandExitError struct {
	code int
	err  error
}

func (e *commandExitError) Error() string {
	if e == nil || e.err == nil {
		return ""
	}
	return e.err.Error()
}

func (e *commandExitError) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.err
}

func withCommandExitCode(err error, code int) error {
	if code <= 0 {
		return err
	}
	if err == nil {
		err = fmt.Errorf("interrupted")
	}
	return &commandExitError{code: code, err: err}
}

func commandExitCode(err error) int {
	if err == nil {
		return 0
	}
	var exitErr *commandExitError
	if errors.As(err, &exitErr) && exitErr.code > 0 {
		return exitErr.code
	}
	switch clienterror.ReasonCode(err) {
	case clienterror.CodeInvalidArgument,
		clienterror.CodeAuthConfigInvalid,
		clienterror.CodeFileTooLarge,
		clienterror.CodeTaskFileLimitExceeded,
		clienterror.CodeLocalFileNotFound,
		clienterror.CodeLocalPathInvalid,
		clienterror.CodeTaskSizeLimitExceeded:
		return 2
	}
	return 1
}

func exitCodeForSignal(sig os.Signal) int {
	if sig == syscall.SIGTERM {
		return 143
	}
	return 130
}
