package main

import (
	"fmt"
	"io"
	"os"
	"time"

	"github.com/mattn/go-isatty"
	"github.com/mattn/go-runewidth"
)

const (
	recursiveDeleteProgressTTYInterval = 120 * time.Millisecond
	recursiveDeleteProgressLogInterval = time.Second
	recursiveDeleteProgressRateWindow  = 5 * time.Second
	recursiveDeleteProgressPathWidth   = 56
)

type recursiveDeleteProgressSample struct {
	at      time.Time
	deleted int
}

type recursiveDeleteProgress struct {
	output      io.Writer
	interactive bool
	startedAt   time.Time
	lastOutput  time.Time
	state       string
	path        string
	deleted     int
	samples     []recursiveDeleteProgressSample
	finished    bool
}

func newRecursiveDeleteProgress(output io.Writer, remotePath string) *recursiveDeleteProgress {
	startedAt := time.Now()
	progress := &recursiveDeleteProgress{
		output:      output,
		interactive: isTerminalWriter(output),
		startedAt:   startedAt,
		state:       "开始递归删除",
		path:        remotePath,
		samples: []recursiveDeleteProgressSample{
			{at: startedAt},
		},
	}
	progress.render(true)
	return progress
}

func isTerminalWriter(output io.Writer) bool {
	file, ok := output.(*os.File)
	return ok && isatty.IsTerminal(file.Fd())
}

func (progress *recursiveDeleteProgress) scanning(remotePath string) {
	if progress == nil || progress.finished {
		return
	}
	progress.state = "正在扫描"
	progress.path = remotePath
	progress.render(false)
}

func (progress *recursiveDeleteProgress) deleting(remotePath string) {
	if progress == nil || progress.finished {
		return
	}
	progress.state = "正在删除"
	progress.path = remotePath
	progress.render(false)
}

func (progress *recursiveDeleteProgress) deletedNode(total int) {
	if progress == nil || progress.finished {
		return
	}
	progress.deleted = total
	progress.render(false)
}

func (progress *recursiveDeleteProgress) finish(success bool) {
	if progress == nil || progress.finished {
		return
	}
	if success {
		progress.state = "递归删除完成"
	} else {
		progress.state = "递归删除结束"
	}
	progress.render(true)
	if progress.interactive {
		_, _ = fmt.Fprintln(progress.output)
	}
	progress.finished = true
}

func (progress *recursiveDeleteProgress) render(force bool) {
	now := time.Now()
	if !force && !progress.lastOutput.IsZero() {
		interval := recursiveDeleteProgressLogInterval
		if progress.interactive {
			interval = recursiveDeleteProgressTTYInterval
		}
		if now.Sub(progress.lastOutput) < interval {
			return
		}
	}

	rate := progress.recordRateSample(now)
	path := runewidth.Truncate(progress.path, recursiveDeleteProgressPathWidth, "...")
	line := fmt.Sprintf(
		"%s：已删除 %d 个节点 · %.1f 节点/秒 · 已用 %s · 当前：%s",
		progress.state,
		progress.deleted,
		rate,
		formatDuration(now.Sub(progress.startedAt)),
		path,
	)
	if progress.interactive {
		_, _ = fmt.Fprintf(progress.output, "\r\033[2K%s", line)
	} else {
		_, _ = fmt.Fprintln(progress.output, line)
	}
	progress.lastOutput = now
}

func (progress *recursiveDeleteProgress) recordRateSample(now time.Time) float64 {
	progress.samples = append(progress.samples, recursiveDeleteProgressSample{at: now, deleted: progress.deleted})
	cutoff := now.Add(-recursiveDeleteProgressRateWindow)
	first := 0
	for first+1 < len(progress.samples) && progress.samples[first+1].at.Before(cutoff) {
		first++
	}
	progress.samples = progress.samples[first:]
	oldest := progress.samples[0]
	elapsed := now.Sub(oldest.at)
	if elapsed <= 0 {
		return 0
	}
	return float64(progress.deleted-oldest.deleted) / elapsed.Seconds()
}
