//go:build windows

package main

import (
	"os"
	"sync"

	"github.com/mattn/go-isatty"
	"golang.org/x/sys/windows"
)

func suppressTerminalInputEcho() func() {
	if os.Stdin == nil || os.Stderr == nil ||
		!isatty.IsTerminal(os.Stdin.Fd()) ||
		!isatty.IsTerminal(os.Stderr.Fd()) {
		return func() {}
	}

	handle := windows.Handle(os.Stdin.Fd())
	var originalMode uint32
	if err := windows.GetConsoleMode(handle, &originalMode); err != nil {
		return func() {}
	}
	quietMode := originalMode &^ windows.ENABLE_ECHO_INPUT
	if err := windows.SetConsoleMode(handle, quietMode); err != nil {
		return func() {}
	}

	var once sync.Once
	return func() {
		once.Do(func() {
			_ = windows.FlushConsoleInputBuffer(handle)
			_ = windows.SetConsoleMode(handle, originalMode)
		})
	}
}
