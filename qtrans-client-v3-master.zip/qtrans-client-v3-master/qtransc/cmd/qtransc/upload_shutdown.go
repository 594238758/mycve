package main

import (
	"context"
	"os"
	"os/signal"
	"qtransc/internal/uploadtask"
	"sync"
	"sync/atomic"
	"syscall"
)

type uploadTaskShutdownController struct {
	task   *uploadtask.UploadTask
	cancel context.CancelFunc
	once   sync.Once
	code   atomic.Int32
}

func newUploadTaskShutdownController(task *uploadtask.UploadTask, cancel context.CancelFunc) *uploadTaskShutdownController {
	return &uploadTaskShutdownController{
		task:   task,
		cancel: cancel,
	}
}

func (c *uploadTaskShutdownController) StopGracefully() {
	if c == nil {
		return
	}
	c.once.Do(func() {
		if c.task != nil {
			_ = c.task.Stop()
		}
		if c.cancel != nil {
			c.cancel()
		}
	})
}

func (c *uploadTaskShutdownController) InstallSignalHandler() func() {
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	stopCh := make(chan struct{})
	go func() {
		select {
		case received := <-sigCh:
			c.code.Store(int32(exitCodeForSignal(received)))
			c.StopGracefully()
		case <-stopCh:
		}
	}()

	return func() {
		signal.Stop(sigCh)
		close(stopCh)
	}
}

func (c *uploadTaskShutdownController) ExitCode() int {
	if c == nil {
		return 0
	}
	return int(c.code.Load())
}
