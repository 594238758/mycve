//go:build darwin

package main

import "golang.org/x/sys/unix"

const (
	terminalGetAttributes     = unix.TIOCGETA
	terminalSetAttributes     = unix.TIOCSETA
	terminalRestoreAttributes = unix.TIOCSETAF
)
