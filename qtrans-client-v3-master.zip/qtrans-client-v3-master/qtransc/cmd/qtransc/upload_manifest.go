package main

import (
	"fmt"
	"io/fs"
	"math"
	"os"
	"path"
	"path/filepath"
	"qtransc/internal/clienterror"
	"qtransc/internal/transferlimits"
	"qtransc/internal/types"
	"sort"
	"strings"
)

type uploadSourceFile struct {
	LocalAbsPath string
	ObjectKey    string
}

const (
	maxPlannedFiles       = transferlimits.MaxTaskFiles
	maxPlannedEntries     = 200000
	maxPlannedDepth       = 128
	maxRemotePathBytes    = 1024
	maxRemoteSegmentBytes = 255
)

func parseUploadDestination(rawServer, rawPath string, transport types.TransportMode) (string, string, error) {
	if rawPath == "" {
		return "", "", fmt.Errorf("remote destination is required")
	}

	parsed, err := ParseRemotePath(rawServer, rawPath, transport)
	if err != nil {
		return "", "", fmt.Errorf("parse remote destination: %w", err)
	}
	destination := "/"
	if parsed.ObjectKey != "" {
		destination, err = normalizeUploadDist(parsed.ObjectKey)
		if err != nil {
			return "", "", fmt.Errorf("parse remote destination path: %w", err)
		}
	}

	return parsed.ServerURL, destination, nil
}

func expandUploadSources(sources []string, destination string) ([]uploadSourceFile, []string, error) {
	if len(sources) == 0 {
		return nil, nil, clienterror.New(clienterror.CodeLocalPathInvalid, "至少需要指定一个本地上传路径", nil)
	}

	expanded := make([]uploadSourceFile, 0, len(sources))
	allDirs := make(map[string]bool)
	targets := make(map[string]string)
	targetKinds := make(map[string]string)
	registerTarget := func(objectKey, kind, origin string) error {
		if previousOrigin, exists := targets[objectKey]; exists {
			return fmt.Errorf(
				"upload sources %s and %s both map to remote %s %q",
				previousOrigin,
				origin,
				targetKinds[objectKey],
				objectKey,
			)
		}
		targets[objectKey] = origin
		targetKinds[objectKey] = kind
		return nil
	}
	for index, source := range sources {
		if source == "" {
			return nil, nil, clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("第 %d 个本地路径不能为空", index+1), nil)
		}

		absSource, err := filepath.Abs(source)
		if err != nil {
			return nil, nil, clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("无法解析第 %d 个本地路径", index+1), err)
		}
		info, err := os.Lstat(absSource)
		if err != nil {
			if os.IsNotExist(err) {
				return nil, nil, clienterror.New(clienterror.CodeLocalFileNotFound, fmt.Sprintf("本地上传源不存在：%s", absSource), err)
			}
			return nil, nil, clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("无法读取本地上传源：%s", absSource), err)
		}
		if info.Mode()&os.ModeSymlink != 0 {
			return nil, nil, clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("本地上传源不能是符号链接：%s", absSource), nil)
		}

		switch {
		case info.Mode().IsRegular():
			file := uploadSourceFile{
				LocalAbsPath: absSource,
				ObjectKey:    joinUploadObjectKey(destination, filepath.Base(absSource)),
			}
			if err := validatePlannedRemotePath(file.ObjectKey); err != nil {
				return nil, nil, err
			}
			if err := registerTarget(file.ObjectKey, "path", absSource); err != nil {
				return nil, nil, err
			}
			expanded = append(expanded, file)
		case info.IsDir():
			dirFiles, dirPaths, err := expandUploadDirectory(absSource, destination)
			if err != nil {
				return nil, nil, fmt.Errorf("expand local directory %d: %w", index+1, err)
			}
			for _, d := range dirPaths {
				if err := registerTarget(d, "path", absSource); err != nil {
					return nil, nil, err
				}
			}
			for _, file := range dirFiles {
				if err := registerTarget(file.ObjectKey, "path", absSource); err != nil {
					return nil, nil, err
				}
			}
			expanded = append(expanded, dirFiles...)
			for _, d := range dirPaths {
				allDirs[d] = true
			}
		default:
			return nil, nil, clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("本地上传源不是普通文件或目录：%s", absSource), nil)
		}
	}
	if err := validateUploadPlanLimits(len(expanded), len(allDirs)); err != nil {
		return nil, nil, err
	}

	dirList := make([]string, 0, len(allDirs))
	for d := range allDirs {
		dirList = append(dirList, d)
	}
	sort.Strings(dirList)

	if len(expanded) == 0 && len(dirList) == 0 {
		return nil, nil, fmt.Errorf("local paths did not resolve to any transferable files or directories")
	}
	return expanded, dirList, nil
}

func validateUploadPlanLimits(fileCount, dirCount int) error {
	if fileCount > maxPlannedFiles {
		return transferlimits.TaskFileLimitExceeded(fileCount)
	}
	if fileCount+dirCount > maxPlannedEntries {
		return fmt.Errorf("upload planning exceeds %d total entries", maxPlannedEntries)
	}
	return nil
}

func totalUploadSourceSize(files []uploadSourceFile) (int64, error) {
	var total int64
	for _, file := range files {
		info, err := os.Stat(file.LocalAbsPath)
		if err != nil {
			if os.IsNotExist(err) {
				return 0, clienterror.New(clienterror.CodeLocalFileNotFound, fmt.Sprintf("本地上传源不存在：%s", file.LocalAbsPath), err)
			}
			return 0, clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("无法读取本地上传源：%s", file.LocalAbsPath), err)
		}
		if !info.Mode().IsRegular() {
			return 0, clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("本地上传源不是普通文件：%s", file.LocalAbsPath), nil)
		}
		if info.Size() > math.MaxInt64-total {
			return 0, fmt.Errorf("upload total size exceeds int64")
		}
		total += info.Size()
	}
	return total, nil
}

func checkUploadLimitSize(files []uploadSourceFile, limitBytes int64) error {
	if limitBytes <= 0 {
		return nil
	}
	total, err := totalUploadSourceSize(files)
	if err != nil {
		return err
	}
	if total > limitBytes {
		return transferlimits.TaskSizeLimitExceeded(total, limitBytes)
	}
	return nil
}

func expandUploadDirectory(absSourceDir, dist string) ([]uploadSourceFile, []string, error) {
	rootObjectKey := joinUploadObjectKey(dist, filepath.Base(filepath.Clean(absSourceDir)))
	files := make([]uploadSourceFile, 0)
	dirs := make(map[string]bool)

	err := filepath.WalkDir(absSourceDir, func(current string, d fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if current != absSourceDir && d.Type()&os.ModeSymlink != 0 {
			fmt.Fprintf(os.Stderr, "warning: skipped local symbolic link %s\n", current)
			return nil
		}
		if d.IsDir() {
			relDir, err := filepath.Rel(absSourceDir, current)
			if err != nil {
				return fmt.Errorf("build relative dir path for %s: %w", current, err)
			}
			dirObjectKey := rootObjectKey
			if relDir != "." {
				if depth := len(strings.Split(filepath.ToSlash(relDir), "/")); depth > maxPlannedDepth {
					return fmt.Errorf("directory depth exceeds %d at %s", maxPlannedDepth, current)
				}
				dirObjectKey = joinUploadObjectKey(rootObjectKey, filepath.ToSlash(relDir))
			}
			if err := validatePlannedRemotePath(dirObjectKey); err != nil {
				return err
			}
			if dirObjectKey != "" {
				dirs[dirObjectKey] = true
			}
			if len(dirs)+len(files) > maxPlannedEntries {
				return fmt.Errorf("upload planning exceeds %d total entries", maxPlannedEntries)
			}
			return nil
		}
		info, err := d.Info()
		if err != nil {
			return err
		}
		if !info.Mode().IsRegular() {
			fmt.Fprintf(os.Stderr, "warning: skipped local special node %s\n", current)
			return nil
		}

		relPath, err := filepath.Rel(absSourceDir, current)
		if err != nil {
			return fmt.Errorf("build relative path for %s: %w", current, err)
		}
		objectKey := joinUploadObjectKey(rootObjectKey, filepath.ToSlash(relPath))
		if err := validatePlannedRemotePath(objectKey); err != nil {
			return err
		}
		files = append(files, uploadSourceFile{
			LocalAbsPath: current,
			ObjectKey:    objectKey,
		})
		if err := validateUploadPlanLimits(len(files), len(dirs)); err != nil {
			return err
		}
		return nil
	})
	if err != nil {
		return nil, nil, err
	}

	// 同时从文件路径中提取所有父目录，确保无遗漏
	for _, f := range files {
		for p := path.Dir(f.ObjectKey); p != "." && p != "/"; p = path.Dir(p) {
			dirs[p] = true
		}
	}

	dirList := make([]string, 0, len(dirs))
	for d := range dirs {
		dirList = append(dirList, d)
	}
	sort.Strings(dirList)

	return files, dirList, nil
}

func validatePlannedRemotePath(raw string) error {
	logical, err := normalizeRemoteAbsolutePath(raw, true)
	if err != nil {
		return fmt.Errorf("invalid planned remote path %q: %w", raw, err)
	}
	if logical != raw {
		return fmt.Errorf("planned remote path is not canonical: %q", raw)
	}
	return nil
}

func normalizeUploadDist(raw string) (string, error) {
	if raw == "" {
		return "", fmt.Errorf("must not be empty")
	}
	return normalizeRemoteAbsolutePath("/"+strings.Trim(raw, "/"), true)
}

func joinUploadObjectKey(dist, relPath string) string {
	normalizedRel := strings.Trim(relPath, "/")
	if dist == "" || dist == "/" {
		return "/" + normalizedRel
	}
	return "/" + strings.TrimPrefix(path.Join(dist, normalizedRel), "/")
}

func buildUploadTaskRequestFromSourceFiles(taskID, taskName, bearerToken, serverURL string, transport types.TransportMode, files []uploadSourceFile, dirPaths []string, useAuthManager bool) (*types.TaskCreateRequest, map[string]string, error) {
	if strings.TrimSpace(bearerToken) == "" && !useAuthManager {
		return nil, nil, fmt.Errorf("--auth-token is required")
	}
	if len(files) == 0 && len(dirPaths) == 0 {
		return nil, nil, fmt.Errorf("upload source list is empty")
	}

	var (
		sourceDir    string
		specs        []types.TaskFileSpec
		absPathByRel map[string]string
		err          error
	)
	if len(files) == 0 {
		sourceDir, err = os.Getwd()
		if err != nil {
			return nil, nil, fmt.Errorf("determine upload source directory: %w", err)
		}
		specs = []types.TaskFileSpec{}
		absPathByRel = map[string]string{}
	} else {
		sourceDir, specs, absPathByRel, err = buildUploadTaskFileSpecs(files)
		if err != nil {
			return nil, nil, err
		}
	}

	req := &types.TaskCreateRequest{
		BearerToken:    bearerToken,
		TaskID:         taskID,
		TaskName:       taskName,
		Mode:           "upload",
		Transport:      transport.String(),
		ServerAddr:     serverURL,
		SourceDir:      sourceDir,
		FileList:       specs,
		DirPaths:       dirPaths,
		UseAuthManager: useAuthManager,
		StateDBPath:    cliStateDB,
	}
	if err := req.Validate(); err != nil {
		return nil, nil, err
	}
	return req, absPathByRel, nil
}

func buildUploadTaskFileSpecs(files []uploadSourceFile) (string, []types.TaskFileSpec, map[string]string, error) {
	commonDir := filepath.Dir(files[0].LocalAbsPath)
	for _, file := range files[1:] {
		commonDir = commonPathDir(commonDir, filepath.Dir(file.LocalAbsPath))
	}
	if commonDir == "" {
		return "", nil, nil, fmt.Errorf("failed to determine common source directory")
	}

	return buildUploadTaskFileSpecsUnderSourceDir(commonDir, files)
}

func buildUploadTaskFileSpecsUnderSourceDir(sourceDir string, files []uploadSourceFile) (string, []types.TaskFileSpec, map[string]string, error) {
	sourceDir = filepath.Clean(sourceDir)
	if sourceDir == "" {
		return "", nil, nil, fmt.Errorf("failed to determine common source directory")
	}

	specs := make([]types.TaskFileSpec, 0, len(files))
	absPathByRel := make(map[string]string, len(files))
	objectKeyToLocal := make(map[string]string, len(files))
	for _, file := range files {
		info, err := os.Stat(file.LocalAbsPath)
		if err != nil {
			return "", nil, nil, fmt.Errorf("stat upload file %s: %w", file.LocalAbsPath, err)
		}
		if !info.Mode().IsRegular() {
			return "", nil, nil, fmt.Errorf("upload file is not a regular file: %s", file.LocalAbsPath)
		}

		relPath, err := filepath.Rel(sourceDir, file.LocalAbsPath)
		if err != nil {
			return "", nil, nil, fmt.Errorf("build relative path for %s: %w", file.LocalAbsPath, err)
		}
		relPath = filepath.Clean(relPath)
		if filepath.IsAbs(relPath) || strings.HasPrefix(relPath, ".."+string(filepath.Separator)) || relPath == ".." {
			return "", nil, nil, fmt.Errorf("file %s is outside common source directory %s", file.LocalAbsPath, sourceDir)
		}
		if _, exists := absPathByRel[relPath]; exists {
			return "", nil, nil, fmt.Errorf("duplicate relative path %s derived from upload files", relPath)
		}
		if existing, exists := objectKeyToLocal[file.ObjectKey]; exists {
			return "", nil, nil, fmt.Errorf("duplicate upload destination %s derived from %s and %s", file.ObjectKey, existing, file.LocalAbsPath)
		}
		absPathByRel[relPath] = file.LocalAbsPath
		objectKeyToLocal[file.ObjectKey] = file.LocalAbsPath
		specs = append(specs, types.TaskFileSpec{
			LocalRelPath: relPath,
			ObjectKey:    file.ObjectKey,
		})
	}

	return sourceDir, specs, absPathByRel, nil
}

func commonPathDir(a, b string) string {
	a = filepath.Clean(a)
	b = filepath.Clean(b)
	for {
		rel, err := filepath.Rel(a, b)
		if err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
			return a
		}
		parent := filepath.Dir(a)
		if parent == a {
			return a
		}
		a = parent
	}
}
