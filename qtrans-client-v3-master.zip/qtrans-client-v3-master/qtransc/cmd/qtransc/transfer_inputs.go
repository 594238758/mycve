package main

import (
	"fmt"
	"os"
	"path"
	"path/filepath"
	"strings"
	"unicode/utf8"

	"qtransc/internal/clienterror"

	"github.com/spf13/cobra"
)

const defaultDownloadDirectoryName = "qtransdownload"

type singleStringFlagValue struct {
	name   string
	target *string
	set    bool
}

func (v *singleStringFlagValue) Set(raw string) error {
	if v.set {
		return fmt.Errorf("--%s may only be specified once", v.name)
	}
	v.set = true
	*v.target = raw
	return nil
}

func (v *singleStringFlagValue) String() string {
	if v == nil || v.target == nil {
		return ""
	}
	return *v.target
}

func (v *singleStringFlagValue) Type() string {
	return "string"
}

type transferSourceInput struct {
	Path         string
	Origin       string
	FromFileList bool
}

type transferCLIInputs struct {
	Sources            []string
	Destination        string
	DefaultDestination bool
}

func resolveDownloadCLIInputs(cmd *cobra.Command, args []string, flagSources []string, fileListPath, destination string) (*transferCLIInputs, error) {
	explicitMode := cmd.Flags().Changed("source") || cmd.Flags().Changed("filelist") || cmd.Flags().Changed("destination")
	if len(args) > 0 && explicitMode {
		return nil, fmt.Errorf("download positional mode cannot be combined with --source, --filelist, or --destination")
	}

	var (
		inputs             []transferSourceInput
		rawDestination     string
		defaultDestination bool
	)
	if len(args) > 0 {
		if len(args) > 2 {
			return nil, fmt.Errorf("download positional mode accepts one remote source and an optional local destination")
		}
		inputs = []transferSourceInput{{Path: args[0], Origin: "remote source argument"}}
		if len(args) == 2 {
			rawDestination = args[1]
		} else {
			defaultDestination = true
		}
	} else {
		loaded, err := resolveExplicitTransferSources(flagSources, fileListPath)
		if err != nil {
			return nil, err
		}
		inputs = loaded
		if cmd.Flags().Changed("destination") {
			rawDestination = destination
		} else {
			defaultDestination = true
		}
	}

	sources, err := normalizeDownloadSources(inputs)
	if err != nil {
		return nil, err
	}
	resolvedDestination, err := resolveDownloadDestination(rawDestination, defaultDestination)
	if err != nil {
		return nil, err
	}
	if err := rejectDuplicateDownloadTargets(sources); err != nil {
		return nil, err
	}
	return &transferCLIInputs{
		Sources:            sources,
		Destination:        resolvedDestination,
		DefaultDestination: defaultDestination,
	}, nil
}

func resolveUploadCLIInputs(cmd *cobra.Command, args []string, flagSources []string, fileListPath, destination string) (*transferCLIInputs, error) {
	explicitMode := cmd.Flags().Changed("source") || cmd.Flags().Changed("filelist") || cmd.Flags().Changed("destination")
	if len(args) > 0 && explicitMode {
		return nil, fmt.Errorf("upload positional mode cannot be combined with --source, --filelist, or --destination")
	}

	var (
		inputs         []transferSourceInput
		rawDestination string
	)
	if len(args) > 0 {
		if len(args) == 1 {
			return nil, clienterror.New(clienterror.CodeInvalidArgument, "缺少远端目标目录。", nil)
		}
		if len(args) != 2 {
			return nil, fmt.Errorf("upload positional mode requires exactly one local source and one remote destination")
		}
		inputs = []transferSourceInput{{Path: args[0], Origin: "local source argument"}}
		rawDestination = args[1]
	} else {
		loaded, err := resolveExplicitTransferSources(flagSources, fileListPath)
		if err != nil {
			return nil, err
		}
		inputs = loaded
		if !cmd.Flags().Changed("destination") {
			return nil, fmt.Errorf("--destination is required in upload explicit mode")
		}
		rawDestination = destination
	}

	sources, err := normalizeUploadSources(inputs)
	if err != nil {
		return nil, err
	}
	normalizedDestination, err := normalizeRemoteAbsolutePath(rawDestination, true)
	if err != nil {
		return nil, fmt.Errorf("remote destination: %w", err)
	}
	return &transferCLIInputs{
		Sources:     sources,
		Destination: normalizedDestination,
	}, nil
}

func resolveExplicitTransferSources(flagSources []string, fileListPath string) ([]transferSourceInput, error) {
	hasSources := len(flagSources) > 0
	hasFileList := fileListPath != ""
	if hasSources && hasFileList {
		return nil, fmt.Errorf("--source and --filelist cannot be used together")
	}
	if !hasSources && !hasFileList {
		return nil, fmt.Errorf("one or more --source values or --filelist is required")
	}
	if hasSources {
		inputs := make([]transferSourceInput, 0, len(flagSources))
		for index, source := range flagSources {
			inputs = append(inputs, transferSourceInput{
				Path:   source,
				Origin: fmt.Sprintf("--source value %d", index+1),
			})
		}
		return inputs, nil
	}
	return loadTransferFileList(fileListPath)
}

func loadTransferFileList(rawPath string) ([]transferSourceInput, error) {
	listPath := rawPath
	if listPath == "" {
		return nil, fmt.Errorf("--filelist must not be empty")
	}
	content, err := os.ReadFile(listPath)
	if err != nil {
		return nil, fmt.Errorf("read --filelist %q: %w", rawPath, err)
	}
	if !utf8.Valid(content) {
		return nil, fmt.Errorf("--filelist %q must be UTF-8 encoded", rawPath)
	}

	lines := strings.Split(string(content), "\n")
	inputs := make([]transferSourceInput, 0, len(lines))
	for index, line := range lines {
		line = strings.TrimSuffix(line, "\r")
		if line == "" {
			continue
		}
		inputs = append(inputs, transferSourceInput{
			Path:         line,
			Origin:       fmt.Sprintf("%s:%d", listPath, index+1),
			FromFileList: true,
		})
	}
	if len(inputs) == 0 {
		return nil, fmt.Errorf("--filelist %q contains no sources", rawPath)
	}
	return inputs, nil
}

func normalizeDownloadSources(inputs []transferSourceInput) ([]string, error) {
	normalized := make([]string, 0, len(inputs))
	seen := make(map[string]string, len(inputs))
	for _, input := range inputs {
		source, err := normalizeRemoteAbsolutePath(input.Path, false)
		if err != nil {
			return nil, fmt.Errorf("%s: %w", input.Origin, err)
		}
		if previous, exists := seen[source]; exists {
			return nil, fmt.Errorf("duplicate remote source %q in %s and %s", source, previous, input.Origin)
		}
		seen[source] = input.Origin
		normalized = append(normalized, source)
	}
	return normalized, nil
}

func normalizeUploadSources(inputs []transferSourceInput) ([]string, error) {
	normalized := make([]string, 0, len(inputs))
	seen := make(map[string]string, len(inputs))
	for _, input := range inputs {
		if input.Path == "" {
			return nil, fmt.Errorf("%s: local source must not be empty", input.Origin)
		}
		if input.FromFileList && !filepath.IsAbs(input.Path) {
			return nil, fmt.Errorf("%s: upload filelist entries must be absolute paths", input.Origin)
		}
		absolute, err := filepath.Abs(input.Path)
		if err != nil {
			return nil, fmt.Errorf("%s: resolve local source: %w", input.Origin, err)
		}
		absolute = filepath.Clean(absolute)
		if previous, exists := seen[absolute]; exists {
			return nil, fmt.Errorf("duplicate local source %q in %s and %s", absolute, previous, input.Origin)
		}
		seen[absolute] = input.Origin
		normalized = append(normalized, absolute)
	}
	return normalized, nil
}

func normalizeRemoteAbsolutePath(raw string, allowRoot bool) (string, error) {
	value := raw
	if value == "" || !strings.HasPrefix(value, "/") {
		return "", fmt.Errorf("must be an absolute remote path beginning with /")
	}
	if !utf8.ValidString(value) || strings.ContainsRune(value, '\x00') || strings.ContainsRune(value, '\\') {
		return "", fmt.Errorf("must be valid UTF-8 and must not contain NUL or backslash")
	}
	segments := make([]string, 0)
	for _, segment := range strings.Split(value, "/") {
		if segment == "" {
			continue
		}
		if segment == "." || segment == ".." {
			return "", fmt.Errorf("must not contain dot segments")
		}
		if len(segment) > maxRemoteSegmentBytes {
			return "", fmt.Errorf("remote path segment exceeds %d bytes", maxRemoteSegmentBytes)
		}
		segments = append(segments, segment)
	}
	cleaned := "/" + strings.Join(segments, "/")
	if len(cleaned) > maxRemotePathBytes {
		return "", fmt.Errorf("remote path exceeds %d bytes", maxRemotePathBytes)
	}
	if cleaned == "/" {
		if allowRoot {
			return "/", nil
		}
		return "", fmt.Errorf("remote root / is not allowed here")
	}
	return cleaned, nil
}

func resolveDownloadDestination(raw string, useDefault bool) (string, error) {
	destination := raw
	if useDefault {
		homeDir, err := os.UserHomeDir()
		if err != nil {
			return "", clienterror.New(clienterror.CodeLocalPathInvalid, "无法确定本地用户目录", err)
		}
		destination = filepath.Join(homeDir, defaultDownloadDirectoryName)
		if err := os.MkdirAll(destination, 0o755); err != nil {
			return "", clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("无法创建默认下载目录：%s", destination), err)
		}
	} else if destination == "" {
		return "", clienterror.New(clienterror.CodeLocalPathInvalid, "本地下载目标不能为空", nil)
	}

	absolute, err := filepath.Abs(destination)
	if err != nil {
		return "", clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("无法解析本地下载目标：%s", destination), err)
	}
	info, err := os.Stat(absolute)
	if err != nil {
		if os.IsNotExist(err) && !useDefault {
			return "", clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("本地下载目标不存在：%s", absolute), err)
		}
		return "", clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("无法读取本地下载目标：%s", absolute), err)
	}
	if !info.IsDir() {
		return "", clienterror.New(clienterror.CodeLocalPathInvalid, fmt.Sprintf("本地下载目标不是目录：%s", absolute), nil)
	}
	return absolute, nil
}

func rejectDuplicateDownloadTargets(sources []string) error {
	targets := make(map[string]string, len(sources))
	for _, source := range sources {
		name := path.Base(source)
		if previous, exists := targets[name]; exists {
			return fmt.Errorf("download sources %q and %q both map to destination name %q", previous, source, name)
		}
		targets[name] = source
	}
	return nil
}
