package main

import (
	"fmt"
	"net"
	"net/url"
	"strconv"
	"strings"

	"qtransc/internal/clienterror"
	"qtransc/internal/types"
)

// QtransURL represents a parsed qtrans:// URL.
//
// Canonical format: qtrans://host:port/object_key
//
// Examples:
//
//	qtrans://qt.cncb.ac.cn:443/gsa/1G      → HTTPS3
//	qtrans://127.0.0.1:10001/private/demo  → HTTPS
type QtransURL struct {
	Host      string // host:port, e.g. "qt.cncb.ac.cn:443"
	ObjectKey string // remote path, e.g. "gsa/1G" or "" for root
	ServerURL string // full server URL, e.g. "https://qt.cncb.ac.cn:443"
}

const defaultQtransPort = types.DefaultServerPort

// ParseQtransURL parses a qtrans remote address. It remains the low-level
// parser used to validate the independently supplied server and remote path.
func ParseQtransURL(rawURL string, transport types.TransportMode) (*QtransURL, error) {
	normalizedInput, err := normalizeQtransInput(rawURL)
	if err != nil {
		return nil, err
	}

	u, err := url.Parse(normalizedInput)
	if err != nil {
		return nil, fmt.Errorf("invalid URL %q: %w", rawURL, err)
	}

	if !strings.EqualFold(u.Scheme, "qtrans") {
		return nil, fmt.Errorf("unsupported scheme %q, expected \"qtrans\"", u.Scheme)
	}
	if u.User != nil {
		return nil, fmt.Errorf("userinfo is not allowed in qtrans URL %q", rawURL)
	}
	if u.RawQuery != "" || u.ForceQuery {
		return nil, fmt.Errorf("query is not allowed in qtrans URL %q", rawURL)
	}
	if u.Fragment != "" || strings.Contains(normalizedInput, "#") {
		return nil, fmt.Errorf("fragment is not allowed in qtrans URL %q", rawURL)
	}

	host := strings.ToLower(strings.TrimSpace(u.Hostname()))
	if host == "" {
		return nil, fmt.Errorf("missing host in URL %q", rawURL)
	}
	if strings.HasSuffix(u.Host, ":") {
		return nil, fmt.Errorf("missing port in URL %q", rawURL)
	}
	port := u.Port()
	if port == "" {
		port = defaultQtransPort
	}
	portNumber, err := strconv.Atoi(port)
	if err != nil || portNumber < 1 || portNumber > 65535 {
		return nil, fmt.Errorf("invalid port %q in URL %q", port, rawURL)
	}
	hostPort := net.JoinHostPort(host, port)

	return &QtransURL{
		Host:      hostPort,
		ObjectKey: strings.Trim(u.Path, "/"),
		ServerURL: fmt.Sprintf("%s://%s", transport.ServerScheme(), hostPort),
	}, nil
}

// ParseQtransServer parses --server. A path is not allowed because remote paths
// are command operands.
func ParseQtransServer(rawServer string, transport types.TransportMode) (*QtransURL, error) {
	trimmedServer := strings.TrimSpace(rawServer)
	if trimmedServer == "" {
		return nil, invalidServerArgumentError(fmt.Errorf("--server is required"))
	}
	if strings.Contains(trimmedServer, "://") {
		return nil, invalidServerArgumentError(fmt.Errorf("invalid --server %q: expected host[:port] without a scheme", rawServer))
	}
	if strings.Contains(trimmedServer, "/") {
		return nil, invalidServerArgumentError(fmt.Errorf("invalid --server %q: expected host[:port] without a path", rawServer))
	}
	parsed, err := ParseQtransURL(trimmedServer, transport)
	if err != nil {
		return nil, invalidServerArgumentError(fmt.Errorf("invalid --server: %w", err))
	}
	if parsed.ObjectKey != "" {
		return nil, invalidServerArgumentError(fmt.Errorf("invalid --server %q: remote path must be supplied as a command argument", rawServer))
	}
	return parsed, nil
}

func invalidServerArgumentError(cause error) error {
	return clienterror.New(clienterror.CodeInvalidArgument, "--server 参数不合法", cause)
}

// ParseRemotePath combines the independently supplied server and remote path
// into the internal representation used by qtserver requests.
func ParseRemotePath(rawServer, remotePath string, transport types.TransportMode) (*QtransURL, error) {
	parsed, err := ParseQtransServer(rawServer, transport)
	if err != nil {
		return nil, err
	}

	if strings.Contains(remotePath, "://") {
		return nil, fmt.Errorf("remote path %q must not contain a server; use --server", remotePath)
	}
	if strings.ContainsAny(remotePath, "?#") {
		return nil, fmt.Errorf("remote path %q must not contain query or fragment", remotePath)
	}
	parsed.ObjectKey = strings.Trim(remotePath, "/")
	return parsed, nil
}

func canonicalRemoteAddress(rawServer, remotePath string, transport types.TransportMode) (string, error) {
	parsed, err := ParseRemotePath(rawServer, remotePath, transport)
	if err != nil {
		return "", err
	}
	location := "qtrans://" + parsed.Host + "/"
	if parsed.ObjectKey != "" {
		location += parsed.ObjectKey
	}
	return location, nil
}

func normalizeQtransInput(rawURL string) (string, error) {
	trimmed := strings.TrimSpace(rawURL)
	if trimmed == "" {
		return "", fmt.Errorf("qtrans URL cannot be empty")
	}
	if strings.Contains(trimmed, "://") {
		return trimmed, nil
	}

	authority := trimmed
	if index := strings.IndexAny(authority, "/?#"); index >= 0 {
		authority = authority[:index]
	}
	if strings.Count(authority, ":") > 1 && !strings.HasPrefix(authority, "[") {
		return "", fmt.Errorf("IPv6 address must be enclosed in brackets in qtrans URL %q", rawURL)
	}
	return "qtrans://" + trimmed, nil
}

// ParseRemotePaths parses multiple paths against one --server value.
func ParseRemotePaths(rawServer string, remotePaths []string, transport types.TransportMode) ([]*QtransURL, string, error) {
	if len(remotePaths) == 0 {
		return nil, "", fmt.Errorf("no remote paths provided")
	}

	parsed := make([]*QtransURL, 0, len(remotePaths))
	for _, remotePath := range remotePaths {
		u, err := ParseRemotePath(rawServer, remotePath, transport)
		if err != nil {
			return nil, "", err
		}
		parsed = append(parsed, u)
	}
	return parsed, parsed[0].ServerURL, nil
}

func resolveQtserverAccess(token string) (types.DownloadUser, string, error) {
	trimmedToken := strings.TrimSpace(token)
	if trimmedToken != "" {
		return types.DownloadUserSelf, trimmedToken, nil
	}
	return types.DownloadUserAnonymous, "", nil
}

func resolveQtserverAccessForURLs(urls []*QtransURL, token string) (types.DownloadUser, string, error) {
	if len(urls) == 0 {
		return "", "", fmt.Errorf("no URLs provided")
	}

	return resolveQtserverAccess(token)
}

func resolveUploadHomeAccess(u *QtransURL, token string, requirePath bool) (string, error) {
	if u == nil {
		return "", fmt.Errorf("missing qtrans URL")
	}
	trimmedToken := strings.TrimSpace(token)
	if trimmedToken == "" {
		return "", fmt.Errorf("authentication is required for upload-home commands")
	}
	if requirePath && u.ObjectKey == "" {
		return "", fmt.Errorf("command requires a non-root path")
	}
	return trimmedToken, nil
}

func resolveUploadHomeAccessForURLs(urls []*QtransURL, token string, requirePath bool) (string, string, error) {
	if len(urls) == 0 {
		return "", "", fmt.Errorf("no URLs provided")
	}

	trimmedToken := strings.TrimSpace(token)
	if trimmedToken == "" {
		return "", "", fmt.Errorf("authentication is required for upload-home commands")
	}

	serverURL := ""
	for _, parsed := range urls {
		if _, err := resolveUploadHomeAccess(parsed, trimmedToken, requirePath); err != nil {
			return "", "", err
		}
		if serverURL == "" {
			serverURL = parsed.ServerURL
			continue
		}
		if parsed.ServerURL != serverURL {
			return "", "", fmt.Errorf("all upload-home paths must target the same server")
		}
	}

	return serverURL, trimmedToken, nil
}
