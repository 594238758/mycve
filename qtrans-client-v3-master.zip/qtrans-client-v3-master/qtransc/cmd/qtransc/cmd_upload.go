package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"qtransc/internal/netclient"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/taskidclient"
	"qtransc/internal/types"
	"qtransc/internal/uploadstate"
	"qtransc/internal/uploadtask"
	"strings"
	"sync/atomic"
	"time"

	"github.com/spf13/cobra"
)

var (
	ulLimitSize   string
	ulSources     []string
	ulFileList    string
	ulDestination string
)

var uploadCmd = &cobra.Command{
	Use:   "upload <local-source> <remote-destination>",
	Short: "Upload files to qtserver",
	Long:  `Upload files or directories to a qtserver instance`,
	RunE:  runUpload,
}

func initUploadFlags() {
	uploadCmd.Flags().StringVar(&ulLimitSize, "limit-size", "",
		"limit total upload size, e.g. 10GB or 512MiB; if exceeded, the command exits with '任务发送数据量超限'")
	uploadCmd.Flags().StringArrayVarP(&ulSources, "source", "s", nil, "local source path; may be specified multiple times")
	uploadCmd.Flags().Var(&singleStringFlagValue{name: "filelist", target: &ulFileList}, "filelist", "UTF-8 source list file")
	uploadCmd.Flags().VarP(&singleStringFlagValue{name: "destination", target: &ulDestination}, "destination", "d", "existing remote destination directory")
}

func runUpload(cmd *cobra.Command, args []string) error {
	transportMode, err := types.ParseTransportMode(cliTransport)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}
	inputs, err := resolveUploadCLIInputs(cmd, args, ulSources, ulFileList, ulDestination)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}

	// ── 1. Parse destination and expand upload sources ──
	serverURL, destination, err := parseUploadDestination(cliServer, inputs.Destination, transportMode)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}
	sourceFiles, dirPaths, err := expandUploadSources(inputs.Sources, destination)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}
	if _, err := uploadstate.ResolvePath(cliStateDB); err != nil {
		return withCommandExitCode(sanitizeCLIError(fmt.Errorf("invalid --state-db: %w", err)), 2)
	}

	// ── 2. Setup logger ──
	configurePendingTaskCLILogger(cliDebug, cliLogPath)

	limitSizeBytes, err := parseLimitSize(ulLimitSize)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(fmt.Errorf("invalid --limit-size: %w", err)), 2)
	}
	if err := checkUploadLimitSize(sourceFiles, limitSizeBytes); err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}
	limitRateBytes, err := parseLimitRate(cliLimitRate)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(fmt.Errorf("invalid --limit-rate: %w", err)), 2)
	}
	effectiveConnections, effectiveStreams := cliConnections, cliStreams

	// ── 3. Init HTTP client pool ──
	poolCfg, err := netclient.NormalizePoolConfig(transportMode, effectiveConnections, effectiveStreams)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(fmt.Errorf("invalid transport concurrency config: %w", err)), 2)
	}
	fileConcurrency, err := resolveFileConcurrency(cliTransfers)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(err), 2)
	}
	client, err := netclient.New(transportMode, netclient.Config{Pool: poolCfg})
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(fmt.Errorf("failed to initialize %s client pool: %w", transportMode, err)), 2)
	}
	defer client.Close()

	// ── 4. Build task request ──
	taskName := fmt.Sprintf("cli-upload-%d", time.Now().Unix())
	bearerToken, err := canonicalWriteCLIBearerToken()
	if err != nil {
		return sanitizeCLIError(err)
	}
	taskID, err := taskidclient.Request(context.Background(), serverURL, client)
	if err != nil {
		return sanitizeCLIError(err)
	}
	configureTaskCLILogger(cliDebug, cliLogPath, taskID, "debug")
	destinationToken := bearerToken
	useAuthManager := strings.TrimSpace(cliAuthToken) == "" && cliAuthUsername != anonymousAuthUsername
	if useAuthManager {
		bearerToken = ""
	}

	req, _, err := buildUploadTaskRequestFromSourceFiles(taskID, taskName, bearerToken, serverURL, transportMode, sourceFiles, dirPaths, useAuthManager)
	if err != nil {
		return withCommandExitCode(sanitizeCLIError(fmt.Errorf("invalid request: %w", err)), 2)
	}

	// ── 5. Create and execute task ──
	completionOption, taskCompleted := cliTaskCompletion()
	task, err := uploadtask.NewUploadTask(req, client.Config(), client, completionOption)
	if err != nil {
		return sanitizeCLIError(fmt.Errorf("failed to create upload task: %w", err))
	}
	if err := ensureUploadDestinationExists(context.Background(), serverURL, destination, destinationToken, taskID, client); err != nil {
		return sanitizeCLIError(err)
	}
	task.LimitRate = limitRateBytes
	task.FileConcurrency = fileConcurrency

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	shutdownController := newUploadTaskShutdownController(task, cancel)
	stopSignals := shutdownController.InstallSignalHandler()
	defer stopSignals()

	done := runCLITask(ctx, task, taskCompleted)

	// ── 6. Display progress or wait ──
	if cliDebug {
		taskErr := preferStoredTaskError(<-done, task.GetStatus().Error)
		printUploadSummary(task, serverURL)
		exitCode := shutdownController.ExitCode()
		if exitCode == 0 && uploadtask.IsLocalStateError(taskErr) {
			exitCode = 2
		}
		return withCommandExitCode(taskErr, exitCode)
	}

	taskErr := showSimpleUploadProgress(task, serverURL, done)
	fmt.Fprintln(os.Stderr)
	exitCode := shutdownController.ExitCode()
	if exitCode == 0 && uploadtask.IsLocalStateError(taskErr) {
		exitCode = 2
	}
	return withCommandExitCode(sanitizeCLIError(taskErr), exitCode)
}

func ensureUploadDestinationExists(ctx context.Context, serverURL, destination, token, taskID string, client *netclient.Client) error {
	capabilities, err := qtserverapi.RequireCapabilities(ctx, serverURL, client, "upload", "file_management")
	if err != nil {
		return fmt.Errorf("validate upload capabilities: %w", err)
	}
	if token == qtserverapi.AnonymousWriteToken {
		if err := capabilities.RequireAnonymousWrite(); err != nil {
			return err
		}
	}
	if destination == "/" {
		return nil
	}
	if _, _, _, err := qtserverapi.DoJSON(ctx, serverURL, "/files/mkdir", http.MethodPost, token, taskID, map[string]string{"path": destination}, client, qtserverapi.IdempotentRetry); err != nil {
		return fmt.Errorf("prepare upload destination directory: %w", err)
	}
	return nil
}

func printUploadSummary(task *uploadtask.UploadTask, serverURL string) {
	status := task.GetStatus().Status
	transferred := atomic.LoadInt64(&task.Transferred)
	totalSize := atomic.LoadInt64(&task.TotalSize)

	fmt.Fprintf(os.Stderr, "\n--- Upload Summary ---\n")
	fmt.Fprintf(os.Stderr, "Server:      %s\n", serverURL)
	fmt.Fprintf(os.Stderr, "Status:      %s\n", status)
	fmt.Fprintf(os.Stderr, "Total:       %s\n", formatBytes(totalSize))
	fmt.Fprintf(os.Stderr, "Transferred: %s\n", formatBytes(transferred))

	if taskErr := task.GetStatus().Error; taskErr != nil {
		fmt.Fprintf(os.Stderr, "Error:       %v\n", taskErr)
	}

	for _, fi := range task.ReadyFiles {
		if fi == nil {
			continue
		}
		mark := "PENDING"
		if fi.Verified {
			mark = "OK"
		} else if fi.Uploaded {
			mark = "UPLOADED"
		}
		fmt.Fprintf(os.Stderr, "  %s %s -> %s (%s)\n", mark, fi.LocalPath, fi.ObjectKey, formatBytes(fi.Size))
	}

	for _, fi := range task.ConflictFiles {
		if fi == nil {
			continue
		}
		fmt.Fprintf(os.Stderr, "  EXISTS %s -> %s (%s)\n", fi.LocalPath, fi.ObjectKey, formatBytes(fi.Size))
	}

	for _, fi := range task.RejectedFiles {
		if fi == nil {
			continue
		}
		fmt.Fprintf(os.Stderr, "  REJECTED %s (%s)\n", fi.LocalPath, fi.Message)
	}
	fmt.Fprintln(os.Stderr, "---")
}
