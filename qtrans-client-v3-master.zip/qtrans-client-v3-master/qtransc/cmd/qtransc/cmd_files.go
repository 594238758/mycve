package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"strings"

	"qtransc/internal/clienterror"
	"qtransc/internal/netclient"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/types"

	"github.com/spf13/cobra"
)

var listJSON bool
var mutationJSON bool
var recursiveDelete bool

var listCmd = &cobra.Command{
	Use: "list [remote-directory]", Short: "List one remote directory",
	Args: cobra.MaximumNArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		path := "/"
		if len(args) == 1 {
			path = args[0]
		}
		err := runCanonicalList(cmd.Context(), path)
		err = formatCanonicalListError(logicalRemotePath(path), err)
		if err != nil && listJSON {
			writeCanonicalJSONError(cmd, err)
		}
		return err
	},
}

var mkdirCmd = &cobra.Command{
	Use: "mkdir <remote-directory>", Short: "Create a remote directory tree", Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		remotePath := logicalRemotePath(args[0])
		body, err := runCanonicalMutation(cmd.Context(), "/files/mkdir", map[string]any{"path": remotePath}, true)
		if err != nil {
			return writeCanonicalMutationErrorJSON(cmd, body, err)
		}
		if mutationJSON {
			return writeCanonicalRawJSON(cmd, body)
		}
		var response struct {
			Path    string `json:"path"`
			Created bool   `json:"created"`
		}
		if err := json.Unmarshal(body, &response); err != nil {
			return err
		}
		if response.Created {
			fmt.Fprintf(cmd.OutOrStdout(), "已创建远端目录：%s\n", response.Path)
			return nil
		}
		fmt.Fprintf(cmd.OutOrStdout(), "远端目录已存在：%s\n", response.Path)
		return nil
	},
}

var moveCmd = &cobra.Command{
	Use: "move <remote-source> <remote-destination>", Short: "Move a remote object", Args: cobra.ExactArgs(2),
	RunE: func(cmd *cobra.Command, args []string) error {
		source := logicalRemotePath(args[0])
		destination := logicalRemotePath(args[1])
		body, err := runCanonicalMutation(cmd.Context(), "/files/move", map[string]any{"source": source, "destination": destination}, false)
		if err != nil {
			return formatCanonicalMoveError(source, destination, writeCanonicalMutationErrorJSON(cmd, body, err))
		}
		if mutationJSON {
			return writeCanonicalRawJSON(cmd, body)
		}
		var response struct {
			Source      string `json:"source"`
			Destination string `json:"destination"`
		}
		if err := json.Unmarshal(body, &response); err != nil {
			return err
		}
		fmt.Fprintf(cmd.OutOrStdout(), "已移动远端路径：%s -> %s\n", response.Source, response.Destination)
		return nil
	},
}

var deleteCmd = &cobra.Command{
	Use: "delete [--recursive] <remote-path>", Short: "Delete a remote file or empty directory", Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		remotePath := logicalRemotePath(args[0])
		if recursiveDelete {
			var progress *recursiveDeleteProgress
			if !mutationJSON && remotePath != "/" {
				progress = newRecursiveDeleteProgress(cmd.ErrOrStderr(), remotePath)
			}
			result, err := runCanonicalRecursiveDelete(cmd.Context(), remotePath, progress)
			if progress != nil {
				progress.finish(err == nil)
			}
			if mutationJSON {
				writeRecursiveDeleteJSON(cmd, result, err)
			} else if err == nil {
				fmt.Fprintf(cmd.OutOrStdout(), "已递归删除远端路径：%s（%d 个节点）\n", result.Path, result.DeletedNodes)
			}
			return err
		}
		body, err := runCanonicalMutation(cmd.Context(), "/files/delete", map[string]any{"path": remotePath}, false)
		if err != nil {
			return formatCanonicalDeleteError(remotePath, writeCanonicalMutationErrorJSON(cmd, body, err))
		}
		if mutationJSON {
			return writeCanonicalRawJSON(cmd, body)
		}
		var response struct {
			Path string `json:"path"`
		}
		if err := json.Unmarshal(body, &response); err != nil {
			return err
		}
		fmt.Fprintf(cmd.OutOrStdout(), "已删除远端路径：%s\n", response.Path)
		return nil
	},
}

func initFileFlags() {
	listCmd.Flags().BoolVar(&listJSON, "json", false, "write one JSON response to stdout")
	for _, cmd := range []*cobra.Command{mkdirCmd, moveCmd, deleteCmd} {
		cmd.Flags().BoolVar(&mutationJSON, "json", false, "write one JSON response to stdout")
	}
	deleteCmd.Flags().BoolVarP(&recursiveDelete, "recursive", "r", false, "delete a directory tree")
}

type canonicalListEntry struct {
	Name         string  `json:"name"`
	Path         string  `json:"path"`
	Type         string  `json:"type"`
	Status       string  `json:"status"`
	TargetType   *string `json:"target_type,omitempty"`
	SpecialType  string  `json:"special_type,omitempty"`
	ReasonCode   string  `json:"reason_code,omitempty"`
	Size         int64   `json:"size,omitempty"`
	LastModified string  `json:"last_modified,omitempty"`
}
type canonicalListResponse struct {
	Code      int                  `json:"code"`
	Path      string               `json:"path"`
	Truncated bool                 `json:"truncated"`
	Entries   []canonicalListEntry `json:"entries"`
}

type canonicalFileSession struct {
	ctx       context.Context
	client    *netclient.Client
	serverURL string
	token     string
}

func openCanonicalFileSession(ctx context.Context, write bool) (*canonicalFileSession, error) {
	client, serverURL, err := prepareCanonicalFileClient()
	if err != nil {
		return nil, withCommandExitCode(err, 2)
	}

	capabilityNames := []string{"file_management"}
	if write {
		capabilityNames = append([]string{"write"}, capabilityNames...)
	}
	capabilities, err := qtserverapi.RequireCapabilities(ctx, serverURL, client, capabilityNames...)
	if err != nil {
		client.Close()
		return nil, err
	}

	var token string
	if write {
		token, err = canonicalWriteCLIBearerToken()
		if err == nil && token == qtserverapi.AnonymousWriteToken {
			err = capabilities.RequireAnonymousWrite()
		}
	} else {
		token, err = optionalCLIBearerToken()
		if err == nil && token == "" {
			err = capabilities.RequireAnonymousRead()
		}
	}
	if err != nil {
		client.Close()
		return nil, err
	}
	return &canonicalFileSession{ctx: ctx, client: client, serverURL: serverURL, token: token}, nil
}

func (s *canonicalFileSession) Close() {
	if s != nil {
		s.client.Close()
	}
}

func (s *canonicalFileSession) list(remotePath string) (canonicalListResponse, []byte, error) {
	var response canonicalListResponse
	endpoint := "/files/list?path=" + url.QueryEscape(remotePath)
	_, _, body, err := qtserverapi.DoJSON(s.ctx, s.serverURL, endpoint, http.MethodGet, s.token, "", nil, s.client, qtserverapi.IdempotentRetry)
	if err != nil {
		return response, body, err
	}
	if err := json.Unmarshal(body, &response); err != nil {
		return response, body, err
	}
	return response, body, nil
}

func (s *canonicalFileSession) mutate(endpoint string, payload any, idempotent bool) ([]byte, error) {
	retry := qtserverapi.NoRetry
	if idempotent {
		retry = qtserverapi.IdempotentRetry
	}
	_, _, body, err := qtserverapi.DoJSON(s.ctx, s.serverURL, endpoint, http.MethodPost, s.token, "", payload, s.client, retry)
	return body, err
}

func (s *canonicalFileSession) delete(remotePath string) error {
	_, err := s.mutate("/files/delete", map[string]any{"path": remotePath}, false)
	return err
}

func runCanonicalList(ctx context.Context, rawPath string) error {
	session, err := openCanonicalFileSession(ctx, false)
	if err != nil {
		return err
	}
	defer session.Close()
	parsed, err := ParseRemotePath(cliServer, rawPath, session.client.Mode())
	if err != nil {
		return err
	}
	response, body, err := session.list(logicalRemotePath(rawPath))
	if err != nil {
		return err
	}
	if response.Truncated {
		return clienterror.New("LIST_TRUNCATED", "目录超过10万条目，无法显示", nil)
	}
	if listJSON {
		_, err = os.Stdout.Write(append(body, '\n'))
		return err
	}
	entries := make([]browseRenderEntry, 0, len(response.Entries))
	for _, entry := range response.Entries {
		entryType := entry.Type
		if entry.Type == "symlink" && entry.TargetType != nil {
			entryType = *entry.TargetType
		}
		entries = append(entries, browseRenderEntry{
			Name:         entry.Name,
			EntryType:    entryType,
			Size:         entry.Size,
			LastModified: entry.LastModified,
		})
	}
	renderBrowseTable(os.Stdout, formatBrowseLocation(parsed), entries)
	return nil
}

func runCanonicalMutation(ctx context.Context, endpoint string, payload any, idempotent bool) ([]byte, error) {
	session, err := openCanonicalFileSession(ctx, true)
	if err != nil {
		return nil, err
	}
	defer session.Close()
	body, err := session.mutate(endpoint, payload, idempotent)
	return body, err
}

func writeCanonicalMutationErrorJSON(cmd *cobra.Command, body []byte, mutationErr error) error {
	if mutationJSON && len(body) > 0 {
		if writeErr := writeCanonicalRawJSON(cmd, body); writeErr != nil {
			return errors.Join(mutationErr, writeErr)
		}
	}
	return mutationErr
}

func writeCanonicalRawJSON(cmd *cobra.Command, body []byte) error {
	_, err := cmd.OutOrStdout().Write(append(body, '\n'))
	return err
}

const (
	recursiveDeleteMaxDepth   = 128
	recursiveDeleteMaxEntries = 200000
	recursiveDeleteMaxRelists = 3
)

type recursiveDeleteResult struct {
	Code         int    `json:"code"`
	ReasonCode   string `json:"reason_code,omitempty"`
	Message      string `json:"message,omitempty"`
	Path         string `json:"path"`
	Recursive    bool   `json:"recursive"`
	DeletedNodes int    `json:"deleted_nodes"`
	FailedPath   string `json:"failed_path,omitempty"`
}

type recursiveDeleteWalker struct {
	session  *canonicalFileSession
	progress *recursiveDeleteProgress
	result   recursiveDeleteResult
	entries  int
}

func runCanonicalRecursiveDelete(ctx context.Context, remotePath string, progress *recursiveDeleteProgress) (recursiveDeleteResult, error) {
	result := recursiveDeleteResult{Code: http.StatusOK, Path: remotePath, Recursive: true}
	if remotePath == "/" {
		return result, clienterror.New(clienterror.CodeInvalidArgument, "根目录 / 不允许删除", nil)
	}
	session, err := openCanonicalFileSession(ctx, true)
	if err != nil {
		return result, err
	}
	defer session.Close()

	walker := &recursiveDeleteWalker{session: session, progress: progress, result: result}
	err = walker.deletePath(remotePath, 0, true)
	if err == nil {
		return walker.result, nil
	}
	if walker.result.DeletedNodes == 0 {
		return walker.result, formatCanonicalDeleteError(walker.result.FailedPath, err)
	}
	walker.result.Code = 1
	walker.result.ReasonCode = clienterror.CodeRecursiveDeletePartial
	walker.result.Message = "递归删除未完成，部分节点可能已删除"
	if walker.result.FailedPath == "" {
		walker.result.FailedPath = remotePath
	}
	return walker.result, clienterror.New(
		clienterror.CodeRecursiveDeletePartial,
		fmt.Sprintf("递归删除未完成：已删除 %d 个节点，失败路径：%s", walker.result.DeletedNodes, walker.result.FailedPath),
		err,
	)
}

func (w *recursiveDeleteWalker) deletePath(remotePath string, depth int, initial bool) error {
	if depth > recursiveDeleteMaxDepth {
		w.setFailedPath(remotePath)
		return clienterror.New("RECURSIVE_DELETE_DEPTH_EXCEEDED", "递归删除目录层级超过 128，已停止", nil)
	}

	if w.progress != nil {
		w.progress.deleting(remotePath)
	}
	err := w.session.delete(remotePath)
	if err == nil {
		w.result.DeletedNodes++
		if w.progress != nil {
			w.progress.deletedNode(w.result.DeletedNodes)
		}
		return nil
	}
	if isCanonicalReason(err, "NOT_FOUND") && !initial {
		return nil
	}
	if !isCanonicalReason(err, "DIRECTORY_NOT_EMPTY") {
		w.setFailedPath(remotePath)
		return err
	}

	for relists := 0; ; relists++ {
		if w.progress != nil {
			w.progress.scanning(remotePath)
		}
		response, _, listErr := w.session.list(remotePath)
		if listErr != nil {
			w.setFailedPath(remotePath)
			return listErr
		}
		if response.Truncated {
			w.setFailedPath(remotePath)
			return clienterror.New("RECURSIVE_DELETE_LIST_TRUNCATED", "目录超过10万条目，无法安全递归删除", nil)
		}
		w.entries += len(response.Entries)
		if w.entries > recursiveDeleteMaxEntries {
			w.setFailedPath(remotePath)
			return clienterror.New("RECURSIVE_DELETE_ENTRY_LIMIT", "递归删除条目超过 200000，已停止", nil)
		}
		for _, entry := range response.Entries {
			childPath := logicalRemotePath(entry.Path)
			if entry.Path == "" {
				childPath = logicalRemotePath(remotePath + "/" + entry.Name)
			}
			if err := w.deletePath(childPath, depth+1, false); err != nil {
				return err
			}
		}

		if w.progress != nil {
			w.progress.deleting(remotePath)
		}
		err = w.session.delete(remotePath)
		if err == nil {
			w.result.DeletedNodes++
			if w.progress != nil {
				w.progress.deletedNode(w.result.DeletedNodes)
			}
			return nil
		}
		if isCanonicalReason(err, "NOT_FOUND") && !initial {
			return nil
		}
		if !isCanonicalReason(err, "DIRECTORY_NOT_EMPTY") {
			w.setFailedPath(remotePath)
			return err
		}
		if relists+1 >= recursiveDeleteMaxRelists {
			w.setFailedPath(remotePath)
			return clienterror.New("RECURSIVE_DELETE_DIRECTORY_CHANGING", "目录持续变化，无法完成递归删除", err)
		}
	}
}

func (w *recursiveDeleteWalker) setFailedPath(remotePath string) {
	if w.result.FailedPath == "" {
		w.result.FailedPath = remotePath
	}
}

func isCanonicalReason(err error, reasonCode string) bool {
	var apiErr *qtserverapi.APIError
	return errors.As(err, &apiErr) && strings.EqualFold(strings.TrimSpace(apiErr.ReasonCode), reasonCode)
}

func writeRecursiveDeleteJSON(cmd *cobra.Command, result recursiveDeleteResult, err error) {
	if err == nil {
		_ = json.NewEncoder(cmd.OutOrStdout()).Encode(result)
		return
	}
	if result.DeletedNodes > 0 {
		_ = json.NewEncoder(cmd.OutOrStdout()).Encode(result)
		return
	}
	writeCanonicalJSONError(cmd, err)
}

func writeCanonicalJSONError(cmd *cobra.Command, err error) {
	var apiErr *qtserverapi.APIError
	if errors.As(err, &apiErr) && len(apiErr.Body) > 0 {
		_, _ = cmd.OutOrStdout().Write(append(apiErr.Body, '\n'))
		return
	}
	normalized := clienterror.Normalize(err)
	_ = json.NewEncoder(cmd.OutOrStdout()).Encode(map[string]any{
		"code":        1,
		"reason_code": normalized.ReasonCode,
		"message":     normalized.Message,
	})
}

func prepareCanonicalFileClient() (*netclient.Client, string, error) {
	transport, err := types.ParseTransportMode(cliTransport)
	if err != nil {
		return nil, "", err
	}
	server, err := ParseQtransServer(cliServer, transport)
	if err != nil {
		return nil, "", err
	}
	client, err := newClientForTransport(transport, cliConnections, cliStreams)
	if err != nil {
		return nil, "", err
	}
	return client, server.ServerURL, nil
}

func logicalRemotePath(raw string) string {
	if raw == "" || raw == "/" {
		return "/"
	}
	return "/" + strings.Trim(raw, "/")
}

func formatCanonicalListError(remotePath string, err error) error {
	if err == nil {
		return err
	}

	var capabilityErr *qtserverapi.CapabilityUnavailableError
	if errors.As(err, &capabilityErr) && capabilityErr.Name == "file_management" {
		return clienterror.New(clienterror.CodeCapabilityUnavailable, "服务器未启用文件管理功能，无法浏览目录", err)
	}

	var apiErr *qtserverapi.APIError
	if !errors.As(err, &apiErr) {
		return clienterror.Normalize(err)
	}

	reasonCode := strings.ToUpper(strings.TrimSpace(apiErr.ReasonCode))
	switch reasonCode {
	case "NOT_FOUND":
		return clienterror.New(reasonCode, fmt.Sprintf("未找到远端目录：%s", remotePath), err)
	case "NOT_A_DIRECTORY":
		return clienterror.New(reasonCode, fmt.Sprintf("远端路径不是目录：%s", remotePath), err)
	case "DAMAGED_SYMLINK":
		return clienterror.New(reasonCode, fmt.Sprintf("远端路径是损坏的符号链接：%s", remotePath), err)
	case "SYMLINK_LOOP":
		return clienterror.New(reasonCode, fmt.Sprintf("远端路径存在符号链接循环：%s", remotePath), err)
	case "INVALID_PATH", "INVALID_OBJECT_KEY":
		return clienterror.New(reasonCode, fmt.Sprintf("远端路径无效：%s", remotePath), err)
	case "UNAUTHORIZED", "INVALID_TOKEN":
		return clienterror.New(reasonCode, "认证失败，请检查认证信息", err)
	case "FORBIDDEN":
		return clienterror.New(reasonCode, fmt.Sprintf("无权访问远端目录：%s", remotePath), err)
	case "ROUTE_NOT_FOUND":
		return clienterror.New(reasonCode, "服务器未启用文件管理功能", err)
	case "DEPENDENCY_UNAVAILABLE":
		return clienterror.New(reasonCode, "qtserver 的依赖暂不可用，请稍后重试", err)
	case "NAMESPACE_BUSY", "NAMESPACE_LOCK_LOST":
		return clienterror.New(reasonCode, "远端目录正在初始化，请稍后重试", err)
	case "INTERNAL_ERROR":
		return clienterror.New(reasonCode, "qtserver 无法读取远端目录，请稍后重试", err)
	}

	switch apiErr.Status {
	case http.StatusBadRequest:
		return clienterror.New("INVALID_REQUEST", fmt.Sprintf("服务器拒绝了远端目录请求：%s", remotePath), err)
	case http.StatusUnauthorized:
		return clienterror.New("UNAUTHORIZED", "认证失败，请检查认证信息", err)
	case http.StatusForbidden:
		return clienterror.New("FORBIDDEN", fmt.Sprintf("无权访问远端目录：%s", remotePath), err)
	case http.StatusNotFound:
		return clienterror.New("NOT_FOUND", fmt.Sprintf("未找到远端目录：%s", remotePath), err)
	case http.StatusConflict:
		return clienterror.New("CONFLICT", "远端目录状态发生冲突，请稍后重试", err)
	case http.StatusTooManyRequests:
		return clienterror.New("RATE_LIMITED", "请求过于频繁，请稍后重试", err)
	case http.StatusInternalServerError, http.StatusBadGateway, http.StatusServiceUnavailable, http.StatusGatewayTimeout:
		return clienterror.New(clienterror.CodeServerUnavailable, "qtserver 暂时不可用，请稍后重试", err)
	default:
		return clienterror.New("HTTP_ERROR", fmt.Sprintf("访问远端目录失败：%s（HTTP %d）", remotePath, apiErr.Status), err)
	}
}

func formatCanonicalMoveError(source, destination string, err error) error {
	if err == nil {
		return err
	}

	var apiErr *qtserverapi.APIError
	if errors.As(err, &apiErr) {
		reasonCode := strings.ToUpper(strings.TrimSpace(apiErr.ReasonCode))
		switch reasonCode {
		case "NOT_FOUND":
			return clienterror.New(reasonCode, fmt.Sprintf("移动失败：源路径或目标父目录不存在（源：%s，目标：%s）", source, destination), err)
		case "INVALID_PATH", "INVALID_OBJECT_KEY":
			return clienterror.New(reasonCode, fmt.Sprintf("移动路径无效（源：%s，目标：%s）", source, destination), err)
		case "INVALID_MOVE":
			return clienterror.New(reasonCode, "不能将目录移动到自己的子目录", err)
		case "UNSUPPORTED_FILE_TYPE":
			return clienterror.New(reasonCode, "不支持移动特殊文件", err)
		case "CROSS_DEVICE_MOVE":
			return clienterror.New(reasonCode, "不支持跨文件系统移动", err)
		case "CONFLICT":
			return clienterror.New(reasonCode, "目标路径无法替换，或源路径和目标路径冲突", err)
		}
	}

	return formatCanonicalMutationError("移动", err)
}

func formatCanonicalDeleteError(remotePath string, err error) error {
	if err == nil {
		return err
	}

	var apiErr *qtserverapi.APIError
	if errors.As(err, &apiErr) {
		reasonCode := strings.ToUpper(strings.TrimSpace(apiErr.ReasonCode))
		switch reasonCode {
		case "NOT_FOUND":
			return clienterror.New(reasonCode, fmt.Sprintf("未找到远端路径：%s", remotePath), err)
		case "DIRECTORY_NOT_EMPTY":
			return clienterror.New(reasonCode, fmt.Sprintf("目录非空，无法删除：%s", remotePath), err)
		case "UNSUPPORTED_FILE_TYPE":
			return clienterror.New(reasonCode, fmt.Sprintf("不支持删除此类文件：%s", remotePath), err)
		case "INVALID_PATH", "INVALID_OBJECT_KEY":
			return clienterror.New(reasonCode, fmt.Sprintf("远端路径无效，无法删除：%s", remotePath), err)
		}
	}

	return formatCanonicalMutationError("删除", err)
}

func formatCanonicalMutationError(operation string, err error) error {
	if err == nil {
		return err
	}

	var capabilityErr *qtserverapi.CapabilityUnavailableError
	if errors.As(err, &capabilityErr) {
		switch capabilityErr.Name {
		case "file_management":
			return clienterror.New(clienterror.CodeCapabilityUnavailable, fmt.Sprintf("服务器未启用文件管理功能，无法%s", operation), err)
		case "write":
			return clienterror.New(clienterror.CodeCapabilityUnavailable, fmt.Sprintf("服务器未启用写入功能，无法%s", operation), err)
		}
	}

	var apiErr *qtserverapi.APIError
	if !errors.As(err, &apiErr) {
		return clienterror.Normalize(err)
	}

	reasonCode := strings.ToUpper(strings.TrimSpace(apiErr.ReasonCode))
	switch reasonCode {
	case "UNAUTHORIZED", "INVALID_TOKEN":
		return clienterror.New(reasonCode, "认证失败，请检查认证信息", err)
	case "FORBIDDEN":
		return clienterror.New(reasonCode, fmt.Sprintf("没有%s权限", operation), err)
	case "ROUTE_NOT_FOUND":
		return clienterror.New(reasonCode, fmt.Sprintf("服务器未启用%s所需功能", operation), err)
	case "DEPENDENCY_UNAVAILABLE":
		return clienterror.New(reasonCode, "qtserver 的依赖暂不可用，请稍后重试", err)
	case "INTERNAL_ERROR", "NAMESPACE_OPERATION_PARTIAL":
		return clienterror.New(clienterror.CodeMutationResultUnknown, fmt.Sprintf("%s结果未确认，请检查远端路径后再决定是否重试", operation), err)
	}

	switch apiErr.Status {
	case http.StatusBadRequest:
		return clienterror.New("INVALID_REQUEST", fmt.Sprintf("服务器拒绝了%s请求", operation), err)
	case http.StatusUnauthorized:
		return clienterror.New("UNAUTHORIZED", "认证失败，请检查认证信息", err)
	case http.StatusForbidden:
		return clienterror.New("FORBIDDEN", fmt.Sprintf("没有%s权限", operation), err)
	case http.StatusNotFound:
		return clienterror.New("NOT_FOUND", fmt.Sprintf("%s失败：远端路径不存在", operation), err)
	case http.StatusConflict:
		return clienterror.New("CONFLICT", fmt.Sprintf("%s失败：远端路径状态发生冲突", operation), err)
	case http.StatusTooManyRequests:
		return clienterror.New("RATE_LIMITED", "请求过于频繁，请稍后重试", err)
	case http.StatusInternalServerError, http.StatusBadGateway, http.StatusServiceUnavailable, http.StatusGatewayTimeout:
		return clienterror.New(clienterror.CodeMutationResultUnknown, fmt.Sprintf("%s结果未确认，请检查远端路径后再决定是否重试", operation), err)
	default:
		return clienterror.New("HTTP_ERROR", fmt.Sprintf("%s失败（HTTP %d）", operation, apiErr.Status), err)
	}
}
