package main

import (
	"fmt"
	"math"
	"regexp"
	"strconv"
	"strings"
)

var byteQuantityPattern = regexp.MustCompile(`^\s*([0-9]+(?:\.[0-9]+)?)\s*([A-Za-z/]*)\s*$`)

var limitRateUnitMultipliers = map[string]float64{
	"":    1,
	"B":   1,
	"KB":  1000,
	"MB":  1000 * 1000,
	"GB":  1000 * 1000 * 1000,
	"KIB": 1024,
	"MIB": 1024 * 1024,
	"GIB": 1024 * 1024 * 1024,
	"K":   1000,
	"M":   1000 * 1000,
	"G":   1000 * 1000 * 1000,
}

func parseByteQuantity(raw string, allowRateSuffix bool) (int64, error) {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" {
		return 0, nil
	}

	matches := byteQuantityPattern.FindStringSubmatch(trimmed)
	if matches == nil {
		return 0, fmt.Errorf("invalid size %q; use forms like 1048576, 10MB, or 5MiB", raw)
	}

	value, err := strconv.ParseFloat(matches[1], 64)
	if err != nil {
		return 0, fmt.Errorf("parse rate value %q: %w", matches[1], err)
	}
	if value <= 0 {
		return 0, fmt.Errorf("rate must be greater than 0")
	}

	unit := strings.ToUpper(strings.TrimSpace(matches[2]))
	if allowRateSuffix {
		unit = strings.TrimSuffix(unit, "/S")
		unit = strings.TrimSuffix(unit, "PS")
	}
	multiplier, ok := limitRateUnitMultipliers[unit]
	if !ok {
		return 0, fmt.Errorf("unsupported unit %q; use B, KB, MB, GB, KiB, MiB, or GiB", matches[2])
	}

	rate := value * multiplier
	if rate > math.MaxInt64 {
		return 0, fmt.Errorf("rate %q is too large", raw)
	}
	rounded := int64(math.Round(rate))
	if rounded <= 0 {
		return 0, fmt.Errorf("rate must be at least 1 B/s")
	}
	return rounded, nil
}

func parseLimitRate(raw string) (int64, error) {
	return parseByteQuantity(raw, true)
}

func parseLimitSize(raw string) (int64, error) {
	return parseByteQuantity(raw, false)
}

func resolveFileConcurrency(transfers int) (int, error) {
	if transfers <= 0 {
		return 0, fmt.Errorf("--transfers must be greater than 0")
	}
	return transfers, nil
}
