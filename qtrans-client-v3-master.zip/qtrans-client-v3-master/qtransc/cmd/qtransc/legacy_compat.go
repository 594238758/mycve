package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"qtransc/internal/authmanager"
	"qtransc/internal/downloadtask"
	"strings"
	"time"

	"github.com/gorilla/websocket"
)

type legacyUpload2ProgressInfo struct {
	File            string  `json:"file"`
	ProgressPercent float64 `json:"progress_percent"`
	Transferred     int64   `json:"transferred"`
	Total           int64   `json:"total"`
	Rate            string  `json:"rate"`
}

type legacyUpload2TotalProgressInfo struct {
	Status           int                         `json:"status"`
	ProgressPercent  float64                     `json:"progress_percent"`
	TotalTransferred int64                       `json:"transferred"`
	TotalFileSize    int64                       `json:"total"`
	Rate             string                      `json:"rate"`
	Files            []legacyUpload2ProgressInfo `json:"inprogressfiles"`
}

type legacyUpload2WSRequest struct {
	TaskID  string          `json:"taskid"`
	Type    string          `json:"type"`
	Message json.RawMessage `json:"message,omitempty"`
}

type legacyUpload2WSResponse struct {
	TaskID string `json:"taskid"`
	Code   int    `json:"code"`
	Data   any    `json:"data,omitempty"`
}

type legacyUpload2WSAckData struct {
	Message string `json:"message"`
}

type legacyUpload2TokenUpdateRequest struct {
	BearerToken string `json:"bearer_token"`
}

func (r *legacyUpload2WSRequest) UnmarshalJSON(data []byte) error {
	var raw struct {
		TaskIDCamel *string         `json:"taskId"`
		TaskID      *string         `json:"taskid"`
		Type        string          `json:"type"`
		Message     json.RawMessage `json:"message"`
	}
	if err := json.Unmarshal(data, &raw); err != nil {
		return err
	}

	if raw.TaskID != nil {
		r.TaskID = *raw.TaskID
	} else if raw.TaskIDCamel != nil {
		r.TaskID = *raw.TaskIDCamel
	} else {
		r.TaskID = ""
	}
	r.Type = strings.TrimSpace(raw.Type)
	if len(raw.Message) > 0 {
		r.Message = append([]byte(nil), raw.Message...)
	} else {
		r.Message = nil
	}
	return nil
}

type legacyUpload2Status int

const (
	legacyUpload2TransNormalStatus legacyUpload2Status = 1000 + iota
	legacyUpload2TransStarting
	legacyUpload2TransRunning
	legacyUpload2TransFinished
)

const legacyUpload2TokenUpdated legacyUpload2Status = 1010

const (
	legacyUpload2TransError legacyUpload2Status = 2000 + iota
	legacyUpload2TransAuthFailed
	legacyUpload2TransDiskSpaceNotEnough
)

const (
	legacyUpload2TokenInvalid      legacyUpload2Status = 2010
	legacyUpload2TokenUpdateFailed legacyUpload2Status = 2011
)

const (
	legacyUpload2RequestQueryProgress = "query-progress"
	legacyUpload2RequestUpdateToken   = "update-token"
)

const legacyCoordinatorPauseCloseReason = "delete or pause"

const legacyTerminalAckTimeout = 30 * time.Second

func (s legacyUpload2Status) String() string {
	switch s {
	case legacyUpload2TransNormalStatus:
		return "正常状态"
	case legacyUpload2TransStarting:
		return "任务开始中"
	case legacyUpload2TransRunning:
		return "任务运行中"
	case legacyUpload2TransFinished:
		return "任务已完成"
	case legacyUpload2TokenUpdated:
		return "token updated"
	case legacyUpload2TransAuthFailed:
		return "认证失败"
	case legacyUpload2TransDiskSpaceNotEnough:
		return "磁盘空间不足"
	case legacyUpload2TokenInvalid:
		return "bearer_token is required"
	case legacyUpload2TokenUpdateFailed:
		return "token update failed"
	case legacyUpload2TransError:
		return "未知错误"
	default:
		return "unknown qtrans status type"
	}
}

func isLegacyCoordinatorPauseClose(err error) bool {
	var closeErr *websocket.CloseError
	if !errors.As(err, &closeErr) {
		return false
	}
	if closeErr.Code != websocket.CloseProtocolError {
		return false
	}
	return strings.Contains(strings.ToLower(strings.TrimSpace(closeErr.Text)), legacyCoordinatorPauseCloseReason)
}

func calcUpload2Percent(transferred, total int64) float64 {
	if total <= 0 {
		return 0
	}
	pct := float64(transferred) / float64(total) * 100
	if pct < 0 {
		return 0
	}
	if pct > 100 {
		return 100
	}
	return pct
}

func formatUpload2KBRate(rate int64) string {
	return fmt.Sprintf("%.2f KB/s", float64(rate)/1000.0)
}

func handleLegacyCoordinatorRequest(taskID string, req legacyUpload2WSRequest, buildQueryResponse func() legacyUpload2WSResponse) (legacyUpload2WSResponse, error) {
	var response legacyUpload2WSResponse
	switch req.Type {
	case legacyUpload2RequestQueryProgress:
		response = buildQueryResponse()
	case legacyUpload2RequestUpdateToken:
		response = applyLegacyUpdateToken(taskID, req.Message)
	default:
		return legacyUpload2WSResponse{}, fmt.Errorf("unknown websocket request type: %s", req.Type)
	}
	response.TaskID = req.TaskID
	return response, nil
}

func applyLegacyUpdateToken(taskID string, raw json.RawMessage) legacyUpload2WSResponse {
	if strings.TrimSpace(string(raw)) == "" {
		return legacyUpload2WSResponse{
			TaskID: taskID,
			Code:   int(legacyUpload2TokenInvalid),
			Data: legacyUpload2WSAckData{
				Message: legacyUpload2TokenInvalid.String(),
			},
		}
	}

	var req legacyUpload2TokenUpdateRequest
	if err := json.Unmarshal(raw, &req); err != nil {
		return legacyUpload2WSResponse{
			TaskID: taskID,
			Code:   int(legacyUpload2TokenInvalid),
			Data: legacyUpload2WSAckData{
				Message: "invalid update-token message",
			},
		}
	}

	bearerToken := strings.TrimSpace(req.BearerToken)
	if bearerToken == "" {
		return legacyUpload2WSResponse{
			TaskID: taskID,
			Code:   int(legacyUpload2TokenInvalid),
			Data: legacyUpload2WSAckData{
				Message: legacyUpload2TokenInvalid.String(),
			},
		}
	}

	if err := authmanager.SetStaticToken(bearerToken); err != nil {
		return legacyUpload2WSResponse{
			TaskID: taskID,
			Code:   int(legacyUpload2TokenUpdateFailed),
			Data: legacyUpload2WSAckData{
				Message: fmt.Sprintf("token update failed: %v", err),
			},
		}
	}

	slog.Info("legacy websocket update-token applied",
		"task_id", taskID,
		"taskpid", "",
		"enterprise_id", "",
		"token_length", len(bearerToken))

	return legacyUpload2WSResponse{
		TaskID: taskID,
		Code:   int(legacyUpload2TokenUpdated),
		Data: legacyUpload2WSAckData{
			Message: legacyUpload2TokenUpdated.String(),
		},
	}
}

func isUpload2AuthError(err error) bool {
	if err == nil {
		return false
	}
	// Check for typed download task errors first: ErrAuthFailed → true, ErrServerError → false
	var taskErr *downloadtask.TaskError
	if errors.As(err, &taskErr) {
		return errors.Is(err, downloadtask.ErrAuthFailed)
	}
	// Fallback: string-based check for upload task errors and other untyped errors
	msg := strings.ToLower(err.Error())
	return strings.Contains(msg, "401") ||
		strings.Contains(msg, "403") ||
		strings.Contains(msg, "unauthorized") ||
		strings.Contains(msg, "forbidden") ||
		strings.Contains(msg, "no files authorized")
}
