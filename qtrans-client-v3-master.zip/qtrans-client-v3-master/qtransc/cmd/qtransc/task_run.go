package main

import (
	"context"
	"sync"

	"qtransc/internal/domain"
	"qtransc/internal/eventcollector"
	"qtransc/internal/types"
)

type cliRunnableTask interface {
	Run(context.Context) error
	GetStatus() domain.TaskBasicStatus
}

// cliTaskCompletion installs the reliable execution-exit signal used by the
// direct CLI commands. The manager uses the same notification for slot release.
func cliTaskCompletion() (eventcollector.RuntimeOption, <-chan struct{}) {
	completed := make(chan struct{})
	var once sync.Once
	option := eventcollector.WithCompletionNotifier(func() {
		once.Do(func() { close(completed) })
	})
	return option, completed
}

// runCLITask adapts the non-blocking Run lifecycle to the CLI's synchronous
// command contract without exposing a separate execution method on Task.
func runCLITask(ctx context.Context, task cliRunnableTask, completed <-chan struct{}) <-chan error {
	done := make(chan error, 1)
	go func() {
		if err := task.Run(ctx); err != nil {
			basic := task.GetStatus()
			switch basic.Status {
			case types.StatusStopped, types.StatusCompleted:
				done <- basic.Error
			default:
				if basic.Error != nil {
					done <- basic.Error
					return
				}
				done <- err
			}
			return
		}
		<-completed
		done <- task.GetStatus().Error
	}()
	return done
}
