package main

import (
	"encoding/json"
	"io"
	"log/slog"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"qtransc/internal/logx"
)

func configureCLILogger(debug bool) {
	if !debug {
		slog.SetDefault(slog.New(slog.NewJSONHandler(io.Discard, nil)))
		logx.RedirectStdLogToSlog(slog.Default())
		return
	}

	slog.SetDefault(newCLIJSONLogger(os.Stderr, slog.LevelDebug))
	logx.RedirectStdLogToSlog(slog.Default())
}

func configurePendingTaskCLILogger(debug bool, logDir string) {
	if debug && strings.TrimSpace(logDir) != "" {
		configureCLILogger(false)
		return
	}
	configureCLILogger(debug)
}

func configureTaskCLILogger(debug bool, logDir, taskID, levelText string) {
	if !debug {
		configureCLILogger(false)
		return
	}
	if strings.TrimSpace(logDir) == "" {
		configureCLIJSONLoggerToTerminal(levelText)
		return
	}
	configureCLILoggerToNamedPathWithTruncate(logDir, taskLogFileName(taskID), levelText, true)
}

func configureCLILoggerToNamedPathWithTruncate(logDir, logFileName, levelText string, truncate bool) {
	logDir = strings.TrimSpace(logDir)
	logPath := filepath.Join(logDir, logFileName)
	if err := os.MkdirAll(logDir, 0o755); err != nil {
		configureCLIJSONLoggerToTerminal(levelText)
		slog.Error("create log directory failed", "log_path", logDir, "error", err)
		return
	}

	level := parseCLILogLevel(levelText)

	f, err := openCLILogFile(logPath, truncate)
	if err != nil {
		configureCLIJSONLoggerToTerminal(levelText)
		slog.Error("open log file failed", "log_path", logPath, "error", err)
		logCLIInvocation("stderr")
		return
	}

	os.Stdout = f
	os.Stderr = f

	slog.SetDefault(newCLIJSONLogger(f, level))
	logx.RedirectStdLogToSlog(slog.Default())
	slog.Debug("CLI logger configured", "log_path", logPath, "level", level.String(), "format", "json")
	logCLIInvocation(logPath)
}

func configureCLIJSONLoggerToTerminal(levelText string) {
	level := parseCLILogLevel(levelText)
	slog.SetDefault(newCLIJSONLogger(os.Stderr, level))
	logx.RedirectStdLogToSlog(slog.Default())
}

func parseCLILogLevel(levelText string) slog.Level {
	var level slog.Level
	if err := level.UnmarshalText([]byte(strings.TrimSpace(levelText))); err != nil {
		return slog.LevelDebug
	}
	return level
}

func taskLogFileName(taskID string) string {
	return "qtransc-" + sanitizeTaskLogName(taskID) + ".log"
}

func sanitizeTaskLogName(taskID string) string {
	taskID = strings.Map(func(r rune) rune {
		if r < 32 || strings.ContainsRune(`<>:"/\|?*`, r) {
			return '-'
		}
		return r
	}, strings.TrimSpace(taskID))
	taskID = strings.Trim(taskID, ". ")
	if taskID == "" {
		taskID = "task"
	}
	return taskID
}

func openCLILogFile(logPath string, truncate bool) (*os.File, error) {
	flags := os.O_CREATE | os.O_WRONLY
	if truncate {
		flags |= os.O_TRUNC
	} else {
		flags |= os.O_APPEND
	}
	return os.OpenFile(logPath, flags, 0666)
}

func newCLIJSONLogger(writer io.Writer, level slog.Level) *slog.Logger {
	opts := &slog.HandlerOptions{Level: level}
	return slog.New(slog.NewJSONHandler(writer, opts))
}

func logCLIInvocation(logPath string) {
	cwd, err := os.Getwd()
	if err != nil {
		cwd = ""
	}
	argv := append([]string(nil), os.Args...)
	argvJSON, err := json.Marshal(argv)
	if err != nil {
		argvJSON = []byte("[]")
	}
	slog.Info("CLI invocation",
		"log_path", logPath,
		"cwd", cwd,
		"argv", argv,
		"argv_json", string(argvJSON),
		"command_line", formatCLICommandLine(argv))
}

func formatCLICommandLine(argv []string) string {
	if len(argv) == 0 {
		return ""
	}
	parts := make([]string, 0, len(argv))
	for _, arg := range argv {
		parts = append(parts, strconv.Quote(arg))
	}
	return strings.Join(parts, " ")
}
