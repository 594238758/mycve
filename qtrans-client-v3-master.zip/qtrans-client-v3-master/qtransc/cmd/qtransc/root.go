package main

import (
	"fmt"
	"os"
	"qtransc/internal/clienterror"
	"qtransc/internal/types"
	"qtransc/internal/version"

	"github.com/spf13/cobra"
)

var cliServer string
var cliAuthToken string
var cliAuthUsername string
var cliAuthPassword string
var cliTransport string
var cliConnections int
var cliStreams int
var cliTransfers int
var cliLimitRate string
var cliDebug bool
var cliLogPath string
var cliStateDB string

const rootUsageTemplate = `Usage:{{if .Runnable}}
  {{.UseLine}}{{end}}{{if .HasAvailableSubCommands}}
  qtransc --server <host[:port]> \
    [--auth-token <token> | \
     --auth-username <username> --auth-password <password>] \
    <command> [command args]{{end}}{{if gt (len .Aliases) 0}}

Aliases:
  {{.NameAndAliases}}{{end}}{{if .HasExample}}

Examples:
{{.Example}}{{end}}{{if .HasAvailableSubCommands}}{{$cmds := .Commands}}

Available Commands:{{range $cmds}}{{if (and (eq .GroupID "") (or .IsAvailableCommand (eq .Name "help")))}}
  {{rpad .Name .NamePadding }} {{.Short}}{{end}}{{end}}{{range $group := .Groups}}

{{.Title}}{{range $cmds}}{{if (and (eq .GroupID $group.ID) (or .IsAvailableCommand (eq .Name "help")))}}
  {{rpad .Name .NamePadding }} {{.Short}}{{end}}{{end}}{{end}}{{end}}{{if .HasAvailableLocalFlags}}

Flags:
{{.LocalFlags.FlagUsages | trimTrailingWhitespaces}}{{end}}{{if .HasAvailableInheritedFlags}}

Global Flags:
{{.InheritedFlags.FlagUsages | trimTrailingWhitespaces}}{{end}}{{if .HasHelpSubCommands}}

Additional help topics:{{range .Commands}}{{if .IsAdditionalHelpTopicCommand}}
  {{rpad .CommandPath .CommandPathPadding}} {{.Short}}{{end}}{{end}}{{end}}{{if .HasAvailableSubCommands}}

Use "{{.CommandPath}} [command] --help" for more information about a command.{{end}}
`

var rootCmd = &cobra.Command{
	Use:           "qtransc",
	Short:         "qtransc – high-performance file transfer tool",
	SilenceErrors: true,
	SilenceUsage:  true,
	Long:          `qtransc is a high-performance file transfer tool.`,
	Example: `  # Browse a remote directory
  qtransc --server transfer.example.com --auth-username '123@qq.com' --auth-password 'password' list /`,
	PersistentPreRunE: func(cmd *cobra.Command, args []string) error {
		if err := prepareCLIAuth(cmd); err != nil {
			return err
		}
		return nil
	},
}

// Execute runs the root command.
func Execute() {
	if err := configureSSLKeyExportFromArgs(os.Args[1:]); err != nil {
		err = withCommandExitCode(sanitizeCLIError(err), 2)
		fmt.Fprintln(os.Stderr, clienterror.Format(err, cliDebug))
		os.Exit(commandExitCode(err))
	}
	if err := rootCmd.Execute(); err != nil {
		err = normalizeCobraError(err)
		fmt.Fprintln(os.Stderr, clienterror.Format(sanitizeCLIError(err), cliDebug))
		os.Exit(commandExitCode(err))
	}
}

func init() {
	cobra.EnableCommandSorting = false
	rootCmd.SetUsageTemplate(rootUsageTemplate)
	rootCmd.CompletionOptions.DisableDefaultCmd = true
	rootCmd.SetHelpCommand(&cobra.Command{
		Use:    "__help [command]",
		Short:  "Help about any command",
		Hidden: true,
		Run: func(cmd *cobra.Command, args []string) {
			cmd.Parent().HelpFunc()(cmd.Parent(), args)
		},
	})

	rootCmd.PersistentFlags().StringVar(&cliServer, "server", "", "qtserver address in host[:port] form; required except for serve; port defaults to 443")
	rootCmd.PersistentFlags().StringVar(&cliAuthToken, "auth-token", "", "bearer token for authenticated qtserver operations")
	rootCmd.PersistentFlags().StringVarP(&cliAuthUsername, "auth-username", "u", "anonymous", "username for auth service login")
	rootCmd.PersistentFlags().StringVarP(&cliAuthPassword, "auth-password", "w", "", "password for auth service login")
	rootCmd.PersistentFlags().StringVar(&cliTransport, "transport", string(types.TransportHTTPS3), "transport to use: v1, v2, or v3 (default)")
	rootCmd.PersistentFlags().IntVar(&cliConnections, "connections", types.DefaultConnections, "maximum connections per task execution and origin")
	rootCmd.PersistentFlags().IntVar(&cliStreams, "streams", types.DefaultStreams, "maximum in-flight requests per connection (v1 requires 1)")
	rootCmd.PersistentFlags().IntVar(&cliTransfers, "transfers", types.DefaultFileConcurrency, "number of files to transfer concurrently per task")
	rootCmd.PersistentFlags().StringVar(&cliLimitRate, "limit-rate", "", "limit total transfer rate, e.g. 10MB/s, 5MiB/s, or 1048576")
	rootCmd.PersistentFlags().Bool(exportSSLKeyFlagName, false, "write TLS session keys to sslkeys.log in the current working directory")
	rootCmd.PersistentFlags().BoolVar(&cliDebug, "debug", false, "enable debug logging")
	rootCmd.PersistentFlags().StringVar(&cliLogPath, "log-path", "", "directory for command log files")
	rootCmd.PersistentFlags().StringVar(&cliStateDB, "state-db", "", "absolute path to the upload recovery SQLite database (default: ~/.qtrans/state/upload.db)")
	rootCmd.AddGroup(
		&cobra.Group{ID: "legacy", Title: "Legacy Compatibility Commands:"},
	)
	download2Cmd.GroupID = "legacy"
	upload2Cmd.GroupID = "legacy"

	// Register subcommands
	rootCmd.AddCommand(
		serveCmd,
		listCmd,
		mkdirCmd,
		moveCmd,
		deleteCmd,
		downloadCmd,
		uploadCmd,
		download2Cmd,
		upload2Cmd,
	)

	// Initialize flags for each subcommand
	initServeFlags()
	initFileFlags()
	initDownloadFlags()
	initUploadFlags()
	initUpload2Flags()
	initDownload2Flags()
	disableFlagSorting(rootCmd)

	// Version
	rootCmd.Version = version.Version
	rootCmd.SetVersionTemplate(version.Text())
}

func disableFlagSorting(cmd *cobra.Command) {
	if cmd == nil {
		return
	}

	cmd.Flags().SortFlags = false
	cmd.PersistentFlags().SortFlags = false
	cmd.LocalFlags().SortFlags = false
	cmd.InheritedFlags().SortFlags = false

	for _, child := range cmd.Commands() {
		disableFlagSorting(child)
	}
}
