package main

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"os"
	"path/filepath"
	"qtransc/internal/clienterror"
	"qtransc/internal/config"
	"qtransc/internal/eventcollector"
	"qtransc/internal/eventlog"
	"qtransc/internal/handlers"
	"qtransc/internal/logx"
	"qtransc/internal/misc"
	"qtransc/internal/taskmanager"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/spf13/cobra"
)

var serveCmd = &cobra.Command{
	Use:   "serve",
	Short: "Start the HTTP API server",
	Long:  "Start the qtransc HTTP API server. Global transport and concurrency flags set the defaults for each task.",
	Args:  cobra.NoArgs,
	RunE: func(cmd *cobra.Command, args []string) error {
		stateDBPath := strings.TrimSpace(cliStateDB)
		if stateDBPath != "" && !filepath.IsAbs(stateDBPath) {
			return clienterror.New(clienterror.CodeInvalidArgument, "state-db must be an absolute path", nil)
		}
		appConf, err := config.Load(cmd.Flags())
		if err != nil {
			return clienterror.New(clienterror.CodeInvalidArgument, "serve 配置无效；使用 --help 查看用法", err)
		}
		return runServer(appConf, stateDBPath)
	},
}

func initServeFlags() {
	config.RegisterServeFlags(serveCmd.Flags())
}

func runServer(appConf *config.AppConfig, stateDBPath string) error {
	if err := enableSSLKeyExportIfRequested(appConf.ExportSSLKey); err != nil {
		return err
	}
	// fmt.Println(appConf.ToJSON())
	configureServeLogger(appConf)
	defer logx.Close()
	eventlog.Init(appConf.LogConfig)
	defer eventlog.SetLogger(nil, false)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	signalCtx, requestShutdown := context.WithCancel(context.Background())
	defer requestShutdown()
	httpCtx, stopHTTP := context.WithCancel(context.Background())
	defer stopHTTP()
	wg := sync.WaitGroup{}

	// Start signal listener
	wg.Add(1)
	go func() {
		defer wg.Done()
		if err := misc.StartSignalHandler(signalCtx, requestShutdown); err != nil {
			slog.Error("Signal handler exited with error", "error", err)
			fmt.Fprintln(os.Stderr, "Signal handler error")
		}
	}()

	// Initialize task manager
	eventBus := eventcollector.NewBus(eventcollector.DefaultSubscriberBuffer)
	defer eventBus.Close()
	taskManager := taskmanager.NewTaskManager(ctx, 10, 64, appConf.TransferDefaults,
		eventcollector.WithPublisher(eventBus),
		eventcollector.WithProgressInterval(appConf.SSEConfig.ProgressInterval),
	)
	if err := taskManager.Start(); err != nil {
		slog.Error("start task manager failed", "error", err)
		requestShutdown()
		wg.Wait()
		return err
	}

	// Initialize handlers
	taskHandler := handlers.NewTaskHandler(ctx, taskManager,
		handlers.WithEventBus(eventBus),
		handlers.WithHeartbeatInterval(appConf.SSEConfig.HeartbeatInterval),
		handlers.WithStateDBPath(stateDBPath),
	)

	// Start HTTP server
	wg.Add(1)
	go func() {
		defer wg.Done()
		StartServer(httpCtx, appConf.Port, appConf.SecretKey, taskHandler)
	}()

	<-signalCtx.Done()
	if err := taskManager.Shutdown(5 * time.Second); err != nil {
		slog.Error("stop task manager failed", "error", err)
	}
	// Closing the bus lets SSE consumers drain final events before HTTP closes.
	eventBus.Close()
	stopHTTP()
	wg.Wait()
	return nil
}

func configureServeLogger(appConf *config.AppConfig) {
	if !appConf.Debug {
		configureCLILogger(false)
		gin.DefaultWriter = io.Discard
		gin.DefaultErrorWriter = io.Discard
		return
	}

	logDir := strings.TrimSpace(appConf.LogConfig.Directory)
	if logDir == "" {
		configureCLILogger(true)
		gin.DefaultWriter = os.Stderr
		gin.DefaultErrorWriter = os.Stderr
		return
	}
	if err := os.MkdirAll(logDir, 0o755); err != nil {
		configureCLILogger(true)
		gin.DefaultWriter = os.Stderr
		gin.DefaultErrorWriter = os.Stderr
		slog.Error("create log directory failed", "log_path", logDir, "error", err)
		return
	}
	if err := logx.Init(appConf.LogConfig); err != nil {
		configureCLILogger(true)
		gin.DefaultWriter = os.Stderr
		gin.DefaultErrorWriter = os.Stderr
		slog.Error("initialize file logger failed", "log_path", appConf.LogConfig.EngineLogPath, "error", err)
	}
}
