package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/url"
	"os"
	"os/signal"
	"path/filepath"
	"qtransc/internal/downloadtask"
	"qtransc/internal/netclient"
	"qtransc/internal/qtserverurl"
	"qtransc/internal/types"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/gorilla/websocket"
	"github.com/spf13/cobra"
)

type legacyDownload2FileRequest struct {
	LocalRelPath string `json:"local_rel_path"`
	RemoteURL    string `json:"remote_url"`
}

type download2CompatReporter struct {
	task         *downloadtask.DownloadTask
	taskID       string
	wsURL        string
	absPathByRel map[string]string

	startCh       chan struct{}
	doneCh        chan error
	terminalAckCh chan struct{}

	startOnce       sync.Once
	terminalAckOnce sync.Once
}

func newDownload2CompatReporter(task *downloadtask.DownloadTask, taskID, wsURL string, absPathByRel map[string]string) *download2CompatReporter {
	return &download2CompatReporter{
		task:          task,
		taskID:        taskID,
		wsURL:         strings.TrimSpace(wsURL),
		absPathByRel:  absPathByRel,
		startCh:       make(chan struct{}),
		doneCh:        make(chan error, 1),
		terminalAckCh: make(chan struct{}),
	}
}

func (r *download2CompatReporter) usesWebSocket() bool {
	return r.taskID != "" && r.wsURL != ""
}

func (r *download2CompatReporter) releaseStart() {
	r.startOnce.Do(func() { close(r.startCh) })
}

func (r *download2CompatReporter) ackTerminal() {
	r.terminalAckOnce.Do(func() { close(r.terminalAckCh) })
}

func (r *download2CompatReporter) Start(ctx context.Context, cancel context.CancelFunc) (<-chan struct{}, <-chan error) {
	go r.run(ctx, cancel)
	return r.startCh, r.doneCh
}

func (r *download2CompatReporter) WaitTerminalAck(timeout time.Duration) {
	if !r.usesWebSocket() {
		return
	}
	select {
	case <-r.terminalAckCh:
	case <-time.After(timeout):
	}
}

func (r *download2CompatReporter) run(ctx context.Context, cancel context.CancelFunc) {
	if !r.usesWebSocket() {
		r.releaseStart()
		r.doneCh <- nil
		return
	}

	conn, _, err := websocket.DefaultDialer.Dial(r.wsURL, nil)
	if err != nil {
		cancel()
		r.doneCh <- fmt.Errorf("dial websocket server failed: %w", err)
		return
	}
	defer conn.Close()

	if err := conn.WriteJSON(legacyUpload2WSResponse{
		TaskID: r.taskID,
		Code:   int(legacyUpload2TransNormalStatus),
	}); err != nil {
		cancel()
		r.doneCh <- fmt.Errorf("write websocket server failed: %w", err)
		return
	}

	messageCh := make(chan []byte)
	errCh := make(chan error, 1)
	go func() {
		for {
			_, message, err := conn.ReadMessage()
			if err != nil {
				errCh <- err
				return
			}
			messageCh <- message
		}
	}()

	for {
		select {
		case <-ctx.Done():
			r.doneCh <- nil
			return
		case err := <-errCh:
			if websocket.IsCloseError(err, websocket.CloseNormalClosure, websocket.CloseGoingAway) {
				r.doneCh <- nil
				return
			}
			if isLegacyCoordinatorPauseClose(err) {
				cancel()
				r.doneCh <- nil
				return
			}
			cancel()
			r.doneCh <- fmt.Errorf("read websocket message failed: %w", err)
			return
		case message := <-messageCh:
			var req legacyUpload2WSRequest
			if err := json.Unmarshal(message, &req); err != nil {
				cancel()
				r.doneCh <- fmt.Errorf("decode websocket request failed: %w", err)
				return
			}

			resp, err := handleLegacyCoordinatorRequest(r.taskID, req, r.buildResponse)
			if err != nil {
				cancel()
				r.doneCh <- err
				return
			}
			if err := conn.WriteJSON(resp); err != nil {
				cancel()
				r.doneCh <- fmt.Errorf("write websocket response failed: %w", err)
				return
			}
		}
	}
}

func (r *download2CompatReporter) buildResponse() legacyUpload2WSResponse {
	status, data := r.currentStatus()
	if status == legacyUpload2TransStarting {
		r.releaseStart()
	}
	if status == legacyUpload2TransFinished || status >= legacyUpload2TransError {
		r.ackTerminal()
	}
	return legacyUpload2WSResponse{
		TaskID: r.taskID,
		Code:   int(status),
		Data:   data,
	}
}

func (r *download2CompatReporter) currentStatus() (legacyUpload2Status, any) {
	basic := r.task.GetStatus()
	progress := r.snapshotProgress()
	taskErr := basic.Error

	switch basic.Status {
	case types.StatusPending:
		return legacyUpload2TransStarting, legacyUpload2TransStarting.String()
	case types.StatusRunning:
		progress.Status = 0
		return legacyUpload2TransRunning, progress
	case types.StatusCompleted:
		progress.Status = 1
		return legacyUpload2TransFinished, progress
	case types.StatusFailed:
		if isUpload2AuthError(taskErr) {
			return legacyUpload2TransAuthFailed, legacyUpload2TransAuthFailed.String()
		}
		if errors.Is(taskErr, downloadtask.ErrTargetDirNoSpace) {
			return legacyUpload2TransDiskSpaceNotEnough, legacyUpload2TransDiskSpaceNotEnough.String()
		}
		return legacyUpload2TransError, legacyUpload2TransError.String()
	case types.StatusStopped:
		if taskErr != nil {
			if isUpload2AuthError(taskErr) {
				return legacyUpload2TransAuthFailed, legacyUpload2TransAuthFailed.String()
			}
			if errors.Is(taskErr, downloadtask.ErrTargetDirNoSpace) {
				return legacyUpload2TransDiskSpaceNotEnough, legacyUpload2TransDiskSpaceNotEnough.String()
			}
			return legacyUpload2TransError, legacyUpload2TransError.String()
		}
		progress.Status = 1
		return legacyUpload2TransFinished, progress
	default:
		progress.Status = -1
		return legacyUpload2TransError, progress
	}
}

func (r *download2CompatReporter) snapshotProgress() legacyUpload2TotalProgressInfo {
	total := r.task.TotalSize.Load()
	transferred := r.task.Transferred.Load()
	rate := r.task.Rate.Load()

	files := make([]legacyUpload2ProgressInfo, 0)
	r.task.TransferingFiles.Range(func(_, value any) bool {
		file, ok := value.(*downloadtask.FileInfo)
		if !ok || file == nil {
			return true
		}
		if file.Verified {
			return true
		}
		fileTransferred := atomic.LoadInt64(&file.Transferred)
		pct := calcUpload2Percent(fileTransferred, file.Size)
		absPath := file.LocalPath
		if abs, ok := r.absPathByRel[file.LocalPath]; ok {
			absPath = abs
		}
		fileRate := atomic.LoadInt64(&file.Rate)
		files = append(files, legacyUpload2ProgressInfo{
			File:            absPath,
			ProgressPercent: pct,
			Transferred:     fileTransferred,
			Total:           file.Size,
			Rate:            formatUpload2KBRate(fileRate),
		})
		return true
	})

	return legacyUpload2TotalProgressInfo{
		Status:           0,
		ProgressPercent:  calcUpload2Percent(transferred, total),
		TotalTransferred: transferred,
		TotalFileSize:    total,
		Rate:             formatUpload2KBRate(rate),
		Files:            files,
	}
}

var (
	dl2TaskID        string
	dl2WSSURL        string
	dl2JSONFile      string
	dl2TargetDir     string
	dl2Transport     string
	dl2CallerVersion string
)

var download2Cmd = &cobra.Command{
	Use:   "download2",
	Short: "Legacy-compatible download command backed by the latest engine core",
	Long: `download2 keeps the old qtrans-client download contract:
- task JSON from --jf with {local_rel_path, remote_url} entries
- remote_url may be a full download URL (public) or a relative path/object key (authorized)
- optional websocket progress query protocol via --wss-url/--taskid
- server address specified via --server

The actual transfer is executed by the current qtransc download core.`,
	RunE: runDownload2,
}

func initDownload2Flags() {
	download2Cmd.Flags().StringVarP(&dl2TaskID, "taskid", "t", "", "legacy task id used by the websocket coordinator")
	download2Cmd.Flags().StringVar(&dl2WSSURL, "wss-url", "", "legacy websocket server URL for status queries")
	download2Cmd.Flags().StringVarP(&dl2JSONFile, "jf", "j", "", "path to the legacy download task JSON file")
	download2Cmd.Flags().VarP(&singleStringFlagValue{name: "destination", target: &dl2TargetDir}, "destination", "d", "local destination directory (default ~/qtransdownload)")
	download2Cmd.Flags().StringVar(&dl2CallerVersion, "callerversion", "", "version of the GUI or agent invoking download2")

}

func runDownload2(cmd *cobra.Command, args []string) error {
	dl2TaskID = resolveDownload2TaskID(dl2TaskID)
	configureCompatTaskCLILogger(cliDebug, cliLogPath, dl2TaskID, "debug")
	slog.Debug("download2 command started",
		"task_id", dl2TaskID,
		"taskpid", "",
		"enterprise_id", "",
		"wss_url", dl2WSSURL,
		"server", cliServer,
		"json_file", dl2JSONFile,
		"connections", cliConnections,
		"streams", cliStreams,
		"transfers", cliTransfers,
		"transport", cliTransport,
		"debug", cliDebug,
		"log_path", cliLogPath)
	if cliDebug {
		slog.Debug("download2 compatibility mode keeps log-only output; terminal summaries are suppressed")
	}

	serverURL, err := resolveDownload2Server(cliServer)
	if err != nil {
		return err
	}

	legacyFiles, err := loadDownload2CompatFiles(dl2JSONFile)
	if err != nil {
		return err
	}

	bearerToken, err := optionalCLIBearerToken()
	if err != nil {
		return err
	}
	req, absPathByRel, err := buildDownload2TaskRequest(dl2TaskID, bearerToken, dl2CallerVersion, serverURL, dl2TargetDir, legacyFiles)
	if err != nil {
		return err
	}

	if cmd.Flags().Changed("transport") {
		slog.Warn("download2 ignores --transport and always uses v3", "requested_transport", cliTransport)
	}

	transportMode, err := types.ParseTransportMode(req.Transport)
	if err != nil {
		return fmt.Errorf("invalid transport: %w", err)
	}
	poolCfg, err := netclient.NormalizePoolConfig(transportMode, cliConnections, cliStreams)
	if err != nil {
		return fmt.Errorf("invalid download concurrency config: %w", err)
	}
	fileConcurrency, err := resolveFileConcurrency(cliTransfers)
	if err != nil {
		return err
	}
	slog.Info("download2 effective transfer settings",
		"transport", transportMode,
		"connections", poolCfg.Connections,
		"streams", poolCfg.StreamsPerConnection,
		"transfers", fileConcurrency)

	client, err := netclient.New(transportMode, netclient.Config{Pool: poolCfg})
	if err != nil {
		return fmt.Errorf("failed to initialize %s client pool: %w", transportMode, err)
	}
	defer client.Close()

	completionOption, taskCompleted := cliTaskCompletion()
	task, err := downloadtask.NewDownloadTask(req, client.Config(), client, completionOption)
	if err != nil {
		return fmt.Errorf("failed to create download task: %w", err)
	}
	task.FileConcurrency = fileConcurrency

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sigCh
		_ = task.Stop()
		cancel()
	}()

	reporter := newDownload2CompatReporter(task, req.TaskID, dl2WSSURL, absPathByRel)
	startCh, wsDone := reporter.Start(ctx, func() { _ = task.Stop(); cancel() })
	select {
	case <-startCh:
	case wsErr := <-wsDone:
		if wsErr != nil {
			return wsErr
		}
	case <-ctx.Done():
		if err := ctx.Err(); err != nil && err != context.Canceled {
			return err
		}
		return context.Canceled
	}

	done := runCLITask(ctx, task, taskCompleted)

	taskErr := waitDownload2WithLogProgress(task, serverURL, req.TargetDir, done)

	reporter.WaitTerminalAck(legacyTerminalAckTimeout)
	cancel()

	wsErr := <-wsDone
	if taskErr != nil {
		return taskErr
	}
	if wsErr != nil {
		return wsErr
	}
	return nil
}

func waitDownload2WithLogProgress(task *downloadtask.DownloadTask, serverURL, targetDir string, done <-chan error) error {
	startedAt := time.Now()
	slog.Info("download2 transfer started",
		"task_id", task.TaskID,
		"taskpid", task.TaskPID,
		"enterprise_id", task.EnterpriseID,
		"server", serverURL,
		"target_dir", targetDir,
		"files", len(task.FileList),
		"total_bytes", task.TotalSize.Load(),
		"total", formatBytes(task.TotalSize.Load()))
	err := <-done
	logDownload2Progress(task, serverURL, targetDir, startedAt, true, err)
	return err
}

func logDownload2Progress(task *downloadtask.DownloadTask, serverURL, targetDir string, startedAt time.Time, final bool, taskErr error) {
	total := task.TotalSize.Load()
	transferred := task.Transferred.Load()
	rate := task.Rate.Load()
	completedFiles, activeFiles := download2FileCounts(task.AuthorizedFiles)
	status := task.GetStatus().Status

	attrs := []any{
		"task_id", task.TaskID,
		"taskpid", task.TaskPID,
		"enterprise_id", task.EnterpriseID,
		"server", serverURL,
		"target_dir", targetDir,
		"status", status,
		"progress_percent", strings.TrimSpace(percentage(transferred, total)),
		"transferred_bytes", transferred,
		"total_bytes", total,
		"transferred", formatBytes(transferred),
		"total", formatBytes(total),
		"rate_bytes_per_sec", rate,
		"rate", formatBytes(rate) + "/s",
		"completed_files", completedFiles,
		"authorized_files", len(task.AuthorizedFiles),
		"unauthorized_files", len(task.UnAuthorizedFiles),
		"active_files", activeFiles,
		"elapsed", formatDuration(time.Since(startedAt)),
	}

	if !final {
		return
	}
	if taskErr != nil {
		attrs = append(attrs, "err", taskErr)
		slog.Error("download2 transfer failed", attrs...)
		return
	}
	slog.Info("download2 transfer finished", attrs...)
}

func download2FileCounts(files []*downloadtask.FileInfo) (completed int, active int) {
	for _, file := range files {
		if file == nil {
			continue
		}
		if file.Verified || (file.Size > 0 && file.Transferred >= file.Size) {
			completed++
			continue
		}
		if file.Transferred > 0 {
			active++
		}
	}
	return completed, active
}

func loadDownload2CompatFiles(jsonFile string) ([]legacyDownload2FileRequest, error) {
	jsonFile = strings.TrimSpace(jsonFile)
	if jsonFile == "" {
		return nil, fmt.Errorf("--jf is required")
	}

	data, err := os.ReadFile(jsonFile)
	if err != nil {
		return nil, fmt.Errorf("read download json file: %w", err)
	}

	var files []legacyDownload2FileRequest
	if err := json.Unmarshal(data, &files); err != nil {
		return nil, fmt.Errorf("parse download task json: %w", err)
	}
	if len(files) == 0 {
		return nil, fmt.Errorf("download task json is empty")
	}

	for i := range files {
		files[i].LocalRelPath = strings.TrimSpace(files[i].LocalRelPath)
		files[i].RemoteURL = strings.TrimSpace(files[i].RemoteURL)
		if files[i].LocalRelPath == "" || files[i].RemoteURL == "" {
			return nil, fmt.Errorf("download task file %d is missing local_rel_path or remote_url", i)
		}
	}

	return files, nil
}

func isAbsoluteDownload2RemoteURL(rawURL string) bool {
	parsed, err := url.Parse(strings.TrimSpace(rawURL))
	return err == nil && parsed.IsAbs() && parsed.Host != ""
}

// extractDownload2ObjectKey extracts the object key from a download input.
// It accepts either:
//   - a root-relative download path, e.g. "/qtserver/v1/d/down/gsa/CRA025038/file.gz?grant=xxx"
//   - a plain object key, e.g. "gsa/CRA025038/file.gz"
func extractDownload2ObjectKey(rawURL string) (string, error) {
	rawURL = strings.TrimSpace(rawURL)
	if rawURL == "" {
		return "", fmt.Errorf("empty object key in remote_url %q", rawURL)
	}

	if isAbsoluteDownload2RemoteURL(rawURL) {
		_, objectKey, err := qtserverurl.ExtractDownloadBaseAndObjectKey(rawURL)
		return objectKey, err
	}

	parsed, err := url.Parse(rawURL)
	if err != nil {
		return "", fmt.Errorf("invalid remote_url %q: %w", rawURL, err)
	}

	cleanPath := strings.TrimRight(parsed.EscapedPath(), "/")
	if cleanPath == "" {
		cleanPath = strings.TrimRight(parsed.Path, "/")
	}
	if cleanPath == "" {
		return "", fmt.Errorf("empty object key in remote_url %q", rawURL)
	}

	marker := qtserverurl.DownloadContentPath + "/"
	if strings.HasPrefix(cleanPath, marker) {
		objectKey := "/" + strings.Trim(strings.TrimPrefix(cleanPath, marker), "/")
		if objectKey == "" {
			return "", fmt.Errorf("empty object key in remote_url %q", rawURL)
		}
		return objectKey, nil
	}

	objectKey := "/" + strings.Trim(cleanPath, "/")
	if objectKey == "" {
		return "", fmt.Errorf("empty object key in remote_url %q", rawURL)
	}
	return objectKey, nil
}

func buildDownload2TaskRequest(taskID, bearerToken, callerVersion, serverURL, targetDir string, files []legacyDownload2FileRequest) (*types.TaskCreateRequest, map[string]string, error) {
	taskID = resolveDownload2TaskID(taskID)
	if strings.TrimSpace(targetDir) == "" {
		home, err := os.UserHomeDir()
		if err != nil {
			return nil, nil, fmt.Errorf("cannot determine home directory: %w", err)
		}
		targetDir = filepath.Join(home, "qtransdownload")
	}
	absTarget, err := filepath.Abs(targetDir)
	if err != nil {
		return nil, nil, fmt.Errorf("invalid target directory: %w", err)
	}
	targetDir = absTarget

	fileList := make([]types.TaskFileSpec, 0, len(files))
	absPathByRel := make(map[string]string, len(files))
	for _, f := range files {
		objectKey, err := extractDownload2ObjectKey(f.RemoteURL)
		if err != nil {
			return nil, nil, err
		}
		fileList = append(fileList, types.TaskFileSpec{
			LocalRelPath: f.LocalRelPath,
			RemoteURL:    objectKey,
		})
		absPathByRel[f.LocalRelPath] = filepath.Join(targetDir, f.LocalRelPath)
	}

	// 从本地相对路径推导父目录，确保本地创建的目录层级与调用方期望一致。
	dirSet := make(map[string]bool)
	for _, fs := range fileList {
		for p := filepath.Dir(fs.LocalRelPath); p != "." && p != string(filepath.Separator); p = filepath.Dir(p) {
			dirSet[p] = true
		}
	}
	dirPaths := make([]string, 0, len(dirSet))
	for d := range dirSet {
		dirPaths = append(dirPaths, d)
	}
	sort.Strings(dirPaths)

	req := &types.TaskCreateRequest{
		TaskID:        taskID,
		CallerVersion: callerVersion,
		TaskName:      "download2-" + taskID,
		Mode:          "download",
		Transport:     types.TransportHTTPS3.String(),
		ServerAddr:    serverURL,
		TargetDir:     targetDir,
		FileList:      fileList,
		DirPaths:      dirPaths,
		BearerToken:   bearerToken,
	}
	if err := req.Validate(); err != nil {
		return nil, nil, err
	}
	return req, absPathByRel, nil
}

func resolveDownload2Server(serverAddr string) (string, error) {
	parsed, err := ParseQtransServer(serverAddr, types.TransportHTTPS3)
	if err != nil {
		return "", err
	}
	return parsed.ServerURL, nil
}

func resolveDownload2TaskID(taskID string) string {
	taskID = strings.TrimSpace(taskID)
	if taskID != "" {
		return taskID
	}
	return fmt.Sprintf("compat-dl-%d", time.Now().UnixNano())
}
