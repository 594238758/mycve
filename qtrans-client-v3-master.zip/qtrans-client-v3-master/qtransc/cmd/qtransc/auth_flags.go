package main

import (
	"errors"
	"fmt"
	"strings"

	"qtransc/internal/authmanager"
	"qtransc/internal/qtserverapi"
	"qtransc/internal/types"

	"github.com/spf13/cobra"
)

const (
	anonymousAuthUsername        = "anonymous"
	anonymousCanonicalWriteToken = qtserverapi.AnonymousWriteToken
)

func prepareCLIAuth(cmd *cobra.Command) error {
	if cmd == serveCmd {
		return nil
	}

	transport, err := types.ParseTransportMode(cliTransport)
	if err != nil {
		return err
	}
	server, err := ParseQtransServer(cliServer, transport)
	if err != nil {
		return err
	}
	if err := validateCLIAuthFlags(); err != nil {
		return err
	}
	return configureAuthManagerFromCLI(server.ServerURL)
}

func validateCLIAuthFlags() error {
	tokenProvided := strings.TrimSpace(cliAuthToken) != ""
	passwordProvided := cliAuthPassword != ""

	if cliAuthUsername == "" {
		return fmt.Errorf("--auth-username must not be empty")
	}
	if tokenProvided && (cliAuthUsername != anonymousAuthUsername || passwordProvided) {
		return fmt.Errorf("--auth-token cannot be used together with --auth-username or --auth-password")
	}
	if cliAuthUsername != anonymousAuthUsername && !passwordProvided {
		return fmt.Errorf("--auth-password is required when --auth-username is not anonymous")
	}
	return nil
}

func configureAuthManagerFromCLI(serverOrigin string) error {
	token := strings.TrimSpace(cliAuthToken)
	if token != "" {
		return authmanager.SetStaticToken(token)
	}
	if cliAuthUsername != anonymousAuthUsername {
		return authmanager.SetUserAndPass(authmanager.UserAndPassConfig{
			Username:     cliAuthUsername,
			Password:     cliAuthPassword,
			ServerOrigin: serverOrigin,
		})
	}
	// anonymous never logs in; a supplied password is intentionally ignored.
	return nil
}

func optionalCLIBearerToken() (string, error) {
	token, err := authmanager.Get()
	if err == nil {
		return token, nil
	}
	if authmanager.IsNotInitialized(err) || errors.Is(err, authmanager.ErrAccessTokenMissing) {
		return "", nil
	}
	return "", err
}

func requiredCLIBearerToken() (string, error) {
	token, err := authmanager.Get()
	if err != nil {
		return "", err
	}
	if strings.TrimSpace(token) == "" {
		return "", authmanager.ErrAccessTokenMissing
	}
	return token, nil
}

func canonicalWriteCLIBearerToken() (string, error) {
	if strings.TrimSpace(cliAuthToken) == "" && cliAuthUsername == anonymousAuthUsername {
		return anonymousCanonicalWriteToken, nil
	}
	return requiredCLIBearerToken()
}
