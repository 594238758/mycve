package main

import (
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

const compatTaskLogRetention = 7 * 24 * time.Hour

func configureCompatTaskCLILogger(debug bool, logDir, taskID, levelText string) {
	logDir = strings.TrimSpace(logDir)
	if !debug || logDir == "" {
		configureTaskCLILogger(debug, logDir, taskID, levelText)
		return
	}

	now := time.Now()
	name := fmt.Sprintf("qtransc-%d-%d-%s.log", now.UnixMilli(), os.Getpid(), sanitizeTaskLogName(taskID))
	configureCLILoggerToNamedPathWithTruncate(logDir, name, levelText, true)
	cleanupCompatTaskLogs(logDir, name, now.Add(-compatTaskLogRetention))
}

// Age is determined solely by the filename timestamp. The current log and
// entries that are not regular files are never removed.
func cleanupCompatTaskLogs(logDir, currentName string, cutoff time.Time) {
	entries, err := os.ReadDir(logDir)
	if err != nil {
		if !os.IsNotExist(err) {
			slog.Warn("read task log directory for cleanup failed", "log_path", logDir, "error", err)
		}
		return
	}

	removed := 0
	for _, entry := range entries {
		name := entry.Name()
		if name == currentName || !entry.Type().IsRegular() {
			continue
		}
		created, ok := compatTaskLogTime(name)
		if !ok || !created.Before(cutoff) {
			continue
		}
		info, err := entry.Info()
		if err != nil {
			if !os.IsNotExist(err) {
				slog.Warn("inspect expired task log failed", "log_file", name, "error", err)
			}
			continue
		}
		if !info.Mode().IsRegular() {
			continue
		}
		if err := os.Remove(filepath.Join(logDir, name)); err != nil {
			if !os.IsNotExist(err) {
				slog.Warn("remove expired task log failed", "log_file", name, "error", err)
			}
			continue
		}
		removed++
	}
	slog.Debug("task log cleanup finished", "removed", removed, "retention_days", 7)
}

func compatTaskLogTime(name string) (time.Time, bool) {
	if !strings.HasPrefix(name, "qtransc-") || !strings.HasSuffix(name, ".log") {
		return time.Time{}, false
	}
	body := strings.TrimSuffix(strings.TrimPrefix(name, "qtransc-"), ".log")
	parts := strings.SplitN(body, "-", 3)
	if len(parts) == 3 && parts[2] != "" {
		if pid, err := strconv.ParseUint(parts[1], 10, 32); err == nil && pid > 0 {
			if stamp, ok := parseTaskLogTimestamp(parts[0], 13); ok {
				return time.UnixMilli(stamp), true
			}
		}
	}

	// Recognize filenames written by older GUI launches without imposing a
	// format on task IDs accepted by the commands or the WebSocket protocol.
	for _, prefix := range []string{"upload-", "download-"} {
		if strings.HasPrefix(body, prefix) {
			last := strings.LastIndexByte(body, '-')
			if last > len(prefix) {
				if stamp, ok := parseTaskLogTimestamp(body[last+1:], 13); ok {
					return time.UnixMilli(stamp), true
				}
			}
		}
	}
	for _, prefix := range []string{"compat-ul-", "compat-dl-"} {
		if rest, ok := strings.CutPrefix(body, prefix); ok {
			if stamp, ok := parseTaskLogTimestamp(rest, 19); ok {
				return time.Unix(0, stamp), true
			}
		}
	}
	return time.Time{}, false
}

func parseTaskLogTimestamp(value string, digits int) (int64, bool) {
	if len(value) != digits {
		return 0, false
	}
	for _, c := range value {
		if c < '0' || c > '9' {
			return 0, false
		}
	}
	stamp, err := strconv.ParseInt(value, 10, 64)
	return stamp, err == nil && stamp > 0
}
