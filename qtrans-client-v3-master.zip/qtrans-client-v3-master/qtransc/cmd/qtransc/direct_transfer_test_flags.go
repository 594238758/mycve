package main

import (
	"fmt"
	"qtransc/internal/types"
	"strings"
)

// These command-local controls exist only for transfer experiments.
var dlMCRWSize string

func initDirectDownloadTestFlags() {
	downloadCmd.Flags().StringVar(&dlMCRWSize, "mcrw-size", "",
		"test only: override QUIC MaxConnectionReceiveWindow, e.g. 4MiB")
}

func parseDownloadMCRWSize(raw string, mode types.TransportMode) (int64, error) {
	if strings.TrimSpace(raw) == "" {
		return 0, nil
	}
	if mode != types.TransportHTTPS3 {
		return 0, fmt.Errorf("--mcrw-size 仅支持 --transport v3")
	}
	windowBytes, err := parseLimitSize(raw)
	if err != nil {
		return 0, fmt.Errorf("invalid --mcrw-size: %w", err)
	}
	return windowBytes, nil
}
