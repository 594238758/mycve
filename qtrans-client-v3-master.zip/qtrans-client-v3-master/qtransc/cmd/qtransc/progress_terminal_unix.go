//go:build linux || darwin

package main

import (
	"os"
	"sync"

	"github.com/mattn/go-isatty"
	"golang.org/x/sys/unix"
)

func suppressTerminalInputEcho() func() {
	if os.Stdin == nil || os.Stderr == nil ||
		!isatty.IsTerminal(os.Stdin.Fd()) ||
		!isatty.IsTerminal(os.Stderr.Fd()) {
		return func() {}
	}

	fd := int(os.Stdin.Fd())
	original, err := unix.IoctlGetTermios(fd, terminalGetAttributes)
	if err != nil {
		return func() {}
	}
	quiet := *original
	quiet.Lflag &^= unix.ECHO | unix.ECHONL
	if err := unix.IoctlSetTermios(fd, terminalSetAttributes, &quiet); err != nil {
		return func() {}
	}

	var once sync.Once
	return func() {
		once.Do(func() {
			_ = unix.IoctlSetTermios(fd, terminalRestoreAttributes, original)
		})
	}
}
