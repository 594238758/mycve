package main

import (
	"fmt"
	"io"
	"text/tabwriter"

	"qtransc/internal/types"
)

type browseRenderEntry struct {
	Name         string
	EntryType    string
	Size         int64
	LastModified string
}

func renderBrowseTable(out io.Writer, location string, entries []browseRenderEntry) {
	_, _ = fmt.Fprintf(out, "%s\n", location)
	if len(entries) == 0 {
		_, _ = fmt.Fprintln(out, "(empty)")
		return
	}

	tw := tabwriter.NewWriter(out, 0, 0, 2, ' ', 0)
	_, _ = fmt.Fprintln(tw, "NAME\tSIZE\tLAST MODIFIED")

	for _, entry := range entries {
		displayName := entry.Name
		sizeDisplay := "-"
		if entry.EntryType == types.DownloadBrowseEntryDirectory {
			displayName += "/"
		} else {
			sizeDisplay = formatBytes(entry.Size)
		}

		_, _ = fmt.Fprintf(tw, "%s\t%s\t%s\n", displayName, sizeDisplay, entry.LastModified)
	}
	_ = tw.Flush()
}
