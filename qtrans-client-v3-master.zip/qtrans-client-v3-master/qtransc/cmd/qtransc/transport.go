package main

import (
	"qtransc/internal/netclient"
	"qtransc/internal/types"
)

func newClientForTransport(mode types.TransportMode, connections, streams int) (*netclient.Client, error) {
	return netclient.New(mode, netclient.Config{Pool: netclient.PoolConfig{Connections: connections, StreamsPerConnection: streams}})
}
