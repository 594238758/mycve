package main

import (
	"context"
	"crypto/subtle"
	"encoding/json"
	"fmt"
	"log/slog"
	"net"
	"net/http"
	"os"
	"qtransc/internal/handlers"
	"qtransc/internal/serveapi"
	"runtime/debug"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
)

const defaultServerHost = "0.0.0.0"

func StartServer(ctx context.Context, port int, secretKey string, handler *handlers.TaskHandler) {
	router := setupRouter(handler, secretKey)

	addr := fmt.Sprintf("%s:%d", defaultServerHost, port)
	srv := &http.Server{
		Addr:    addr,
		Handler: router,
	}

	// Create a listener
	listener, err := net.Listen("tcp", addr)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Failed to listen on port %d: %v\n", port, err)
		os.Exit(1)
	}
	var serveWG sync.WaitGroup
	serveWG.Add(1)
	go func() {
		defer serveWG.Done()
		fmt.Printf("Server listening on %s\n", addr)
		if err := srv.Serve(listener); err != nil && err != http.ErrServerClosed {
			fmt.Fprintf(os.Stderr, "Server error: %v\n", err)
		}
	}()

	// Wait for context cancellation to gracefully shutdown the server
	<-ctx.Done()

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(shutdownCtx); err != nil {
		fmt.Fprintf(os.Stderr, "Server shutdown error: %v\n", err)
	} else {
		serveWG.Wait()
		fmt.Println("Server gracefully stopped")
	}
}

func setupRouter(handler *handlers.TaskHandler, secretKey string) *gin.Engine {
	router := gin.New()
	router.RedirectTrailingSlash = false
	router.RedirectFixedPath = false
	router.HandleMethodNotAllowed = true

	// CORS remains outermost so every generated JSON response carries the
	// expected headers and OPTIONS can terminate with 204.
	router.Use(corsMiddleware(), gin.LoggerWithFormatter(formatGinAccessLogJSON), ginJSONRecovery())
	router.NoRoute(func(c *gin.Context) {
		c.JSON(http.StatusOK, serveapi.Failure(serveapi.CodeRequestInvalid))
	})
	router.NoMethod(func(c *gin.Context) {
		c.JSON(http.StatusOK, serveapi.Failure(serveapi.CodeRequestInvalid))
	})

	// Health check
	router.GET("/api/v1/health", handler.Health)

	protected := router.Group("")
	if strings.TrimSpace(secretKey) != "" {
		protected.Use(secretKeyMiddleware(secretKey))
	}
	protected.GET("/api/v1/conf", handler.GetConfig)
	protected.POST("/api/v1/conf/token", handler.UpdateToken)

	// SSE subscribe (实时事件推送)
	protected.GET("/api/v1/events", handler.Events)

	// Task management
	protected.POST("/api/v1/tasks", handler.CreateAndStartTask)
	protected.POST("/api/v2/tasks", handler.CreateAndStartTaskV2)
	protected.DELETE("/api/v1/tasks/:task_id", handler.DeleteTask)
	protected.GET("/api/v1/tasks/:task_id/detail", handler.GetTaskDetail)
	protected.GET("/api/v1/tasks/:task_id/summary", handler.GetTaskSummary)

	// Task operations
	protected.POST("/api/v1/tasks/:task_id/start", handler.StartTask)
	protected.POST("/api/v1/tasks/:task_id/pause", handler.StopTask)

	// List tasks
	protected.GET("/api/v1/tasks", handler.GetTasksSummary)

	return router
}

func secretKeyMiddleware(secretKey string) gin.HandlerFunc {
	expected := []byte(strings.TrimSpace(secretKey))
	return func(c *gin.Context) {
		provided, ok := bearerCredential(c.GetHeader("Authorization"))
		if !ok || subtle.ConstantTimeCompare([]byte(provided), expected) != 1 {
			c.AbortWithStatusJSON(http.StatusOK, serveapi.Failure(serveapi.CodeAccessDenied))
			return
		}
		c.Next()
	}
}

func bearerCredential(authorization string) (string, bool) {
	scheme, credential, ok := strings.Cut(strings.TrimSpace(authorization), " ")
	credential = strings.TrimSpace(credential)
	if !ok || !strings.EqualFold(scheme, "Bearer") || credential == "" {
		return "", false
	}
	return credential, true
}

func formatGinAccessLogJSON(param gin.LogFormatterParams) string {
	record := map[string]any{
		"time":       param.TimeStamp.Format(time.RFC3339Nano),
		"level":      "INFO",
		"msg":        "gin request",
		"status":     param.StatusCode,
		"latency":    param.Latency.String(),
		"client_ip":  param.ClientIP,
		"method":     param.Method,
		"path":       param.Path,
		"body_size":  param.BodySize,
		"user_agent": param.Request.UserAgent(),
	}
	if param.ErrorMessage != "" {
		record["error"] = param.ErrorMessage
	}
	raw, err := json.Marshal(record)
	if err != nil {
		return `{"level":"ERROR","msg":"marshal gin access log failed"}` + "\n"
	}
	return string(raw) + "\n"
}

func ginJSONRecovery() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if recovered := recover(); recovered != nil {
				slog.Error("gin panic recovered",
					"panic", fmt.Sprint(recovered),
					"method", c.Request.Method,
					"path", c.Request.URL.Path,
					"stack", string(debug.Stack()))
				if !c.Writer.Written() {
					c.AbortWithStatusJSON(http.StatusOK, serveapi.Failure(serveapi.CodeInternalError))
					return
				}
				c.Abort()
			}
		}()
		c.Next()
	}
}

// corsMiddleware handles CORS
func corsMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT, DELETE")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(http.StatusNoContent)
			return
		}

		c.Next()
	}
}
