## Purpose

定义独立轻量服务 `qtuser` 如何以 SQLite 持久保存一对一用户 token，通过标准 Token Introspection、Management API 和 CLI 向 Qtserver 与本机管理员提供稳定且可部署的身份注册表能力。

## ADDED Requirements

### Requirement: qtuser 使用单一二进制提供服务与管理 CLI

`qtuser` SHALL 以单一可执行文件提供 `qtuser serve` 前台服务和 `qtuser user ...` 管理命令。`serve` SHALL NOT daemonize，并 SHALL 支持由专用非 root OS 账户运行；收到 SIGINT 或 SIGTERM 时 SHALL 停止接受新请求、关闭数据库并退出。管理 CLI SHALL 通过 Management API 操作服务，SHALL NOT 直接打开或修改 SQLite 文件。

#### Scenario: 由 systemd 启动服务

- **WHEN** systemd 执行 `qtuser serve`
- **THEN** unit SHALL 使用专用非 root OS 账户启动进程
- **AND** 进程 SHALL 保持前台运行并将普通日志写入 stdout 或 stderr

#### Scenario: CLI 创建用户

- **WHEN** 管理员执行 `qtuser user create alice`
- **THEN** CLI SHALL 通过 Management API 创建用户
- **AND** SHALL NOT 直接写入 `qtuser.db`

### Requirement: 配置与数据库位于安装目录

`qtuser` SHALL 以解析符号链接后的可执行文件所在目录作为安装目录，默认从该目录读取固定名称 `qtuser_config.toml`，并将唯一 SQLite 主数据库保存在该目录内。相对路径 SHALL 以安装目录为基准，SHALL NOT 因进程当前工作目录不同而改变。可执行文件、`qtuser_config.toml` 和 `qtuser.db` SHALL 是三个核心持久文件；SQLite MAY 在同一目录创建和维护 `-wal`、`-shm`、`-journal` 或其他 driver 所需辅助文件。服务 SHALL NOT 在安装目录之外创建数据、PID、cache 或日志文件。整个安装目录 SHALL 被视为同一可信边界，并 SHALL 允许运行服务的专用非 root OS 账户维护主数据库及辅助文件。

#### Scenario: 从其他工作目录启动

- **WHEN** `/opt/qtuser/qtuser` 从任意 working directory 执行 `serve`
- **THEN** 服务 SHALL 读取 `/opt/qtuser/qtuser_config.toml`
- **AND** SHALL 使用 `/opt/qtuser/qtuser.db`

#### Scenario: 通过符号链接启动

- **WHEN** PATH 中的符号链接指向 `/opt/qtuser/qtuser`
- **THEN** 安装目录 SHALL 是 `/opt/qtuser` 而不是符号链接所在目录

#### Scenario: WAL 创建辅助文件

- **WHEN** SQLite 在 WAL mode 运行并创建 `qtuser.db-wal` 或 `qtuser.db-shm`
- **THEN** 辅助文件 SHALL 位于 `qtuser.db` 所在的安装目录
- **AND** 服务 SHALL NOT 因目录不再只有三个物理文件而将其判定为异常

### Requirement: 配置文件完整显式且严格校验

发行的 `qtuser_config.toml` SHALL 写出当前版本支持的全部配置项及默认值，并为每项说明用途、单位或允许值。服务 SHALL 拒绝缺失字段、未知字段、类型错误、无效枚举和相互冲突的配置；涉及已启用能力的空凭据 SHALL 使启动失败。服务 SHALL NOT 在启动时自动生成、补写或覆盖配置文件。

#### Scenario: 默认值没有被修改

- **WHEN** 运维使用发行配置且保留某项默认值
- **THEN** 该配置项及其实际默认值 SHALL 仍在 `qtuser_config.toml` 中可见

#### Scenario: 升级后缺少新增字段

- **WHEN** 新版本读取未包含该版本全部字段的旧配置
- **THEN** `qtuser serve` SHALL 以非零状态拒绝启动并指出缺失字段

#### Scenario: 配置包含拼写错误字段

- **WHEN** 配置包含未知字段
- **THEN** `qtuser serve` SHALL 以非零状态拒绝启动

### Requirement: 启动时初始化并校验 SQLite

`qtuser serve` SHALL 在接受 HTTP 请求前完成配置校验、安装目录可写性检查、SQLite 打开和 schema 校验。`qtuser.db` 不存在时 SHALL 自动创建数据库与当前 schema；受支持的旧 schema SHALL 在事务中迁移；损坏数据库、迁移失败、未知的新 schema、目录不可写或监听端口绑定失败 SHALL 使进程以非零状态拒绝启动。

#### Scenario: 第一次启动

- **WHEN** 完整有效配置存在但 `qtuser.db` 不存在
- **THEN** `serve` SHALL 自动创建数据库和用户表后开始监听

#### Scenario: 数据库 schema 比程序更新

- **WHEN** 数据库 schema version 高于当前二进制支持的版本
- **THEN** `serve` SHALL 拒绝启动且 SHALL NOT 降级或覆盖数据库

#### Scenario: 迁移失败

- **WHEN** 旧 schema 的事务化迁移失败
- **THEN** `serve` SHALL 回滚迁移并以非零状态退出

### Requirement: 运行期 SQLite 故障按可恢复性处理

`qtuser` SHALL 将 SQLite constraint、not found 等可识别业务结果映射为对应 Management API 业务响应，SHALL NOT 因此退出。SQLite busy 或 locked SHALL 返回 HTTP 503 且进程 SHALL 继续运行。其他数据库读取、写入、损坏或 I/O 故障 SHALL 在尚可响应时返回 HTTP 503，随后停止接受新请求、完成有界 graceful shutdown 并以非零状态退出，由进程管理器决定是否重启。

#### Scenario: SQLite 暂时 busy

- **WHEN** introspection 或 Management API 遇到 SQLite busy 或 locked
- **THEN** 当前请求 SHALL 返回 HTTP 503
- **AND** `qtuser` SHALL 继续运行并接受后续请求

#### Scenario: 数据库损坏

- **WHEN** 请求发现 SQLite 数据库损坏或发生非 busy/locked 的底层读写错误
- **THEN** 当前请求在尚可响应时 SHALL 返回 HTTP 503
- **AND** `qtuser` SHALL graceful shutdown 后以非零状态退出

#### Scenario: 唯一约束冲突

- **WHEN** create 或 token replacement 命中用户 ID 或 token 唯一约束
- **THEN** Management API SHALL 返回对应 HTTP 409
- **AND** `qtuser` SHALL NOT 退出

### Requirement: 每个用户持有唯一且可读取的单一 token

每条用户记录 SHALL 包含不可修改的 `id`、一个明文 `token`、`created_at` 和 `updated_at`。服务 SHALL 接受匹配 `[A-Za-z0-9][A-Za-z0-9._-]{0,127}` 的输入 ID，并在任何 create、get、token replacement 和 delete 查找前统一转换为 ASCII lowercase；存储和 response 中的 canonical ID SHALL 匹配 `[a-z0-9][a-z0-9._-]{0,127}`。ID 唯一性 SHALL 基于 canonical lowercase 值，因此不同大小写 SHALL 表示同一用户。`token` SHALL 全局唯一且为 canonical lowercase UUID v4。创建用户未提供 token 时，服务 SHALL 使用安全随机源生成 UUID v4；显式提供 token 时 SHALL 按原值保存合法 canonical UUID v4，并拒绝其他格式。时间 SHALL 使用 UTC RFC 3339 表示。

服务 SHALL 允许查询和列表接口返回完整明文 token。第一版 SHALL NOT 提供多 token、token hash、过期时间、enabled 状态、scope、token 历史或一次性展示行为。

#### Scenario: 自动生成 token

- **WHEN** 创建 `Alice` 时没有提供 token
- **THEN** 服务 SHALL 为 `alice` 生成并返回唯一的 canonical lowercase UUID v4

#### Scenario: 大小写不同的重复用户

- **WHEN** 用户 `alice` 已存在且调用方尝试创建 `ALICE`
- **THEN** 服务 SHALL 返回 HTTP 409

#### Scenario: 使用不同大小写查询

- **WHEN** 用户 `alice` 已存在且调用方查询 `/api/v1/users/Alice`
- **THEN** 服务 SHALL 返回 canonical ID 为 `alice` 的同一条用户记录

#### Scenario: 使用调用方 token

- **WHEN** 创建 `alice` 时提供 `3d797212-75fe-46fb-8707-97bd6896e4c1`
- **THEN** 服务 SHALL 原样保存并返回该 token

#### Scenario: token 已被占用

- **WHEN** 创建或更新用户时提供已属于另一用户的 token
- **THEN** 服务 SHALL 返回 409 Conflict

#### Scenario: 用户 ID 不合法

- **WHEN** 创建用户时 `id` 包含 `/`、空白、Unicode 或以 `.` 开头
- **THEN** 服务 SHALL 返回 400 Bad Request

### Requirement: introspection endpoint 遵循 RFC 7662 请求契约

`POST /oauth2/introspect` SHALL 接受 `application/x-www-form-urlencoded` body 中的必填 `token` 和可选 `token_type_hint`。服务 SHALL 接受并忽略 `token_type_hint=access_token`。Endpoint SHALL 通过 OAuth `client_secret_basic` 验证调用方，固定接受内置 `client_id="qtserver"` 和 `client_secret="qtserver-introspection"`。这组值 SHALL NOT 出现在 `qtuser_config.toml` 中，第一版 SHALL NOT 允许配置或轮换它们，也 SHALL NOT 建立 OAuth clients 表。内置值是公开的协议标识，SHALL NOT 被视为安全边界。

缺少或错误的 endpoint client credentials SHALL 返回 HTTP 401、`WWW-Authenticate: Basic` 和 OAuth `invalid_client` error；缺少 `token` SHALL 返回 HTTP 400 `invalid_request`。

#### Scenario: 标准 introspection 请求

- **WHEN** Qtserver 使用正确 HTTP Basic credentials 发送 form body `token=<uuid>&token_type_hint=access_token`
- **THEN** `qtuser` SHALL 处理该 token 查询

#### Scenario: 内置 client secret 不匹配

- **WHEN** introspection 请求使用错误的 client secret
- **THEN** endpoint SHALL 返回 HTTP 401 和 `invalid_client`

#### Scenario: 配置文件尝试改写 client identity

- **WHEN** `qtuser_config.toml` 包含 introspection client ID 或 client secret 字段
- **THEN** 严格配置校验 SHALL 将该字段视为未知字段并拒绝启动

#### Scenario: 请求缺少 token

- **WHEN** 已认证 introspection 请求没有 `token` form 字段
- **THEN** endpoint SHALL 返回 HTTP 400 和 `invalid_request`

### Requirement: introspection 使用 active 和 sub 表达 token 状态

匹配现有用户 token 时，`POST /oauth2/introspect` SHALL 返回 HTTP 200 JSON `active=true`、该用户的 `sub` 和 `token_type="Bearer"`。未知、格式错误、已被替换或已随用户删除的 token SHALL 返回 HTTP 200 且 response body 只包含 `{"active":false}`。SQLite 无法完成查询时 SHALL 返回 HTTP 503，SHALL NOT 把依赖故障伪装成 inactive token。

第一版 SHALL NOT 提供 `/authorize`、`/oauth2/token`、`/userinfo`、OIDC discovery、JWT 或登录流程。

#### Scenario: token 有效

- **WHEN** token 属于用户 `alice`
- **THEN** endpoint SHALL 返回 `{"active":true,"sub":"alice","token_type":"Bearer"}`

#### Scenario: token 不存在

- **WHEN** token 不属于任何用户或不是 UUID v4
- **THEN** endpoint SHALL 返回 HTTP 200 和 `{"active":false}`

#### Scenario: SQLite 查询失败

- **WHEN** introspection 无法完成 SQLite 查询
- **THEN** endpoint SHALL 返回 HTTP 503
- **AND** SHALL NOT 返回 `active=false`

### Requirement: Management API 使用明确的本地与远程边界

HTTP 服务 SHALL 默认绑定 `127.0.0.1:10020`，并 SHALL 允许通过配置改为任意合法监听地址。配置为非 loopback 地址后，introspection SHALL 允许跨机器直接通过 HTTP 调用。无论 introspection 监听地址如何配置，`/api/v1/users` Management API SHALL 默认只接受 TCP peer address 为 loopback 的请求，且 SHALL NOT 信任 `Forwarded` 或 `X-Forwarded-For` 改写该判断。`management.allow_remote=true` 时，远程请求 SHALL 额外要求配置的静态 management bearer token；缺失或错误 token SHALL 返回 401。`allow_remote=false` 时远程请求 SHALL 返回 403。

#### Scenario: 默认本机管理

- **WHEN** 本机 CLI 从 `127.0.0.1` 调用 Management API 且远程管理关闭
- **THEN** 请求 SHALL 被允许且 SHALL NOT 要求 management token

#### Scenario: introspection 对外但管理仍关闭

- **WHEN** 服务监听非 loopback 地址、`management.allow_remote=false` 且远程主机调用 `/api/v1/users`
- **THEN** 请求 SHALL 返回 HTTP 403

#### Scenario: 远程 Qtserver 直接使用 HTTP

- **WHEN** 服务配置监听非 loopback 地址且远程 Qtserver 通过 HTTP 调用 `/oauth2/introspect`
- **THEN** `qtuser` SHALL 处理该请求
- **AND** SHALL NOT 要求部署 HTTPS 反向代理

#### Scenario: 启用远程管理

- **WHEN** `management.allow_remote=true` 且远程请求携带正确 management bearer token
- **THEN** Management API SHALL 处理该请求

### Requirement: Management API 提供用户 CRUD

Management API SHALL 提供以下版本化路由：

- `POST /api/v1/users`：只接受 JSON `{"id":"<id>"}` 或 `{"id":"<id>","token":"<uuid>"}` 创建用户，成功返回 HTTP 201 和完整用户记录；重复 ID 或 token 返回 409。
- `GET /api/v1/users`：返回 HTTP 200 和 `{"users":[<user-record>...]}`，包括全部明文 token，并按 canonical ID 的 bytewise ascending order 排序；第一版不分页。
- `GET /api/v1/users/{id}`：返回 HTTP 200 和完整用户记录；用户不存在返回 404。
- `PUT /api/v1/users/{id}/token`：只接受空 JSON object `{}` 自动生成 token，或 `{"token":"<uuid>"}` 使用指定 token；空 body、其他字段或其他 JSON shape 返回 400；成功返回 HTTP 200 和更新后的完整记录；用户不存在返回 404。
- `DELETE /api/v1/users/{id}`：删除用户及其 token，成功返回 HTTP 204；用户不存在返回 404。

完整用户记录的 JSON shape SHALL 精确包含 string 字段 `id`、`token`、`created_at` 和 `updated_at`，不使用外层 `data` envelope。用户 ID SHALL 不可修改。token 替换或用户删除提交成功后，旧 token 的后续 introspection SHALL 立即返回 `active=false`。

删除用户 SHALL 只删除 qtuser SQLite 中的用户记录和 token，SHALL NOT 请求 Qtserver 或操作任何外部文件、目录、session、grant 或业务资源。服务 SHALL NOT 保存 tombstone 或删除历史；删除后 SHALL 允许重新创建同一 canonical ID，并把它作为相同 lowercase `sub` 返回。

#### Scenario: 创建重复用户

- **WHEN** `POST /api/v1/users` 提交已经存在的 `id`
- **THEN** 服务 SHALL 返回 HTTP 409

#### Scenario: 自动替换 token

- **WHEN** `PUT /api/v1/users/alice/token` 提交 `{}`
- **THEN** 服务 SHALL 生成新 UUID v4、返回更新记录并使旧 token 失效

#### Scenario: token replacement 使用空 body

- **WHEN** `PUT /api/v1/users/alice/token` 没有 request body
- **THEN** 服务 SHALL 返回 HTTP 400 Problem Details

#### Scenario: 列出用户

- **WHEN** `GET /api/v1/users` 成功
- **THEN** response SHALL 使用 `users` array envelope
- **AND** 每个元素 SHALL 包含 `id`、明文 `token`、`created_at` 和 `updated_at`
- **AND** 元素 SHALL 按 canonical ID bytewise ascending order 排序

#### Scenario: 删除用户不操作外部资源

- **WHEN** `DELETE /api/v1/users/alice` 成功
- **THEN** 服务 SHALL 只删除本地用户记录和 token
- **AND** SHALL NOT 调用 Qtserver 或操作 Qtserver 业务资源

#### Scenario: 删除后重新创建同名用户

- **WHEN** 用户 `alice` 已删除且调用方再次创建 `Alice`
- **THEN** 服务 SHALL 创建 canonical ID 为 `alice` 的新记录
- **AND** introspection SHALL 为新 token 返回 `sub="alice"`

#### Scenario: 删除不存在的用户

- **WHEN** `DELETE /api/v1/users/nobody` 找不到用户
- **THEN** 服务 SHALL 返回 HTTP 404

### Requirement: Management API 错误使用 Problem Details

Management API 的非成功业务响应 SHALL 使用 RFC 9457 `application/problem+json`，至少包含稳定 URN `type`、`title` 和 HTTP `status`，MAY 包含不泄漏凭据的 `detail`。Introspection endpoint SHALL 继续使用 OAuth error response，SHALL NOT 使用 Problem Details；`active=false` SHALL 是成功状态而不是错误。

#### Scenario: token 冲突

- **WHEN** Management API 检测到 token 已被其他用户占用
- **THEN** 服务 SHALL 返回 HTTP 409、`application/problem+json` 和稳定的 token-conflict problem type

### Requirement: CLI 命令与 Management API 一一对应

`qtuser` SHALL 提供 `user create <id> [--token <uuid>]`、`user get <id>`、`user list`、`user token reset <id>`、`user token set <id> <uuid>` 和 `user delete <id>`。成功命令 SHALL 输出足以取得结果和明文 token 的人类可读内容；HTTP、验证或服务错误 SHALL 写入 stderr 并返回非零退出码。

#### Scenario: reset 用户 token

- **WHEN** 管理员执行 `qtuser user token reset alice`
- **THEN** CLI SHALL 调用 token 替换 API 且不提供 token
- **AND** SHALL 输出新 token

#### Scenario: CLI 使用大写用户 ID

- **WHEN** 管理员执行 `qtuser user get Alice`
- **THEN** CLI SHALL 查询 canonical ID `alice`
- **AND** 输出 SHALL 使用 `alice`

#### Scenario: CLI 请求失败

- **WHEN** Management API 返回非成功状态
- **THEN** CLI SHALL 返回非零退出码并输出可读错误

### Requirement: 凭据不得进入日志

`qtuser` SHALL NOT 在 access log、普通日志、错误日志或 Problem Details 中记录或回显 introspection token、Management API 返回的用户 token、HTTP Authorization、内置 introspection client credential 或 management token。显式用户查询和成功 CRUD response 返回 token SHALL 是该规则的唯一例外。配置诊断输出 SHALL 对全部可配置 secret 和 token 做脱敏。

#### Scenario: introspection 查询失败

- **WHEN** introspection 请求触发 SQLite 或协议错误
- **THEN** 日志 SHALL NOT 包含被查询 token 或 Authorization header
