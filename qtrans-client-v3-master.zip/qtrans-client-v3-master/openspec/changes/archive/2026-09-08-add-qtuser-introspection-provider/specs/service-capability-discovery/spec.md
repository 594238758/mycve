## MODIFIED Requirements

### Requirement: PostgreSQL 和 Redis 是 fatal dependencies

Qtserver SHALL 在启动时成功连接 PostgreSQL、校验受支持的 schema version，并成功执行 Redis PING；任一失败 SHALL 拒绝启动。`identity.mode="oauth2-introspection"` 时，Qtserver SHALL 在开始监听前使用内置 client authentication 和一个进程内生成的 UUID v4 probe token 调用 introspection endpoint，并确认 response 符合 RFC 7662；连接、TLS、timeout、内置 client authentication、HTTP status 或 response protocol 失败 SHALL 拒绝启动。服务 SHALL NOT 提供 Redis、PostgreSQL 或已启用 introspection provider 的启动降级，也 SHALL NOT 在 fatal dependency 恢复后继续使用同一进程。

#### Scenario: PostgreSQL 启动时不可用

- **WHEN** Qtserver 无法连接 PostgreSQL 或 schema version 不受支持
- **THEN** Qtserver SHALL 以非零状态拒绝启动

#### Scenario: Redis 启动时不可用

- **WHEN** Qtserver 无法完成 Redis PING
- **THEN** Qtserver SHALL 以非零状态拒绝启动

#### Scenario: introspection provider 启动时不可用

- **WHEN** 启用 `oauth2-introspection` 且 endpoint 无法完成 authenticated probe
- **THEN** Qtserver SHALL 以非零状态拒绝启动

#### Scenario: introspection probe 返回标准 active 结果

- **WHEN** probe 返回 HTTP 200 和结构合法的 boolean `active`
- **THEN** Qtserver SHALL 将 endpoint 判定为可用

### Requirement: fatal dependency 故障触发 graceful shutdown

Qtserver SHALL 每五秒检查 PostgreSQL、Redis 和已启用 `oauth2-introspection` provider 的健康状态。健康检查或业务命令发现 connection refused、连接断开、TLS、timeout、内置 client authentication、HTTP status 或协议错误时，服务 SHALL 在第一次故障时立即开始 shutdown，SHALL NOT 等待连续多次失败或重试阈值。服务 SHALL 停止接受新连接，给予现有请求最多 30 秒完成，然后以非零状态退出。直接观察到 introspection provider 故障且仍可响应的认证请求 SHALL 返回 HTTP 503 `DEPENDENCY_UNAVAILABLE`；其他尚可响应且未完成的业务请求 SHALL 返回 HTTP 500 `INTERNAL_ERROR`，而不是降级结果。

#### Scenario: 运行期 Redis 断开

- **WHEN** Redis 健康检查或业务命令检测到连接级故障
- **THEN** Qtserver SHALL 触发 graceful shutdown
- **AND** SHALL NOT 等待 Redis 恢复后继续服务

#### Scenario: 运行期 PostgreSQL 断开

- **WHEN** PostgreSQL 健康检查或业务命令检测到连接级故障
- **THEN** Qtserver SHALL 触发同一 graceful shutdown 流程

#### Scenario: 运行期 introspection provider 故障

- **WHEN** 周期 probe 或业务 introspection 检测到 provider 故障
- **THEN** Qtserver SHALL 触发同一 graceful shutdown 流程
- **AND** SHALL NOT 等待第二次健康检查确认
- **AND** SHALL NOT 等待 provider 恢复后继续服务

#### Scenario: 正常 signal 停止

- **WHEN** Qtserver 收到 SIGINT 或 SIGTERM 且没有 fatal dependency
- **THEN** graceful shutdown 完成后的进程退出码 SHALL 为 0

### Requirement: 仅连接级 PostgreSQL 和 Redis 故障终止服务

锁冲突、CAS miss、key 不存在、唯一约束和查询无结果 SHALL NOT 被判定为依赖故障。既有 `auth` mode 的身份服务超时或拒绝、任意 provider 返回无效 token、单个 principal 目录错误、单次文件 I/O、磁盘满和客户端错误 SHALL 是请求级错误且 SHALL NOT 终止 Qtserver。只有启用 `oauth2-introspection` 时，该 provider 的连接、TLS、timeout、内置 client authentication、HTTP status 或协议故障 SHALL 按 fatal dependency 处理。

#### Scenario: 上传磁盘空间不足

- **WHEN** 单次 PATCH 因磁盘空间不足失败
- **THEN** 请求 SHALL 返回 507
- **AND** Qtserver SHALL 继续处理其他请求

#### Scenario: namespace lock 冲突

- **WHEN** 请求未获取同 principal namespace lock
- **THEN** 请求 SHALL 返回 409 `NAMESPACE_BUSY`
- **AND** Qtserver SHALL NOT 退出

#### Scenario: introspection 返回 inactive

- **WHEN** `oauth2-introspection` 返回结构合法的 `active=false`
- **THEN** 当前请求 SHALL 作为无效 token 失败
- **AND** Qtserver SHALL NOT 退出

#### Scenario: 既有 auth 服务超时

- **WHEN** `identity.mode="auth"` 的既有 `/userinfo` 请求超时
- **THEN** 请求 SHALL 按既有行为失败
- **AND** Qtserver SHALL NOT 因本变更退出
