## 1. qtuser 模块与配置

- [x] 1.1 新增顶层 `qtuser/` Go module、单一 `qtuser` 入口和 `serve`、`user`、`version` Cobra 命令骨架，引入无需 CGO 的 SQLite driver
- [x] 1.2 实现解析符号链接后的安装目录定位，让配置、SQLite 主数据库和辅助文件位于安装目录且不依赖 working directory，并禁止 qtuser 在目录外创建运行数据
- [x] 1.3 实现 `qtuser_config.toml` 的完整严格 schema、缺失/未知字段检测、字段关联校验和脱敏配置输出
- [x] 1.4 提供包含全部支持字段与注释的发行版 `qtuser_config.toml`，固定默认 `127.0.0.1:10020` 和同目录数据库路径

## 2. SQLite 用户注册表

- [x] 2.1 实现 SQLite 打开、同安装目录 WAL/SHM 辅助文件、`PRAGMA user_version`、首次建表、版本校验和事务化 migration 框架
- [x] 2.2 实现安装目录可写性、数据库完整性和启动查询检查，让损坏、未知新 schema 或迁移失败阻止启动
- [x] 2.3 实现 users store 的 create/get/list/replace-token/delete，并区分 constraint/not found、busy/locked 和其他 fatal SQLite 故障
- [x] 2.4 实现用户 ID ASCII lowercase canonicalization、case-insensitive 唯一性和查询、canonical UUID v4 校验、安全随机 UUID v4 生成以及 UTC RFC 3339 时间字段

## 3. qtuser HTTP 服务

- [x] 3.1 实现前台 HTTP server、固定路由注册、stdout/stderr 结构化日志、signal shutdown 以及 fatal SQLite error shutdown
- [x] 3.2 实现 RFC 7662 `POST /oauth2/introspect` 的 form 解析、固定 `qtserver` / `qtserver-introspection` 的 `client_secret_basic` 验证、OAuth error 和 active/sub response，且不增加 client 配置或 clients 表
- [x] 3.3 实现 Management API 的 TCP peer loopback 限制、可选远程 bearer 管理认证，并禁止 proxy header 绕过本地判断
- [x] 3.4 实现 `/api/v1/users` create/list/get、token replace 和 delete 路由，固定四字段 user record、按 canonical ID 升序的 `users` envelope 及 `{}`/指定 token replacement body
- [x] 3.5 固定 delete 只移除本地 row/token、允许同 ID 重建且不调用 Qtserver 或保存 tombstone
- [x] 3.6 实现 RFC 9457 Management API Problem Details，确保 empty body、inactive token、SQLite busy 503 和 fatal SQLite 503 使用约定的不同语义
- [x] 3.7 统一 HTTP 和日志敏感字段处理，禁止记录 Authorization、introspection form token、CRUD body、用户 token、内置 client credential 和 management token

## 4. qtuser 管理 CLI 与部署材料

- [x] 4.1 实现读取 `client.base_url` 的 Management API client，并让远程调用按配置携带 management bearer token
- [x] 4.2 实现 `user create`、`get`、`list`、`token reset`、`token set` 和 `delete` 命令的 lowercase ID、人类可读稳定排序输出与非零错误退出
- [x] 4.3 编写 qtuser 配置、HTTP API、CLI、核心持久文件、SQLite 辅助文件、完整安装目录可信边界、明文 token 边界以及跨机器直接 HTTP 调用方式
- [x] 4.4 提供以 `/opt/qtuser` 为安装目录、专用非 root `qtuser` 账户、`Type=simple` 和 `Restart=on-failure` 为基线的 systemd unit 示例，并记录目录写权限要求

## 5. Qtserver 新 provider 配置与协议

- [x] 5.1 在既有 `identity.mode` 增加 `oauth2-introspection`，只新增 `introspection_endpoint` 字段与 mode 专属校验，保持 `auth`、`fake`、`off` 校验不变
- [x] 5.2 实现 RFC 7662 identity client，包括 form POST、`token_type_hint`、内置 `qtserver` / `qtserver-introspection` 的 `client_secret_basic`、timeout、redirect 拒绝和严格 active/sub 解析，不增加 client credential 配置
- [x] 5.3 为新 mode 实现严格 RFC 6750 Bearer header 解析，并保持既有三个 mode 的宽松解析路径不变
- [x] 5.4 将 active token 转换为原样 `sub` principal、将 inactive token 转换为 401，并忽略 scope/role 等额外 claims
- [x] 5.5 确保新 provider 不接入 Redis 或进程内 token cache，现有 `auth` userinfo cache 行为保持不变
- [x] 5.6 收敛 provider 错误与日志字段，禁止记录 token、内置 client credential、form body 和完整 introspection response body

## 6. Qtserver fatal dependency 生命周期

- [x] 6.1 在 Qtserver 开始监听前使用内置 client authentication 执行 UUID v4 introspection probe，让 endpoint、authentication、HTTP status 或协议故障阻止启动
- [x] 6.2 将新 provider probe 加入现有五秒 fatal dependency monitor，在第一次故障时立即复用最多 30 秒 graceful shutdown 流程，不增加连续失败阈值
- [x] 6.3 让业务 introspection provider 故障返回 503 `DEPENDENCY_UNAVAILABLE` 并报告 fatal dependency，同时确保 `active=false` 只返回 401 且不触发退出
- [x] 6.4 检查 `auth`、`fake`、`off` 的启动、运行期和 anonymous 路径，确保没有被纳入新 provider 的严格解析或 fatal lifecycle

## 7. Qtserver 文档与部署配置

- [x] 7.1 更新 `qtserver/docs/qtserver-apis.md`，记录新 mode 的严格 Bearer、active/inactive 和 provider 503 行为
- [x] 7.2 更新配置权威 `qtserver/docs/config.md`，记录 `oauth2-introspection` 的 endpoint-only 配置、内置 client identity、允许本机或跨机器 HTTP(S) endpoint、无缓存和既有 mode 兼容性
- [x] 7.3 更新 `qtserver/deploy/qtserver_config_default.toml`，完整写出 `introspection_endpoint` 及注释，不增加 client credential 字段，同时保持现有部署默认 mode 不变
- [x] 7.4 更新 Qtserver 部署说明，记录 qtuser systemd 顺序、startup probe 和跨机器直接 HTTP endpoint 配置

## 8. 编译验证

- [x] 8.1 格式化新增和修改的 Go 源码并编译 `qtuser`
- [x] 8.2 编译 `qtserver`，确认新增 mode、配置和 fatal dependency 集成通过编译
