## Context

Qtserver 当前在 `IdentityClient` 后面保留 `auth`、`fake`、`off` 三种 mode：`auth` 调用私有 `/userinfo` 并兼容多种 response shape，`fake` 使用配置中的静态 map，`off` 禁止普通 principal。用户文件空间和资源归属已经只消费 principal ID，因此新增标准 token introspection 不需要改变业务授权模型。

过去曾把 SQLite 用户表和管理路由直接放在 Qtserver 中；该实现已经删除。新方向保留其简单 CRUD 思路，但把 token 注册表做成独立进程 `qtuser`，Qtserver 只通过标准 RFC 7662 endpoint 依赖它。

## Goals / Non-Goals

**Goals:**

- 形成可以独立部署、由 systemd 管理且只有一个 SQLite 主数据库的轻量 token registry。
- 让 Qtserver 新 provider 同时兼容 `qtuser`、Keycloak 和其他提供 RFC 7662 introspection 的服务。
- 将 token 有效性与用户身份交给 provider，将文件与传输资源授权留在 Qtserver。
- 新增能力时保持 `auth`、`fake`、`off` 的实现、配置与兼容行为不变。

**Non-Goals:**

- 不把 `qtuser` 建设成 OAuth Authorization Server 或 OpenID Provider。
- 不实现密码、登录页面、authorization code、token endpoint、refresh token、JWT、OIDC discovery 或 JWKS。
- 不实现权限表、scope、role、group、ACL、RBAC 或外部 policy decision。
- 不为用户提供多个 token，也不增加过期、禁用、历史或审计模型。
- 不在第一版设计 token introspection cache 或撤销传播窗口。
- 不管理 Qtserver 文件、目录、session、grant 或其他业务资源，也不在用户删除时产生外部副作用。

## Decisions

### 1. qtuser 是独立 Go module 和单一二进制

在仓库顶层新增 `qtuser/` Go module，输出一个 `qtuser` 二进制。命令层沿用仓库现有 Cobra 风格；HTTP 服务优先使用 Go 标准库，避免为了少量固定路由引入完整 Web framework。SQLite 采用无需 CGO 的 Go driver，使安装目录中的单一二进制可以直接部署。

`qtuser serve` 是 systemd `Type=simple` 的前台进程，由专用非 root `qtuser` OS 账户运行；不 fork、不写 PID 文件、不实现自己的 supervisor。SIGINT/SIGTERM 使用有界 graceful shutdown，日志交给 stdout/stderr 和 journald。

备选方案是把 CRUD 重新放回 Qtserver；它会再次把身份注册表、文件传输服务和 SQLite 生命周期耦合，且无法让其他 RFC 7662 consumer 复用，因此不采用。

### 2. 安装目录是完整运行单元

默认布局固定为：

```text
/opt/qtuser/
├── qtuser
├── qtuser_config.toml
└── qtuser.db
```

其中 `qtuser`、`qtuser_config.toml` 和 `qtuser.db` 是核心持久文件，不代表运行时目录永远只有三个物理文件。SQLite MAY 在同一目录创建 `qtuser.db-wal`、`qtuser.db-shm`、`qtuser.db-journal` 或 driver 所需的临时辅助文件；这些文件属于数据库实现细节和同一可信边界。qtuser 不在安装目录之外创建数据、PID、cache 或日志文件。

安装目录取解析符号链接后的 executable directory，不依赖 working directory。服务不会在启动时生成配置；发行和部署必须提供完整 `qtuser_config.toml`。数据库不存在时由 `serve` 创建。安装目录必须允许专用 `qtuser` OS 账户创建和维护主数据库及 SQLite 辅助文件。

第一版配置 schema 保持窄而完整：

```toml
[server]
host = "127.0.0.1"
port = 10020

[database]
path = "qtuser.db"

[management]
allow_remote = false
token = ""

[client]
base_url = "http://127.0.0.1:10020"

[log]
level = "info"
```

这些是全部支持字段，而不是可省略字段示例。`database.path` 必须解析到安装目录内部；`client.base_url` 只供同一二进制的 CLI 连接 Management API。`management.token` 在远程管理关闭时仍以空字符串显式出现，启用远程管理时必须非空。未知或缺失字段都拒绝启动，使配置文件同时充当运行参数的完整清单。

备选方案是按 Linux FHS 把 binary、config 和 variable data 分到 `/usr/bin`、`/etc`、`/var/lib`；它更适合发行版包，但不符合本项目要求的自包含安装方式，因此不采用。

### 3. SQLite 只保存一张 users 表

逻辑 schema 为：

```sql
CREATE TABLE users (
    id         TEXT PRIMARY KEY,
    token      TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
```

Schema version 使用 SQLite `PRAGMA user_version`，不增加业务表。启动顺序是：严格解析配置、检查路径、打开 SQLite、设置 pragmas、创建或事务化迁移 schema、完成数据库基本查询、绑定 listener。数据库使用 WAL 以允许 introspection read 与单个 management write 共存；对应 `-wal` 和 `-shm` 文件保留在安装目录内，由 SQLite 管理。时间以 UTC RFC 3339 写入。

运行期错误分为三类：constraint/not found 是业务结果；`SQLITE_BUSY`/`SQLITE_LOCKED` 返回 503 后继续运行；其他 SQLite read/write 错误、corruption 和 I/O error 在尽量完成当前 503 response 后报告进程 fatal，触发有界 graceful shutdown 和非零退出。这样暂时锁争用不会造成重启，而 systemd 可以处理无法通过重试恢复的数据库故障。

token 明文是明确的产品能力，因为管理员需要随时 get/list。自动 token 使用加密安全随机源生成 canonical lowercase UUID v4；显式 token 也必须已经是 canonical lowercase UUID v4，从而避免“原样保存”和“统一规范化”冲突。

所有用户 ID 输入先验证 ASCII 字符集合，再使用 ASCII lowercase 形成 canonical ID；SQLite 只存 canonical lowercase，唯一约束和查询都基于该值。`Alice`、`ALICE` 和 `alice` 因而是同一 ID。列表使用 `ORDER BY id` 的 bytewise ascending 顺序，保证 API 与 CLI 稳定输出。

旧实现使用 email 加自增整数 ID；新服务不承担邮箱语义，直接以受限 canonical lowercase 字符串作为 `sub`，避免额外内部 ID 和 display name。

### 4. introspection 是标准集成面，不宣称完整 OAuth

`POST /oauth2/introspect` 遵循 [RFC 7662](https://www.rfc-editor.org/rfc/rfc7662)：form POST、endpoint client authentication、`active` 和可选 claims。第一版通过 RFC 6749 `client_secret_basic` 使用双方程序内置的稳定协议常量，不建立 clients 表，也不提供对应配置项：

```text
client_id     = qtserver
client_secret = qtserver-introspection
```

这两个值公开、不可配置且第一版不可轮换。它们的用途是使 endpoint 只接受预期的 HTTP Basic request shape，并让 Qtserver 与 qtuser 无需额外凭据配置即可互操作；因为值编译在程序中，它们不是鉴别可信调用方的安全边界。用户 bearer token、Management API 的远程 bearer token 和网络边界仍按各自契约处理。缺少或不匹配的 Basic credentials 仍按 OAuth `invalid_client` 拒绝。

有效 token 返回：

```json
{"active":true,"sub":"alice","token_type":"Bearer"}
```

未知 token 返回：

```json
{"active":false}
```

RFC 7662 不规定 access token 的内部格式，因此 UUID v4 与标准兼容。无效 token 返回 200/`active=false`，而数据库故障返回 503；consumer 因而可以区分凭据失效和 provider 故障。

不提供 `/oauth2/token`、`/authorize` 或 `/userinfo`。这使 `qtuser` 是 token registry/introspection provider，而不是 OAuth 登录系统。

### 5. Management API 是版本化 CRUD，错误使用标准 Problem Details

Management API 使用 `/api/v1/users` 路由族。单项资源直接以用户 ID 作为 path segment，因此用户 ID 限制为 `[A-Za-z0-9][A-Za-z0-9._-]{0,127}`；这同时避免 `/`、percent-decoding 和 SQLite key 的歧义。

CRUD response 总是可以返回完整明文 token。非成功业务 response 使用 [RFC 9457](https://www.rfc-editor.org/rfc/rfc9457) `application/problem+json` 和稳定 `urn:qtuser:problem:*` type；introspection 保持 OAuth error shape，不混用两种错误协议。

单用户 response 直接返回 `id/token/created_at/updated_at` 四个字段；列表固定使用 `{"users":[...]}` envelope。Token replacement 用 `{}` 表示自动生成，用 `{"token":"..."}` 表示指定值；空 body 和未知字段返回 400。显式区分 `{}` 与空 body，避免不同 JSON decoder 行为产生隐式默认值。

Create、path lookup、token replacement 和 delete 共用同一 ID canonicalization。Delete 只删除 users row；不调用 Qtserver，不清理文件或其他业务对象，也不写 tombstone。以后重新创建同一 ID 会再次返回相同 lowercase `sub`；该 `sub` 在 Qtserver 中对应什么资源完全由 Qtserver 决定，qtuser 不参与。

CLI 命令与 HTTP operation 一一对应。CLI 读取同一安装目录配置中的 `client.base_url` 和 `management.token`，只作为 API client，不在服务停止时绕过 API 修改数据库。

### 6. Management API 默认按 TCP peer 限制本机访问

默认 listener 是 `127.0.0.1:10020`。即使为跨机器 Qtserver 把 listener 配置到非 loopback，Management API middleware 仍使用 TCP peer address 拒绝远程请求；不信任 proxy header。`management.allow_remote=true` 才允许远程 peer，并要求静态 management bearer token。本机 peer 不要求该 token，保持日常 CLI 简单。

第一版不内置 TLS。配置监听非 loopback 地址后，跨主机 Qtserver 可以直接通过 HTTP 调用 introspection；启用 `management.allow_remote` 后，管理 CLI 也可以按配置直接通过 HTTP 调用。Qtserver 只校验 endpoint 是绝对 HTTP(S) URL，不根据目标地址、网络拓扑或 scheme 增加 HTTPS 限制。是否额外部署 HTTPS 反向代理由部署方自行决定，不是服务启动或配置校验的前提。

备选方案是管理员账号、RBAC、mTLS 或 Unix socket；它们与单表静态注册表的定位不匹配，暂不采用。

### 7. Qtserver 以最小增量增加第四种 mode

保持现有 `IdentityClient` 和 `identity.mode` 结构，仅增加 `oauth2-introspection` client 与一个平铺 endpoint 字段：

```toml
[identity]
mode = "oauth2-introspection"
introspection_endpoint = "http://127.0.0.1:10020/oauth2/introspect"
```

生产配置模板始终写出这个新字段；当 `auth`、`fake`、`off` 被选择时允许它为空。client identity 使用决策 4 中的内置常量，不进入 Qtserver 配置。这样新增 provider 不需要重命名既有 mode，也不需要先完成一次大规模 identity abstraction 重构。

新 mode 单独执行严格 RFC 6750 Bearer 解析；既有 mode 继续保留当前宽松 header 行为。Provider 以 form POST 和 `client_secret_basic` 调用精确 endpoint、拒绝 redirect，并只接受标准 boolean `active` 与非空 string `sub`。合法额外 claims 被忽略，私有 `code/id/data.id` 不兼容。

这个 endpoint contract 可由 `qtuser`、Keycloak 或其他 RFC 7662 服务实现；Qtserver 配置和 provider 逻辑中不出现 qtuser 专属判断。第三方服务必须配置一个接受内置 `qtserver` / `qtserver-introspection` credentials 的 confidential client；第一版不允许为已有第三方 client 改写这组值。

### 8. 认证与授权保持分离

调用链固定为：

```text
Authorization: Bearer <token>
              │
              ▼
oauth2-introspection provider
              │ active + sub
              ▼
      Principal{ID: sub}
              │
              ▼
Qtserver local file/session/grant authorization
```

Provider 只回答 token 是否 active 以及主体是谁。即使 response 带有 scope、role 或 group，Qtserver 也不把它们解释为文件权限。`sub` 只要求非空，随后遵守现有“完全信任 provider principal ID”契约；`qtuser` 自己施加的 lowercase ID canonicalization 是 provider 侧约束，不扩张为所有 provider 的通用限制。

### 9. 新 provider 不做 token cache

第一版每个普通用户请求都 introspect。这样替换或删除 token 后，下一次请求立即观察到 `active=false`，也避免在尚未确定撤销延迟前复用当前 `auth` mode 的 Redis cache。`auth` 的既有 `userinfo_cache_ttl_seconds` 完全不变。

代价是每次业务请求增加一个本地或网络 HTTP+SQLite read。服务定位和初始规模允许先接受该开销；后续若引入 cache，必须另行规定最大撤销延迟和 provider 故障时的 cache 语义。

### 10. introspection provider 是 Qtserver fatal dependency

选择新 mode 后，Qtserver 在监听前用内置 client authentication 和随机 UUID v4 发起一次 authenticated introspection probe；任何结构合法、包含 boolean `active` 的 HTTP 200 response 都证明网络、内置 client identity、协议与 provider 存储查询路径可用，避免 probe token 极低概率碰撞真实 token时误判故障。

运行期把同一 probe 加入现有五秒 fatal dependency monitor。业务请求或 probe 第一次遇到连接、TLS、timeout、client authentication、非 200 或 malformed response 时立即报告 fatal dependency，不做连续失败计数，复用现有最多 30 秒 graceful shutdown。`active=false` 是正常认证结果，不报告 fatal。

既有 `auth` mode 不加入这个 fatal lifecycle，避免本变更偷偷改变已部署系统行为。

### 11. token 与 secret 在诊断路径中统一脱敏

`qtuser` access log 不记录 Authorization、form body 或用户 CRUD body；业务日志只记录 operation、用户 ID、status 和错误类别。Qtserver provider 错误不保存或打印完整 response body，也不输出内置 Basic credential。配置 dump 对 management token、fake token 和用户 token 统一 redact。

明文 token 只在明确的成功 Management API/CLI get、list、create、set、reset response 中出现；这是管理员主动查询能力而不是日志行为。

## Risks / Trade-offs

- [SQLite 主数据库、辅助文件和明文 token 位于安装目录] → 把整个 `/opt/qtuser` 目录权限视为管理边界，以专用非 root `qtuser` 账户运行；日志仍严格禁止复制 token。
- [完整严格配置使新增字段成为升级步骤] → 每个版本同时发布完整 `qtuser_config.toml`，启动错误明确列出缺失字段，禁止静默使用不可见默认值。
- [每请求 introspection 增加延迟和负载] → 第一版优先保证行为简单和 token 立即失效；缓存另开 change 讨论。
- [内置 client identity 不能鉴别或隔离多种 consumer] → 第一版只服务 Qtserver，明确不把公开常量当作 secret；出现多 consumer 或调用方授权需求后再增加 clients 表或可轮换凭据。
- [远程 HTTP 会明文传输用户 token、公开的内置 Basic credential 或 management token] → 这是允许配置选择的部署权衡；Qtserver 和 qtuser 不强制 HTTPS，部署方按网络边界自行决定是否增加 TLS。
- [provider 短暂故障会使 Qtserver 退出] → 这是明确的强依赖语义，由 systemd 负责重启；未来若需要失败阈值必须另改规格。
- [qtuser ID 规则不接受 Unicode 且不保留原始大小写] → 保持 URL、查询和 CLI 标识简单稳定；需要 display name 时另增字段，而不放宽 canonical lowercase `sub`。
- [删除并重建同一 ID 会再次产生相同 `sub`] → qtuser 只管理凭据且不追踪外部资源；需要永久禁用 ID 时再引入 tombstone，本变更不提供。

## Migration Plan

1. 在独立安装目录部署 `qtuser`、完整 `qtuser_config.toml` 和使用专用非 root `qtuser` 账户的 systemd unit；授予该账户维护安装目录内 SQLite 主数据库及辅助文件所需权限，首次启动自动创建 `qtuser.db`。
2. 使用本机 CLI 创建用户并确认 token 可随时 get/list；以正确和错误 token 分别验证 introspection 的 `active=true/false`。
3. 为 Qtserver 配置 `identity.mode="oauth2-introspection"` 和 endpoint，同步更新配置权威与生产模板后先执行 `qtserver config validate`；使用第三方 provider 时，先令其接受规格固定的内置 client identity。
4. 启动 Qtserver；只有 startup probe 通过后才接受流量。客户端继续使用标准 `Authorization: Bearer <uuid>`，不需要协议迁移。
5. 回滚时把 Qtserver 配置切回原 `auth`、`fake` 或 `off` mode 并恢复对应既有字段；`qtuser.db` 可原样保留，停止 qtuser 不影响旧 mode。
