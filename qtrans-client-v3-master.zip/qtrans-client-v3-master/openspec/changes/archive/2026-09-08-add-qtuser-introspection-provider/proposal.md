## Why

Qtserver 现有 `auth`、`fake`、`off` 已经形成既定行为，但 `auth` 依赖私有 `/userinfo` 协议，无法直接复用开源生态中的标准 token 验证接口。需要新增一个独立、轻量、可自行管理的 `qtuser` 服务，并让 Qtserver 通过 RFC 7662 Token Introspection 接入它，同时避免重构或替换现有三种模式。

## What Changes

- 新增独立程序 `qtuser`：以 SQLite 保存稳定的 `user → token` 一对一映射，并以单一二进制提供前台服务和管理 CLI。
- 新增 RFC 7662-compatible `POST /oauth2/introspect`，使用双方程序内置的稳定 HTTP Basic client identity 验证 Qtserver，使用 `active` 与 `sub` 返回 token 对应身份；该内置凭据只用于协议标识，不作为安全边界。
- 新增 `/api/v1/users` Management API 及对应 `qtuser user ...` CLI，支持创建、查询、列出、替换 token 和删除用户；CLI 只调用 API，不直接打开 SQLite。
- 自动生成的 token 使用 canonical lowercase UUID v4；调用方也可显式提供合法 UUID v4。一个用户固定一个 token，token 全局唯一并以明文保存、查询和列出。
- `qtuser` 用户 ID 不区分大小写，所有输入统一转为 ASCII 小写后保存、查询并作为 introspection `sub` 返回；删除只删除本地用户凭据，不操作 Qtserver 或其他外部资源，同一 ID 可以重新创建。
- `qtuser` 默认监听 `127.0.0.1:10020`；配置为非 loopback 地址后，Qtserver 可以直接通过 HTTP 跨机器调用 introspection。Management API 默认只接受 loopback 请求，显式配置后才允许使用静态管理 bearer token 远程管理。
- `qtuser` 使用安装目录中的完整显式 `qtuser_config.toml` 和唯一 SQLite 主数据库 `qtuser.db`；SQLite 的 WAL、shared-memory 或 journal 辅助文件也只能位于该目录。`serve` 启动时完成严格配置校验、SQLite 创建或 schema 检查，严重错误以非零状态退出，并由专用非 root 账户作为 systemd 前台服务运行。
- `qtuser` 运行期把 SQLite busy/locked 视为可恢复的 HTTP 503，把约束冲突视为业务错误；其他数据库读写、损坏或 I/O 故障在尽量返回 503 后触发进程退出，由 systemd 重启。
- Qtserver 在保留 `auth`、`fake`、`off` 原有配置和行为的基础上新增 `identity.mode="oauth2-introspection"`，通过标准 form POST 和内置 `client_secret_basic` identity 调用配置的 introspection endpoint；新 mode 只配置 endpoint，不配置 client credentials。
- 新 provider 只把 bearer token 解析为普通 principal；Qtserver 继续负责文件空间、上传 session、transfer grant 和其他业务对象的本地授权，不采用 introspection 的 scope、role 或其他授权 claims。
- 新 provider 是 Qtserver 的强依赖：启动时协议探测失败会阻止启动，运行期任意一次 provider 故障会立即触发 graceful shutdown，不累计连续失败次数；`active=false` 只是普通无效 token，不属于依赖故障。
- 第一版不提供登录、`/authorize`、`/oauth2/token`、OIDC、JWT 签发或验证、密码、scope、RBAC、ACL、多 token、token 过期和 token 缓存。
- 兼容性：现有 Qtserver `auth`、`fake`、`off` 配置和请求行为不变，无需迁移；只有选择新 mode 的部署才需要配置 endpoint。除 `qtuser` 外的 RFC 7662 provider 必须预先配置为接受规格固定的内置 client identity。现有客户端仍以 `Authorization: Bearer <token>` 调用 Qtserver。

## Capabilities

### New Capabilities

- `qtuser-token-registry`: 定义 `qtuser` 的 SQLite 数据模型、完整配置、进程生命周期、RFC 7662 introspection、Management API 和 CLI 行为。
- `qtserver-oauth2-introspection-provider`: 定义 Qtserver 新增 `oauth2-introspection` mode 的配置、RFC 7662 调用、principal 结果、认证错误和既有模式兼容边界。

### Modified Capabilities

- `service-capability-discovery`: 将启用的 `oauth2-introspection` provider 纳入 Qtserver 的启动检查和运行期 fatal dependency 生命周期。

## Impact

- 新增顶层 `qtuser/` Go module、SQLite 依赖、`qtuser` CLI/HTTP API、部署配置与 systemd 示例。
- 修改 Qtserver identity 配置模型、校验、identity client/factory、依赖健康检查和敏感请求日志处理。
- Qtserver API 文档需要补充严格 Bearer 调用和新 provider 的故障语义；配置权威 `qtserver/docs/config.md` 与生产模板 `qtserver/deploy/qtserver_config_default.toml` 需要新增完整字段。
- `qtuser` 的 Management API 会返回明文 token；部署方必须把包含主数据库及 SQLite 辅助文件的整个安装目录和远程管理入口视为可信管理边界。
- 不修改 qtransc 协议、Qtserver principal 文件空间和现有 `auth`、`fake`、`off` 实现。
- `qtuser` 不读取、创建、删除或迁移 Qtserver 文件空间及任何业务资源。
