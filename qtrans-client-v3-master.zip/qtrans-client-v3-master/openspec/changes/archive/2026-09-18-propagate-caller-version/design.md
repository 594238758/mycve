## Context

动机见 [proposal.md](proposal.md)。现有 qtransc 已在 upload init、普通下载注册分片/verify 和 Small download 请求中发送 `Client-ID`、`Client-OS`、`Client-Version`，Qtserver 据此生成 `file.registered` 或自包含的 `download.small_file_sent`，Qtlogsim 再把 `client_version` 归约到最终记录。

本变更跨越 qtransc CLI/serve、两类 task、Qtserver 事件 producer 与 Qtlogsim consumer。原始事件 envelope 严格保持八字段，但 schema v1 已允许 typed payload 增加未知字段，因此 `caller_version` 应放在上下文 payload，而不是 envelope 或每个 chunk 事件。当前 PostgreSQL 最终表按列顺序严格校验，且没有自动 migration 框架。

## Goals / Non-Goals

**Goals:**

- 让 serve、upload2 与 download2 的调用方版本沿用现有 client metadata 首请求路径，普通文件每个文件只在注册请求阶段发送。
- 保持旧 qtransc、旧 Qtserver、旧 schema v1 原始事件和遵守未知 payload 字段规则的旧分析器兼容。
- 让新原始事件与最终记录始终具有 string `caller_version`，无值时统一为空字符串。

**Non-Goals:**

- 不建立 caller name/type、可信来源证明、版本比较或 capability negotiation。
- 不把 `caller_version` 传播到每个 chunk、Nginx handoff、兼容 WebSocket 帧、任务详情或 SSE。
- 不引入数据库自动迁移框架，不修改人工维护的 `docs/`，不顺带重构现有 metadata 重复代码。

## Decisions

### 1. 外部命名固定为 caller_version / --callerversion / Caller-Version

JSON 与业务日志使用 snake_case `caller_version`；兼容命令严格使用用户指定的 `--callerversion`；qtransc 到 Qtserver 使用与 `Client-Version` 同族的 `Caller-Version` HTTP header。该命名同时覆盖 GUI 与 agent，且不会混淆 qtransc 自身的 `client_version`。

备选方案 `gui_version`/`agent_version` 会绑定单一调用方类型；复用 `Client-Version` 会丢失 qtransc 自身版本，均不采用。

### 2. caller_version 是 task 内不可变、API 输出隐藏的诊断值

`TaskCreateRequest` 增加 `CallerVersion`，serve JSON 解码拒绝显式 `null` 与非 string。归一化只去除首尾 ASCII SP/HTAB，并执行 UTF-8、256 bytes 与 HTTP header value 安全校验；upload2/download2 flag 进入同一验证路径。UploadTask 与 DownloadTask 保存该值但继续通过 `json:"-"` 和既有 summary/detail 类型隐藏，避免意外扩大任务查询与事件 API。

256 bytes 与 Qtserver 现有 client metadata 上限一致。备选方案是不在 qtransc 校验、交给 `net/http` 或 Qtserver 拒绝，但这会使任务在创建成功后才异步失败，错误位置更差。

### 3. 只在现有 client metadata 代码点增加 Caller-Version

qtransc 在下列已有 `Client-Version` 设置点同时设置 `Caller-Version`：

- canonical upload 首次创建 session 的 init；
- 普通 download 注册 chunk，以及无数据恢复时的首次整文件 verify；
- Small download 请求，包括 v1/v2 batch 的协议重试。

普通下载在收到注册请求合法响应头后沿用现有 `logRegistrationConfirmed` 边界，不再发送四项 metadata。上传 session 后续 PATCH/finalize/complete 不发送。协议重试在响应头确认前可能重发相同值，这是“像 client_version 一样只传递一次”的现有可靠性语义，不额外引入持久发送标记。

不把 caller version 加入 `TaskCorrelation`，因为后者会随每个带 `X-Task-ID` 的请求发送，违反首请求边界，也会误导其日志关联语义。

### 4. Qtserver 用三项必填 metadata 判定注册，Caller-Version 独立可空

Qtserver 扩展 `clientLogMetadata` 与 `fileLogContext`。`Client-ID`、`Client-OS`、`Client-Version` 仍必须三项全有或全无，并决定普通下载请求是否是注册请求；`Caller-Version` 缺失或 trim 后为空时归一化为空字符串，不参与 present count。非空值使用相同 256-byte 和 CR/LF/NUL 防护。

`FileRegisteredPayload` 与 `DownloadSmallFileSentPayload` 始终序列化 `caller_version`，不使用 `omitempty`。Caller-Version 单独出现不会产生注册事实，也不会影响授权、file key 或传输结果。

备选方案把 Caller-Version 变成第四个必填字段会使旧 qtransc 无法与新 Qtserver 互操作，因此不采用。

### 5. 在 schema v1 payload 中演进，不修改 envelope 或 schema version

`caller_version` 只属于建立最终上下文的 `file.registered` 和 `download.small_file_sent` payload。chunk、verify、finished 事件不携带它，Nginx download chunk handoff 与八字段 envelope 均不变。

Qtlogsim 解码上下文 payload 时：字段缺失则向内存 payload 补空字符串，字段存在但非 string 则隔离。这样新 consumer 可重放历史 v1；旧 consumer 按既有规则忽略新字段。注册上下文确定性比较和语义冲突检查包含归一化后的 `caller_version`，最终记录从选定的注册或 Small 事件复制它。

备选方案提升 `schema_version` 会迫使所有 producer、collector 与 consumer 同步切换，而本次只是 schema v1 已允许的 payload 扩展，不采用。

### 6. PostgreSQL 物理列追加在表尾，JSON 顺序仍靠结构体定义

新建 `business_file_logs` 时增加 non-null text `caller_version`。为使已有表能用单条 `ALTER TABLE ... ADD COLUMN caller_version text NOT NULL DEFAULT ''` 升级，物理列追加在现有 `speed` 之后；Qtlogsim 的严格列校验也按此顺序更新。UPSERT、distinct 比较、查询与 scan 显式包含该列。最终 JSON 的字段顺序由 `FinalRecord` 决定，可仍放在 `client_version` 后，不依赖数据库物理顺序。

不在 `qtlogsim init` 中自动执行 ALTER：当前实现只创建或严格校验，不具有版本化 migration 机制，静默改变生产表超出本变更范围。

## Risks / Trade-offs

- [调用方自报版本可伪造] → 规格与命名明确它只用于诊断，不进入身份、授权、file key 或能力判断。
- [首请求响应丢失会产生重复注册] → 完全沿用 client metadata 现有规则；值固定且分析器选择最早合法上下文。
- [遗漏某个 Small/verify metadata 代码点] → 实现时用 `Client-Version` 全局检索逐点配对，并在完成后再次审计。
- [历史 raw event 没有新字段] → 新 decoder 只对缺失字段补空值；显式错误类型仍隔离。
- [已有 PostgreSQL 表阻止新版 qtlogsim 启动] → 部署前显式追加表尾列并回填空字符串；程序继续严格校验，避免半升级结构静默运行。
- [旧 qtlogsim 回滚后无法接受多出列] → 数据库升级后优先通过前滚恢复；若必须回滚 consumer，需保留新版 consumer 或在确认不再需要 caller 数据后人工移除该列。

## Migration Plan

1. 对已有 Qtlogsim PostgreSQL schema 执行等价的 `ALTER TABLE <schema>.business_file_logs ADD COLUMN caller_version text NOT NULL DEFAULT ''`；新环境无需该步骤。
2. 部署新版 Qtlogsim，使其可读取历史缺字段事件并写入25字段最终记录。
3. 部署新版 Qtserver；它接受旧 qtransc 缺失 Caller-Version 并记录空字符串。
4. 部署新版 qtransc，随后 GUI/agent 可逐步开始传入 serve `caller_version` 或兼容命令 `--callerversion`。
5. 回滚 qtransc 或 Qtserver 不需要数据回滚；旧 Qtserver 会忽略额外 header，新 Qtserver 接受旧客户端。Qtlogsim 与数据库列应优先前滚，避免严格 schema 校验与旧二进制不匹配。
