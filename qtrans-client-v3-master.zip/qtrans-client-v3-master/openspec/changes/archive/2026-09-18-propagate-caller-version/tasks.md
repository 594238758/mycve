## 1. qtransc 输入与任务模型

- [x] 1.1 在 `TaskCreateRequest` 增加可选 `caller_version`，实现 SP/HTAB trim、256 bytes、UTF-8、HTTP header value 与非 string/null 拒绝规则，并在 upload/download task 内不可变保存但不暴露到 summary/detail；通过代码审查确认缺失或空值归一化为空字符串且现有 API 输出结构不变
- [x] 1.2 为 `upload2` 与 `download2` 注册 `--callerversion` flag，并把值传入各自 `TaskCreateRequest` 构造路径；通过命令帮助与构造调用点检查确认省略参数时为空、WebSocket 帧结构未修改
- [x] 1.3 在 canonical upload init、普通 download 注册 chunk/首次 verify 以及 Small v1/v2 请求的现有 `Client-Version` 代码点同时设置 `Caller-Version`；用 `rg` 逐一审计全部 `Client-Version` 设置点，确认普通文件响应头确认后的后续请求未新增该 header

## 2. Qtserver 原始事件生产

- [x] 2.1 扩展客户端日志元数据解析，使 `Caller-Version` 独立允许缺失或为空、接受合法非空值且不参与三项必填 metadata 的注册判定；通过处理路径检查确认旧 qtransc 请求仍被接受且单独 Caller-Version 不建立注册事实
- [x] 2.2 在文件日志上下文、`file.registered` 与 `download.small_file_sent` payload 中增加始终序列化的 string `caller_version`；通过 `rg` 审计两个上下文事件构造入口，确认 chunk/verify/finished payload、envelope、Nginx handoff 与授权逻辑未增加该字段

## 3. Qtlogsim 解码、归约与存储

- [x] 3.1 扩展 schema v1 上下文解码：缺失 `caller_version` 时补空字符串、显式非 string 时拒绝，并把该字段纳入注册上下文确定性比较、语义冲突检查和最终 `FinalRecord`；通过代码路径检查确认普通与 Small 归约都输出该字段
- [x] 3.2 在 PostgreSQL 新建表定义末尾、严格列校验、UPSERT/distinct、查询与 scan 中加入 non-null text `caller_version`，保持最终 JSON 字段位于 `client_version` 后；通过 SQL 占位参数与 scan 字段逐项核对确认数量和顺序一致，且未加入自动 ALTER 或删除逻辑

## 4. 验证

- [x] 4.1 分别在 `qtransc`、`qtserver` 与 `qtlogsim` 运行 `go build ./...`，确认三个组件编译成功；按项目约定不新增或运行测试
- [x] 4.2 运行 `openspec validate propagate-caller-version --strict` 并用 `rg` 全局审计 `caller_version`、`Caller-Version`、`--callerversion`，确认命名、首请求边界和三个组件的字段链路完整
