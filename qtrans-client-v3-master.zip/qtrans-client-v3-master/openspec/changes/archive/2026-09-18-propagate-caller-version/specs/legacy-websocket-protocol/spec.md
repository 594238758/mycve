## MODIFIED Requirements

### Requirement: 兼容命令输入契约

`upload2` SHALL 通过 `--jf` 读取 JSON 数组，元素为 `{"local_abs_path":"<绝对路径>","remote_rel_path":"<远端逻辑路径>"}`；`download2` SHALL 通过 `--jf` 读取 JSON 数组，元素为 `{"local_rel_path":"<本地相对路径>","remote_url":"<远端 URL 或 object key>"}`。download2 的 `remote_url` SHALL 接受绝对下载 URL、以 `/qtserver/v1/d/down/` 开头的根相对路径或纯 object key。upload2 SHALL 拒绝匿名写 token `00000000-0000-4000-8000-000000000000`。upload2 与 download2 的传输 SHALL 固定使用 QUIC；download2 对显式指定其他 `--transport` SHALL 忽略并告警。

upload2/download2 支持的启动参数 SHALL 限定为：`--taskid`/`-t`、`--wss-url`、`--jf`/`-j`、可选 `--callerversion`、download2 的 `--destination`/`-d`，以及全局 `--server`、认证参数、并发参数、`--debug`/`--log-path` 等现有全局参数。`--callerversion` SHALL 表示启动该兼容命令的 GUI 或 agent 版本；省略或值为空时 SHALL 使用空字符串。该参数 SHALL 只进入文件首请求日志元数据，SHALL NOT 加入 WebSocket 注册、请求、响应或进度对象。

upload2/download2 SHALL NOT 接受已移除的旧版启动参数：`-upload`、`-download`、`--upload-url`、`--download-url`、`--bearer`、`--simple`、`--O`、`--disk-free-percent`、`--server-taskid`、`--js`、`--conns`、`--streams-per-conn`、`--max-transfer-files`、`--threads`、`--requests-per-conn`、`--retries`、`--retry-delay`、`--transinfo`、`--verify-url`、`--log-level`、`--insecure`、`--enable-0rtt`、`--buffer-size`。调用方 SHALL 使用全局 `--server` 指定服务端、`--auth-token` 或认证参数提供凭据。当前 qtrans-client-web 仍以旧参数启动子进程，属于已知集成缺口，qtransc 在收到这些参数时 SHALL 按 CLI 解析错误失败。

#### Scenario: download2 三种 remote_url

- **WHEN** `remote_url` 分别为绝对 URL、`/qtserver/v1/d/down/...` 和 `gsa/CRA025038/file.gz`
- **THEN** qtransc SHALL 从三种形式提取同一逻辑 object key

#### Scenario: upload2 匿名写 token

- **WHEN** `--auth-token` 为固定匿名写 token
- **THEN** upload2 SHALL 拒绝启动

#### Scenario: upload2 缺少认证

- **WHEN** upload2 未提供 token 或用户名密码
- **THEN** upload2 SHALL 在开始传输前拒绝启动

#### Scenario: 兼容命令提供调用方版本

- **WHEN** 调用方使用 `--callerversion 3.2.1` 启动 upload2 或 download2
- **THEN** qtransc SHALL 将 `3.2.1` 保存为该任务的 `caller_version`
- **AND** WebSocket 帧 SHALL 与未提供该参数时保持相同

#### Scenario: 兼容命令省略调用方版本

- **WHEN** 调用方启动 upload2 或 download2 时未提供 `--callerversion`
- **THEN** qtransc SHALL 使用空字符串作为该任务的 `caller_version`
- **AND** 传输 SHALL 正常执行

#### Scenario: 旧版启动参数

- **WHEN** 调用方以 `--upload-url`、`--bearer`、`--simple` 等旧参数启动 upload2 或 download2
- **THEN** 命令 SHALL 以 CLI 参数错误失败
- **AND** SHALL NOT 静默忽略或猜测参数含义
