## ADDED Requirements

### Requirement: caller_version 在 schema v1 中保持向前与历史兼容

当前 schema v1 producer SHALL 在 `file.registered` 与 `download.small_file_sent` payload 中显式输出 string `caller_version`，空值 SHALL 编码为空字符串。升级后的 decoder SHALL 把历史 schema v1 上下文 payload 中缺失的 `caller_version` 归一化为空字符串；字段存在但不是 string 时 SHALL 按已知字段类型错误隔离。旧 decoder SHALL 按 schema v1 未知 payload 字段规则保留原始 JSON 并忽略 `caller_version`，不得仅因该新增字段隔离整行。

#### Scenario: 历史 payload 缺少 caller_version

- **WHEN** 新分析程序读取一条其他字段均合法、但上下文 payload 没有 `caller_version` 的历史 schema v1 事件
- **THEN** SHALL 把该事件的 `caller_version` 解释为空字符串
- **AND** SHALL NOT 仅因缺少该字段隔离事件

#### Scenario: caller_version 类型错误

- **WHEN** schema v1 上下文 payload 显式包含非 string `caller_version`
- **THEN** decoder SHALL 将该行作为已知字段类型错误隔离

#### Scenario: 旧分析程序读取新增字段

- **WHEN** 遵守 schema v1 未知 payload 字段规则的旧分析程序读取带 `caller_version` 的新事件
- **THEN** SHALL 保留原始 JSON 并忽略该未知字段
- **AND** SHALL NOT 仅因该字段隔离整行

## MODIFIED Requirements

### Requirement: 最终标准业务日志具有项目内固定字段契约

日志分析程序 SHALL 为每个已经得到最终结论的文件活动保存一条当前最终标准业务日志。产品要求的基础字段 SHALL 按下表存在，外部《日志格式.xlsx》只作为本契约形成时的历史需求来源，不得成为构建、运行或审核依赖。

| 字段 | 类型 | 规范语义 |
| --- | --- | --- |
| `task_type` | string | 文件注册时生效的 qtserver `log.task_type` 配置值；`"0"`表示多中心，`"1"`表示C/S |
| `server_ip` | string | 文件第一次进入系统时实际使用的外部入口IP；两种`task_type`均原样输出可信值 |
| `task_id` | string | 客户端关联 ID |
| `taskpid` | string | 外部日志关联值，允许为空，不参与业务判断 |
| `enterprise_id` | string | 外部企业日志关联值，允许为空，不参与业务判断 |
| `client_id` | string | 客户端持久设备标识；两种`task_type`均原样输出可信值 |
| `client_ip` | string | qtserver 从可信网络边界观察到的客户端 IP |
| `client_os` | string | 客户端系统类型；两种`task_type`均原样输出可信值 |
| `client_version` | string | 执行传输的 qtransc 版本 |
| `caller_version` | string | 创建任务的 GUI 或 agent 自报版本，允许为空 |
| `client_username` | string | 一期固定等于服务端可信 `principal_id`；这是产品兼容字段，不表示独立展示名 |
| `action` | string | `upload` 或 `download` |
| `transmitted` | integer | 有合法完成事件证明的文件内容传输字节总和，单位 bytes |
| `file_path` | string | qtserver 校验并规范化后的逻辑路径 |
| `file_size` | integer | 文件大小，单位 bytes |
| `start_time` | string | 文件活动开始时间，UTC RFC3339且固定三位毫秒 |
| `end_time` | string | 权威成功事实发生时间或 timeout deadline，UTC RFC3339且固定三位毫秒 |
| `duration` | number | `end_time-start_time` 的 wall-clock 秒数，按整数毫秒计算并保留三位小数 |
| `log_time` | string | 当前结果首次写入或最近一次内容实际修订的分析时间，UTC RFC3339且固定三位毫秒 |

最终记录还 SHALL 包含下列分析扩展字段：

| 字段 | 类型 | 规范语义 |
| --- | --- | --- |
| `file_key` | string | 文件活动确定性关联键和当前结果修订键 |
| `principal_id` | string | 服务端得到的稳定身份 ID；内置 `anonymous` 用户固定为 `anonymous` |
| `result` | string | `SUCCESS` 或 `FAILED` |
| `result_reason` | string | 本 spec 定义的稳定原因码 |
| `retry_count` | integer | 相同 chunk index 的额外data attempt数之和；不是错误响应数量 |
| `speed` | number 或 null | 当前活动`transmitted>0`、成功且duration与file size均大于0时的端到端有效速度，单位bytes/s并四舍五入到三位小数；零传输、失败、`ALREADY_PRESENT`、零字节或无法计算时为null |

所有string时间字段 SHALL 使用UTC RFC3339并固定三位毫秒。分析程序 SHALL 先用时间戳差得到非负integer `duration_ms`，输出`duration=duration_ms/1000`且固定三位小数；满足speed条件时 SHALL 使用decimal或等价无溢出算法计算`file_size*1000/duration_ms`并四舍五入到三位小数，不得从格式化后的浮点duration反算。`duration_ms=0`时duration SHALL 是`0.000`且speed SHALL 是null。`transmitted` 与 `file_size` SHALL 是 `0..9223372036854775807` 的 integer。`transmitted` MAY 大于 `file_size`，因为失败、中断、hash mismatch 和重传产生的完成事件仍计入实际网络成本。最终结果原因只允许：

```text
SUCCESS / UPLOADED_AND_COMMITTED
SUCCESS / ALREADY_PRESENT
SUCCESS / DOWNLOADED_AND_VERIFIED
SUCCESS / SMALL_FILE_SENT
FAILED  / TIMEOUT
```

`log.task_type` SHALL 只允许字符串 `"0"` 或 `"1"`并默认使用`"1"`。原始事件与最终记录 SHALL 始终保留完整且可信的`server_ip`、`client_id`和`client_os`；无论`task_type`为`"0"`还是`"1"`，分析程序 SHALL 原样输出这些字段以及 `client_version` 与 `caller_version`。Task type SHALL 只表示场景分类，SHALL NOT 改变其他字段、传输协议、授权、文件空间、事件类型或状态机。

系统 SHALL NOT 把 anonymous 定义为一种下载类型。`anonymous` SHALL 是一个没有密码、任何调用方都可选择的内置用户；Qtserver SHALL 直接构造该用户的可信 principal而不查询外部身份服务，并 SHALL 固定 `principal_id=anonymous` 与 `client_username=anonymous`。普通用户与 anonymous用户 SHALL 使用相同的原始事件协议和分析状态机；本契约 SHALL NOT 改变既有文件空间或 API 权限。

一期所有用户的 `client_username` SHALL 固定等于服务端可信 `principal_id`。Producer SHALL NOT 使用客户端自报 username，也 SHALL NOT 为满足该字段单独查询或扩展身份服务。该字段当前 SHALL 视为产品格式兼容字段而不是独立展示名；未来改变其语义需要修订本契约。

#### Scenario: 使用 anonymous 用户

- **WHEN** 一个合法文件请求选择内置 `anonymous` 用户
- **THEN** Qtserver SHALL NOT 为该用户查询外部身份服务
- **AND** 原始事件与最终记录的 `principal_id` 和 `client_username` SHALL 都是 `anonymous`
- **AND** 分析程序 SHALL NOT 把它归入另一种下载类型或状态机

#### Scenario: 普通用户生成 username字段

- **WHEN** Qtserver 为合法文件请求得到可信普通用户 `principal_id`
- **THEN** 原始事件与最终记录的 `client_username` SHALL 等于该 `principal_id`
- **AND** Qtserver SHALL NOT 使用 qtransc 提交的登录名或其他客户端字段覆盖它

#### Scenario: 项目外需求附件不可用

- **WHEN** producer、分析程序或审核者无法访问原始 Excel 附件
- **THEN** SHALL 能仅依据本 requirement 确定最终记录的字段、类型和语义

#### Scenario: 多中心最终字段映射

- **WHEN** 合法原始事件的`task_type`是`"0"`
- **THEN** 原始事件 SHALL 仍包含完整且可信的`server_ip`、`client_id`和`client_os`
- **AND** 最终记录 SHALL 原样使用这些字段以及 client 与 caller version

#### Scenario: C/S最终字段映射

- **WHEN** 合法原始事件的`task_type`是`"1"`
- **THEN** 最终记录 SHALL 原样使用原始上下文中的`server_ip`、`client_id`、`client_os`、`client_version`与`caller_version`

#### Scenario: 调用方版本为空

- **WHEN** 文件活动没有提供调用方版本
- **THEN** 最终记录 SHALL 显式包含 `"caller_version":""`
- **AND** SHALL NOT 省略该字段或写 `null`

#### Scenario: 校验失败后重传成功

- **WHEN** 同一上传 chunk 传输两次并最终提交成功
- **THEN** 最终记录 SHALL 是 `SUCCESS/UPLOADED_AND_COMMITTED`
- **AND** `transmitted` SHALL 累加两次完成事件的实际字节
- **AND** `retry_count` SHALL 至少增加 1

#### Scenario: 最终内容未改变

- **WHEN** 分析程序再次得到与数据库当前行完全相同的候选结果
- **THEN** SHALL NOT 仅为重复分析改变 `log_time`

### Requirement: 普通文件注册事件固定完整上下文

Qtserver SHALL 在接受普通上传的第一个有效 init，或者普通下载携带完整client metadata的指定 `/d/down` 或整文件 `/d/verify` 请求时，为文件可靠写入 `file.registered` 后再执行该请求的传输或校验。Download grant同时服务small与普通路径，SHALL NOT 输出 `file.registered` 或其他原始业务事件。Payload SHALL 包含：

```text
task_type
action
file_path
file_size
principal_id
client_username
client_id
client_ip
client_os
client_version
caller_version
server_ip
server_instance
server_version
file_inactivity_timeout_seconds
```

`task_type` SHALL 使用当时 qtserver `log.task_type`配置值`"0"|"1"`，保存在原始事件中且只表示场景分类，不得影响其他字段、读取客户端Task-Type或改变传输逻辑。Client metadata SHALL 来自该文件的第一个请求；principal、client username、client IP、server IP、文件路径和下载文件大小 SHALL 使用服务端可信事实。Producer SHALL NOT 使用客户端自报 username 填充 `client_username`。上传file size SHALL 使用qtserver已校验接受的init声明值；下载file size SHALL 使用服务端已打开普通文件的stat事实。`server_instance` SHALL 使用派生完成后的`server.instance_id`（缺省为启动时hostname），`server_version` SHALL 使用当前qtserver构建版本；两者不得来自请求。`file_inactivity_timeout_seconds` SHALL 大于 0 并固定该文件历史的超时口径。

Qtserver SHALL 在当前文件首请求中构造上述上下文，SHALL NOT 从旧`/taskid`日志上下文回读字段。客户端在日志上下文中只提供`Client-ID`、`Client-OS`、`Client-Version`与允许为空的`Caller-Version`；其提交的Task-Type、username、server IP、server instance或server version SHALL NOT 覆盖服务端来源。

注册payload的`task_type` SHALL 是`"0"|"1"`；`file_path`、`principal_id`、`client_username`、`client_id`、`client_os`、`client_version`、`server_instance`与`server_version` SHALL 是非空string；`caller_version` SHALL 是允许为空的string；`file_size` SHALL 是`0..MaxInt64` integer；`client_ip`与`server_ip` SHALL 是可解析且非unspecified的IP string。Nginx MAY 通过内部header提供本次入口`$server_addr`，但Qtserver SHALL 只在直接连接方属于`server.trusted_proxies`时信任它；否则 SHALL 使用本地监听地址或配置`server.external_ip`。任意客户端直接提交同名header SHALL NOT 改变`server_ip`。`client_ip` SHALL 同样按可信代理配置解析，而不得使用客户端自报值。

同一文件因上传init或普通下载注册请求的HTTP重试出现多条注册事实时，分析程序 SHALL 使用`occurred_at`最早且合法的一条，后续注册 SHALL NOT 刷新deadline或覆盖最终字段。后续完全一致的注册 SHALL 被忽略；`task_type`、`client_ip`、`server_ip`、`server_instance`、`server_version`或`file_inactivity_timeout_seconds`变化 SHALL 作为重试上下文漂移展示但不作为文件语义冲突；`file_size`、`client_id`、`client_os`、`client_version`、`caller_version`或`client_username`变化 SHALL 报告语义冲突，但不得阻止最早上下文继续归约。Action、file path或principal与file key不一致的注册 SHALL 按非法注册处理。

若最早`occurred_at`上并列注册会产生不同最终上下文字段，分析程序 SHALL 报告无法确定首次注册，且 SHALL NOT 为该`file_key`输出候选结果；最早并列但全部上下文字段一致 SHALL 视为同一事实。分析程序 SHALL NOT 使用ClickHouse导入顺序或虚构event ID选择并列上下文。

#### Scenario: 晚到的入口漂移

- **WHEN** 最早合法注册之后的重试注册使用不同client IP、server IP或server instance但文件语义字段一致
- **THEN** 分析程序 SHALL 保留最早上下文继续归约
- **AND** inspect SHALL 展示入口漂移但不得把它标记为file size或client metadata语义冲突

#### Scenario: 晚到的语义冲突注册

- **WHEN** 最早合法注册之后出现不同file size或client metadata的注册事件
- **THEN** 分析程序 SHALL 保留最早上下文继续归约
- **AND** 后续冲突注册 SHALL NOT 刷新deadline或改变最终字段
- **AND** inspect SHALL 报告该冲突

#### Scenario: 最早注册时间并列冲突

- **WHEN** 同一file key在最早`occurred_at`上存在两个会产生不同最终字段的注册上下文
- **THEN** 分析程序 SHALL NOT 按导入顺序选择其中一个
- **AND** SHALL NOT 输出该file key的候选结果
- **AND** inspect SHALL 报告无法确定首次注册

上传源文件在活动中发生变化 SHALL 停止当前文件活动且不得用新的size/hash覆盖原注册上下文。客户端上传变化后的内容 SHALL 使用新的task ID形成新的`file_key`；旧活动没有成功事实时 SHALL 独立TIMEOUT。

普通下载 producer SHALL 以Client-ID、Client-OS和Client-Version三项全部存在作为注册请求标志，全部不存在时不得重复输出注册，部分存在时 SHALL 拒绝请求。`Caller-Version` SHALL NOT 改变该三项判定；缺失时使用空字符串。Qtransc SHALL 在注册分片获得合法响应头前阻止同文件其他分片开始，因此遵守本协议的qtransc在任何普通chunk完成事实之前 SHALL 已经有至少一次注册写入。Qtserver SHALL NOT 为避免响应丢失产生的重复注册而增加持久download registration状态；分析程序 SHALL 合并内容一致的重复注册。

没有持久注册状态时Qtserver无法区分合法后续请求和三项metadata全缺失的非规范首请求，因此本spec SHALL NOT 要求它拒绝后一种情况。违反协议的客户端 MAY 产生无注册的孤立chunk/verify事件；分析程序 SHALL 保留它们，但在合法注册到达前 SHALL NOT 建立状态、deadline或最终结果。

#### Scenario: 无注册的普通下载事件

- **WHEN** ClickHouse收到普通下载chunk或verify事件但没有该file key的合法`file.registered`
- **THEN** 分析程序 SHALL 保留该事件并在inspect中说明缺少注册上下文
- **AND** SHALL NOT 为该file key生成PROCESSING、TIMEOUT或最终结果

#### Scenario: 注册日志不可写

- **WHEN** Qtserver 无法可靠写入普通文件的 `file.registered`
- **THEN** SHALL 拒绝该文件活动并返回稳定的日志不可用错误
- **AND** SHALL NOT 开始数据传输

#### Scenario: 后续配置改变

- **WHEN** 文件注册后运维改变 task type 或 inactivity timeout 配置
- **THEN** 分析程序 SHALL 继续使用该 `file.registered` 中固定的历史值

#### Scenario: 上传源文件发生变化

- **WHEN** qtransc检测到已注册上传文件的size、mtime或文件身份变化
- **THEN** SHALL 停止当前活动且不得在同一file key下注册新文件内容
- **AND** 重新上传变化后的内容 SHALL 使用新task ID

#### Scenario: download grant不建立文件状态

- **WHEN** Qtserver成功签发一个随后可能走small路径的download grant
- **THEN** SHALL NOT 输出该文件的 `file.registered`
- **AND** 普通文件 SHALL 等到指定的合法 `/d/down` 或整文件verify请求才进入状态机

#### Scenario: 完整本地恢复只执行verify

- **WHEN** 普通下载没有任何Range请求且第一次整文件verify携带完整metadata
- **THEN** Qtserver SHALL 先可靠输出`file.registered`再执行verify

#### Scenario: 并行普通下载建立注册顺序

- **WHEN** 一个文件存在多个待下载分片
- **THEN** qtransc SHALL 先使最小待下载chunk的注册请求收到合法响应头
- **AND** 才能启动其他chunk请求

### Requirement: 小文件下载只记录完整发送成功

Small download SHALL 不输出 `file.registered`、开始、失败、重试、timeout 或 verify 事件。Qtserver 只有在一个小文件的`io.Copy`成功、实际字节等于`file_size`且显式`tar.Writer.Flush()`成功写完当前entry padding后，才 SHALL 立即输出一条 `download.small_file_sent`；未写完、字节数不符、当前entry flush失败、中途停止或其他写入失败 SHALL 不输出该文件的任何原始业务事件。Producer SHALL NOT 仅以`io.Copy`返回成功提前记录，也 SHALL NOT 等待整个批次tar关闭后才统一补写已完成文件。

`download.small_file_sent` SHALL 自包含最终记录需要的 `task_type`、`action=download`、`file_path`、`file_size`、`principal_id`、`client_username`、`client_id`、`client_ip`、`client_os`、`client_version`、允许为空的`caller_version`、`server_ip`、`server_instance`、`server_version` 和 `started_at`。这些上下文字段 SHALL 使用注册payload的相同类型规则；`started_at` SHALL 使用本spec固定的UTC三位毫秒格式且不得晚于envelope `occurred_at`。Envelope `occurred_at` SHALL 是 qtserver 完成该文件写入的时间。

普通事件family SHALL 与最早合法注册action匹配：`upload.*`只可用于upload，`download.*`只可用于download。事件早于注册、family与action不匹配、注册四元组或small自包含四元组无法按本spec重算出envelope file key时，该事件 SHALL NOT 参与状态、deadline或统计，并 SHALL 在inspect中报告。无注册普通事件 MAY 先保留在ClickHouse，注册到达后再执行语义校验。

分析程序收到合法 small-file event 后 SHALL 立即形成 `SUCCESS/SMALL_FILE_SENT`，并设置 `transmitted=file_size`、`retry_count=0`、`start_time=started_at`、`end_time=occurred_at`。服务端 SHALL NOT 等待或推断客户端是否收到、落盘或校验文件。多个小文件在同一响应中传输时 SHALL 按文件边界独立记录；后续文件失败不得撤销此前已记录文件的成功。

合法small成功 SHALL 对同一`file_key`具有终态优先级。客户端在small成功后因本地校验、tar尾部或连接问题改走普通下载时，后续`file.registered`、`download.chunk_finished`与`download.verify_finished` MAY 保留在ClickHouse和inspect中，但 SHALL NOT 改变、补充或撤回现有`SUCCESS/SMALL_FILE_SENT`的任何最终字段。

零字节下载 SHALL 使用small路径而不是由qtransc根据grant响应直接在本地完成。Qtserver成功写入header并结束零长度tar entry后 SHALL 输出`download.small_file_sent`；其最终`transmitted=0`、`retry_count=0`、`speed=null`。客户端随后无法创建本地空文件 SHALL NOT 改变该服务端成功事实。

#### Scenario: 小文件完整写完

- **WHEN** Qtserver 正常完成一个小文件全部内容的响应写入
- **THEN** SHALL 输出一条自包含 `download.small_file_sent`
- **AND** 分析程序 SHALL 不等待其他事件即形成成功最终记录

#### Scenario: 小文件调用方版本为空

- **WHEN** small请求没有提供非空调用方版本且文件完整写完
- **THEN** `download.small_file_sent` payload 与最终记录 SHALL 显式包含空字符串 `caller_version`

#### Scenario: 当前tar entry flush失败

- **WHEN** 小文件内容字节已经全部复制，但`tar.Writer.Flush()`写当前entry padding失败
- **THEN** Qtserver SHALL NOT 输出该文件的`download.small_file_sent`
- **AND** SHALL 停止当前small响应的后续文件

#### Scenario: 小文件中途断开

- **WHEN** Qtserver 未完成一个小文件的全部响应写入或写入返回错误
- **THEN** SHALL NOT 输出该文件的任何原始业务事件
- **AND** 分析程序 SHALL NOT 为该文件生成 TIMEOUT 或失败结果

#### Scenario: 批次中后续文件失败

- **WHEN** 一个批次的第一个小文件已写完并记录，而第二个文件中途失败
- **THEN** 第一个文件的成功事件 SHALL 保留
- **AND** 第二个文件 SHALL 没有原始业务事件

#### Scenario: 批次尾部关闭失败

- **WHEN** 一个文件的内容与tar entry已经完整结束并记录成功，但后续文件或整个tar尾部关闭失败
- **THEN** 已记录的该文件成功事实 SHALL 保留

#### Scenario: small成功后客户端普通下载fallback

- **WHEN** 同一file key在small成功事件之后出现普通下载注册、chunk或verify事件
- **THEN** 当前最终结果 SHALL 保持第一次`SUCCESS/SMALL_FILE_SENT`
- **AND** 普通事件 SHALL NOT 计入transmitted或retry count

#### Scenario: 零字节下载

- **WHEN** Qtserver成功结束一个file size为0的small tar entry
- **THEN** SHALL 输出`download.small_file_sent`
- **AND** 最终记录 SHALL 是`SUCCESS/SMALL_FILE_SENT`且transmitted为0、speed为null

### Requirement: 普通文件字段使用完成事实确定性归约

普通文件 `start_time` SHALL 使用最早合法 `file.registered.occurred_at`。分析程序 SHALL 先确定包含两个边界的结果统计窗口：SUCCESS是`start_time..最早权威成功时间`，TIMEOUT是`start_time..首次inactivity deadline`。普通事件早于start time SHALL 非法；晚于结果窗口的普通事件 MAY 保留在ClickHouse和inspect中，但 SHALL NOT 参与最终字段。

普通文件的公共上下文 SHALL 使用最早合法注册payload，small SHALL 使用自身payload。两条路径都 SHALL 原样保留上下文中的可信字段；`task_type`只表示场景分类，`"0"`和`"1"`均不得导致`server_ip`、`client_id`、`client_os`、`client_version`、`caller_version`或其他最终字段被删除、清空或改写。

全部25个最终字段 SHALL 确定如下：普通文件的`task_type`、`server_ip`、`client_id`、`client_ip`、`client_os`、`client_version`、`caller_version`、`client_username`、`action`、`file_path`、`file_size`与`principal_id`来自最早合法注册payload，small的这些字段来自其自包含payload；`task_id`与`file_key`来自对应envelope并通过四元组校验；普通文件的`taskpid`与`enterprise_id`来自同一条被选定的最早合法注册envelope，small的两项标签来自同一条形成当前结果的small成功envelope。普通文件`start_time`来自最早合法注册时间，small来自`started_at`；普通文件`end_time`来自最早权威成功时间或首次deadline，small来自事件时间；`duration`为两者非负毫秒差，`log_time`为候选首次写入或内容实际修订时的固定analysis time。普通文件`result`与`result_reason`按committed、already-present、整文件matched或timeout映射，small固定为`SUCCESS/SMALL_FILE_SENT`。`transmitted`、`retry_count`与`speed` SHALL 按下述规则计算。除此之外不得从调试日志、qtserver数据库或客户端状态补字段。

除already-present外，上传 `transmitted` SHALL 是结果统计窗口内合法 `upload.chunk_finished.actual_bytes` 之和；下载 SHALL 是结果统计窗口内合法 `download.chunk_finished.actual_bytes` 之和。`retry_count` SHALL 在相同窗口内按 `chunk_index` 分组，对每组计算 `max(finished_count-1,0)` 后求和，不要求前一个attempt结果是failed或interrupted。`SUCCESS/ALREADY_PRESENT` SHALL 固定 `transmitted=0` 与 `retry_count=0`。

上传成功 `end_time` SHALL 使用最早合法 `upload.finished.occurred_at`；下载成功 SHALL 使用最早合法整文件 matched 时间；失败 SHALL 使用 timeout deadline。除already-present外，成功且`transmitted>0`、`duration_ms>0`、`file_size>0`时speed SHALL 按本spec的三位小数规则计算，其他情况为null；already-present的speed SHALL 固定为null。校验请求、HTTP header、TLS 和授权数据 SHALL NOT 计入 transmitted。

#### Scenario: 新task复用完整下载现场只执行verify

- **WHEN** 新task ID的文件活动没有任何download chunk finished，但第一次携带metadata的整文件verify得到matched
- **THEN** 最终记录 SHALL 是`SUCCESS/DOWNLOADED_AND_VERIFIED`
- **AND** `transmitted=0`、`retry_count=0`且`speed=null`

#### Scenario: 原task ID继续完整下载现场

- **WHEN** 调用方复用原task ID且四元组其余字段不变，并在已有历史chunk后执行整文件matched verify
- **THEN** 分析程序 SHALL 按同一file key完整历史计算transmitted与retry count

普通文件duration SHALL 包含注册后的传输、校验、重试等待、退避和客户端静默wall-clock时间；服务端 SHALL NOT 猜测或扣除客户端暂停。并行chunk持续时间 SHALL NOT 相加。Speed SHALL 使用file size而非transmitted作为分子，表示端到端有效速度而非链路吞吐率。Small文件duration只覆盖当前tar响应内该文件从started_at到entry完成，不包含grant或客户端接收与本地校验时间。

#### Scenario: 客户端暂停后继续

- **WHEN** 普通文件注册后客户端静默一段时间并在deadline前继续直到成功
- **THEN** duration SHALL 包含该静默时间
- **AND** 分析程序 SHALL NOT 扣除未上报的暂停区间

#### Scenario: 并行分片

- **WHEN** 多个chunk并行传输并最终成功
- **THEN** duration SHALL 只等于文件start到end的wall-clock差
- **AND** SHALL NOT 累加各chunk耗时

#### Scenario: 成功响应丢失后再次请求

- **WHEN** 最早权威成功事实之后出现chunk、verify或相同成功事实重试
- **THEN** 最终结果 SHALL 保持第一次成功
- **AND** 成功之后的chunk SHALL NOT 进入transmitted或retry count

#### Scenario: 上传成功事实冲突

- **WHEN** 同一file key同时存在合法`upload.finished{committed}`与`upload.finished{already_present}`
- **THEN** 分析程序 SHALL 报告producer终态冲突
- **AND** SHALL NOT 按到达顺序或时间猜测其中一个结果

本模型没有 started 事件，因此完全没有留下完成事件的调用无法计入 transmitted 或 retry。分析程序 SHALL NOT 猜测其字节数，也 SHALL NOT 为此引入 `statistics_complete`、operation pairing 或全局序号。

连接中断后从后续offset续传、hash mismatch后重传或客户端重新请求同一chunk SHALL 都作为额外data attempt计数。Init、grant、verify、complete和查询请求的重复调用 SHALL NOT 增加`retry_count`。

#### Scenario: 中断 attempt有完成事件

- **WHEN** 一个 `chunk_finished{result=interrupted}` 记录了非零 actual bytes，随后重试并成功
- **THEN** 两个完成事件的实际字节 SHALL 都计入 transmitted
- **AND** 相同 chunk index SHALL 使 retry count增加 1

#### Scenario: 完成事件整行丢失

- **WHEN** 一次请求没有留下任何 finished 事件
- **THEN** 分析程序 SHALL 不猜测该请求的实际字节或 attempt
- **AND** 本契约允许最终统计小于真实网络成本
