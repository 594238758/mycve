## ADDED Requirements

### Requirement: serve 创建任务 API 接收可选 caller_version

qtransc `serve` 的 `POST /api/v1/tasks` 请求体 SHALL 接受可选 string 字段 `caller_version`。qtransc SHALL 去除其首尾 ASCII SP 和 HTAB、保留内部字符，并在归一化后要求值为合法 UTF-8、至多 256 bytes 且可安全作为 HTTP header field value 传播。字段缺失、值为空字符串或 trim 后为空时 SHALL 使用空字符串创建任务；显式 `null`、非 string、超长或包含非法 header value 字符时 SHALL 返回现有 invalid-request 类别的 400 响应且不得创建任务。

`caller_version` SHALL 是创建任务的 GUI 或 agent 自报版本，仅用于诊断日志。它 SHALL NOT 具有客户端二进制版本、身份、授权、tenant、任务 ID、幂等键或能力协商语义。创建任务响应、任务详情与摘要、SSE、WebSocket 和其他 API 响应 SHALL NOT 返回 `caller_version`。除 `upload2`/`download2 --callerversion` 与 serve 创建任务 API 外，其他 qtransc CLI 创建的任务 SHALL 使用空字符串。

#### Scenario: serve 调用方传入 caller_version

- **WHEN** 调用方以合法 string `caller_version` 创建 upload 或 download 任务
- **THEN** qtransc SHALL 在任务生命周期内保存归一化后的值
- **AND** 该值 SHALL NOT 改变任务 ID、文件选择、授权或传输结果

#### Scenario: serve 调用方省略 caller_version

- **WHEN** 创建任务请求没有 `caller_version`、值为空字符串或 trim 后为空
- **THEN** qtransc SHALL 正常创建任务
- **AND** 该任务的 `caller_version` SHALL 是空字符串

#### Scenario: serve 调用方提交非法 caller_version

- **WHEN** `caller_version` 是 `null`、非 string、trim 后超过 256 bytes、不是合法 UTF-8 或包含非法 HTTP header value 字符
- **THEN** qtransc SHALL 以 400 invalid request 拒绝创建任务
- **AND** SHALL NOT 截断或部分传播该值

#### Scenario: 查询任务不暴露 caller_version

- **WHEN** 调用方创建带非空 `caller_version` 的 serve 任务后查询任务或订阅实时事件
- **THEN** 对应 API、SSE 与 WebSocket 输出 SHALL NOT 包含 `caller_version`

## MODIFIED Requirements

### Requirement: 每个文件的第一个请求携带日志上下文

qtransc SHALL 在每个文件的第一个有效上传 init、普通下载注册分片请求或 small download 请求中携带 `Client-ID`、`Client-OS`、`Client-Version` 和允许为空的 `Caller-Version`。前三项 SHALL 继续构成必填 client metadata；`Caller-Version` SHALL 使用任务创建时固定的 `caller_version`，且其缺失或空值不影响前三项的完整性判断。普通下载注册分片 SHALL 是本次启动时最小的待下载`chunk_index`；在收到该分片一次合法HTTP响应头以前，该分片的每次attempt SHALL 携带完整metadata，且qtransc SHALL NOT 启动该文件其他分片请求。收到合法响应头后，后续Range SHALL 不再发送这四项metadata。如果恢复现场无需任何数据请求，第一次整文件 `/d/verify` SHALL 作为注册请求携带metadata。Qtserver SHALL 从配置取得 `task_type`、instance与timeout，从当前构建取得server version，从服务端解析的可信 principal取得`principal_id`并固定`client_username=principal_id`；`anonymous`直接使用两项值`anonymous`而不查询身份服务。Qtserver SHALL 从可信网络边界取得 `client_ip` 与实际外部入口 `server_ip`，并从当前文件事实取得规范路径与file size。Qtransc SHALL NOT 提交 username、task type或服务端字段作为可信日志上下文，Qtserver也 SHALL NOT 从旧`/taskid`上下文回读这些字段。客户端元数据 SHALL 只用于文件日志上下文，不得参与授权、session ownership、grant HMAC、文件归属、能力协商或传输成功判定。

每个普通下载 `/d/down` GET还 SHALL 使用请求头 `X-QT-Chunk-Index` 携带稳定的非负分片编号，包括Range和无Range完整GET。该编号 SHALL 只用于原始日志的分片关联和retry count分组，不得参与授权、grant、文件定位或Range计算；具体校验、零字节small分流与可信Nginx handoff规则由`raw-business-event-log`定义。

Download grant同时服务small与普通文件，SHALL NOT 产生原始业务事件，也不得被视为普通文件注册点。普通文件除指定注册请求及其在合法响应头确认前的重试外，后续 Range、verify和complete请求 SHALL NOT 重复提交上述客户端元数据。Small download 因不产生独立注册事件，其每个请求 SHALL 使用当前任务的完整metadata；同一请求的协议重试 MAY 重发相同metadata。

上传init与small请求是各自路径明确的首请求，缺少 `Client-ID`、`Client-OS` 或 `Client-Version` 任一必填metadata时Qtserver SHALL 拒绝；`Caller-Version` 缺失或为空时 SHALL 归一化为空字符串而不得拒绝。对普通下载`/d/down`和`/d/verify`，Qtserver SHALL 只把前三项必填metadata全部存在解释为注册请求，全部不存在解释为后续请求，只有前三项中的部分字段存在 SHALL 以参数错误拒绝；`Caller-Version` 单独存在 SHALL NOT 建立注册事实。Qtserver SHALL NOT 为此增加download registration业务状态；指定请求因HTTP异常重试产生内容一致的重复注册事实 MAY 被分析程序按最早事实合并。

因为Qtserver不保存普通下载注册状态，它 SHALL NOT 声称能区分“合法后续请求全无metadata”和“违反协议的首请求全无metadata”。Qtransc SHALL 通过注册分片串行握手保证自己的首个普通请求完整携带metadata。其他客户端若违反该契约，后续数据请求 MAY 产生无`file.registered`的孤立原始事件；分析程序 SHALL 保留但不得在注册到达前形成最终结果。

#### Scenario: 上传文件第一次 init

- **WHEN** qtransc 为一个文件发送第一次有效 upload init
- **THEN** 请求 SHALL 携带 client ID、OS、qtransc version 和任务的 caller version
- **AND** Qtserver SHALL 使用可信服务端事实补齐该文件日志上下文

#### Scenario: caller_version 只随注册请求发送

- **WHEN** 普通文件的注册请求已经收到一次合法响应头
- **THEN** qtransc 后续 Range、verify、chunk、complete 或其他数据请求 SHALL NOT 再发送 `Caller-Version`
- **AND** 首个请求在合法响应头确认前的重试 MAY 重发相同 `Caller-Version`

#### Scenario: 上传或small首请求metadata缺失

- **WHEN** upload init或small download请求缺少 `Client-ID`、`Client-OS` 或 `Client-Version`
- **THEN** Qtserver SHALL 在形成文件活动前拒绝该请求
- **AND** SHALL NOT 输出不完整的原始业务事件

#### Scenario: caller_version 缺失

- **WHEN** 合法首请求包含三项必填 client metadata 但未包含 `Caller-Version`
- **THEN** Qtserver SHALL 接受该请求并使用空字符串 `caller_version`
- **AND** 其他日志上下文与传输行为 SHALL 保持不变

#### Scenario: grant 后选择 small 路径

- **WHEN** qtransc 获取 download grant 后把文件分到 small download路径
- **THEN** grant SHALL NOT 已经为该文件产生 `file.registered`
- **AND** small请求未完整写完时 SHALL 不留下任何该文件原始业务事件

#### Scenario: 恢复下载无需Range请求

- **WHEN** qtransc本地已经具有全部文件数据且只需执行整文件verify
- **THEN** 第一次整文件verify SHALL 携带完整client metadata与任务的 caller version
- **AND** Qtserver SHALL 在校验前可靠输出`file.registered`

#### Scenario: metadata只出现一部分

- **WHEN** 普通下载请求只携带Client-ID、Client-OS、Client-Version中的一部分
- **THEN** Qtserver SHALL 以参数错误拒绝
- **AND** SHALL NOT 输出不完整注册事实

#### Scenario: Caller-Version 单独出现

- **WHEN** 普通下载请求没有三项必填metadata但单独携带 `Caller-Version`
- **THEN** Qtserver SHALL NOT 把该请求解释为注册请求
- **AND** SHALL NOT 仅凭该字段输出 `file.registered`

#### Scenario: 非规范客户端下载首请求完全不带metadata

- **WHEN** 非qtransc客户端第一次调用普通`/d/down`时三项必填metadata全部缺失
- **THEN** Qtserver MAY 按无状态协议把它解释为后续请求并发送数据
- **AND** 相应chunk事件 SHALL 在缺少注册时只保留供inspect使用，不得形成最终日志

#### Scenario: 注册分片响应头尚未确认

- **WHEN** 注册分片请求在qtransc收到合法响应头前发生网络错误
- **THEN** qtransc SHALL 使用包含相同 caller version 的完整metadata重试该注册分片
- **AND** SHALL NOT 启动其他分片请求

#### Scenario: 注册分片响应丢失导致重复注册

- **WHEN** Qtserver已经注册并返回响应但qtransc未收到响应头而重试
- **THEN** Qtserver MAY 输出内容一致的重复`file.registered`
- **AND** 分析程序 SHALL 使用最早合法注册事实

#### Scenario: 客户端伪造身份或 IP

- **WHEN** 客户端提交的字段与已认证 principal 或可信网络观察值冲突
- **THEN** Qtserver SHALL 使用服务端可信事实
- **AND** 客户端字段 SHALL NOT 改变授权结果
