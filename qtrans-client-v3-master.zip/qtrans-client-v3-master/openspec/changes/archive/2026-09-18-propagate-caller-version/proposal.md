## Why

当前业务日志只能记录实际执行传输的 qtransc 版本，无法区分创建任务的 GUI 或 agent 版本，出现调用方相关问题时缺少可检索的版本上下文。系统需要新增可选 `caller_version`，并沿用 `client_version` 的首请求元数据路径把它带入原始事件和最终业务日志。

## What Changes

- `upload2` 与 `download2` 新增可选 CLI 参数 `--callerversion <value>`；未提供时使用空字符串，不改变现有 WebSocket 帧、状态码或传输行为。
- qtransc `serve` 的 `POST /api/v1/tasks` 请求体新增可选 string 字段 `caller_version`；字段缺失或为空时正常创建任务并使用空字符串。
- qtransc 在任务内固定保存 `caller_version`，仅在每个文件沿用 `Client-Version` 的首请求日志元数据位置发送 `Caller-Version`；首请求在获得合法响应前的协议重试可以重发，后续分片及其他请求不重复发送。
- Qtserver 把 `Caller-Version` 作为不可信诊断元数据读取，并在 `file.registered` 与 `download.small_file_sent` payload 中始终输出 string `caller_version`，允许为空。
- 日志分析程序把 `caller_version` 归约到最终标准业务日志；历史 schema v1 payload 缺少该字段时按空字符串读取，旧分析程序继续按既有未知 payload 字段规则忽略新字段。
- 非目标：不使用 `caller_version` 做认证、授权、任务身份、file key、幂等、状态机或传输决策；不把它加入兼容 WebSocket 消息或 qtransc 任务查询/事件响应；不修改人工维护的 `docs/`。

兼容性与迁移：CLI 与 serve API 变更均为可选输入，旧调用方行为不变；新 qtransc 对旧 Qtserver 发送的额外 header 会被忽略，旧 qtransc 对新 Qtserver 不提供该值时记录空字符串。Qtlogsim 新建最终表包含 non-null `caller_version`；已有 PostgreSQL `business_file_logs` 需要在部署升级时增加以空字符串回填的 non-null text 列后再由新版程序校验，本变更不自动迁移或删除已有数据。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `legacy-websocket-protocol`：在 `upload2`/`download2` 兼容命令输入契约中增加可选 `--callerversion`，同时保持 WebSocket 协议不变。
- `transfer-task-correlation`：增加 serve `caller_version` 输入以及随首请求客户端日志元数据传播的契约。
- `raw-business-event-log`：把 `caller_version` 加入注册与 Small 成功 payload，并归约为最终业务日志字段。

## Impact

- qtransc：任务创建请求、upload/download task 内部模型、`upload2`/`download2` flags 与首请求 header 构造路径。
- Qtserver：客户端日志元数据解析、普通文件注册 payload 和 Small 下载成功 payload。
- Qtlogsim：schema v1 payload 解码与兼容默认、注册上下文比较、最终记录模型、PostgreSQL 建表/校验/UPSERT/查询。
- 外部接口：`POST /api/v1/tasks` 增加可选 `caller_version`；`upload2`/`download2` 增加可选 `--callerversion`；原始与最终业务日志增加 `caller_version`。
- 无新增依赖；不修改 Nginx download chunk handoff，因为 `caller_version` 只存在于首次上下文事件而不属于每个 chunk 的公共 envelope。
