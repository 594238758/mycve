## 1. 配置兼容边界

- [x] 1.1 在 Qtserver 配置模型中增加仅识别 `[postgres].dsn` 的私有 legacy 载体，保持 `UnmarshalExact` 对其他未知字段的拒绝，并确保该字段不进入 JSON 配置输出。
- [x] 1.2 在配置解码成功后立即清零 legacy DSN，确认默认值、demo config、运行期 bootstrap、health check 和命令树均不读取它或恢复 PostgreSQL 行为。
- [x] 1.3 复核 Qtserver 独立 module graph 和源码，确保没有 `pgx`、PostgreSQL driver、database package、migration CLI 或连接逻辑。

## 2. 部署与验收流程

- [x] 2.1 从 `qtserver/deploy/install_local.sh` 删除已失效的 `qtserver db migrate` 调用，保留 config validate、Nginx 配置生成和服务安装顺序。
- [x] 2.2 调整 `scripts/e2e_business_logging.sh`：从 Qtserver 配置和启动流程移除 PostgreSQL/migration，把保留的 PostgreSQL 明确限制为 `qtlogsim` 使用，并让 Redis 启动参数满足 AOF、`everysec` 和 `noeviction` preflight。

## 3. 现行规范与文档

- [x] 3.1 修正主 `file-hash-management` spec 的 Purpose，并保持 OpenSpec archive 不变。
- [x] 3.2 更新 `qtserver/docs/config.md`、`deploy.md` 和 `jyszdeploy.md`，删除 Qtserver PostgreSQL 部署、DSN 和 migration 指引，改为 Redis AOF 运行边界并说明旧 `[postgres].dsn` 仅被忽略。
- [x] 3.3 更新 `docs/mcdlvsdeploy.md`、`docs/zhichuanyun-client-installer-outline-design.md` 和 `qtransc/docs/TEST_PLAN.md` 中的 Qtserver PostgreSQL 旧说明，不删除属于 `qtlogsim` 或业务日志参考架构的 PostgreSQL 事实。
- [x] 3.4 修正 `qtlogsim` 现行说明中声称 Qtserver 仍拥有 PostgreSQL 的句子，同时保持 `qtlogsim` 自身 PostgreSQL 契约、代码与依赖不变。

## 4. 编译与静态校验

- [x] 4.1 对修改的 Go 源码执行格式化，执行 Qtserver 必需的编译检查，并对修改的 shell 脚本执行语法检查；不运行 test 或 benchmark。
- [x] 4.2 严格校验 OpenSpec change，执行 whitespace 检查和聚焦搜索，确认 Qtserver 当前运行/部署材料不再依赖 PostgreSQL，剩余匹配仅属于 legacy 输入兼容、`qtlogsim` 真实依赖或历史归档。
