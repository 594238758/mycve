## MODIFIED Requirements

### Requirement: 配置 schema 严格且 secrets 不泄漏

Qtserver SHALL 拒绝未知或已删除的配置字段，不从环境变量覆盖配置。`qtserver run` SHALL 只允许 `--port`、`--host`、`--loglevel` 和 `--logpath` 覆盖。作为存量配置的过渡兼容，配置 MAY 包含只带字符串 `dsn` 字段的 `[postgres]` section；Qtserver SHALL 完全忽略该值，不建立 PostgreSQL 连接、不校验 DSN、不执行 migration，也不得在普通日志或配置输出中暴露它。`[postgres]` 内其他字段和其余未知配置仍 SHALL 被拒绝。普通日志和配置输出 SHALL redact Redis password、HMAC secret、fake token keys、Authorization 和 anonymous token。

#### Scenario: config validate

- **WHEN** 运维运行 `config validate`
- **THEN** 命令 SHALL 只执行配置和本地路径的只读校验
- **AND** SHALL NOT 连接 Redis、PostgreSQL 或身份服务，也 SHALL NOT 创建目录

#### Scenario: 使用旧 PostgreSQL 配置

- **WHEN** 配置包含只带字符串 `dsn` 的 `[postgres]` section 且其他字段均有效
- **THEN** validate 和启动 SHALL 接受该配置
- **AND** Qtserver SHALL 忽略 DSN 且不产生任何 PostgreSQL 网络访问

#### Scenario: 使用其他未知配置字段

- **WHEN** 配置包含 `[postgres]` 下除 `dsn` 之外的字段、非字符串 `dsn`、其他已删除字段或未知字段
- **THEN** validate 和启动 SHALL 失败
