## Context

参见 `proposal.md`。当前 Qtserver 已删除 PostgreSQL package、migration CLI 和直接 module 依赖，配置通过 Viper `UnmarshalExact` 保持严格 schema；因此旧 `[postgres]` 会在解码阶段失败。配置的 `String()` 会输出 JSON 诊断文本并对现有 secrets 做 redaction。仓库根 `go.work` 同时加载仍真实使用 PostgreSQL 的独立 `qtlogsim` module，所以 workspace 级 module graph 出现 `pgx` 不代表 Qtserver binary 依赖它。

此外，`qtserver/deploy/install_local.sh` 仍调用已删除的 migration 命令，`scripts/e2e_business_logging.sh` 仍把同一个 PostgreSQL 实例同时写入 Qtserver 配置和 `qtlogsim` 配置，多份现行部署文档仍描述旧架构。OpenSpec archive 则记录当时事实，不能按当前实现反向改写。

## Goals / Non-Goals

**Goals:**

- 用最小兼容载体接受旧 `[postgres].dsn`，同时保持其他配置字段严格校验。
- 确保 DSN 只在配置解码期间短暂存在，返回的运行时配置、日志与配置输出均不保留该值。
- 清理所有仍把 PostgreSQL 当作 Qtserver 依赖的可执行部署流程与现行说明。
- 在共享验收脚本中清楚分离 Qtserver 的 Redis AOF 依赖与 `qtlogsim` 自己的 PostgreSQL 依赖。

**Non-Goals:**

- 不恢复 Qtserver PostgreSQL 连接、health check、migration、schema、hash 状态或 `pgx` 依赖。
- 不替换或删除 `qtlogsim` 的 PostgreSQL 最终结果存储。
- 不删除或改写 OpenSpec archive、Git 历史和历史验收产物。
- 不改变 HTTP、WebSocket、上传下载协议或文件 hash 行为。

## Decisions

### 1. 使用严格的私有兼容结构，而不是通用 map

在配置模型中加入仅供解码使用的 legacy section，mapstructure 名为 `postgres`，只声明字符串 `dsn`，并从 JSON 输出中排除。`UnmarshalExact` 因此仍会拒绝 `[postgres]` 下的其他字段和所有其他未知配置。解码成功后立即把 legacy 值清零，运行时组件不得读取它。

选择该方案是因为接受旧 section 本身必然需要一小段兼容代码；明确结构能把残留代码和接受面限制到一个字段。使用 `map[string]any` 虽然代码更少，但会静默吞掉拼写错误和未知字段；在读取 TOML 前做文本删除则容易错误处理 quoted string、重复 table 和 TOML 语义，均不采用。

### 2. 兼容输入不进入默认值、生成配置或运维输出

默认配置、demo config 和部署样例继续只生成 Redis。Qtserver 不为 legacy section 设置默认值，不校验 DSN，不探测 PostgreSQL，也不输出弃用警告中的值。兼容行为只解决存量配置升级，不把该 section 重新定义为有效运行参数。

### 3. 可执行流程按组件职责清理

`install_local.sh` 删除 migration 调用。业务日志端到端脚本保留 PostgreSQL 容器和 DSN，因为 `qtlogsim` 仍需要它，但从 Qtserver TOML 删除 `[postgres]` 并删除 Qtserver migration；同时让脚本中的 Redis 满足 Qtserver 已有 AOF、`everysec` 和 `noeviction` preflight，避免清理后仍因旧 Redis 启动参数失败。

### 4. 只更新现行事实，保留有价值的历史与独立依赖

更新 Qtserver 配置/部署文档、qtransc 现行测试计划、仓库根部署说明以及 `qtlogsim` 文档中声称“Qtserver 自己仍有 PostgreSQL”的过时句子。仍描述 `qtlogsim` 或业务日志参考架构自身 PostgreSQL 的内容保持不变。OpenSpec archive 不修改；主 `file-hash-management` 的 Purpose 属于现行规范概述，直接修正为 Redis 状态机。

## Risks / Trade-offs

- [静默接受 DSN 可能掩盖运维尚未清理旧配置] → 默认和文档不再生成该字段，只把它定义为迁移兼容输入；未知 sibling 仍严格失败。
- [DSN 可能包含 secret] → legacy 字段使用 `json:"-"`，解码后立即清零，错误和日志不得拼接其值。
- [仓库搜索仍能发现 PostgreSQL] → 明确保留 `qtlogsim` 的真实依赖和 archive 历史；验收标准按“Qtserver 当前依赖和现行说明”而不是字面零匹配判断。
- [共享 E2E 中 PostgreSQL 容器易被误认为 Qtserver 依赖] → 变量和注释明确其只服务 `qtlogsim`，Qtserver 配置不再引用 DSN。

## Migration Plan

1. 发布兼容版本后，旧配置可原样保留 `[postgres].dsn` 并启动；新安装和新生成配置不再包含该 section。
2. 运维确认 Qtserver 只连接 Redis 且 Redis AOF preflight 正常后，可在任意维护窗口删除旧 `[postgres]` section，并独立下线仅服务旧 Qtserver 的 PostgreSQL。
3. `qtlogsim` 使用的 PostgreSQL 按其自身生命周期继续运行，不与 Qtserver Redis 迁移绑定。
4. 回滚到仍依赖 PostgreSQL 的旧 Qtserver 版本时，必须恢复相应 PostgreSQL 服务和旧配置；本变更不提供 hash 状态双写或自动回填。
