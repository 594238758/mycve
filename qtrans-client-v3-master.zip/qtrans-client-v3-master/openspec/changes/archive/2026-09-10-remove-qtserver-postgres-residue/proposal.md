## Why

Qtserver 已移除 PostgreSQL 运行时依赖，但本地安装脚本、端到端验收脚本和现行部署文档仍包含已删除的 migration 命令或 PostgreSQL 部署步骤，会误导运维并直接导致安装失败。同时，当前严格配置解析会拒绝仍带有旧 `[postgres]` section 的存量配置，不利于平滑升级。

## What Changes

- Qtserver 配置兼容识别旧 `[postgres].dsn`，但完全忽略该值，不建立连接、不校验 DSN、不执行 migration，也不在日志或配置输出中暴露它；`[postgres]` 内其他未知字段仍按严格 schema 拒绝。
- 默认配置、生成配置和新部署说明继续不包含 `[postgres]`，该 section 只作为存量配置的过渡兼容输入。
- 删除 Qtserver 安装与验收流程中已失效的 `qtserver db migrate` 调用，并移除只为 Qtserver hash 状态准备 PostgreSQL 的步骤。
- 更新 Qtserver、qtransc 与仓库根目录中仍描述 Qtserver PostgreSQL 依赖的现行部署、配置和验收文档。
- 修正主 `file-hash-management` spec 的旧 Purpose 表述，使其与 Redis hash 状态机一致。
- 保留 OpenSpec archive 中的历史事实；保留独立 `qtlogsim` 对其自身 PostgreSQL 最终结果存储的真实依赖，相关脚本只删除 Qtserver 对 PostgreSQL 的使用。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `service-capability-discovery`: 将旧 `[postgres].dsn` 从必须拒绝的配置改为可识别但完全忽略的兼容输入，同时维持其余配置字段的严格校验。

## Impact

- 配置契约：旧配置无需先删除 `[postgres].dsn` 即可通过 validate 和启动；新配置仍不得生成或依赖该 section。
- 代码：仅保留解析兼容所需的最小旧字段载体，不恢复 `pgx`、数据库 package、migration CLI、连接检查或 health check。
- 部署与验收：影响 `qtserver/deploy/install_local.sh`、业务日志端到端脚本中的 Qtserver 启动部分，以及现行部署文档；`qtlogsim` 自身的 PostgreSQL 参数、schema 和依赖不变。
- HTTP、WebSocket、上传下载协议和 qtransc wire contract 均不变。
