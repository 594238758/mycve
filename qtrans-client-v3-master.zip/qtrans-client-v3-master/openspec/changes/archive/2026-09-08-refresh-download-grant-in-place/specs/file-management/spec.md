## MODIFIED Requirements

### Requirement: grant 保持现有taskid HMAC绑定和无Redis状态

download grant SHALL 保留现有body/query taskid和HMAC兼容绑定；默认TTL900秒、最小60秒。grant SHALL 自验证且不存Redis、不续期、不支持revoke。X-Task-ID仅用于日志，header与grant taskid不同不影响授权。qtransc在下载期间刷新grant时 SHALL 使用相同grant taskid，并 SHALL 保留已经建立的分片布局、已传输offset、分片完成状态和增量hash状态。

#### Scenario: grant过期后原地续传

- **WHEN** qtransc下载收到410 `GRANT_EXPIRED`
- **THEN** qtransc SHALL 使用相同grant taskid重新申请grant
- **AND** SHALL 使用新grant根据现有分片offset发起Range请求
- **AND** SHALL NOT重新加载`.progress`、重新准备全部分片或重新hash已下载数据

#### Scenario: 多个并发分片发现同一grant过期

- **WHEN** 同一文件的一个或多个并发分片发现当前grant过期
- **THEN** qtransc SHALL 停止继续发起使用该过期grant的请求
- **AND** SHALL 对该文件只执行一次grant刷新
- **AND** 等待中的分片 SHALL 复用刷新后的grant继续传输

#### Scenario: grant刷新时远端文件大小变化

- **WHEN** 新grant返回的文件大小与初始分片布局对应的大小不同
- **THEN** qtransc SHALL 将其报告为远端文件已变化并停止该文件下载
- **AND** SHALL NOT使用旧分片布局下载已变化的远端文件

## ADDED Requirements

### Requirement: download恢复准备支持取消

qtransc从`.progress`恢复下载并读取本地数据重建分片hash时 SHALL 响应任务context取消，且 SHALL 保留已持久化的断点数据供后续恢复。

#### Scenario: 本地恢复hash期间暂停任务

- **WHEN** GUI在qtransc读取已有分片并重建hash期间暂停或终止任务
- **THEN** qtransc SHALL 中断恢复准备并退出当前传输
- **AND** SHALL NOT等待全部已有分片完成hash后才响应取消
