## Why

大文件断点下载期间 grant 过期后，qtransc 当前会重新执行整个文件的分片准备，并重新读取、哈希所有已下载数据。已下载数据量较大时，准备耗时可能超过新 grant 的 TTL，造成 grant 不断过期、任务永久停滞，同时暂停操作也会被不可中断的本地哈希延迟。

## What Changes

- 初次下载准备只执行一次；grant 过期后保留分片进度、哈希状态和待下载队列，原地申请新 grant 并继续 Range 下载。
- 同一文件多个并发分片同时发现 grant 过期时，只执行一次文件级 grant 刷新；其余分片等待或复用已刷新的代次。
- 首个 grant 过期响应会及时终止仍使用旧 grant 的同级请求，避免过期请求风暴。
- 刷新后的文件大小与初始布局不一致时，将其识别为远端文件变化并停止下载。
- 初始恢复阶段读取本地数据并重建哈希时响应 context 取消，使暂停和终止能够及时生效。
- 不改变 qtserver HTTP API、CLI 参数或 GUI 协议，无需迁移。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `file-management`: 明确 download grant 过期后的原地刷新、并发协调、远端文件变化检测及恢复哈希可取消行为。

## Impact

- 主要影响 `qtransc/internal/downloadtask` 的文件下载调度、分片请求和恢复哈希流程。
- qtserver 的 grant API 与 900 秒默认 TTL 保持不变。
- `.progress` 格式、已有断点数据和外部接口保持兼容。
