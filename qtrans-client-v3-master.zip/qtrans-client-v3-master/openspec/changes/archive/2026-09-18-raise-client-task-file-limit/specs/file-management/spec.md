## MODIFIED Requirements

### Requirement: qtransc 递归规划在传输前完成并有固定上限

qtransc 的每个 upload/download task SHALL 在传输 bytes 前完成选择展开、路径规范化、映射校验和普通文件去重。最终计划 SHALL 最多包含 100000 个普通文件；该限制同时适用于显式文件、多 source、目录递归、serve 任务以及 upload2/download2 的内部适配。递归规划仍限制 200000 总 entries、128 深度、1024-byte remote path 和 255-byte segment。任一 list 返回 `truncated=true` SHALL 使整个目录任务失败；不得使用前100000项启动部分任务。

超过普通文件上限或其他 planning limit 时，qtransc SHALL 在远端或本地目录创建、内容传输和 download grant 请求前失败。普通文件数超过上限 SHALL 使用 `TASK_FILE_LIMIT_EXCEEDED`；目录不计入 100000 文件数，但继续计入既有总 entries 上限。

#### Scenario: 目录超过服务端list上限

- **WHEN** 规划中的任一list响应`truncated=true`
- **THEN** qtransc SHALL 在传输开始前报“目录超过10万条目，无法启动任务”并失败

#### Scenario: 直接qtransc list被截断

- **WHEN** 用户直接list一个返回truncated的目录
- **THEN** 文本模式 SHALL 一个entry也不显示，只输出错误并非零退出
- **AND** `--json` SHALL 在stdout输出单一JSON error object且不得包含部分entries

#### Scenario: 任务展开超过文件数上限

- **WHEN** upload 或 download 任务去重后包含 100001 个普通文件
- **THEN** qtransc SHALL 以 `TASK_FILE_LIMIT_EXCEEDED` 结束 planning
- **AND** SHALL NOT 创建本地或远端目录、传输 bytes 或申请 download grant

#### Scenario: 超过递归总entries

- **WHEN** 多层目录累计超过200000项
- **THEN** qtransc SHALL 在传输前以planning错误失败
