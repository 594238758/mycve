## 1. 共享客户端上限

- [x] 1.1 将已有的 `transferlimits.MaxTaskFiles=100000` 工作区修改纳入实现，并让 `TASK_FILE_LIMIT_EXCEEDED` 的客户端回退文案从共享常量得到上限；以 `cd qtransc && go build ./...` 成功验证编译。

## 2. 规范与文档同步

- [x] 2.1 更新主 `file-management` 与 `client-error-contract` 规范，以及未归档 `improve-server-argument-errors` delta 中的任务文件数阈值；以定向 `rg` 确认活动规范不再将客户端任务上限写为 10000。
- [x] 2.2 更新 `qtransc/docs/qtransc-apis.md` 的规划限制、显式 `file_list`、错误说明和字段表，将客户端任务上限统一为 100000；以定向 `rg` 确认所有相关说明一致，保留无关的端口和服务端限制。

## 3. 范围验证

- [x] 3.1 复查 CLI、serve、upload2 与 download2 均经共享 `MaxTaskFiles` 校验，且变更不修改 qtserver 限制或归档历史；运行 `cd qtransc && go build ./...`、`openspec validate raise-client-task-file-limit --strict` 与 `git diff --check`。
