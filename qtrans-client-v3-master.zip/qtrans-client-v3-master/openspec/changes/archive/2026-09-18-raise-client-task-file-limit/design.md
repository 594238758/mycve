## Context

qtransc 的普通 CLI、serve 和兼容入口已通过 `transferlimits.MaxTaskFiles` 使用同一任务规划阈值；当前工作区中该共享常量已经是 100,000。仍有客户端错误的回退文案、主 OpenSpec、未归档 delta 和 qtransc API 文档保留 10,000，因此可观察契约与实际代码不一致。

参见 proposal.md 与本变更的 delta specs。

## Goals / Non-Goals

**Goals:**

- 让所有 qtransc 入口以同一个 100,000 普通文件边界规划任务并报告错误。
- 让主规范、待归档 delta 与面向调用方的 API 文档一致。
- 保留现有稳定原因码、HTTP 状态与 JSON wire schema。

**Non-Goals:**

- 不修改 qtserver 的 list、grant、small download 或单文件大小限制。
- 不提高递归规划 200,000 total entries / 128 depth 限制，也不增加分页或新的服务端配额。
- 不更改历史 archive 中的 OpenSpec 产物，也不改写已正确记载 100,000 的 `qtransc/docs/DESIGN.md`。

## Decisions

### 共享常量继续作为唯一代码阈值

保留 `transferlimits.MaxTaskFiles` 作为规划、显式 file_list 验证和兼容入口的唯一数值来源，并采用工作区已有的 100,000 修改。只修复仍硬编码 10,000 的错误回退文案，避免出现两个可观察阈值。

不为各入口单独设置配置值：这会改变客户端跨 CLI、serve 与旧协议的一致性，并引入配置兼容与状态恢复问题，超出本次单一固定上限的范围。

### 100,000 与既有限制保持独立

100,000 是去重后的普通文件数，而非目录项总数、单层 list 数或单次 grant 数。一个 100,000 文件任务仍可能因 200,000 总枚举 entries、128 深度、路径规则或单个 1,000 文件 grant 批次而失败或被拆分。这些限制分别约束不同资源，不能随文件数上限一并放开。

### 文档与未归档 delta 同步

更新 qtransc API 文档的所有任务文件数表述，并更新主 OpenSpec。`improve-server-argument-errors` 尚未归档且包含完整的旧 `client-error-contract` requirement copy；同步其中的阈值，防止它日后归档时重新写回 10,000。归档产物是历史记录，保持不动。

## Risks / Trade-offs

- [100,000 文件的计划占用更多内存、SQLite 状态和网络调度时间] → 保留全部既有 entries、深度、grant batch 与单文件保护；本次不承诺性能提升。
- [只改一个入口产生行为漂移] → 使用共享常量并审计 CLI、serve、upload2、download2 的引用链。
- [未来归档旧 delta 覆盖新规范] → 同步仍未归档的完整 delta requirement；不修改 archive 历史。

## Migration Plan

1. 发布新 qtransc 二进制后，原本因 10,001 至 100,000 个去重普通文件被拒绝的任务可直接提交。
2. 调用方无需改请求格式；只有超过 100,000 才会收到既有 `TASK_FILE_LIMIT_EXCEEDED`。
3. 回滚到旧二进制会恢复 10,000 边界；远端数据和任务 wire schema 不受影响。
