## Why

客户端当前的任务普通文件数限制、错误文案和 API 文档仍有 `10,000` 的不一致表述，阻止需要处理大目录的 upload/download 任务。用户要求将 qtransc 客户端侧限制统一放宽到 `100,000`，避免调用方与实际行为不一致。

## What Changes

- 将 qtransc 共享任务规划上限从 10,000 个去重普通文件调整为 100,000 个，继续覆盖前台 CLI、serve、upload2 与 download2。
- 更新本地 `TASK_FILE_LIMIT_EXCEEDED` 的人类可读文案与阈值场景，使错误明确反映 100,000 上限。
- 同步主 OpenSpec、尚未归档的相关 OpenSpec delta，以及 qtransc API 文档中的任务创建、`file_list` 与错误说明。
- 保持 200,000 总枚举条目、128 层目录深度、服务端单次 grant 1,000 个对象和所有单文件大小限制不变。

## Capabilities

### New Capabilities

- 无。

### Modified Capabilities

- `file-management`: 将 qtransc upload/download 最终去重普通文件计划上限改为 100,000。
- `client-error-contract`: 将本地任务文件数超限的可观察阈值场景更新为 100,000。

## Impact

- 修改 `qtransc/internal/transferlimits` 与 `qtransc/internal/clienterror`；已有共享上限常量继续作为所有入口的唯一来源。
- 修改 `qtransc/docs/qtransc-apis.md`、主 OpenSpec 与一个未归档 delta；`qtransc/docs/DESIGN.md` 已经正确记载 100,000，无需改写。
- 扩大 serve `POST /api/v1/tasks` 可接受的 `file_list` 范围，兼容现有调用方；超过 100,000 才返回既有 `TASK_FILE_LIMIT_EXCEEDED`，wire 字段和错误原因码不变。
