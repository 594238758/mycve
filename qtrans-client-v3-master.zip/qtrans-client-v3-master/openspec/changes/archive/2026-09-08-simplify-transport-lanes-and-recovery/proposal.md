## Why

qtransc 需要同时保留文件分片并发和多连接带来的独立拥塞控制能力，但当前网络池直接管理 HTTP/2/HTTP/3 连接与 stream 状态，重复承担了标准库和 quic-go 已经实现的协议容量、GOAWAY 与连接替换职责，并已在服务端并发上限较小时暴露 `REFUSED_STREAM` 导致任务失败的问题。需要重新划清业务调度、网络 lane 与协议库的边界，使服务端容量不足只造成排队或性能下降，暂时性服务故障可以恢复，而客户端代码保持简单。

## What Changes

- 明确两层并发模型：业务层以文件并发和单文件分片并发约束同时推进的数据操作，网络层以每 origin 的 `connections` 个连接 lane 和每 lane 的 `streams` 个本地在途请求约束传输容量；业务容量超过网络容量时必须形成可取消的背压，而不是创建无界网络请求或报容量错误。
- 每个连接 lane 使用独立、可复用的高层 HTTP Transport：`https` 使用 HTTP/1.1 Transport，`https2` 使用完整的 Go HTTP/2 Transport，`https3` 使用 quic-go HTTP/3 Transport。qtransc 不再直接调度对端 stream credit，也不自行实现 SETTINGS、MAX_STREAMS、GOAWAY 或可安全协议重放的判断。
- 保留多 lane 以获得多个独立 TCP/QUIC 拥塞控制上下文；请求优先分散到可用 lane，再受每 lane 的本地 `streams` 上限约束。`connections`、`streams` 继续表示客户端上限，不声明服务端实际容量，也不要求启动时预建全部连接。
- 服务端发布的 HTTP/2/HTTP/3 stream 容量由标准库或 quic-go 阻塞等待；本地和对端容量等待不计入业务重试次数。第一版不增加 lane 级熔断或退避状态，最终返回的网络错误释放 lane 后交给业务分片恢复，下一次尝试重新选择 lane。
- 将返回给 qtransc 的结果统一分为：容量等待、可用性恢复、有限语义修复和永久失败。连接失败、临时 DNS/握手错误、HTTP `408/429/502/503/504` 等可用性错误采用带上限的指数退避和 jitter，但不使用固定次数或固定 30 秒无进展作为终止条件；活动传输持续恢复直到任务 context 取消、用户停止、显式总期限到达或出现永久错误。
- 上传在响应结果不确定时继续先查询服务端确认的 offset 再恢复，不盲目重放可能已经写入的 PATCH；下载分片可重新请求相同范围。授权刷新、offset/Range 协调、哈希不一致和 HTTP `500` 等语义修复保持独立的有限次数规则。
- 不新增或重命名 CLI 参数，不修改 qtserver HTTP API。现有命令仍将 `--transfers` 解析为文件并发，并按当前兼容规则得到任务内的单文件分片并发；本变更只固定这些有效值进入两层调度后的行为。
- **BREAKING**：活动 upload/download 遇到持续可用性故障时不再因统一的 30 秒网络重试窗口自动失败或进入 `stopped`；它们保持可恢复状态并持续退避，直至显式终止条件出现。

## Capabilities

### New Capabilities

- `client-transfer-concurrency`: 定义 qtransc 文件/分片业务并发、连接/请求网络并发、连接 lane、背压以及协议库容量管理之间的可观察关系。

### Modified Capabilities

- `file-management`: 将统一的 30 秒网络重试窗口拆分为可取消的持续可用性恢复与有限语义修复，并保持不确定 mutation 不盲重试。
- `service-capability-discovery`: 修改活动传输在 Qtserver 暂时退出后的停止条件，使已开始的可恢复传输持续退避等待服务恢复，而不是固定 30 秒后停止。

## Impact

- 受影响代码：`qtransc/internal/transportpool`、`qtransc/internal/netclient`、`qtransc/internal/downloadtask`、`qtransc/internal/uploadtask` 以及直接传输并发解析路径。
- 依赖边界：继续使用 Go `net/http` 与 quic-go，不新增第三方依赖；网络层从低层 `ClientConn`/显式 stream 容量管理迁移到高层 Transport。
- 外部行为：transport 名称、URL、`connections`/`streams` 范围、CLI 参数和 qtserver API 不变；容量不足时可能观察到更长等待，活动任务在服务暂时不可用时不再自动于 30 秒后终止。
- 资源影响：多 lane 仍可按需建立多条连接；业务并发和网络并发均为上限，排队请求必须可取消，且实现不得按 `connections * streams` 预创建同等数量的常驻 goroutine。
- 规格关系：本变更是 `define-versioned-https-transports` 的后续设计修正；不改变 `https|https2|https3` 的固定协议映射，但替换其低层连接管理决策。上传断点事实继续遵守 `resumable-upload`，不确定 mutation 继续遵守 `file-management` 的安全边界。
