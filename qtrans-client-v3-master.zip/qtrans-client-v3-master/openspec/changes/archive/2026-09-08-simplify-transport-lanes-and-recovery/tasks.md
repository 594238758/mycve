## 1. 两层并发与 lane 基础

- [x] 1.1 审核 upload/download 的 `FileConcurrency`、`ChunkConcurrency` 及直接命令并发推导路径，保持现有输入和公式，并确保大文件分片通过固定上限渐进调度而不为全部分片预建 goroutine。
- [x] 1.2 将每 origin 的网络池改为最多 `connections` 个轻量 lane，每条 lane 维护独立高层 RoundTripper 和最多 `streams` 个本地在途 lease；`https` lane 容量固定为 1。
- [x] 1.3 实现 spread-first 的最少负载 lane 选择和统一可取消等待，使业务容量超过 `connections * streams` 时形成背压，并保持请求失败、Body EOF/Close、未使用 release、取消和 pool Close 路径恰好一次归还容量。
- [x] 1.4 保持 transport/origin 隔离、origin 数量上限和空闲资源关闭，不在 pool 初始化时 Dial，也不按 `connections * streams` 创建常驻 goroutine。

## 2. 高层协议 Transport

- [x] 2.1 将 `https` lane 改为独立、只启用 HTTP/1.1 的 `http.Transport`，限制每 lane 一条 host 连接并保留代理、TLS 和严格协议选择行为。
- [x] 2.2 将 `https2` lane 从 `NewClientConn` 迁移到独立、只启用 HTTP/2 的完整 `http.Transport.RoundTrip`，配置单 lane host 连接上限和 `HTTP2.StrictMaxConcurrentRequests`，并保留 `h2` ALPN 强校验。
- [x] 2.3 删除 TCP pool 对 `ClientConn.Available/Reserve/Release/SetStateHook`、协议错误文本和 `ready/draining/failed` 状态的依赖，让 SETTINGS、REFUSED_STREAM、GOAWAY 和内部连接替换由 Go Transport 处理。
- [x] 2.4 审核 `https3` lane 继续使用 `http3.Transport.RoundTrip`，保留 per-origin physical connection permit、UDP 资源回收、QUIC 配置和 pool Close 行为，不新增 MAX_STREAMS 或 GOAWAY 自定义判断。

## 3. 请求可重建性与错误分类

- [x] 3.1 为上传 PATCH 提供可重建相同文件范围的 `Request.GetBody`，使安全协议重试重新应用限速与进度包装，并确保实际重传字节计入网络发送量而确认进度不重复增长。
- [x] 3.2 审核下载 GET、授权、控制和 complete 请求的 body 可重建性，只有无请求体、可重建 body 或既有幂等契约允许的请求才能使用 Transport 安全重试。
- [x] 3.3 将 transport 相关错误包装统一改为 `%w`，为请求体本地 I/O 建立稳定错误类型，并集中按 context、TLS/ALPN/config、本地 I/O、网络错误和 HTTP status 分类，禁止依赖 REFUSED_STREAM、GOAWAY 等错误字符串。
- [x] 3.4 实现共享 `Retry-After` 解析和可用性退避：1 秒指数增长到最多 5 秒、20% jitter，兼容 delta-seconds 与 HTTP-date，并确保退避前释放 response body 和 lane lease。

## 4. 上传与下载恢复

- [x] 4.1 将上传 transport 错误及 HTTP `408/429/502/503/504` 接入可取消的持续恢复；PATCH 结果不确定时先获取服务端确认 offset，complete 只按幂等契约恢复，并保留 SQLite 状态。
- [x] 4.2 将下载授权、控制请求和分片的 transport 错误及 HTTP `408/429/502/503/504` 接入统一恢复队列，使文件级临时失败重新调度且已成功文件不重复下载。
- [x] 4.3 将 HTTP `500` 限制为每个可恢复操作最多 3 次自动重试，保持 401 每请求最多 refresh 一次、hash mismatch、session/namespace busy、offset 和 Range 修复的既有有限预算，预算耗尽后不得转入持续可用性恢复。
- [x] 4.4 删除活动传输的统一 30 秒网络终止窗口，使前台和 serve 任务持续恢复到 context 取消、用户停止、显式总期限或永久错误；保持现有任务状态集合，并对等待日志与进度通知限频。
- [x] 4.5 确保每次业务恢复重新 Acquire 网络容量且不固定到原物理连接；第一版不增加 lane failure count、retryAt、熔断或自适应并发状态。

## 5. 定向测试与验证

- [x] 5.1 增加 lane 调度测试，覆盖 spread-first、多 origin/transport 隔离、`connections * streams` 上限、响应体期间占用、FIFO/可取消等待、错误和 Close 的容量归还。
- [x] 5.2 增加 HTTPS2 测试，覆盖服务端 `SETTINGS_MAX_CONCURRENT_STREAMS` 小于客户端 `streams`、首次 SETTINGS 并发、REFUSED_STREAM 安全恢复、GOAWAY 和连接替换，并验证上传请求体可重建和进度不重复。
- [x] 5.3 增加恢复策略测试，覆盖 Retry-After 两种格式、408/429/502/503/504 持续恢复、500 三次上限、401 单次刷新、context 取消、本地 I/O 永久失败和不确定 mutation 不重放。
- [x] 5.4 按既有 Nginx 测试文档执行 upload/download：64 个 500 MiB 文件和 1 个 10 GiB 文件，覆盖客户端连接数超过服务端能力、请求并发限制、HTTP/2/HTTP/3 单连接 stream 上限、graceful reload、强制退出和恢复，并校验全部文件内容一致。
- [x] 5.5 对修改的 Go 文件执行 gofmt，编译 qtransc 全部生产包，运行与本 change 直接相关的定向测试，并执行 `openspec validate simplify-transport-lanes-and-recovery --strict`；只报告需要人工同步的 `docs/` 位置，不自动改写 human-maintained docs。
