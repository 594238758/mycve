## Context

参见 `proposal.md` 的动机和三份 delta spec 的行为契约。

qtransc 已经在任务对象中区分 `FileConcurrency` 与 `ChunkConcurrency`，直接传输命令把 `--transfers` 作为文件并发，并以 `max(1, connections * streams / transfers)` 计算单文件分片并发。网络侧 `transportpool` 则按 transport 和 origin 管理 connection lane 与一次性 lease。当前 `https2` lane 直接使用 Go 1.26 `http.Transport.NewClientConn`，外层根据 `ClientConn.Available`、`Reserve` 和状态 hook 调度请求；连接刚建立但尚未处理服务端首个 SETTINGS 时，Go 暂以 100 作为 HTTP/2 并发上限，外层会提前放入大量请求，Nginx 的较小上限因而产生 `REFUSED_STREAM`。直接 `ClientConn.RoundTrip` 又绕过完整 HTTP/2 Transport 的连接选择和安全重试循环，最终错误可使下载授权或分片调度失败。

现有 HTTP/3 driver 已经让每条 lane 使用高层 `http3.Transport.RoundTrip`，并通过 per-origin physical connection permit 保留 QUIC 连接硬上限；这个方向应保留。新的共同边界是：qtransc 只管理业务操作和本地 lane 名额，高层 Transport 管理一条 lane 内的协议连接与对端 stream credit。

现有主规格把 transport 和 HTTP `408/429/500/502/503/504` 统一放在连续 30 秒无进展窗口中，Qtserver fatal shutdown 也要求窗口结束后停止任务。这会把服务端容量拒绝和暂时重启变成终态失败，因此本变更同时调整活动传输的恢复边界。

## Goals / Non-Goals

**Goals:**

- 保留文件并发、单文件分片并发、连接数和每 lane 请求数四个独立维度，不把业务调度与网络容量合并为一个参数。
- 让多 lane 在有需求时形成多条独立 TCP/QUIC 连接，以保留多拥塞窗口带来的吞吐能力。
- 使用 Go `http.Transport` 与 quic-go `http3.Transport` 的高层路径处理 SETTINGS、MAX_STREAMS、REFUSED_STREAM、GOAWAY 和安全连接替换。
- 让本地或对端容量不足表现为可取消等待，让已经返回的可用性错误在业务分片边界恢复。
- 保持请求副作用安全：上传结果不确定时按服务端 offset 恢复，不把“网络错误”直接等同于“请求未发送”。

**Non-Goals:**

- 不新增独立的文件并发或分片并发 CLI 参数，不改变现有直接命令的并发推导规则。
- 不探测 Nginx 的 `worker_connections`、`limit_conn` 或未通过协议发布的全局容量，也不试图学习一个精确服务端连接上限。
- 第一版不实现 lane 熔断、失败惩罚、半开探测或 AIMD 自适应并发；这些只在实测证明失败 lane 造成明显重连风暴后另行设计。
- 不自动切换 `https|https2|https3`，不改变严格 ALPN、TLS 校验、代理和 QUIC window 配置。
- 不修改 qtserver HTTP API、上传 chunk 格式、下载 Range 语义或持久化 schema。

## Decisions

### 1. 业务调度和网络准入保持两个串联边界

业务层继续维护最多 `F=FileConcurrency` 个活动文件，并让每个大文件最多运行 `P=ChunkConcurrency` 个分片操作；理论数据操作上界为 `F * P`。分片列表由固定 worker/launch semaphore 渐进消费，不为全部分片一次性创建 goroutine。现有直接命令继续使用：

```text
F = transfers
P = max(1, floor(connections * streams / transfers))
```

网络层独立维护 `C=connections` 条 lane、每 lane 最多 `S=streams` 个本地在途请求，网络准入上界为 `C * S`。业务操作先产生请求需求，再等待网络 lease；因此 `F * P > C * S` 时自然在 Acquire 阶段背压，不需要让业务层反向读取协议 stream 状态。

容量 lease 覆盖完整 RoundTrip 和响应体消费期。等待 lease 只使用任务 context，不启动可用性错误退避，也不被当作一次请求失败。备选方案“把四个参数折叠为全局请求并发”被拒绝，因为它无法表达文件公平性、单文件分片能力或多连接拥塞窗口目标。

### 2. origin pool 预建轻量 lane 描述，但连接仍按需建立

每个 origin pool 创建 `connections` 个轻量 lane，每条 lane 包含独立高层 RoundTripper、本地 `inflight` 计数和关闭边界，但初始化时不 Dial、不启动与 `connections * streams` 等量的 goroutine。物理连接由首次分配到该 lane 的 RoundTrip 按需建立。

调度采用 spread-first 的最少负载规则：先选择尚无在途请求的 lane，再选择 `inflight/streams` 较小且未满的 lane；全部 lane 达到本地上限时进入同一个可取消等待队列。该规则使并发需求达到 lane 数时可以尽早建立多条连接，而不是等第一条连接达到服务端 stream 上限后才扩展。连接失败后的下一次业务尝试重新参与选择，不保存对某个物理连接的亲和关系。

备选方案“只使用一个共享 Transport”最简单，但当服务端单连接 stream 上限很高时通常只形成一条 HTTP/2 或 HTTP/3 连接，无法实现用户配置多拥塞窗口的目标。备选方案“每条 lane 自己解析协议容量”正是当前复杂度来源，因此被拒绝。

### 3. HTTPS 与 HTTPS2 lane 使用完整 `http.Transport`

每条 TCP lane 持有独立 `http.Transport`：

- `https` 只启用 HTTP/1.1，`MaxConnsPerHost=1`，本地 lane 容量固定为 1。
- `https2` 只启用 HTTP/2，继续执行 `NegotiatedProtocol == "h2"` 的严格 ALPN 校验，设置 `MaxConnsPerHost=1`，并启用 Go 1.26 `HTTP2.StrictMaxConcurrentRequests`，使服务端 SETTINGS 生效后多出的 RoundTrip 在 Transport 内等待而不是由 qtransc 自行预留 stream。

qtransc 不再调用 `NewClientConn`、`ClientConn.Available`、`Reserve`、`Release` 或 `SetStateHook`，也不维护 TCP `ready/draining/failed` 协议状态。完整 `http.Transport.RoundTrip` 负责缓存与替换内部连接，并执行其能够证明安全的 REFUSED_STREAM、GOAWAY 或陈旧连接重试；最终返回给 qtransc 的错误才进入业务恢复判断。

每条 Transport 的连接池限制为一个连接，以使 lane 能稳定代表一个独立连接通道；Go 在关闭或替换内部连接期间的精确时序由标准库负责，qtransc 只保证 lane 数和本地在途请求数。origin pool Close 依次关闭各 Transport 的 idle/internal 资源并唤醒本地等待者。

备选方案“为新 HTTP/2 连接增加 SETTINGS-known/bootstrap 状态”可以修补初始竞争，但仍要求 qtransc 维护协议状态和 REFUSED_STREAM 兼容判断，长期维护成本更高。

### 4. HTTPS3 保留高层 Transport 和物理连接 permit

每条 `https3` lane 继续持有独立 `http3.Transport` 并调用其 `RoundTrip`。quic-go 通过同步打开 request stream 等待对端 QUIC stream credit，并负责 GOAWAY 后淘汰内部 client connection 和安全单次重试；qtransc 不读取 MAX_STREAMS，也不解析未导出的 HTTP/3 错误。

现有 per-origin physical connection permit 继续包裹 HTTP/3 Dial，因为它只执行用户要求的实际 QUIC 连接硬上限和 UDP 资源回收，不参与 stream 调度或重试判断。该 permit 与本地 lane lease 是两个边界：前者限制正在 Dial 和存活的 QUIC 连接，后者限制业务请求数。

备选方案“删除 physical permit 并完全依赖每 lane Transport”会在 GOAWAY 排空与替换重叠时弱化既有 `connections` 实际连接硬上限，本变更不扩大这一行为变化。

### 5. 所有可安全协议重试都要求请求体可重建

下载 GET 没有请求体；使用 `bytes.Reader`、`bytes.Buffer` 或 `strings.Reader` 构造的控制请求继续获得可重建 body。上传 PATCH 当前使用带进度与限速包装的 `io.SectionReader`，实现需要提供 `Request.GetBody` 工厂，在标准库确认请求未被处理且决定安全重试时重新创建相同 offset、长度、限速和进度包装。

重建 body 的每次实际读取都计入网络发送量；文件完成进度继续以服务端确认 offset 为准，不能因重传读数重复增长。若 Transport 无法证明请求未处理，或错误发生在请求可能已部分写入后，PATCH 错误返回业务层，先 GET session/offset 再决定剩余范围。qtransc 不匹配 REFUSED_STREAM 错误字符串来扩大自动重试范围。

### 6. 返回结果集中分为等待、可用性恢复、语义修复和永久失败

本地或协议容量等待发生在 RoundTrip 完成之前，不进入结果分类。标准 Transport 已完成内部处理后，qtransc 对返回值按以下顺序判断：

```text
task context 已结束
  -> 取消/停止，不重试

收到 HTTP response
  -> 408/429/502/503/504：可用性恢复
  -> 500：有限 3 次语义重试
  -> 401：同一请求最多 refresh 1 次
  -> offset/range/hash/session 状态：按现有专用修复规则
  -> 其他永久响应：失败

只有 error、没有 response
  -> TLS 证书、ALPN、配置、本地文件读取错误：永久失败
  -> 连接、临时 DNS/握手、超时、EOF、QUIC 连接错误：可用性恢复
  -> 未知错误：保留错误链并由调用操作的保守策略处理
```

共享 classifier 只识别 context、标准 typed/wrapped error 和 HTTP status，不使用协议错误文本。所有 `client.Do` 包装必须使用 `%w` 保留 `errors.Is/As`；请求体本地读取错误需要以稳定 sentinel 或 typed error 与网络错误区分，避免磁盘故障进入持续重试。

### 7. 可用性恢复没有固定次数，但始终可取消且不占住 lane

可用性失败先关闭可能存在的 response body、释放 lane lease，再从 1 秒指数退避到 5 秒并加 20% jitter；合法 `Retry-After` 形成下一次尝试的最早时间。退避结束后，业务分片或控制操作重新进入正常网络 Acquire，因此可以选择另一条 lane，真实连接是否复用或重建仍由该 lane 的 Transport 决定。

活动传输不再使用固定 30 秒无进展窗口终止可用性恢复；终止只来自任务 context、用户 pause/cancel、显式总期限或永久错误。前台进程保持运行并输出限频等待信息；serve task 保持现有状态集合中的活动状态，不新增 `waiting` 状态。上传 SQLite 与下载 progress 状态在等待期间持续保留。

这里的“持续”不是在一次 `client.Do` 内循环，也不是无延迟重试：每次尝试都释放网络资源、响应取消并经过退避。HTTP `500`、认证刷新、hash mismatch、session/namespace busy 和状态协调仍遵守各自有限预算，不能在预算用尽后改名为可用性错误继续循环。

### 8. 第一版不实现 lane 级退避

高层 Transport 已合并同一 lane 的并发 Dial 并处理内部连接复用；业务可用性恢复又自带有界指数退避与 jitter。第一版因此不额外保存 lane failure count、retryAt、half-open probe 或健康状态，以避免在协议库外再建一个近似连接状态机。

当客户端 lane 数高于 Nginx 能接受的连接数时，部分请求可能在失败 lane 返回错误；它们释放名额并由业务层退避后重新参与 spread-first 选择，其他成功 lane 继续传输。这可能产生额外失败和较低吞吐，但不应造成终态失败。Nginx 压力测试需要记录无进展、错误率和连接尝试频率；只有证据显示请求级 jitter 仍造成不可接受的重连风暴时，才以独立 change 增加最小 lane cooldown。

## Risks / Trade-offs

- [独立 Transport lane 比单 Transport 使用更多内部对象] → lane 对象最多为已校验的 `connections`，不预建连接或 `connections * streams` 个 goroutine；关闭 origin 时统一释放。
- [服务器接受的连接数小于 lane 数时会反复出现失败尝试] → 业务恢复先释放容量并使用指数退避与 jitter，下一次不固定原连接；通过压力测试决定是否需要后续 lane cooldown，而不预先引入状态机。
- [HTTP/2 初始 SETTINGS 竞争仍可能在标准库内部发生] → 使用完整 Transport 的安全重试循环并为可安全重放的请求提供 `GetBody`；最终错误仍由分片恢复兜底。
- [持续可用性恢复可能让无人值守任务长期运行] → 明确依赖 context、用户停止和可选显式总期限，输出限频状态；不再用隐式 30 秒窗口替代调用方生命周期决策。
- [把所有无响应错误视为网络故障会掩盖本地磁盘错误] → 保留完整错误链并为请求体本地 I/O 添加稳定类型，classifier 先排除永久的本地/config/TLS/ALPN 错误。
- [每 lane 一个连接可能限制标准 Transport 自行扩展] → 这是有意约束，使 `connections` 明确控制独立拥塞窗口数量；扩展由 spread-first 创建更多 lane，而不是让单 lane 隐式突破边界。
- [现有 docs 可能暂时描述旧连接状态机和 30 秒窗口] → OpenSpec 先作为权威来源落地；按项目政策只报告需要人工修订的位置，本变更不自动改写 human-maintained docs。

## Migration Plan

1. 先替换 HTTPS/HTTPS2 lane 的内部 Transport 路径并保留现有外部 pool/lease 接口，使上传、下载调用点可以分阶段迁移。
2. 调整 origin lane 创建和 spread-first 调度，删除 TCP `ClientConn` 容量/状态判断，同时保持 origin 隔离、关闭和本地 lease 恰好一次归还。
3. 为可安全重放请求补齐 body 重建，集中结果分类并把上传、下载恢复接到新的持续可用性策略。
4. 使用 Nginx 的低 HTTP/2 stream、低请求/连接限制、HTTP/3 stream credit、graceful reload、强制退出和恢复场景验证上传与下载；容量受限时允许吞吐下降，但任务不得仅因此终止。
5. 发布不需要配置、CLI、HTTP API 或持久化迁移。回滚到旧二进制时连接池和状态文件仍兼容，但活动任务会恢复旧的 30 秒网络停止行为。
