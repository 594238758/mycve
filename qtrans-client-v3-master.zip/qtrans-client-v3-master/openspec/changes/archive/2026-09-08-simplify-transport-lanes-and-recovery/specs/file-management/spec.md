## MODIFIED Requirements

### Requirement: qtransc retry有界且mutation不盲重试

qtransc SHALL 对需要修复业务语义后才能继续的失败使用有限次数策略：HTTP `500` 对可恢复传输操作 SHALL 最多自动重试 3 次并使用退避；hash `202` 轮询不计入该次数；`SESSION_BUSY` 与 `NAMESPACE_BUSY` 继续使用各自最多 30 秒窗口；同一请求收到 `401` 后 SHALL 最多 refresh 一次。move、delete 或其他非幂等 mutation 在结果不确定时 SHALL NOT 自动重复执行。

可恢复传输操作即使同时符合可用性恢复条件，也 SHALL 先遵守其安全语义：PATCH 在响应不确定时先查询服务端确认的 offset，下载重新请求确定的文件范围，complete 仅按幂等结果契约恢复。有限语义修复用尽后 SHALL 返回对应业务失败，而 SHALL NOT 把同一状态重新归类为无限可用性恢复。

#### Scenario: PATCH响应不确定

- **WHEN** PATCH连接在response前断开
- **THEN** qtransc SHALL 先GET offset再决定重传

#### Scenario: complete响应不确定

- **WHEN** complete请求断连
- **THEN** qtransc MAY 幂等重试complete或GET session

#### Scenario: move断连

- **WHEN** move可能已经完成但response丢失
- **THEN** qtransc SHALL 报告不确定结果且不得自动重复mutation

#### Scenario: HTTP 500重复失败

- **WHEN** 一个可恢复传输操作连续收到 HTTP `500` 且已完成 3 次自动重试
- **THEN** qtransc SHALL 停止自动重试该操作并报告服务端业务失败

## ADDED Requirements

### Requirement: qtransc 可用性恢复持续至明确终止

活动 upload/download 遇到 transport 错误、临时 DNS 或握手错误、HTTP `408`、`429`、`502`、`503` 或 `504` 时，SHALL 将对应操作视为可用性恢复候选。每次失败尝试 SHALL 先释放网络容量，再从 1 秒开始指数退避到最多 5 秒并加 20% jitter；响应携带合法 `Retry-After` 时 SHALL 同时支持 delta-seconds 与 HTTP-date，并 SHALL 以不早于该值的时间开始下一次尝试。

上述可用性恢复 SHALL NOT 使用固定尝试次数或固定 30 秒无进展窗口作为终止条件。只要任务 context 仍有效、用户未停止、显式总期限尚未到达且没有永久错误，qtransc SHALL 持续重新调度操作并保持可观察的等待或重试状态。该规则 SHALL NOT 允许盲目重放结果不确定的非幂等 mutation，也 SHALL NOT 覆盖本规格中的有限语义修复上限。

#### Scenario: Nginx连接限制返回503

- **WHEN** 一个可恢复上传或下载操作因 Nginx 容量限制收到 HTTP `503`
- **THEN** qtransc SHALL 释放本次请求占用的网络容量并退避后重新调度该操作
- **AND** SHALL NOT 仅因累计超过 30 秒或固定次数而终止任务

#### Scenario: 服务返回HTTP-date Retry-After

- **WHEN** 可重试响应携带合法 HTTP-date `Retry-After`
- **THEN** qtransc SHALL 以该时间约束下次尝试

#### Scenario: 可用性恢复期间取消任务

- **WHEN** 操作正在退避等待且任务 context 被取消
- **THEN** qtransc SHALL 及时停止等待并按既有取消或停止语义结束任务

#### Scenario: 不确定mutation遇到可用性错误

- **WHEN** move 或 delete 可能已经生效但响应丢失
- **THEN** qtransc SHALL 保持不确定结果并 SHALL NOT 因 transport 错误属于可用性候选而自动重放该 mutation
