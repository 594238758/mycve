## Purpose

定义 qtransc 如何把文件和分片的业务并发映射到按 origin 隔离的连接 lane 与本地请求容量，并在不自行实现 HTTP/2、HTTP/3 协议流量控制的前提下提供可取消背压和多连接传输能力。

## ADDED Requirements

### Requirement: 业务层分别约束文件并发和单文件分片并发

qtransc SHALL 分别维护文件并发上限和单个活动文件的分片并发上限。对需要分片的大文件，同时处于数据传输阶段的文件数 SHALL NOT 超过文件并发上限，每个文件同时执行的分片操作 SHALL NOT 超过其分片并发上限；因此任务的数据分片操作上界 SHALL 为两者乘积，但实现 SHALL NOT 因文件包含大量分片而一次性创建与全部分片数量相同的常驻 goroutine。

#### Scenario: 多文件并行分片传输

- **WHEN** 文件并发为 3、单文件分片并发为 4，且至少有 3 个各含 4 个待传分片的大文件
- **THEN** qtransc SHALL 允许最多 3 个文件同时推进
- **AND** 每个文件 SHALL 最多同时执行 4 个分片操作
- **AND** 同时执行的数据分片操作 SHALL NOT 超过 12 个

#### Scenario: 单个文件包含大量分片

- **WHEN** 一个活动文件包含的待传分片数大于其分片并发上限
- **THEN** qtransc SHALL 只调度上限内的分片操作，并在已有操作完成后继续调度剩余分片

### Requirement: 网络层以连接 lane 和本地请求上限约束容量

qtransc SHALL 为每个 transport 与规范化 origin 维护最多 `connections` 个相互独立的连接 lane。`streams` SHALL 表示一条 lane 同时准入的本地在途 HTTP 请求上限；`https` 的该值 SHALL 固定为 1，`https2` 与 `https3` SHALL 使用有效配置值。每个请求从获准进入 lane 起，直到请求失败、无响应体请求完成、响应体读到 EOF 或响应体关闭期间 SHALL 占用一个本地名额。

`connections` 与 `streams` SHALL 仅定义客户端上限，不声明服务端实际连接或 stream 容量。连接 SHALL 按需建立；当业务需求和服务端能力足够时，qtransc SHALL 能将请求分散到多个 lane，使 `connections` 能形成多个独立物理连接，而 SHALL NOT 要求先耗尽第一条连接的对端 stream 容量后才使用其他 lane。

#### Scenario: 本地网络容量上限

- **WHEN** 一个 `https2` origin 配置 `connections=4`、`streams=8`
- **THEN** qtransc SHALL 为该 origin 维护最多 4 个连接 lane
- **AND** 每条 lane SHALL 最多准入 8 个本地在途请求
- **AND** 该 origin SHALL NOT 准入超过 32 个本地在途请求

#### Scenario: 多连接承载并发请求

- **WHEN** 至少有 `connections` 个并发请求、服务端接受相应连接且本地未受其他资源限制
- **THEN** qtransc SHALL 能让不同 lane 按需建立相互独立的物理连接并承载请求

#### Scenario: 响应体仍未消费完成

- **WHEN** 一个请求已收到响应头但响应体尚未读完或关闭
- **THEN** 该请求 SHALL 继续占用所在 lane 的一个本地请求名额

### Requirement: 本地容量不足形成可取消背压

当业务层可执行的分片操作数超过网络层本地容量时，超出部分 SHALL 等待 lane 名额，而 SHALL NOT 因容量不足被报告为传输失败。容量等待 SHALL NOT 增加业务重试次数或启动可用性错误退避；等待 SHALL 在名额释放后继续，并 SHALL 在任务 context 取消、显式总期限到达或网络池关闭时及时结束且不泄漏容量。

#### Scenario: 业务并发大于网络容量

- **WHEN** 文件与分片调度产生的可执行操作数大于 `connections * streams`
- **THEN** qtransc SHALL 只准入本地网络容量内的请求
- **AND** 其余操作 SHALL 等待容量释放而不计为失败尝试

#### Scenario: 容量等待期间取消任务

- **WHEN** 一个分片操作正在等待 lane 名额且任务 context 被取消
- **THEN** 该等待 SHALL 及时结束
- **AND** qtransc SHALL NOT 发送该请求或泄漏 lane 名额

### Requirement: 对端协议容量由所选传输协议约束

`https2` 的实际并发 HTTP/2 stream 数 SHALL NOT 超过对端发布的 `SETTINGS_MAX_CONCURRENT_STREAMS`，`https3` 的实际客户端请求 stream 数 SHALL NOT 超过对端授予的 QUIC stream credit。对端容量小于本地 `streams` 时，超出容量的请求 SHALL 在所选 transport 内等待或按协议保证安全的方式恢复，而 SHALL NOT 仅因该容量差异使文件或任务失败。qtransc SHALL NOT 通过额外业务探测请求猜测上述协议已明确发布的容量。

#### Scenario: HTTP2 服务端 stream 上限更小

- **WHEN** `https2` 的本地 `streams` 为 32，而服务端在一条连接上只允许 2 个并发 stream
- **THEN** 该连接实际同时活动的 HTTP/2 stream SHALL NOT 超过 2
- **AND** 其余已准入该 lane 的请求 SHALL 等待或由协议层安全恢复
- **AND** 任务 SHALL NOT 仅因该差异进入失败终态

#### Scenario: HTTP3 等待 stream credit

- **WHEN** `https3` 已用完对端允许的客户端双向 stream
- **THEN** 后续请求 SHALL 等待新的 QUIC stream credit 或其 context 结束
- **AND** qtransc SHALL NOT 把正常的 credit 等待计为一次失败重试

### Requirement: 最终网络错误释放容量并返回业务恢复

底层 transport 已完成其协议内安全处理后仍返回的网络错误 SHALL 结束当前请求尝试并释放对应 lane 名额。网络层 SHALL NOT 盲目重放无法证明未被处理的请求，也 SHALL NOT 要求业务层申请、持有或替换物理连接；业务层重新调度可恢复操作时 SHALL 重新获取网络容量，并 MAY 被分配到其他 lane。第一版 SHALL NOT 因单个 lane 的历史失败建立额外的持久熔断、健康探测或自适应并发状态。

#### Scenario: 一条 lane 建连失败而其他 lane 可用

- **WHEN** 客户端配置的 lane 数大于服务端当前可接受的连接数，且一次请求最终收到建连或传输错误
- **THEN** qtransc SHALL 释放失败请求占用的本地容量并把结果交给业务恢复策略
- **AND** 其他可工作的 lane SHALL 能继续传输
- **AND** 可恢复操作的下一次尝试 SHALL NOT 被固定到原失败物理连接

#### Scenario: 请求结果可能已经产生副作用

- **WHEN** transport 无法证明一个带请求体的操作尚未被服务端处理
- **THEN** 网络层 SHALL 返回该结果而不盲目重放请求
- **AND** 业务层 SHALL 按该操作的幂等或断点恢复契约决定后续动作
