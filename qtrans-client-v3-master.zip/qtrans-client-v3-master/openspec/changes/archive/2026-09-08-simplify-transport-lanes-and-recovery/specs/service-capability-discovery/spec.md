## REMOVED Requirements

### Requirement: fatal shutdown 后 qtransc 有界停止

**Reason**: 固定 30 秒网络重试窗口会使本可断点恢复的活动传输在 Nginx 或 Qtserver 暂时退出时过早停止，与容量限制和暂时故障只降低性能、不使任务失败的新恢复契约冲突。

**Migration**: 活动前台和 serve upload/download 改为遵守可取消的持续可用性恢复；需要有界执行的调用方应设置显式任务总期限或主动停止任务，而不再依赖隐式 30 秒窗口。

## ADDED Requirements

### Requirement: fatal shutdown 后活动传输保持可恢复

已开始的前台 upload/download 在 Qtserver 因 fatal dependency 退出或暂时无法连接时 SHALL 保留可恢复状态，并按 `file-management` 的可用性恢复契约持续退避，直到服务恢复、任务 context 取消、用户停止、显式总期限到达或出现永久错误。serve 中的活动任务在相同情况下 SHALL 保持可恢复的活动状态，而 SHALL NOT 仅因固定网络重试窗口结束自动进入 `stopped`。

本要求只适用于已经开始且具有安全恢复路径的传输；创建任务前的 capability 预检、配置错误、认证错误以及不可恢复业务错误 SHALL 继续按各自契约失败。未完成上传的 SQLite 状态和下载恢复状态 SHALL 在等待和显式停止后继续保留。

#### Scenario: 前台上传期间服务暂时退出

- **WHEN** Qtserver 在前台上传期间退出且超过 30 秒后恢复
- **THEN** qtransc SHALL 在任务未被取消且没有显式总期限到达时继续退避等待
- **AND** 服务恢复后 SHALL 从服务端确认状态继续上传

#### Scenario: serve上传期间服务暂时退出

- **WHEN** serve 中的活动上传任务暂时无法连接 Qtserver
- **THEN** 任务 SHALL 保持可恢复的活动状态并持续退避
- **AND** SHALL NOT 仅因经过固定 30 秒自动进入 `stopped`

#### Scenario: 等待服务恢复时显式停止

- **WHEN** 调用方在活动任务等待 Qtserver 恢复期间暂停、取消或使显式总期限到达
- **THEN** qtransc SHALL 及时结束恢复等待
- **AND** SHALL 按既有任务状态规则保留可恢复状态

#### Scenario: 创建任务前服务不可用

- **WHEN** qtransc 在创建任务前无法完成必要的 Qtserver capability 预检
- **THEN** qtransc SHALL NOT 创建任务
- **AND** SHALL 按既有契约报告服务不可用
