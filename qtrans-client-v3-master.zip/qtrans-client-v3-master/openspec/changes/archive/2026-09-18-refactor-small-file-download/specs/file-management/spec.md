## ADDED Requirements

### Requirement: small download v2 使用独立的可提交 mini-tar 协议

Qtserver SHALL 在 read/download 启用且 `small_download_v2` 可用时注册 `POST /qtserver/v1/d/small-v2`，并继续保留既有 `/qtserver/v1/d/small` v1 路由。v2 请求 SHALL 复用 v1 的 `taskid` 和非空 `files` 对象列表 wire contract。服务端 SHALL 在发送成功响应 headers 前完成所有对象的授权、打开、类型和大小校验，但 SHALL NOT 为构造响应而预先读取完整文件或预先计算整文件哈希。

v2 成功响应 SHALL 为流式 tar，条目顺序 SHALL 固定为：首个 `.qtrans/manifest.json`、manifest 顺序对应的 `payload/000000` 起连续十进制编号 payload、最后一个 `.qtrans/checksums.json`，随后正常结束 tar。Manifest SHALL 包含 `version=2`、`taskid`、`file_count`、`total_unpacked_bytes`、`hash_algorithm=layered_xxh3_128_v1`，以及每个文件的顺序编号、规范化 `object_key`、payload entry 名和字节大小；manifest SHALL NOT 包含预计算 hash。Checksum footer SHALL 使用相同版本、taskid、算法和文件顺序，并包含每个文件的编号、`object_key`、实际发送字节数和服务端边发送边计算的 hash。远端 `object_key` SHALL NOT 直接作为 tar payload 路径。

客户端 SHALL 拒绝重复、缺失、越序、未知或路径不匹配的控制及 payload 条目。只有 footer 完整、一致、所有本地计算 hash 匹配且 footer 后得到正常 tar EOF 时，响应 SHALL 被视为完成；footer 自身存在但 tar 尾部损坏 SHALL NOT 被视为成功。

#### Scenario: v2 正常响应

- **WHEN** 请求内全部对象在 headers 前通过校验且流式读取保持一致
- **THEN** Qtserver SHALL 返回按固定顺序组成的 v2 tar
- **AND** 每个文件 SHALL 只为响应 payload 读取一次
- **AND** checksum footer SHALL 反映实际发送字节和增量计算的哈希

#### Scenario: headers 前批次校验失败

- **WHEN** 任一对象在 headers 前发生授权、打开、类型或限制错误
- **THEN** 整批 SHALL 返回统一 JSON error
- **AND** SHALL NOT 开始 tar 响应

#### Scenario: footer 后 tar 未正常结束

- **WHEN** 客户端读到完整 checksum footer，但随后未得到合法 tar 结束
- **THEN** 当前尝试 SHALL NOT 被提交
- **AND** SHALL 按响应中断规则处理整个批次

#### Scenario: manifest 使用编号 payload

- **WHEN** 请求包含带特殊字符或多层目录的合法 `object_key`
- **THEN** manifest SHALL 保存规范化 `object_key` 与编号 payload 的映射
- **AND** tar payload entry 名 SHALL NOT 直接使用该远端路径

### Requirement: v2 small 批次同时受文件数和总字节数约束

Qtserver SHALL 对 v1 和 v2 保持当前默认硬限制：每批最多 100 个文件、单文件最多 4 MiB、总计最多 128 MiB；实际请求 SHALL 服从 capabilities 公布的当前有效值。qtransc 的 v2 调度目标 SHALL 为每批最多 100 个文件且最多 32 MiB，并 SHALL 同时取客户端目标与服务端限制的较小值。按已规划顺序加入文件时，只要加入下一文件会超过文件数或总字节数任一上限，qtransc SHALL 结束当前非空批次并开始下一批；最后一个非空不足目标的批次 SHALL 立即可调度，不得为凑满目标无限等待。

#### Scenario: 文件数先达到目标

- **WHEN** 100 个小文件总大小小于 32 MiB，且后续仍有小文件
- **THEN** qtransc SHALL 用前 100 个文件形成一个批次
- **AND** 后续文件 SHALL 进入下一批次

#### Scenario: 总字节数先达到目标

- **WHEN** 当前批次不足 100 个文件，但加入下一文件会使总大小超过 32 MiB
- **THEN** qtransc SHALL 结束当前非空批次
- **AND** 下一文件 SHALL 作为新批次的首个文件

#### Scenario: 最后一个批次未达到目标

- **WHEN** 小文件计划已遍历完成且当前批次非空
- **THEN** 该批次 SHALL 立即进入等待 lane 的可调度状态

### Requirement: 下载任务先收敛小文件阶段再进入大文件阶段

混合下载任务 SHALL 先处理 v2 小文件批次。小文件阶段中的每个文件 SHALL 达到成功、明确重分类为普通大文件或终态失败之一后，小文件阶段才 SHALL 收敛；随后 qtransc SHALL 使用既有普通下载链路和 `transfers` 约束处理原计划的大文件及重分类文件。第一版 SHALL NOT 同时运行小文件和大文件阶段。

服务端在开始 v2 响应前发现某个对象已超过当前 small 单文件限制、但未超过普通 `max_file_bytes` 时，SHALL 返回包含该 `object_key` 的稳定 `NOT_SMALL` 错误且不开始 tar。qtransc SHALL 将该文件移入大文件阶段，并使用批次剩余文件重新形成 small 批次；该重分类 SHALL NOT 作为任务错误。

#### Scenario: 混合任务阶段顺序

- **WHEN** 一个任务同时包含 small 文件和普通大文件
- **THEN** qtransc SHALL 先让 small 阶段收敛
- **AND** 在此之前 SHALL NOT 启动普通大文件数据传输

#### Scenario: 文件在请求前增长

- **WHEN** v2 批次中的一个文件已超过 small 单文件限制但仍可普通下载
- **THEN** Qtserver SHALL 在 headers 前返回指明该文件的 `NOT_SMALL`
- **AND** qtransc SHALL 将该文件转入大文件阶段并重新安排批次剩余文件
- **AND** SHALL NOT 把 `NOT_SMALL` 记录为最终错误

### Requirement: v2 小文件以批次为重试和收敛单位

v2 尝试在合法 footer 和 tar 结束前发生连接错误、超时、响应截断或 HTTP `408`、`429`、`502`、`503`、`504` 时，qtransc SHALL 丢弃当前尝试并按既有可用性恢复策略重试整个批次，直到成功、任务 context 取消、显式总期限到达或出现永久错误。HTTP `500` SHALL 以整个批次为操作单位应用既有“最多自动重试 3 次”的有界策略。格式完整的 v2 响应存在任一文件 hash mismatch 时，qtransc SHALL 重试整个批次，最多允许两次重新尝试，即最多三次完整传输；第三次仍 mismatch SHALL 形成终态完整性错误。

`401` refresh 次数、`Retry-After`、不可恢复认证或授权、业务对象不存在、本地磁盘错误以及其他既有错误分类 SHALL 保持原契约。结构非法但网络传输完整的 manifest、footer 或 tar SHALL 形成不可自动重试的协议错误。v2 批次内部重试 SHALL 独立于 recursive task 的“无文件成功则停止下一轮”规则；一次可恢复批次尝试没有文件完成 SHALL NOT 提前阻止本 Requirement 明确允许的下一次尝试。

#### Scenario: HTTP 500 后整批成功

- **WHEN** 一个 v2 批次首次请求收到 HTTP `500`，并在允许次数内重新请求成功
- **THEN** qtransc SHALL 重新请求整个批次
- **AND** 首次 `500` SHALL NOT 使任何批次文件形成最终失败

#### Scenario: HTTP 500 重试耗尽

- **WHEN** 一个 v2 批次在首次尝试后又完成 3 次自动重试且均收到 HTTP `500`
- **THEN** qtransc SHALL 停止自动重试该批次
- **AND** SHALL 将该业务失败作为终态错误

#### Scenario: 连续两次 hash mismatch 后成功

- **WHEN** 同一 v2 批次前两次完整响应均发生 hash mismatch，第三次全部匹配
- **THEN** qtransc SHALL 提交第三次批次结果
- **AND** 前两次 mismatch SHALL NOT 使任务最终状态异常

#### Scenario: 连续三次 hash mismatch

- **WHEN** 同一 v2 批次连续三次完整响应均发生 hash mismatch
- **THEN** qtransc SHALL 停止自动重试整个批次
- **AND** SHALL 报告终态完整性错误

#### Scenario: availability 重试不持有 lane

- **WHEN** 一个截断的 v2 响应需要退避后重试
- **THEN** qtransc SHALL 先关闭响应体并释放当前 lane
- **AND** 下一次整批尝试 SHALL 重新申请 lane

#### Scenario: 完整但非法的 footer

- **WHEN** HTTP 响应完整结束但 footer 的版本、taskid、文件集合或条目映射与 manifest 不一致
- **THEN** qtransc SHALL 报告终态协议错误
- **AND** SHALL NOT 将其归类为无限可用性恢复

## MODIFIED Requirements

### Requirement: qtransc 对下载hash mismatch只自动重下一次

普通下载第一次 file mismatch 时 qtransc SHALL 删除 `.progress` 并从零重下该文件一次；第二次仍 mismatch 时前台 SHALL 失败，serve task SHALL `stopped`。v1 small SHALL 保持只重下失败文件且每个文件最多重新下载一次。v2 small SHALL 以整个批次为完整性重试单位，允许两次重新尝试，即最多三次完整传输；第三次仍有任一文件 mismatch 时前台 SHALL 失败，serve task SHALL `stopped`。批量任务中已经通过普通或 v1 路径成功的其他文件 SHALL NOT 重下；v2 在批次通过 footer 提交门槛前 SHALL NOT 把其中的单文件视为已成功。

#### Scenario: 首次mismatch

- **WHEN** verify 返回 `match=false` 且该普通下载文件尚未因 mismatch 重下
- **THEN** qtransc SHALL 从零重下一次该文件

#### Scenario: 第二次mismatch

- **WHEN** 同一普通下载文件重下后再次 mismatch
- **THEN** 前台 SHALL 非零失败或 serve task SHALL stopped

#### Scenario: v2 首次或第二次 mismatch

- **WHEN** v2 批次第一次或第二次完整传输出现任一 hash mismatch
- **THEN** qtransc SHALL 丢弃本次整个批次的临时结果并重新传输整个批次

#### Scenario: v2 第三次 mismatch

- **WHEN** v2 批次第三次完整传输仍出现任一 hash mismatch
- **THEN** 前台 SHALL 非零失败或 serve task SHALL stopped
- **AND** SHALL NOT 启动第四次完整性尝试
