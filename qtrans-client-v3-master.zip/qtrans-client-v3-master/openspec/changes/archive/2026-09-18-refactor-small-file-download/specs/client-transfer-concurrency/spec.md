## ADDED Requirements

### Requirement: 小文件下载并发由网络 lane 独立约束

qtransc SHALL NOT 使用 `transfers` 限制 v2 小文件批次的并发数，也 SHALL NOT 让小文件批次占用普通大文件的文件并发名额。每个活动 v2 批次 SHALL 占用一个 HTTP 请求名额；本地最大活动批次数 SHALL 只受对应 origin 的可用 lane 容量以及其他共享该 origin 的在途请求约束，其中 `https` 的容量为 `connections`，`https2` 和 `https3` 的客户端容量上限为 `connections * streams`，实际容量仍 SHALL 服从对端协议限制。

#### Scenario: transfers 小于可用 lane 数

- **WHEN** `transfers=1`，所选 transport 有 8 个可用请求 lane，且至少有 8 个已成形的小文件批次
- **THEN** qtransc SHALL 允许最多 8 个 v2 小文件批次同时传输
- **AND** SHALL NOT 因 `transfers=1` 把活动小文件批次限制为 1 个

#### Scenario: 小文件和大文件使用不同并发约束

- **WHEN** 小文件阶段已经收敛并进入普通大文件阶段
- **THEN** 普通大文件 SHALL 继续受 `transfers` 和既有分片并发规则约束
- **AND** 小文件阶段使用过的并发数 SHALL NOT 改变大文件并发上限

### Requirement: 小文件 worker 只在批次和 lane 同时就绪后启动

qtransc SHALL 先形成非空小文件批次，再以可取消方式申请一个空闲 lane；只有申请成功后才 SHALL 启动负责该批次请求和响应消费的 worker。等待 lane 的批次 SHALL 作为调度状态存在，而 SHALL NOT 预先创建一组阻塞等待 lane 的 worker。一次尝试完成或失败后 SHALL 先关闭响应体并释放 lane，再成功结束、进入退避队列、重新分批或形成终态失败；重试退避期间 SHALL NOT 占用 lane。

#### Scenario: 所有 lane 正忙

- **WHEN** 已有请求占满所选 origin 的全部本地 lane 容量且仍有已成形的小文件批次
- **THEN** 后续批次 SHALL 等待容量释放
- **AND** qtransc SHALL NOT 为这些等待批次预先启动阻塞 worker
- **AND** 容量等待 SHALL NOT 计为失败尝试

#### Scenario: 失败批次进入退避

- **WHEN** 一个 v2 批次尝试收到可重试结果并需要等待后再次尝试
- **THEN** 当前响应体 SHALL 被关闭且 lane SHALL 被释放
- **AND** 退避结束后的新尝试 SHALL 重新申请任意可用 lane

#### Scenario: 等待 lane 时取消任务

- **WHEN** 一个已成形批次正在等待 lane 且任务 context 被取消
- **THEN** 等待 SHALL 及时结束
- **AND** SHALL NOT 启动该批次 worker或泄漏 lane 名额

### Requirement: 小文件优化不隐式扩大配置

本变更 SHALL NOT 改变 `connections`、`streams` 或 `transfers` 的默认值。qtransc SHALL 将每个 v2 mini-tar 作为普通独立 HTTP 请求交给所选 transport，并 SHALL NOT 自行分配、固定或管理 HTTP/2、HTTP/3 stream ID。

#### Scenario: 用户保留默认 streams

- **WHEN** 用户未显式增大 `streams`
- **THEN** qtransc SHALL 使用现有默认值计算本地 lane 容量
- **AND** SHALL NOT 因启用 v2 小文件下载自动改写该配置

#### Scenario: HTTP2 多流映射

- **WHEN** qtransc 在 `https2` transport 上并发发起多个 v2 批次请求
- **THEN** 底层 transport SHALL 将请求映射到协议 stream
- **AND** 应用层 SHALL NOT 依赖特定 stream ID 或请求到物理连接的固定映射
