## ADDED Requirements

### Requirement: v2 小文件批次使用尝试级临时状态

qtransc SHALL 将 v2 批次的每个 payload 写入目标路径旁由 qtransc 唯一命名和管理的临时文件，并在写入过程中计算 `layered_xxh3_128_v1`。这些临时文件 SHALL NOT 写入 upload state DB，也 SHALL NOT 作为普通下载 `.progress` 恢复状态。响应缺少完整 checksum footer、tar 未正常结束、条目不完整或任一哈希不匹配时，当前尝试的全部未发布临时文件 SHALL 被删除后才进入整批重试。

#### Scenario: footer 前连接中断

- **WHEN** 客户端已写完部分或全部 payload，但未收到完整合法的 checksum footer 和 tar 结束标记
- **THEN** 当前批次 SHALL NOT 被视为验证成功
- **AND** 当前尝试的全部未发布临时文件 SHALL 被删除

#### Scenario: 任务在批次传输中暂停

- **WHEN** v2 批次正在传输且任务被主动 pause
- **THEN** 当前请求 SHALL 被取消
- **AND** 当前尝试的未发布临时文件 SHALL 被清理
- **AND** pause SHALL NOT 把相关文件记录为失败

#### Scenario: 删除下载任务

- **WHEN** 调用方删除包含 v2 小文件临时状态的下载任务
- **THEN** qtransc SHALL 删除仍存在的 qtrans-owned 批次临时文件
- **AND** SHALL NOT 删除已经发布的用户目标文件

### Requirement: v2 批次先整体验证再逐文件发布

qtransc SHALL 在 footer、tar 结束、文件集合、大小和全部哈希验证成功前不把本批次任何新临时文件发布为最终目标。验证成功后 SHALL 逐文件原子替换对应目标；跨文件发布不承诺形成单个文件系统事务。发布某个文件失败时，已经成功发布的文件 SHALL 保持成功，尚未发布的临时文件 SHALL 被清理，失败文件 SHALL 形成终态本地错误且 SHALL NOT 仅为重试本地发布而重新下载整个批次。

#### Scenario: 全批验证成功

- **WHEN** v2 响应包含与 manifest 一致的全部 payload、合法 footer、匹配哈希和正常 tar 结束
- **THEN** qtransc SHALL 在验证全部文件之后才开始逐文件发布
- **AND** 全部发布成功时该批次 SHALL 成功

#### Scenario: 发布中途发生本地错误

- **WHEN** 批次验证成功，第一个文件已发布，但后续文件无法替换目标路径
- **THEN** 已发布文件 SHALL 保持成功且不得被删除
- **AND** 失败文件 SHALL 报告终态本地错误
- **AND** 尚未发布的 qtrans-owned 临时文件 SHALL 被清理

### Requirement: 尝试错误与任务最终错误分离

小文件 worker SHALL 返回可区分的成功、重试、转入大文件和终态失败结果。一次请求、stream 或完整性尝试产生的临时错误 SHALL 只进入该批次的重试状态，不得直接追加到任务最终错误；批次后来成功或其文件成功转入大文件链路后，历史尝试错误 SHALL NOT 使任务进入异常终态。只有永久错误或重试策略耗尽后仍未完成的文件 SHALL 贡献任务最终错误。

#### Scenario: 首次失败后整批成功

- **WHEN** 一个 v2 批次首次尝试失败并在后续尝试中完整成功
- **THEN** 该批次所有文件 SHALL 记为成功
- **AND** 首次尝试错误 SHALL NOT 出现在任务最终错误中

#### Scenario: 文件转入大文件阶段后成功

- **WHEN** 服务端确认批次中的一个文件已不符合 small 限制，且该文件随后通过普通下载成功
- **THEN** small 尝试结果 SHALL 只触发阶段迁移
- **AND** SHALL NOT 使最终任务状态异常

#### Scenario: 完整性重试耗尽

- **WHEN** 同一 v2 批次连续三次完整传输均发生哈希不一致
- **THEN** 第三次完整性错误 SHALL 成为终态错误
- **AND** 任务 SHALL 按既有状态分类结束

### Requirement: v2 实时字节进度与批次完成状态分离

qtransc SHALL 在读取每个 v2 payload entry 前把对应文件登记为活动文件，并在每次从响应成功读取正数字节且写入尝试临时文件时，同步推进该文件和任务的 live logical transferred bytes 与实际 network bytes。文件和任务的 rate SHALL 继续根据实际 network payload bytes 按既有不大于 300ms 的内存采样周期计算，且 SHALL 汇总同时活动的多个 mini-tar；tar control entry、header、padding 和业务日志等待时间 SHALL NOT 计入 payload progress 或 rate。

单个文件的 logical transferred 达到文件大小时，文件 MAY 显示 100%，但在整个批次 footer、全部 hash、tar EOF 和该文件本地发布完成前 SHALL 保持 `in_progress`，SHALL NOT 增加 `VerifiedFileNum` 或发布 completed 状态。批次全部验证后，客户端 SHALL 按实际逐文件发布结果连续发布最终文件 progress 和 completed 状态，因此完成文件数 MAY 在一个观察周期内批量增长。

批次尝试失败并准备重试时，qtransc SHALL 在删除尝试临时文件的同时把本批次尚未发布文件的 logical transferred 重置为 0；任务 logical progress MAY 因此回退。实际 network bytes SHALL 保留失败尝试已经接收的 payload，后续重传 SHALL 继续计入 network rate，但 logical transferred SHALL NOT 因重复接收同一文件而超过文件或任务 total。外部 CLI、REST、SSE 和兼容 WebSocket SHALL 继续读取同一组实时内存事实。

#### Scenario: v2 payload 仍在传输

- **WHEN** 一个 v2 payload entry 只读取并写入了部分字节
- **THEN** 对应文件和任务的 live transferred SHALL 已包含这些字节
- **AND** rate SHALL 能在当前批次完成前反映实际网络吞吐

#### Scenario: payload 已写完但 footer 尚未到达

- **WHEN** v2 批次中的文件 payload 已完整写入临时文件，但 checksum footer 尚未完成验证
- **THEN** 该文件的 logical transferred MAY 等于 total
- **AND** 文件 SHALL 保持 `in_progress`
- **AND** `VerifiedFileNum` SHALL NOT 因此增加

#### Scenario: 批次验证后集中完成

- **WHEN** v2 批次的 footer、全部 hash 和 tar EOF 验证成功且多个文件连续发布成功
- **THEN** 每个文件 SHALL 发布最终 progress 与 completed 状态
- **AND** 调用方 MAY 在一次观察快照中看到完成文件数增加多个

#### Scenario: 批次失败后重试

- **WHEN** v2 批次已经接收部分 payload 后因连接中断或完整性错误进入重试
- **THEN** 该批次未发布文件的 logical transferred SHALL 重置为 0
- **AND** 任务 progress MAY 回退后随下一次尝试重新增长
- **AND** 实际 network bytes 与 rate SHALL 保留并继续统计重试流量
