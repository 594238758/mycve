## MODIFIED Requirements

### Requirement: 小文件下载只记录完整发送成功

Small download SHALL 不输出 `file.registered`、开始、失败、重试、timeout 或 verify 事件，也 SHALL NOT 为 v2 新增其他原始业务事件类型。

对 v1，Qtserver 只有在一个小文件的 `io.Copy` 成功、实际字节等于 `file_size` 且显式 `tar.Writer.Flush()` 成功写完当前 entry padding 后，才 SHALL 立即输出一条 `download.small_file_sent`；未写完、字节数不符、当前 entry flush 失败、中途停止或其他写入失败 SHALL 不输出该文件的任何原始业务事件。Producer SHALL NOT 仅以 `io.Copy` 返回成功提前记录，也 SHALL NOT 等待整个批次 tar 关闭后才统一补写已完成文件。

对 v2，Qtserver SHALL 在每个 payload 内容和 entry padding 完整写入时确定该文件的 `download.small_file_sent` 内容与 `occurred_at`，但 SHALL 将该批次事件暂存在内存中。只有全部 payload entry 均完成后，Qtserver 才 SHALL 按 manifest 顺序批量 append 这些逐文件事件，并在该批次全部事件完成一次 sync 后发送 checksum footer。任一 payload 未完成时 SHALL 不 append 本批次暂存的任何事件；事件 append 或 sync 失败时 SHALL 不发送 footer。Footer 或后续 tar 结束写入失败 SHALL NOT 撤回已经持久化的发送事实。

`download.small_file_sent` SHALL 自包含最终记录需要的 `task_type`、`action=download`、`file_path`、`file_size`、`principal_id`、`client_username`、`client_id`、`client_ip`、`client_os`、`client_version`、`server_ip`、`server_instance`、`server_version` 和 `started_at`。这些上下文字段 SHALL 使用注册 payload 的相同类型规则；`started_at` SHALL 使用本 spec 固定的 UTC 三位毫秒格式且不得晚于 envelope `occurred_at`。Envelope `occurred_at` SHALL 是 Qtserver 完成该文件 payload entry 写入的时间，即使 v2 事件稍后才批量 append。

普通事件 family SHALL 与最早合法注册 action 匹配：`upload.*` 只可用于 upload，`download.*` 只可用于 download。事件早于注册、family 与 action 不匹配、注册四元组或 small 自包含四元组无法按本 spec 重算出 envelope file key 时，该事件 SHALL NOT 参与状态、deadline 或统计，并 SHALL 在 inspect 中报告。无注册普通事件 MAY 先保留在 ClickHouse，注册到达后再执行语义校验。

分析程序收到合法 small-file event 后 SHALL 立即形成 `SUCCESS/SMALL_FILE_SENT`，并设置 `transmitted=file_size`、`retry_count=0`、`start_time=started_at`、`end_time=occurred_at`。该事件只证明 Qtserver 已完整发送对应 payload entry，不证明客户端已收到 checksum footer、完成 tar 校验或发布本地文件。多个 v2 批次尝试 MAY 为同一 file key 产生多个真实发送事件；分析程序 SHALL 使用最早合法 small 成功事实且 SHALL NOT 从这些事件推导客户端重试次数。

多个小文件在同一响应中传输时 SHALL 按文件边界独立记录。v1 后续文件失败不得撤销此前已记录文件的成功；v2 任一 payload 失败 SHALL 使本批次暂存事件全部不写入，但 footer 写入失败不得撤销此前已经批量持久化的事件。

合法 small 成功 SHALL 对同一 `file_key` 具有终态优先级。客户端在 small 成功事件后因本地校验、tar 尾部或连接问题重试 v2 批次或改走普通下载时，后续 small、`file.registered`、`download.chunk_finished` 与 `download.verify_finished` MAY 保留在 ClickHouse 和 inspect 中，但 SHALL NOT 改变、补充或撤回现有 `SUCCESS/SMALL_FILE_SENT` 的任何最终字段。

零字节下载 SHALL 使用 small 路径而不是由 qtransc 根据 grant 响应直接在本地完成。v1 在 Qtserver 成功写入 header 并结束零长度 tar entry 后 SHALL 输出 `download.small_file_sent`；v2 SHALL 在全部 payload 结束后随批次持久化该零字节文件事件并在成功 sync 后发送 footer。其最终 `transmitted=0`、`retry_count=0`、`speed=null`。客户端随后无法创建本地空文件 SHALL NOT 改变该服务端成功事实。

#### Scenario: 小文件完整写完

- **WHEN** Qtserver 通过 v1 正常完成一个小文件全部内容和 entry padding 的响应写入
- **THEN** SHALL 立即输出一条自包含 `download.small_file_sent`
- **AND** 分析程序 SHALL 不等待其他事件即形成成功最终记录

#### Scenario: 当前tar entry flush失败

- **WHEN** v1 小文件内容字节已经全部复制，但 `tar.Writer.Flush()` 写当前 entry padding 失败
- **THEN** Qtserver SHALL NOT 输出该文件的 `download.small_file_sent`
- **AND** SHALL 停止当前 small 响应的后续文件

#### Scenario: 小文件中途断开

- **WHEN** Qtserver 未完成一个小文件的全部 payload 或 entry padding 写入
- **THEN** SHALL NOT 输出该文件的任何原始业务事件
- **AND** 分析程序 SHALL NOT 为该文件生成 TIMEOUT 或失败结果

#### Scenario: 批次中后续文件失败

- **WHEN** v2 批次的第一个 payload 已完整写出，但第二个 payload 中途失败
- **THEN** Qtserver SHALL NOT append 本批次任何暂存的 `download.small_file_sent`
- **AND** SHALL NOT 发送 checksum footer

#### Scenario: 批次尾部关闭失败

- **WHEN** v2 全部 payload 的逐文件事件已经批量 append 并 sync，但 checksum footer 或 tar 结束写入失败
- **THEN** 已持久化的逐文件成功事实 SHALL 保留
- **AND** 客户端 MAY 重试整个批次

#### Scenario: v2 重试形成重复发送事实

- **WHEN** 同一 file key 因 v2 批次重试产生多个合法 `download.small_file_sent`
- **THEN** 分析程序 SHALL 保持最早的 `SUCCESS/SMALL_FILE_SENT`
- **AND** SHALL NOT 将后续事件计入 transmitted 或 retry count

#### Scenario: small成功后客户端普通下载fallback

- **WHEN** 同一 file key 在 small 成功事件之后出现普通下载注册、chunk 或 verify 事件
- **THEN** 当前最终结果 SHALL 保持第一次 `SUCCESS/SMALL_FILE_SENT`
- **AND** 普通事件 SHALL NOT 计入 transmitted 或 retry count

#### Scenario: 零字节下载

- **WHEN** Qtserver 成功结束包含零字节文件的全部 v2 payload 并完成批次事件 sync
- **THEN** SHALL 为该文件持久化 `download.small_file_sent` 后发送 footer
- **AND** 最终记录 SHALL 是 `SUCCESS/SMALL_FILE_SENT` 且 transmitted 为 0、speed 为 null

### Requirement: 原始事件写入、轮转和凭据边界明确

Qtserver active 文件 SHALL 固定为 `log.file_path/business_events.log`；Nginx active 文件 SHALL 固定为 `/opt/qtrans/nginx/logs/download_events.log`。每个事件 SHALL 完整占一行并以换行结束；压缩 SHALL 只处理已经关闭的轮转段。Active 文件末尾未换行内容 SHALL 留待下次采集，关闭段中的不完整行 SHALL 被隔离。

Qtserver writer SHALL 串行 append 完整行，并在 `file.registered`、`upload.finished`、整文件 matched 的 `download.verify_finished` 以及 `download.small_file_sent` 上完成 sync 后才报告事件持久成功。v2 small 的同一批次多个 `download.small_file_sent` MAY 在同一个串行 writer 临界区内连续 append，并 SHALL 在全部完整行 append 后只执行一次 sync；sync 成功前 SHALL NOT 报告该批次事件持久成功。处于 logging-unhealthy 时 Qtserver SHALL 拒绝所有下一步会产生 schema v1 事件的传输或校验 API，而不只是新文件起点；不产业务事件的健康、恢复和查询操作 MAY 继续。Writer 或健康组件 SHALL 能在不写伪业务事件且不依赖事件生产 API 越过 gate 的情况下独立执行 reopen 与文件级 sync/状态探测；成功后 SHALL 先清除 gate，再恢复事件生产 API。恢复流程 SHALL NOT 因业务请求被 gate 拒绝而自锁。

Writer SHALL 在每次 append 前记录受同一串行锁保护的 active 文件边界。完整行已经写入但 sync 失败时 SHALL 只重试 sync，不得再次 append；partial write 后只有成功 truncate 并 sync 回写前边界时才 MAY 重试 append。v2 批量 append SHALL 对每个事件仍保留可恢复的行边界；任一行写入失败或最终 sync 失败 SHALL 使整个批量操作失败并进入 logging-unhealthy，但已经成为完整行的真实发送事实 SHALL NOT 被伪造为未发生。无法确认边界、truncate 失败或无法验证最后完整换行时 SHALL 保持 logging-unhealthy，不得盲目重写。独立恢复流程 MAY 截断 active 文件最后一个完整换行之后的不完整尾部并完成 sync；SHALL NOT 改写已经关闭的 segment。轮转 SHALL 与 append 使用同一串行边界。上述规则 SHALL 防止 producer 把一次 chunk 或 small payload 事实自身重复写成多个真实 attempt。

`file.registered` 写入或 sync 失败 SHALL 在业务动作前返回稳定、可重试的日志不可用错误。Qtserver 过程事件在请求业务事实已经发生后写失败 SHALL NOT 回滚已经接收、写入或校验的数据，当前请求 SHALL 返回其真实业务结果，同时 SHALL 进入 logging-unhealthy 并 gate 后续事件生产 API。Producer SHALL NOT 为促使重试而把已经成功接受的 PATCH 伪装成业务失败。

真实 committed、already-present 或整文件 verify matched 发生后，Qtserver SHALL 在对应终态事件 append 并 sync 成功前不向客户端返回成功。写入失败 SHALL NOT 回滚真实文件或 hash 一致事实，但当前请求 SHALL 返回可重试的日志不可用错误；客户端以后对同一幂等 API 重试时，Qtserver SHALL 能再次输出内容一致的成功事件并在持久成功后返回业务成功。分析程序 SHALL 使用最早合法成功事实，不要求 event ID。

Direct 下载响应完成后写 chunk 事件失败 SHALL NOT 回滚响应，但 SHALL 使 Qtserver logging-unhealthy 并接受本次统计事实缺失。v1 small 文件 entry 结束后 SHALL append 并 sync 其成功事件再开始下一个 entry；写入或 sync 失败 SHALL 停止继续生成该批次的后续文件响应、使 Qtserver logging-unhealthy 且不得撤回当前 entry，第一版接受当前文件成功事实缺失。v2 small SHALL 在全部 payload entry 结束后批量 append 逐文件成功事件并完成一次 sync；任一 append 或 sync 失败 SHALL 停止响应、不得发送 checksum footer 并使 Qtserver logging-unhealthy。Nginx access-log phase 写入失败 SHALL 通过 Nginx error log 与采集监控暴露，已发送响应不得回滚；第一版 SHALL NOT 要求 Nginx 反向修改 Qtserver 健康状态。

原始事件 SHALL NOT 包含 Authorization、access/refresh token、download grant、HMAC secret、anonymous fixed token、TLS key、请求 body 或其他 credential。客户端 metadata SHALL 只用作日志上下文，服务端权威身份、IP、路径、大小、hash 与发布结果 SHALL 使用已验证事实。

#### Scenario: commit 后日志写入失败

- **WHEN** 文件已原子发布但 `upload.finished` 无法写入
- **THEN** Qtserver SHALL NOT 回滚已发布文件
- **AND** 当前 complete 请求 SHALL 返回可重试的日志不可用错误
- **AND** SHALL 进入 logging-unhealthy 并拒绝后续事件生产 API

#### Scenario: writer恢复后重试已提交文件

- **WHEN** writer 恢复后客户端重试一个文件已经 committed 但终态日志曾失败的 complete 请求
- **THEN** Qtserver SHALL 再次构造内容一致的 `upload.finished{result=committed}` 并可靠写入
- **AND** 写入成功后 SHALL 返回业务成功

#### Scenario: 过程事件写入失败

- **WHEN** 上传 chunk 数据已经被接受但对应 `upload.chunk_finished` 最终无法写入
- **THEN** Qtserver SHALL NOT 回滚或伪造未接收该数据
- **AND** 当前 PATCH SHALL 返回已经接受数据的真实业务结果
- **AND** SHALL 进入 logging-unhealthy 并拒绝后续事件生产 API

#### Scenario: 完整行写入后sync失败

- **WHEN** writer 已确认当前 chunk 事件完整行存在但后续 sync 失败
- **THEN** writer SHALL 只重试 sync 且不得再次 append 该事件
- **AND** 分析结果 SHALL NOT 因 writer 恢复产生虚假的额外 attempt

#### Scenario: partial write无法安全回滚

- **WHEN** writer 发生 partial write 且无法 truncate 并 sync 回写前边界
- **THEN** SHALL 保持 logging-unhealthy 且不得盲目重写该行
- **AND** 独立恢复流程 SHALL 只清除 active 文件最后完整换行之后的不完整尾部

#### Scenario: small事件写入失败

- **WHEN** 当前 v1 small tar entry 已经结束但 `download.small_file_sent` 无法写入
- **THEN** Qtserver SHALL NOT 撤回已经写出的 entry
- **AND** SHALL 停止继续写该批次后续文件并进入 logging-unhealthy

#### Scenario: small事件sync成功后继续批次

- **WHEN** 当前 v1 small tar entry 结束且其 `download.small_file_sent` 已经 append 并 sync 成功
- **THEN** Qtserver MAY 开始写下一个文件 entry
- **AND** 后续 entry 失败 SHALL NOT 撤回当前文件成功事实

#### Scenario: v2 批次事件只 sync 一次

- **WHEN** 一个 v2 批次的全部 payload entry 已完成且所有逐文件事件完整 append
- **THEN** writer SHALL 对该批次执行一次文件级 sync
- **AND** Qtserver SHALL 仅在 sync 成功后发送 checksum footer

#### Scenario: v2 批次事件 sync 失败

- **WHEN** v2 批次事件完整 append 后 sync 失败
- **THEN** writer SHALL 只恢复或重试 sync 而不得再次 append 同一发送 attempt
- **AND** Qtserver SHALL NOT 发送 checksum footer
- **AND** SHALL 进入 logging-unhealthy

#### Scenario: 内部 handoff header

- **WHEN** Nginx 返回一个普通下载响应
- **THEN** 所有 Qtserver 提供的日志 handoff header SHALL 对客户端隐藏

## ADDED Requirements

### Requirement: v2 批次重试细节只进入 debug log

qtransc 和 Qtserver SHALL 使用既有 debug logging 通道记录 v2 small 的调度与重试诊断信息，而 SHALL NOT 为 batch、attempt、lane 获取、footer 校验或客户端发布新增 schema v1 原始业务事件类型。每个客户端批次 SHALL 使用仅用于诊断关联的 `batch_id`；相关 debug 记录 SHALL 至少能够关联 `batch_id`、当前 `attempt`、文件数、计划总字节数、transport、结果分类以及适用时的 retry 分类和下次尝试时间。服务端能够取得客户端传入的 batch 关联值时 MAY 记录同一 `batch_id`，但 SHALL NOT 将其当作授权或业务文件身份。

Debug log SHALL NOT 输出批次完整文件列表、Authorization、token、download grant、HMAC secret、请求 body 或本地临时文件内容。业务事件仍 SHALL 只表达服务端逐文件完整发送事实；debug attempt 数 SHALL NOT 被分析程序解释为业务日志的 `retry_count`。

#### Scenario: 批次发生可恢复错误

- **WHEN** 一个 v2 批次尝试因 HTTP `500`、连接中断或 hash mismatch 进入重试
- **THEN** qtransc SHALL 写入包含同一 `batch_id`、递增 `attempt`、结果分类和 retry 分类的 debug 记录
- **AND** SHALL NOT 为该重试新增原始业务事件类型

#### Scenario: 批次最终成功

- **WHEN** 一个经历过重试的 v2 批次最终验证并发布成功
- **THEN** debug log SHALL 能通过 `batch_id` 关联各次尝试和最终 completed 结果
- **AND** 原始业务日志 SHALL 继续按最早合法 `download.small_file_sent` 形成既有最终结果

#### Scenario: debug log 保护敏感与高基数字段

- **WHEN** qtransc 或 Qtserver 记录 v2 批次诊断信息
- **THEN** 记录 SHALL NOT 包含凭据、请求 body 或批次完整路径列表
- **AND** `batch_id` SHALL NOT 参与认证、授权或 file key 计算
