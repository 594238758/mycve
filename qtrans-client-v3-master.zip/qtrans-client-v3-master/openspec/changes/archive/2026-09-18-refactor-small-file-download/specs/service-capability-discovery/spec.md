## ADDED Requirements

### Requirement: capabilities 显式公布 small download v2

支持 v2 mini-tar 的 Qtserver SHALL 在 `capabilities` 中公布 `small_download_v2`，其值 SHALL 使用与其他 capability 相同的 `enabled`、`available` 结构，并 SHALL 与全局 `download` 能力同时启用或关闭。服务端批次硬限制 SHALL 继续通过 `limits.small_files`、`limits.small_file_bytes` 和 `limits.small_total_bytes` 公布，v2 的哈希算法 SHALL 通过 `algorithms` 中的 `layered_xxh3_128_v1` 公布。客户端 SHALL 根据 capability 字段选择协议，而 SHALL NOT 根据 Qtserver 应用版本号猜测。

#### Scenario: 新服务支持 v2

- **WHEN** Qtserver 已实现 v2 且 read/download 已启用
- **THEN** `capabilities.small_download_v2` SHALL 为 `enabled=true,available=true`
- **AND** 响应 SHALL 公布当前 small 三项硬限制和 `layered_xxh3_128_v1`

#### Scenario: 下载能力关闭

- **WHEN** Qtserver 已实现 v2 但 read/download 被配置关闭
- **THEN** `capabilities.small_download_v2` SHALL 为 `enabled=false,available=false`

### Requirement: qtransc 以协商结果选择小文件协议

qtransc SHALL 仅在 `small_download_v2.enabled=true`、`small_download_v2.available=true`、服务端公布 `layered_xxh3_128_v1` 且三项 small 限制有效时调用 v2 端点。旧服务的 capabilities 不含 `small_download_v2` 时，qtransc SHALL 继续使用既有 v1 small 路径，而 SHALL NOT 将字段缺失视为整个下载任务不兼容。客户端生成的每个 v2 请求 SHALL 同时满足本地批次目标与服务端公布的硬限制。

#### Scenario: 连接旧服务端

- **WHEN** capabilities 包含既有 download 能力和 small 限制但不含 `small_download_v2`
- **THEN** qtransc SHALL 使用 `/qtserver/v1/d/small`
- **AND** SHALL NOT 因缺少 v2 字段拒绝整个下载任务

#### Scenario: 服务端限制小于客户端目标

- **WHEN** 服务端公布的 `small_files` 或 `small_total_bytes` 小于客户端的 100 文件或 32 MiB 目标
- **THEN** qtransc SHALL 使用较小值形成 v2 批次
- **AND** 每个请求 SHALL 满足服务端公布的单文件与批次硬限制

#### Scenario: v2 宣告存在但算法缺失

- **WHEN** `small_download_v2` 可用但 `algorithms` 不含 `layered_xxh3_128_v1`
- **THEN** qtransc SHALL NOT 调用 v2 端点
- **AND** SHALL 报告不一致的服务契约，而不得猜测哈希算法
