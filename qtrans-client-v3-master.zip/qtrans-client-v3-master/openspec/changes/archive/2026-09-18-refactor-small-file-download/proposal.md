## Why

当前小文件下载虽然使用流式 tar 聚合文件，但客户端只启动受 `transfers` 限制的少量 worker，服务端还会在响应前串行计算所有文件哈希，并且每个文件的业务事件可能触发一次同步落盘。小文件数量较多时，网络 lane、CPU、磁盘和 HTTP/2、HTTP/3 的多流能力都无法被充分利用。

同时，现有错误处理会把一次 worker 尝试的错误直接累积到任务结果中。即使文件后来通过回退或重试下载成功，任务仍可能在全部文件传完后以异常状态结束。小文件加速需要独立、可收敛的批次重试语义，而不是把临时尝试错误当成最终文件错误。

## What Changes

- 新增能力协商项 `small_download_v2` 和独立的 `POST /qtserver/v1/d/small-v2` 端点；能力不可用时客户端继续使用现有 v1 小文件下载流程。
- 保留流式 tar，但把小文件计划拆成多个相互独立的 mini-tar 批次。客户端批次目标同时受 100 个文件和 32 MiB 限制，并继续遵守服务端公布的 100 个文件、128 MiB 硬限制以及 4 MiB 单文件阈值。
- 小文件 worker 不再计入或受 `transfers` 限制。调度器凑齐一个批次且成功取得空闲网络 lane 后才启动 worker；HTTP/1 lane 由连接数决定，HTTP/2、HTTP/3 lane 由连接数与用户配置的 streams 共同决定。
- 不修改 `connections`、`streams` 或 `transfers` 的默认值。应用层只发起独立 HTTP 请求，不管理 HTTP/2 或 HTTP/3 stream ID。
- 一个混合下载任务保持两个顺序阶段：先让所有小文件批次成功、明确转入大文件阶段或形成终态失败，再使用普通下载流程传输大文件。
- v2 服务端在响应前完成批次文件的打开和元数据校验，但在发送 payload 时单次读取并同步计算分层 XXH3-128；首部 manifest 不含哈希，最终 checksum footer 是客户端提交整个批次的校验门槛。
- 客户端先把一个批次的所有 payload 写入 qtrans 管理的临时文件并同步计算哈希。只有 footer 完整、所有条目与哈希均匹配时才发布该批次；否则清理本次临时文件并按整批重试。
- v2 payload 的每次正数字节读取 SHALL 继续实时推进文件和任务的 logical transferred 与 network rate；文件即使达到 100% 也保持 `in_progress`，直到整个批次 footer 校验和本地发布完成。批次重试时 logical progress 回退并重新增长，实际网络字节和 rate 保留重试流量。
- worker 返回结构化结果（成功、重试、转入大文件、终态失败），尝试级错误不直接写入任务最终错误。重试成功后，之前的临时错误不得导致任务最终失败。
- HTTP 500 按现有有界策略对整个批次重试；连接错误、超时及 408、429、502、503、504 继续按现有可用性策略重试。连续哈希错误允许两次整批重试，即最多三次完整尝试，第三次仍不一致才形成终态完整性错误。
- 服务端在一个批次的所有 payload 完成后批量追加逐文件 `download.small_file_sent` 事件，并以一次同步落盘作为发送 checksum footer 的前置条件，避免每个小文件各执行一次同步落盘；v2 的 batch、attempt 和 retry 细节只写 debug log，不改变业务事件 schema。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `file-management`: 增加 v2 mini-tar 下载协议、批次提交门槛和小文件整批重试行为。
- `raw-business-event-log`: 调整 v2 小文件批次的成功事件生成与同步落盘时序，并明确重试细节只进入 debug log。
- `client-transfer-concurrency`: 使小文件 worker 脱离 `transfers`，改为由可用网络 lane 驱动。
- `client-transfer-state`: 定义 v2 批次临时文件、发布、清理、实时进度边界和尝试错误收敛语义。
- `service-capability-discovery`: 公布 v2 协议支持、算法与服务端批次限制，并要求客户端据此选择协议和约束请求。

## Impact

- `qtransc/internal/downloadtask`：小文件分批、lane 调度、结构化重试结果、实时进度、临时文件提交以及大小文件阶段衔接。
- `qtransc/internal/client` 及 HTTP transport 配置：暴露可用 lane，而不改变现有 CLI 默认值或手工管理协议 stream。
- `qtserver/internal/handlers`：新增 v2 路由、单次读取的 tar/哈希流和 footer 提交协议。
- `qtserver/internal/filehash`：复用分层哈希算法的增量计算能力，保持既有摘要兼容性。
- `qtserver/internal/event` 与原始业务事件分析：批量追加和单次同步落盘，但不新增事件类型。
- API 兼容性：保留 `/qtserver/v1/d/small` 及其 v1 行为；旧客户端不受影响，新客户端面对旧服务端时继续走 v1。
- 配置兼容性：不新增必填配置，不改变 `connections`、`streams`、`transfers` 的默认值，不新增公开任务状态。

## Non-Goals

- 不让小文件与大文件阶段并行，也不在本次变更中设计二者之间的公平调度。
- 不为单个 mini-tar 实现断点续传；失败时以批次为最小重试单位。
- 不把一个 tar 拆分到多个协议 stream，也不在应用层分配或管理 HTTP/2、HTTP/3 stream ID。
- 不改变普通大文件下载的 `transfers` 并发约束、哈希算法或现有重试策略。
- 不调整目录遍历或下载计划生成并发度，不引入新的服务端公开配置项。
