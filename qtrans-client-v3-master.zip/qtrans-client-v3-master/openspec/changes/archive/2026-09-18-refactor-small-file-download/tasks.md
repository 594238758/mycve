## 1. Qtserver v2 基础能力

- [x] 1.1 在 `qtserver/internal/filehash` 抽取与 `layered_xxh3_128_v1` 字节兼容的增量 hasher，并让既有 reader 路径复用它；用现有固定 hash 向量做代码级对照检查，并以 `go build ./internal/filehash` 验证编译
- [x] 1.2 增加 small v2 manifest、footer 和逐文件条目的 wire model，固定 version、编号 payload、大小及 hash 字段；检查 JSON tag 与 delta spec 完全一致，并以包含这些 model 的 package 编译验证
- [x] 1.3 在 capabilities 响应中加入受 read/download 开关控制的 `small_download_v2`，继续复用现有三项 small limits 与算法列表；检查开关两条构造路径并以 handlers package 编译验证
- [x] 1.4 实现按打开文件数计费、支持 context 取消且容量为 1024 的进程内 prepared-small-file gate，确保所有准备失败和请求结束路径释放权重；通过静态检查所有 acquire/release 分支并以所属 package 编译验证

## 2. Qtserver v2 流式响应与事件持久化

- [x] 2.1 为业务事件 writer 增加串行 batch append + 单次 sync 能力，保留逐行边界、partial write 恢复和 logging-unhealthy gate；检查正常批次只有一次 sync、失败路径不重复 append，并以 `go build ./internal/businessevents/...` 验证编译
- [x] 2.2 实现 v2 请求准备阶段：全量授权、取得 FD 权重、打开并 `fstat` 所有对象、校验 regular file 与 small/max-file 限制，并为超 small 文件返回含 `object_key` 的稳定 `NOT_SMALL` JSON；检查 headers 在全部准备成功后才发送，并以 handlers package 编译验证
- [x] 2.3 实现 manifest-first、编号 payload、checksums-footer-last 的 tar 流，在一次 payload 读取中完成发送与增量 hash，全部 payload 完成后批量持久化逐文件事件并仅在成功 sync 后写 footer；检查任一 stream/log 失败均停止响应且不追加 JSON，并以 handlers package 编译验证
- [x] 2.4 注册精确的 `POST /qtserver/v1/d/small-v2` 路由且保留 v1 路由不变；检查 read_enabled 关闭时两条 small 路由均遵守既有能力关闭行为，并以 `go build ./...` 在 `qtserver` 模块验证

## 3. qtransc v2 协商、消费与本地提交

- [x] 3.1 扩展 capabilities model 和预检逻辑：仅在 v2 capability、三项限制和 `layered_xxh3_128_v1` 同时有效时选择 v2，字段缺失时回退 v1，契约自相矛盾时明确失败；检查不依赖 Qtserver 应用版本并以相关 package 编译验证
- [x] 3.2 按计划顺序实现同时受文件数与总字节数约束的 v2 分批，客户端目标固定为 100 files / 32 MiB / 4 MiB 并与服务端限制取较小值；检查文件数先满、字节数先满和最后不足一批三条分支，并以 downloadtask package 编译验证
- [x] 3.3 实现严格的 v2 tar consumer：校验 manifest、连续编号 payload、footer、全部大小/hash 以及 footer 后正常 tar EOF，拒绝重复、缺失、越序或未知条目；通过代码级状态转换检查每个非法输入都不能进入 publish，并以 downloadtask package 编译验证
- [x] 3.4 实现目标旁 qtrans-owned 尝试临时文件和增量 hash，批次全部验证后才逐文件原子发布；检查 retry、pause、cancel、task delete、协议错误与发布中途失败均遵守清理/保留规则，并以 downloadtask package 编译验证
- [x] 3.5 将 v2 payload 读取接入现有 live logical transferred、network bytes 和不大于 300ms 的 rate 采样：footer 前保持文件 `in_progress`，验证发布后再 completed，重试清理时回退 logical progress 但保留 network 统计；检查 CLI、REST、SSE 和 WebSocket 仍读取同一内存事实，并以 downloadtask package 编译验证

## 4. qtransc lane 调度与失败收敛

- [x] 4.1 为 transport lane 暴露 scheduler 可取得并传给 worker 的 lease，保证 lease 覆盖 request、完整 response body 消费或关闭，且取消等待不会泄漏容量；检查 HTTP/1 与 HTTP/2/3 仍使用既有 `connections`/`streams` 上限，并以 client/transport 相关 package 编译验证
- [x] 4.2 用 ready/active/delayed batch 状态替换 small 固定 worker pool：批次成形且取得 lane 后才创建 worker，worker 完成后先释放 lane，retry 退避不占 lane；检查 small 路径不再读取或占用 `transfers` 并以 downloadtask package 编译验证
- [x] 4.3 增加 `completed/retry/rerouteLarge/terminal` 结构化 worker 结果及独立 HTTP/integrity 计数器，实现可用性重试、HTTP 500 整批最多自动重试三次、hash mismatch 整批最多三次完整尝试和未知协议错误终止；检查 retry 结果不会加入最终错误并以 downloadtask package 编译验证
- [x] 4.4 实现 `NOT_SMALL` 单文件重分类与剩余文件重新分批，保持 small 阶段完全收敛后才运行 original + rerouted large 文件；检查重分类和后来成功的 retry 不会残留 task error，普通 large 阶段仍受 `transfers` 限制，并以 downloadtask package 编译验证
- [x] 4.5 移除 v2 一般失败自动 fallback 普通下载和尝试级 `joinedErr` 累积，只让永久错误或重试耗尽进入现有任务终态映射；检查“首次失败、后续成功”的任务最终为 completed，并以 `go build ./...` 在 `qtransc` 模块验证
- [x] 4.6 为逻辑批次生成诊断 `batch_id` 并在 qtransc/Qtserver debug log 记录 attempt、文件数、计划字节、transport、结果和 retry 分类，禁止记录完整路径列表、请求 body 或凭据；检查业务事件类型和分析 `retry_count` 不变，并分别编译相关 logging package

## 5. 集成一致性与编译验证

- [x] 5.1 对照五份 delta spec 复查 v1/v2 兼容、批次限制、lane 生命周期、三类 retry 上限、temp cleanup、事件 sync-before-footer 和两阶段顺序，记录并修正任何实现偏差
- [x] 5.2 在 `qtserver` 运行 `go build ./...`，确认服务端全部 package 编译成功且未引入新的公开必填配置
- [x] 5.3 在 `qtransc` 运行 `go build ./...`，确认客户端全部 package 编译成功且 `connections`、`streams`、`transfers` 默认值未改变
- [x] 5.4 运行 `openspec validate refactor-small-file-download --strict`，确认实现完成后的 OpenSpec change 仍通过严格校验
