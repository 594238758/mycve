## Context

动机见 [proposal.md](./proposal.md)。当前实现已经具备按文件数与总字节数切分 small batch、顺序执行 small/large 阶段以及流式 tar 的基础，但存在四个结构性问题：

- small worker 数通过 `workerCountForPending` 受 `FileConcurrency`（即 `transfers`）限制，不能直接利用 transport lane；
- worker 在一次尝试失败时把错误加入 `joinedErr`，之后即使 fallback 成功也可能遗留最终错误；
- v1 服务端在响应 headers 前为全部文件读取并计算完整分层 hash，文件内容随后又为响应读取一次；
- `download.small_file_sent` 按文件 append 和 sync，批次包含大量小文件时持久化开销被放大。

本设计受以下既有契约约束：

- transport 已按规范化 origin 管理 `connections` 个 lane，每条 lane 的本地请求容量由 `streams` 约束；对端 HTTP/2 SETTINGS 和 HTTP/3 QUIC credit 仍是实际协议上限；
- `layered_xxh3_128_v1` 以 100 MiB 逻辑 chunk 的 XXH3-128 digest 串联后再次计算 XXH3-128，零字节文件是空 digest 序列的最终 hash；
- `/qtserver/v1/d/small` v1、现有 capabilities、任务公开状态和普通大文件下载需要保持兼容；
- 下载目标可能位于不支持跨多个文件原子提交的普通文件系统，因此 batch commit 只能是“全部验证后再逐文件发布”，不能宣称多文件事务。

## Goals / Non-Goals

**Goals:**

- 让 small 调度直接使用空闲网络 lane，在用户显式配置的连接和 stream 容量内并行多个独立 mini-tar；
- 以简单的单调状态机收敛每个批次，使临时错误只决定重试，不污染最终任务状态；
- 服务端对文件内容只读一次，在发送 payload 的同时生成与既有算法完全相同的 hash；
- 客户端收到整个批次的权威 footer 后才验证和发布；
- payload 字节和实际网络速度继续近实时可见，同时把文件 completed 状态保留到 footer 校验与发布之后；
- 将 v2 一个批次的业务事件同步落盘次数从“每文件一次”降为“一批一次”；
- 新旧客户端、服务端可以滚动升级和独立回滚。

**Non-Goals:**

- 不让 small/large 两个阶段交错运行；
- 不实现 mini-tar 内部续传或部分批次网络重试；
- 不提供跨多个目标文件的原子文件系统事务；
- 不自动调高 `connections`、`streams`、`transfers`，也不实现自适应并发；
- 不改变原始业务日志的事件类型或现有分析结果定义；
- 不改变目录规划并发度、普通下载恢复文件格式和大文件调度器。

## Decisions

### 1. 使用独立 v2 路由和 capability，不原地改变 v1

新增 `POST /qtserver/v1/d/small-v2`，请求继续使用：

```json
{
  "taskid": "...",
  "files": [
    {"object_key": "/absolute/logical/path"}
  ]
}
```

capabilities 新增：

```json
{
  "capabilities": {
    "small_download_v2": {
      "enabled": true,
      "available": true
    }
  }
}
```

`small_download_v2` 与 `download` 使用相同开关；三项限制仍复用 `limits.small_files`、`limits.small_file_bytes`、`limits.small_total_bytes`，算法仍从 `algorithms` 协商。客户端只有在 capability、算法和限制同时有效时使用 v2；字段缺失时走 v1。

选择独立路由而不是用请求 header 在同一路由协商，是为了让旧 handler 保持完全不变，避免缓存、代理或错误客户端把 v1/v2 tar 解释混淆。API major 仍为 v1，因为新增路由和 capability 是向后兼容扩展。

### 2. mini-tar 是并发和重试的最小网络单位

客户端按已经完成的下载计划顺序生成批次，同时应用四个上限：

```text
file count = min(100, capabilities.limits.small_files)
total bytes = min(32 MiB, capabilities.limits.small_total_bytes)
file bytes  = min(4 MiB, capabilities.limits.small_file_bytes)
ordinary max_file_bytes 仍独立生效
```

加入下一文件会超过“文件数”或“总字节数”任一限制时立即封口当前非空批次。最后一个批次不要求填满。100 files / 32 MiB 是客户端调度目标；100 files / 128 MiB / 4 MiB 是当前服务端默认硬限制，二者职责不同。

每个批次对应一个普通 HTTP request/response。HTTP/2、HTTP/3 transport 自然把这些请求映射为协议 stream，应用层不拆分单个 tar、不保存 stream ID，也不把一次 batch 绑定到特定物理连接。

备选方案是“一文件一请求”，实现更直接但重新放大 header、鉴权、路由和日志开销；另一个方案是“一个超大 tar 跨多个 stream 分片”，会引入重组、流间失败协调和自定义 framing，复杂度与失败面都明显更高，因此不采用。

### 3. 调度器持有 batch 状态，lane lease 随 worker 生命周期传递

small scheduler 使用三类状态即可：

```text
ready batches     等待 lane
active batches    已取得 lane，由 worker 执行
delayed batches   已释放 lane，等待 retry_at
```

调度循环只在存在 ready batch 时申请 lane。申请成功后，把 lane lease 和 batch 一并交给新 worker；不会先创建 worker 再让 goroutine 堵塞在 lane 获取上。Worker 必须消费或关闭 response body，随后释放 lease，最后把结构化结果写回 scheduler。退避 batch 放入按 `retry_at` 排序的最小堆或等价定时队列，等待期间不持有 lane。

Worker 结果使用有限枚举，而不是返回一个待直接 join 的裸 `error`：

```text
completed     整批已验证并发布
retry         携带 retry_at、原因和计数器，整个批次重入队列
rerouteLarge  携带发生 NOT_SMALL 的文件，剩余文件重新分批
terminal      携带最终错误和受影响文件
```

Scheduler 只把 `terminal` 写入最终错误集合。`retry` 记录可观察日志但不进入任务错误；`completed` 会自然丢弃其历史尝试错误；`rerouteLarge` 只修改第二阶段输入。

可采用单调的阶段流程：

```text
build small batches
       |
       v
run until every batch => completed | rerouteLarge | terminal
       |
       v
run ordinary large files + rerouted files under transfers
       |
       v
derive final task state from unresolved terminal errors only
```

备选方案是保留固定 worker pool并把池大小改成 `connections*streams`。这仍会预创建等待任务的 goroutine，并使 retry sleep 占住 worker；结构化调度器更直接地表达“有批次且有 lane 才启动 worker”。

### 4. v2 tar 以 manifest 开始、checksums footer 提交

响应条目固定为：

```text
.qtrans/manifest.json
payload/000000
payload/000001
...
.qtrans/checksums.json
<tar EOF>
```

manifest v2 结构：

```json
{
  "version": 2,
  "taskid": "...",
  "file_count": 2,
  "total_unpacked_bytes": 1234,
  "hash_algorithm": "layered_xxh3_128_v1",
  "files": [
    {
      "index": 0,
      "object_key": "/a/b.txt",
      "archive_path": "payload/000000",
      "size": 1000
    }
  ]
}
```

footer v2 结构沿用相同公共字段，`files` 项使用 `index`、`object_key`、`archive_path`、`size` 和 `hash`。`size` 是实际完成发送的字节数，必须与 manifest 相等。Manifest 不含 hash，因此服务端无需在 headers 前预读内容；编号 archive path 避免把不可信远端路径交给 tar 解包路径处理。

服务端先授权并打开所有文件、通过 `fstat` 确认普通文件及限制，再发 headers。成功响应开始后，某文件截断、读取失败、客户端断开、日志失败或 tar 写入失败都通过结束 stream 表示，不尝试在 tar 中嵌入错误 JSON。文件在预检时超过 small 阈值返回 JSON `NOT_SMALL` 并指出 `object_key`；客户端只把该文件放入 large 阶段，再重组剩余 small 文件。

客户端只接受严格条目顺序和完全一致的映射。读取 footer entry 后还要调用下一次 `tar.Reader.Next()` 并得到正常 EOF，防止“footer 内容完整、tar closing blocks 丢失”被误判为成功。

备选方案是在 manifest 中保留 hash。它要求服务端两次读取内容，正是本次要移除的主要瓶颈。另一个方案是 HTTP trailer，但代理和不同 transport 对 trailer 的处理更分散，tar footer 能把完整性元数据保留在同一个版本化 payload 协议中。

### 5. 服务端和客户端共用真正增量的 layered hash

抽取一个保持 `layered_xxh3_128_v1` 字节兼容的增量 hasher：

- 当前逻辑 chunk 使用 streaming XXH3-128，累计到 100 MiB 时把 16-byte digest 写入 overall XXH3-128并重置 chunk hasher；
- EOF 时仅在当前 chunk 非空时提交最后一个 chunk digest；
- 零字节文件不提交 chunk digest，直接得到空 digest 序列的 overall hash；
- `Sum` 不改变后续写入状态，或明确只在文件 EOF 后调用。

服务端通过一个小的复用 copy buffer把 payload 同时写入 tar 和增量 hasher，客户端把 tar entry 同时写入临时文件和同一算法 hasher。这样每个方向各自只读取一次 payload，且不再为每个小文件分配现有 `LayeredReader` 的 100 MiB buffer。

实现后应让既有 `LayeredReader` 也复用该增量器，减少算法出现两个实现而逐渐漂移的风险；这属于内部重构，不改变 hash wire value。

### 6. footer 是批次验证门槛，发布不是跨文件事务

每次尝试为每个目标创建同目录、不可预测且 qtrans-owned 的临时文件。客户端验证以下全部条件：

- manifest 与请求文件集合、顺序、大小一致；
- payload 编号连续、无重复、无未知 entry，每项实际字节数一致；
- footer 与 manifest 的版本、taskid、算法、映射和大小完全一致；
- 每项客户端增量 hash 与 footer hash 一致；
- footer 后 tar 正常 EOF。

任一条件不满足时，在 retry 入队前删除当前尝试的所有临时文件。全部满足后才逐个执行同目录原子 rename。跨文件 rename 不能成为一个事务：如果中途本地权限、磁盘或目标冲突导致失败，已发布的正确文件保留成功，未发布临时文件清理，失败文件成为终态本地错误。这里不重新下载整个网络批次，因为 bytes 已经验证，重新下载不能修复本地发布错误。

进度提交与文件发布使用不同边界。读取 payload 并成功写入临时文件时立即增加文件和任务的 logical transferred，同时累计实际 network bytes；多个并发 mini-tar 的 network bytes 进入同一个任务 rate 采样器。文件 payload 写满后可显示 100%，但继续保持 `in_progress`，直到 footer、全部 hash、tar EOF 和该文件 rename 均成功。批次验证后多个文件会在很短时间内连续发布，因此 `VerifiedFileNum` 和 completed 事件可以呈现批量跳变，而字节进度与 rate 不需要等待整个批次。

失败尝试清理临时文件时，把尚未发布文件的 logical transferred 重置为 0，所以任务进度允许回退再增长；实际 network bytes 不回退，重传继续影响 rate。这样既不重复累计逻辑文件大小，也能让用户看到真实网络负载。Tar headers、manifest、footer、padding 和等待日志 sync 的时间不计入 payload progress，等待期间 rate 会按现有采样规则收敛到 0。

备选方案是直接写最终路径并在失败时删除，这会把未验证内容暴露给消费者且可能破坏用户原文件，因此不采用。为整个 batch 建 staging 目录再目录 rename 只适用于所有目标具有共同可替换父目录的情况，不能覆盖一般下载映射。

### 7. 重试分类在 batch 层执行，尝试错误不向最终状态泄漏

分类顺序固定为：

1. context cancellation、用户 pause、显式 deadline：结束调度并按既有任务状态处理；
2. `401`：按既有契约最多 refresh 一次，然后重试同一批次；
3. `NOT_SMALL`：重分类指定文件，不计失败；
4. 连接错误、超时、截断、`408/429/502/503/504`：清理并按既有可用性恢复策略整批重试；
5. `500`：清理并按既有退避最多自动重试三次（初始尝试之外最多三次）；
6. hash mismatch：清理并允许两次整批重新传输，总计最多三次；
7. 完整响应中的非法 v2 wire 格式，以及确定的 `400/403/404/413`、本地磁盘或发布错误：终态；
8. 未知错误默认终态，避免把协议 bug 变成无限网络重试。

HTTP retry 计数与 integrity retry 计数分开，状态转换时保留各自语义。例如一次 `500` 后成功收到但 hash mismatch，只增加相应分类的计数。可用性恢复延续现有无固定次数契约，但每次都释放 lane；它不受 recursive task “本轮零成功则停止”的启发式提前终止。

不再对一般 small 失败自动 fallback 普通下载。只有服务端给出明确 `NOT_SMALL` 才转 large；否则 fallback 会掩盖服务端错误、重复传输并重新引入“small 失败但任务仍带旧 error”的问题。

### 8. v2 事件在 payload 后批量 append、一次 sync、再发 footer

服务端在写每个 payload entry 时生成发送事实所需字段并记录 entry 完成时间，但先将最多 100 个事件保存在内存。全部 payload 成功后调用 writer 的 batch durable API：在现有串行锁内按 manifest 顺序 append 每条完整 JSONL，只在最后执行一次文件 sync。成功后才写 `.qtrans/checksums.json`。

顺序保证单向不变量：客户端能完成 v2 batch，意味着该批次逐文件发送事件此前已经 durable。反向不成立：事件 sync 后 footer 或连接仍可能失败，所以客户端可重试并形成多个真实发送事件。现有分析器使用最早 small 成功事实且 `retry_count=0`，本变更保持这个定义；精确统计客户端 small retry 属于未来事件 schema 变更，不在本次范围。

Writer 对 batch 中每一完整行仍记录恢复边界。任一 append 或最终 sync 失败时不发送 footer、进入 logging-unhealthy；完整行已写但 sync 失败时只恢复 sync，不重复 append 同一 attempt。该设计将正常批次的 sync 次数从最多 100 次降为 1 次，同时不弱化“客户端成功前日志已持久”的约束。

为了让上述限制可排查而不改变业务 schema，客户端为每个逻辑批次生成随机 `batch_id`，每次完整请求递增 `attempt`。qtransc debug log 记录 batch_id、attempt、文件数、计划总字节、transport、结果分类、retry 分类和 retry_at；Qtserver 在收到关联 header 时记录相同 batch_id、文件数、总字节和 stream 终止阶段。Debug log 不记录完整 object_key 列表、请求 body 或任何凭据。`batch_id` 只用于诊断，既不进入 file key，也不参与授权。

备选方案是在 footer 后写事件。那会允许客户端报告成功但事件尚未持久化；在 footer 前仍逐文件 sync 则保留原性能瓶颈，因此都不采用。

### 9. 服务端对预打开文件设置内部 FD 安全阀

v2 为保证 headers 前全量校验会同时持有一个批次最多 100 个打开文件。客户端脱离 `transfers` 后，并发批次可能显著增加，因此服务端需要一个进程内、context-aware 的 weighted semaphore，按本批次实际打开文件数计费。初始内部容量取 1024 个 prepared small file handles；取得容量后再逐个打开，任一失败则关闭已打开文件并释放全部权重，请求结束也统一释放。

这个安全阀不作为新的公开配置，避免本次再增加一套用户并发参数；它只保护进程免受显式增大 streams 后的 FD 峰值冲击。等待安全阀的请求尚未发 headers，可响应客户端取消。容量常量集中定义并记录指标，未来只有实际部署数据证明需要时再配置化。

备选方案是只 stat 后关闭、流中逐个重新打开。它降低 FD 峰值，但会把常见的 open/permission 失败推迟到 headers 之后，造成不必要的整批网络重试，违背 v2 的准备阶段目标。

## Risks / Trade-offs

- [用户不增大 `streams` 时并发收益有限] → 保持用户明确要求的不改默认值；通过指标和日志展示活动/等待 batch 与 lane 使用率，便于用户按环境调整。
- [32 MiB 整批重试会重复传输已经正确的文件] → 以简单可靠的批次事务换取最多 32 MiB 的重传上界；hash mismatch 最多三次完整尝试。
- [预打开文件造成 FD 峰值] → 服务端按文件数使用 1024 权重的内部安全阀，并保留每请求 100 文件硬限制。
- [同一远端文件在读取中被原地修改] → 保持现有下载弱一致性；footer 校验实际发送 bytes，不声称提供远端快照。截断或读失败则整批重试。
- [批次验证后多文件发布仍可能部分成功] → 明确只保证“验证前不发布”，逐文件 rename 失败时保留已成功文件且只报告真实本地失败，不伪造全批回滚。
- [文件完成数会批量跳变且失败重试会使 logical progress 回退] → payload bytes 与 rate 仍实时更新；明确 100% 但 `in_progress` 的等待阶段，并用 debug batch/attempt 记录解释回退原因。
- [事件已持久化但 footer 发送失败会产生重复 small 事件] → 重复表示真实再次发送；分析程序继续选择最早合法成功事实，不把它们误计为额外 transmitted。
- [服务端 batch sync 暂停 footer 发送] → 单批仅一次 sync，且不占全局 writer 锁之外的其他资源；相较逐文件 sync 明显缩短累计等待。
- [严格 wire 校验可能暴露代理或服务端实现错误] → 将完整但非法协议视为终态，避免无限重试；版本协商失败时不静默解释其他布局。
- [small 优先会推迟大文件启动] → 这是已确认的阶段语义；避免第一版引入大小文件公平调度和互相抢占。

## Migration Plan

1. 先部署 Qtserver：新增增量 hash、batch event writer、FD gate、v2 handler 与 capability；保留并继续验证 v1 handler。
2. 确认 capabilities 在 read 开关两种状态下正确公布 v2，并观察 v2 路由、FD gate 和 writer 指标。
3. 再部署 qtransc：客户端发现 v2 后启用 lane-driven scheduler；面对旧 Qtserver 自动使用 v1。
4. 灰度期间比较 v1/v2 的批次吞吐、重试分类、hash mismatch、临时文件清理和事件 sync 延迟。
5. 回滚客户端时，旧版继续调用仍保留的 v1；回滚服务端前先回滚或停止使用 v2 的客户端，随后 capability 消失，新版客户端也会回退 v1。

本次不删除 v1，因此不需要数据迁移、任务状态迁移或配置迁移。
