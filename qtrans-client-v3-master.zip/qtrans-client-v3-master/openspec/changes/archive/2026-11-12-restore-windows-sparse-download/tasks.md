# Tasks

## 1. 文件准备与恢复

- [x] 1.1 增加 Windows 稀疏文件准备和非 Windows 空操作；审查稀疏失败回退、大小设置错误及句柄使用。
- [x] 1.2 接入正常准备与整文件重试；审查续传数据保留、准备失败关闭句柄、逻辑大小不能直接完成下载、小文件路径不变。

## 2. 编译与交付

- [x] 2.1 完成 Linux/amd64 与 Windows/amd64 编译，生成 Windows 可执行文件；不编写或运行测试、benchmark，不宣称传输性能已验证。
- [x] 2.2 通过 OpenSpec 校验及差异格式检查，确认用户已有缓冲修改保留、依赖版本未变，记录产物和验证限制。

验证记录：Go 1.26.2 下 Linux/amd64 `go build ./...` 与 `make windows-amd64` 均通过；Windows 产物为 `qtransc/bin/release/qtransc-windows-amd64.exe`。`openspec validate restore-windows-sparse-download --strict`、`git diff --check` 通过。未运行测试、benchmark 或实际传输；Windows 机械盘效果尚待实际对比。
