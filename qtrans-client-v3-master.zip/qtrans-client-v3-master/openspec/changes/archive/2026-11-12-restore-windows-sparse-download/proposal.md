# Proposal

## Why

修正服务端流缓冲后，新旧客户端在 SSD 上速度接近，但 Windows 机械盘上的新版下载仍明显波动。旧版会创建稀疏文件，新版普通文件的乱序分片写入可能产生额外补零 I/O；恢复这一优化，保留现有传输调度。

## What Changes

- Windows 普通分片下载在传输前尝试启用稀疏属性，成功后设置目标逻辑大小；校验失败后的整文件重试同样适用。
- 续传保留已下载数据；文件大小不代表下载完成，继续使用 `.progress` 和完整性校验。
- 无法启用稀疏属性时记录警告并沿用普通文件写入；逻辑大小设置失败则停止该文件下载。
- 不调整 QUIC、并发、读写缓冲、小文件批次或非 Windows 行为。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `client-transfer-state`：补充 Windows 分片下载目标文件的稀疏准备与恢复约束。

## Impact

修改 `qtransc/internal/downloadtask`，覆盖 download、download2 和 serve 共享的普通分片链路；不修改 qtserver、CLI/API 字段或依赖版本，无迁移要求。目标文件可以在下载开始时已有完整逻辑大小，但不代表已下载字节或实际磁盘占用；不承诺资源管理器实时刷新目录信息。
