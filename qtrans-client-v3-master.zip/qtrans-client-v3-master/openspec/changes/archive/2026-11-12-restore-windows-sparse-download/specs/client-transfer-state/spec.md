## ADDED Requirements

### Requirement: Windows 普通分片下载使用稀疏目标文件

qtransc 在 Windows 上执行普通分片下载时 SHALL 在分片写入前尝试启用目标文件的稀疏属性，成功后 SHALL 将逻辑大小设为预期文件大小，避免为未写入区间主动填零。续传 SHALL 保留预期范围内已有数据和 `.progress` 恢复语义，SHALL NOT 仅凭文件逻辑大小报告成功。无法启用稀疏属性时 SHALL 记录警告并回退普通写入；启用成功但设置大小失败时 SHALL 停止该文件下载并释放文件句柄。该行为 SHALL 覆盖 download、download2 和 serve 的普通分片链路，不改变非 Windows 和小文件批次行为。

#### Scenario: 新建文件并乱序写入

- **WHEN** Windows 普通分片下载在支持稀疏文件的目标文件系统上开始
- **THEN** 首个分片写入前目标文件 SHALL 已具有稀疏属性和预期逻辑大小
- **AND** 未下载区域 SHALL NOT 因预设逻辑大小而被计入已下载进度

#### Scenario: 暂停后续传

- **WHEN** 存在目标文件和 `.progress`，用户恢复 Windows 下载
- **THEN** 文件准备 SHALL 保留预期范围内已有数据，不得先截断至零
- **AND** 客户端 SHALL 继续按保存进度恢复分片并进行完整性校验

#### Scenario: 逻辑大小已匹配但内容不完整

- **WHEN** 稀疏目标文件已具有完整逻辑大小，但 `.progress` 丢失且部分内容未下载
- **THEN** 客户端 SHALL 进行内容校验，不得仅凭大小标记文件成功
- **AND** 校验失败后的整文件重试 SHALL 在再次写入前重新准备稀疏文件及逻辑大小

#### Scenario: 稀疏属性设置失败

- **WHEN** 文件系统不支持稀疏文件或稀疏属性设置被拒绝
- **THEN** 客户端 SHALL 记录警告，保留已有内容并沿用普通文件写入
- **AND** SHALL NOT 为模拟稀疏文件而主动填零或增加强制刷盘

#### Scenario: 设置逻辑大小失败

- **WHEN** 稀疏属性已启用，但无法设置目标逻辑大小
- **THEN** 该文件 SHALL 报告本地错误，关闭文件句柄且不启动分片写入

#### Scenario: 非 Windows 或小文件批次

- **WHEN** 客户端在非 Windows 系统运行，或文件经小文件批次传输
- **THEN** SHALL 保持原有文件创建、写入和发布流程
