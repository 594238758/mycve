# Design

## Context

参见 proposal.md。qtransc 的 serve、CLI 和旧兼容命令共用任务请求与上传下载执行代码，但凭据生命周期不同：serve 需要由每次 HTTP 创建请求完整决定身份，普通 CLI 可以显式选择进程级用户名密码刷新，旧 WebSocket 还要求 `update-token` 热更新正在运行的兼容传输。anonymous 下载不发送 Authorization，anonymous 上传则必须发送 `user-file-space` 规定的固定公开写 token。

上传控制请求还会经过通用 JSON 请求 helper；该 helper 在进程级认证模式为用户名密码时可在 401 后刷新并替换 token。因此只在 handler 保存请求 token，仍不足以保证 serve 的请求级隔离。

## Goals / Non-Goals

**Goals:**

- 让 serve HTTP 任务的实际身份只由该次创建请求决定，并在整个任务生命周期保持稳定。
- 在共享任务实现中明确区分请求级 token 与进程级认证来源。
- 保留 CLI 用户名密码刷新和旧 WebSocket static token 热更新。
- 保证 anonymous 上传继续使用固定写 token，而调用方无需感知该常量。

**Non-Goals:**

- 不移除或改名 `/api/v1/conf/token`。
- 不修改 Qtserver 的鉴权、anonymous principal 或固定写 token。
- 不修改 CLI 参数、旧 WebSocket 帧或 `update-token` 响应。
- 不增加 token 持久化、轮换协议或新的错误码。

## Decisions

### 1. 在 serve HTTP 边界确定凭据语义

serve handler 对 `bearerToken` trim 后立即确定任务身份：下载空值保持无 token，上传空值转换为固定 anonymous 写 token，非空值保留为任务 token。同时给内部任务请求标记“精确使用请求 token”，阻止共享构造器将其转换为进程级认证来源。

备选方案是在所有任务构造器中把空 token 一律解释为 anonymous、非空 token 一律解释为固定快照。该方案会改变 CLI 用户名密码刷新和旧 WebSocket `update-token`，违反现有兼容规范，因此拒绝。

### 2. 共享任务构造器显式区分两类 token 来源

内部任务请求保留两个互斥意图：serve 使用请求级精确 token；CLI 或兼容命令可继续使用进程级认证管理器。若请求级 token 标记存在，它优先于进程级标记；共享上传和下载任务保存最终解析出的来源，后续请求不得重新猜测。

备选方案是根据 token 是否为空隐式推断来源。旧兼容命令启动时同时持有当前 token 和进程级热更新能力，单凭字符串为空与否无法表达该差异，因此拒绝。

### 3. 上传通用请求提供禁止全局刷新路径

上传任务根据凭据来源选择通用 JSON 请求路径。请求级 token 和 anonymous 固定 token 禁止 401 后读取全局认证；明确使用进程级用户名密码的 CLI 任务保留刷新能力。直接发送上传数据和下载请求沿用同一来源判断。

备选方案是删除通用 helper 的全部自动刷新。该方案会让 CLI 用户名密码模式失去既有恢复能力，影响范围超过本变更，因此拒绝。

### 4. 保留 `/conf/token` 路由但隔离其作用域

`/api/v1/conf/token` 继续更新进程级 static token，并保持现有请求与响应格式，以满足路由稳定性要求。serve HTTP 创建任务不再消费该状态，因此更新操作不会改变既有任务，也不会成为后续任务的默认凭据。

直接删除该路由会造成额外协议破坏且不属于本次范围；继续让它作为 HTTP 任务默认值则无法满足请求自包含目标。

## Risks / Trade-offs

- [依赖 `/conf/token` 的现有调用方创建任务后变为 anonymous] → 在 proposal 和 API 文档中明确迁移要求：每次创建任务都传 `bearerToken`。
- [共享任务代码的两种 token 来源容易再次混用] → 以单一内部来源标记贯穿上传、下载与控制请求，并把 401 行为纳入规范场景。
- [保留但不供 HTTP 任务使用的 `/conf/token` 容易被误解] → 文档明确其与 `POST /api/v1/tasks` 隔离；未来若要废弃该路由，另行提出兼容变更。
- [token trim 改变带首尾空白值] → 将 trim 作为 wire 契约；调用方应发送不含首尾空白的 token。

## Migration Plan

1. 审核并批准本 change，确认 `/conf/token` 调用方的迁移窗口。
2. 同步实现请求级来源标记、anonymous 默认值和禁止全局刷新路径。
3. 更新 `qtransc-apis.md`，明确字段可选性、任务级固定值及 `/conf/token` 隔离；由维护者完成人工审核。
4. 执行格式与编译检查，在同一发布窗口切换调用方和 qtransc。

若需回滚，应同时恢复 serve 对进程级 token 的回退、API 文档和本规格，避免 wire 文档与实际凭据来源不一致。
