# Tasks

## 1. Serve 请求级认证入口

- [x] 1.1 在 serve 创建任务入口 trim `bearerToken`，为空的上传请求设置固定 anonymous 写 token、为空的下载请求保持无 token，并标记任务使用请求级凭据；通过静态核对 handler 到内部请求的字段传递确认三种分支均被覆盖。
- [x] 1.2 更新 `qtransc/docs/qtransc-apis.md` 中 `bearerToken`、`/conf/token` 和任务创建说明，写明 anonymous 默认值、显式 token 固定值及调用方迁移要求；由维护者人工审核字段含义和示例。

## 2. 共享任务凭据隔离

- [x] 2.1 在内部任务请求及上传、下载构造链中区分请求级精确 token 与进程级认证来源，保证前者优先，同时保留 CLI 和旧 WebSocket 使用进程级凭据的路径；静态核对 `upload2`/`download2` 与普通 CLI 的认证分支未被改为 serve 语义。
- [x] 2.2 为上传通用 JSON 请求增加禁止进程级 401 刷新的调用路径，并让上传 session、分片控制、完成、取消、释放和远端建目录按任务凭据来源选择路径；用 `rg` 核对全部上传控制请求均经过来源选择。
- [x] 2.3 核对下载授权、browse、small、chunk 和 verify 请求只在明确使用进程级认证时刷新 401，显式 token 和 anonymous 请求不回退其他凭据；通过静态检查各重试入口完成验证。

## 3. 集成验证

- [x] 3.1 对改动的 Go 文件执行 `gofmt`，运行 `go build ./...` 确认 qtransc 编译成功，并运行 `openspec validate make-serve-task-token-request-scoped --strict` 确认 change 结构与规格场景有效；不运行测试或 benchmark。

## Workflow follow-up

- 维护者批准本 change 后再确认实现完成状态。
- 实现与文档审核完成后归档 change，并核对主规格已包含新增 requirement。
