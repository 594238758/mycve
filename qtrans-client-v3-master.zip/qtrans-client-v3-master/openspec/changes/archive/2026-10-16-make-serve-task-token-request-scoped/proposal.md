# Proposal

## Why

qtransc `serve` 创建任务时会把请求中的 `bearerToken` 与进程级 `authmanager` 混用，导致省略 token 的任务可能继承全局凭据，显式 token 也可能在 401 后被全局凭据替换。调用方无法仅凭创建请求确定任务最终使用的身份，需要把 HTTP 任务认证收敛为请求级契约。

## What Changes

- **BREAKING**：`POST /api/v1/tasks` 未提供 `bearerToken`，或该值 trim 后为空时，任务固定按 anonymous 语义执行；下载不发送 Authorization，上传自动使用规范规定的固定 anonymous 写 token。
- **BREAKING**：创建请求提供非空 `bearerToken` 时，该任务在整个生命周期内固定使用该值，不写入、读取或在 401 后替换为进程级 `authmanager` 凭据。
- **BREAKING**：`POST /api/v1/conf/token` 保留既有 method、path 和响应，但其进程级 static token 不再作为 HTTP 创建任务的默认凭据，也不改变既有 HTTP 任务的凭据。
- 保持 qtransc CLI 的既有认证选择和用户名密码刷新行为，保持 `upload2`/`download2` 旧 WebSocket `update-token` 协议不变。
- 同步 qtransc `serve` API 文档，使字段必填性、anonymous 行为和迁移方式与规范一致。

迁移时，原先依赖 `/api/v1/conf/token` 为 HTTP 任务提供默认凭据的调用方，必须在每次 `POST /api/v1/tasks` 中显式传入 `bearerToken`；需要 anonymous 身份的调用方应省略该字段或传入空字符串。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `qtransc-serve-api-contract`: 明确 HTTP 创建任务的 request-scoped `bearerToken`、anonymous 默认行为、进程级 token 隔离和非 serve 兼容边界。

## Impact

影响 qtransc `serve` 任务创建 handler、上传和下载任务的凭据来源、上传控制请求的 401 刷新边界，以及 `qtransc/docs/qtransc-apis.md`。不修改 Qtserver 鉴权协议、固定 anonymous 写 token、CLI 参数、旧 WebSocket 帧或错误码注册表；不新增依赖。
