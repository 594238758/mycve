# Spec Delta

## ADDED Requirements

### Requirement: serve 创建任务的 bearerToken 按请求隔离

`POST /api/v1/tasks` SHALL 将 `bearerToken` 限定为该任务的请求级凭据。字段缺失或 trim 后为空时，下载 SHALL 使用 anonymous 且不发送 Authorization，上传 SHALL 使用 `user-file-space` 规定的固定 anonymous 写 token；字段非空时，任务 SHALL 在整个生命周期固定使用 trim 后的请求值。进程级 static token 的已有值或后续更新 SHALL NOT 改变这些选择，认证失败 SHALL NOT 回退 anonymous 或其他进程级凭据。

#### Scenario: 未提供 token 的下载任务

- **WHEN** 调用方创建下载任务且省略 `bearerToken`，或其值 trim 后为空
- **THEN** qtransc SHALL 按 anonymous 下载语义执行
- **AND** 下游下载请求 SHALL NOT 携带 Authorization

#### Scenario: 未提供 token 的上传任务

- **WHEN** 调用方创建上传任务且省略 `bearerToken`，或其值 trim 后为空
- **THEN** qtransc SHALL 自动使用 `user-file-space` 规定的固定 anonymous 写 token
- **AND** 调用方 SHALL NOT 被要求提供该固定 token

#### Scenario: 创建任务时显式提供 token

- **WHEN** 调用方创建上传或下载任务并提供 trim 后非空的 `bearerToken`
- **THEN** qtransc SHALL 在该任务整个生命周期固定使用该请求值
- **AND** SHALL NOT 因进程级 static token 已存在或发生更新而改变任务凭据

#### Scenario: 显式 token 鉴权失败

- **WHEN** 使用显式 `bearerToken` 的任务收到下游 401 或其他鉴权失败
- **THEN** qtransc SHALL 按该显式凭据报告鉴权失败
- **AND** SHALL NOT 将任务凭据替换为 anonymous 或进程级凭据后重试

#### Scenario: 预先配置进程级 token 后创建无 token 任务

- **WHEN** 调用方先成功调用 `POST /api/v1/conf/token`，随后创建省略 `bearerToken` 的任务
- **THEN** 新任务 SHALL 仍按对应上传或下载的 anonymous 语义执行

#### Scenario: 任务运行期间更新进程级 token

- **WHEN** 一个 HTTP 创建的任务正在运行，调用方成功调用 `POST /api/v1/conf/token`
- **THEN** 该任务后续请求使用的凭据 SHALL 保持不变

#### Scenario: 非 serve 凭据生命周期保持不变

- **WHEN** CLI 使用用户名密码刷新凭据，或旧 WebSocket 按 `legacy-websocket-protocol` 处理 `update-token`
- **THEN** SHALL 继续遵守各自既有的凭据刷新和热更新契约
- **AND** SHALL NOT 套用 serve HTTP 任务的请求级隔离规则
