## MODIFIED Requirements

### Requirement: qtransc task状态和退出码保持现有集合

serve SHALL 只公开`pending|running|completed|stopped|failed`，不新增paused或partial。主动pause和可恢复错误 SHALL 是stopped；规划/config/auth等不可恢复错误 SHALL failed。CLI退出码 SHALL 是0成功含warnings、1 remote/auth/network/transfer、2 CLI/local config/planning/state DB、130 SIGINT。stdout SHALL 用于结果，stderr SHALL 用于progress/warnings/errors；`list --json`失败 SHALL 在stdout输出单一JSON error。

显式携带 bearer token 的 download、download2 或 serve download SHALL 使用 self 空间，即使 token 已转存到进程内 auth manager；未显式要求授权下载时，auth manager 中存在 token 不得把匿名下载隐式改成 self。失败或 stopped 任务通过 start 重新进入 pending 时 SHALL 清除上一轮 error 和终止时间。主动 pause 导致的 context cancellation SHALL 使 serve 的 `task_status` 为 `stopped`，并只通过任务事件中的状态 `paused` 表达；不得发布 `file_status=failed`。下载选择不存在时，前台 CLI SHALL 在 stderr 输出`未找到该文件`，不得暴露`internal error`或 browse expansion 实现细节。

#### Scenario: task只有warnings

- **WHEN** 所有可传输文件成功且只有skip warnings
- **THEN** task SHALL completed且CLI退出0

#### Scenario: planning limit失败

- **WHEN** 目录规划超过固定限制
- **THEN** task SHALL failed且CLI退出2

#### Scenario: 显式token下载私有对象

- **WHEN** download2或serve download显式携带有效bearer token
- **THEN** browse和下载 SHALL 使用self空间
- **AND** 不得回退到anonymous空间

#### Scenario: 失败任务修复凭据后重试

- **WHEN** 任务因旧凭据失败，调用方更新token并调用start
- **THEN** 任务进入pending前 SHALL 清除旧error
- **AND** 成功完成后的detail SHALL 不包含旧错误

#### Scenario: 主动暂停上传

- **WHEN** 运行中的上传任务被主动pause且文件协程收到context cancellation
- **THEN** serve 的 `task_status` SHALL 为`stopped`
- **AND** 对应任务事件状态 SHALL 为`paused`
- **AND** file_status SHALL NOT 为failed

#### Scenario: 下载选择不存在

- **WHEN** 前台download请求不存在的远端选择
- **THEN** CLI SHALL 以退出码1结束并输出`未找到该文件`
- **AND** 输出 SHALL NOT 包含`internal error`
