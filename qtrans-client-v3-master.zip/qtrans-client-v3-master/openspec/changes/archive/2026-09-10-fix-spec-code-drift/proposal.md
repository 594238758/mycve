## Why

静态核对发现 HTTPS2 lane 未按 `streams` 多路复用、Redis 重启后正式 hash 的 incarnation 判断存在跨命令窗口，以及旧 WebSocket 协议会改写或忽略请求 task ID。这些实现与既有 OpenSpec 契约不一致；同时任务暂停状态在同一规格内混用了 serve 状态与事件状态。

## What Changes

- 让 HTTPS2 的单 lane 在不突破 `connections` 和服务端 stream 容量的前提下，实际承载最多 `streams` 个并发请求。
- 将正式 hash 的 Redis incarnation 判断与每次 Redis 脚本读写原子化，禁止 AOF 恢复的旧 hash 或 calculation claim 被复用。
- 让 upload2/download2 原样传递 task ID，并按每个入站请求的 task ID 回复。
- 澄清任务暂停：serve 任务状态为 `stopped`，任务事件状态为 `paused`。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `file-management`: 明确暂停后的 serve 任务状态与事件状态的不同语义。

## Impact

- 影响 qtransc 的 HTTPS2 transport pool 及旧 GUI WebSocket 兼容层；CLI 参数、HTTP API 和 WebSocket 字段名不变。
- 影响 qtserver 的正式 hash Redis Lua 脚本；Redis 的既有 `INFO` 权限继续是运行前提，不新增配置项或数据迁移。
- qtransc 将直接使用已锁定版本的 `golang.org/x/net/http2`，不引入新的第三方库。
