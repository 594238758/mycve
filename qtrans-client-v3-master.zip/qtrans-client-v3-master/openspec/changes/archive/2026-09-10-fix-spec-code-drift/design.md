## Context

本变更同时触及 qtransc 的 TCP/H2 transport pool、旧 GUI WebSocket 兼容层和 qtserver 的正式 hash Redis 协调状态。既有 OpenSpec 已规定前三项的外部行为；唯一需要调整的行为规格是 serve 状态与任务事件暂停状态的区分。

## Goals / Non-Goals

**Goals:**

- 让 HTTPS2 lane 的物理连接和本地请求容量严格对应 `connections` 与 `streams`。
- 让 Redis 重启在任何正式 hash 脚本执行边界均不能复用旧 incarnation 数据。
- 保持旧 GUI task ID 的字节级透传和请求响应关联。

**Non-Goals:**

- 不新增 CLI、HTTP、WebSocket 或 Redis 配置。
- 不改变 HTTP/1、HTTP/3、上传 session 或非正式 hash Redis 状态。
- 不自动修改人维护的 `docs/`，也不新增测试任务。

## Decisions

- HTTPS2 使用每 lane 独占、惰性建立的 `http.Transport.NewClientConn`，并由 `golang.org/x/net/http2` 配置 H2 实现。该 API 在一个已经完成 h2 ALPN 的 TLS 连接上实行服务端 stream 背压，不会让标准库 transport 为饱和的 stream 另建未受 lane 管理的 TCP 连接，同时保留现有代理和 TLS 处理。放弃原来的单请求 permit；HTTP/1 继续使用当前 `http.Transport`。
- 正式 hash 脚本在其原子执行范围内通过 `INFO server` 取得 `run_id`，并以该值判断和写入 record/claim。Go 侧不再在脚本调用前读取或缓存 incarnation，避免重启发生在两条 Redis 命令之间的窗口。
- WebSocket 仅规范化命令 `type` 和 bearer token；task ID 不再 trim。请求处理使用启动任务 ID 进行本地 token 更新作用域，但始终将入站 task ID 写入对应响应。

## Risks / Trade-offs

- [H2 连接初始化失败] → lane 报告不可用并交给既有业务重试；后续 lease 建立新 lane。
- [Redis ACL 不允许脚本内 INFO] → 启动和健康检查本已依赖 `INFO`；若运行时仍遭拒绝，将按既有 Redis 依赖故障路径停止服务，不降级复用 hash。
- [旧协调端发送与注册 ID 不同的请求 ID] → 按兼容契约原样回显该请求 ID，不把它当作业务对象键。

## Migration Plan

部署不需要数据迁移。升级 qtransc 后 HTTPS2 并发立即按既有配置生效；升级 qtserver 后旧 incarnation 的 AOF hash/claim 会在首次相关脚本调用时失效并按既有异步流程重建。回滚到旧 qtserver 仅会恢复旧窗口，不会破坏 Redis 数据格式。
