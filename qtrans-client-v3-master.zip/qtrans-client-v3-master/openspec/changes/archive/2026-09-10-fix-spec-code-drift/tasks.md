## 1. OpenSpec 状态语义

- [x] 1.1 将 `file-management` 的暂停状态 delta 规格纳入变更，并以 `openspec validate fix-spec-code-drift --strict` 验证规格格式。

## 2. qtransc transport 与兼容协议

- [x] 2.1 重构 HTTPS2 lane 为独占、惰性建立的 HTTP/2 client connection，移除单请求串行闸门，并以 `go build ./...`（qtransc 模块）验证编译。
- [x] 2.2 将 `golang.org/x/net` 作为 qtransc 的直接依赖，保持锁定版本，并以 `go build ./...`（qtransc 模块）验证依赖解析。
- [x] 2.3 修正 upload2/download2 对 task ID 的原样传递和按请求回显，并以 `go build ./...`（qtransc 模块）验证编译。

## 3. qtserver 正式 hash incarnation

- [x] 3.1 在正式 hash 的 lookup、claim、heartbeat、submit、fail、mutation 和 known-hash commit 脚本内原子获取并使用 Redis incarnation，并以 `go build ./...`（qtserver 模块）验证编译。
- [x] 3.2 删除正式 hash 决策对 Go 侧 Redis incarnation 缓存的依赖，并以 `go build ./...`（qtserver 模块）验证编译。

## 4. 收尾验证

- [x] 4.1 运行 qtransc 与 qtserver 的编译检查、`openspec validate fix-spec-code-drift --strict` 和 `git diff --check`，确认无格式错误。
