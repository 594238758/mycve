## Why

`qtransc --server aaa.cn:port list` 已能在本地识别参数错误，但面向用户的错误归一化会把该信息折叠为通用的“命令参数无效”。用户无法据此知道错误来自 `--server` 参数。

## What Changes

- 对 `--server` 的本地校验失败，保留稳定原因码 `CLI_INVALID_ARGUMENT`，并固定输出 `--server 参数不合法`。
- 保持其他参数错误的既有错误原因码和错误格式不变。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `client-error-contract`: 明确 `--server` 本地参数校验失败时的稳定错误格式和可修复说明。

## Impact

- 受影响代码：`qtransc/internal/clienterror` 中的本地错误归一化，以及必要时的 `qtransc` 地址解析错误分类。
- CLI 兼容性：`CLI_INVALID_ARGUMENT` 保持不变；仅改进人类可读的中文 message。调用方无需迁移。
- 不涉及 qtserver HTTP API、WebSocket 协议、传输行为或认证凭据输出。
