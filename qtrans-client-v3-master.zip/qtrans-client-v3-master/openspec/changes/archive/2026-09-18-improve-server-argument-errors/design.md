## Context

地址解析层已经能识别 `--server` 的本地校验失败；但它返回普通 `error`，随后统一错误归一化依据英文文本把它变为通用 `CLI_INVALID_ARGUMENT` 文案。详见 `proposal.md` 和本变更的 `client-error-contract` delta。

## Goals / Non-Goals

**Goals:**

- 让 `--server` 解析层产生稳定、可面向用户展示的错误。
- 保持现有原因码、`--debug` 诊断链和敏感信息脱敏机制。

**Non-Goals:**

- 不改变 `--server` 接受的地址语法、默认端口或传输协议选择。
- 不重写其他 CLI 参数的通用错误文案。
- 不改变 qtserver API、WebSocket 或 serve 的错误响应。

## Decisions

### 在地址解析边界构造已分类的 CLI 错误

`ParseQtransServer` 是全部直接命令解析 `--server` 的共同边界。它将在该参数缺失或格式非法时返回带 `CLI_INVALID_ARGUMENT` 的错误及固定中文 message `--server 参数不合法`；错误的底层原因保留为 cause，供 `--debug` 使用。

选择该边界而非在 `clienterror.Normalize` 中匹配英文错误文本：前者使用明确的参数语义，避免 Go 标准库或调用栈措辞变化导致错误分类漂移。`clienterror.Normalize` 对已分类错误保持原样，因此不影响其他调用方。

### 不回显用户输入的服务器地址

面向用户的 message 不需要回显原始地址即可指导修复。底层错误仅在 `--debug` 下输出，并继续使用既有脱敏逻辑处理。

## Risks / Trade-offs

- [地址解析新增路径遗漏] → 所有 `ParseQtransServer` 直接返回点都通过同一辅助函数封装，并用示例命令进行手工验证。
- [过度改变其他错误] → 仅处理 `--server` 解析失败；通用 `Normalize` 分支和其他参数错误保持不变。
- [不同底层原因导致文案漂移] → 在 `--server` 解析边界使用固定用户可见 message，不按失败原因细分。

## Migration Plan

1. 发布新 qtransc 二进制。
2. 自动化调用继续依赖不变的 `CLI_INVALID_ARGUMENT`；如解析人类可读 message，可改为展示更具体的 `--server` 修复提示。
3. 若需回滚，恢复通用文案即可；不存在数据迁移或服务端兼容性风险。
