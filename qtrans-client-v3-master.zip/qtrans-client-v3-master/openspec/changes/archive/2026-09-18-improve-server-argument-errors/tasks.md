## 1. `--server` 参数错误分类

- [x] 1.1 在 `ParseQtransServer` 的本地校验失败路径创建保留 cause 的 `CLI_INVALID_ARGUMENT` 错误，并固定 message 为 `--server 参数不合法`；验证不改变地址解析语法或其他参数的归一化行为。

## 2. 编译与命令行验证

- [x] 2.1 运行 `go build ./...`，并执行 `qtransc --server aaa.cn:port list` 与一个非端口地址格式错误示例，验证均输出 `Error [CLI_INVALID_ARGUMENT]: --server 参数不合法`；验证 `--debug` 仍输出底层诊断且不输出认证凭据。
