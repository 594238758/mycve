## MODIFIED Requirements

### Requirement: CLI 使用稳定原因码和中文可读错误

qtransc 的直接命令在非 JSON 模式发生可报告错误时 SHALL 在 stderr 使用 `Error [REASON_CODE]: 中文说明` 格式。`REASON_CODE` SHALL 是稳定的大写下划线标识符；来自 qtserver 结构化错误的 `reason_code` SHALL 原样传递。客户端自身产生的错误 SHALL 使用稳定客户端原因码，至少包括 `CLI_INVALID_ARGUMENT`、`AUTH_CONFIG_INVALID`、`AUTH_LOGIN_REJECTED`、`AUTH_LOGIN_FAILED`、`AUTH_REFRESH_FAILED`、`ANONYMOUS_READ_UNAVAILABLE`、`ANONYMOUS_WRITE_UNAVAILABLE`、`CAPABILITY_UNAVAILABLE`、`SERVER_UNAVAILABLE`、`RECURSIVE_DELETE_PARTIAL`、`MUTATION_RESULT_UNKNOWN`、`FILE_TOO_LARGE` 和 `TASK_FILE_LIMIT_EXCEEDED`。

当本地 `--server` 校验失败时，CLI SHALL 保持 `CLI_INVALID_ARGUMENT` 原因码，并固定输出中文说明 `--server 参数不合法`。该说明 SHALL NOT 泄露认证凭据或令牌，也 SHALL NOT 按端口、协议、路径或其他具体失败原因改变文案。

`--debug` SHALL 保留额外的底层诊断信息，但所有模式均 SHALL NOT 输出用户名、密码、access token、refresh token、OAuth client secret 或 Authorization header。用户名密码认证被拒绝时 SHALL 使用 `AUTH_LOGIN_REJECTED`，不得声称是用户名或密码中某一项错误。

#### Scenario: 路径不存在

- **WHEN** 直接 CLI 命令收到 qtserver 的 `NOT_FOUND`
- **THEN** stderr SHALL 输出 `Error [NOT_FOUND]:` 开头的中文说明

#### Scenario: 本地发现单文件超限

- **WHEN** qtransc 在传输规划中发现文件大小超过有效单文件上限
- **THEN** 它 SHALL 使用 `FILE_TOO_LARGE` 和中文说明报告错误

#### Scenario: 本地发现任务文件数超限

- **WHEN** qtransc 在传输规划中发现去重普通文件数超过 100000
- **THEN** 它 SHALL 使用 `TASK_FILE_LIMIT_EXCEEDED` 和中文说明报告错误

#### Scenario: 非法服务器端口

- **WHEN** 用户以 `--server aaa.cn:port` 执行直接 CLI 命令
- **THEN** stderr SHALL 输出 `Error [CLI_INVALID_ARGUMENT]: --server 参数不合法`

#### Scenario: 非法服务器地址格式

- **WHEN** 用户的 `--server` 值包含协议、路径或其他不符合 `host[:port]` 的内容
- **THEN** stderr SHALL 输出 `Error [CLI_INVALID_ARGUMENT]: --server 参数不合法`

#### Scenario: 用户名密码认证被拒绝

- **WHEN** qtransc 的用户名密码登录被认证服务拒绝
- **THEN** stderr SHALL 输出 `Error [AUTH_LOGIN_REJECTED]:` 开头的中文说明
- **AND** SHALL NOT 指出用户名或密码中哪一项错误

#### Scenario: 调试模式的敏感信息保护

- **WHEN** 用户以 `--debug` 执行命令且认证请求失败
- **THEN** qtransc SHALL 提供额外诊断
- **AND** SHALL NOT 输出任何认证凭据或令牌值
