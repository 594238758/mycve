## MODIFIED Requirements

### Requirement: taskid endpoint 独立生成关联标识

Qtserver SHALL 无认证且在健康运行时始终注册 `/qtserver/v1/taskid`。每次成功调用 SHALL 返回新的 UUID v4，且 SHALL NOT 创建上传、下载、Task 状态或其他业务资源，也 SHALL NOT 输出原始业务事件。

qtransc serve 创建 SHALL 要求调用方显式提供 taskId，且 SHALL NOT 因字段缺失自行申请 ID；缺失或空白值 SHALL 在请求阶段拒绝。直接 CLI 仍 MAY 按既有流程调用 taskid endpoint 取得新 ID。

同一个仍存在于qtransc进程内的task被再次start时 SHALL 继续使用该task保存的server task ID。Qtransc进程重启后由调用方使用新ID创建serve task，或CLI新进程在未显式提供原task ID时取得新ID，SHALL 被视为新task，并 SHALL 被日志视为新文件活动；本地download `.progress` SHALL 只恢复字节现场，不得自行恢复或猜测日志task ID。调用方需要显式跨进程延续同一文件活动时 SHALL 复用原task ID并保持路径、principal和action不变。Qtserver SHALL NOT 为跨进程合并task ID增加Task状态。

新task ID复用完整`.progress`且只执行整文件verify时 SHALL 形成新文件活动；其成功记录 SHALL 按`raw-business-event-log`输出零transmitted、零retry与null speed。复用原task ID并保持其余四元组字段时，旧chunk与新verify SHALL 属于同一file key完整历史。

#### Scenario: 申请 taskid

- **WHEN** 调用方或 qtransc 直接 CLI 调用 taskid endpoint
- **THEN** Qtserver SHALL 返回一个 UUID v4
- **AND** 该调用 SHALL NOT 改变文件或 session 状态
- **AND** SHALL NOT 输出 `task.registered` 或其他原始业务事件

#### Scenario: 同一内存task重新start

- **WHEN** qtransc在进程内对同一个已有task执行重新start
- **THEN** 后续文件请求 SHALL 继续使用该task原有server task ID

#### Scenario: 新进程只发现download progress

- **WHEN** 新qtransc CLI进程发现已有`.progress`但调用方没有提供原task ID
- **THEN** qtransc SHALL 使用新task ID并形成新的文件活动
- **AND** SHALL NOT 从progress路径、文件内容或服务端状态猜测原task ID

#### Scenario: serve 不自动申请 ID

- **WHEN** serve 创建请求未提供有效 taskId
- **THEN** qtransc SHALL 在请求阶段拒绝，不调用 taskid endpoint
