## MODIFIED Requirements

### Requirement: 本地 fingerprint 变化先删除 row 再停止上传

检测到本地源 fingerprint 变化后，qtransc SHALL 先删除对应 SQLite 行，再停止 workers并 best-effort cancel旧 session。无论 cancel 是否成功，下次执行 SHALL NOT 恢复旧 session。前台命令 SHALL 非零退出；serve task SHALL 进入 `failed` 并提示传输期间不可修改本地文件。

#### Scenario: 运行中检测到本地变化

- **WHEN** 任一 worker 或 complete 前检查发现 fingerprint 变化
- **THEN** SQLite row SHALL 在 cancel 之前删除
- **AND** 前台 SHALL 退出或 serve task SHALL failed

#### Scenario: cancel 请求失败

- **WHEN** 删除 row 后无法连接 Qtserver cancel
- **THEN** qtransc SHALL 继续新的开始流程而 SHALL NOT 恢复旧 session
