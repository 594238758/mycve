## MODIFIED Requirements

### Requirement: JSON 业务响应使用统一信封和 HTTP 200

serve JSON SHALL 使用 `{code,message,data?,meta?}` 和 HTTP 200。成功 SHALL 为 `0/Success` 并省略顶层 meta；失败 SHALL 使用注册表 API 请求类错误，携带两个显式布尔 meta 字段并省略 data。无载荷 SHALL 省略 data，空列表 SHALL 为 data:[]。

#### Scenario: 无载荷成功

- **WHEN** token 更新、启动、暂停或删除请求成功
- **THEN** SHALL 返回 0/Success，省略 data 和 meta

#### Scenario: 业务失败

- **WHEN** API 请求失败
- **THEN** SHALL 返回请求类错误及固定 message/meta，HTTP 为 200 且无 data

#### Scenario: 空任务列表

- **WHEN** 查询没有任务的列表
- **THEN** SHALL 返回 code=0 和 data:[]

### Requirement: serve wire 不输出字符串原因码

serve wire SHALL NOT 输出 reasonCode 或 reason_code。任务摘要、详情、列表和创建返回值中的 error SHALL 为可选对象 `{code,message,meta}`，文件视图 SHALL 使用相同错误结构。失败任务 SHALL 携带当前执行错误，其余任务状态 SHALL 省略 error；成功查询的 HTTP 外层 SHALL 为 0/Success。原有非错误业务字段 SHALL 保留。

#### Scenario: 查询失败任务

- **WHEN** 成功查询失败任务
- **THEN** 外层 SHALL 为 code=0，task.error SHALL 包含与对应失败 SSE 相同的执行码、message 和 meta

#### Scenario: 查询失败文件

- **WHEN** 文件最终失败
- **THEN** file.error SHALL 为执行错误对象，原有上传文件 message SHALL 与 error.message 一致

#### Scenario: 查询正常或暂停任务

- **WHEN** 任务 pending、running、completed 或主动 stopped
- **THEN** task.error SHALL 省略

### Requirement: 错误出现位置与任务终态遵循规范注册表

HTTP 顶层失败 SHALL 只使用 API 请求码；SSE 失败和 HTTP 任务、文件 error SHALL 只使用执行码。任务因执行故障终止 SHALL 为 failed，明确停止 SHALL 为 stopped 且无任务错误；内部重试 SHALL 保持 running。注册表预留码 SHALL NOT 输出。

#### Scenario: HTTP API 专用错误

- **WHEN** API 请求被拒绝
- **THEN** HTTP 顶层 SHALL 使用请求类错误

#### Scenario: 文件失败后任务失败

- **WHEN** 源文件变化或完整性校验最终失败
- **THEN** 文件及任务失败事件 SHALL 使用相应执行错误，任务终态 SHALL 为 failed

#### Scenario: 预留错误码

- **WHEN** 错误码标记为预留
- **THEN** 当前实现 SHALL NOT 输出该码

### Requirement: 未登记失败码归一为内部错误

失败构造 SHALL 按请求或执行类别校验登记。成功码、未登记、非法、预留或跨类别码 SHALL 归一为对应类别的内部兜底完整条目。

#### Scenario: 未登记错误码

- **WHEN** 使用未登记值构造失败
- **THEN** SHALL 使用所在类别的兜底 code/message/meta

#### Scenario: 跨类别错误

- **WHEN** 请求失败构造器收到执行码或反之
- **THEN** SHALL 归一为目标类别的兜底条目

### Requirement: SSE 使用统一结果信封

每条 SSE data JSON SHALL 为 `{messageType,code,message,data,meta?}`，前四项必填。正常事件 SHALL 为 0/Success 且无 meta；失败任务或文件事件 SHALL 携带执行错误及固定 meta。data SHALL 使用 lowerCamelCase，且 SHALL NOT 重复包含 error 或字符串原因码。

#### Scenario: 任务失败事件

- **WHEN** 已接受任务因执行故障终止
- **THEN** SHALL 发布 qtrans.task.status、status=failed 和对应执行错误

#### Scenario: 查询失败任务恢复错误

- **WHEN** 调用方错过失败 SSE 后成功查询仍在内存中的任务
- **THEN** HTTP 外层 SHALL 为 code=0，data.error SHALL 返回该任务当前执行错误

#### Scenario: 正常文件进度

- **WHEN** 发布文件进度
- **THEN** SHALL 使用 qtrans.file.progress、0/Success，省略 meta，data SHALL 保留 taskId、fileKey、total、transferred、rate

#### Scenario: 心跳事件

- **WHEN** 连接建立或心跳周期到期
- **THEN** SHALL 使用 qtrans.heartbeat、0/Success，timestamp SHALL 保持 RFC3339

### Requirement: 综合 API 文档链接规范注册表

综合 `qtransc-apis.md` SHALL 只说明信封规则、HTTP 与 SSE 的观察差异并链接唯一规范源 `qtransc/docs/qtransc-error-codes.md`，不得复制完整码表。请求和执行错误的普通顺序编号、预留及固定兜底分配、后续追加与发布后稳定性 SHALL 遵循该注册表的号码选取规则；分类器 SHALL 显式映射两类错误，不得通过加减固定数值推导。规范注册表 SHALL NOT 包含“调用方处置”列；任何码值、message、meta、适用对象或研发触发条件变化 SHALL 先修订并批准规范注册表，再同步 OpenSpec 与代码。

#### Scenario: 调用方查找错误码

- **WHEN** 调用方从综合 API 文档查找 QTrans 错误码定义
- **THEN** 文档 SHALL 指向独立错误码注册表
- **AND** 综合 API 文档 SHALL NOT 维护第二份完整码表

#### Scenario: 调整编号保持错误含义

- **WHEN** 按批准的注册表调整错误码编号
- **THEN** HTTP、SSE 和查询错误对象 SHALL 使用新的集中登记值
- **AND** 该错误的 message、meta、适用对象和触发条件 SHALL 保持注册表定义，API 示例 SHALL 使用相同新编号

## ADDED Requirements

### Requirement: 停止、重启与故障按执行轮次处理

任务最终错误 SHALL 采用首个记录的最终非取消错误，并保留各文件错误。已确认故障 SHALL 优先于后续停止。重启前轮次未释放 SHALL 拒绝；接受重启 SHALL 清除本轮重执行对象的旧错误，拒绝 SHALL 保留原快照。无停止意图的意外取消或未完成提前返回 SHALL failed。

#### Scenario: 故障后收到暂停

- **WHEN** 最终执行故障已记录，随后收到停止或清理取消
- **THEN** 任务 SHALL 保留 failed 及原故障

#### Scenario: 重启源文件变化任务

- **WHEN** 原上传任务因源文件变化要求新建任务，调用方仍启动原任务
- **THEN** SHALL 返回请求状态冲突，保留原执行错误

#### Scenario: 意外取消排队任务

- **WHEN** 已接受 pending 任务因基础设施故障被意外取消
- **THEN** SHALL 转为 failed 并携带执行错误

### Requirement: serve 正常关闭先停止全部活动任务

正常关闭 SHALL 先禁止创建、启动并使用注册表的关闭条目拒绝这些请求，再逐个停止 pending/running 任务并等待退出。已有终态 SHALL 保留，最终故障 SHALL 优先。完成收尾和终态发布后 SHALL 关闭 worker pool、SSE、HTTP、传输池及日志。停止阶段 SHALL NOT 新增强杀期限，HTTP 收尾 SHALL 沿用五秒期限。

#### Scenario: 正常停服

- **WHEN** 收到正常退出信号
- **THEN** SHALL 先逐个 stop 活动任务，再结束服务，主动停止任务 SHALL stopped 且无 error

#### Scenario: 关闭期间创建或启动

- **WHEN** 服务已进入关闭阶段且收到创建或启动请求
- **THEN** SHALL 返回注册表的请求类关闭条目，不接受新执行

### Requirement: 创建任务的请求校验与执行准备分离

serve 创建请求 SHALL 显式提供 taskId，trim 后 SHALL 非空且最多 128 字节；缺失、空白、null 或错误类型 SHALL 使用注册表的请求无效条目拒绝。serve SHALL NOT 为调用方申请 task ID。接受前 SHALL 只校验请求格式、字段及路径语法、认证配置、显式 fileList 项数和任务接收条件。显式 fileList 超过 100000 项 SHALL 返回请求类文件数量超限错误且不登记任务。

能力协商、本地文件存在性和可访问性、单文件大小、目录展开及下游可用性和远端鉴权检查 SHALL 在任务被接受后执行。预检属于 running 执行准备阶段，SHALL 绑定该轮任务 context，按既有期限与重试策略执行，并响应主动停止。最终预检错误 SHALL 使任务 failed 并保存执行错误；HTTP 创建成功的外层 SHALL 保持 0/Success，即使响应快照已经观察到 failed。CLI 同步预检及 Qtserver taskid endpoint SHALL 保持原契约。

#### Scenario: 缺少 taskId

- **WHEN** 创建请求缺失 taskId、值为空白或不符合字段类型要求
- **THEN** SHALL 返回注册表的请求无效条目，不创建任务且不访问 Qtserver

#### Scenario: 显式列表超限

- **WHEN** 请求 fileList 有 100001 项
- **THEN** SHALL 在入队前返回请求类文件数量超限错误，且不保留任务 ID

#### Scenario: 本地文件或服务端能力预检失败

- **WHEN** 合法创建请求已被接受，执行准备发现上传源不存在、单文件超限、能力不可用或下游不可达
- **THEN** 任务 SHALL failed 并保存对应执行错误
- **AND** 成功的创建和后续查询响应外层 SHALL 保持 0/Success，SSE SHALL 在顶层给出执行错误

#### Scenario: 目录展开后数量超限

- **WHEN** 显式列表未超限，但任务执行规划展开后的普通文件超过上限
- **THEN** 任务 SHALL failed 并保存执行类文件数量超限错误，不得开始部分内容传输

#### Scenario: 预检期间主动暂停

- **WHEN** 任务在能力预检期间收到主动停止且未确认最终执行故障
- **THEN** SHALL 取消预检，任务 SHALL stopped 且无任务 error
