## MODIFIED Requirements

### Requirement: qtransc 对下载hash mismatch只自动重下一次

普通下载第一次 file mismatch 时 qtransc SHALL 删除 `.progress` 并从零重下该文件一次；第二次仍 mismatch 时前台 SHALL 失败，serve task SHALL `failed`。v1 small SHALL 保持只重下失败文件且每个文件最多重新下载一次。v2 small SHALL 以整个批次为完整性重试单位，允许两次重新尝试，即最多三次完整传输；第三次仍有任一文件 mismatch 时前台 SHALL 失败，serve task SHALL `failed`。批量任务中已经通过普通或 v1 路径成功的其他文件 SHALL NOT 重下；v2 在批次通过 footer 提交门槛前 SHALL NOT 把其中的单文件视为已成功。

#### Scenario: 首次mismatch

- **WHEN** verify返回match=false且该文件尚未因mismatch重下
- **THEN** qtransc SHALL 从零重下一次

#### Scenario: 第二次mismatch

- **WHEN** 同一文件重下后再次mismatch
- **THEN** 前台 SHALL 非零失败或serve task SHALL failed

#### Scenario: v2 首次或第二次 mismatch

- **WHEN** v2 批次第一次或第二次完整传输出现任一 hash mismatch
- **THEN** qtransc SHALL 丢弃本次整个批次的临时结果并重新传输整个批次

#### Scenario: v2 第三次 mismatch

- **WHEN** v2 批次第三次完整传输仍出现任一 hash mismatch
- **THEN** 前台 SHALL 非零失败或 serve task SHALL failed
- **AND** SHALL NOT 启动第四次完整性尝试
