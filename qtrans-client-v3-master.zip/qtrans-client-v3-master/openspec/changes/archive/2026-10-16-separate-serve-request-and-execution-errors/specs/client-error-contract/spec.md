## MODIFIED Requirements

### Requirement: serve 控制面使用数字五位码

serve SHALL 按唯一注册表将 HTTP 请求失败和任务、文件执行失败分开表达。HTTP 查询失败任务 SHALL 外层成功并在数据 error 中返回当前执行错误；SSE SHALL 保持顶层执行结果。CLI 字符串原因码 SHALL 保留，serve SHALL NOT 输出字符串原因码。

#### Scenario: serve HTTP 参数错误

- **WHEN** 请求格式或字段无效
- **THEN** SHALL 使用请求类条目，包含固定 message/meta

#### Scenario: serve 任务 failed 事件

- **WHEN** 已接受任务最终失败
- **THEN** SSE SHALL 使用执行类错误，data.status SHALL failed

#### Scenario: 文件失败并使任务失败

- **WHEN** 源文件变化或校验最终失败
- **THEN** 文件及任务 SHALL 使用相应执行错误，任务 SHALL failed

#### Scenario: serve 任务失败快照

- **WHEN** 成功查询失败任务
- **THEN** 外层 SHALL code=0，data.error SHALL 返回当前执行错误，与对应 SSE 一致
