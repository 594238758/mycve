# Proposal

## Why

serve 把请求失败和执行失败共用同一码表，查询又无法恢复错过 SSE 的执行错误；故障 stopped 混淆暂停与失败。按用户已确认并明确要求实施的计划分离两类结果，同时保留三方协商的信封。

## What Changes

- **BREAKING**：HTTP 请求错误使用 30xxx，执行错误使用 31xxx；任务 error 从字符串改为结构化对象，文件视图增加 error。
- **BREAKING**：源文件变化、校验最终失败及无主动停止的异常退出统一 failed；不再输出 39999。
- SSE 保留顶层 code/message/meta；HTTP 查询外层成功，数据包含当前执行错误。
- **BREAKING**：serve 创建必须显式提供 taskId，不再代为申请；显式 fileList 数量超限仍在 HTTP 请求阶段拒绝，文件、能力和下游检查移至任务接受后的执行准备阶段。移除仅为同步预检保留的请求码副本，保留对应执行错误语义。
- 正常停服先拒绝创建、启动，再逐个 stop 活动任务，最后关闭服务资源。
- 注册表保持一张表，上 API、下执行；CLI、Qtserver 和旧 WebSocket 格式及退出码不变。
- **BREAKING**：按维护者要求将两类普通码分别从各自类别的第一个序号连续编号，预留项占用普通序号，各类别兜底固定使用末尾 999；错误语义、message、meta 和触发条件不变。后续新增按类别追加，已发布号码不重排，具体分配只在权威注册表维护。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `qtransc-serve-api-contract`: 两类码、结构化查询错误、SSE 和优雅停服契约。
- `client-error-contract`: serve 失败快照及故障终态，保留 CLI 契约。
- `file-management`: 下载完整性重试耗尽后的 serve 终态同步为 failed。
- `client-transfer-state`: 本地源变化使 serve 任务 failed，保留 session 清理和新任务要求。
- `client-preflight-timeouts`: serve 能力预检在任务内执行，沿用十五秒期限和任务停止取消。
- `transfer-task-correlation`: serve 强制调用方提供 taskId，CLI 和 Qtserver ID 分配协议不变。

## Impact

影响 serve wire、任务管理、上传下载执行和文件快照、信号退出协调，以及错误注册表和 API 文档。使用同一发布窗口切换；调用方适配 error 对象与新执行码，不提供双格式；异常时整体回滚。无新增依赖，不新增或运行测试、benchmark，仅编译和静态核对。
