## Context

当前 qtserver、qtransc 和 Nginx 中存在一套尚未上线的试验日志设计：它包含 task 状态、客户端 report、event/operation ID、started/finished 配对、source sequence 和 watermark。后续评审确认服务端的真实业务主体只是单文件，客户端展示状态不应进入服务端日志。项目不需要兼容这套试验实现，应直接删除并按本设计实现。

产品最终字段已固定在 `raw-business-event-log` spec；面向会议的完整解释、字段表和状态机图长期维护在项目内 `docs/server-business-logging-design.md`。本 design 只记录关键实现选择及其原因。

## Goals / Non-Goals

**Goals:**

- 用最少的服务端完成事实分析普通文件成功、TIMEOUT、实际传输量与分片重试。
- 小文件下载使用与普通下载明确不同、代码简单且符合服务端观察边界的成功语义。
- 让 ClickHouse 中的原始事件可以重放，并由 PostgreSQL 提供一行可修订的当前业务结果。
- 将 writer 失败、Nginx 可信字段和 credential 边界说清楚。

**Non-Goals:**

- 不建立 Task、session 或 operation 分析状态机。
- 不接收客户端 started、paused、completed、failed 或 abandoned 日志状态。
- 不精确识别整行事件丢失、采集重复、所有并发冲突或客户端本地失败。
- 不实现生产流处理平台、daemon、offset checkpoint、分布式锁或通用去重。
- 不改变现有传输授权、session ownership、grant HMAC、文件 hash 存储和真实文件成功点。

## Decisions

### 1. 以单文件四元组为唯一聚合单位

服务端不把 task 当作业务实体。`task_id` 只是客户端批次关联值，和规范路径、服务端 principal、action共同构成文件活动四元组。`file_key` 使用带 domain prefix 的 SHA-256确定性编码，避免在 Nginx 高频事件中重复路径和身份上下文。

Upload session虽然不以task ID做ownership，但会保存创建时的task ID作为不可变日志关联。恢复请求可以携带不同ID继续业务，producer仍使用session初始ID输出事件，避免一项文件活动被拆成两个aggregate。

Qtransc同一内存task重新start复用其server task ID；新进程或新task默认取得新ID并形成新文件活动，即使下载`.progress`恢复了相同字节现场。显式跨进程延续需要调用方复用原task ID并保持四元组其余字段不变，服务端不保存Task状态来猜测或合并活动。新ID只verify成功时本活动transmitted/retry为0且speed为null；复用旧ID时按同一file key完整历史统计。

同一file key的注册上下文保持不可变。源文件变化会停止旧上传而不是在同一aggregate中切换版本；新内容使用新task ID。这避免为`file_size`与hash引入“首次、最新或成功版本”的复杂裁决。

备选方案是保留 task aggregate和 task register。它会重新引入客户端展示语义、跨文件终态和上下文补全，而这些都不影响服务端单文件传输，因此删除。

### 2. schema v2只记录七类完成事实

事件公共外壳只包含 schema、event type、事实时间、task ID、file key和 typed payload。Chunk 请求结束本身就是一次 attempt；用相同 chunk index的事件数即可计算重试，无需 operation ID 或 started/finished配对。

这会主动放弃识别“请求开始后进程在任何完成日志前退出”所产生的精确字节。增加 started、event ID、source sequence和 statistics-complete仍无法发现整行日志完全消失，却会显著增加 producer和 reducer分支，因此第一版接受少量低估。

Schema version 固定为2，仅表示本次落地协议的 wire 版本；项目不读取或兼容旧试验格式。

Payload只保留最终归约所需字段。Verify事件不复制expected/actual hash或算法，chunk事件不复制请求级reason code；这些信息不改变状态、统计或最终字段，应留在现有hash存储和调试日志。这样也避免原始业务事件变成另一套排障日志。

Decoder对公共envelope严格，避免本major悄悄恢复event/operation等字段；对payload采用“已知字段严格、未知字段保留但忽略”。当前producer只输出本契约列出的最小字段，未来同一major可以增加不影响旧归约器的payload字段。跨事件的action、file key、Range/file size与时间约束在reducer中校验，无注册普通事件先留存而不是猜测上下文。

### 3. 普通文件只存在成功事实和 inactivity timeout

普通上传的成功事实是 committed 或 already-present；普通下载成功事实是整文件 verify matched。校验失败、cancel、session失效、客户端停止和单次服务端错误都可能继续重试，producer不提前声明文件失败。只要没有走到成功 API，分析器最终在 inactivity deadline输出 `FAILED/TIMEOUT`。

Verify事件只表示真正开始执行hash校验后的结果：完成比较为matched或mismatched，执行中因读取、计算或依赖错误无法得出结论为failed。认证、参数、路径、chunk完整性等前置失败，以及下载hash pending/unavailable尚无可比较结果，不输出verify完成事实。这样原始事件能区分“内容确实不一致”和“校验没有完成”，又不把控制面轮询伪装成文件活动。

上传和下载verify payload不强求形式对称。Canonical upload只有独立的chunk finalize，因此`upload.verify_finished`固定为chunk index加结果；complete内部的整文件hash组合和发布不形成file-scope verify，成功只由`upload.finished{committed}`表示。下载公开API支持chunk和file校验，所以`download.verify_finished`保留scope与可选chunk index。

零字节上传是canonical upload的零chunk特例，注册后complete直接用零chunk分层hash发布并committed；零字节下载则统一走small。普通`/d/down`只处理非空文件，Range和完整GET都必须携带chunk index，完整GET通常使用0并记录`[0,file_size)`。

状态机因此收缩为：

```mermaid
stateDiagram-v2
    [*] --> PROCESSING: file.registered
    PROCESSING --> PROCESSING: chunk/verify finished
    PROCESSING --> SUCCESS: committed / already-present / file verify matched
    PROCESSING --> FAILED: inactivity timeout
    FAILED --> SUCCESS: 迟到权威成功事实
```

TIMEOUT 结果允许被迟到成功修订，是因为采集链路和数据库处理仍可能延迟。普通迟到 attempt不重新打开文件，避免结果在 PROCESSING与 FAILED间反复跳动。

### 4. 小文件采用只记录正常发送完成的直达事件

小文件由 qtserver直接写tar响应。只有`io.Copy`成功、实际字节等于file size且Go `tar.Writer.Flush()`成功写出当前entry padding后才写 `download.small_file_sent`；该唯一事实append并sync成功后才开始下一个entry。之前不写注册事件，失败后也不写失败或 timeout。事件必须自包含最终上下文，分析器直接映射 `SUCCESS/SMALL_FILE_SENT`。事件不等待整个批次tar关闭，因此后续entry或tar尾部失败不会撤销已经完成的文件。逐文件sync有明确I/O成本，但避免为批量确认再增加协议和崩溃恢复状态。

Small成功后客户端可能因其本地观察改走普通路径。因为服务端明确不关心客户端落盘，reducer让第一次small成功对同一file key拥有终态优先级；后续普通事件只供inspect，不修订small统计。

零字节文件同样通过small tar传输。虽然没有payload字节，成功写入entry header并flush零长度entry仍是服务端可观察的文件边界；这比qtransc仅凭grant在本地创建空文件多了一条可分析的服务端成功事实。

这里的成功是“qtserver向响应栈写完”，不是“客户端已落盘”。Go/HTTP无法在不增加客户端确认协议的前提下证明后者，而用户明确将客户端故障排除在服务端范围外。日志事件写入发生在数据之后，写失败无法回滚响应，这是该简化路径接受的边界。

备选方案是让小文件走注册、Nginx finish、verify和 timeout。它能产生更多失败统计，但与“小文件失败完全不记录”的业务要求冲突，且会恢复已经删掉的状态机复杂度。

### 5. client metadata属于文件首请求而不是 taskid

`/taskid` 无认证地生成 UUID，不应为了日志持久化或绑定公共上下文。上传init、普通下载第一次`/d/down`以及small请求携带client ID、OS和version；qtserver在已有身份与路径校验后补充可信 principal、username、client/server IP。

Download grant发生在客户端按大小选择small/普通路径之前，因此它不能建立文件日志状态，否则small中断也会留下注册事件。Qtransc选最小待下载chunk作为注册分片，在收到其合法响应头前只运行该分片并在每次attempt携带metadata；无需Range的完整恢复则在第一次整文件verify携带。Qtserver以metadata是否完整作为注册标志，不增加download registration数据库：全有即注册、全无即后续、部分存在即拒绝。响应丢失可能产生少量相同注册，reducer取最早事实。这个无状态方案无法识别非规范客户端第一次就全不带metadata；其孤立普通事件只供inspect且不形成结果，这是明确接受的边界。小文件没有注册事件，所以成功事实携带完整上下文。Metadata不参与授权，避免日志字段改变传输兼容性或安全边界。

注册重试可能经不同入口或实例，后续IP、server instance/version及配置差异只作为上下文漂移，永不覆盖首次注册；file size或client metadata变化才作为语义冲突告警，但同样保留首次事实继续归约。最早时间并列且输出字段不同仍无法确定首次事实，第一版不猜测。

### 6. 普通下载由 chunk index跨 Range续传关联

Nginx只能可靠记录一次响应实际发送的字节和状态。qtransc为每个逻辑分片提供稳定 `chunk_index`，断点续传时改变实际 Range但保持 chunk index；分析器按 index统计额外data attempt，不试图区分是网络错误、hash mismatch还是客户端本地原因。

Qtserver通过七个 upstream-only handoff传递 task/file/index/规范Range以及expected status/bytes：`X-QT-Log-Task-ID`、`File-Key`、`Chunk-Index`、`Range-Start`、`Range-End`、`Expected-Status`和`Expected-Bytes`。Nginx使用对应`$upstream_http_*`而不是客户端header，并隐藏全部handoff。Schema version和event type由专用log format固定，不为每个响应传递；event/operation/started等无关handoff全部删除。Nginx用request completion、实际status、Content-Range和body bytes判断succeeded/interrupted/failed；只有状态与Range仍表示文件数据时body bytes才计入actual bytes，错误响应body固定按0处理。未启用加速时qtserver direct响应使用同一判定表生成`download.chunk_finished`，分析器不区分producer。这样无需operation UUID，也不会把错误页字节计作文件传输量。

隔离的官方Nginx验证确认X-Accel internal redirect后的access-log仍保留原upstream response变量。配置因此继续使用upstream handoff，但在专用`access_log`前增加七项结构校验和条件写入；缺字段时变量会呈现`-`，必须跳过业务日志行而不是输出无效JSON。跨字段Range关系留给独立decoder校验，避免在Nginx map中堆叠复杂业务逻辑。

第一版不要求Nginx用复杂正则逐字符比较实际Content-Range与handoff Range；qtserver已经规范化请求，Nginx仍校验预期状态、Content-Range结构和预期字节数。极端代理偏离可能无法精确识别，这是保持配置与代码清晰的有意边界。

### 7. ClickHouse保存事实，PostgreSQL保存当前结论

原始 JSONL进入 ClickHouse append-only `raw_events`。正式分析程序可以按 dirty keys 优化处理，但必须能够依据完整历史重算同一结果。当前最终记录使用 `file_key` UPSERT到分析程序自己的 PostgreSQL，内容不变不刷新 `log_time`，TIMEOUT后迟到成功则更新同一行。

物理结构保持三张最小表：ClickHouse `raw_events`保存可查询公共列与完整payload JSON，ClickHouse `quarantine`只保存来源、稳定原因和安全摘要，PostgreSQL `business_file_logs`按file key保存全部当前字段。没有事件去重表、aggregate快照、checkpoint或dirty-key表。时间用毫秒UTC，最终decimal固定三位；`server_ip`使用与最终JSON string类型一致的text。

qtserver自己的 PostgreSQL继续只保存文件 hash，不参与分析结果。

TIMEOUT是一次统计截断：没有成功事实时忽略deadline之后的普通事件，保持当前结果稳定；迟到成功出现后再以成功时间作为新终点全历史重算，并纳入此前被截断的attempt。这避免无终态噪声不断更新下游，同时不丢失最终成功传输的网络成本。

归约先确定闭区间统计窗口：成功使用注册到最早权威成功，TIMEOUT使用注册到首次不活动deadline。窗口外普通事件只供inspect。相同上传终态重试取最早时间，但`committed`与`already_present`同时存在表示producer冲突，第一版停止输出该候选而不猜测优先级。

同一 `occurred_at` 的普通事实按时间组作为集合处理，不使用ClickHouse导入顺序，也不为排序重新引入event ID。闭区间包含与成功事实同时间的全部attempt；活动组恰好位于deadline时先刷新deadline。只有committed与already-present并存等语义互斥事实无法靠集合归约，按少量producer异常报告并停止候选输出。

### 8. Writer可靠性按可逆边界处理

普通文件注册必须append并sync后才接受业务动作。Committed、already-present或file verify matched已经发生时不得回滚真实文件结果，但终态事件append并sync成功前不向客户端返回成功；失败时返回可重试日志错误，恢复后由幂等API重试补出内容一致的成功事实。Qtserver进入logging-unhealthy后拒绝所有下一步会产生v2事件的传输/校验API，不能只拦新文件，否则会扩大静默缺口。Writer/健康组件独立执行不产生伪事件的reopen与sync探测，成功后先清除gate再允许终态重试；恢复不能依赖被gate拒绝的业务请求。

过程事件发生在数据或校验事实之后，写失败不能回滚业务，当前请求返回真实业务结果；实例转为不健康并停止后续事件生产。Writer不能为恢复盲目重复append：完整行后的sync失败只重试sync，partial write只有truncate+sync回原边界后才重写，无法证明时保持不健康并由独立恢复清除active不完整尾部。否则没有event ID时producer自身会把一个chunk制造成多个attempt。Direct/Nginx响应和small entry已经写出后同样不能回滚：direct使qtserver不健康，small还停止当前批次后续entry，Nginx依靠error log与采集监控而不反向联动qtserver。没有started事件时分析器可能完全看不到本次事实，这是简化协议已接受的风险，而不是由reducer猜测。

## Risks / Trade-offs

- [完成事件整行丢失会低估 transmitted或产生 TIMEOUT] -> writer健康、独立采集监控和隔离全链路验证负责降低概率；第一版不增加事件身份与sequence协议。
- [small response写完不等于客户端收到] -> 成功原因明确命名为 `SMALL_FILE_SENT`，文档固定服务端观察边界，不承诺客户端落盘。
- [没有客户端状态后无法区分放弃、崩溃和等待] -> 普通文件统一使用 inactivity timeout，避免猜测客户端原因。
- [不同 producer时钟偏差影响 duration和deadline] -> 部署统一UTC/NTP；未来事件在analysis time追上前只保存和展示，持续漂移由监控告警，不由reducer校正或虚构全局序号。
- [Nginx合法206但Content-Range内容与handoff Range异常偏离] -> 第一版校验状态、Content-Range结构和预期字节数，不增加复杂动态Range比较；通过隔离全链路测试覆盖正常Range和中断。
- [成功点后写日志失败无法重建事实] -> qtserver停止新起点并暴露不健康；接受已发生业务与日志结果短时不一致，而不回滚用户文件。

## Implementation Plan

1. 按 schema v2重建事件类型、file key、writer与配置，直接删除旧试验输出。
2. 删除 `/taskid` 业务事件和 `/e/event` 客户端状态上报；把 metadata迁移到文件首请求。
3. 接入上传注册、chunk、verify和finished事实，并让upload init携带整文件 hash。
4. 接入普通下载chunk index、可信Nginx handoff、download finish与整文件verify成功点。
5. 将small路径替换为只在单文件完整写完后输出自包含成功事件。
6. 使用隔离环境完成真实上传、普通下载、小文件下载和最终日志生成验收。

### 9. inactivity timeout默认24小时

`log.file_inactivity_timeout_seconds`默认86400秒并要求大于0。默认值与现有upload session retention一致，避免默认部署中session已经不可恢复而日志仍长时间保持PROCESSING；两项配置保持独立并在file registered中固化历史值。

### 10. duration与speed表达业务窗口而非网络测速

普通文件从registered到成功/timeout计算wall-clock duration，不扣服务端不可见的客户端暂停；speed使用file size除以该窗口。Transmitted单独保留重试网络成本。Small仅计算单个tar entry在服务端内的写入窗口，因此两条路径的speed都可用于业务观察，但不声称是可直接对比的链路瞬时吞吐率。

跨语言输出按整数毫秒固定duration，再用decimal计算并将speed四舍五入到三位小数；不依赖二进制浮点格式或从展示duration反算。这样PostgreSQL可使用固定scale numeric，Java与Go fixture也能逐字段比较。

Already-present没有传输文件内容，固定为`transmitted=0`、`retry_count=0`、`speed=null`，但保留注册到内容确认之间的duration。Timeout按事件时间顺序寻找第一个完整不活动间隙：只有不晚于当前deadline的chunk/verify完成事件可以延长deadline；一旦遇到更晚的普通事件就固定首次deadline。这样批量重放不会因已经读到deadline后的噪声而把历史TIMEOUT不断后移。

### 11. anonymous是内置用户而不是下载模式

系统不建立“匿名下载”业务分支。`anonymous` 是没有密码、任何调用方都可选择的内置用户；qtserver 直接构造其 principal，不访问外部身份服务，并固定 `principal_id=anonymous`、`client_username=anonymous`。普通用户和 anonymous用户共享相同的传输事件、成功事实与 reducer，既有文件空间和 API 权限边界不因日志设计改变。

### 12. task type只表示场景分类

`log.task_type` 第一版采用产品既有编码：字符串 `"0"` 表示多中心，字符串 `"1"` 表示 C/S，默认 `"1"`。它只是一个日志配置和场景分类，不参与其他字段的收集或输出，也不参与传输协议、授权、文件空间、事件分类或状态机。

Producer在注册和small成功事件中记录完整、可信的`server_ip`、`client_id`和`client_os`。Reducer生成最终标准业务日志时，无论历史上下文的`task_type`为`"0"`还是`"1"`，都原样输出这三个字段以及其他上下文字段，不按task type删除、清空或改写字段。

### 13. 下载分片身份使用单一外部请求头

普通下载需要区分同一分片的断点续传、重试和其他并发分片，否则只凭变化后的 Range 无法确定 `retry_count`。Qtransc 已经具有稳定分片编号，因此每个 `/d/down` 请求使用 `X-QT-Chunk-Index` 传递非负编号；它只服务日志关联，不进入授权、文件定位、Range 或成功语义。

Qtserver先校验客户端值，再用 `X-QT-Log-Chunk-Index` 构造只对Nginx可见的内部handoff。Nginx只信任upstream handoff而不读取客户端同名字段，避免把客户端输入直接写成服务端原始事实。这个单字段扩展足以支持重试统计，不增加 operation、started event或服务端下载注册状态。

### 14. username与最终扩展字段已固定

Qtserver当前可信principal、userinfo解析和身份缓存只提供稳定用户ID。第一版因此固定`client_username=principal_id`，把它视为产品格式兼容字段而非独立展示名；producer不读取客户端自报username，也不为日志扩展身份服务调用或缓存结构。`anonymous`的两项值均固定为`anonymous`。未来只有身份链路完整提供可信展示名时，才通过新的契约修订改变该字段语义。

最终记录固定增加`file_key`、`principal_id`、`result`、`result_reason`、`retry_count`和`speed`六项，并固定使用`UPLOADED_AND_COMMITTED`、`ALREADY_PRESENT`、`DOWNLOADED_AND_VERIFIED`、`SMALL_FILE_SENT`和`TIMEOUT`五个原因码。它们已经是实现契约，不再保留为Open Question。

### 15. 权威成功事实独立于活动deadline

Deadline只限制chunk和非成功verify是否还能延长PROCESSING活动窗口，不是成功事实的有效期。Reducer必须先从完整历史识别合法`upload.finished`或整文件matched，再选择SUCCESS统计窗口；不能先丢弃deadline后的全部事件，否则日志采集稍晚或TIMEOUT先落库时会永久漏掉真实完成结果。只有deadline后仍然只有过程事实时，首次TIMEOUT才保持不变。

### 16. 时钟同步是部署前提而不是reducer状态

跨qtserver与Nginx事件必须按`occurred_at`共同排序，因此部署使用NTP同步。第一版不引入allowed lateness、watermark或时钟偏差校正；每轮只看不晚于固定analysis time的事件，未来事件留在ClickHouse等待后续运行。这个边界既避免输出未来end time，也保持batch重放确定性，持续漂移交给监控处理。

Wire和最终输出时间固定为UTC RFC3339三位毫秒，匹配ClickHouse `DateTime64(3)`与duration毫秒算法。Producer在编码前截断，decoder严格拒绝其他wire精度；analysis time同样归一，避免数据库写入时隐式截断改变同时间分组。
