## MODIFIED Requirements

### Requirement: taskid endpoint 独立生成关联标识

Qtserver SHALL 无认证且在健康运行时始终注册 `/qtserver/v1/taskid`。每次成功调用 SHALL 返回新的 UUID v4，且 SHALL NOT 创建上传、下载、Task 状态或其他业务资源，也 SHALL NOT 输出原始业务事件。

同一个仍存在于qtransc进程内的task被再次start时 SHALL 继续使用该task保存的server task ID。Qtransc进程重启后新建task或CLI新进程在未显式提供原task ID时 SHALL 取得新ID，并 SHALL 被日志视为新文件活动；本地download `.progress` SHALL 只恢复字节现场，不得自行恢复或猜测日志task ID。调用方需要显式跨进程延续同一文件活动时 SHALL 复用原task ID并保持路径、principal和action不变。Qtserver SHALL NOT 为跨进程合并task ID增加Task状态。

新task ID复用完整`.progress`且只执行整文件verify时 SHALL 形成新文件活动；其成功记录 SHALL 按`raw-business-event-log`输出零transmitted、零retry与null speed。复用原task ID并保持其余四元组字段时，旧chunk与新verify SHALL 属于同一file key完整历史。

#### Scenario: 申请 taskid

- **WHEN** qtransc 在没有 task ID 时调用 taskid endpoint
- **THEN** Qtserver SHALL 返回一个 UUID v4
- **AND** 该调用 SHALL NOT 改变文件或 session 状态
- **AND** SHALL NOT 输出 `task.registered` 或其他原始业务事件

#### Scenario: 同一内存task重新start

- **WHEN** qtransc在进程内对同一个已有task执行重新start
- **THEN** 后续文件请求 SHALL 继续使用该task原有server task ID

#### Scenario: 新进程只发现download progress

- **WHEN** 新qtransc进程发现已有`.progress`但调用方没有提供原task ID
- **THEN** qtransc SHALL 使用新task ID并形成新的文件活动
- **AND** SHALL NOT 从progress路径、文件内容或服务端状态猜测原task ID

### Requirement: qtransc 为上传和下载请求携带 X-Task-ID

qtransc SHALL 为同一个客户端 upload/download task 的 Qtserver 文件请求携带 `X-Task-ID`。Canonical upload session MAY 保存创建时收到的初始 task ID，但 SHALL 只把它用作不可变的日志关联值，不得用它参与 session ownership、业务幂等性、鉴权或签名。服务端 SHALL 把文件而不是客户端 task 作为日志主体；同一个客户端 task 中的多个文件 SHALL 分别产生文件活动。

Canonical upload session创建时的 task ID SHALL 固定为该文件活动的日志关联值。后续请求携带不同 `X-Task-ID` 恢复同一 principal拥有的session MAY 继续业务，但qtserver产生的chunk、verify和commit原始事件 SHALL 使用session保存的初始task ID及其`file_key`；当前请求的不同ID只可用于调试诊断。

#### Scenario: 恢复上传时重新创建 task

- **WHEN** qtransc 使用 SQLite 中的同一 session 恢复上传但当前 taskid 不同
- **THEN** Qtserver SHALL 按当前认证 principal 和 session 继续上传
- **AND** taskid 变化 SHALL NOT 使 session 失效
- **AND** 后续原始业务事件 SHALL 继续使用session创建时的task ID

#### Scenario: 第三方伪造 header

- **WHEN** 第三方请求携带任意受信任格式的 X-Task-ID
- **THEN** 该值 SHALL 只影响当前请求和文件日志关联
- **AND** SHALL NOT 扩大调用方权限或改变业务结果

## ADDED Requirements

### Requirement: 每个文件的第一个请求携带日志上下文

qtransc SHALL 在每个文件的第一个有效上传 init、普通下载注册分片请求或 small download 请求中携带 `Client-ID`、`Client-OS` 和 `Client-Version`。普通下载注册分片 SHALL 是本次启动时最小的待下载`chunk_index`；在收到该分片一次合法HTTP响应头以前，该分片的每次attempt SHALL 携带完整metadata，且qtransc SHALL NOT 启动该文件其他分片请求。收到合法响应头后，后续Range SHALL 不再要求metadata。如果恢复现场无需任何数据请求，第一次整文件 `/d/verify` SHALL 作为注册请求携带metadata。Qtserver SHALL 从配置取得 `task_type`、instance与timeout，从当前构建取得server version，从服务端解析的可信 principal取得 `principal_id`并固定`client_username=principal_id`；`anonymous`直接使用两项值`anonymous`而不查询身份服务。Qtserver SHALL 从可信网络边界取得 `client_ip` 与实际外部入口 `server_ip`，并从当前文件事实取得规范路径与file size。Qtransc SHALL NOT 提交 username、task type或服务端字段作为可信日志上下文，Qtserver也 SHALL NOT 从旧`/taskid`上下文回读这些字段。这些字段 SHALL 只用于文件日志上下文，不得参与授权、session ownership、grant HMAC、文件归属或传输成功判定。

每个普通下载 `/d/down` GET还 SHALL 使用 `X-QT-Chunk-Index` 携带稳定的非负分片编号，包括Range和无Range完整GET。该编号 SHALL 只用于原始日志的分片关联和retry count分组，不得参与授权、grant、文件定位或Range计算；具体校验、零字节small分流与可信Nginx handoff规则由`raw-business-event-log`定义。

Download grant同时服务small与普通文件，SHALL NOT 产生原始业务事件，也不得被视为普通文件注册点。普通文件除指定注册请求外的后续 Range、verify和complete请求 SHALL NOT 重复提交这些客户端字段。Small download 因不产生独立注册事件，其成功事件 SHALL 使用当前请求携带的 metadata。

上传init与small请求是各自路径明确的首请求，缺少任一metadata时Qtserver SHALL 拒绝。对普通下载`/d/down`和`/d/verify`，Qtserver SHALL 把三项metadata全部存在解释为注册请求，全部不存在解释为后续请求，只有部分字段存在 SHALL 以参数错误拒绝。Qtserver SHALL NOT 为此增加download registration业务状态；指定请求因HTTP异常重试产生内容一致的重复注册事实 MAY 被分析程序按最早事实合并。

因为Qtserver不保存普通下载注册状态，它 SHALL NOT 声称能区分“合法后续请求全无metadata”和“违反协议的首请求全无metadata”。Qtransc SHALL 通过注册分片串行握手保证自己的首个普通请求完整携带metadata。其他客户端若违反该契约，后续数据请求 MAY 产生无`file.registered`的孤立原始事件；分析程序 SHALL 保留但不得在注册到达前形成最终结果。

#### Scenario: 上传文件第一次 init

- **WHEN** qtransc 为一个文件发送第一次有效 upload init
- **THEN** 请求 SHALL 携带 client ID、OS 和 version
- **AND** Qtserver SHALL 使用可信服务端事实补齐该文件日志上下文

#### Scenario: 上传或small首请求metadata缺失

- **WHEN** upload init或small download请求缺少任一必填client metadata
- **THEN** Qtserver SHALL 在形成文件活动前拒绝该请求
- **AND** SHALL NOT 输出不完整的原始业务事件

#### Scenario: grant 后选择 small 路径

- **WHEN** qtransc 获取 download grant 后把文件分到 small download路径
- **THEN** grant SHALL NOT 已经为该文件产生 `file.registered`
- **AND** small请求未完整写完时 SHALL 不留下任何该文件原始业务事件

#### Scenario: 恢复下载无需Range请求

- **WHEN** qtransc本地已经具有全部文件数据且只需执行整文件verify
- **THEN** 第一次整文件verify SHALL 携带完整client metadata
- **AND** Qtserver SHALL 在校验前可靠输出`file.registered`

#### Scenario: metadata只出现一部分

- **WHEN** 普通下载请求只携带Client-ID、Client-OS、Client-Version中的一部分
- **THEN** Qtserver SHALL 以参数错误拒绝
- **AND** SHALL NOT 输出不完整注册事实

#### Scenario: 非规范客户端下载首请求完全不带metadata

- **WHEN** 非qtransc客户端第一次调用普通`/d/down`时三项metadata全部缺失
- **THEN** Qtserver MAY 按无状态协议把它解释为后续请求并发送数据
- **AND** 相应chunk事件 SHALL 在缺少注册时只保留供inspect使用，不得形成最终日志

#### Scenario: 注册分片响应头尚未确认

- **WHEN** 注册分片请求在qtransc收到合法响应头前发生网络错误
- **THEN** qtransc SHALL 使用完整metadata重试该注册分片
- **AND** SHALL NOT 启动其他分片请求

#### Scenario: 注册分片响应丢失导致重复注册

- **WHEN** Qtserver已经注册并返回响应但qtransc未收到响应头而重试
- **THEN** Qtserver MAY 输出内容一致的重复`file.registered`
- **AND** 分析程序 SHALL 使用最早合法注册事实

#### Scenario: 客户端伪造身份或 IP

- **WHEN** 客户端提交的字段与已认证 principal 或可信网络观察值冲突
- **THEN** Qtserver SHALL 使用服务端可信事实
- **AND** 客户端字段 SHALL NOT 改变授权结果

### Requirement: 文件活动使用稳定四元组关联

原始业务事件中的文件活动 SHALL 由 `(task_id, normalized_file_path, principal_id, action)` 唯一关联。`action` SHALL 是 `upload|download`。系统 SHALL NOT 定义“匿名下载”类型；选择内置 `anonymous` 用户的合法文件请求 SHALL 直接使用 `principal_id=anonymous` 和 `client_username=anonymous`，且 Qtserver SHALL NOT 为该用户查询外部身份服务。Qtserver SHALL 使用 `raw-business-event-log` 定义的确定性算法生成 `file_key`，且 SHALL NOT 把 `file_key` 当作新的授权或资源 ownership 字段。

#### Scenario: 一个客户端 task 包含多个文件

- **WHEN** qtransc 使用同一 task ID传输两个不同规范路径的文件
- **THEN** Qtserver SHALL 形成两个不同 `file_key` 的文件活动
- **AND** SHALL NOT 创建服务端 Task aggregate

#### Scenario: 同一路径上传和下载

- **WHEN** 同一 task ID、principal 和规范路径分别执行上传与下载
- **THEN** 两项活动 SHALL 因 action 不同而使用不同 `file_key`
