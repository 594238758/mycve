## Why

当前日志设计把客户端 task 状态、传输 operation、请求事实和文件结果混在一起，复杂度明显超过“按单文件生成最终业务日志”的真实需求。项目尚未上线，不需要兼容这套试验设计；需要直接固定最终字段、最小原始事件集和可重放分析规则，并用实际使用 ClickHouse 与 PostgreSQL 的参考程序证明它能够工作。

## What Changes

- 把产品要求的 16 个最终标准业务日志字段、六个扩展字段及五个原因码固定在项目内 OpenSpec；一期固定`client_username=principal_id`且不为日志扩展身份服务，外部 Excel 只保留为历史需求来源。
- 服务端只把单文件活动作为日志主体，以 `(task_id, normalized_file_path, principal_id, action)` 及其确定性 `file_key` 关联事件；不建立 Task 业务实体或 Task 状态机。
- `/taskid` 只分配关联 ID，不产生原始业务事件。客户端在上传 init、普通下载第一次 `/d/down` 或 small 请求中携带文件日志 metadata；download grant 不产生原始事件。
- 原始事件固定为 schema v2，只保留 `file.registered`、三类上传完成事实、两类普通下载完成事实和 `download.small_file_sent` 共七类事件；删除 event ID、operation ID、started/finished 配对、task/session 状态和客户端 report。
- 普通上传以 committed/already-present 为成功事实，普通下载以整文件 `/d/verify matched` 为成功事实；没有成功事实的普通文件在 inactivity timeout 后形成 `FAILED/TIMEOUT`。
- 小文件下载采用特殊直达规则：服务端完整写完单个文件才记录一条自包含成功事件；未写完、中途停止或客户端故障不记录原始业务事件，也不进入 timeout 状态机。
- 校验失败或单次分片失败不直接结束文件；后续重传成功仍为最终成功，完成事件中的实际字节和相同 chunk index 的额外次数用于计算传输量与重试次数。
- ClickHouse 保存原始事件；日志分析程序自己的 PostgreSQL 保存每个 `file_key` 当前最终业务日志并允许由迟到权威成功事实修订。
- 调试日志只保留种类和用途说明，分析程序不得依赖调试日志补齐业务事实。
- 删除旧试验代码中的 `event.log`、`file_transmit.log` 和文本式 Nginx `download.log`，不提供兼容或迁移旁路。

非目标：不在 qtserver 内生成最终业务日志，不接收客户端 started/paused/completed/failed 等展示状态，不为低概率日志丢失或采集重复引入通用去重、全局序号、watermark 或分布式状态协议。

## Capabilities

### New Capabilities

- `raw-business-event-log`: 定义最终标准业务日志字段、单文件身份、schema v2 七类原始事件、普通文件状态机、小文件直达语义、超时和迟到修订规则。

### Modified Capabilities

- `transfer-task-correlation`: `/taskid` 明确只分配关联 ID且不产生业务事件；client metadata 从 taskid 请求迁移到每个文件的第一个传输请求，task ID 保持只关联不授权的边界。

## Impact

- qtransc：文件首请求 metadata、上传 init 整文件 hash、普通下载 chunk index 和整文件 verify 流程；删除日志状态上报。
- qtserver：schema v2 模型与 writer、taskid handler、上传/download/verify 事件接入、日志健康、配置和 API 文档；删除 `/e/event` 日志上报设计。
- Nginx：X-Accel模式使用qtserver可信handoff输出`download.chunk_finished`并隐藏内部header；direct模式由qtserver输出同一事件。
- 文档与部署：长期维护 `docs/server-business-logging-design.md`，同步配置/API 文档和部署模板，并提供隔离数据库的验证方式。
