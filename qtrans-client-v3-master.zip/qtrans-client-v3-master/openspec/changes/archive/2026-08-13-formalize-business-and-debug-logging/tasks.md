## 1. 评审门槛与契约收尾

- [x] 1.1 固定`log.file_inactivity_timeout_seconds`默认86400秒并同步design与行为spec；实现阶段再同步配置文档和模板。
- [x] 1.2 固定零字节下载走small路径，并补充零长度tar entry与最终字段Scenario。
- [x] 1.3 固定一期`client_username=principal_id`、六个扩展字段及五个`result_reason`，并确保会议文档与三个delta spec语义一致；producer不为日志扩展身份服务或信任客户端username。
- [x] 1.4 对 `formalize-business-and-debug-logging` 执行 OpenSpec strict validation，修正所有格式和引用错误。

## 2. schema v2模型与可靠写入

- [x] 2.1 在qtserver定义schema v2最小envelope、七类typed payload、稳定result值和UTC三位毫秒RFC3339时间编码，verify不复制hash且chunk不复制请求级reason，删除event/operation/task状态类型依赖。
- [x] 2.2 按四元组和`qtrans-file-v1`算法实现确定性`file_key`，统一使用已规范路径、可信principal和action。
- [x] 2.3 收缩`BusinessEventWriter`为串行完整JSONL append、注册/成功终态（含small）sync和关闭段轮转压缩；记录写前边界，完整行sync失败只重试sync，partial write仅在truncate+sync回边界后重写。
- [x] 2.4 将writer接入qtserver启动、关闭和健康检查；unhealthy时拒绝所有后续v2事件生产API，由独立reopen+sync探测先清除gate再恢复，避免恢复依赖被拒绝的业务请求自锁；不产事件的查询/恢复操作可继续。
- [x] 2.5 对注册写失败在业务前返回可重试日志错误；过程事实写失败不回滚已发生业务；committed/already-present/file-matched在终态事件sync前不返回成功并支持恢复后幂等重试补写。
- [x] 2.6 对direct响应后事件失败进入不健康；small entry事件失败停止批次后续文件；Nginx写失败由error log与采集监控暴露而不反向联动qtserver。
- [x] 2.7 更新`qtserver/docs/config.md`与`qtserver/deploy/qtserver_config_default.toml`，新增默认`log.task_type="1"`并只接受`"0"|"1"`，同时固定timeout和外部入口配置。

## 3. taskid与文件首请求上下文

- [x] 3.1 移除`/taskid`的`task.registered`及上下文持久化，使API只返回UUID v4并保持现有无认证兼容性。
- [x] 3.2 删除qtserver `/e/event`及qtransc task/file状态上报路径，不再生成report ID或客户端业务状态事件。
- [x] 3.3 让qtransc选择最小待下载chunk作为注册分片，在其合法响应头确认前只重试该分片并携带metadata；无数据恢复用整文件verify注册，grant不建立日志上下文。
- [x] 3.4 让qtserver从可信principal、代理/入口信息、配置和规范路径构造完整文件上下文；upload init/small缺少任一metadata时拒绝，普通下载全有即注册、全无即后续、部分存在时拒绝。
- [x] 3.5 同步更新`qtserver/docs/qtserver-apis.md`，删除事件上报API并记录taskid与文件首请求metadata契约。
- [x] 3.6 保持同一内存task重新start复用server task ID；新进程只发现`.progress`时不猜测旧ID，显式跨进程延续由调用方复用原task ID。

## 4. 普通上传原始事件

- [x] 4.1 在第一个合法upload init前可靠输出`file.registered`，并让canonical init接收整文件hash与算法。
- [x] 4.2 固定使用upload session创建时保存的task ID和file key输出后续chunk、verify与finished事实，请求task ID变化只影响调试标签。
- [x] 4.3 在每次已准入canonical PATCH结束时输出`upload.chunk_finished`，将分片内Upload-Offset换算成本次请求的文件绝对半开Range，按request body实际读取字节记录actual bytes，并区分succeeded/interrupted/failed。
- [x] 4.4 在通过前置校验并实际执行chunk hash读取/计算/比较后输出仅含chunk index与结果的最小`upload.verify_finished`，区分matched、mismatched和执行失败failed；前置失败不产生日志，complete不虚构file-scope verify，单次非matched不升级为文件终态。
- [x] 4.5 在原子发布后输出`upload.finished{committed}`；只有客户端init hash与服务端目标大小、算法、hash均一致时输出`upload.finished{already_present}`。
- [x] 4.6 删除cancel/release/expire和客户端放弃的文件失败事件；没有上传成功事实的文件只由分析器TIMEOUT。
- [x] 4.7 删除旧event/file-transmit业务日志输出和配置，不提供兼容旁路。
- [x] 4.8 保持源文件变化时停止旧file key，并确保重新上传变化内容时客户端使用新task ID。
- [x] 4.9 支持零字节canonical upload以零chunk session直接complete并输出committed，最终零transmitted/retry且null speed。

## 5. 普通与small下载原始事件

- [x] 5.1 移除download grant原始事件；普通文件在携带完整metadata的指定`/d/down`或整文件verify可靠输出`file.registered`，部分metadata拒绝且不增加持久download registration状态；非规范客户端产生的无注册孤立事件不形成结果。
- [x] 5.2 让qtransc每个普通`/d/down` GET（Range或完整GET）用`X-QT-Chunk-Index`携带稳定非负chunk index；断点续传只推进Range而不更换index，缺失或非法值在注册和发送数据前拒绝。
- [x] 5.3 在普通下载调度中先完成注册分片响应头握手再开放同文件其他chunk并发，允许响应丢失造成一致重复注册。
- [x] 5.4 让qtserver校验外部`X-QT-Chunk-Index`，通过固定七项`X-QT-Log-{Task-ID,File-Key,Chunk-Index,Range-Start,Range-End,Expected-Status,Expected-Bytes}`隐藏handoff交给Nginx；先结构校验完整handoff并条件写业务日志，再由request completion、status、Content-Range和body bytes输出schema v2 `download.chunk_finished`，schema/event type在log format中固定。
- [x] 5.5 在未启用Nginx加速的direct路径由qtserver按相同完成性判定输出`download.chunk_finished`，确保错误响应body不计入actual bytes。
- [x] 5.6 隐藏全部七项handoff headers，确保Nginx只使用对应upstream变量而非客户端headers，删除event/operation/started等无关handoff并更新Nginx轮转配置。
- [x] 5.7 在通过前置校验并实际执行hash读取/计算/比较后输出`download.verify_finished`，区分matched、mismatched和执行失败failed；HASH_PENDING/UNAVAILABLE不产生日志也不刷新deadline，整文件matched先可靠记录再返回成功，并删除独立下载完成确认和report路径。
- [x] 5.8 将small路径改为每个文件`io.Copy`成功、实际字节匹配并显式`tar.Writer.Flush()`成功写完当前entry padding后立即输出一条自包含`download.small_file_sent`；任一步失败不输出该文件业务事件并停止后续文件。
- [x] 5.9 确保small批次按文件边界记录，后续文件失败不撤销此前成功事件，且普通用户与内置`anonymous`用户使用相同small日志语义。
- [x] 5.10 将零字节下载从qtransc本地直建改为`/d/small`，由qtserver完成零长度entry并输出small成功事件。

## 8. 文档与验证验收

- [x] 8.1 维护`docs/server-business-logging-design.md`的最终字段、七类事件、普通状态机、小文件直达流程和ClickHouse/PostgreSQL职责，避免README重复协议正文。
- [x] 8.2 为qtserver和qtransc补充schema/file-key/writer、metadata、事件、状态机、timeout、小文件、迟到修订及数据库集成测试。
- [x] 8.3 使用官方Nginx container执行`nginx -t`，验证可信handoff、内部header隐藏和生成事件满足 schema v2 契约。
- [x] 8.4 使用隔离PostgreSQL、Redis、Nginx和临时目录运行真实上传、普通下载与small下载验收，不复用开发机已有数据。
- [x] 8.5 对qtserver和qtransc执行gofmt、`go test ./...`、`go build ./...`和现有相关跨平台构建。
- [x] 8.6 确认旧试验事件、客户端report和legacy日志代码均已删除，不存在兼容旁路。
- [x] 8.7 再次执行OpenSpec strict validation，并逐项核对本change任务与当前实现证据后再考虑archive。
