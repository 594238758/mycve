## Why

当前上传与下载使用不同的物理目录和文件管理入口，导致同一个 principal 看到的文件空间被割裂，浏览、上传、下载、目录管理和断点续传之间存在重复模型。与此同时，上传临时状态、正式文件 hash 和客户端续传定位的职责边界不清晰，难以明确缓存丢失、进程中断、依赖故障和最终发布时的行为。

本变更将上传和下载收敛为一个用户文件空间，并为 GUI、qtransc 和第三方程序建立一致、可运维、可续传的 Qtserver 文件能力。本 change 是当前项目第一次正式建立 OpenSpec 行为基线，不恢复旧的 OpenSpec 历史文档。

## What Changes

- 使用 `server.user_home_root` 作为所有普通用户和 `anonymous` 的最终文件根目录；上传完成后的文件立即可以 list 和下载。
- 使用可选的 `server.temp_root` 存放上传临时数据；未配置时默认为 `<user_home_root>/.uploadtemp`。
- 新增 `read_enabled`、`write_enabled` 和 `anonymous_enabled`；关闭能力时不注册对应路由。
- PostgreSQL 和 Redis 都成为 Qtserver 启动及运行期必需依赖。启动连接或 schema 校验失败时拒绝启动；运行期连接类故障触发非零 graceful shutdown，不提供降级运行或自动恢复模式。
- **BREAKING**：以 `/qtserver/v1/files/list|mkdir|move|delete|create` 替换旧上传、下载 browse 与文件管理 API，不保留旧入口兼容层，第一版不提供 `copy`。
- **BREAKING**：以 `qtransc list|mkdir|move|delete` 替换 `dlist|ulist|umkdir|umove|udelete`，不保留旧命令别名；`list` 支持文本和 JSON 输出。
- Qtserver list 仅浏览单层目录；目录递归、任务规划、限制和异常汇总由 qtransc 负责。目录任务保留空目录。
- **BREAKING**：以 canonical `/qtserver/v1/uploads` resource API 替换旧 `/u/file/init|chunk|complete|abort`；qtransc、标准 upload 和 upload2 的服务内适配统一使用新 API，不保留旧 Qtserver 上传路由。
- PostgreSQL 只持久化正式文件 hash；上传 session、chunk 进度、chunk hash 和上传锁只在 Redis 中。Redis session 丢失后未完成上传从零开始。
- 每个上传 session 使用 `<temp_root>/<principal_id>/<session_id>` 的单个未预分配缓存文件。固定 100 MiB chunks 可以并行上传，单 chunk 通过 offset 和五秒 checkpoint 续传，并通过独立 finalize 校验。
- complete 不重新扫描整个缓存文件，而是组合 verified chunk hashes 生成 `layered_xxh3_128_v1`；只有 complete 原子发布正式文件。
- 正式 hash 由 PostgreSQL 状态、异步 worker、心跳接管、客户端轮询和 stale-while-revalidate 维护；Redis 只作 cache-aside。
- Qtserver 使用 principal namespace lock 串行同一 principal 的文件管理与发布，并使用 session operation lock 线性化 complete、cancel 和 release。租约是 advisory lease，不提供严格 filesystem fencing。
- qtransc 使用本地 SQLite `upload_files` 表保存未完成文件的 session ID、本地 fingerprint 和可选 hash；下载继续使用现有 `.progress` 文件。
- `--state-db` 是 qtransc 全局参数，必须是绝对路径；Linux 固定默认 `$HOME/.local/state/qtransc/upload.db`，忽略 `XDG_STATE_HOME`。
- complete 或同目标 hash 秒传成功后，qtransc 删除 SQLite 行并 best-effort release。暂停保留状态；显式放弃、本地 fingerprint 变化或 session 被替代时先删除本地行，再 best-effort cancel。
- 新增只供 HTTP 调用方使用的 `/qtserver/v1/files/create` 空文件 API；不增加 qtransc `create` 或 `touch` 命令。普通 upload 和 upload2 支持零字节文件。
- 下载继续使用 `/d/grant`、`/d/small`、`/d/down` 和 `/d/verify`，但对象路径统一为逻辑绝对路径，服务端不再递归展开目录。
- 下载 grant 保留现有 body/query `taskid` 与 HMAC 签名绑定；grant 自验证且不保存 Redis 状态。qtransc 同时把该值写入 `X-Task-ID`；`X-Task-ID` 只用于日志。
- anonymous 读允许无认证请求。anonymous 写要求固定代码常量 token `00000000-0000-4000-8000-000000000000`；该公开常量不是秘密，只有部署同时开启 anonymous 与 write 时才赋予 anonymous 写能力。upload2 始终拒绝 anonymous。
- 新增 `/qtserver/v1/capabilities`，公开应用版本、API 主版本、能力和关键限制；健康运行时已启用能力的 `available=true`。
- 配置、数据和未完成上传不兼容旧部署；采用新机器全新部署和流量切换，不提供迁移工具或原地升级。
- `upload2`、`download2` 等面向旧 GUI 的外部协议不在本 change 中重写，只在内部适配 canonical 能力。

## Capabilities

### New Capabilities

- `user-file-space`: 定义统一文件空间、根目录、principal、anonymous、权限策略、能力开关和依赖生命周期。
- `file-management`: 定义 canonical 文件 API、空文件 API、路径与 symlink 行为，以及 qtransc CLI 和目录规划。
- `resumable-upload`: 定义 canonical 上传 API、Redis-only 临时状态、单缓存文件、chunk 续传、终态操作和原子发布。
- `client-transfer-state`: 定义 qtransc SQLite session 定位、本地 fingerprint/hash 缓存和下载 `.progress` 边界。
- `file-hash-management`: 定义 `layered_xxh3_128_v1`、正式 hash 的 PostgreSQL 状态、失效、worker、轮询和缓存。
- `service-capability-discovery`: 定义能力发现、客户端预检、版本识别、路由与公共 HTTP 错误边界。
- `transfer-task-correlation`: 定义 `X-Task-ID` 日志标签及 download grant taskid 兼容例外。

### Modified Capabilities

当前 `openspec/specs/` 为空，没有需要修改的既有 capability。

## Impact

- 影响 Qtserver 的配置加载、启动顺序、路由注册、鉴权、文件浏览与管理、上传 API、下载 API、hash worker、后台清理、graceful shutdown 和 Nginx 配置生成。
- 影响 qtransc 的 CLI 命令、目录任务规划、退出码、能力预检、网络重试、上传 SQLite 和 chunk 续传流程。
- 新增 PostgreSQL migration 与正式 hash 表；Redis 同时作为上传 session、cache-aside 和分布式 advisory lock 依赖。
- 删除旧文件管理 API、上传 API、旧配置和旧 CLI，属于破坏性变更。
- 需要同步更新 Qtserver、qtransc、部署和运维文档；实现阶段不得顺带重写 upload2/download2 外部协议。

## Non-Goals

- 不实现 `copy`，不在 `qtransc serve` 中代理 Qtserver 文件管理。
- 不提供旧配置、旧 staging、旧 Redis session、旧目录或旧 SQLite schema 的迁移兼容。
- 不提供文件系统、Redis 与 PostgreSQL 的分布式事务，也不提供 publish intent。
- 不把下载 grant 变成 inode/hash/version snapshot，不建立活动下载锁。
- 不防御可信运维在运行期间重定向 symlink 或直接修改正式文件造成的全部 TOCTOU；正式 hash worker 对服务外并发修改不作完整保证。
- 不检测目录递归中的稳定 inode/canonical identity；远端目录 symlink 环依靠服务端错误或规划限制终止。
- 不让 SQLite 替代 Redis session，也不在 SQLite 保存 token、principal ID、expires_at 或 chunk offsets。
- API v1 不支持可变 chunk size，不设置上传 file size、chunk 数或 active session 配额。
- 不提供同 chunk writer fence，也不提供严格 namespace fencing；极端并发和长暂停窗口作为 Known Behavior。
- 不为本地下载增加临时文件校验后 rename；部分文件和 `.progress` 在完成前可见。
- taskid 不是可信审计标识；固定 anonymous token 也不是秘密或用户级授权边界。
- 不校验、清洗或编码身份服务与 fake-token 配置提供的 principal ID；不安全 ID 导致的目录逃逸、碰撞或跨 principal 访问不在隔离保证内。
- 未经后续 OpenSpec 审批，不重写 `upload2`、`download2` 等旧 GUI 外部兼容协议。
