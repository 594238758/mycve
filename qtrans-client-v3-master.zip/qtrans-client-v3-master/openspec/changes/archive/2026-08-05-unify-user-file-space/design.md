## Context

本 change 同时影响 qtransc 和 Qtserver。文件系统是正式内容的事实来源；PostgreSQL 是正式文件 hash 的可靠元数据来源；Redis 是上传 session、chunk 进度、可丢失 hash cache 和多实例协调锁的事实来源；qtransc SQLite 只保存客户端恢复 session 所需的定位信息。

运维可以在 Qtserver 外创建家目录、symlink 和文件。本设计信任身份适配层与运维边界，明确 API 的弱一致性，而不构造跨文件系统、Redis 和 PostgreSQL 的事务。

## Goals / Non-Goals

**Goals:**

- 每个 principal 只有一个可上传、下载和管理的逻辑文件空间。
- qtransc 重启后能从 SQLite 找到 session，并从 Qtserver 已确认 offset 继续。
- 固定 chunks 可并行；单 chunk 断连最多损失最后五秒 checkpoint 之后的确认进度。
- complete 不扫描整文件，并以原子 rename 为正式发布点。
- Qtserver 文件 API 可被 qtransc、GUI 和第三方程序直接使用。
- PostgreSQL/Redis 故障采用简单的 fail-fast 服务生命周期。

**Non-Goals:**

- 不迁移旧配置、数据、session 或 staging。
- 不实现 copy、分布式事务、publish intent、下载 snapshot、活动下载锁或严格 fencing。
- 不抵御全部服务外文件修改与 symlink TOCTOU。
- 不校验或编码 principal ID。
- 不设置上传大小、chunk 数或 session 数配额。
- 不重写 upload2/download2 外部协议。

## Decisions

### 1. 存储根、启动校验与默认权限

- 最终文件映射为 `<user_home_root>/<principal_id>/`。`user_home_root` 必须是运维预先创建的绝对 Clean path、可访问普通目录且自身不是 symlink；无效时启动失败。
- 路径关系使用解析祖先 symlink 后的实际位置比较。允许 `user_home_root` 的祖先包含 symlink。
- 上传临时数据使用绝对 `temp_root`；未配置时为 `<user_home_root>/.uploadtemp`。
- `temp_root` 由 Qtserver 独占，不能是 symlink、普通文件或特殊节点，不能等于或包含 `user_home_root`，也不能位于 `user_home_root` 内；唯一例外是默认 `.uploadtemp`。
- write 关闭时不创建、检查或清理 `temp_root`。write 开启时缺失的 temp_root 以 `0700` 创建；已有目录收紧为 `0700`，失败则启动失败。
- 上传缓存 principal 子目录为 `0700`，缓存文件传输期间为 `0600`。发布前，managed mode 使用精确配置；否则文件使用 `0666 & umask`、目录使用 `0777 & umask`。缓存的 `0600` 不直接成为正式文件权限。
- temp_root 与实际目标必须在支持原子 rename 的同一文件系统。服务不提前扫描全部家目录；complete 遇到 EXDEV 返回 HTTP 500 `CROSS_DEVICE_PUBLISH`，保留 session 和缓存，不复制后删除。

### 2. principal、家目录、anonymous 和鉴权

- `principal_id` 原样采用 access token 解析结果、身份服务结果或 fake-token 映射。Qtserver 不校验格式、路径安全、长度、保留名或字符集合，也不清洗、规范化或编码。身份来源必须保证其可安全用作目录名；否则隔离不受保证。
- 普通家目录可以是有效 symlink，目标可以位于 root 外。API 调用方不能修改家目录链接本身。
- 普通家目录缺失时，根 list 返回空结构且不创建；具体读取返回 404。只有 mkdir、create 和成功进入发布阶段的 complete 可以创建家目录；move/delete 在家目录缺失时直接 404，不产生副作用。
- 坏家目录链接的读行为等价空空间，写请求失败且不修复。
- `anonymous_enabled` 默认 false。启用时，缺失则创建 `<user_home_root>/anonymous`；已有非空真实目录可直接接受；symlink、文件或特殊节点使启动失败。
- anonymous read 允许无 Authorization。anonymous write 必须使用代码内固定公开 token `00000000-0000-4000-8000-000000000000`。该值是 UUID-v4 结构下其余位为零的常量，不是 secret。
- missing Authorization 只在 read 路由映射 anonymous；write 路由没有 token 返回 401。非法 token 永不回退 anonymous。固定 token 在 anonymous 关闭时返回 401；upload2 即使收到该 token也返回 403。
- anonymous token 持有者在 anonymous 与 write 同时开启时拥有与普通 principal 相同的 canonical upload 和文件管理能力，包括 overwrite。部署只需 anonymous 下载时关闭 anonymous 写入口的使用，不把该常量当权限隔离。

### 3. 家目录初始化与 managed 权限

- `user_home_init_dirs` 只用于普通 principal。每项 `name` 必须是唯一一级目录名，拒绝空、`.`、`..`、分隔符、NUL 和无效 UTF-8；uid/gid 同时出现且非负；mode 接受 `700`、`0700`、`0o700`，范围 `0000..0777`。非法配置使启动失败。
- 本次调用新建普通家目录时才执行完整初始化。中途失败时 best-effort 删除本次新建家目录；删除失败返回 `HOME_INITIALIZATION_FAILED`，残留目录交由运维处理，后续不自动补建。
- 已存在家目录不补建 init dirs，不重新 chmod/chown。
- 以规范化逻辑路径第一个 segment 匹配 managed policy。complete、create、mkdir 对新目录和新 inode 应用策略；已存在目录不重新应用；move/delete/list/download 不应用。
- managed 第一级是指向外部目录的有效 symlink 时继续跟随，并对其后新建对象应用策略。anonymous 始终只使用进程 umask。

### 4. 依赖、启动顺序和 graceful shutdown

- PostgreSQL 和 Redis 都是 fatal dependencies。Qtserver 启动必须连接 PostgreSQL、校验 schema version并成功 Redis PING；任一失败拒绝启动。Redis 启动降级和 PostgreSQL 运行期降级均不支持。
- 运行期每五秒健康检查；业务命令先发现 connection refused、断连、timeout 或协议错误时也立即触发 shutdown。锁冲突、CAS miss、key 不存在、唯一约束和查询无结果不是依赖故障。
- fatal dependency 后停止接收新连接，最多给现有请求 30 秒；正常 SIGINT/SIGTERM 退出码 0，fatal dependency 非零。hash workers 停止领取，计算取消并由心跳超时接管。
- 文件系统修改尚未达到成功点时，检测依赖故障的请求返回 500 `INTERNAL_ERROR`。rename/unlink 等正式修改已完成后，不回滚；尽量返回成功，再 shutdown。来不及响应时允许客户端看到断连。
- 身份服务超时、单 principal 目录错误、单次文件 I/O、磁盘满和客户端错误均为请求级问题，不杀进程。
- 健康运行时 capabilities 的 enabled capability 均为 `available=true`；fatal dependency 被检测后不承诺 capabilities 仍可查询，也不自动恢复。

### 5. 配置与命令

- PostgreSQL 最小配置为 `[postgres].dsn`；`[transfer]` 包含 `file_hash_revalidate_seconds=86400`、`hash_worker_count=2`、`hash_queue_size=1000`、`upload_session_retention_seconds=86400` 及下载限制。DSN 只从配置文件读取。
- `qtserver db migrate --config <absolute-file>` 使用同一 DSN，获取 PostgreSQL advisory lock，最多等 30 秒，按版本执行独立事务；不支持 down migration。server 启动只校验，不自动 DDL。schema 更新于程序支持版本时 migrate 与启动均失败。
- 删除旧存储参数和 `--hmac-secret`。`qtserver run` 只允许 `--port`、`--host`、`--loglevel`、`--logpath` 覆盖；不读取环境变量覆盖配置。
- `config validate` 严格拒绝未知和旧字段，执行只读本地路径校验，不连接 PostgreSQL、Redis 或身份服务，不创建目录。
- DSN、Redis password、HMAC secret、fake token keys、Authorization 和 anonymous token 不得进入普通日志或 config dump。固定 anonymous token 虽为公开常量，仍不记录请求 header。

### 6. 路由、请求解析和响应基线

- 只注册精确 `/qtserver/v1/...` 路由；不自动修正尾随 slash，不注册无版本或旧别名。错误 method 返回 405；关闭能力或未知路由返回 404 `ROUTE_NOT_FOUND`。
- 校验顺序为 route → method → capability → auth/anonymous → Content-Type/body → logical path → session/grant/file state。无效 token 优先于 body/path 错误。
- JSON POST 要求 `application/json`（允许 UTF-8 charset），body 最大 2 MiB，拒绝未知字段和尾随第二个 JSON value；重复 key 沿用解析器最后值。complete 的空 body 等价 `{}`。
- 成功 JSON 的 `code` 等于 HTTP status。错误 JSON 包含 status code、稳定 `reason_code`、human-readable `message` 和适用 typed extras；不增加 request ID。PATCH/cancel/release 的成功为 204 空 body。
- `X-Task-ID` 是受信任客户端提供的当前日志标签，暂不新增长度或字符处理；它不影响 canonical upload 业务。download grant 的 body/query taskid 是明确兼容例外。
- HTTP server 使用固定 `ReadHeaderTimeout=10s`、`IdleTimeout=120s`，不设置覆盖整个传输的全局 Read/WriteTimeout。PATCH 和 direct download 连续 60 秒无 bytes progress 时取消。

### 7. 逻辑路径、URL 解码与 exact routing

- 逻辑路径必须是 UTF-8 绝对路径，以 `/` 开头。`/` 是唯一根；mkdir/move/delete/create 禁止操作根。
- 合并重复 `/`，去掉非根尾随 `/`；拒绝 `.`、`..` segment、NUL、反斜杠和无效 UTF-8。规范化后总长最多 1024 bytes、单 segment 最多 255 bytes。不做 Unicode normalization。
- query path 由 HTTP 层 percent-decode 一次；JSON string 不作 URL decode，`%2F` 是字面名称。解码后的 segment 重新执行路径检查。
- `/d/down/docs/a.txt` 在授权与签名中使用规范化 `/docs/a.txt`，避免 URL 双斜杠。

### 8. symlink、特殊节点和弱一致性

- 有效中间 symlink 正常跟随，即使目标在家目录外。download 跟随 final symlink-to-file；显式 list 和 mkdir 跟随 final symlink-to-directory。
- move/delete 对 final symlink 操作链接节点。upload/create 拒绝 final symlink。delete 是唯一允许删除坏链或环链接节点的操作。
- list 子项中的正常 symlink 返回 `type=symlink`、`status=normal`、`target_type=file|directory|special`；坏链/环返回 `status=damaged,target_type=null`；special target 返回 `status=unsupported,target_type=special`。qtransc 文本按 target_type 展示，JSON 保留 symlink。
- FIFO/socket/device 等直接下载、覆盖、move 或作为 delete 顶层目标时返回 422；递归删除普通目录时只 unlink 内部特殊节点和 symlink，不跟随。
- list 不持锁。枚举后消失或变化的子项使用 `type=unknown,status=unavailable,reason_code=ENTRY_CHANGED|ENTRY_UNREADABLE`，整体仍 200。
- qtransc 递归跟随远端正常目录 symlink，不维护 inode/canonical 去重。循环最终由 `SYMLINK_LOOP`、128 深度、1024-byte path 或总条目限制在传输前终止。

### 9. list、目录规划和 CLI

- `GET /files/list?path=/docs` 只枚举一层，不排序、不分页，最多返回文件系统首先枚举的 100000 项。响应为 `code,path,truncated,entries`；entry 使用 name/path/type/status、可选 target_type/special_type/reason_code/size/last_modified。时间为 UTC RFC3339Nano，顺序不保证。
- 请求目标缺失 404；普通文件 422 `NOT_A_DIRECTORY`；special、坏链和环分别 422。请求目录权限或 I/O 错误为 500，不泄露物理路径。
- qtransc 目录规划上限为 100000 普通文件、200000 总条目、128 深度、1024-byte path 和 255-byte segment。任何 list `truncated=true` 使目录任务在传输前失败；直接 `qtransc list` 不显示任何 entry，文本只报错，`--json` 输出 error object，退出非零。
- qtransc 保留空目录：上传先调用 mkdir，下载先创建本地目录。目录上传要求 upload 与 file_management capabilities；目录创建失败时不开始文件 bytes，已创建目录不回滚。
- 本地 upload 不跟随 symlink；显式 symlink/special 规划失败，递归遇到则跳过告警；hard link 按逻辑路径分别上传。
- qtransc 对 remote symlink-to-directory 复制内容，不在本地创建 symlink。多 source 保留 basename；映射到同一本地/远端路径时规划失败，使用本地 OS 的实际大小写语义判断下载冲突。

### 10. 文件管理 API

- wire contract：

```text
GET  /files/list?path=/docs
POST /files/mkdir  {"path":"/docs"}
POST /files/move   {"source":"/a","destination":"/b"}
POST /files/delete {"path":"/docs"}
POST /files/create {"path":"/empty","overwrite":false}
```

- list 200；mkdir 201 新建/200 已存在；move 200；delete 200；create 201 新建/200 幂等。delete 缺失返回 404；所有非 204 操作为 JSON。
- mkdir 是 mkdir-p。final symlink-to-directory 返回 200 且不替换；symlink-to-file 409；坏链/环 422。response 包含 normalized path 与 created。
- move destination 是精确目标，父目录不自动创建。source==destination 或 destination 已存在任意节点返回 409。目录移入自身后代返回 409 `INVALID_MOVE`。EXDEV 返回 HTTP 500 `CROSS_DEVICE_MOVE`，不复制删除。
- move/create/complete 的 no-overwrite 必须使用 Linux `renameat2(RENAME_NOREPLACE)` 或等价原子 primitive；不支持时 500 `ATOMIC_NOREPLACE_UNSUPPORTED`，不退化为 stat+rename。
- delete 边遍历边删除，不预扫描、不回滚、不设 mount boundary。顶层缺失 404；开始后子项并发消失视为已删除。部分失败返回 HTTP 500 `DELETE_PARTIAL`、逻辑 failed_path 和 partial=true。
- create 自动 mkdir-p，用目标父目录中的 `.qtserver-create-<random>.tmp` 原子发布。正常失败 best-effort 删除；崩溃残留不自动扫描，作为普通隐藏文件可 list/move/delete。
- filesystem mutation 的成功点是不可逆 syscall。rename 前 chmod/chown/fsync 失败则不发布；rename 后父目录 fsync 失败记录高等级错误但返回成功，不回滚。move/delete 同理。

### 11. canonical upload wire contract

- API 路由为 `/uploads` resource 及 session/chunk/finalize/complete/cancel/release 子资源。session ID 为 server-generated lowercase UUID v4，客户端视为 opaque；非法或超长 ID 与不存在统一 404。
- init request 为 `object_key,file_size,overwrite?`，file_size 范围 0..int64 max。201 active response 包含 session ID、normalized object key、file size、chunk size/count、algorithms 与 Location。
- overwrite=false 且目标普通文件存在：size 不同返回 200 target_exists/target_size；size 相同且 hash 可用返回 200 target hash/algorithm；hash pending 返回 202 `HASH_PENDING`、Retry-After 5。qtransc hash 不同后重新 init overwrite=true。
- GET active session 返回 unordered/unpaged sparse chunks object，key 是 decimal index；缺失 chunk 等价 partial/0。committed GET 返回原 complete result且不返回 chunks。单 chunk GET 返回 state/stored/chunk_size/hash（适用时）。不设 chunk count 上限，接受超大响应设计缺陷。
- PATCH 要求 `Upload-Offset`、positive Content-Length 和 octet-stream。缺失/分块传输 411，非正长度或非法 index/offset 400，wrong media type 415，body 超 chunk 413，offset ahead 409并同时返回 JSON/header correct offset。成功 204并返回 offset/state headers。complete/verified chunk 不写数据，204返回当前状态。
- finalize body 只含 lowercase 32-hex `chunk_hash`。malformed 为 400 `INVALID_CHUNK_HASH`；incomplete/mismatch/conflict 为 409。mismatch 重置当前 chunk partial/0并返回 offset header；相同 verified hash 幂等 200。
- complete body 可空，effective overwrite 是 init overwrite OR complete overwrite，不能降级。committed retry 忽略新 body并返回原结果。成功固定 200 body；incomplete 409并返回 total/verified counts。
- cancel/release missing（含其他 principal）均 204。cancel committed 为 409 `SESSION_COMMITTED`；release active 为 409 `SESSION_NOT_COMMITTED`；成功 204。

### 12. 上传缓存、chunks 和弱并发

- Redis 是 active/committed session、chunk state、stored offset、chunk hash、TTL 和 locks 的唯一控制事实。二进制只在单个 sparse cache file；init 先 Redis 后文件，文件创建失败删除 session。
- API v1 chunk size 固定 104857600。不同 chunks 可并行；qtransc 单进程不主动并发同 chunk，多进程不协调，SQLite 也不提供 row lease。
- PATCH 每五秒将连续 stored bytes checkpoint并续期；正常结束必须完成最终 checkpoint 后才返回 204。断连不额外 checkpoint，尾部重传覆盖。checkpoint Redis 故障触发 fatal shutdown。
- same-chunk PATCH/finalize 不设 barrier。晚到 PATCH 可与 finalize 竞争，甚至在 verified 后造成缓存字节与 hash 不一致；该风险只影响当前 principal，用户可重新上传，服务不提供 fence。
- chunk 全部 bytes 后为 complete，finalize 读取该区间并转 verified。chunk hash 不写 PostgreSQL、不做 chunk fsync。

### 13. complete、终态锁和 publish crash window

- complete 要求所有 chunks verified，使用 ordered chunk hashes 生成 layered file hash，不重读缓存。
- complete、cancel、release 共享 renewable session operation lock；complete 还获取 principal namespace lock。lease 30 秒、每 10 秒续租；冲突分别返回 409 `SESSION_BUSY`/`NAMESPACE_BUSY` 与 Retry-After 1，qtransc 最多重试 30 秒。
- namespace/session lease 是 advisory，非严格 fencing。不可逆操作前检查 token；尚未修改时丢锁返回 409 `NAMESPACE_LOCK_LOST`，已有部分 mkdir 返回 500 `NAMESPACE_OPERATION_PARTIAL`，delete 返回 `DELETE_PARTIAL`。极端进程暂停窗口仍可能竞争。
- complete 创建家目录/parents、应用权限、fsync cache、原子 rename。rename 是业务成功点。成功后写 committed response并重启 retention；重复 complete/GET返回原结果。
- 不增加 publish intent。rename 后 committed 前崩溃或 Redis fatal 时，后续请求若只看到 session 存在但 cache missing，统一删除 session并返回 404 `SESSION_NOT_FOUND`。内部日志区分 rename crash，不对外返回 `UPLOAD_CACHE_MISSING`。
- complete/create overwrite 发布时必须使旧 hash generation 失效；known hash 与 worker submit 均 CAS，旧 worker不能覆盖新结果。

### 14. TTL、cancel/release 和 orphan

- `upload_session_retention_seconds` 默认 86400、最小 60。PATCH checkpoint、finalize 与 complete 执行期间持续续期；GET 和无数据 stall 不续期。committed 从成功时重新计时。
- pause、Ctrl+C 和临时网络故障不调用 cancel。显式放弃、LOCAL_FILE_CHANGED、session superseded 时删除本地记录后 best-effort cancel；complete 后删除行再 release。
- cancel/release 只操作 session/cache，绝不删除正式文件。cancel 可与 PATCH 重叠，后者在后续 Redis checkpoint 停止，残留由 orphan scanner处理。
- orphan scanner 启动立即执行，此后每 60 秒；30 秒 Redis lock、10 秒续租。递归 lstat temp_root，按 cache basename session ID 查询 Redis；missing 删除 regular/symlink/special 节点且不跟随 symlink，best-effort 删除空目录，不删除 temp_root。单文件 I/O 失败记录并下轮重试；Redis query failure 触发 fatal shutdown。

### 15. layered hash 和正式 fingerprint

- `layered_xxh3_128_v1`：固定 104857600-byte chunks；每 chunk 用 seed 0 XXH3-128；128-bit digest 以 `Uint128.Bytes()` 的大端 16 bytes 表示；按 index 拼接；对拼接结果再做 seed 0 XXH3-128；输出 lowercase 32-hex。零 chunk 对空 byte string执行外层 hash。
- 规格必须包含空文件、单 chunk 与跨 chunk boundary 的固定 vectors，供 Go/其他语言实现互操作。
- 正式 fingerprint 只使用 `ctime_ns,mtime_ns,file_size`，不使用 inode/device。运维原地修改并恢复这些属性可能导致 stale hash，作为可信运维边界。
- hash identity 为 principal、normalized object key、algorithm、version。不同逻辑路径即使指向同 inode也独立。

### 16. PostgreSQL hash worker 和 Redis cache

- PostgreSQL `file_hashes` 保存 hash/fingerprint、idle/pending/calculating/failed、calculation_id/generation、started/heartbeat、error/retry/next_retry_at。所有时间使用数据库 `now()`/timestamptz。
- 请求发现 fingerprint 变化或 missing 时使旧 generation 失效并删除 PG/Redis cache。service-controlled create/complete/move/delete 必须主动失效。move 不迁移旧 hash，新路径首次计算。
- fresh hash 直接返回；fingerprint 相同但超过 revalidate seconds 时返回 stale 值并后台刷新。没有 hash 返回 202 + Retry-After 5；普通 download 不等待。
- worker 每五秒从 PostgreSQL 领取 pending；内存 queue 不是可靠事实。启动继续 pending；calculating 30 秒无 heartbeat 可 CAS 接管；failed 只在新访问且到 next_retry_at 后置 pending。旧 hash存在时计算失败继续返回旧值；无旧值返回 503 `HASH_UNAVAILABLE`。
- 默认 worker_count 2、queue 1000；必需 pending保留在 PG，refresh queue 满可跳过 notification。
- Redis hash cache TTL 等于 `file_hash_revalidate_seconds`，entry 包含 hash/algorithm/version/fingerprint；cache hit仍 stat compare。TTL 只触发回查 PG，不删除 PG记录。
- 不按访问年龄 GC仍可能有效的 PG hash。
- 对服务外并发修改正式文件不提供 worker 前后稳定性保证；服务信任运维很少在 hash scan 中修改文件。

### 17. qtransc SQLite 与源文件一致性

- 全局 `--state-db` 适用于 upload/upload2/serve；显式值必须 absolute。Linux固定默认 `$HOME/.local/state/qtransc/upload.db`，不读取 XDG；list/download 接受 flag但不打开 DB。
- DB parent 为 `0700`、DB/WAL/SHM 为 `0600`，final DB path不能是 symlink且 Unix owner必须是当前 euid。使用 `user_version=1`，WAL、synchronous FULL、busy_timeout 5000、foreign_keys ON、wal_autocheckpoint 1000。损坏、不兼容或更新版本不自动删除。
- `upload_files` 使用 INTEGER PRIMARY KEY（无 AUTOINCREMENT）和 unique `(local_absolute_path,server,remote_absolute_path)`。server 使用现有 normalized origin；remote 是 normalized logical absolute；local 是 filepath.Abs+Clean且不 EvalSymlinks。多账号同 key和多进程同文件竞争是接受的设计缺陷。
- 行保存 session、size/mtime/ctime/platform file ID、可选 hash/algorithm、updated_at；不保存 principal/token/expires/chunks。Linux file ID 是 dev+ino，Windows是 volume serial+file index，不可用时为空。
- init 后必须先事务性持久化 session row，再 PATCH；持久化失败 best-effort cancel并返回 LOCAL_STATE_ERROR。init与row commit之间崩溃造成 orphan可接受。
- 每文件只打开一个 source handle，chunks使用 ReadAt；fingerprint从 handle获取。路径 rename/替换但原 handle不变时继续旧 inode；原 inode变化触发 LOCAL_FILE_CHANGED。
- fingerprint变化先删除 SQLite 行，随后停止 workers并 best-effort cancel；前台退出，serve task进入 stopped。下次不得恢复旧 session。
- SESSION_NOT_FOUND 保留 fingerprint/hash并 init新 session，row commit替换 session ID后才PATCH。complete/秒传成功删除行；删除失败仍完成任务但报告 `LOCAL_STATE_CLEANUP_FAILED`，不 release。下次 committed GET后重试清理/release。
- SQLite不保存完整 serve task。serve重启不自动重建任务；调用方重新创建相同业务键后恢复 session。

### 18. 下载 grant、small、down 与 verify

- 下载对象字段统一为逻辑绝对 `object_key`。grant/small只接受显式普通文件，目录为 400 INVALID_REQUEST。grant一次最多1000，先全量验证，normalized duplicates保留第一次，response按请求顺序返回 object_key/size/grant。
- grant保留现有 taskid HMAC绑定，默认 TTL 900、最小60，不存Redis、不续期/吊销。qtransc 410后用相同taskid刷新并按 `.progress` Range继续。
- `/d/down` 只注册 GET，保证 full与single range；416处理不可满足范围，多Range不保证。成功 headers为 octet-stream、logical basename disposition、private no-store、accept-ranges。data开始后读取错误只断连接。
- `/d/small` 默认100 files、4 MiB each、128 MiB total。headers前打开所有文件并同步计算 layered hash，manifest/session使用v1。stream开始前错误JSON失败；开始后错误断连接，qtransc丢弃该batch临时结果并把文件改走普通链路。
- `/d/verify` file使用PG正式hash；pending 202。可用时200返回 match/calculated_hash/hash_algorithm，mismatch也200。chunk verify同步读最多一个100 MiB区间，不写PG。
- mismatch时qtransc删除`.progress`并从零自动重下一次；再次 mismatch前台失败、serve stopped。其他成功文件不重下；small中只重下失败文件。
- 本地下载直接写最终路径，完成前部分文件可见。pause保留文件与 `.progress`；task delete删除 `.progress`和qtrans owned temp但不删除用户文件。

### 19. Nginx direct parity

- `nginx_acc`为空 direct；非空必须是无scheme/host/query/fragment、以 `/` 开头且非根的安全URI prefix，拒绝percent、反斜杠、NUL、dot segments，保存时去尾slash。
- internal URI按principal/object每segment UTF-8 percent encode，Nginx decode一次，alias指向user_home_root。read关闭不生成internal location。
- 外部symlink目标必须对Nginx用户可见/可读。Qtserver不遍历验证，不在Nginx失败时回退direct。X-Accel后目标变化可返回Nginx原生403/404/5xx，不保证JSON。
- Qtserver和Nginx access log记录当前 X-Task-ID；Nginx不以其授权。

### 20. qtransc任务、重试和退出码

- upload destination始终是目录；缺失时mkdir-p。单文件映射destination/basename，目录映射destination/source-basename，多source保留basename；第一版上传同时改名需后续move。
- 当前task递归远端正常dir symlink；本地source symlink不跟随。规划保留空目录并在传输前完成limits检查。
- serve公开状态保持 pending/running/completed/stopped/failed，不新增paused/partial。可恢复错误与主动pause为stopped；规划/配置/auth等不可恢复错误为failed；单文件失败继续健康文件后task failed；只有warnings则completed。
- serve DELETE task是显式放弃：先停worker、删除SQLite rows、best-effort cancel active sessions；不删除正式remote或本地用户文件。
- transport及408/429/500/502/503/504按1s指数到5s、20% jitter重试；连续30秒无有效response/progress后停止。hash 202轮询例外。401只refresh一次；move/delete不因不确定结果自动重试。
- PATCH不确定先GET offset，finalize只以相同hash重试，complete/cancel/release幂等重试。Retry-After支持delta/date。
- CLI退出码：0成功含warnings，1 remote/auth/network/transfer，2 CLI/local config/planning/state DB，130 SIGINT；serve正常signal 0、fatal 1。stdout用于结果，stderr用于progress/warnings/errors；list --json失败输出单一JSON error到stdout。

### 21. capabilities、taskid 与 compatibility

- capabilities无认证、健康运行时始终注册；返回 qtserver_version、api_version、capabilities(enabled/available)与limits/algorithms。qtransc upload/download/list/mkdir/move/delete在创建task或发操作前预检，可缓存5秒；只按api主版本和capability，不按应用版本。
- limits至少包含 list 100000、path 1024、segment255、grant1000、chunk104857600、small defaults；algorithms返回 xxh3_128 与 layered_xxh3_128_v1。anonymous报告read/write可用性。
- `/taskid`无认证、始终注册、生成UUIDv4且不创建资源。qtransc为所有upload/download请求携带X-Task-ID。
- X-Task-ID只影响日志；download grant request/body taskid、grant query和HMAC保持现有绑定。grant自验证且不保存Redis状态。header缺失或不同不影响grant；日志优先记录header，缺失回退grant taskid。
- upload2/download2外部GUI协议不改；内部路径、hash algorithm与canonical API适配本change。

## Risks / Trade-offs

- raw principal ID 可造成目录逃逸和空间碰撞；身份来源被视为可信。
- temp_root/外部家目录跨文件系统只能在complete时报错。
- list不分页且10万截断，超大目录无法由qtransc启动任务。
- namespace lock是advisory lease，极端进程暂停存在竞态；同principal无关写被串行。
- Redis丢失使active session不可恢复；无上传配额可能耗尽Redis或磁盘。
- sparse cache不预留空间，PATCH中途可能507。
- same-chunk writer/finalize无barrier，服务不保证恶意或错误客户端下的verified bytes稳定。
- rename后committed前崩溃只通过SESSION_NOT_FOUND和重新init收敛；已发布文件可能已存在。
- 正式fingerprint只有ctime/mtime/size，运维可构造stale hash。
- 下载grant与文件修改弱一致；Nginx/direct错误形态并不完全相同。
- SQLite不协调多进程同一业务key；下载最终路径在校验前可见。
- 固定anonymous token公开，anonymous write一旦开启就是共享完全写权限。

## Migration Plan

1. 新机器准备 user_home_root、temp_root、PostgreSQL、Redis和共享存储；确认Linux/filesystem支持atomic rename与RENAME_NOREPLACE。
2. 运行 `qtserver db migrate --config ...`，部署同步版本 Qtserver/qtransc，生成新Nginx配置。
3. 在独立流量验证 capabilities、anonymous read/write边界、canonical upload/download/list/file management和崩溃恢复。
4. 停止旧服务写入并切流；不合并旧目录、staging、Redis session或SQLite state。
5. 回滚时切回旧服务；两套数据和状态不双向合并。

## Open Questions

当前没有阻塞本 change 实现的设计问题。实现若需要改变外部协议、数据模型、错误语义或弱一致性边界，必须先更新本 change。
