## Purpose

定义正式文件 hash 的跨语言算法、PostgreSQL 状态机、Redis cache、文件 fingerprint、后台计算与失效契约。

## ADDED Requirements

### Requirement: layered_xxh3_128_v1 算法必须完全确定

`layered_xxh3_128_v1` SHALL 将文件按 104857600 bytes 分 chunk；每个 chunk SHALL 使用 seed 0 的 XXH3-128；128-bit digest SHALL 使用 `github.com/zeebo/xxh3.Uint128.Bytes()` 等价的大端 16-byte 表示；服务 SHALL 按 chunk index 拼接 digest，对结果再执行 seed 0 XXH3-128，并输出 32 个 lowercase hex 字符。零 chunk 文件 SHALL 对空 byte string 执行外层 hash。

#### Scenario: 空文件固定向量

- **WHEN** 输入文件长度为 0
- **THEN** `layered_xxh3_128_v1` SHALL 等于 `99aa06d3014798d86001c324468d497f`

#### Scenario: 单 chunk 固定向量

- **WHEN** 文件内容是 UTF-8 bytes `abc`
- **THEN** `layered_xxh3_128_v1` SHALL 等于 `f758394eebabb2bb51ee911f78f31836`

#### Scenario: 跨 chunk 边界固定向量

- **WHEN** 文件由 104857600 个 `0x00` bytes 后接一个 `0x01` byte 构成
- **THEN** `layered_xxh3_128_v1` SHALL 等于 `8bfc757b9f970427d349bb75e516af66`

### Requirement: chunk hash 使用 xxh3_128

上传 chunk finalize 和下载 chunk verify SHALL 使用 seed 0 XXH3-128，输出同样的大端 16-byte digest 的 lowercase 32-hex 字符串，并以 `xxh3_128` 标识算法。

#### Scenario: finalize 验证 chunk

- **WHEN** 客户端提交一个完整 chunk 的 `xxh3_128`
- **THEN** Qtserver SHALL 用相同 byte representation 计算和比较

### Requirement: 正式 hash 按逻辑对象和算法版本标识

PostgreSQL hash identity SHALL 至少包含 principal、normalized object key、algorithm 和 version。不同逻辑路径 SHALL 有独立记录，即使它们当时指向同一个 inode。

#### Scenario: 同一 inode 有两个逻辑路径

- **WHEN** 两个 object key 通过 hard link 或 symlink 最终读取同一 inode
- **THEN** 服务 SHALL 独立缓存、失效和返回各自路径的正式 hash

#### Scenario: 算法升级

- **WHEN** 同一逻辑对象请求不同 algorithm/version
- **THEN** PostgreSQL SHALL 保存互不覆盖的记录

### Requirement: 正式 fingerprint 只使用 ctime mtime 和 size

Qtserver SHALL 以 `ctime_ns,mtime_ns,file_size` 判断正式文件事实是否变化，SHALL NOT 使用 inode 或 device ID。对服务外修改后同时恢复这三个属性导致 stale hash 的情况，SHALL 归入受信任运维边界。

#### Scenario: fingerprint 发生变化

- **WHEN** 当前 stat 的 ctime、mtime 或 size 与 hash 记录不同
- **THEN** 旧 hash SHALL 立即失效且不得作为 stale 值返回

#### Scenario: 正式文件已不存在

- **WHEN** hash lookup发现对应logical object已不存在
- **THEN** 服务 SHALL 使PostgreSQL generation和Redis cache失效
- **AND** SHALL 按对象不存在返回而不得返回旧hash

#### Scenario: 运维恢复全部 fingerprint 字段

- **WHEN** 运维原地改变 bytes 后恢复 ctime、mtime 和 size 到记录值
- **THEN** 服务 MAY 继续返回旧 hash
- **AND** 本 change SHALL NOT 增加额外内容探测

### Requirement: PostgreSQL 是正式 hash 可靠状态源

`file_hashes` SHALL 保存 hash/fingerprint 以及 `idle|pending|calculating|failed` 状态、calculation_id/generation、started/heartbeat、error/retry 和 next_retry_at。时间 SHALL 使用 PostgreSQL `now()` 和 `timestamptz`。Redis SHALL 只作为可丢失 cache，内存 queue SHALL 只作为 notification。

#### Scenario: Qtserver 重启时存在 pending

- **WHEN** 服务启动后 PostgreSQL 中仍有 pending 记录
- **THEN** workers SHALL 继续从 PostgreSQL 领取这些记录
- **AND** 不得依赖重启前的内存 queue

#### Scenario: Redis hash cache 丢失

- **WHEN** Redis cache miss 但 PostgreSQL 存在 fresh hash
- **THEN** 服务 SHALL 从 PostgreSQL 返回 hash 并可重建 Redis cache

### Requirement: PostgreSQL schema 必须由显式 migration 管理

Qtserver 启动 SHALL 校验 hash schema version但 SHALL NOT 自动建表或迁移。`qtserver db migrate` SHALL 按 service capability spec 定义的 advisory lock 和 forward-only transaction 规则维护该 schema。

#### Scenario: hash schema 缺失

- **WHEN** PostgreSQL 可连接但缺失程序要求的 schema
- **THEN** Qtserver SHALL 拒绝启动并要求显式 migration

### Requirement: complete 从 verified chunk hashes 生成正式 hash

complete SHALL 按 chunk index 组合所有已验证的 chunk digest，生成 `layered_xxh3_128_v1`，不得为此重新扫描完整 cache file。零字节 session SHALL 使用固定空文件向量。

#### Scenario: 大文件完成上传

- **WHEN** 所有 chunk 均为 verified
- **THEN** complete SHALL 只读取 Redis 中有序 chunk hashes 生成正式 file hash

#### Scenario: 零字节上传

- **WHEN** session 的 chunk_count 为 0
- **THEN** complete SHALL 发布空文件并返回 `99aa06d3014798d86001c324468d497f`

### Requirement: create 和 complete 的已知 hash 使用 generation CAS

create、complete 以及任何 overwrite 发布 SHALL 在同一业务流程中使旧 hash generation 失效，并以 CAS 写入新 inode 的已知 hash。旧 worker 持有旧文件描述符时，其延迟提交 SHALL NOT 覆盖新发布结果。

#### Scenario: overwrite 与旧 worker 竞争

- **WHEN** worker 正在计算旧正式文件而 complete overwrite 发布新文件
- **THEN** overwrite SHALL bump generation
- **AND** 旧 worker 的 submit SHALL 因 generation 不匹配被丢弃

### Requirement: 文件管理 mutation 主动失效 hash

create、complete、move 和 delete SHALL 对受影响逻辑路径主动失效 PostgreSQL generation 和 Redis cache。move SHALL NOT 把 source hash 记录迁移到 destination；destination 第一次需要 hash 时 SHALL 重新计算。

#### Scenario: move 文件

- **WHEN** `/a` 被移动为 `/b`
- **THEN** `/a` 的 hash SHALL 失效
- **AND** `/b` SHALL NOT 直接继承 `/a` 的记录

#### Scenario: 删除文件

- **WHEN** 正式文件被删除
- **THEN** 对应 PostgreSQL 和 Redis hash 状态 SHALL 失效

### Requirement: fresh 和 stale hash 使用 stale-while-revalidate

fingerprint 匹配且 hash 年龄不超过 `file_hash_revalidate_seconds` 时 SHALL 直接返回 fresh hash。超过该时长时 SHALL 立即返回现有 hash并 best-effort 安排后台刷新；普通下载 SHALL NOT 等待刷新。

#### Scenario: hash 已到 revalidate 时间

- **WHEN** 请求命中 fingerprint 相同的过期 hash
- **THEN** 服务 SHALL 返回旧值
- **AND** SHALL 将记录置为或通知 pending refresh

#### Scenario: refresh queue 已满

- **WHEN** stale hash 已可返回但内存 notification queue 已满
- **THEN** 请求 SHALL 仍成功
- **AND** worker SHALL 通过 PostgreSQL polling 最终发现 pending

### Requirement: 首次计算使用 202 轮询

fingerprint 当前但没有可用 hash 时，请求 SHALL 建立或保留 PostgreSQL pending 状态，并返回 HTTP 202 `HASH_PENDING` 和 `Retry-After: 5`；SHALL NOT 在长 HTTP 请求内同步扫描完整正式文件。普通 download 不要求 hash 时 SHALL 正常传输。

#### Scenario: init 检查同大小正式目标

- **WHEN** overwrite=false、目标 size 相同但正式 hash 尚不可用
- **THEN** init SHALL 返回 202 `HASH_PENDING` 与 Retry-After 5

#### Scenario: 普通文件正在计算 hash

- **WHEN** 客户端只请求普通下载而 hash 状态是 pending
- **THEN** 下载 SHALL 不等待 hash worker

### Requirement: workers 通过数据库 polling 和 heartbeat 协调

workers SHALL 每五秒从 PostgreSQL CAS 领取 pending 记录。calculating worker SHALL 每五秒更新 heartbeat；超过 30 秒无 heartbeat 的记录 MAY 由另一 worker CAS 接管。默认 `hash_worker_count=2`、`hash_queue_size=1000`，两者 SHALL 大于 0。`file_hash_revalidate_seconds` SHALL 默认86400且必须大于0。

#### Scenario: worker 进程退出

- **WHEN** calculating 记录超过 30 秒未更新 heartbeat
- **THEN** 另一健康实例 SHALL 能以 CAS 获取新 calculation_id 并重新计算

#### Scenario: 必需计算 notification queue 已满

- **WHEN** 无 hash 请求创建 pending 但内存 queue 已满
- **THEN** pending SHALL 保留在 PostgreSQL
- **AND** 请求 SHALL 继续返回 202 而不是丢失工作

### Requirement: failed 状态由后续访问触发重试

worker 失败 SHALL 保存 failed、error、retry_count 和 next_retry_at。达到 next_retry_at 前，存在旧 hash 时 SHALL 返回旧值；没有旧 hash时 SHALL 返回 HTTP 503 `HASH_UNAVAILABLE`。达到时间后的首次访问 SHALL CAS 置为 pending并返回旧值或 202。

#### Scenario: refresh 失败但旧值存在

- **WHEN** failed 记录仍保存 fingerprint 匹配的旧 hash
- **THEN** 请求 SHALL 返回旧 hash

#### Scenario: 首次计算失败

- **WHEN** failed 记录没有可用旧 hash且尚未到重试时间
- **THEN** 请求 SHALL 返回 503 `HASH_UNAVAILABLE`

#### Scenario: retry 时间已到

- **WHEN** 新访问发生在 next_retry_at 之后
- **THEN** 服务 SHALL best-effort 将记录置为 pending
- **AND** 没有旧 hash 的请求 SHALL 返回 202

### Requirement: 服务外并发修改不提供额外稳定性保证

本 change SHALL 信任运维很少在 worker 扫描中修改正式目录。worker MAY 对一次打开的文件完成计算并用 generation CAS 提交，但 SHALL NOT 为服务外并发原地写增加计算前后 fingerprint 重试、全文件锁或 `FILE_CHANGED_DURING_HASH` 协议。

#### Scenario: 运维在 hash scan 中修改文件

- **WHEN** 服务外程序在 worker 读取期间修改同一正式 inode
- **THEN** 结果 MAY 反映弱一致性读取
- **AND** Qtserver SHALL NOT 因此定义新的客户端错误或自动暂停 qtransc

### Requirement: Redis hash cache 仍须核对 fingerprint

Redis hash cache TTL SHALL 等于 `file_hash_revalidate_seconds`，entry SHALL 包含 hash、algorithm、version 和 fingerprint。cache hit 时 Qtserver SHALL 重新 stat 并比较 fingerprint；TTL 过期只触发回查 PostgreSQL，不删除 PostgreSQL 记录。

#### Scenario: cache entry 对应旧 fingerprint

- **WHEN** Redis 命中但当前 ctime、mtime 或 size 不同
- **THEN** 服务 SHALL 丢弃 cache hit并失效旧 generation

### Requirement: 正式 hash 不按访问年龄主动清理

服务 SHALL NOT 仅因对象长期未访问而 GC PostgreSQL hash。只有文件事实变化、业务 mutation 或明确数据维护操作可以使其失效。

#### Scenario: 文件一年未访问

- **WHEN** fingerprint 仍匹配且记录存在
- **THEN** PostgreSQL hash SHALL 继续可用于 stale-while-revalidate

### Requirement: PostgreSQL 故障不使用同步 fallback

PostgreSQL 是 fatal dependency。运行期连接级故障 SHALL 触发 Qtserver graceful shutdown；服务 SHALL NOT 改为请求内同步扫描、只关闭 hash capability或继续普通文件接口。

#### Scenario: verify 时 PostgreSQL 断开

- **WHEN** file verify 查询 PostgreSQL 时发生连接级故障
- **THEN** 请求 SHALL 返回 500 `INTERNAL_ERROR`（若仍可响应）
- **AND** Qtserver SHALL 触发 graceful shutdown
