## Purpose

定义 qtransc 使用 SQLite 恢复 canonical upload 的最小本地状态、源文件一致性、多进程缺陷边界和清理语义。

## ADDED Requirements

### Requirement: qtransc 只用 SQLite 持久化未完成上传

qtransc SHALL 使用 SQLite `upload_files` 保存 canonical upload 与 upload2 的未完成文件 session。下载、完整 serve task、task 状态、服务端 chunk map、token 和 principal SHALL NOT 写入该数据库。

#### Scenario: qtransc 进程重新启动

- **WHEN** 用户用相同业务键重新执行未完成上传
- **THEN** qtransc SHALL 从 upload_files 定位 session
- **AND** SHALL 从 Qtserver GET 返回的服务端进度继续

#### Scenario: serve 重新启动

- **WHEN** qtransc serve 进程重启
- **THEN** 它 SHALL NOT 自动重建旧 task
- **AND** 调用方重新创建相同业务键后 MAY 恢复 session

#### Scenario: 执行下载命令

- **WHEN** list 或 download 接受全局 state-db flag
- **THEN** 命令 SHALL NOT 打开或修改 SQLite

### Requirement: state_db 使用固定默认位置或显式绝对路径

qtransc SHALL 新增全局 `--state-db`，供 upload、upload2 和 serve 使用。显式值 SHALL 是绝对路径。Linux 默认 SHALL 固定为 `$HOME/.local/state/qtransc/upload.db`，并 SHALL 忽略 `XDG_STATE_HOME`。本 change SHALL NOT 增加 serve 配置字段或环境变量优先级。

#### Scenario: 未提供参数

- **WHEN** Linux 用户运行 upload 且未提供 `--state-db`
- **THEN** qtransc SHALL 使用 `$HOME/.local/state/qtransc/upload.db`

#### Scenario: 提供绝对路径

- **WHEN** 用户提供 `--state-db /srv/qtrans/state.db`
- **THEN** upload、upload2 或 serve SHALL 使用该文件

#### Scenario: 提供相对路径

- **WHEN** 用户提供相对 state-db
- **THEN** qtransc SHALL 以 CLI/local config 错误拒绝启动

### Requirement: SQLite 文件必须具有本地安全属性

qtransc SHALL 创建 DB parent 为 `0700`，DB、WAL 和 SHM 为 `0600`；final DB path SHALL NOT 是 symlink。Unix 上已有文件 owner SHALL 是当前 euid。SQLite SHALL 使用 `user_version=1`、WAL、`synchronous=FULL`、`busy_timeout=5000`、`foreign_keys=ON` 和 `wal_autocheckpoint=1000`。

#### Scenario: 数据库路径是 symlink

- **WHEN** final state-db 节点是 symlink
- **THEN** qtransc SHALL 拒绝打开并报告本地状态错误

#### Scenario: 数据库被其他 Unix 用户拥有

- **WHEN** 已有数据库 owner 不是当前 euid
- **THEN** qtransc SHALL 拒绝使用它

#### Scenario: 短暂写锁竞争

- **WHEN** 另一个 qtransc 短暂持有 SQLite 写锁
- **THEN** 当前进程 SHALL 等待最多 busy_timeout

### Requirement: 不自动删除损坏或不兼容数据库

qtransc SHALL 在 SQLite 损坏、schema 不兼容或 `user_version` 高于 1 时停止并报告错误，SHALL NOT 自动删除、重建或降级数据库。

#### Scenario: SQLite 损坏

- **WHEN** integrity/open 检测到数据库损坏
- **THEN** qtransc SHALL 失败并保留原文件供用户诊断

#### Scenario: 数据库来自未来版本

- **WHEN** user_version 大于当前程序支持值
- **THEN** qtransc SHALL 拒绝运行且 SHALL NOT 修改数据库

### Requirement: upload_files 使用整数主键和业务唯一键

`upload_files` SHALL 使用 `INTEGER PRIMARY KEY` 且 SHALL NOT 使用 AUTOINCREMENT。唯一键 SHALL 是 `(local_absolute_path,server,remote_absolute_path)`；local path SHALL 使用 `filepath.Abs` 与 `Clean` 且不 EvalSymlinks，server SHALL 使用现有 normalized origin，remote SHALL 使用规范化逻辑绝对路径。

#### Scenario: 同一本地文件上传到两个 remote

- **WHEN** local 与 server 相同但 remote 不同
- **THEN** SHALL 存为两行独立 session

#### Scenario: 相同业务键重复 init

- **WHEN** qtransc 需要用新 session 替换旧 session
- **THEN** SHALL 在同一业务键行内事务性替换 session 数据

### Requirement: state_db 不区分 principal 也不提供业务 lease

本 change SHALL 接受多个 qtransc 进程共享 SQLite，但 SHALL NOT 为行增加 owner/lease，也 SHALL NOT 把 principal 放入 unique key。同一业务键被多个进程或账号同时使用可能竞争、覆盖 session ID 或并发发送同一 chunk，属于已知客户端设计缺陷。

#### Scenario: 两个进程上传同一业务键

- **WHEN** 两个 qtransc 同时恢复同一行
- **THEN** SQLite busy timeout MAY 保护单次事务
- **AND** qtransc SHALL NOT 承诺只有一个进程执行该上传

#### Scenario: 两个账号共享 state_db 和业务键

- **WHEN** 两个 principal 使用相同 local/server/remote key
- **THEN** 其记录 MAY 冲突
- **AND** 用户 SHALL 通过使用不同 state-db 自行隔离

### Requirement: upload_files 只保存恢复定位字段

每行 SHALL 保存 session ID、normalized business key、size、mtime、ctime、可用时的平台 file ID、可选完整 hash/algorithm 和 updated_at。行 SHALL NOT 保存 session expires、Authorization/token、principal、完整 chunk 状态或 task。

#### Scenario: init 尚未计算完整本地 hash

- **WHEN** qtransc 已取得 session 但完整 file hash 尚未完成
- **THEN** 行 SHALL 允许 hash 字段为空

#### Scenario: 本地行很旧

- **WHEN** updated_at 很久以前但服务端 session 仍存在
- **THEN** qtransc SHALL 尝试 GET session
- **AND** SHALL NOT 仅凭本地时间判定过期

### Requirement: init 后必须先提交本地 row 再传 bytes

qtransc SHALL 在 init 成功后事务性写入 upload_files，只有事务 commit 成功后才能发送第一个 PATCH。写入失败 SHALL best-effort cancel 新 session 并返回 `LOCAL_STATE_ERROR`。init 成功到 row commit 之间的进程崩溃 MAY 留下服务端 orphan。

#### Scenario: SQLite 写入失败

- **WHEN** init 已返回 session 但本地事务不能 commit
- **THEN** qtransc SHALL NOT 发送文件 bytes
- **AND** SHALL best-effort cancel session

#### Scenario: 进程在 commit 前崩溃

- **WHEN** 服务端 session 已创建而本地行尚未提交
- **THEN** 客户端 SHALL NOT 假定能恢复该 session
- **AND** 服务端 TTL/orphan scanner SHALL 最终清理它

### Requirement: 服务端进度始终覆盖 SQLite 推测

SQLite SHALL 只定位 session。qtransc 恢复时 SHALL 以 GET session/chunk 返回的 stored offset、state 和 committed result 为事实，SHALL NOT 保存或信任本地 chunk map。

#### Scenario: 服务端未 checkpoint 最后几秒

- **WHEN** 本地曾发送的 bytes 超过服务端 GET stored offset
- **THEN** qtransc SHALL 从服务端 offset 覆盖重传

#### Scenario: 服务端已经 committed

- **WHEN** 本地仍有行但 GET session 返回 committed result
- **THEN** qtransc SHALL 将上传视为成功并只执行本地清理/release

### Requirement: 每个文件任务使用单一 source handle

qtransc SHALL 为一个上传文件只打开一次 source handle，并由并行 chunks 使用 `ReadAt` 读取。fingerprint SHALL 从该 handle 获取。Linux file ID SHALL 使用 dev+ino；Windows SHALL 在可用时使用 volume serial+file index，不可用时可为空。

#### Scenario: 路径被替换但旧 handle 仍有效

- **WHEN** 上传开始后路径名被 rename/replaced而打开的 inode 未变化
- **THEN** workers SHALL 继续读取原 handle

#### Scenario: 已打开 inode 内容发生变化

- **WHEN** size、mtime、ctime 或可用的平台 file ID 与任务 fingerprint 不同
- **THEN** qtransc SHALL 触发 `LOCAL_FILE_CHANGED`

### Requirement: 本地 fingerprint 变化先删除 row 再停止上传

检测到本地源 fingerprint 变化后，qtransc SHALL 先删除对应 SQLite 行，再停止 workers并 best-effort cancel旧 session。无论 cancel 是否成功，下次执行 SHALL NOT 恢复旧 session。前台命令 SHALL 非零退出；serve task SHALL 进入 `stopped` 并提示传输期间不可修改本地文件。

#### Scenario: 运行中检测到本地变化

- **WHEN** 任一 worker 或 complete 前检查发现 fingerprint 变化
- **THEN** SQLite row SHALL 在 cancel 之前删除
- **AND** 前台 SHALL 退出或 serve task SHALL stopped

#### Scenario: cancel 请求失败

- **WHEN** 删除 row 后无法连接 Qtserver cancel
- **THEN** qtransc SHALL 继续新的开始流程而 SHALL NOT 恢复旧 session

### Requirement: SESSION_NOT_FOUND 创建新 session 并原子替换 row

服务端返回 `SESSION_NOT_FOUND` 时，qtransc SHALL 保留仍匹配的 fingerprint 和可选本地 hash，重新 init，并在事务 commit 新 session ID 后才发送 PATCH。

#### Scenario: 服务端 TTL 已删除 session

- **WHEN** SQLite 行仍存在但 GET 返回 404 `SESSION_NOT_FOUND`
- **THEN** qtransc SHALL init 新 session
- **AND** 新 row commit 之前 SHALL NOT 开始上传 bytes

### Requirement: pause 与显式放弃必须区分

Ctrl+C、GUI pause 和暂时网络故障 SHALL 保留 active session 与 SQLite 行且不调用 cancel。用户显式放弃、LOCAL_FILE_CHANGED 或 session 被新 session 取代时 SHALL 删除行后 best-effort cancel。

#### Scenario: 用户按 Ctrl+C

- **WHEN** 前台上传收到 SIGINT
- **THEN** 命令 SHALL 以 130 退出
- **AND** SQLite 行和服务端 active session SHALL 保留

#### Scenario: serve DELETE task

- **WHEN** 调用方删除活动 task
- **THEN** qtransc SHALL 停止 workers、删除相关 SQLite rows并 best-effort cancel active sessions
- **AND** SHALL NOT 删除 remote 正式文件或本地用户文件

### Requirement: 成功后清理 row 再 release

complete 或服务端判定同目标内容相同后，qtransc SHALL 删除 upload_files 行，再 best-effort release committed session。删除失败 SHALL 不改变业务已完成事实，但 task SHALL 报告 `LOCAL_STATE_CLEANUP_FAILED` 且本次不 release。

#### Scenario: complete 后 SQLite 删除成功

- **WHEN** complete 返回 committed success且 row 删除成功
- **THEN** qtransc SHALL best-effort 调用 release

#### Scenario: complete 后 SQLite 删除失败

- **WHEN** 正式文件已成功但本地 row 无法删除
- **THEN** task SHALL 完成文件传输但报告 `LOCAL_STATE_CLEANUP_FAILED`
- **AND** 下次 GET committed SHALL 重试清理和 release

### Requirement: SQLite 丢失不能恢复原 session

客户端 SHALL NOT 从 Qtserver 枚举 principal 的 active sessions。state_db 行丢失时 SHALL 创建新 session，旧 session只由 TTL、cancel 或 orphan scanner 清理。

#### Scenario: 用户删除 state_db

- **WHEN** 本地没有业务键记录但服务端仍有旧 active session
- **THEN** qtransc SHALL 创建新 session
- **AND** SHALL NOT 猜测或搜索旧 session ID

### Requirement: 下载恢复状态保持在目标旁边

下载 SHALL 继续用目标文件和 `.progress` sidecar 表达局部进度，SHALL NOT 写入 upload state_db。完成校验前最终路径上的部分文件 MAY 可见。pause SHALL 保留这些文件；task delete SHALL 删除 qtransc-owned `.progress`/临时文件但 SHALL NOT 删除用户文件。

#### Scenario: 下载暂停

- **WHEN** 下载在 partial 状态暂停
- **THEN** 目标文件和 `.progress` SHALL 保留供恢复

#### Scenario: 删除下载 task

- **WHEN** 调用方删除 serve download task
- **THEN** qtransc SHALL 清理 `.progress`
- **AND** 已写入的用户目标文件 SHALL 保留
