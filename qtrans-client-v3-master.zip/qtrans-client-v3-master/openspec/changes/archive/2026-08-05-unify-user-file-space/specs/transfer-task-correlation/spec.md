## Purpose

定义 qtransc taskid 的生成、传播和日志关联语义，并保留现有 download grant 的 taskid 绑定兼容契约。

## ADDED Requirements

### Requirement: taskid endpoint 独立生成关联标识

Qtserver SHALL 无认证且在健康运行时始终注册 `/qtserver/v1/taskid`。每次成功调用 SHALL 返回新的 UUID v4，且 SHALL NOT 创建上传、下载或其他业务资源。

#### Scenario: 申请 taskid

- **WHEN** qtransc 在创建上传或下载 task 前调用 taskid endpoint
- **THEN** Qtserver SHALL 返回一个 UUID v4
- **AND** 该调用 SHALL NOT 改变文件或 session 状态

### Requirement: qtransc 为上传和下载请求携带 X-Task-ID

qtransc SHALL 为同一个 upload/download task 的 Qtserver 请求携带 `X-Task-ID`。canonical upload 不得把该 header 保存进 session，也不得用它参与 session ownership、幂等性、鉴权或签名。

#### Scenario: 恢复上传时重新创建 task

- **WHEN** qtransc 使用 SQLite 中的同一 session 恢复上传但当前 taskid 不同
- **THEN** Qtserver SHALL 按当前认证 principal 和 session 继续上传
- **AND** taskid 变化 SHALL NOT 使 session 失效

#### Scenario: 第三方伪造 header

- **WHEN** 第三方请求携带任意受信任格式的 X-Task-ID
- **THEN** 该值 SHALL 只影响当前请求日志标签
- **AND** SHALL NOT 扩大调用方权限或改变业务结果

### Requirement: 暂不新增 X-Task-ID 输入规则

Qtserver SHALL 保持当前 X-Task-ID 信任边界，本 change SHALL NOT 新增长度、字符集、截断或拒绝规则。qtransc 自己生成或申请的 taskid SHALL 继续使用 UUID v4。

#### Scenario: 现有客户端发送 taskid

- **WHEN** 请求使用当前协议允许的 taskid
- **THEN** 服务 SHALL 按现有方式记录它
- **AND** 本 change SHALL NOT 因新的格式策略拒绝该业务请求

### Requirement: download grant 保留 taskid 绑定

download grant request/body 中的 taskid、grant query taskid和HMAC input SHALL 保留现有绑定和格式校验。grant SHALL 自验证且不保存Redis状态。该绑定 SHALL 是“X-Task-ID 只用于日志”的明确兼容例外。

#### Scenario: 申请 download grant

- **WHEN** qtransc 使用 taskid 申请 grant
- **THEN** Qtserver SHALL 将该 taskid 纳入现有 grant 签名和校验上下文

#### Scenario: grant query 使用不同 taskid

- **WHEN** 下载请求 query/body taskid 与 grant 绑定值不同
- **THEN** Qtserver SHALL 按现有 grant 契约拒绝授权

#### Scenario: header 与 grant taskid 不同

- **WHEN** 有效 grant 请求的 X-Task-ID 与受 HMAC 绑定的 body/query taskid 不同或缺失
- **THEN** 下载授权 SHALL 只按现有 body/query taskid 校验
- **AND** header 差异 SHALL NOT 使有效 grant 失败

### Requirement: Qtserver 日志记录当前请求关联值

Qtserver 应用日志 SHALL 优先记录当前 `X-Task-ID`。旧 download grant 客户端缺失该 header 时，日志 SHALL 回退记录 grant 绑定的 taskid。日志 SHALL NOT 记录 Authorization、grant、HMAC secret 或固定 anonymous token。

#### Scenario: canonical upload 内部错误

- **WHEN** 携带 X-Task-ID 的 chunk 请求产生请求级错误
- **THEN** 对应结构化日志 SHALL 记录该 X-Task-ID

#### Scenario: 旧下载客户端没有 header

- **WHEN** 有效 grant 下载没有 X-Task-ID header
- **THEN** Qtserver SHALL 用 grant taskid 作为日志关联值

### Requirement: Nginx access log 记录但不授权 taskid

Nginx 加速下载 access log SHALL 使用安全转义格式记录客户端提供的 X-Task-ID；Nginx SHALL NOT 用该 header 做访问控制、路径选择或 grant 校验。

#### Scenario: X-Accel 下载

- **WHEN** Qtserver 返回 X-Accel-Redirect
- **THEN** Nginx SHALL 在 access log 中保留当前请求 X-Task-ID
- **AND** 下载授权 SHALL 仍完全由 Qtserver 的既有 grant 结果决定
