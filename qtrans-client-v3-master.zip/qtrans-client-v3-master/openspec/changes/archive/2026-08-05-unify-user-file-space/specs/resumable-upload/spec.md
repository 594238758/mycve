## Purpose

定义 canonical Qtserver 可续传上传 API、Redis session、单文件缓存、固定 chunk offset 协议、原子 complete、终态操作锁和 orphan 清理。

## ADDED Requirements

### Requirement: canonical 上传 API 精确替换旧路由

Qtserver SHALL 精确注册以下版本化 API，且 SHALL NOT 保留旧 `/u/file/init|chunk|complete|abort`、无版本别名或尾随 slash 自动修正：

- `POST /qtserver/v1/uploads`
- `GET /qtserver/v1/uploads/{session_id}`
- `GET /qtserver/v1/uploads/{session_id}/chunks/{chunk_index}`
- `PATCH /qtserver/v1/uploads/{session_id}/chunks/{chunk_index}`
- `POST /qtserver/v1/uploads/{session_id}/chunks/{chunk_index}/finalize`
- `POST /qtserver/v1/uploads/{session_id}/complete`
- `POST /qtserver/v1/uploads/{session_id}/cancel`
- `POST /qtserver/v1/uploads/{session_id}/release`

qtransc、标准 upload 和 upload2 的服务内适配 SHALL 使用 canonical API；upload2 面向旧 GUI 的外部协议 SHALL 保持不变。

#### Scenario: 调用旧上传路由

- **WHEN** 调用方访问旧 `/u/file/init`、`/u/file/chunk`、`/u/file/complete` 或 `/u/file/abort`
- **THEN** Qtserver SHALL 返回 404 `ROUTE_NOT_FOUND`

#### Scenario: canonical 路由带尾随 slash

- **WHEN** 调用方访问未精确注册的尾随 slash 版本
- **THEN** Qtserver SHALL 返回 404且 SHALL NOT redirect

### Requirement: JSON 请求遵循统一严格解析

canonical POST JSON SHALL 要求 `application/json`（允许 UTF-8 charset），最大 body 2 MiB，拒绝未知字段和尾随第二个 JSON value；重复 key SHALL 沿用解析器最后值。校验顺序 SHALL 是 route、method、capability、auth/anonymous、Content-Type/body、logical path、session/file state。complete 的空 body SHALL 等价 `{}`。

#### Scenario: 无效 token 和 malformed body 同时存在

- **WHEN** 请求 token 无效且 JSON body malformed
- **THEN** Qtserver SHALL 先返回认证错误

#### Scenario: JSON 含未知字段

- **WHEN** 已鉴权 canonical POST body 含未定义字段
- **THEN** 服务 SHALL 返回 400 `INVALID_REQUEST`

#### Scenario: complete 不发送 body

- **WHEN** 客户端对 complete 发送 Content-Length 0
- **THEN** 服务 SHALL 按空对象和 init 时的 overwrite policy 处理

### Requirement: init 创建单文件 opaque session

`POST /uploads` SHALL 接受 `object_key`、`file_size` 和可选 `overwrite`，默认 false。file_size SHALL 在 0 到 int64 max。客户端 SHALL NOT 提交 session ID、完整 file hash 或 chunk size。服务 SHALL 生成 lowercase UUID v4 `session_id`，客户端 SHALL 将其视为 opaque。

#### Scenario: 目标不存在

- **WHEN** init 请求合法且正式目标不存在
- **THEN** 服务 SHALL 返回 201、`Location` 和 `active`
- **AND** 响应 SHALL 包含 session ID、normalized object key、file size、chunk size/count、`xxh3_128` 和 `layered_xxh3_128_v1`

#### Scenario: 零字节文件

- **WHEN** file_size 为 0
- **THEN** init SHALL 创建 chunk_count 0 的 active session
- **AND** complete SHALL 不要求 finalize chunk

#### Scenario: session ID 非法

- **WHEN** path session ID 缺失、过长、不是 lowercase UUID v4 或不存在
- **THEN** 服务 SHALL 统一返回 404 `SESSION_NOT_FOUND`

### Requirement: init 对已有目标返回服务端事实

overwrite=false 且目标是普通文件时，size 不同 SHALL 返回 200 和 target size；size 相同且正式 hash 可用 SHALL 返回 200 和 hash/algorithm；size 相同但没有 hash SHALL 返回 202 `HASH_PENDING` 与 `Retry-After: 5`。这些响应 SHALL NOT 创建 Redis session 或 cache。已有目录、symlink 或特殊目标 SHALL 返回 422。

#### Scenario: 已有目标 size 不同

- **WHEN** target 是普通文件且 size 与声明不同
- **THEN** init SHALL 返回 200 `target_exists` 和 target_size
- **AND** SHALL NOT 计算或返回 target hash

#### Scenario: 已有同大小目标 hash 可用

- **WHEN** target size 相同且正式 hash fresh 或可 stale-return
- **THEN** init SHALL 返回 200、target hash 和 algorithm

#### Scenario: 已有同大小目标 hash pending

- **WHEN** target size 相同但没有可返回 hash
- **THEN** init SHALL 返回 202 `HASH_PENDING` 和 `Retry-After: 5`
- **AND** qtransc SHALL 轮询而非开始上传

#### Scenario: 客户端 hash 不同

- **WHEN** qtransc 计算本地 hash 后确认与 target hash 不同
- **THEN** qtransc SHALL 重新 init 并显式使用 overwrite=true

### Requirement: session ownership 只由认证 principal 决定

Qtserver SHALL 将 session 绑定 principal，但 session ID、X-Task-ID 或 anonymous token本身 SHALL NOT 越过 principal ownership。对其他 principal 的 GET/PATCH/finalize/complete SHALL 与不存在一样返回 404；cancel/release SHALL 与不存在一样返回 204。

#### Scenario: 其他 principal 猜中 session ID

- **WHEN** 另一个 principal 请求 session 或 chunk
- **THEN** 服务 SHALL 返回 404 `SESSION_NOT_FOUND`

#### Scenario: 恢复 task 的 X-Task-ID 改变

- **WHEN** 同 principal 使用不同 X-Task-ID 恢复 session
- **THEN** 业务 SHALL 正常继续且 session SHALL NOT 保存新 taskid

### Requirement: Redis 是上传控制状态唯一事实源

Redis SHALL 保存 active/committed session、chunk state、stored offset、chunk hash、retention 和 coordination locks。二进制 SHALL 只保存在 temp_root 中一个未预分配 sparse cache file。PostgreSQL SHALL NOT 保存未完成 session 或 chunk 进度。

#### Scenario: Redis 中 session 丢失

- **WHEN** cache 可能仍存在但 Redis active/committed key 不存在
- **THEN** 上传 API SHALL 返回 `SESSION_NOT_FOUND`
- **AND** cache SHALL 只由 orphan scanner 清理

#### Scenario: 创建 cache file 失败

- **WHEN** init 已创建 Redis session但无法创建 cache file
- **THEN** 服务 SHALL 删除 Redis session并返回请求级错误

#### Scenario: Redis 连接失败

- **WHEN** init、PATCH checkpoint 或其他命令发生 Redis 连接级故障
- **THEN** 当前请求 SHALL 返回 500 `INTERNAL_ERROR`（若仍可响应）
- **AND** Qtserver SHALL 触发 fatal graceful shutdown

### Requirement: cache file 缺失使 session 统一失效

Redis session 存在但 cache 缺失、不可打开或事实无法安全使用时，Qtserver SHALL 删除 session并统一返回 404 `SESSION_NOT_FOUND`。外部协议 SHALL NOT 返回 `UPLOAD_CACHE_MISSING`，内部日志 MAY 区分原因。

#### Scenario: cache 被运维删除

- **WHEN** GET、PATCH、finalize 或 complete 发现 cache 缺失
- **THEN** Redis session SHALL 被删除
- **AND** 客户端 SHALL 收到 404 `SESSION_NOT_FOUND`

#### Scenario: rename 后 committed 前崩溃

- **WHEN** 文件已发布但进程在 committed 写入前崩溃，恢复后 session仍存在且 cache path缺失
- **THEN** 后续请求 SHALL 同样返回 `SESSION_NOT_FOUND`
- **AND** qtransc SHALL 重新 init并通过正式 target 事实收敛

### Requirement: 固定 100 MiB chunks 可并行传输

API v1 chunk size SHALL 固定为 104857600 bytes。不同 chunk MAY 并行 PATCH；同一个 qtransc 进程 SHALL NOT 主动并发写同 chunk。cache SHALL 不预分配完整 file size。

#### Scenario: 不同 chunks 并行

- **WHEN** chunk 0 与 chunk 3 同时使用各自正确 offset PATCH
- **THEN** 服务 SHALL 写入同一 sparse cache file 的不同固定区间

#### Scenario: 磁盘中途耗尽

- **WHEN** sparse file 写入时磁盘不足
- **THEN** PATCH SHALL 返回 507
- **AND** 该请求级错误 SHALL NOT 杀死 Qtserver

### Requirement: PATCH 使用严格连续 offset 协议

PATCH SHALL 要求 `Upload-Offset`、positive Content-Length 和 `application/octet-stream`。缺失 Content-Length 或 chunked transfer SHALL 返回 411；非正长度、非法 chunk index或offset SHALL 返回 400；错误 media type SHALL 返回 415；body 超过 chunk 剩余空间 SHALL 返回 413。offset ahead SHALL 返回 409并同时在 JSON和header给出 correct offset。

#### Scenario: 正常续传

- **WHEN** Upload-Offset 等于 Redis stored offset且 body 在 chunk 边界内
- **THEN** 服务 SHALL 从该 offset 写入并推进连续 stored bytes

#### Scenario: 客户端落后于服务端 offset

- **WHEN** Upload-Offset 小于 current stored offset
- **THEN** 服务 MAY 覆盖已经确认的区间
- **AND** 最终 stored offset SHALL 保持连续且不倒退

#### Scenario: 客户端越过未确认区间

- **WHEN** Upload-Offset 大于 current stored offset
- **THEN** 服务 SHALL 返回 409和 current offset
- **AND** SHALL NOT 写 body

#### Scenario: 成功响应

- **WHEN** PATCH 完成必要 checkpoint
- **THEN** 服务 SHALL 返回 204 空 body
- **AND** SHALL 返回 current offset/state headers

#### Scenario: chunk 已 complete 或 verified

- **WHEN** PATCH 到达已 complete/verified chunk
- **THEN** 服务 SHALL NOT 写数据
- **AND** SHALL 以 204 返回当前 offset/state

### Requirement: PATCH 每五秒 checkpoint 并续期

持续 PATCH SHALL 每五秒把连续 stored bytes 写入 Redis并刷新 active retention。正常请求结束 SHALL 完成最后一次 checkpoint 后才返回 204。连接异常中断 SHALL 不额外 checkpoint，客户端 SHALL 从最后确认 offset 覆盖重传。纯 GET 与无数据 stall SHALL NOT 续期。

#### Scenario: 慢速 PATCH 持续发送

- **WHEN** 同一 PATCH 超过五秒且持续有 progress
- **THEN** 服务 SHALL 至少每五秒 checkpoint并续期

#### Scenario: 连接在 checkpoint 间断开

- **WHEN** server写入了未 checkpoint 尾部后连接断开
- **THEN** GET SHALL 只返回最后 Redis offset
- **AND** 客户端 SHALL 覆盖重传尾部

#### Scenario: 最终 checkpoint 失败

- **WHEN** body已写完但最终 Redis checkpoint发生连接级错误
- **THEN** 服务 SHALL NOT 返回 204
- **AND** SHALL 触发 fatal shutdown

### Requirement: same-chunk writer 不提供 barrier

PATCH、finalize 和 verified 状态之间 SHALL NOT 增加 per-chunk writer lease 或 fence。晚到 PATCH 可能在 finalize 读取期间或 verified 后落盘，导致缓存 bytes 与已存 hash 不一致；该风险 SHALL 被接受为受信任客户端下的同 principal 设计缺陷。

#### Scenario: 两个进程并发同 chunk

- **WHEN** 错误客户端在 finalize 同时继续 PATCH同一区间
- **THEN** 服务不保证 verified hash 对应最终 cache bytes
- **AND** 不得因此影响其他 principal 的 namespace

### Requirement: GET session 提供完整可恢复状态

active GET SHALL 返回 session元数据和 unordered、unpaged sparse chunks object，key为 decimal index；缺失 chunk SHALL 等价 `partial`、stored 0。单 chunk GET SHALL 返回 state、stored、chunk_size和适用的 hash。committed GET SHALL 返回原 complete result且不返回 chunks。

#### Scenario: 进程恢复 active session

- **WHEN** qtransc GET active session
- **THEN** 它 SHALL 能依据 sparse chunk states决定每个 chunk 的 offset/finalize/complete动作

#### Scenario: session 非常大

- **WHEN** file_size 产生极多 chunks
- **THEN** GET SHALL 继续返回不分页完整对象
- **AND** 服务 SHALL 接受响应可能过大乃至不可用的设计缺陷

### Requirement: finalize 独立验证完整 chunk

finalize body SHALL 只接受 lowercase 32-hex `chunk_hash`。malformed hash SHALL 返回 400 `INVALID_CHUNK_HASH`；未完整 SHALL 返回 409；服务 SHALL 读取该 chunk 区间计算 `xxh3_128`。匹配后状态变为 verified；mismatch SHALL 返回 409、重置当前 chunk为 partial/stored 0并返回 offset header。相同 verified hash重试 SHALL 200成功，不同 hash SHALL 409。

#### Scenario: chunk hash 匹配

- **WHEN** chunk已 complete且提交 hash匹配
- **THEN** finalize SHALL 返回 200并保存 verified hash

#### Scenario: chunk hash 不匹配

- **WHEN** 服务计算值与提交值不同
- **THEN** finalize SHALL 返回 409 hash mismatch
- **AND** 该 chunk SHALL 回到 partial/stored 0

#### Scenario: verified finalize 幂等重试

- **WHEN** 客户端以相同 hash再次 finalize
- **THEN** 服务 SHALL 返回 200且不重读 chunk

### Requirement: complete 只接受全部 verified chunks

complete SHALL 要求 verified_count 等于 total chunk_count，并按 index组合 hash生成正式 `layered_xxh3_128_v1`，不得重新扫描 cache。缺失 chunk SHALL 返回 409及 total/verified counts。

#### Scenario: 尚有 partial chunk

- **WHEN** 客户端调用 complete但存在未 verified chunk
- **THEN** 服务 SHALL 返回 409 `UPLOAD_INCOMPLETE`
- **AND** SHALL NOT 创建目标父目录或发布文件

#### Scenario: 零 chunk complete

- **WHEN** chunk_count为0
- **THEN** 服务 SHALL 使用固定空文件 hash并发布零字节文件

### Requirement: complete 是唯一 cache 发布操作

finalize SHALL NOT 使 cache 对正式空间可见。complete SHALL 创建允许创建的家目录和 parents、应用权限、fsync cache，并以原子 rename 发布。rename SHALL 是业务成功点。rename前 chmod/chown/fsync失败 SHALL 不发布；rename后 parent fsync失败 SHALL 记录高等级错误但返回成功，SHALL NOT 回滚。

#### Scenario: 尚未 complete

- **WHEN** 所有 chunks verified但客户端暂停
- **THEN** 正式 object key SHALL 仍不存在或保持旧文件

#### Scenario: 发布时父目录缺失

- **WHEN** complete进入发布且parents不存在
- **THEN** 服务 MAY mkdir-p并应用 managed policy

#### Scenario: overwrite 期间读取

- **WHEN** complete原子替换已有普通文件
- **THEN** 并发 reader SHALL 看到完整旧 inode或完整新 inode

### Requirement: no-overwrite 发布必须使用原子 primitive

overwrite=false 的 complete SHALL 使用 Linux `renameat2(RENAME_NOREPLACE)` 或等价原子 primitive。平台或文件系统不支持时 SHALL 返回 500 `ATOMIC_NOREPLACE_UNSUPPORTED`，不得以 stat 后 rename 替代。

#### Scenario: 发布时目标刚被创建

- **WHEN** no-overwrite complete 与其他 writer竞争且目标已存在
- **THEN** complete SHALL 返回 409 conflict
- **AND** SHALL 保留 active session/cache

### Requirement: complete 可以单向升级 overwrite

complete optional body MAY 提供 overwrite。effective overwrite SHALL 是 init overwrite OR complete overwrite；客户端不得从 true降为false。committed retry SHALL 忽略新 body并返回原结果。

#### Scenario: init false complete true

- **WHEN** 上传期间目标被创建且客户端确认覆盖
- **THEN** complete overwrite=true SHALL 原子替换普通文件

#### Scenario: init true complete false

- **WHEN** session在init已允许overwrite而complete body为false或空
- **THEN** effective overwrite SHALL 仍为true

### Requirement: complete 成功结果可幂等读取

发布成功后服务 SHALL 写入 committed状态和固定 complete response，并从成功时重启 retention。重复 complete和GET session SHALL 返回原 response。complete success SHALL 固定使用 HTTP 200 JSON。

#### Scenario: complete response 丢失

- **WHEN** committed已写入但客户端未收到response
- **THEN** 重试 complete SHALL 返回相同 object key、size、file hash和algorithm

#### Scenario: release 前查询 committed

- **WHEN** qtransc本地row仍存在且GET看到committed
- **THEN** 它 SHALL 将业务视为已完成并执行本地清理

### Requirement: complete 不使用 publish intent

本 change SHALL NOT 在 Redis或PostgreSQL增加 publish intent。rename后 committed前崩溃是明确窗口；若恢复后cache缺失，外部只返回 `SESSION_NOT_FOUND`。客户端 SHALL 通过重新init并检查target收敛。

#### Scenario: rename后服务断电

- **WHEN** 正式文件已发布但committed状态未写入
- **THEN** 正式文件 SHALL 保留
- **AND** 客户端重试 MAY 先收到 `SESSION_NOT_FOUND`，再由init返回已有target事实

### Requirement: 正式 hash persistence 不回滚已发布文件

complete SHALL 用 generation CAS 将已知 file hash 写入正式 hash状态。PostgreSQL在rename前故障 SHALL 阻止发布并触发shutdown；rename后写入时才发现连接级故障 SHALL 保留文件、best-effort返回成功并触发shutdown，SHALL NOT 回滚。

#### Scenario: rename后PostgreSQL断开

- **WHEN** 文件已发布但正式hash写入检测到数据库断开
- **THEN** 新文件 SHALL 保持可见
- **AND** Qtserver SHALL 触发fatal graceful shutdown

### Requirement: terminal 操作共享 renewable session lock

complete、cancel和release SHALL 获取同一 session operation lock；complete还 SHALL 获取principal namespace lock。两个lock lease均为30秒、每10秒续租。冲突 SHALL 分别返回409 `SESSION_BUSY`或`NAMESPACE_BUSY`并带`Retry-After: 1`。qtransc SHALL 最多自动重试30秒，之后保留session并报告失败。

#### Scenario: cancel与complete并发

- **WHEN** complete持有session operation lock
- **THEN** cancel SHALL 返回409 `SESSION_BUSY`
- **AND** SHALL NOT 删除session/cache

#### Scenario: namespace被其他mutation占用

- **WHEN** complete无法取得principal namespace lock
- **THEN** SHALL 返回409 `NAMESPACE_BUSY`

### Requirement: Redis locks 是 advisory 而不是严格 fencing

终态和namespace mutation SHALL 在不可逆操作前检查lock token。尚未修改时丢lock SHALL 返回409 `NAMESPACE_LOCK_LOST`；已经部分mkdir SHALL 返回500 `NAMESPACE_OPERATION_PARTIAL`。极端进程暂停越过lease后仍可能发生并发mutation，本change SHALL NOT 增加分布式事务或fencing token。

#### Scenario: rename前发现lock已丢失

- **WHEN** complete尚未正式发布且token不再匹配
- **THEN** complete SHALL 返回409 `NAMESPACE_LOCK_LOST`

#### Scenario: 已创建部分parents后丢lock

- **WHEN** complete已创建目录但尚未rename就失去lock
- **THEN** SHALL 返回500 `NAMESPACE_OPERATION_PARTIAL`
- **AND** 已创建目录 SHALL 不回滚

### Requirement: cancel 与 release 分离且不删除正式文件

cancel SHALL 只终止active session并删除cache；committed cancel SHALL 返回409 `SESSION_COMMITTED`。release SHALL 只删除committed session/cache metadata；active release SHALL 返回409 `SESSION_NOT_COMMITTED`。missing或other-principal cancel/release SHALL 返回204。任何操作 SHALL NOT 删除正式文件。

#### Scenario: 取消active上传

- **WHEN** 用户显式放弃并调用cancel
- **THEN** 服务 SHALL 删除active session和cache并返回204

#### Scenario: complete后release

- **WHEN** qtransc已删除本地row并release committed session
- **THEN** 服务 SHALL 删除committed元数据并返回204
- **AND** 正式文件 SHALL 保留

#### Scenario: cancel与PATCH重叠

- **WHEN** PATCH未持有terminal lock而cancel删除session
- **THEN** PATCH SHALL 在后续Redis checkpoint停止
- **AND** 未立即清理的cache SHALL 由orphan scanner处理

### Requirement: session retention 有固定下限和续期事件

`upload_session_retention_seconds` SHALL 默认86400且最小60。PATCH checkpoint、finalize和complete执行期间 SHALL 持续续期；GET和无数据stall SHALL NOT 续期。committed SHALL 从complete成功时重新计时。

#### Scenario: 用户只轮询GET

- **WHEN** active session没有PATCH/finalize/complete活动而只被GET
- **THEN** GET SHALL NOT 阻止session自然过期

#### Scenario: finalize耗时接近TTL

- **WHEN** finalize仍在读取和hash chunk
- **THEN** 服务 SHALL 在执行期间刷新retention

### Requirement: pause 不等于 cancel

Ctrl+C、GUI pause和暂时网络故障 SHALL 保留active session；显式放弃、LOCAL_FILE_CHANGED和session superseded SHALL 在删除本地row后best-effort cancel。complete成功 SHALL 删除SQLite row后best-effort release。

#### Scenario: Ctrl+C后恢复

- **WHEN** 用户暂停上传后再次执行相同业务键
- **THEN** qtransc SHALL 尝试GET原session而不是先cancel

### Requirement: orphan scanner 只按Redis事实清理temp_root

scanner SHALL 启动立即执行、此后每60秒执行，并使用30秒Redis lock、每10秒续租。它 SHALL 递归lstat temp_root且不跟随symlink，按cache basename session ID查询Redis；session missing时 SHALL 删除regular/symlink/special节点并best-effort删除空目录，但 SHALL NOT 删除temp_root。

#### Scenario: Redis健康且cache无session

- **WHEN** scanner发现一个合法cache节点但Redis无对应active/committed session
- **THEN** scanner SHALL 删除该节点且不跟随其symlink target

#### Scenario: 单个文件I/O失败

- **WHEN** 某cache节点无法lstat或删除
- **THEN** scanner SHALL 记录错误并在下轮重试
- **AND** Qtserver SHALL 保持运行

#### Scenario: scanner查询Redis断开

- **WHEN** orphan扫描发生Redis连接级故障
- **THEN** Qtserver SHALL 触发fatal graceful shutdown

#### Scenario: 多实例同时扫描

- **WHEN** 一个实例持有scanner Redis lock
- **THEN** 其他实例 SHALL 跳过本轮扫描
