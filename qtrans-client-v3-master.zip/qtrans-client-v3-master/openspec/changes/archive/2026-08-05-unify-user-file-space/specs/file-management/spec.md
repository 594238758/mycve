## Purpose

定义统一文件空间的 logical path、list、symlink/特殊节点、canonical 文件管理、qtransc 递归规划以及 download/grant/verify 行为。

## ADDED Requirements

### Requirement: canonical 文件管理 API 使用固定 wire contract

Qtserver SHALL 精确注册以下 API：

```text
GET  /qtserver/v1/files/list?path=/docs
POST /qtserver/v1/files/mkdir  {"path":"/docs"}
POST /qtserver/v1/files/move   {"source":"/a","destination":"/b"}
POST /qtserver/v1/files/delete {"path":"/docs"}
POST /qtserver/v1/files/create {"path":"/empty","overwrite":false}
```

成功状态 SHALL 是 list 200、mkdir新建201/已存在200、move200、delete200、create新建201/已有空文件200。所有这些成功响应 SHALL 是JSON且`code`等于HTTP status。

#### Scenario: 使用 canonical API

- **WHEN** 已鉴权客户端按上述 method和path调用文件管理
- **THEN** Qtserver SHALL 按定义的JSON schema和status响应

#### Scenario: 调用旧browse路由

- **WHEN** 客户端访问旧browse/file-management别名
- **THEN** 服务 SHALL 返回404 `ROUTE_NOT_FOUND`

#### Scenario: delete成功

- **WHEN** delete完成文件系统mutation
- **THEN** 服务 SHALL 返回200 JSON而不是204空响应

### Requirement: JSON与错误响应遵循统一基线

文件管理POST SHALL 使用严格`application/json`、2MiB body上限、未知字段拒绝和单JSON value规则。错误JSON SHALL 包含HTTP status code、稳定`reason_code`、human-readable `message`和适用typed extras，SHALL NOT 新增request ID。鉴权 SHALL 先于body与path校验。

#### Scenario: 未认证请求含坏路径

- **WHEN** write请求既未认证又包含非法logical path
- **THEN** 服务 SHALL 先返回认证错误

#### Scenario: delete部分失败

- **WHEN** 递归delete已删除部分节点后失败
- **THEN** error body SHALL 包含`reason_code=DELETE_PARTIAL`、`partial=true`和逻辑`failed_path`
- **AND** SHALL NOT 泄露物理宿主机路径

### Requirement: logical path 必须绝对且确定地规范化

对象路径 SHALL 是有效UTF-8并以`/`开头。服务 SHALL 合并重复slash并去除非根尾随slash； SHALL 拒绝`.`、`..` segment、NUL、反斜杠和无效UTF-8。规范化后总长 SHALL 不超过1024 bytes，segment SHALL 不超过255 bytes。服务 SHALL NOT执行Unicode normalization。mkdir/move/delete/create SHALL 拒绝操作根`/`。

#### Scenario: 规范化重复slash

- **WHEN** JSON path是`//docs///a/`
- **THEN** 服务 SHALL 使用`/docs/a`进行授权、mutation和响应

#### Scenario: 两个Unicode表示

- **WHEN** 两个名称的Unicode codepoints不同但视觉等价
- **THEN** 服务 SHALL 将其视为不同byte名称

#### Scenario: 目录穿越

- **WHEN** path包含`.`、`..`、反斜杠或NUL
- **THEN** 服务 SHALL 返回path validation错误且不得访问宿主机路径

### Requirement: query和JSON路径解码规则不同

query path SHALL 由HTTP层percent-decode恰好一次，再执行logical path检查。JSON string SHALL NOT URL-decode，`%2F` SHALL 是名称中的字面字符。download URL `/d/down/docs/a.txt` SHALL 在授权和签名中对应规范化`/docs/a.txt`。

#### Scenario: query含encoded slash

- **WHEN** list query path percent-decode后产生新segment边界
- **THEN** 服务 SHALL 对解码后的path重新执行segment和dot检查

#### Scenario: JSON含percent文本

- **WHEN** create JSON path为`/docs/%2F.txt`
- **THEN** 服务 SHALL 操作名字字面为`%2F.txt`的文件

### Requirement: list 只返回单层无序无分页结果

`GET /files/list` SHALL 只枚举请求目录直接子项，不排序、不分页，最多返回文件系统首先枚举的100000项。200响应 SHALL 包含`code,path,truncated,entries`；entry SHALL 包含name、logical path、type、status及适用的target_type、special_type、reason_code、size和last_modified。时间 SHALL 为UTC RFC3339Nano，顺序不保证。

#### Scenario: 小目录完整返回

- **WHEN** 直接子项不超过100000且枚举完成
- **THEN** list SHALL 返回全部直接子项和`truncated=false`

#### Scenario: 大目录被截断

- **WHEN** 目录直接子项超过100000
- **THEN** list SHALL 返回至多100000项和`truncated=true`
- **AND** SHALL NOT 提供下一页token

#### Scenario: list普通文件

- **WHEN** 请求path最终是普通文件
- **THEN** 服务 SHALL 返回422 `NOT_A_DIRECTORY`

#### Scenario: list目标不存在

- **WHEN** 请求目录不存在
- **THEN** 服务 SHALL 返回404 `NOT_FOUND`

#### Scenario: list目标是坏链或循环

- **WHEN** 请求path最终节点是damaged symlink或symlink loop
- **THEN** 服务 SHALL 返回422及对应稳定reason_code

### Requirement: list 对并发变化采用entry级弱一致性

list SHALL 不持有namespace lock。枚举后子项消失或属性发生竞争时，整体 SHALL 仍返回200；该项 SHALL 使用`type=unknown,status=unavailable`以及`ENTRY_CHANGED`或`ENTRY_UNREADABLE`。请求目录本身的permission/I/O错误 SHALL 返回500且不得泄露物理路径。

#### Scenario: 子项在stat前消失

- **WHEN** readdir后该子项被并发删除
- **THEN** entry SHALL 标记`unknown/unavailable/ENTRY_CHANGED`
- **AND** 其他entries SHALL 正常返回

#### Scenario: 请求目录不可读

- **WHEN** Qtserver不能打开请求目录
- **THEN** 整个list SHALL 返回500请求级错误

### Requirement: list 显式表示symlink事实和目标类型

有效symlink entry SHALL 返回`type=symlink,status=normal,target_type=file|directory|special`。坏链或环 SHALL 返回`status=damaged,target_type=null`及对应reason_code。指向特殊节点 SHALL 返回`status=unsupported,target_type=special`。qtransc文本输出 SHALL 按target_type将正常链接展示为普通文件或目录；`--json` SHALL 保留真实`type=symlink`。

#### Scenario: symlink指向普通文件

- **WHEN** list枚举到有效file symlink
- **THEN** entry SHALL 是`type=symlink,status=normal,target_type=file`
- **AND** qtransc文本模式 SHALL 按文件展示

#### Scenario: symlink形成循环

- **WHEN** 子项symlink解析产生ELOOP
- **THEN** entry SHALL 是`status=damaged,target_type=null`
- **AND** reason_code SHALL 表示`SYMLINK_LOOP`

#### Scenario: symlink指向FIFO

- **WHEN** symlink目标是FIFO、socket或device
- **THEN** entry SHALL 是`status=unsupported,target_type=special`

### Requirement: final与intermediate symlink按操作区分

有效intermediate symlink SHALL 正常跟随，即使目标在用户家目录外。download SHALL 跟随final symlink-to-file；显式list和mkdir SHALL 跟随final symlink-to-directory。move/delete SHALL 操作final symlink节点本身。upload/create SHALL 拒绝final symlink。delete SHALL 是唯一允许删除坏链或环链接节点的操作。

#### Scenario: 下载final file symlink

- **WHEN** object key最终节点是指向普通文件的有效symlink
- **THEN** download SHALL 跟随并传输目标bytes

#### Scenario: list final directory symlink

- **WHEN** list path最终是指向普通目录的有效symlink
- **THEN** list SHALL 跟随并枚举目标目录

#### Scenario: delete final symlink

- **WHEN** delete path最终是symlink
- **THEN** 服务 SHALL unlink链接本身且不得删除target

#### Scenario: complete目标是symlink

- **WHEN** canonical upload要发布到任何final symlink
- **THEN** 服务 SHALL 返回422且不得跟随覆盖target

### Requirement: 特殊节点只允许安全枚举和递归unlink

FIFO、socket和device可以由list报告。直接download、overwrite、move或作为delete顶层target SHALL 返回422 `UNSUPPORTED_FILE_TYPE`。递归删除普通目录时，内部symlink和特殊节点 SHALL 只被unlink，不得打开或跟随。

#### Scenario: 直接删除FIFO

- **WHEN** delete的顶层path是FIFO
- **THEN** 服务 SHALL 返回422且不删除该节点

#### Scenario: 删除包含FIFO的目录

- **WHEN** recursive delete进入普通目录并遇到FIFO
- **THEN** 服务 SHALL unlink FIFO并继续

### Requirement: mkdir 是幂等mkdir-p

mkdir SHALL 创建缺失parents并应用家目录和managed policy。最终已是普通目录或有效symlink-to-directory时 SHALL 返回200且`created=false`；新建一项或多项 SHALL 返回201且`created=true`。final symlink-to-file或普通文件 SHALL 返回409；坏链或环 SHALL 返回422。

#### Scenario: 部分父目录存在

- **WHEN** `/a`存在而mkdir请求`/a/b/c`
- **THEN** 服务 SHALL 创建`b/c`并返回201和normalized path

#### Scenario: 最终是directory symlink

- **WHEN** requested path已是有效symlink-to-directory
- **THEN** mkdir SHALL 跟随它并返回200而不替换链接

### Requirement: create 原子创建或清空普通文件

create SHALL mkdir-p，随后在目标parent创建`.qtserver-create-<random>.tmp`，应用文件mode/ownership并原子发布。overwrite默认false。新文件 SHALL 返回201；已有空普通文件且overwrite=false SHALL 返回200幂等；已有非空普通文件且未允许overwrite SHALL 返回409；overwrite=true SHALL 原子清空普通文件。目录、symlink和特殊target SHALL 返回422。

#### Scenario: 新建空文件

- **WHEN** target不存在
- **THEN** create SHALL 发布零字节普通文件并返回201

#### Scenario: 已有空文件

- **WHEN** target是零字节普通文件且overwrite=false
- **THEN** create SHALL 返回200且不替换inode

#### Scenario: 原子清空

- **WHEN** target是非空普通文件且overwrite=true
- **THEN** reader SHALL 看到完整旧inode或完整新空inode

#### Scenario: create进程崩溃留下temp

- **WHEN** 进程在发布前崩溃留下`.qtserver-create-*`
- **THEN** 启动 SHALL NOT 自动清理该文件
- **AND** 它 SHALL 作为普通隐藏文件被list/move/delete

#### Scenario: create正常失败

- **WHEN** create在进程仍健康时发布前失败
- **THEN** 服务 SHALL best-effort删除本次创建的`.qtserver-create-*`

### Requirement: no-overwrite create 必须原子

create no-overwrite SHALL 使用`renameat2(RENAME_NOREPLACE)`或等价原子primitive；不支持时 SHALL 返回500 `ATOMIC_NOREPLACE_UNSUPPORTED`，不得stat后rename。

#### Scenario: 并发创建同一target

- **WHEN** 两个no-overwrite create并发发布同一路径
- **THEN** 至多一个 SHALL 新建成功
- **AND** 另一个 SHALL 得到已存在冲突/幂等结果而不得覆盖

### Requirement: create 写入正式hash并遵守成功点

create SHALL 生成固定空文件hash并以generation CAS写入正式hash状态。rename前的permission/fsync或PostgreSQL故障 SHALL 阻止发布；rename后parent fsync或依赖故障 SHALL NOT 回滚，服务 SHALL 尽量返回成功并按规则记录/退出。

#### Scenario: rename后parent fsync失败

- **WHEN** empty file已rename到target但parent fsync失败
- **THEN** create SHALL 返回成功并记录高等级错误
- **AND** SHALL NOT unlink新文件

#### Scenario: rename后PostgreSQL断开

- **WHEN** 文件已发布而hash persistence检测到数据库连接故障
- **THEN** 文件 SHALL 保持正式可见
- **AND** Qtserver SHALL 触发fatal graceful shutdown

### Requirement: move 使用精确destination和原子no-replace rename

move SHALL 将source移动到exact destination，SHALL NOT把destination解释为目录容器，也 SHALL NOT自动创建destination parent。parent缺失或source缺失 SHALL 返回404。source==destination、destination已存在任意节点 SHALL 返回409。目录移入自身后代 SHALL 返回409 `INVALID_MOVE`。final source symlink SHALL 移动链接本身；特殊source SHALL 返回422。no-replace SHALL 使用`renameat2(RENAME_NOREPLACE)`或等价原子primitive，不支持时 SHALL 返回500 `ATOMIC_NOREPLACE_UNSUPPORTED`，不得stat后rename。

#### Scenario: target不存在

- **WHEN** source存在、destination parent存在且destination不存在
- **THEN** move SHALL 原子rename并返回200

#### Scenario: destination是已有目录

- **WHEN** destination节点已经存在
- **THEN** move SHALL 返回409且不得把source放入该目录

#### Scenario: 跨文件系统

- **WHEN** rename返回EXDEV
- **THEN** move SHALL 返回500 `CROSS_DEVICE_MOVE`
- **AND** SHALL NOT复制后删除source

#### Scenario: 文件系统不支持原子no-replace

- **WHEN** 平台不能为move提供等价的atomic no-replace rename
- **THEN** move SHALL 返回500 `ATOMIC_NOREPLACE_UNSUPPORTED`
- **AND** source与destination SHALL 保持未修改

#### Scenario: move成功后hash

- **WHEN** source被rename到destination
- **THEN** source和destination旧hash generation SHALL 失效
- **AND** destination SHALL 在首次需要时重新计算

### Requirement: delete 使用Linux递归删除语义

delete普通文件、symlink或普通目录 SHALL 采用边遍历边删除，不预扫描、不回滚且不设mount boundary。顶层不存在 SHALL 返回404。开始后子项并发消失 SHALL 视为已删除。真实子mount或bind mount SHALL 按Linux递归语义进入；服务 SHALL 不承诺跨mount事务。

#### Scenario: 删除普通目录树

- **WHEN** 目录包含普通文件、目录、symlink和特殊节点
- **THEN** 服务 SHALL 不跟随symlink，unlink节点并最终删除目录

#### Scenario: 子项并发消失

- **WHEN** delete开始后一个child已被其他操作删除
- **THEN** 服务 SHALL 继续并可返回成功

#### Scenario: 递归中途失败

- **WHEN** 已删除若干节点后遇到permission或I/O错误
- **THEN** 服务 SHALL 返回500 `DELETE_PARTIAL`、`partial=true`和logical failed_path
- **AND** SHALL NOT恢复已删除节点

### Requirement: 文件系统mutation以不可逆syscall为业务成功点

move、delete和create SHALL 在rename/unlink之前完成必须成功的chmod、chown和相关fsync。不可逆syscall成功后的parent directory fsync失败 SHALL 记录高等级错误但业务返回成功，SHALL NOT回滚已完成mutation。

#### Scenario: move rename后parent fsync失败

- **WHEN** source已成功rename到destination但parent fsync失败
- **THEN** move SHALL 返回成功且不得rename回source

#### Scenario: delete unlink后parent fsync失败

- **WHEN** target已成功unlink但parent fsync失败
- **THEN** delete SHALL 返回成功且不得重建target

### Requirement: namespace mutation使用advisory renewable lock

mkdir、create、move、delete和complete SHALL 使用principal namespace lock，lease30秒且每10秒续租。冲突 SHALL 返回409 `NAMESPACE_BUSY`和`Retry-After: 1`。不可逆操作前 SHALL 检查token；未修改即丢失返回409 `NAMESPACE_LOCK_LOST`，已有partial mutation返回对应500 partial错误。该lock SHALL NOT宣称严格fencing。

#### Scenario: mkdir持锁时move到达

- **WHEN** 同principal namespace lock已被另一mutation占用
- **THEN** move SHALL 返回409 `NAMESPACE_BUSY`

#### Scenario: delete中途丢lock

- **WHEN** delete已unlink部分节点后lock失效
- **THEN** 服务 SHALL 返回500 `DELETE_PARTIAL`

### Requirement: qtransc 文件管理CLI使用canonical能力

qtransc SHALL 提供list、mkdir、move和delete对canonical API的调用；create SHALL 只作为API能力，本change SHALL NOT增加touch/create CLI。文本输出用于人类，`--json` SHALL 保留服务端结构，包括symlink真实type。

#### Scenario: 文本list

- **WHEN** 用户执行qtransc list
- **THEN** stdout SHALL 展示人类可读结果，正常symlink按target_type展示

#### Scenario: JSON list

- **WHEN** 用户执行qtransc list --json且请求成功
- **THEN** stdout SHALL 输出单一有效JSON对象并保留entry字段

#### Scenario: 调用旧CLI命令

- **WHEN** 用户调用`dlist|ulist|umkdir|umove|udelete`
- **THEN** qtransc SHALL 按未知命令失败且 SHALL NOT 保留兼容别名

### Requirement: qtransc 递归规划在传输前完成并有固定上限

qtransc目录上传/下载 SHALL 在传输bytes前完成规划，限制100000个普通文件、200000总entries、128深度、1024-byte remote path和255-byte segment。任一list返回`truncated=true` SHALL 使整个目录任务失败；不得使用前100000项启动部分任务。

#### Scenario: 目录超过服务端list上限

- **WHEN** 规划中的任一list响应`truncated=true`
- **THEN** qtransc SHALL 在传输开始前报“目录超过10万条目，无法启动任务”并失败

#### Scenario: 直接qtransc list被截断

- **WHEN** 用户直接list一个返回truncated的目录
- **THEN** 文本模式 SHALL 一个entry也不显示，只输出错误并非零退出
- **AND** `--json` SHALL 在stdout输出单一JSON error object且不得包含部分entries

#### Scenario: 超过递归总entries

- **WHEN** 多层目录累计超过200000项
- **THEN** qtransc SHALL 在传输前以planning错误失败

### Requirement: 远端递归跟随正常directory symlink但不维护identity map

qtransc SHALL 通过list API递归远端目录，并跟随`status=normal,target_type=directory`的symlink，将其内容下载为普通本地目录。客户端 SHALL NOT额外维护inode/canonical-target去重。循环 SHALL 最终由`SYMLINK_LOOP`、depth、path或entry limit导致传输前失败，但不保证精确识别为目录环。

#### Scenario: 输入目录本身是symlink loop

- **WHEN** 首次list返回`SYMLINK_LOOP`
- **THEN** qtransc SHALL 在传输前失败

#### Scenario: 有效ancestor link形成逻辑递归

- **WHEN** 每次list单独成功但路径不断返回祖先内容
- **THEN** qtransc SHALL 最终命中固定planning限制并失败
- **AND** SHALL NOT开始部分传输

#### Scenario: 显式remote source是damaged或special

- **WHEN** 用户直接下载damaged symlink或special node
- **THEN** qtransc SHALL 在规划阶段失败

#### Scenario: remote目录内含damaged或special entry

- **WHEN** 递归list枚举到不能下载的damaged symlink或special node
- **THEN** qtransc SHALL 跳过该entry、记录warning并继续健康项

### Requirement: 本地目录上传不跟随symlink

显式local source是symlink或特殊节点时规划 SHALL 失败；递归目录内遇到这些节点 SHALL 跳过并warning。hard link SHALL 按每个logical path分别上传。空目录 SHALL 先通过mkdir保留；目录上传 SHALL 同时要求upload和file_management capabilities。

#### Scenario: 显式source是symlink

- **WHEN** 用户将local symlink直接作为upload source
- **THEN** qtransc SHALL 在规划阶段失败

#### Scenario: nested symlink

- **WHEN** 递归扫描普通目录遇到symlink
- **THEN** qtransc SHALL 跳过它、记录warning并继续其他健康项

#### Scenario: 空目录

- **WHEN** upload source tree包含空目录
- **THEN** qtransc SHALL 在传输文件bytes前调用mkdir创建对应remote目录

#### Scenario: 下载空目录

- **WHEN** remote规划包含空目录
- **THEN** qtransc SHALL 创建对应local目录，即使没有文件bytes需要下载

### Requirement: 多source映射和冲突必须确定

upload destination SHALL 总是目录：单文件映射为`destination/basename`，目录映射为`destination/source-basename`，多source均保留basename；第一版不得在upload中同时改名。download多source也 SHALL 保留basename。规划 SHALL 在执行前检测多个source映射到同一local/remote target；本地冲突 SHALL 使用实际OS大小写语义。

#### Scenario: 两个source basename相同

- **WHEN** 多source会映射到同一destination path
- **THEN** qtransc SHALL 在传输前失败而不得静默覆盖

#### Scenario: 用户需要上传时改名

- **WHEN** 用户希望单文件上传到不同basename
- **THEN** 第一版 SHALL 要求上传后显式move

### Requirement: recursive task 保留健康项但规划错误整体失败

规划limit、目录list失败或mapping冲突 SHALL 在传输前使task失败。传输阶段单文件错误 SHALL 允许其他已规划健康文件继续，最终task为failed；仅有warnings SHALL completed。

#### Scenario: nested特殊节点被跳过

- **WHEN** upload规划只有可跳过的nested symlink/special warnings
- **THEN** 健康文件 SHALL 继续且最终task MAY completed with warnings

#### Scenario: 子目录list权限失败

- **WHEN** remote递归规划无法读取任一目录
- **THEN** 整体 SHALL 在传输前失败且不得发布partial task计划

### Requirement: download对象统一使用logical absolute object_key

grant、small、down和verify SHALL 使用规范化logical absolute object_key。grant和small SHALL 只接受显式普通文件；目录输入 SHALL 返回400 `INVALID_REQUEST`。final symlink-to-file按普通文件处理；special或damaged symlink SHALL 失败。

#### Scenario: 目录作为grant输入

- **WHEN** grant request包含directory object_key
- **THEN** 整个request SHALL 返回400且不签发任何grant

### Requirement: grant 批量验证并保持顺序

单次grant SHALL 最多1000个objects，服务 SHALL 先全量验证再签发。normalized duplicates SHALL 保留第一次；response SHALL 按首次请求顺序返回object_key、size和grant，不得部分成功。

#### Scenario: 批次中一个对象无效

- **WHEN** grant batch中任一object不存在或类型不支持
- **THEN** 整批 SHALL 失败且不返回其他对象grant

#### Scenario: normalized duplicate

- **WHEN** 两个输入规范化为同一object_key
- **THEN** response SHALL 只保留第一次出现

### Requirement: grant 保持现有taskid HMAC绑定和无Redis状态

download grant SHALL 保留现有body/query taskid和HMAC兼容绑定；默认TTL900秒、最小60秒。grant SHALL 自验证且不存Redis、不续期、不支持revoke。X-Task-ID仅用于日志，header与grant taskid不同不影响授权。

#### Scenario: grant过期

- **WHEN** qtransc下载收到410
- **THEN** qtransc SHALL 使用相同grant taskid重新申请
- **AND** SHALL 根据`.progress`用Range继续

### Requirement: down 保证GET full和single Range

`/d/down` SHALL 只注册GET，HEAD SHALL 405。服务 SHALL 支持完整下载和单Range，不可满足返回416；multi-range行为不保证。成功 SHALL 设置`application/octet-stream`、基于logical basename的Content-Disposition、`Cache-Control: private, no-store`和`Accept-Ranges: bytes`。开始传输后读取错误 SHALL 断开连接而不得追加JSON。

#### Scenario: 有效single Range

- **WHEN** grant有效且请求一个可满足byte range
- **THEN** 服务 SHALL 返回206和对应bytes

#### Scenario: stream开始后文件读取失败

- **WHEN** headers/body已开始后底层read失败
- **THEN** 连接 SHALL 中断
- **AND** 服务 SHALL NOT在body尾部输出error JSON

### Requirement: download grant 与路径修改采用弱一致性

grant SHALL 授权normalized logical path而非inode snapshot。签发后该路径被overwrite、move或delete时，后续下载 MAY 读取新文件或得到not found；活动direct/Nginx下载 SHALL 不持有namespace lock。

#### Scenario: grant后target被覆盖

- **WHEN** 同object_key在下载前被原子overwrite
- **THEN** 有效grant MAY 下载新inode

#### Scenario: 下载中发生delete

- **WHEN** direct handler已打开旧inode后路径被delete
- **THEN** 当前流 MAY 继续读取旧inode

### Requirement: small download 使用固定批量限制和v1 manifest

small SHALL 默认最多100 files、每文件4MiB、总计128MiB。服务 SHALL 在发送headers前打开所有文件并同步计算其`layered_xxh3_128_v1`，manifest/session SHALL 使用v1。stream开始前错误 SHALL JSON失败；开始后错误 SHALL 断连接。

#### Scenario: small批次准备失败

- **WHEN** headers前某文件无法打开或hash
- **THEN** 整批 SHALL 返回JSON error且不开始stream

#### Scenario: small stream中断

- **WHEN** stream开始后任一文件失败
- **THEN** qtransc SHALL 丢弃该batch临时结果
- **AND** 相关文件 SHALL 改走普通download链路

### Requirement: verify 区分file和chunk

file verify SHALL 使用PostgreSQL正式hash：无可用hash时返回202，hash可用时返回200并包含match、calculated_hash和hash_algorithm，mismatch也 SHALL 是200。chunk verify SHALL 同步读取最多一个104857600-byte区间并计算`xxh3_128`，不得写PostgreSQL。

#### Scenario: file hash pending

- **WHEN** verify file没有可返回正式hash
- **THEN** 服务 SHALL 返回202 `HASH_PENDING`和Retry-After 5

#### Scenario: verify mismatch

- **WHEN** client hash与正式hash不同
- **THEN** 服务 SHALL 返回200、`match=false`和calculated hash

#### Scenario: verify单chunk

- **WHEN** 请求验证一个合法chunk区间
- **THEN** 服务 SHALL 同步读取该区间并返回`xxh3_128`
- **AND** SHALL NOT创建file_hashes记录

### Requirement: qtransc 对下载hash mismatch只自动重下一次

第一次file mismatch时 qtransc SHALL 删除`.progress`并从零重下该文件一次；第二次仍mismatch时前台 SHALL失败，serve task SHALL `stopped`。批量任务中其他成功文件 SHALL NOT重下，small中 SHALL 只重下失败文件。

#### Scenario: 首次mismatch

- **WHEN** verify返回match=false且该文件尚未因mismatch重下
- **THEN** qtransc SHALL 从零重下一次

#### Scenario: 第二次mismatch

- **WHEN** 同一文件重下后再次mismatch
- **THEN** 前台 SHALL 非零失败或serve task SHALL stopped

### Requirement: qtransc retry有界且mutation不盲重试

transport和HTTP 408/429/500/502/503/504 SHALL 从1秒指数退避到5秒并加20% jitter；连续30秒无有效response/progress后 SHALL停止。hash 202轮询不计入该窗口；SESSION/NAMESPACE_BUSY另有最多30秒窗口。401只refresh一次。move/delete在结果不确定时 SHALL NOT自动重试。

qtransc SHALL 同时支持`Retry-After`的delta-seconds和HTTP-date形式。

#### Scenario: PATCH响应不确定

- **WHEN** PATCH连接在response前断开
- **THEN** qtransc SHALL 先GET offset再决定重传

#### Scenario: complete响应不确定

- **WHEN** complete请求断连
- **THEN** qtransc MAY 幂等重试complete或GET session

#### Scenario: move断连

- **WHEN** move可能已经完成但response丢失
- **THEN** qtransc SHALL 报告不确定结果且不得自动重复mutation

#### Scenario: 服务返回HTTP-date Retry-After

- **WHEN** 可重试响应携带合法HTTP-date
- **THEN** qtransc SHALL 以该时间约束下次尝试

### Requirement: qtransc task状态和退出码保持现有集合

serve SHALL 只公开`pending|running|completed|stopped|failed`，不新增paused或partial。主动pause和可恢复错误 SHALL 是stopped；规划/config/auth等不可恢复错误 SHALL failed。CLI退出码 SHALL 是0成功含warnings、1 remote/auth/network/transfer、2 CLI/local config/planning/state DB、130 SIGINT。stdout SHALL 用于结果，stderr SHALL 用于progress/warnings/errors；`list --json`失败 SHALL 在stdout输出单一JSON error。

#### Scenario: task只有warnings

- **WHEN** 所有可传输文件成功且只有skip warnings
- **THEN** task SHALL completed且CLI退出0

#### Scenario: planning limit失败

- **WHEN** 目录规划超过固定限制
- **THEN** task SHALL failed且CLI退出2

### Requirement: 旧GUI外部协议只做内部适配

upload2和download2面向旧GUI的WebSocket、进程和HTTP外部协议 SHALL 保持现有兼容契约；实现 SHALL 只把其内部文件空间、hash算法和canonical API适配到本change。

#### Scenario: 旧GUI启动download2

- **WHEN** 兼容GUI使用既有download2协议
- **THEN** qtransc SHALL 保持原外部消息与进程交互
- **AND** 内部 SHALL 使用统一logical object空间
