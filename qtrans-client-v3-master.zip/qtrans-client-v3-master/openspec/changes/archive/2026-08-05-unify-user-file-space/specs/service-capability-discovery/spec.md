## Purpose

定义 Qtserver 的依赖生命周期、capabilities 发现、配置和迁移边界，以及 qtransc 的预检行为。

## ADDED Requirements

### Requirement: PostgreSQL 和 Redis 是 fatal dependencies

Qtserver SHALL 在启动时成功连接 PostgreSQL、校验受支持的 schema version，并成功执行 Redis PING；任一失败 SHALL 拒绝启动。服务 SHALL NOT 提供 Redis 启动降级、PostgreSQL 运行期降级或依赖恢复后的进程内自动恢复。

#### Scenario: PostgreSQL 启动时不可用

- **WHEN** Qtserver 无法连接 PostgreSQL或 schema version 不受支持
- **THEN** Qtserver SHALL 以非零状态拒绝启动

#### Scenario: Redis 启动时不可用

- **WHEN** Qtserver 无法完成 Redis PING
- **THEN** Qtserver SHALL 以非零状态拒绝启动

### Requirement: fatal dependency 故障触发 graceful shutdown

Qtserver SHALL 每五秒检查 PostgreSQL 和 Redis 健康状态。健康检查或业务命令发现 connection refused、连接断开、timeout 或协议错误时，服务 SHALL 停止接受新连接，给予现有请求最多 30 秒完成，然后以非零状态退出。此时所有尚可响应且未完成的业务请求 SHALL 返回 HTTP 500 `INTERNAL_ERROR`，而不是 503 或降级结果。

#### Scenario: 运行期 Redis 断开

- **WHEN** Redis 健康检查或业务命令检测到连接级故障
- **THEN** Qtserver SHALL 触发 graceful shutdown
- **AND** SHALL NOT 等待 Redis 恢复后继续服务

#### Scenario: 运行期 PostgreSQL 断开

- **WHEN** PostgreSQL 健康检查或业务命令检测到连接级故障
- **THEN** Qtserver SHALL 触发同一 graceful shutdown 流程

#### Scenario: 正常 signal 停止

- **WHEN** Qtserver 收到 SIGINT 或 SIGTERM且没有 fatal dependency
- **THEN** graceful shutdown 完成后的进程退出码 SHALL 为 0

### Requirement: 已完成文件系统修改不因依赖故障回滚

文件系统操作达到 rename、unlink 等业务成功点后，随后检测到 PostgreSQL 或 Redis 故障 SHALL NOT 回滚已经完成的正式文件修改。服务 SHALL best-effort 向当前请求返回成功，再触发 shutdown；如果来不及响应，客户端 MAY 看到连接断开。

#### Scenario: complete rename 后 Redis 断开

- **WHEN** complete 已原子发布正式文件但尚未写 committed response 时 Redis 断开
- **THEN** Qtserver SHALL 保留已发布文件且 SHALL NOT 反向 rename
- **AND** SHALL 触发 graceful shutdown

#### Scenario: delete unlink 后 PostgreSQL 断开

- **WHEN** delete 已完成不可逆 unlink 后检测到 PostgreSQL 故障
- **THEN** 删除 SHALL 保持生效
- **AND** 服务 SHALL 尽量返回成功后退出

### Requirement: 仅连接级 PostgreSQL 和 Redis 故障终止服务

锁冲突、CAS miss、key 不存在、唯一约束和查询无结果 SHALL NOT 被判定为依赖故障。身份服务超时或拒绝、单个 principal 目录错误、单次文件 I/O、磁盘满和客户端错误 SHALL 是请求级错误且 SHALL NOT 终止 Qtserver。

#### Scenario: 上传磁盘空间不足

- **WHEN** 单次 PATCH 因磁盘空间不足失败
- **THEN** 请求 SHALL 返回 507
- **AND** Qtserver SHALL 继续处理其他请求

#### Scenario: namespace lock 冲突

- **WHEN** 请求未获取同 principal namespace lock
- **THEN** 请求 SHALL 返回 409 `NAMESPACE_BUSY`
- **AND** Qtserver SHALL NOT 退出

### Requirement: capabilities 在健康运行时始终可访问

Qtserver 健康运行期间 SHALL 无认证注册 `/qtserver/v1/capabilities`。响应 SHALL 包含 `qtserver_version`、`api_version`、capabilities 的 `enabled`/`available`、limits 和 algorithms。进程健康时所有 enabled capability SHALL 具有 `available=true`；fatal dependency 被检测后不承诺该接口仍可查询。

#### Scenario: 查询健康服务

- **WHEN** 客户端无认证查询 capabilities
- **THEN** 服务 SHALL 返回 200
- **AND** 每个启用能力 SHALL 返回 `enabled=true,available=true`

#### Scenario: 能力被配置关闭

- **WHEN** read 或 write 被关闭
- **THEN** 对应 capability SHALL 返回 `enabled=false,available=false`

### Requirement: capabilities 公布协议版本和关键限制

capabilities SHALL 至少公布 list 上限 100000、逻辑路径上限 1024 bytes、segment 上限 255 bytes、grant 上限 1000、chunk size 104857600，以及 small download 的默认文件数、单文件和总大小限制。algorithms SHALL 包含 `xxh3_128` 和 `layered_xxh3_128_v1`，并 SHALL 公布 anonymous read/write 可用性。

#### Scenario: qtransc 读取服务契约

- **WHEN** qtransc 查询 capabilities
- **THEN** 它 SHALL 能从响应确定 API major version、所需能力、限制和 hash algorithms
- **AND** SHALL NOT 根据 Qtserver 应用版本号猜测兼容性

### Requirement: qtransc 在创建任务或操作前预检 capability

qtransc upload、download、list、mkdir、move 和 delete SHALL 在创建 task 或发送操作前查询 capabilities，并 MAY 缓存同一服务响应五秒。目录上传 SHALL 同时要求 upload 和 file_management。

#### Scenario: 服务没有所需能力

- **WHEN** 预检发现所需 capability disabled 或 API major version 不兼容
- **THEN** qtransc SHALL 在传输或 mutation 开始前失败

#### Scenario: 服务连接失败

- **WHEN** 创建 task 前无法连接 Qtserver
- **THEN** qtransc SHALL NOT 创建 task
- **AND** SHALL 报告服务不可用

### Requirement: fatal shutdown 后 qtransc 有界停止

活动前台 upload/download 在正常网络重试窗口结束后 SHALL 非零退出并保留上传 SQLite 行。serve 中的活动任务 SHALL 在重试窗口结束后进入 `stopped` 并保留恢复状态；qtransc SHALL NOT 无限等待 Qtserver 恢复。

#### Scenario: 前台上传期间服务退出

- **WHEN** Qtserver 因 fatal dependency 退出且 30 秒内不能恢复连接
- **THEN** qtransc SHALL 非零退出
- **AND** 未完成上传行 SHALL 保留供用户重新执行

#### Scenario: serve 上传期间服务退出

- **WHEN** serve task 超过网络重试窗口仍无法连接服务
- **THEN** task SHALL 进入 `stopped`
- **AND** 调用方 SHALL 可在 Qtserver 恢复后重新创建或恢复任务

### Requirement: 路由、method 和业务对象不存在可区分

Qtserver SHALL 只注册精确版本化路由，不自动重定向尾随 slash，也不注册无版本或旧别名。未知或能力关闭路由 SHALL 返回 404 `ROUTE_NOT_FOUND`；已注册路由的错误 method SHALL 返回 405；业务对象不存在 SHALL 返回对应 404 reason code。

#### Scenario: write 关闭时访问 upload

- **WHEN** write capability 关闭且客户端调用 canonical upload route
- **THEN** 服务 SHALL 返回 404 `ROUTE_NOT_FOUND`

#### Scenario: 文件不存在

- **WHEN** read route 已注册且鉴权成功但对象不存在
- **THEN** 服务 SHALL 返回 404 `NOT_FOUND`

#### Scenario: 对 download 使用 HEAD

- **WHEN** 客户端对只注册 GET 的 `/d/down` 发送 HEAD
- **THEN** 服务 SHALL 返回 405

#### Scenario: 浏览器发送 CORS preflight

- **WHEN** 客户端对业务路由发送未显式注册的 OPTIONS
- **THEN** Qtserver SHALL NOT 自动添加 CORS handler
- **AND** 请求 SHALL 按 route/method 基线返回404或405

### Requirement: 配置 schema 严格且 secrets 不泄漏

Qtserver SHALL 拒绝未知或旧配置字段，不从环境变量覆盖配置。`qtserver run` SHALL 只允许 `--port`、`--host`、`--loglevel` 和 `--logpath` 覆盖。PostgreSQL DSN SHALL 只从 `[postgres].dsn` 读取；普通日志和配置输出 SHALL redact DSN、Redis password、HMAC secret、fake token keys、Authorization 和 anonymous token。

#### Scenario: config validate

- **WHEN** 运维运行 `config validate`
- **THEN** 命令 SHALL 只执行配置和本地路径的只读校验
- **AND** SHALL NOT 连接 PostgreSQL、Redis 或身份服务，也 SHALL NOT 创建目录

#### Scenario: 使用旧配置字段

- **WHEN** 配置包含已删除字段或未知字段
- **THEN** validate 和启动 SHALL 失败

### Requirement: PostgreSQL migration 必须显式执行

`qtserver db migrate --config <absolute-file>` SHALL 使用配置中的同一 DSN，等待 PostgreSQL advisory lock 最多 30 秒，并按版本以独立事务执行 forward migrations。命令 SHALL NOT 支持 down migration；Qtserver 启动 SHALL 只校验 schema，SHALL NOT 自动执行 DDL。

#### Scenario: 两个 migration 并发

- **WHEN** 第二个 migration 在 30 秒内无法取得 advisory lock
- **THEN** 它 SHALL 失败且不得并发修改 schema

#### Scenario: 数据库版本比程序新

- **WHEN** schema version 高于当前程序支持版本
- **THEN** migrate 和 Qtserver 启动 SHALL 均失败

### Requirement: HTTP 基线适合长传输

Qtserver SHALL 使用 `ReadHeaderTimeout=10s` 和 `IdleTimeout=120s`，不得设置覆盖完整上传或下载的全局 ReadTimeout/WriteTimeout。PATCH 和 direct download 连续 60 秒没有 bytes progress 时 SHALL 取消当前请求。

#### Scenario: 慢速但持续传输

- **WHEN** 长传输持续产生 byte progress
- **THEN** 它 SHALL NOT 因全局请求时长而被取消

#### Scenario: 数据流停滞

- **WHEN** PATCH 或 direct download 连续 60 秒没有 byte progress
- **THEN** 服务 SHALL 取消当前请求
