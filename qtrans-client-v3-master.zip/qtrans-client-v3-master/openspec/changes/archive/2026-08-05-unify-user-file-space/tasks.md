## 1. Qtserver 配置与依赖基础设施

- [x] 1.1 替换 Qtserver 配置模型与严格校验，落实统一 user_home_root、temp_root、能力开关、PostgreSQL 和 transfer 参数
- [x] 1.2 实现 PostgreSQL forward-only migration、schema 校验和 `qtserver db migrate` 命令
- [x] 1.3 实现 PostgreSQL/Redis 启动检查、运行期健康检查和 fatal graceful shutdown 生命周期

## 2. Qtserver 统一文件空间与 HTTP 基线

- [x] 2.1 实现 logical path、principal home、anonymous、managed policy 和安全原子文件系统 primitives
- [x] 2.2 实现严格 JSON、统一错误、exact route/method、X-Task-ID 日志和长传输 HTTP 基线
- [x] 2.3 实现 capabilities 与 taskid 公共 API，并按 read/write 开关注册业务路由

## 3. Qtserver 正式 hash 管理

- [x] 3.1 实现 xxh3_128 与 layered_xxh3_128_v1 算法及文件 fingerprint
- [x] 3.2 实现 PostgreSQL file_hashes 状态机、Redis cache、generation 失效和后台 worker

## 4. Qtserver 文件与下载能力

- [x] 4.1 实现 canonical list、mkdir、move、delete 和 create API 及 namespace advisory lock
- [x] 4.2 将 grant、small、down、verify 适配统一 logical object 空间、正式 hash 和既有 taskid HMAC 契约
- [x] 4.3 更新 Nginx 生成逻辑，落实安全 internal URI、read 开关和 X-Task-ID access log

## 5. Qtserver canonical resumable upload

- [x] 5.1 实现 Redis-only upload session/chunk 状态、单 sparse cache 文件和 session ownership
- [x] 5.2 实现 PATCH checkpoint、chunk finalize、可恢复 GET 与严格 wire contract
- [x] 5.3 实现 complete/cancel/release、session/namespace renewable locks、原子发布和正式 hash CAS
- [x] 5.4 实现 session retention 与 temp_root orphan scanner，并把 upload2 内部适配到统一空间

## 6. qtransc 服务发现与文件管理

- [x] 6.1 实现 capabilities 预检、统一错误解析、Retry-After 和有界重试基础设施
- [x] 6.2 以 `list|mkdir|move|delete` 替换旧文件管理命令并使用 canonical API
- [x] 6.3 实现上传与下载目录的传输前递归规划、空目录保留、symlink/special 规则和固定限制

## 7. qtransc 上传恢复状态与 canonical 协议

- [x] 7.1 实现全局 `--state-db`、安全 SQLite user_version=1 和 upload_files repository
- [x] 7.2 将标准 upload 与 upload2 内部流程迁移到 canonical session/chunk/finalize/complete/cancel/release API
- [x] 7.3 实现单 source handle fingerprint、SQLite 恢复/替换/清理语义、pause/abandon 和 serve task 状态收敛

## 8. qtransc 下载与兼容适配

- [x] 8.1 将 download/grant/small/down/verify 迁移到 logical object_key，携带 X-Task-ID 并落实 mismatch 单次重下
- [x] 8.2 保持 upload2/download2 外部 GUI 协议不变并完成统一文件空间内部适配

## 9. 文档与构建

- [x] 9.1 同步 Qtserver/qtransc 权威 API、配置、设计、部署和 CLI 文档及默认部署配置
- [x] 9.2 格式化源码并分别编译 qtserver 与 qtransc
