## MODIFIED Requirements

### Requirement: recursive task 保留健康项但规划错误整体失败

规划limit、目录list失败或mapping冲突 SHALL 在传输前使task失败。传输阶段单文件错误 SHALL 允许其他已规划健康文件继续；首轮结束后，可恢复传输错误对应的文件 SHALL 进入按轮重试队列。每轮 SHALL 对队列中的每个文件尝试一次；本轮至少一个文件成功时 SHALL 仅将仍为可恢复错误的文件送入下一轮，本轮没有文件成功时 SHALL 停止自动重试。重试 SHALL 复用既有session、本地恢复状态、文件hash和已确认分片，不得重新处理已经committed或existing的文件。永久错误不得进入下一轮。停止重试后最终task SHALL 按错误分类进入failed或带错误的stopped。仅有warnings SHALL completed。

#### Scenario: nested特殊节点被跳过

- **WHEN** upload规划只有可跳过的nested symlink/special warnings
- **THEN** 健康文件 SHALL 继续且最终task MAY completed with warnings

#### Scenario: 子目录list权限失败

- **WHEN** remote递归规划无法读取任一目录
- **THEN** 整体 SHALL 在传输前失败且不得发布partial task计划

#### Scenario: 重试轮取得进展

- **WHEN** 当前重试轮至少有一个文件committed或existing，且仍有文件以可恢复错误失败
- **THEN** qtransc SHALL 仅把仍然失败的可恢复文件送入下一轮
- **AND** SHALL NOT 重新处理本轮成功或此前已经成功的文件
- **AND** 下一轮 SHALL 从服务端已确认offset继续并跳过已验证分片

#### Scenario: 重试轮没有进展

- **WHEN** 当前重试轮中的所有文件均未成功
- **THEN** qtransc SHALL NOT 启动下一轮
- **AND** task SHALL 按现有错误分类进入failed或带错误的stopped
- **AND** 未完成上传状态 SHALL 保留供后续任务恢复

#### Scenario: 多轮后全部恢复

- **WHEN** 每个继续发生的重试轮都至少成功一个文件，并且最后一个队列文件成功
- **THEN** qtransc SHALL completed该task
- **AND** 每个已经committed或existing的文件 SHALL 只从重试队列移除而不得再次上传

#### Scenario: 单文件永久错误

- **WHEN** 单文件发生本地文件变化、本地状态错误、认证或权限拒绝、非法请求或确定的hash错误
- **THEN** qtransc SHALL NOT 将该文件加入下一重试轮
- **AND** 其他已规划健康文件 SHALL 继续
- **AND** 最终task SHALL failed或进入现有错误分类规定的终态
