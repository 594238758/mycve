## 1. Qtserver 配置与能力发现

- [x] 1.1 在 `TransferConfig`、默认值、严格校验和部署默认配置中增加 `max_file_bytes`，默认 1099511627776，并拒绝非法值及 `max_small_file_bytes` 大于它的组合；确认现有未显式配置的部署使用默认值。
- [x] 1.2 在 `/qtserver/v1/capabilities` 的 `limits` 中发布 `max_file_bytes`；确认字段反映当前有效的 transfer 配置而不改变现有 capability 键。

## 2. Qtserver 单文件强制边界

- [x] 2.1 为 `FILE_TOO_LARGE` 建立复用的 HTTP 413 错误响应，包含 `file_size` 与 `max_file_bytes`；确认响应遵守既有 JSON error envelope。
- [x] 2.2 在 canonical upload init 的 session、cache 和业务登记之前拒绝超限 `file_size`；确认合法的零字节和 1 TiB 以下文件的既有 init 路径不变。
- [x] 2.3 在 grant、small 和 direct download（含 Nginx internal redirect 前）统一检查当前普通文件大小；确认超限 batch 不签发部分 grant、超限文件仍不影响 `/files/list` 的枚举结果。

## 3. qtransc 传输规划边界

- [x] 3.1 扩展 qtransc capabilities 解析，读取有效的 `limits.max_file_bytes` 并为缺少该字段的 API v1 服务提供 1 TiB 回退；确认缺字段不触发 API 版本失败。
- [x] 3.2 建立 qtransc 共享的 10,000 普通文件计划上限和 `FILE_TOO_LARGE`、`TASK_FILE_LIMIT_EXCEEDED` 错误映射；确认 CLI、JSON 输出、serve task summary/detail/SSE 使用稳定原因码。
- [x] 3.3 将共享上限接入普通 upload、普通 download 的显式选择与递归 browse，并在任何目录副作用、bytes 传输或 grant 请求前终止超限任务；确认目录仍只计入既有 entries 上限。
- [x] 3.4 在上传源重新 stat 与下载 browse entry 的规划路径中使用服务端大小上限，并把同一规则接入 serve 的显式 `FileList` 入队校验；确认服务端仍是并发变化和非 qtransc 调用方的最终边界。
- [x] 3.5 将相同文件数量和大小预检接入 `upload2`、`download2` 的内部任务构造；确认旧 GUI WebSocket 帧字段和格式不变。

## 4. 编译与交付检查

- [x] 4.1 对修改后的 Go 文件执行 `gofmt`，并在 `qtserver` 模块执行 `go build ./...`，确认 Qtserver 可以编译。
- [x] 4.2 在 `qtransc` 模块执行 `go build ./...`，确认 CLI、serve 和旧 GUI 适配可以编译。
- [x] 4.3 交付时列出需要由维护者人工更新的 Qtserver/qtransc 配置与 API 文档位置；不自动改写 `docs/`。
