## Why

Qtserver 目前允许创建接近 `int64` 上限的单文件上传 session，qtransc 的传输计划又可包含十万普通文件；这些值会放大 chunk 状态、下载进度、内存、文件描述符和磁盘消耗，最终可能使客户端或服务端不可用。需要把单文件大小作为服务端强制边界，并把单任务文件数作为 qtransc 的客户端计划边界，同时保留浏览超限文件的能力。

## What Changes

- 在 Qtserver `[transfer]` 增加严格校验的 `max_file_bytes` 配置，默认值为 `1099511627776`（1 TiB），并通过 capabilities 的 `limits.max_file_bytes` 公布实际生效值。
- **BREAKING**：canonical upload init 对 `file_size` 超过该值返回 HTTP 413 `FILE_TOO_LARGE`，不创建 session、cache 或业务登记；新服务不再接受此前可接受的超大上传。
- **BREAKING**：canonical download grant、small download 和 direct/Nginx download 在发送内容前均拒绝超过该值的普通文件，返回 HTTP 413 `FILE_TOO_LARGE`；已经存在的超大文件仍可由 list 正常枚举及报告其实际大小。
- qtransc 对每一个 upload/download task 在传输前将去重后的普通文件数限制为 10,000；直接 CLI、`serve`、`upload2` 和 `download2` 都使用同一限制。超限任务以本地 planning 错误结束，不创建目录、不传输 bytes，也不申请 download grant。
- qtransc 使用服务端已公布的单文件上限预检；连接未公布该字段的旧服务时回退到 1 TiB。本地发现的超大文件使用稳定 `FILE_TOO_LARGE`，单任务文件数超限使用 `TASK_FILE_LIMIT_EXCEEDED`。服务端错误原因码原样保留，旧 GUI 的 WebSocket 帧格式不变。

## Capabilities

### New Capabilities

- 无。

### Modified Capabilities

- `resumable-upload`：修改 canonical upload init 可接受的 `file_size` 范围及超限错误契约。
- `file-management`：修改 qtransc 传输计划普通文件数上限，并定义超大文件可浏览但不可下载的下载路径行为。
- `service-capability-discovery`：新增单文件大小配置及 capabilities 限制字段，并定义 qtransc 对该限制的预检和旧服务兼容行为。
- `client-error-contract`：为客户端本地大小与任务文件数限制增加稳定原因码和可见错误契约。

## Impact

- Qtserver 将变更 transfer 配置 schema、config validate、capabilities 响应、canonical upload/download handler，以及默认部署配置；Nginx 加速下载仍须经 Qtserver 的授权检查。
- qtransc 将变更普通传输、serve 创建任务及旧 GUI 适配的计划校验和错误映射，不改变 CLI 参数、canonical wire 路径或旧 GUI WebSocket 帧。
- 现有未配置 `max_file_bytes` 的部署通过默认值获得限制；若已有文件超过新限制，它们保持 list 可见，但升级后不能再下载，运维需要在发布前识别这类业务影响。
