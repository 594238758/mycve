## MODIFIED Requirements

### Requirement: init 创建单文件 opaque session

`POST /uploads` SHALL 接受 `object_key`、`file_size` 和可选 `overwrite`，默认 false。file_size SHALL 在 0 到当前 `transfer.max_file_bytes` 之间。客户端 SHALL NOT 提交 session ID、完整 file hash 或 chunk size。服务 SHALL 生成 lowercase UUID v4 `session_id`，客户端 SHALL 将其视为 opaque。

#### Scenario: 目标不存在

- **WHEN** init 请求合法且正式目标不存在
- **THEN** 服务 SHALL 返回 201、`Location` 和 `active`
- **AND** 响应 SHALL 包含 session ID、normalized object key、file size、chunk size/count、`xxh3_128` 和 `layered_xxh3_128_v1`

#### Scenario: 零字节文件

- **WHEN** file_size 为 0
- **THEN** init SHALL 创建 chunk_count 0 的 active session
- **AND** complete SHALL 不要求 finalize chunk

#### Scenario: 文件超过服务端上限

- **WHEN** 已完成鉴权的 init 请求中 `file_size` 大于当前 `transfer.max_file_bytes`
- **THEN** 服务 SHALL 返回 HTTP 413 `FILE_TOO_LARGE`，并包含 `file_size` 和 `max_file_bytes`
- **AND** 服务 SHALL NOT 创建 Redis session、cache 文件或业务登记

#### Scenario: session ID 非法

- **WHEN** path session ID 缺失、过长、不是 lowercase UUID v4 或不存在
- **THEN** 服务 SHALL 统一返回 404 `SESSION_NOT_FOUND`
