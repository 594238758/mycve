## ADDED Requirements

### Requirement: 超大普通文件可浏览但不得传输内容

`transfer.max_file_bytes` 只限制内容上传和下载，不限制 canonical `GET /files/list`。list SHALL 对超过该值的普通文件继续返回实际 `size` 与正常可枚举的 entry 事实，不得因其大小隐藏、改写为 unsupported 或使 list 请求失败。

canonical grant SHALL 在签发前验证 batch 中每个去重普通文件的当前大小；任一文件超过上限时，整个 batch SHALL 返回 HTTP 413 `FILE_TOO_LARGE`，包含超限文件的 `file_size` 和 `max_file_bytes`，且不得签发任何 grant。small 和 direct download（含经 Nginx 加速的 direct path）也 SHALL 在开始成功响应或内部重定向前验证当前普通文件大小；超过上限时 SHALL 返回同一 413 错误而不得发送内容 bytes。

#### Scenario: list 超大文件

- **WHEN** 目录含有大小大于 `transfer.max_file_bytes` 的普通文件
- **THEN** list SHALL 成功返回该 entry 的实际 `size`
- **AND** entry SHALL 不因大小限制被隐藏或标记为 unsupported

#### Scenario: grant batch 含超大文件

- **WHEN** grant batch 中任一显式普通文件的当前大小超过 `transfer.max_file_bytes`
- **THEN** 服务 SHALL 返回 HTTP 413 `FILE_TOO_LARGE`，包含该文件大小和上限
- **AND** 服务 SHALL 不返回该 batch 中任何文件的 grant

#### Scenario: 已签发 grant 后文件变大

- **WHEN** direct download 在发送 headers 前观察到获授权路径当前指向的普通文件超过上限
- **THEN** direct 或 Nginx 加速入口 SHALL 返回 HTTP 413 `FILE_TOO_LARGE`
- **AND** SHALL NOT 开始内容流或内部重定向

## MODIFIED Requirements

### Requirement: qtransc 递归规划在传输前完成并有固定上限

qtransc 的每个 upload/download task SHALL 在传输 bytes 前完成选择展开、路径规范化、映射校验和普通文件去重。最终计划 SHALL 最多包含 10000 个普通文件；该限制同时适用于显式文件、多 source、目录递归、serve 任务以及 upload2/download2 的内部适配。递归规划仍限制 200000 总 entries、128 深度、1024-byte remote path 和 255-byte segment。任一 list 返回 `truncated=true` SHALL 使整个目录任务失败；不得使用前100000项启动部分任务。

超过普通文件上限或其他 planning limit 时，qtransc SHALL 在远端或本地目录创建、内容传输和 download grant 请求前失败。普通文件数超过上限 SHALL 使用 `TASK_FILE_LIMIT_EXCEEDED`；目录不计入 10000 文件数，但继续计入既有总 entries 上限。

#### Scenario: 目录超过服务端list上限

- **WHEN** 规划中的任一list响应`truncated=true`
- **THEN** qtransc SHALL 在传输开始前报“目录超过10万条目，无法启动任务”并失败

#### Scenario: 直接qtransc list被截断

- **WHEN** 用户直接list一个返回truncated的目录
- **THEN** 文本模式 SHALL 一个entry也不显示，只输出错误并非零退出
- **AND** `--json` SHALL 在stdout输出单一JSON error object且不得包含部分entries

#### Scenario: 任务展开超过文件数上限

- **WHEN** upload 或 download 任务去重后包含 10001 个普通文件
- **THEN** qtransc SHALL 以 `TASK_FILE_LIMIT_EXCEEDED` 结束 planning
- **AND** SHALL NOT 创建本地或远端目录、传输 bytes 或申请 download grant

#### Scenario: 超过递归总entries

- **WHEN** 多层目录累计超过200000项
- **THEN** qtransc SHALL 在传输前以planning错误失败
