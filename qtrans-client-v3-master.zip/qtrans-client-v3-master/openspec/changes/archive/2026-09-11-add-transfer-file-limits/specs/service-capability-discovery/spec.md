## ADDED Requirements

### Requirement: 单文件传输上限使用严格的 transfer 配置

Qtserver SHALL 接受 `[transfer].max_file_bytes` 作为上传和下载共同的单文件字节上限。该值 SHALL 为 `1..int64 max` 的整数，缺省值 SHALL 为 `1099511627776`。`config validate` 和启动 SHALL 拒绝零、负数、超过 `int64` 表示范围的值，以及 `max_small_file_bytes` 大于 `max_file_bytes` 的配置。

#### Scenario: 未显式设置单文件上限

- **WHEN** 有效配置省略 `transfer.max_file_bytes`
- **THEN** Qtserver SHALL 使用 `1099511627776` 作为上限

#### Scenario: 单文件上限无效

- **WHEN** 配置中的 `transfer.max_file_bytes` 为零、负数或小于 `max_small_file_bytes`
- **THEN** `config validate` 和启动 SHALL 失败

### Requirement: qtransc 预检单文件传输上限并兼容旧服务

qtransc SHALL 在 upload/download task 的文件规划期间读取 capabilities 的 `limits.max_file_bytes`，并用该值预检上传源文件的实际大小和下载 browse entry 的大小。服务响应不含该字段时，qtransc SHALL 使用 `1099511627776` 作为兼容回退值，而 SHALL NOT 仅因缺少该限制字段判定 API major 不兼容。客户端预检 SHALL 在任何目录创建、内容传输或 download grant 请求前完成；它不替代服务端强制检查。

#### Scenario: 新服务公布较小上限

- **WHEN** capabilities 的 `limits.max_file_bytes` 小于 qtransc 内置回退值
- **THEN** qtransc SHALL 使用服务公布的较小值规划 upload 和 download

#### Scenario: 旧服务未公布该字段

- **WHEN** API v1 capabilities 不含 `limits.max_file_bytes`
- **THEN** qtransc SHALL 使用 1 TiB 回退值继续执行其他兼容的 capability 预检

## MODIFIED Requirements

### Requirement: capabilities 公布协议版本和关键限制

capabilities SHALL 至少公布 list 上限 100000、逻辑路径上限 1024 bytes、segment 上限 255 bytes、grant 上限 1000、chunk size 104857600、当前 `max_file_bytes`，以及 small download 的默认文件数、单文件和总大小限制。`limits.max_file_bytes` SHALL 是当前有效 `[transfer].max_file_bytes` 的正整数。algorithms SHALL 包含 `xxh3_128` 和 `layered_xxh3_128_v1`。

capabilities SHALL 保留 `read`、`download`、`write`、`upload` 和 `file_management` 键。`read` 与 `download` 的 `enabled`/`available` SHALL 均等于 `read_enabled`，表示内容下载是否可用；`write` 与 `upload` 的 `enabled`/`available` SHALL 均等于 `write_enabled`，表示远端 mutation 是否可用；`file_management` 的 `enabled`/`available` SHALL 始终为 true，表示 canonical list 路由可用，而不得被解释为 mutation 已获准。

响应 SHALL 公布 anonymous read/write 可用性。`anonymous.read` SHALL 等于 `anonymous_enabled`，表示无凭据 caller 能否浏览 anonymous 空间；anonymous 内容下载仍同时要求 `anonymous.read=true` 和全局 `download.enabled=true`。`anonymous.write` SHALL 仅在 `anonymous_enabled=true` 且 `write_enabled=true` 时为 true。

#### Scenario: 下载关闭时的 capabilities

- **WHEN** `read_enabled=false`、`write_enabled=false` 且 `anonymous_enabled=true`
- **THEN** `read` 与 `download` SHALL 均为 disabled/unavailable，`write` 与 `upload` SHALL 均为 disabled/unavailable，`file_management` SHALL 为 enabled/available，`anonymous.read` SHALL 为 true，且 `anonymous.write` SHALL 为 false

#### Scenario: qtransc 读取服务契约

- **WHEN** qtransc 查询 capabilities
- **THEN** 它 SHALL 能从响应确定 API major version、所需能力、限制、`max_file_bytes` 和 hash algorithms
- **AND** SHALL NOT 根据 Qtserver 应用版本号猜测兼容性
