## Context

参见 [proposal.md](proposal.md)。当前 canonical upload init 只拒绝负数 `file_size`，fixed 100 MiB chunk 下可建立极大的 session；下载 grant 与 direct download 也没有共同的单文件大小判断。qtransc 的普通传输和旧 GUI 适配分别展开文件计划，现有 100,000 普通文件 planning 上限并不是用户确认的 10,000 文件任务边界。

Qtserver 是单文件 upload/download 服务：`max_download_files` 继续只表示单个 grant 请求最多 1,000 个 object，不承担整项下载任务的计数。qtransc 才拥有一个任务的完整选择、去重和目录展开结果。

## Goals / Non-Goals

**Goals:**

- 用 Qtserver 配置在服务端强制限制任意单个上传和下载文件的大小。
- 使新旧 qtransc 都能在开始传输前尽早发现单文件与单任务文件数超限，并让服务端成为不可绕过的最终边界。
- 保持超限文件的元数据浏览可用，且向调用方返回可自动处理的稳定原因码。
- 让 server、CLI、serve 和旧 GUI 适配共享同一组客户端计划规则。

**Non-Goals:**

- 不把 10,000 个文件的任务限制存入 Qtserver、Redis 或 download grant；服务端不追踪跨 grant 请求的 task 总文件数。
- 不改变 list 的 100,000 entries 上限、递归 planning 的 200,000 entries/128 depth 上限，或为 list 增加分页、排序和“可传输”标志。
- 不新增用户配额、全局 session 数、临时磁盘 reservation、inode 限制或流量并发限制；这些仍是独立的服务容量治理议题。
- 不改变 upload2/download2 面向旧 GUI 的 WebSocket wire frame，也不自动改写人维护的 `docs/`。

## Decisions

### 1. 使用一个服务端 `max_file_bytes` 作为上传与下载的共同硬边界

在 `[transfer]` 增加 `max_file_bytes`，默认 `1099511627776`，接受范围为 `1..int64 max`。配置校验还要求 `max_small_file_bytes <= max_file_bytes`，以免 small download 的既有上限高于共同文件上限。服务将实际值发布为 `limits.max_file_bytes`。

服务端在 canonical init 接受前验证声明的 `file_size`，在 grant、small 和 direct download 实际确认常规文件大小时验证。所有超限分支使用 HTTP 413 `FILE_TOO_LARGE`，并在 JSON 中返回 `file_size` 和 `max_file_bytes`。direct/Nginx download 必须在写入成功 headers 或内部重定向前再次检查；grant 不是 inode 或 size snapshot，所以并发替换/增长仍遵循既有弱一致性，但在每次可观察的授权或开始传输点都会执行限制检查。

备选方案是只在 qtransc 检查或把上限只施加于上传。前者可被其他客户端绕过，后者会让已有超大文件仍消耗下载资源，均不能满足容量边界目标。

### 2. list 保持事实枚举，传输路径单独拒绝

`GET /files/list` 不以大小上限改变普通文件 entry 的 type、status 或 size；超大文件和普通文件同样可见。qtransc 的独立 `list` 也不因条目大小失败。只有 upload/download task 规划和服务端内容路径使用该上限。

不在 list entry 添加 `transferable` 或 `max_file_bytes` 派生字段。该状态会随服务器配置与文件大小竞争变化，而 capabilities 已提供全局阈值，增加 per-entry 字段会扩大 wire contract 和列表负载。

### 3. qtransc 按“最终去重普通文件集合”限制为 10,000

所有 qtransc 发起的 upload/download task 都在本地完成选择展开、路径规范化和去重后，检查普通文件数不超过 10,000。该规则涵盖普通 CLI、serve 创建或执行的任务以及 upload2/download2 的内部适配；目录不计入该数，但仍计入既有递归 entries 上限。超过限制时，不创建远端或本地目录、不开始 bytes 传输，也不申请 grant；任务按已有 planning 失败规则结束。

对显式 `FileList` 已超过 10,000 的 serve 请求，在任务入队前直接拒绝，避免保留无效任务。目录下载等只能在 browse 后得知总数的请求可先创建任务，但必须在任何传输副作用前以 planning failure 终止。

不复用 Qtserver 的 `max_download_files`，也不把 10,000 降为单个 grant 限制：qtransc 会将合法任务分批请求 1,000 个 grant，服务端无需保存跨请求计数。

### 4. 客户端优先使用 capabilities，旧服务回退到协议默认值

qtransc 读取有效 `limits.max_file_bytes` 时以该值预检上传本地 stat 结果和下载 browse size；缺少该字段的 API v1 服务使用内置 1 TiB 回退值。客户端会在文件开始前再次取得实际本地大小，服务端仍负责阻止本地检查与请求之间的竞争或非 qtransc 调用方。

服务器先升级时，新客户端获得部署的实际配置；客户端先升级时也不会允许超过 1 TiB 的本地任务。缺字段不作为 API major 不兼容，避免强制同版本发布。

### 5. 用稳定原因码区分文件大小和任务数量

服务端的 `FILE_TOO_LARGE` 原样由 qtransc 传递。qtransc 在本地发现单文件超限也使用 `FILE_TOO_LARGE`；发现最终普通文件数超过 10,000 时使用 `TASK_FILE_LIMIT_EXCEEDED`。直接 CLI、JSON 输出、serve summary/detail/SSE 遵循现有 client error contract；旧 GUI 仍使用其既有错误帧，不增加字段。

使用一个笼统的 `INVALID_REQUEST` 会令调用方无法区分可通过拆分任务解决的数量问题与必须缩小/调整配置的大小问题，因此不采用。

## Risks / Trade-offs

- [1 TiB 仍对应约 10,486 个 100 MiB chunks，且没有解决磁盘或 session 总量配额] → 本变更消除无界的单文件输入；临时空间 reservation、session 数和 chunk 状态分页作为后续独立容量治理处理。
- [新限制使已存在的超大文件无法下载] → list 保留可见性，413 body 提供阈值；发布前由运维识别并迁移、拆分或临时上调 `max_file_bytes`。
- [客户端和服务端配置不一致] → capabilities 的服务端值优先，服务端在每个入口强制检查，客户端检查只用于提前失败和保护本地资源。
- [文件在 grant 与实际读取间改变] → direct path 在 headers 前重检；其余替换竞争维持现有弱一致性，不能承诺跨文件系统操作的原子 size snapshot。
- [旧服务不会强制新边界] → 新 qtransc 使用 1 TiB 回退值；需要服务端升级才能约束其他或旧客户端。

## Migration Plan

1. 发布含新字段的 Qtserver；现有配置因默认值兼容，运维可在同次部署显式写入 `max_file_bytes`，并确认该值不小于 `max_small_file_bytes`。
2. 先升级 Qtserver 后升级 qtransc，使 qtransc 读取实际 capabilities 值；旧 qtransc 对新的 413 安全失败，但不会提供本地预检。
3. 发布前扫描或告知业务方：大于最终阈值的既有文件仍可 list，但下载会返回 `FILE_TOO_LARGE`。
4. 回滚 qtransc 不改变远端数据或恢复状态；回滚 Qtserver 会取消服务端硬限制，因此只应在确认容量风险可接受时执行。
