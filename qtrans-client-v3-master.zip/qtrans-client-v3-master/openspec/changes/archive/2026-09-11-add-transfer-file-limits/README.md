# add-transfer-file-limits

为 Qtserver 单文件传输和 qtransc 单任务文件数建立可配置、可发现且强制执行的上限
