## ADDED Requirements

### Requirement: qtransc 递归删除提供人类可读的活动状态

未带 `--json` 的 `qtransc delete -r/--recursive` SHALL 在 stderr 提供递归删除的活动状态，且不得等待全部节点完成后才首次输出。状态 SHALL 标识当前是枚举目录还是删除节点，并提供已确认删除的节点数、近期节点速率、已用时间和当前处理的逻辑路径。节点数只计入服务端已成功确认的 delete；客户端 SHALL NOT 为生成总数或百分比而预扫描整棵目录树，也不得展示推测的总数或百分比。

当 stderr 是交互终端时，客户端 SHALL 原位刷新单条状态；当 stderr 不是交互终端时，客户端 SHALL 输出完整的、带换行的状态行，并将连续状态限频至最多每秒一次。两种模式在结束前都 SHALL 完成当前状态行，随后再输出既有成功摘要或错误。该状态仅用于人类观察，SHALL NOT 改变递归删除顺序、已删除节点计数、退出码、错误原因码或重试语义。

`qtransc delete -r/--recursive --json` SHALL 不输出上述人类状态；它的 stdout 继续只包含既有的单一最终 JSON 对象。

#### Scenario: 交互终端中删除大量节点

- **WHEN** 用户在交互终端执行 `qtransc delete -r /tree` 且删除持续进行
- **THEN** stderr SHALL 持续原位展示已确认删除节点数、速率、已用时间和当前逻辑路径
- **AND** 在枚举目录时 SHALL 表示正在扫描该目录
- **AND** stdout SHALL 只保留既有的最终成功摘要

#### Scenario: 重定向 stderr 的递归删除

- **WHEN** 用户执行 `qtransc delete -r /tree 2>delete.log`
- **THEN** `delete.log` SHALL 包含完整的换行状态记录而非终端控制字符
- **AND** 连续状态记录 SHALL 不超过每秒一行

#### Scenario: JSON 递归删除

- **WHEN** 用户执行 `qtransc delete -r --json /tree`
- **THEN** stdout SHALL 只包含既有的单一最终 JSON 对象
- **AND** 客户端 SHALL NOT 输出人类进度状态

## MODIFIED Requirements

### Requirement: qtransc 文件管理CLI使用canonical能力

qtransc SHALL 提供 list、mkdir、move 和 delete 对 canonical API 的调用；create SHALL 只作为 API 能力，本 change SHALL NOT 增加 touch/create CLI。文本输出用于人类，`--json` SHALL 保留服务端结构，包括 symlink 真实 type 和非递归 delete 的 `DIRECTORY_NOT_EMPTY` 错误。`delete --recursive` 的客户端定义 JSON 结果服从递归删除要求。所有文件管理 CLI 错误 SHALL 服从 `client-error-contract` 的稳定 `reason_code` 与人类可读格式。

在未带 `--json` 的成功情况下，`mkdir` SHALL 根据服务端 `created` 事实输出“已创建远端目录：<path>”或“远端目录已存在：<path>”；`move` SHALL 输出“已移动远端路径：<source> -> <destination>”；单节点 `delete` SHALL 输出“已删除远端路径：<path>”。这些中文文本 SHALL 不包含服务端 JSON 字段名或原始 JSON。带 `--json` 的 mkdir、move 和单节点 delete SHALL 继续在 stdout 原样输出服务端成功 JSON。

#### Scenario: 文本list

- **WHEN** 用户执行qtransc list
- **THEN** stdout SHALL 展示人类可读结果，正常symlink按target_type展示

#### Scenario: JSON list

- **WHEN** 用户执行qtransc list --json且请求成功
- **THEN** stdout SHALL 输出单一有效JSON对象并保留entry字段

#### Scenario: 文本mkdir新建目录

- **WHEN** 用户执行未带 `--json` 的 `qtransc mkdir /docs` 且服务端返回 `created=true`
- **THEN** stdout SHALL 输出“已创建远端目录：/docs”

#### Scenario: 文本mkdir已有目录

- **WHEN** 用户执行未带 `--json` 的 `qtransc mkdir /docs` 且服务端返回 `created=false`
- **THEN** stdout SHALL 输出“远端目录已存在：/docs”

#### Scenario: 文本move和delete

- **WHEN** 用户执行未带 `--json` 的 move 或单节点 delete 且请求成功
- **THEN** stdout SHALL 分别输出包含源与目标路径的移动提示或包含目标路径的删除提示
- **AND** stdout SHALL 不输出原始 JSON

#### Scenario: JSON mutation成功

- **WHEN** 用户以 `--json` 执行 mkdir、move 或未带递归标志的 delete 且请求成功
- **THEN** stdout SHALL 原样输出服务端成功 JSON

#### Scenario: delete 非空目录的 JSON 错误

- **WHEN** 用户执行 qtransc delete --json 且服务返回 409 `DIRECTORY_NOT_EMPTY`
- **THEN** qtransc SHALL 以非零状态退出并原样保留服务端结构化错误

#### Scenario: 调用旧CLI命令

- **WHEN** 用户调用`dlist|ulist|umkdir|umove|udelete`
- **THEN** qtransc SHALL 按未知命令失败且 SHALL NOT 保留兼容别名
