## 1. 文件管理成功结果

- [x] 1.1 调整 canonical mutation 的命令层输出：非 JSON 的 mkdir、move 和单节点 delete 渲染规定的中文成功提示，`--json` 与错误 body 保持既有契约；以 `cd qtransc && go build ./...` 成功验证编译。

## 2. 递归删除进度

- [x] 2.1 实现基于 stderr TTY 状态的递归删除观察器，提供扫描/删除状态、确认节点数、近期速率、耗时和当前路径，并在非 TTY 限频为换行记录；以 `cd qtransc && go build ./...` 成功验证编译。
- [x] 2.2 将观察器接入递归 walker、保证 `--json` 不产生人类状态并在成功或失败前完成状态行；复查变更仅影响 qtransc 与本 OpenSpec 变更，并以 `cd qtransc && go build ./...` 成功验证编译。
