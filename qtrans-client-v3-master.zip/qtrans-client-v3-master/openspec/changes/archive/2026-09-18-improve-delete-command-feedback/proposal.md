## Why

`qtransc delete -r` 必须逐节点向 qtserver 发起请求。包含大量小文件的目录会长时间没有可见输出，用户无法区分操作仍在推进、正在枚举目录还是已经卡住。与此同时，普通文件管理命令在非 JSON 模式直接打印服务端 JSON，缺少面向人的动作结果。

## What Changes

- 为非 JSON 的 `mkdir`、`move` 和单节点 `delete` 输出中文、动作明确的成功提示；`mkdir` 区分新建与目录已存在。
- 为非 JSON 的递归 `delete -r/--recursive` 增加持续进度：已确认删除节点数、近期节点速率、已用时间和当前处理路径；枚举目录时显示扫描状态。
- 在交互终端中原位刷新进度，在非交互 stderr 中限频输出独立状态行，避免重定向日志被高频输出淹没。
- 保持 `--json` 的现有 stdout 结构和单一最终结果；不增加服务端递归删除 API，不改变 qtserver 单节点 delete 语义。

## Capabilities

### New Capabilities

- 无。

### Modified Capabilities

- `file-management`: 明确 qtransc 文件管理成功文本输出及客户端递归删除的可观察进度，同时保持 JSON 与服务端 API 兼容。

## Impact

- 影响 `qtransc/cmd/qtransc/cmd_files.go` 及同目录的终端进度辅助代码。
- 不修改 qtserver HTTP API、认证、删除语义或已有 JSON schema；脚本可继续使用 `--json` 获取机器可读结果。
