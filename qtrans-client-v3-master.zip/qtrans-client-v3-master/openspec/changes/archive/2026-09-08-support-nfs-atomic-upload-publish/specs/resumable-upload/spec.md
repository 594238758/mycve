## MODIFIED Requirements

### Requirement: complete 是唯一 cache 发布操作

finalize SHALL NOT 使 cache 对正式空间可见。complete SHALL 创建允许创建的家目录和 parents、应用权限、fsync cache，并以文件系统提供的原子 publish primitive 发布。正式 target 名称原子出现或被原子替换 SHALL 是业务成功点。publish前 chmod/chown/fsync失败 SHALL 不发布；publish后 parent fsync失败 SHALL 记录高等级错误但返回成功，SHALL NOT 回滚。使用 hard link 发布时，删除不可见 cache 名称 SHALL 是提交后的清理步骤，清理失败 SHALL NOT 删除或回滚 target。

#### Scenario: 尚未 complete

- **WHEN** 所有 chunks verified但客户端暂停
- **THEN** 正式 object key SHALL 仍不存在或保持旧文件

#### Scenario: 发布时父目录缺失

- **WHEN** complete进入发布且parents不存在
- **THEN** 服务 MAY mkdir-p并应用 managed policy

#### Scenario: overwrite 期间读取

- **WHEN** complete原子替换已有普通文件
- **THEN** 并发 reader SHALL 看到完整旧 inode或完整新 inode

#### Scenario: hard-link 发布后 cache 清理失败

- **WHEN** target 已原子创建但删除不可见 cache 名称失败
- **THEN** complete SHALL 保留 target 并按已发布事实继续提交
- **AND** cache SHALL 由后续重试、release 或 orphan cleanup 再次清理

### Requirement: no-overwrite 发布必须使用原子 primitive

overwrite=false 的 complete SHALL 使用 Linux `renameat2(RENAME_NOREPLACE)` 或等价的 regular-file 原子 publish primitive。对于同一文件系统上的 verified regular cache，服务 MAY 通过原子 hard link 创建 target，并在提交状态持久化后删除 cache 名称。任一 primitive 都必须在 target 已存在时原子失败且不得修改既有 target；不得以 stat 后 replace rename 替代。平台或文件系统既不支持 atomic no-replace rename也不支持等价 hard-link publish时，SHALL 返回500 `ATOMIC_NOREPLACE_UNSUPPORTED`。

#### Scenario: 发布时目标刚被创建

- **WHEN** no-overwrite complete 与其他 writer竞争且目标已存在
- **THEN** complete SHALL 返回409 conflict
- **AND** SHALL 保留 active session/cache

#### Scenario: rename no-replace 不支持但 hard link 可用

- **WHEN** cache与target位于同一文件系统、atomic no-replace rename返回unsupported且原子hard link可用
- **THEN** complete SHALL 原子创建target并返回正常committed结果

#### Scenario: 两种原子 primitive 均不可用

- **WHEN** atomic no-replace rename和等价hard-link publish均不可用
- **THEN** complete SHALL 返回500 `ATOMIC_NOREPLACE_UNSUPPORTED`
- **AND** target SHALL 保持不存在且session/cache SHALL 保留

#### Scenario: hard link 发布遇到跨文件系统

- **WHEN** cache与target不在同一文件系统且publish返回EXDEV
- **THEN** complete SHALL 返回500 `CROSS_DEVICE_PUBLISH`
- **AND** SHALL NOT复制后删除cache

### Requirement: 正式 hash persistence 不回滚已发布文件

complete SHALL 用 generation CAS 将已知 file hash 写入正式 hash状态。PostgreSQL在publish前故障 SHALL 阻止发布并触发shutdown；publish后写入时才发现连接级故障 SHALL 保留文件、best-effort返回成功并触发shutdown，SHALL NOT 回滚。

#### Scenario: publish后PostgreSQL断开

- **WHEN** 文件已发布但正式hash写入检测到数据库断开
- **THEN** 新文件 SHALL 保持可见
- **AND** Qtserver SHALL 触发fatal graceful shutdown

## ADDED Requirements

### Requirement: complete 使用 publish intent 收敛提交窗口

no-overwrite complete SHALL 在不可逆publish前保存包含target和cache文件身份的publish intent。intent SHALL 只用于幂等协调文件系统事实与session状态，不得被视为NFS、Redis和PostgreSQL之间的分布式事务或fencing token。complete重试 SHALL 比对cache、target和intent：由本session发布的同一文件身份 SHALL 收敛为committed；不同文件身份 SHALL 按目标冲突处理且不得覆盖。

#### Scenario: intent 后、publish 前断电

- **WHEN** publish intent 已保存但target尚未创建时服务断电
- **THEN** complete重试 SHALL 使用保留的cache继续原子发布

#### Scenario: publish 后、committed 前断电

- **WHEN** target已由本session发布但committed状态尚未保存时服务断电
- **THEN** complete重试 SHALL 识别target文件身份并继续写入committed结果
- **AND** SHALL NOT返回target conflict或重新传输文件内容

#### Scenario: intent 存在但target属于其他writer

- **WHEN** complete重试发现target文件身份与intent记录的cache身份不同
- **THEN** complete SHALL 返回409 conflict
- **AND** SHALL NOT修改既有target

## REMOVED Requirements

### Requirement: complete 不使用 publish intent

**Reason**: NFS hard-link publish 与 NFS RPC不确定结果要求服务在Redis session中记录cache文件身份，才能区分自身已发布target与并发writer创建的target。

**Migration**: publish intent是向后兼容的Redis session可选字段，不需要数据库migration；旧session缺失该字段时仍按原有active流程处理。
