## 1. 原子发布基础能力

- [x] 1.1 在 filespace 中增加仅用于 regular cache 的 hard-link no-replace publish primitive，并保持通用 `RenameNoReplace` 不变
- [x] 1.2 统一映射 target exists、cross-device 和 primitive unsupported 错误，保持现有 HTTP reason code

## 2. Canonical upload 提交恢复

- [x] 2.1 为 canonical upload session 增加向后兼容的 publish intent 文件身份字段
- [x] 2.2 在 no-overwrite complete 中持久化 intent、协调 target/cache identity，并幂等完成 filesystem publish
- [x] 2.3 committed 持久化后 best-effort 清理 cache，并使 complete、cancel、release 正确处理发布窗口

## 3. 规格与部署文档

- [x] 3.1 更新 MCD LVS 部署文档，明确 NFS hard-link publish 能力与部署前验证要求
- [x] 3.2 校验 OpenSpec change，并确认 delta spec、design 和实现保持一致

## 4. 验证

- [x] 4.1 格式化 Qtserver Go 代码并执行 `go build ./...`
- [x] 4.2 执行 `git diff --check` 并核对本变更未修改 qtransc、move 或 file create 行为
