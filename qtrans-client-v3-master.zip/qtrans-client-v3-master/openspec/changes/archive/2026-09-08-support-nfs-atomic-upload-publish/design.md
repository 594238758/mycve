## Context

Qtserver 将 verified upload cache 与正式 target 放在同一共享文件系统，并在 complete 中完成唯一一次 namespace publish。当前实现对 no-overwrite 固定调用 `renameat2(RENAME_NOREPLACE)`；测试环境的 NFSv4.2 对该 flag 返回 `EINVAL`，但同一主机的本地文件系统支持它。Nginx 直接按正式路径读取文件，因此不能通过数据库中的逻辑指针替代文件系统 namespace commit。

complete 同时持有 renewable session lock 和 principal namespace lock，但这些 Redis lease 只能协调 Qtserver 实例，不能约束直接访问共享存储的外部 writer，也不能作为 no-overwrite 的正确性边界。

## Goals / Non-Goals

**Goals:**

- 在不支持 `RENAME_NOREPLACE`、但支持跨目录 hard link 的共享文件系统上原子发布新 regular file。
- 保持 target 已存在时绝不覆盖，并使网络错误或进程崩溃后的 complete 重试可识别自身已完成的 publish。
- 保持 overwrite complete 的原子 replace 行为以及现有 HTTP 请求和成功响应。

**Non-Goals:**

- 不将 link/unlink 用作普通 move；该操作要求用户可见 namespace 的单步原子转换。
- 不为 NFS、Redis、PostgreSQL 引入2PC，也不把 Redis lease提升为严格fencing。
- 不在本变更中改变 file create、qtransc 或鉴权行为。

## Decisions

### 1. 为 regular-file publish 建立独立抽象

新增只面向不可见 regular cache 的 no-replace publish primitive，不修改通用 `RenameNoReplace`：

1. no-overwrite regular upload 直接调用 `linkat(cache, target, 0)`；不先rename cache。
2. hard link 成功后，target立即指向完整且已fsync的cache inode；这是文件系统commit点。
3. session committed状态写入后best-effort unlink cache名称；失败交给release或orphan scanner清理。
4. `renameat2(RENAME_NOREPLACE)` 继续只服务于普通move等必须单步移除可见source的操作。

hard link 对已存在的任意target原子返回 `EEXIST`，因此无需依赖 `stat + rename` 的TOCTOU窗口。若 hard link 返回 `EXDEV`，沿用 `CROSS_DEVICE_PUBLISH`；若返回不支持错误，返回 `ATOMIC_NOREPLACE_UNSUPPORTED`。

备选方案 `stat + rename` 被拒绝，因为外部writer不受Redis lock约束。强制overwrite被拒绝，因为会改变数据保护语义。content-addressed blob加PostgreSQL路径指针可提供更强事务模型，但与Nginx直接文件路径架构不兼容且改动过大。

### 2. publish intent 保存在现有 canonical session 中

no-overwrite complete 在文件系统调用前，将可选 intent 写入Redis session：target路径和hard-link策略；session既有的cache路径、session ID、size和hash共同定义cache内容身份。外部 session status 仍保持 `active`，不新增HTTP字段。intent写入失败时不得publish。

complete持锁重读session后按以下规则协调：

- target不存在且cache身份匹配：继续publish；
- cache与target为同一文件身份：说明本session已publish，跳过重复publish并继续hash/session commit；
- target身份不同：返回409，不覆盖；
- hard-link调用返回不确定结果：重新读取cache与target并用同一挂载内的文件身份比对后继续commit。

cancel遇到已产生target的intent时不得按普通active session删除状态；它应保留正式文件并拒绝取消，由complete重试收敛。尚未产生target的intent仍可安全取消并删除cache。

### 3. Redis committed先于cache名称清理，正式fingerprint在清理后写入

hard-link publish 后先持久化 committed session，再unlink cache，最后用清理后的target fingerprint提交已知hash。unlink会改变inode link count和ctime；把正式fingerprint放在清理后计算可避免刚写入的hash索引立即过期。这样在 committed 写入前崩溃时，cache 与 target 仍是同一inode，重试可以无歧义识别。committed 写入后、cache清理前崩溃只会留下额外cache链接；后续complete、GET session或release清理该链接，并以已知file hash刷新最终fingerprint，不重新读取文件内容。

Redis丢失时不承诺恢复session intent；客户端重新init后由既有target和hash收敛，这与当前Redis临时状态边界一致。

### 4. overwrite路径保持现状

overwrite=true 继续使用 `rename(cache, target)`。本变更不扩大到overwrite崩溃窗口，避免改变已批准范围；未来若统一使用intent恢复replace结果，应单独修改契约。

## Risks / Trade-offs

- [NFS export不允许hard link] → 部署探针必须验证跨 `temp_root`/`user_home_root` 的link成功和目标存在时EEXIST；不支持时保持500失败。
- [hard-link commit后短暂存在两个名称] → cache目录不对用户/Nginx暴露，外部正式namespace只观察到target原子出现。
- [committed后cache清理失败导致空间占用] → complete、release和orphan scanner均best-effort清理；清理不得回滚target。
- [NFS RPC响应丢失导致调用结果不确定] → 使用publish intent和文件身份比对，不依据单次syscall返回值推断最终事实。
- [NFS文件身份和缓存一致性依赖挂载语境] → 两个Qtserver必须使用同一export和一致挂载；恢复时在执行节点同时stat cache与target并比较，不跨节点持久化Linux device id。

## Migration Plan

1. 在两个Qtserver节点运行扩展后的filesystem probe，验证hard link publish、EEXIST和普通replace rename。
2. 滚动部署Qtserver；不需要数据库migration、Redis清理或qtransc升级。
3. 使用新object key执行小文件和大文件no-overwrite upload，并在complete阶段停止单节点验证另一节点可重试收敛。
4. 回滚到旧版本不会改变已发布文件；旧版本在该NFS上仍会对新no-overwrite complete返回 `ATOMIC_NOREPLACE_UNSUPPORTED`。
