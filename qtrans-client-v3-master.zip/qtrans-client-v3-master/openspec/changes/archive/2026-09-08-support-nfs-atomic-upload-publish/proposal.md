## Why

当前 Qtserver 对 no-overwrite upload complete 固定调用 `renameat2(RENAME_NOREPLACE)`。MCD 测试环境的 NFSv4.2 共享存储对该调用返回 `EINVAL`，导致文件内容已经全部上传后仍以 `ATOMIC_NOREPLACE_UNSUPPORTED` 发布失败；需要在不降低并发 no-overwrite 语义的前提下支持这类共享文件系统。

## What Changes

- 将 regular-file no-overwrite upload publish 改为使用同文件系统 hard link 原子创建目标名称；`RENAME_NOREPLACE` 继续保留给必须单步移动可见source的操作。
- 将目标名称原子出现定义为文件系统提交点，目标创建后再清理不可见 cache 名称。
- complete 重试必须识别 cache 与 target 指向同一 inode 的“已发布但 session 尚未 committed”状态并幂等收敛。
- overwrite complete 继续使用原子 replace rename，不改变现有覆盖语义。
- hard link 不受支持或 cache/target 跨文件系统时继续返回明确的 500 reason code。
- 普通 `move` 继续要求原子 no-replace rename；本变更不使用 link/unlink 降低其单步原子语义。

非目标：不引入 NFS、Redis、PostgreSQL 之间的分布式事务；不改变 qtransc CLI、Qtserver HTTP 请求结构、上传 chunk 协议或 anonymous 鉴权模型。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `resumable-upload`: 将 no-overwrite complete 从必须依赖 `RENAME_NOREPLACE` 调整为可使用等价的 regular-file 原子 publish primitive，并规定 hard-link 发布的幂等恢复和 cache 清理语义。

## Impact

- 主要代码：`qtserver/internal/filespace`、`qtserver/internal/handlers/canonical_upload_handler.go` 及 canonical upload session 存储模型。
- 外部兼容性：HTTP API 和成功响应保持不变；此前在支持 hard link 但不支持 `RENAME_NOREPLACE` 的文件系统上返回 500 的 no-overwrite complete 将可以成功。
- 部署：`temp_root` 与目标仍必须位于同一文件系统；部署前必须验证跨目录 hard link、原子 `EEXIST` 和普通 rename 能力。
- `move`、file create 和 overwrite upload 的行为不因本变更降低或放宽。
