## Why

`POST /files/move` 和 `POST /files/delete` 当前为并发协调、no-overwrite、目录递归删除和精确 hash 子树失效执行较多检查与 Redis/文件系统操作。在包含大量小文件或部署于 NFS 时，这些保证使请求耗时随已索引 hash 或目录节点数量增长，并可能超过客户端超时；本变更选择更接近传统文件服务器的单次文件系统操作语义，以降低实现复杂度和请求关键路径的不确定性。

## What Changes

- **BREAKING**：move 不再提供 no-overwrite 保证，不再获取 principal namespace lock，也不再探测或要求 `renameat2(RENAME_NOREPLACE)`；服务在完成必要的鉴权、路径和 source/destination 类型校验后使用一次普通 `rename`，由底层文件系统决定 destination 覆盖、类型冲突和并发结果。
- **BREAKING**：delete 不再递归删除目录，只允许删除普通文件、final symlink 和空目录；非空目录返回 409 `DIRECTORY_NOT_EMPTY`，不再出现递归删除导致的 `DELETE_PARTIAL`。
- move 和 delete 不再执行逐路径或逐子树 hash 记录清理，改为对 principal hash namespace generation 做固定次数的代际失效；旧记录保留到 retention/GC，但不得再作为 cache hit 返回，旧 worker 不得提交为当前结果。
- 正式 hash record 和 calculation claim 绑定 Redis incarnation；Redis 重启或故障切换后不沿用 AOF 恢复的旧 hash cache，而是根据正式文件事实重建，避免 AOF `everysec` 回退使旧 generation 再次生效。上传 session 等非 hash 控制状态继续按现行 AOF 规则恢复。
- move 和 delete 不再执行显式 parent directory fsync；成功点是单次 `rename` 或 `remove` syscall 成功返回。服务不额外承诺主机崩溃后的目录项持久性，也不承诺 NFS 故障返回时 mutation 一定未发生。
- mkdir、create、canonical upload complete 继续使用现有 namespace lock、发布、hash CAS 和持久性语义；本变更不放宽路径隔离、根目录保护、symlink 或特殊节点安全边界。
- 本变更取代已实现但尚未归档的 `allow-compatible-move-fallback`：move 不再区分 strict 与 compatible 路径，也不保留 destination 不存在检查。
- API endpoint、请求 JSON 和成功响应保持不变；qtransc 命令保持不变，但必须原样呈现新的稳定错误。服务端与客户端应同步升级，不提供兼容开关或递归删除过渡模式。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `file-management`：将 move 改为普通 rename 的底层覆盖语义，将 delete 限制为单文件、final symlink 或空目录，并移除两者的 namespace lock 和 parent fsync 要求。
- `file-hash-management`：将 move/delete 的精确路径或子树失效改为 principal hash namespace generation 的固定成本代际失效。

## Impact

- 影响 Qtserver 的 move/delete handler、文件系统错误映射、namespace lock 调用和 Redis 正式 hash 状态机。
- move 可能覆盖已存在的兼容 destination；依赖“destination 已存在必定返回 409”的调用方必须调整。这是有数据覆盖风险的有意兼容性破坏。
- delete 非空目录将从递归删除改为稳定 409；依赖服务端递归删除的调用方必须自行调整业务流程，但本项目不在 qtransc 中新增递归删除实现。
- move/delete 请求的应用层文件系统工作量不再随目录节点数增长；底层 NFS RPC、hard mount 重试、服务端空间回收和跨文件系统限制仍可能造成不可预测时延或错误，本变更不承诺固定 wall-clock 上限。
- principal generation 失效会牺牲缓存命中率：一次 move/delete 会使该 principal 的其他正式文件 hash 记录在下次访问时重新验证或计算，以换取固定成本和简单状态模型。
- Redis incarnation 变化会使全部正式 hash cache 和 calculation claim 失效；AOF 仍持久化上传 session 等控制状态，但不再用于跨 Redis 进程复用正式 hash 值。
- 不新增配置、数据库 migration 或第三方依赖。`qtserver/docs/qtserver-apis.md` 和现有排查文档会因契约变化而需要后续人工审核更新，但不在本次自动文档修改范围内。
