## Context

动机见 [proposal.md](./proposal.md)。当前 `FileMoveHandler` 和 `FileDeleteHandler` 的主要非固定成本不来自 rename/unlink 本身，而来自目录 subtree hash index 的分批清理、递归 `ReadDir`/逐节点 `os.Remove`、每节点 hash 失效及 parent fsync。move 还持有可续租 namespace lock，并先尝试 `renameat2(RENAME_NOREPLACE)`；当前未归档变更 `allow-compatible-move-fallback` 又在不支持该 primitive 时增加一次 destination 检查和普通 rename 降级。

正式 hash 状态已经有 principal namespace generation，但它目前只约束 calculation claim；完成态 record 的 cache hit 不比较该 generation。当前 Redis 强制 `appendonly yes`、`appendfsync everysec`，因此已确认的 generation 更新在 Redis 异常退出时仍可能回退约一秒，而文件系统 rename/remove 已经生效。

目标文件空间可能位于本地磁盘、NFSv3 或 NFSv4。NFSv3 和 NFSv4 都提供普通 rename/remove 协议操作，但 Linux `renameat2(RENAME_NOREPLACE)` 能力不能据此推定。hard mount 上的单个元数据 syscall 仍可能因重传或服务端不可用长时间阻塞，并且 Go request context 不能取消已经阻塞在内核中的 syscall。

## Goals / Non-Goals

**Goals:**

- 使一次 move/delete 在 Qtserver 用户态执行固定数量的路径、元数据、Redis 和文件系统操作，不随目录 descendant 或已索引 hash record 数量增长。
- 在不逐 subtree 清理的前提下，保证 mutation 前产生的正式 hash 和旧 worker 不会在 mutation 后被当作当前结果。
- 保留路径隔离、根目录保护、final symlink 语义和对已观察到特殊节点的拒绝。
- 让 NFSv3/NFSv4 只依赖普通 rename/remove，不再依赖 `RENAME_NOREPLACE`。

**Non-Goals:**

- 不保证请求 wall-clock 为常数或小于客户端一分钟超时；单个 NFS syscall 仍可能无限接近挂起。
- 不实现垃圾箱、后台递归删除、异步 job、HTTP 流式进度或 qtransc 客户端递归删除。
- 不为 move 提供 no-overwrite、事务、回滚、跨文件系统复制或 exactly-once 结果。
- 不协调 Qtserver 之外直接修改挂载目录的程序，也不保证相互冲突的 move/delete/create/complete 的先后次序。
- 不改变 create 和 canonical upload publish 对 `RenameNoReplace`、namespace lock、hash CAS 和 fsync 的使用。

## Decisions

### 1. move 保留固定元数据校验，最终只调用普通 rename

handler 继续执行鉴权、logical path 规范化、source `Lstat`、destination parent `Stat`、目录后代关系检查以及 destination `Lstat`。最后一项不再用于 no-overwrite，而只用于拒绝校验时已观察到的 FIFO、socket 或 device；destination 不存在、普通文件、symlink 或目录都继续进入 rename。随后直接调用 `os.Rename`，不再调用 `filespace.RenameNoReplace`，也不再二次检查 destination。

保留这些检查的成本不随 subtree 规模增长，并能维持稳定的 404/409/422 边界。若在检查后发生并发替换，底层 rename 结果优先；这一 TOCTOU 窗口是取消 fencing 后的明确契约，不能再声称特殊节点或 destination 不被并发覆盖的强保证。

普通 rename 的错误至少按以下类别映射：`EXDEV` 为 500 `CROSS_DEVICE_MOVE`；`EEXIST`、`ENOTEMPTY`、`EISDIR` 和 `ENOTDIR` 为 409 `CONFLICT`；权限、I/O 和未知错误沿用通用 500。返回错误在 NFS 上只表示 syscall 的最终返回，不能证明远端 namespace 一定未改变。

备选方案是保留 strict rename 并仅在不支持时降级，即 `allow-compatible-move-fallback` 的现行实现。它仍保留 no-overwrite 检查和两条实现路径，与本次接受“底层覆盖语义”的目标不符，因此不再使用。`RenameNoReplace` 本身不能删除，因为 create/upload publish 仍依赖它。

### 2. delete 使用 `Lstat` 加单节点 `os.Remove`

handler 在完成路径与顶层类型校验后直接调用 `os.Remove`。不调用 `ReadDir`、`RemoveAll`、递归 helper 或 subtree hash 清理。Unix 上该 API 对普通文件/final symlink 执行 unlink 语义，对目录执行 rmdir 语义；非空目录的 `ENOTEMPTY` 或 `EEXIST` 映射为 409 `DIRECTORY_NOT_EMPTY`。其他失败不再返回 `DELETE_PARTIAL`，因为服务不会主动删除任何 descendant。

不预先 `ReadDir` 的原因不是少一次检查本身，而是让“是否为空”与真正移除保持在同一个底层操作上。预检查既增加 NFS RPC，也不能消除检查后新增 child 的竞态。

备选方案包括 `RemoveAll`、垃圾箱 rename 加后台清理、异步 delete job 和 HTTP 流式心跳。前三者仍要承担递归工作、恢复与状态机；流式响应也不能取消卡在 NFS 内核调用中的 syscall。它们均不属于本次快速收敛方案。

### 3. move/delete 不使用 namespace lock，并显式接受冲突结果

删除 `requireNamespaceLock`、续租和 syscall 前 token 检查，只针对 move/delete；mkdir、create、complete 保持不变。这样 move/delete 不会因其他长 mutation 持锁而等待，也不会为一种已经放弃的串行化保证保留复杂分支。

代价是与 create/complete 的竞态也被纳入“底层结果优先”：例如 move 刚移走 target 后，complete 可能又在原 logical path 发布新文件；delete 空目录与并发创建 child 竞争时，remove 可能成功或返回 `DIRECTORY_NOT_EMPTY`。这是数据平面的弱并发契约，不是 bug recovery 机制。

备选方案是保留现有 namespace lock。它本身是固定成本且能减少内部竞态，因此若未来重新要求 no-overwrite 或跨接口顺序保证，应优先恢复这一个协调点，而不是增加更多 `Lstat`。本变更按用户确认的“假定无人同时修改”前提选择移除。

### 4. move/delete 在文件系统操作前只推进一次 principal generation

在全部可能的固定校验之后、普通 rename 或单节点 remove 之前调用一次 `BumpOfficialHashNamespaceGeneration`。推进失败时不执行文件系统 mutation；推进成功后即使文件系统操作失败也不回滚，只产生额外 cache miss。删除现有的 begin/end 双 bump、`InvalidateTree` 和逐 path `Invalidate` 调用，避免不可逆文件系统操作之后还必须完成 Redis 收尾。

一次前置 bump 足够的依据是：

- bump 前的完成态 record 因 `namespace_generation` 不匹配而不能返回；
- bump 前领取的 worker 因 claim generation 不匹配而不能 heartbeat 或提交；
- bump 后、rename/remove 前新建的 record 仍要在每次 lookup 时核对当前 path fingerprint。source 消失时 lookup 先得到 not-found；被覆盖的 destination fingerprint 变化时该 record 重新 pending；
- 目录在新 destination 下的历史 record 全部属于旧 principal generation，不需要枚举 subtree。

这依赖现有 `(ctime_ns, mtime_ns, size)` fingerprint 的信任边界；本变更不额外解决人为恢复完全相同 fingerprint 的外部修改。为了覆盖 move 与 create/complete 并发，所有 record 创建路径和 `CommitKnown` 都要捕获/验证当前 principal generation；generation 已变化时 known hash 提交被拒绝，后续 lookup 从文件事实重建。

备选的第二次后置 bump 能缩小 mutation 窗口，却会在 rename/remove 已成功后重新引入 Redis fatal 收尾，并不能解决 AOF 回退，因此不采用。逐 subtree 清理能维持更高 cache hit，但正是请求耗时随节点数增长的来源。

### 5. 完成态 hash record 同时绑定 namespace generation 和 Redis incarnation

`officialHashLookupScript` 创建或更新 record 时写入 `record_namespace_generation` 和 `redis_incarnation`，cache hit 必须同时比较它们与当前值；不匹配时不得 stale-while-revalidate 返回旧 hash，而是按当前 fingerprint 重建 pending。claim、heartbeat、submit、fail、`BeginKnownMutation` 和 `CommitKnown` 同样携带并验证这两个值。

Qtserver 在 Redis 初始化检查时通过 `INFO server` 读取当前 `run_id`，作为该进程生命周期内的 Redis incarnation。现有 fatal dependency 策略要求 Redis 连接/协议故障触发 Qtserver shutdown；重启后的 Qtserver 会读取新的 run_id。多个 Qtserver 实例连接同一 Redis 时共享同一 run_id，不会互相使 cache 失效。

incarnation 不匹配的旧 pending record 在 claim 扫描或 exact lookup 时按有界方式从 due/expiry index 移除或重建，不在启动或 move/delete 请求内全量扫描。旧 record 可等待 retention/GC 清除。

选择 incarnation 的原因是当前 `appendfsync everysec` 允许 AOF 丢失最后一段 generation bump：若 Redis 恢复旧 generation 与旧完成态 record，它们可能再次匹配。run_id 在每次 Redis 进程启动时变化，使正式 hash cache 在这种恢复后整体失效。备选方案 `appendfsync always` 会把所有 Redis 写入的磁盘同步延迟扩大到上传控制路径；仅信任 everysec AOF 则无法提供规格要求的内部 mutation 后 hash 正确性。

### 6. move/delete 不执行 parent directory fsync

普通 rename 或单节点 remove 成功即返回 200，不再调用 `FsyncDirectory`。这减少固定但可能很慢的 NFS 元数据同步等待，也避免成功 mutation 后的附加失败点。代价是响应只确认运行中文件系统接受了操作，不承诺主机崩溃后的目录项持久性。create 和 upload publish 的现有 fsync 行为不变。

### 7. qtransc 不增加协议或递归行为

endpoint、request JSON 和成功 JSON 不变。qtransc 已有通用 canonical mutation 错误透传路径；实现时只需确认 409 `DIRECTORY_NOT_EMPTY` 在文本模式可读、在 `--json` 模式保留服务端结构，不新增客户端递归遍历，也不通过流式响应延长 HTTP deadline。

## Feasibility Assessment

该方案在“减少随目录规模增长的 Qtserver 工作量”这一目标上可行：move 的关键路径由 subtree hash 清理变为固定次数元数据操作、一次 Redis generation bump 和一次普通 rename；delete 由逐节点递归变为固定次数元数据操作、一次 generation bump 和一次单节点 remove。目录内有一百万个小文件时，Qtserver 不再读取或逐个删除它们，delete 会较快得到 409，而 move 通常只修改目录项。

它不能把 NFS 请求变成时间上界明确的常数操作。hard mount 断网、server stall、metadata lock、目录项更新、空间回收或跨 export 限制仍可能让一次 `Lstat`、`Stat`、rename 或 remove 超过一分钟；客户端超时后服务端 syscall 还可能继续，NFS 返回错误时 mutation 也可能已经发生。因此本方案解决的是当前确定存在的 O(n) 应用层路径，不是所有超时。

移除 namespace lock 在性能上不是必要条件，因为该 lock 自身是固定成本；它是为了按已确认的弱并发模型删掉分支。若“无人并发修改”的部署假设不能被运维约束，建议保留 lock，而仍采用普通 rename、单节点 delete 和 generation 失效。那会稍复杂一点，但不改变目录规模问题的解决效果。

综合结论：方案可实施，且适合作为快速修复；前提是接受三个明确结果——move 可能覆盖 destination、delete 非空目录永远返回 409、NFS 单 syscall 仍可能超时或产生结果不确定。Redis incarnation 校验是保证 AOF everysec 回退后不复活旧 hash 的必要补强，不应从实现中省略。

## Risks / Trade-offs

- [move 覆盖已有普通文件或兼容空目录] → 在 spec 和发布说明中标为 breaking；不提供“先检查再 rename”伪 no-overwrite 保证。
- [取消 namespace lock 后内部 mutation 竞争] → 明确 last-syscall-wins；若部署无法保证低并发，恢复 lock，不改变其余方案。
- [校验后的特殊节点 TOCTOU] → 只保证拒绝校验时观察到的特殊节点；强保证需要 dirfd/fencing 等不同设计。
- [一次 move/delete 使 principal 全量 hash cache 失效] → 接受额外重新计算，换取请求关键路径固定成本；旧记录由 retention/GC 后台处理。
- [Redis incarnation 变化使全部正式 hash cache 失效] → 正式文件是事实源，按需重建；上传 session 等控制状态继续由 AOF 恢复。
- [NFS hard mount syscall 超过客户端 deadline] → 不宣称固定 wall-clock；依靠运维层 NFS 健康、mount 策略和请求幂等判断，客户端不得仅凭 timeout 断言 mutation 未发生。
- [delete 非空目录不再完成用户目标] → 返回稳定 409，不做 partial mutation；大目录清理由 Qtserver 之外的受控流程承担。
- [回滚无法恢复已覆盖或已删除数据] → 部署前通知调用方 breaking 语义，必要时先做数据快照；代码回滚只恢复后续请求行为。

## Migration Plan

1. 先处理已完成但未归档的 `allow-compatible-move-fallback`：若要保留完整 OpenSpec 历史，应先同步并归档该变更，再同步/归档本变更；不得在本变更之后再同步旧 delta，否则会重新引入 no-overwrite 契约。
2. 实现 Redis record/claim 的 namespace generation 与 incarnation 校验，使旧 schema record 自动按 cache miss 处理；不做启动期全量 migration。
3. 实现 move/delete handler 简化并移除它们的 subtree hash 清理、namespace lock 和 parent fsync；保留 create/upload 所需的 `RenameNoReplace` 和 lock 代码。
4. 同步部署 Qtserver 与 qtransc 使用方，并明确通知 move overwrite 与 delete 409 两项 breaking 行为；不增加配置开关。
5. 编译检查 Qtserver 和 qtransc。在目标本地盘、NFSv3、NFSv4 环境由人工验证普通文件、final symlink、空目录、非空目录、destination overwrite、跨文件系统和 Redis 重启后的 hash miss。
6. 回滚时恢复旧 handler 与旧 spec；已发生的 destination 覆盖和成功删除无法由软件回滚恢复。
