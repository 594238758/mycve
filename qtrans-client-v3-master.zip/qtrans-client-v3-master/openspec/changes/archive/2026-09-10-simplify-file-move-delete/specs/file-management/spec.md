## ADDED Requirements

### Requirement: move 使用普通 rename 和底层覆盖语义

move SHALL 将 source 移动到 exact destination，SHALL NOT 把 destination 解释为目录容器，也 SHALL NOT 自动创建 destination parent。服务 SHALL 在固定数量的路径、权限和节点类型校验后直接尝试普通 rename；destination 已存在时是否可替换 SHALL 由底层文件系统的 rename 语义决定，服务 SHALL NOT 提供 no-overwrite 保证。source==destination 和目录移入自身后代 SHALL 返回 409；final source symlink SHALL 移动链接本身；校验时观察到的特殊 source 或特殊 destination SHALL 返回 422。跨文件系统 SHALL 返回 500 `CROSS_DEVICE_MOVE`，服务 SHALL NOT 复制后删除 source。

#### Scenario: destination 不存在

- **WHEN** source 存在、destination parent 存在且 destination 不存在
- **THEN** move SHALL 尝试一次普通 rename 并在成功时返回 200

#### Scenario: destination 是可替换节点

- **WHEN** destination 已存在且底层文件系统允许普通 rename 替换该节点
- **THEN** move SHALL 替换 destination 并返回 200
- **AND** 服务 SHALL NOT 因 destination 在校验时已存在而预先返回冲突

#### Scenario: destination 不能被底层 rename 替换

- **WHEN** 普通 rename 因节点类型冲突或 destination 是非空目录而拒绝替换
- **THEN** move SHALL 返回 409 `CONFLICT`
- **AND** 服务 SHALL NOT 递归清空 destination

#### Scenario: 跨文件系统

- **WHEN** rename 返回 EXDEV
- **THEN** move SHALL 返回 500 `CROSS_DEVICE_MOVE`
- **AND** SHALL NOT 复制后删除 source

#### Scenario: 并发修改 move 路径

- **WHEN** 其他操作在 move 校验和 rename 之间修改 source、destination 或 parent
- **THEN** move SHALL 以该次普通 rename 的实际结果作为响应依据
- **AND** 服务 SHALL NOT 承诺 no-overwrite、先到者优先或自动重试

### Requirement: delete 只删除单个文件、final symlink 或空目录

delete SHALL 只删除请求 path 对应的单个普通文件、final symlink 或空目录，SHALL NOT 递归遍历或删除任何 descendant。顶层不存在 SHALL 返回 404；特殊节点 SHALL 返回 422 `UNSUPPORTED_FILE_TYPE`；目录在实际移除时非空 SHALL 返回 409 `DIRECTORY_NOT_EMPTY`。服务 SHALL NOT 为判断目录是否为空而预扫描目录内容，目录是否为空 SHALL 由底层单节点移除操作判定。

#### Scenario: 删除普通文件

- **WHEN** target 是普通文件且底层文件系统允许移除
- **THEN** delete SHALL 只移除该节点并返回 200

#### Scenario: 删除 final symlink

- **WHEN** target 是有效、broken 或 loop final symlink
- **THEN** delete SHALL 移除链接本身并返回 200
- **AND** SHALL NOT 跟随或删除链接目标

#### Scenario: 删除空目录

- **WHEN** target 是在实际移除时仍为空的普通目录
- **THEN** delete SHALL 移除该目录并返回 200

#### Scenario: 删除非空目录

- **WHEN** target 目录在实际移除时包含至少一个 descendant
- **THEN** delete SHALL 返回 409 `DIRECTORY_NOT_EMPTY`
- **AND** 目录和全部 descendants SHALL 保持未被本次请求删除

#### Scenario: 空目录校验后出现新子项

- **WHEN** 其他操作在 delete 校验和实际移除之间向目录加入子项
- **THEN** 底层单节点移除 SHALL 失败且 delete SHALL 返回 409 `DIRECTORY_NOT_EMPTY`
- **AND** 服务 SHALL NOT 再次遍历或递归删除该目录

### Requirement: 特殊节点只允许安全枚举

FIFO、socket 和 device MAY 由 list 报告。直接 download、overwrite、move 或 delete 特殊节点 SHALL 返回 422 `UNSUPPORTED_FILE_TYPE`；文件管理 mutation SHALL NOT 打开、跟随或递归删除特殊节点。

#### Scenario: 直接删除 FIFO

- **WHEN** delete 的顶层 path 是 FIFO
- **THEN** 服务 SHALL 返回 422 且不删除该节点

#### Scenario: move 覆盖已观察到的特殊节点

- **WHEN** move 校验时发现 source 或 destination 是特殊节点
- **THEN** 服务 SHALL 返回 422 且不得尝试 rename

## MODIFIED Requirements

### Requirement: JSON与错误响应遵循统一基线

文件管理 POST SHALL 使用严格 `application/json`、2MiB body 上限、未知字段拒绝和单 JSON value 规则。错误 JSON SHALL 包含 HTTP status code、稳定 `reason_code`、human-readable `message` 和适用 typed extras，SHALL NOT 新增 request ID。鉴权 SHALL 先于 body 与 path 校验。delete 非空目录 SHALL 使用 409 `DIRECTORY_NOT_EMPTY`，且 SHALL NOT 返回 `partial=true` 或 `failed_path`。

#### Scenario: 未认证请求含坏路径

- **WHEN** write 请求既未认证又包含非法 logical path
- **THEN** 服务 SHALL 先返回认证错误

#### Scenario: delete 非空目录

- **WHEN** delete 的 target 在实际移除时是非空目录
- **THEN** error body SHALL 包含 `reason_code=DIRECTORY_NOT_EMPTY`
- **AND** SHALL NOT 包含递归删除专用的 `partial=true` 或 `failed_path`

### Requirement: 文件系统mutation以不可逆syscall为业务成功点

create SHALL 在发布 rename 之前完成必须成功的 chmod、chown 和相关 fsync；发布后的 parent directory fsync 失败 SHALL 记录高等级错误但业务返回成功，SHALL NOT 回滚已完成 mutation。move 和 delete SHALL NOT 显式 fsync parent directory；普通 rename 或单节点移除操作成功返回即为业务成功点。服务 SHALL NOT 因 move/delete 已返回成功而额外承诺主机崩溃后的目录项持久性。

#### Scenario: move rename 成功

- **WHEN** move 的普通 rename 成功返回
- **THEN** move SHALL 返回成功且不得为 parent fsync 延迟响应

#### Scenario: delete 单节点移除成功

- **WHEN** delete 的单节点移除操作成功返回
- **THEN** delete SHALL 返回成功且不得为 parent fsync 延迟响应

#### Scenario: create 发布后 parent fsync 失败

- **WHEN** create 已成功发布 target 但 parent fsync 失败
- **THEN** create SHALL 返回成功且不得删除已发布 target

### Requirement: namespace mutation使用advisory renewable lock

mkdir、create 和 complete SHALL 使用 principal namespace lock，lease 30 秒且每 10 秒续租。此类操作的 lock 冲突 SHALL 返回 409 `NAMESPACE_BUSY` 和 `Retry-After: 1`；不可逆操作前 SHALL 检查 token，未修改即丢失返回 409 `NAMESPACE_LOCK_LOST`。move 和 delete SHALL NOT 获取、续租、等待或检查 principal namespace lock；它们与其他 mutation 并发时仅服从各自底层文件系统操作的实际结果，服务 SHALL NOT 提供跨操作串行化保证。该 lock SHALL NOT 宣称严格 fencing。

#### Scenario: mkdir 遇到 lock 冲突

- **WHEN** 同 principal namespace lock 已被另一 mutation 占用
- **THEN** mkdir SHALL 返回 409 `NAMESPACE_BUSY`

#### Scenario: move 在 namespace lock 被占用时到达

- **WHEN** 同 principal namespace lock 已被 mkdir、create 或 complete 占用
- **THEN** move SHALL 不等待该 lock，并继续执行自身固定校验和普通 rename

#### Scenario: delete 在 namespace lock 被占用时到达

- **WHEN** 同 principal namespace lock 已被 mkdir、create 或 complete 占用
- **THEN** delete SHALL 不等待该 lock，并继续执行自身固定校验和单节点移除

### Requirement: qtransc 文件管理CLI使用canonical能力

qtransc SHALL 提供 list、mkdir、move 和 delete 对 canonical API 的调用；create SHALL 只作为 API 能力，本 change SHALL NOT 增加 touch/create CLI。文本输出用于人类，`--json` SHALL 保留服务端结构，包括 symlink 真实 type 和 delete 的 `DIRECTORY_NOT_EMPTY` 错误。

#### Scenario: 文本 list

- **WHEN** 用户执行 qtransc list
- **THEN** stdout SHALL 展示人类可读结果，正常 symlink 按 target_type 展示

#### Scenario: JSON list

- **WHEN** 用户执行 qtransc list --json 且请求成功
- **THEN** stdout SHALL 输出单一有效 JSON 对象并保留 entry 字段

#### Scenario: delete 非空目录的 JSON 错误

- **WHEN** 用户执行 qtransc delete --json 且服务返回 409 `DIRECTORY_NOT_EMPTY`
- **THEN** qtransc SHALL 以非零状态退出并原样保留服务端结构化错误

#### Scenario: 调用旧 CLI 命令

- **WHEN** 用户调用 `dlist|ulist|umkdir|umove|udelete`
- **THEN** qtransc SHALL 按未知命令失败且 SHALL NOT 保留兼容别名

## REMOVED Requirements

### Requirement: 特殊节点只允许安全枚举和递归unlink

**Reason**: delete 不再递归进入目录，因此不再存在递归过程中 unlink 特殊节点的行为。

**Migration**: 使用新的“特殊节点只允许安全枚举”要求；需要移除特殊节点时由受控的系统管理操作在 Qtserver 之外完成。

### Requirement: move 使用精确destination和原子no-replace rename

**Reason**: move 改为普通 rename，并有意移除 destination 不存在和原子 no-overwrite 保证。

**Migration**: 调用方在不能接受覆盖时必须自行避免提交冲突 destination；Qtserver 不再提供防覆盖协议或兼容开关。

### Requirement: delete 使用Linux递归删除语义

**Reason**: 递归删除的耗时和 partial failure 随目录规模增长，无法满足本变更要求的固定规模请求关键路径。

**Migration**: 调用方只能请求删除普通文件、final symlink 或空目录；非空目录必须由 Qtserver 之外的显式流程处理。
