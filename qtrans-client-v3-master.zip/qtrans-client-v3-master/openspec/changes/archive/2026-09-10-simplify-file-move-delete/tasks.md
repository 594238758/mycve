## 1. 正式 hash 代际与 Redis incarnation

- [x] 1.1 在 Redis 初始化阶段读取并保存当前 `INFO server` run_id，作为正式 hash record 和 claim 使用的 Redis incarnation，且不改变上传 session 的 AOF 恢复路径。
- [x] 1.2 扩展正式 hash lookup/record 状态，使完成态 hash 同时记录并校验 principal `namespace_generation` 和 Redis incarnation；旧 schema 或不匹配记录必须按 cache miss 重建，不得作为 stale 值返回。
- [x] 1.3 扩展 pending claim、heartbeat、submit 和 fail 的原子脚本及 Go 数据结构，使它们同时验证 object generation、principal generation 和 Redis incarnation，并有界清理 incarnation 过时的 pending 索引项。
- [x] 1.4 扩展 `BeginKnownMutation`/`CommitKnown` 路径，使 create 和 canonical upload complete 写入的 known hash 捕获并校验 principal generation 与 Redis incarnation，generation 已被并发 move/delete 推进时拒绝旧提交。

## 2. move 固定成本实现

- [x] 2.1 调整 `FileMoveHandler` 的固定校验：保留路径、source、parent、目录后代和特殊 source/destination 检查，但删除 destination 不存在要求、namespace lock、二次 destination 检查及 strict/compatible 分支。
- [x] 2.2 在 move 的不可逆操作前推进一次 principal hash namespace generation，删除 source/destination `InvalidateTree` 和后置 hash fence，并直接使用普通 `os.Rename`。
- [x] 2.3 完成普通 rename 的稳定错误映射，覆盖 `CROSS_DEVICE_MOVE`、类型/非空目录冲突和通用失败，并移除 move 成功后的 parent directory fsync。

## 3. delete 单节点实现

- [x] 3.1 调整 `FileDeleteHandler`，保留路径和顶层节点类型检查，删除 namespace lock、递归 hash fence和 `deleteTree` 调用。
- [x] 3.2 在 delete 的不可逆操作前推进一次 principal hash namespace generation，随后只调用单节点 `os.Remove`，不执行 `ReadDir`、递归遍历、逐 path hash 失效或 parent directory fsync。
- [x] 3.3 将非空目录的 `ENOTEMPTY`/`EEXIST` 映射为 409 `DIRECTORY_NOT_EMPTY`，删除 `DELETE_PARTIAL` 响应路径，并保持普通文件、final symlink、空目录、not-found 和特殊节点契约。

## 4. 客户端与范围收敛

- [x] 4.1 核对 qtransc canonical mutation 的文本和 `--json` 错误路径，确保 409 `DIRECTORY_NOT_EMPTY` 以非零退出状态呈现并保留服务端结构；仅在现有通用路径不满足规格时修改客户端。
- [x] 4.2 确认 create、mkdir 和 canonical upload complete 仍使用原有 namespace lock，且 create/upload publish 仍使用 `RenameNoReplace`、hash CAS 和现有 fsync 语义。

## 5. 编译验证

- [x] 5.1 对修改的 Go 文件执行格式化，并编译检查 Qtserver。
- [x] 5.2 编译检查 qtransc，确认共享 API/error 变更未造成编译回归；不新增或运行 test/benchmark。
