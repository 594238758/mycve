## Why

Qtserver 当前从第一条业务事件开始就创建带时间戳的分段文件，并通过硬链接暴露 `business_events.log`，导致 active 文件名、归档文件名和文件生命周期不符合常规日志采集认知。需要改为固定的 `business-events.jsonl` active 文件，仅在达到既有大小阈值时生成归档，便于运维、采集与人工排查。

## What Changes

- **BREAKING**：Qtserver schema v1 业务日志的 active 文件从 `log.file_path/business_events.log` 更名为 `log.file_path/business-events.jsonl`；日志采集配置需要同步更新。
- active 文件本身作为唯一写入目标；首次写入、正常关闭和重启均不创建带时间戳的归档，也不再通过硬链接维持 active 名称。
- 复用现有 `[log.rotation]` 配置，不增加配置字段：仅在 `enable=true` 且 active 文件达到 `max_size` 时按大小轮转；`max_age` 只用于历史归档保留期清理，不是按时间轮转条件；`max_backups` 和 `compress` 继续约束已关闭归档。
- 轮转后，已关闭文件命名为 `business-events-<UTC timestamp>-<sequence>.jsonl`，启用压缩时再生成相应 `.gz`；新的写入继续进入 `business-events.jsonl`。
- 正常关闭保留 active 文件，重启时修复不完整尾行后继续追加，不因进程生命周期触发轮转。
- 为旧版 `business_events.log` 及其硬链接分段提供一次性、安全迁移；若新旧 active 文件同时存在且无法无歧义处理，启动 SHALL 失败并暴露日志不可用状态，而不是猜测合并或覆盖。
- 更新 Qtserver 业务日志说明和本地端到端验证，使文档与实际 active/归档文件生命周期一致。
- 非目标：不改变七类事件的 JSON schema、事件产生时机、HTTP/CLI 接口、Nginx `download_events.log`，也不新增按时间轮转。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `raw-business-event-log`：修改 Qtserver 原始业务事件 active 文件名、大小轮转、归档、重启续写和旧文件迁移契约。

## Impact

- 代码：`qtserver/internal/businessevents` writer、初始化/恢复路径及相关测试。
- 配置：继续复用 `qtserver_config.log.rotation`；配置结构和字段含义不变，`max_age` 仍只表示归档保留天数。
- 运维：采集器和排障命令需从 `business_events.log` 切换为 `business-events.jsonl`，并继续识别 `business-events-*.jsonl[.gz]` 归档。
- 文档与验证：更新 Qtserver 配置/部署说明、服务端业务日志简明文档及本地 E2E 脚本。
- API 与依赖：无 HTTP、CLI、事件 schema 或第三方依赖变更。
