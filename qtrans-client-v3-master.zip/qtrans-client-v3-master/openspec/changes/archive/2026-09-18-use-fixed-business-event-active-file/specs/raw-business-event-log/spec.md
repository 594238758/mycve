## MODIFIED Requirements

### Requirement: 原始业务事件和调试日志相互隔离

Qtserver SHALL 将 schema v1 原始业务事件以 UTF-8 JSON Lines 写入独立 `business-events.jsonl`；Nginx SHALL 将普通下载完成事件以 JSON Lines 写入独立 `download_events.log`。`qtserver.log`、`gin.log`、Nginx `access.log`/`error.log`、stdout/stderr 和 qtransc 本地日志 SHALL 属于调试或运行日志，SHALL NOT 作为业务分析输入。

只有完成业务准入、获得可信 principal 与规范路径并实际进入文件传输流程的请求才能产生原始业务事件。未认证、非法参数、非法路径、扫描请求及业务准入前失败 SHALL 只进入访问、安全或调试日志。

#### Scenario: 调试级别改变

- **WHEN** 运维关闭 debug 日志或提高日志级别
- **THEN** 原始业务事件 SHALL 继续按相同契约输出
- **AND** 分析结果 SHALL 不受调试级别影响

#### Scenario: 非法请求

- **WHEN** 请求在形成合法文件活动前因认证、参数或路径校验失败
- **THEN** Qtserver SHALL NOT 为它输出原始业务事件

### Requirement: 原始事件写入、轮转和凭据边界明确

Qtserver active 文件 SHALL 固定为 `log.file_path/business-events.jsonl`；Nginx active 文件 SHALL 固定为 `/opt/qtrans/nginx/logs/download_events.log`。每个事件 SHALL 完整占一行并以换行结束；压缩 SHALL 只处理已经关闭的轮转段。Active 文件末尾未换行内容 SHALL 留待下次采集，关闭段中的不完整行 SHALL 被隔离。

Qtserver SHALL 复用既有 `[log.rotation]` 配置，不增加业务日志专用轮转配置。仅当 `log.rotation.enable=true` 且 active 文件已有内容、追加下一条完整事件将使文件超过 `log.rotation.max_size` 时，Qtserver SHALL 在追加前按大小轮转；任何运行时长、自然日、固定时刻、进程关闭或进程重启 SHALL NOT 触发轮转。`log.rotation.max_age` SHALL 只控制已关闭归档的保留期清理，SHALL NOT 作为时间轮转周期。`log.rotation.max_backups` SHALL 限制已关闭归档数量，`log.rotation.compress` SHALL 只决定已关闭归档是否压缩。`log.rotation.enable=false` 时，Qtserver SHALL 持续追加同一个 active 文件且 SHALL NOT 因文件大小或时间生成新归档。

轮转前，所有事件 SHALL 只写入 `business-events.jsonl`，且目录中 SHALL NOT 为当前 active 内容预先创建带时间戳的归档或硬链接别名。一次成功轮转 SHALL 将刚关闭的 active 文件保存为不覆盖已有文件的 `business-events-<UTC timestamp>-<sequence>.jsonl`，并立即以 `business-events.jsonl` 创建新的 active 文件；启用压缩时 MAY 将刚关闭的归档转换为同名 `.jsonl.gz`。正常关闭 SHALL sync并关闭 active 文件但保留其固定路径；下一次启动 SHALL 修复最后一个完整换行之后的不完整尾部并继续追加，SHALL NOT 仅因关闭或重启把它改名、压缩或归档。

升级时，若新的 `business-events.jsonl` 不存在而旧版 `business_events.log` 存在，Qtserver SHALL 在继续写入前无损迁移旧 active 内容到新固定路径。若旧 active 与一个旧式 `business-events-*.jsonl` 是同一文件的硬链接，迁移后 SHALL 只保留新 active 路径承载该内容，SHALL NOT 将同一内容同时暴露为 active 和已关闭归档。若新旧 active 路径同时存在，或旧式文件关系无法无歧义判定，Qtserver SHALL NOT 合并、覆盖或删除任一文件，且 SHALL 进入日志不可用状态。旧版已经关闭且不与旧 active 同文件的归档 SHALL 保持关闭状态，并继续受归档保留策略管理。

Qtserver writer SHALL 串行append完整行，并在`file.registered`、`upload.finished`、整文件matched的`download.verify_finished`以及`download.small_file_sent`上完成sync后才报告事件持久成功。处于logging-unhealthy时Qtserver SHALL 拒绝所有下一步会产生schema v1事件的传输或校验API，而不只是新文件起点；不产业务事件的健康、恢复和查询操作 MAY 继续。Writer或健康组件 SHALL 能在不写伪业务事件且不依赖事件生产API越过gate的情况下独立执行reopen与文件级sync/状态探测；成功后 SHALL 先清除gate，再恢复事件生产API。恢复流程 SHALL NOT 因业务请求被gate拒绝而自锁。

Writer SHALL 在每次append前记录受同一串行锁保护的active文件边界。完整行已经写入但sync失败时 SHALL 只重试sync，不得再次append；partial write后只有成功truncate并sync回写前边界时才 MAY 重试append。无法确认边界、truncate失败或无法验证最后完整换行时 SHALL 保持logging-unhealthy，不得盲目重写。独立恢复流程 MAY 截断active文件最后一个完整换行之后的不完整尾部并完成sync；SHALL NOT 改写已经关闭的segment。轮转 SHALL 与append使用同一串行边界。上述规则 SHALL 防止producer把一次chunk事实自身重复写成多个真实attempt。

`file.registered`写入或sync失败 SHALL 在业务动作前返回稳定、可重试的日志不可用错误。Qtserver过程事件在请求业务事实已经发生后写失败 SHALL NOT 回滚已经接收、写入或校验的数据，当前请求 SHALL 返回其真实业务结果，同时 SHALL 进入logging-unhealthy并gate后续事件生产API。Producer SHALL NOT 为促使重试而把已经成功接受的PATCH伪装成业务失败。

真实committed、already-present或整文件verify matched发生后，Qtserver SHALL 在对应终态事件append并sync成功前不向客户端返回成功。写入失败 SHALL NOT 回滚真实文件或hash一致事实，但当前请求 SHALL 返回可重试的日志不可用错误；客户端以后对同一幂等API重试时，Qtserver SHALL 能再次输出内容一致的成功事件并在持久成功后返回业务成功。分析程序 SHALL 使用最早合法成功事实，不要求event ID。

Direct下载响应完成后写chunk事件失败 SHALL NOT 回滚响应，但 SHALL 使Qtserver logging-unhealthy并接受本次统计事实缺失。Small文件entry结束后 SHALL append并sync其成功事件再开始下一个entry；写入或sync失败 SHALL 停止继续生成该批次的后续文件响应、使Qtserver logging-unhealthy且不得撤回当前entry，第一版接受当前文件成功事实缺失。Nginx access-log phase写入失败 SHALL 通过Nginx error log与采集监控暴露，已发送响应不得回滚；第一版 SHALL NOT 要求Nginx反向修改Qtserver健康状态。

原始事件 SHALL NOT 包含 Authorization、access/refresh token、download grant、HMAC secret、anonymous fixed token、TLS key、请求 body或其他 credential。客户端 metadata SHALL 只用作日志上下文，服务端权威身份、IP、路径、大小、hash与发布结果 SHALL 使用已验证事实。

#### Scenario: 首次写入只创建固定 active 文件

- **WHEN** Qtserver 在空日志目录中写入第一条业务事件
- **THEN** 该事件 SHALL 写入 `business-events.jsonl`
- **AND** 目录中 SHALL NOT 因首次写入出现 `business-events-<UTC timestamp>-<sequence>.jsonl` 归档

#### Scenario: 达到大小阈值后轮转

- **WHEN** `log.rotation.enable=true` 且向非空 active 文件追加下一条完整事件将超过 `log.rotation.max_size`
- **THEN** 当前 active 内容 SHALL 先成为唯一的 `business-events-<UTC timestamp>-<sequence>.jsonl[.gz]` 归档
- **AND** 下一条事件 SHALL 写入新的 `business-events.jsonl`

#### Scenario: 保留期不是轮转周期

- **WHEN** `business-events.jsonl` 的存在时间超过 `log.rotation.max_age` 但没有达到大小轮转条件
- **THEN** Qtserver SHALL 继续向同一个 active 文件追加
- **AND** SHALL NOT 因经过该时间而创建归档

#### Scenario: 关闭并重启不轮转

- **WHEN** Qtserver 正常关闭后再次启动且 active 文件没有损坏
- **THEN** `business-events.jsonl` SHALL 保持 active 并继续追加
- **AND** 关闭或重启 SHALL NOT 单独产生新的归档

#### Scenario: 禁用轮转

- **WHEN** `log.rotation.enable=false` 且 active 文件超过 `log.rotation.max_size`
- **THEN** Qtserver SHALL 继续向 `business-events.jsonl` 追加
- **AND** SHALL NOT 生成新的业务事件归档

#### Scenario: 迁移旧式硬链接 active

- **WHEN** 新 active 不存在，且 `business_events.log` 与一个旧式未压缩时间戳文件指向同一文件
- **THEN** Qtserver SHALL 将其内容迁移为唯一的 `business-events.jsonl` active 文件
- **AND** SHALL NOT 将同一内容同时保留为时间戳归档

#### Scenario: 新旧 active 冲突

- **WHEN** `business-events.jsonl` 与 `business_events.log` 同时存在
- **THEN** Qtserver SHALL NOT 猜测、合并、覆盖或删除其中任一文件
- **AND** SHALL 报告日志不可用且拒绝事件生产API

#### Scenario: commit 后日志写入失败

- **WHEN** 文件已原子发布但 `upload.finished` 无法写入
- **THEN** Qtserver SHALL NOT 回滚已发布文件
- **AND** 当前complete请求 SHALL 返回可重试的日志不可用错误
- **AND** SHALL 进入logging-unhealthy并拒绝后续事件生产API

#### Scenario: writer恢复后重试已提交文件

- **WHEN** writer恢复后客户端重试一个文件已经committed但终态日志曾失败的complete请求
- **THEN** Qtserver SHALL 再次构造内容一致的`upload.finished{result=committed}`并可靠写入
- **AND** 写入成功后 SHALL 返回业务成功

#### Scenario: 过程事件写入失败

- **WHEN** 上传chunk数据已经被接受但对应`upload.chunk_finished`最终无法写入
- **THEN** Qtserver SHALL NOT 回滚或伪造未接收该数据
- **AND** 当前PATCH SHALL 返回已经接受数据的真实业务结果
- **AND** SHALL 进入logging-unhealthy并拒绝后续事件生产API

#### Scenario: 完整行写入后sync失败

- **WHEN** writer已确认当前chunk事件完整行存在但后续sync失败
- **THEN** writer SHALL 只重试sync且不得再次append该事件
- **AND** 分析结果 SHALL NOT 因writer恢复产生虚假的额外attempt

#### Scenario: partial write无法安全回滚

- **WHEN** writer发生partial write且无法truncate并sync回写前边界
- **THEN** SHALL 保持logging-unhealthy且不得盲目重写该行
- **AND** 独立恢复流程 SHALL 只清除active文件最后完整换行之后的不完整尾部

#### Scenario: small事件写入失败

- **WHEN** 当前small tar entry已经结束但`download.small_file_sent`无法写入
- **THEN** Qtserver SHALL NOT 撤回已经写出的entry
- **AND** SHALL 停止继续写该批次后续文件并进入logging-unhealthy

#### Scenario: small事件sync成功后继续批次

- **WHEN** 当前small tar entry结束且其`download.small_file_sent`已经append并sync成功
- **THEN** Qtserver MAY 开始写下一个文件entry
- **AND** 后续entry失败 SHALL NOT 撤回当前文件成功事实

#### Scenario: 内部 handoff header

- **WHEN** Nginx 返回一个普通下载响应
- **THEN** 所有 qtserver 提供的日志 handoff header SHALL 对客户端隐藏
