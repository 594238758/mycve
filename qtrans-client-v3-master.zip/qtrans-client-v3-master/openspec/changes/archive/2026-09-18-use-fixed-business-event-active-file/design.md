## Context

参见 [proposal.md](proposal.md) 的 Why。当前 writer 在启动时先创建 `business-events-<timestamp>-<sequence>.jsonl`，再用 `business_events.log` 硬链接到同一 inode；轮转或关闭时删除该链接并完成归档。因此“当前文件”从诞生起就具有归档名，且正常重启也会生成新分段。

现有 writer 还承担完整行串行写入、可选 sync、partial write 回滚、尾部修复、logging-unhealthy gate、压缩与归档清理，这些可靠性边界必须保留。`qtserver_config.log.rotation` 已被普通日志和业务日志共同读取，其中 `max_size` 是大小阈值，`max_age` 是归档保留天数。

## Goals / Non-Goals

**Goals:**

- 让 `business-events.jsonl` 成为真实、唯一且长期稳定的 active 文件，而不是指向预创建归档的别名。
- 只在大小阈值触发时更换 active inode，并保持完整行、sync、恢复和 health gate 语义。
- 无损接管当前版本可能遗留的 `business_events.log` 硬链接布局。
- 让归档命名、压缩和清理对日志采集器可预测，且不覆盖任何已有文件。

**Non-Goals:**

- 不引入按小时、按天、空闲时长或进程生命周期轮转。
- 不把业务日志 writer 替换为通用日志库；当前 writer 的事件级持久性与 health gate 仍需保留。
- 不改变事件 JSON、事件生成规则或 Nginx 下载业务日志。
- 不支持多个 Qtserver 进程并发写入同一 `log.file_path`；部署仍应保证日志目录单 writer。

## Decisions

### 1. Active 路径直接持有可写文件

writer 打开 `log.file_path/business-events.jsonl`，`w.path` 始终指向该固定路径。启动时若文件不存在则以 `0600` 创建；若存在则修复最后一个完整换行之后的尾部并以 append 模式打开。`Close` 只完成必要的 sync、尾部修复和 close，不改名、不压缩、不清理该路径；`Reopen` 也直接重新打开固定路径。

不再为当前内容创建时间戳路径，也不再调用 `os.Link` 维护 active 别名。这样采集器只需持续跟踪一个常规 active 文件，并在真正轮转后处理 inode 变化。

备选方案是保留时间戳文件加固定硬链接，仅把下划线名称改为连字符名称；该方案仍会让未轮转内容看起来像归档，也无法满足用户要求，因此不采用。

### 2. `max_size` 是唯一轮转触发器

保留当前“写入前预测”语义：当 active 非空，且下一条完整 JSONL 写入会使总大小超过 `max_size` 时，先轮转当前 active，再把该事件写入新的 active。单条事件大于阈值时仍允许写入空 active，避免产生无内容归档；事件自身仍受现有最大事件大小限制。

只有 `rotation.enable=true` 时执行上述判断。`max_age` 只参与已关闭归档清理，`max_backups` 只参与归档数量限制，`compress` 只处理已关闭归档。不会增加 timer、goroutine、每日边界或新的配置字段。

备选方案包括新增 `rotation_interval` 或把 `max_age` 解释为轮转周期；前者扩大配置面，后者会破坏现有配置含义，且用户已明确只按大小轮转，因此均不采用。

### 3. 轮转采用“关闭 active、原子改名、创建新 active”的顺序

轮转与 append 继续共用 writer mutex。流程为：

1. sync并关闭 `business-events.jsonl`；
2. 根据当前 UTC 时间和递增 sequence 选择未占用的 `business-events-<timestamp>-<sequence>.jsonl`，同时检查同名 `.gz`，确保不覆盖历史文件；
3. 将 active 原子 rename 为该归档并 sync 日志目录；
4. 以 `O_CREATE|O_EXCL` 和 `0600` 创建新的 `business-events.jsonl`，再 sync 日志目录；
5. 按既有方式压缩刚关闭的归档并执行 `max_age`/`max_backups` 清理；
6. 将触发轮转的事件写入新的 active。

任何无法确认文件边界、归档唯一性或目录持久性的错误都沿用现有策略：本次事件不盲目重写，writer 进入 logging-unhealthy，由独立恢复流程处理。归档压缩继续先写临时文件、sync 后替换，避免把半成品 `.gz` 暴露给采集器。

备选方案是复制 active 后 truncate 原文件；它会在复制期间引入双份可变内容和崩溃一致性问题，且无法自然保持关闭段不可变，因此不采用。

### 4. 启动时执行受控的旧布局迁移

打开新 active 前检查旧路径 `business_events.log`：

- 新旧 active 均不存在：创建新的 `business-events.jsonl`。
- 只有新 active：修复尾部并继续追加。
- 只有旧 active：修复尾部，并查找与其 inode 相同的未压缩 `business-events-*.jsonl`。
  - 没有匹配项时，旧文件是独立 active，直接 rename 为新 active。
  - 恰有一个匹配项时，先删除这个旧式时间戳硬链接并 sync 目录，再把仍保存全部内容的旧 active rename 为新 active并再次 sync。若中途失败，至少仍有旧 active 保留内容，下次启动可重试。
  - 多个匹配项或文件关系无法验证时，拒绝启动 writer。
- 新旧 active 同时存在：即使大小或 inode 看似相同也不自动合并或删除，直接报告日志不可用，留给运维确认。

没有 `business_events.log` 与之关联的历史 `business-events-*.jsonl[.gz]` 一律视为已关闭归档，不会在启动时重新变成 active。迁移只发生在启动边界，不产生业务事件，也不通过事件生产API越过 health gate。

备选方案是把所有旧文件拼接到新 active；这会改变事件顺序并可能重复采集。另一个方案是无条件把旧 active 当作已关闭归档；这会让升级本身制造一次非大小轮转。两者均不采用。

### 5. 归档发现显式排除 active

清理和压缩只匹配 `business-events-*.jsonl` 及其 `.gz` 形式；固定 active `business-events.jsonl` 不匹配该模式。旧版已经关闭的归档继续参加 `max_age` 和 `max_backups` 清理，保证升级后不需要第二套保留策略。

## Risks / Trade-offs

- [采集器仍监听 `business_events.log`] → 部署前让采集配置同时识别新旧 active 名称，确认新版本稳定后移除旧名称；归档 glob 保持 `business-events-*`。
- [迁移时发现新旧 active 冲突] → fail closed，不覆盖任何一方；在 Qtserver 日志中输出两个明确路径，运维备份并确认权威文件后再处理。
- [轮转在 rename 后、创建新 active 前失败] → 已关闭内容仍安全保存在唯一归档；writer 保持 unhealthy，恢复逻辑在确认归档状态后创建/打开固定 active，不重复旧内容。
- [归档名称碰撞] → 同时检查未压缩和压缩候选，递增 sequence，找不到唯一名称时停止轮转而不是覆盖。
- [低流量环境长期不产生归档] → 这是只按大小轮转的预期结果；active 文件可跨多次重启持续增长到阈值。
- [轮转时 active inode 变化] → 文档明确采集器必须支持 rename/create 型日志轮转，并同时读取关闭归档，避免只按初始 inode 永久跟随。

## Migration Plan

1. 部署前更新采集配置，使其同时监听旧 `business_events.log`、新 `business-events.jsonl` 和 `business-events-*.jsonl[.gz]`；避免滚动升级窗口出现采集空档。
2. 停止目标 Qtserver，保留日志目录原状并部署新版本；不要手工预创建空的新 active 文件。
3. 启动后确认 `business-events.jsonl` 是唯一 active，旧 `business_events.log` 已迁移，历史归档未被改写；再执行上传、下载和大小轮转验证。
4. 所有实例升级并稳定后，从采集配置中移除旧 active 名称。

回滚时先停止新版本并备份日志目录。若只有 `business-events.jsonl`，可将其改回 `business_events.log` 后启动旧版本；旧 writer 会按旧逻辑把该内容安全收为 recovered/关闭段并建立自己的时间戳段与硬链接。若新旧路径或不完整迁移状态同时存在，回滚前必须人工判定，禁止自动覆盖。
