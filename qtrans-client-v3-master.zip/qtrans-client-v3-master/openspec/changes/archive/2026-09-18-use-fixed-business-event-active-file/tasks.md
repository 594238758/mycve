## 1. Writer 文件生命周期

- [x] 1.1 将业务事件 writer 改为直接创建、追加、sync、reopen 和关闭固定 `business-events.jsonl`，移除 active 硬链接与“关闭即归档”逻辑；更新现有 writer 测试并验证首次写入、正常关闭和重启均不生成归档
- [x] 1.2 实现只由 `rotation.enable` 与 `max_size` 触发的 rename/create 轮转，保留 `max_backups`、`max_age` 和 `compress` 对关闭归档的既有处理；用 writer 测试验证阈值前无归档、超过阈值后只有一个关闭归档、禁用轮转时持续写同一 active、归档名称冲突不覆盖文件
- [x] 1.3 实现旧 `business_events.log` 独立文件及旧式硬链接布局的启动迁移，并对新旧 active 并存、多重 inode 匹配等歧义 fail closed；用迁移测试验证内容、完整行边界和历史归档均不丢失或重复暴露

## 2. 引用、文档与验证脚本

- [x] 2.1 更新仓库内 Qtserver active 文件名引用和运维说明，包括 `qtserver/README.md`、`qtserver/docs/config.md` 与 `docs/server-business-logging.md`；核对文档只描述固定 active、大小轮转及七类事件示例，不提 Qtlogsim或按时间轮转
- [x] 2.2 更新 `scripts/e2e_business_logging.sh` 对业务日志文件的检查，验证事件先进入 `business-events.jsonl`，正常重启不产生时间戳归档，并保留 caller_version 七类事件覆盖

## 3. 构建与本地部署验证

- [x] 3.1 对修改的 Go 文件运行 `gofmt`，运行 `go test ./internal/businessevents` 和 Qtserver 必要编译检查，确认 writer 生命周期、迁移与轮转测试以及构建全部通过
- [x] 3.2 按本地测试环境流程将 Qtserver 与 qtransc 部署到 `pingtouge153`，运行更新后的业务日志 E2E，并在临时使用 `rotation.enable=true,max_size=1` 的受控场景中产生足量事件，验证只在大小阈值后出现 `business-events-<UTC timestamp>-<sequence>.jsonl[.gz]`、新的事件继续进入 `business-events.jsonl`，测试结束后恢复原配置
- [x] 3.3 汇总本地测试命令、服务版本、实际 active/归档文件名和七类事件检查结果，核对简明业务日志文档示例与实测输出一致
