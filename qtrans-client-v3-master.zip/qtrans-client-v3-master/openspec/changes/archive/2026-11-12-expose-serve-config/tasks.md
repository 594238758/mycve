# Tasks

## 1. 配置查询实现

- [x] 1.1 为 TaskManager 增加按值返回配置快照的方法，代码审查确认两项限制和默认传输参数来自实际管理器字段、不暴露引用或运行计数。
- [x] 1.2 在 serveapi 定义专用配置响应类型，四个默认传输参数直接放在 defaults 下，代码审查确认六个叶子字段均使用正确类型和 lowerCamelCase 且不会省略。
- [x] 1.3 实现配置查询 handler 并注册受保护的 GET /api/v1/conf，代码审查确认默认值直接映射到 defaults、复用信封鉴权、无下游调用或关闭状态拒绝。

## 2. 契约核对与编译

- [x] 2.1 静态核对内置及自定义配置、鉴权、任务占用变化和关闭期间行为，同步对外 API 文档的字段路径与响应示例，提醒维护者人工审核；验证变更通过 openspec validate expose-serve-config --strict。
- [x] 2.2 在 qtransc 模块执行 go build ./... 并确认成功；不编写或运行测试和 benchmark。
