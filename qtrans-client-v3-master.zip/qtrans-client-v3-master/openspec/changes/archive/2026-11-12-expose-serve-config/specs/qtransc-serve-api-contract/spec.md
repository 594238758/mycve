## MODIFIED Requirements

### Requirement: serve 路由集合保持稳定

qtransc `serve` SHALL 暴露配置查询、token 更新、健康检查、任务创建、删除、详情、摘要、启动、暂停和列表共 10 个 JSON 接口，以及一个 SSE 事件接口；配置查询 SHALL 使用 `GET /api/v1/conf`，既有接口的 HTTP method 与 path SHALL 保持不变。

#### Scenario: 调用既有详情接口

- **WHEN** 调用方请求 `GET /api/v1/tasks/:task_id/detail`
- **THEN** qtransc SHALL 继续按该 method 与 path 提供任务详情

#### Scenario: 订阅既有事件接口

- **WHEN** 调用方请求 `GET /api/v1/events`
- **THEN** qtransc SHALL 建立 SSE 事件流

#### Scenario: 查询服务配置

- **WHEN** 调用方通过鉴权并请求 `GET /api/v1/conf`
- **THEN** qtransc SHALL 返回当前服务的任务限制和默认传输参数

## ADDED Requirements

### Requirement: 配置查询只返回任务限制和生效默认值

`GET /api/v1/conf` SHALL 使用 HTTP 200 和既有成功信封，省略顶层 meta。data SHALL 只包含 limits 和 defaults；limits SHALL 包含整数 maxConcurrentTasks、maxAdmittedTasks；defaults SHALL 直接包含字符串 transport 及整数 connections、streams、fileConcurrency，不增加传输参数分组层级。字段 SHALL 使用 lowerCamelCase 且全部返回。响应 SHALL NOT 包含凭据、本地路径、实时占用、剩余容量或其他配置字段。

#### Scenario: 使用内置默认配置

- **WHEN** 服务使用当前内置配置且配置查询成功
- **THEN** 响应 SHALL 为 code=0、message="Success"
- **AND** data.limits SHALL 为 maxConcurrentTasks=10、maxAdmittedTasks=64
- **AND** data.defaults SHALL 为 transport="v3"、connections=10、streams=1、fileConcurrency=5
- **AND** SHALL NOT 返回未约定字段

#### Scenario: 启动时覆盖默认传输参数

- **WHEN** 配置文件和显式启动参数按既有优先级合并、校验后的默认值为 v2、connections=3、streams=4、transfers=7
- **THEN** 配置查询 SHALL 返回 transport="v2"、connections=3、streams=4、fileConcurrency=7
- **AND** SHALL NOT 返回被覆盖的内置默认值

### Requirement: 配置查询区分接纳上限和任务默认参数

maxConcurrentTasks SHALL 表示同时占用执行名额的任务数上限；maxAdmittedTasks SHALL 表示排队任务与尚未结算执行的总接纳上限，不统计已经释放名额的终态任务记录。两项 SHALL 返回服务实际使用的限制，SHALL NOT 随任务占用变化。defaults SHALL 表示未指定任务参数时使用的服务默认值，SHALL NOT 作为请求覆盖值的上限。

#### Scenario: 任务执行和结算改变占用

- **WHEN** 任务创建、排队、执行或结算改变当前占用
- **THEN** 配置查询 SHALL 仍返回相同的配置上限和服务默认值
- **AND** SHALL NOT 从任务数量推导新的限制或返回剩余容量

#### Scenario: 单任务覆盖默认值

- **WHEN** 一个合法任务指定大于服务默认值的 connections 或 transfers
- **THEN** SHALL 按既有任务参数规则接纳
- **AND** 配置查询 SHALL 继续返回服务默认值，而非该任务的覆盖值

### Requirement: 配置查询沿用控制面鉴权且保持只读

配置查询 SHALL 遵守既有受保护接口的 server secret 鉴权规则及失败信封。查询 SHALL 只读取本地配置，SHALL NOT 访问 Qtserver、创建连接池或执行 context、改变任务或调度状态。服务正常关闭期间，只要 HTTP 仍可用且鉴权成功，配置查询 SHALL 继续成功，不因停止接纳任务而返回关闭错误。

#### Scenario: 配置了控制面密钥

- **WHEN** 服务配置 server secret，调用方未提供或提供了不匹配的 Bearer 密钥
- **THEN** 配置查询 SHALL 返回既有访问拒绝条目的完整信封，HTTP SHALL 为 200
- **AND** SHALL NOT 返回 data

#### Scenario: 未配置控制面密钥

- **WHEN** 服务未配置 server secret，调用方请求配置查询
- **THEN** SHALL 按既有未启用鉴权的规则成功返回配置

#### Scenario: 下游不可用

- **WHEN** Qtserver 不可用，调用方通过鉴权并查询配置
- **THEN** 配置查询 SHALL 仍成功，且不发起任何下游请求或创建执行资源

#### Scenario: 服务正在正常关闭

- **WHEN** 服务已停止接纳任务，但 HTTP 仍可用，调用方通过鉴权并查询配置
- **THEN** SHALL 继续返回原配置，不改变关闭流程
