# Proposal

## Why

外部调用方无法通过 qtransc HTTP API 获得服务的任务并发数、任务量上限和默认传输参数，只能在集成中重复维护这些值。新增只读配置查询，使调用方能够依据当前服务配置控制任务提交。

## What Changes

- 新增受现有控制面鉴权保护的 `GET /api/v1/conf`，使用现有 HTTP 200 成功信封。
- 返回 `limits.maxConcurrentTasks`、`limits.maxAdmittedTasks`，以及 `defaults` 下的 `transport`、`connections`、`streams`、`fileConcurrency`，不再增加传输参数分组层级。
- 任务量表示排队任务与尚未结算执行的总接纳容量；返回服务生效默认值，不返回实时占用或剩余容量。
- 查询仅读取本地配置，不创建执行资源；正常关闭期间 HTTP 仍可用时继续提供查询。
- 非目标：配置修改、新增启动参数、其他限制字段、Qtserver 能力查询和错误码变更。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `qtransc-serve-api-contract`：路由集合追加配置查询，定义其字段语义、鉴权和只读行为。

## Impact

- 涉及 qtransc 路由、handler、专用 HTTP 响应结构和 TaskManager 配置快照。
- 仅追加一个 JSON 接口；既有 method、path、响应、CLI、SSE 和下游协议不变，现有调用方无需迁移。
- 不新增依赖，不编写或运行测试及 benchmark；实现后执行 qtransc `go build ./...`。
- 更新对外 API 文档中的配置查询说明、字段表和响应示例；新增或修改内容交由维护者人工审核。
