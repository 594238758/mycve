# Design

## Context

动机见 proposal.md。serve 初始化 TaskManager 时传入执行名额 10、接纳上限 64 和已合并校验的 TransferDefaults。管理器已有内部统计读取方法，但它包含实时计数，也没有稳定 HTTP 字段约定，不能直接充当配置响应。

## Goals / Non-Goals

**Goals:** 返回与调度和任务默认参数一致的配置快照；隔离内部状态与对外 JSON；复用既有鉴权和信封。

**Non-Goals:** 不增加配置修改、热更新、启动选项或实时状态查询；不为本地配置查询创建执行资源。

## Decisions

1. TaskManager 新增按值返回配置快照的方法，包含实际执行上限、接纳上限和默认 TransferSettings。沿用管理器锁保护读取，返回值不共享可变引用。相较于 handler 硬编码 10/64 或直接返回 ManagerStats，该方案保持单一数据来源且不公开运行计数。
2. serveapi 定义专用 ConfigData、ConfigLimits 和 ConfigDefaults 响应类型，所有约定字段必填。ConfigDefaults 直接包含四个默认传输参数，减少一层对象和一个响应类型。handler 从管理器快照显式映射六个叶子字段，不序列化 AppConfig、TransferSettings 或 ManagerStats，避免内部字段增加后意外进入公开响应。
3. `GET /api/v1/conf` 注册在现有 protected 组，复用 respondSuccess；不添加关闭状态拒绝分支。只读取快照，不调用任务解析、Qtserver 或连接池代码。
4. 保留当前启动配置加载和任务覆盖规则。服务默认配置在管理器构造时按值固定；接口不提供实时容量承诺，调用方仍需按既有创建或启动结果判断接纳是否成功。

## Risks / Trade-offs

- [把默认值当成硬上限] → 契约明确 defaults 与 limits 的不同语义，任务参数覆盖逻辑保持原状。
- [暴露内部或敏感配置] → 专用 HTTP 类型和显式字段映射限制返回范围。
- [把任务量误解为历史任务数或等待队列数] → 明确接纳上限包括排队与尚未结算的执行，已释放名额的终态记录不计入。
- [仅编译无法证明全部运行时行为] → 按用户要求不编写或运行测试，以构建及逐项代码审查核对契约。

## Migration Plan

仅追加接口，既有调用方无需迁移；回退本次新增接口及读取结构即可撤回。对外 API 文档同步配置查询说明，新增或修改内容作为草稿交由维护者人工审核。
