## Context

参见 `proposal.md` 的动机，以及 `specs/versioned-https-transports/spec.md` 和 `specs/tcp-transport-pooling/spec.md` 的行为契约。

当前 transport 枚举是 `http|https|quic`，空值默认 `quic`。`netclient` 将 `https` 映射到只启用 HTTP/2 的 Go `http.Transport`，但配置规范化又把它的 `MaxLeasesPerConnection` 固定为 1；文档则把 `https` 描述为可使用 HTTP/1.1 或 HTTP/2。`http` 选择明文 HTTP/1.1，`quic` 选择 HTTP/3。

`internal/transportpool` 已经是当前权威连接池实现：顶层按 transport 保存 pool，每个 pool 按规范化 origin 建立 origin pool，origin pool 再以 lane 管理连接和 lease。`connections` 当前限制 lane 数；HTTP/3 另外在 Dial 层用 per-origin permit 限制标准 `http3.Transport` 在 GOAWAY 替换期间持有的实际 QUIC 连接。旧 `internal/h12client` 与 `internal/h3client` 没有被现有调用链引用，不作为本次设计的连接池基础。

已完成的 `fix-http3-goaway-connection-recovery` 变更已经定义并实现 HTTP/3 的物理连接 permit、GOAWAY 排空、安全单次重试和 UDP 资源回收。本设计保留该模型，只把用户可见名称迁移为 `https3`。

## Goals / Non-Goals

**Goals:**

- transport 名称在建连前唯一确定 HTTP 版本，不把 ALPN fallback 当作隐含行为。
- 让 HTTP/1.1 与 HTTP/2 共用同一套 origin、lease、等待和关闭框架，同时保留各自不同的并发能力。
- 把 `connections` 明确实现为按需使用的物理连接硬上限，把 `streams` 实现为多路复用协议的本地请求准入上限。
- 让 HTTP/2 真正使用配置的多 stream 容量，并继续服从服务端动态发布的并发上限。
- 在不复制 HTTP/3 生命周期规格的前提下完成 `quic` 到 `https3` 的一致迁移。

**Non-Goals:**

- 不提供 HTTP 版本自动探测、fallback、Alt-Svc 升级或 Happy Eyeballs 式的跨协议竞速。
- 不支持明文 HTTP/1.1、h2c、raw TCP 或自定义 TCP 应用协议。
- 不改变 TLS 证书校验策略、环境代理策略、QUIC window 默认值、业务 HTTP API 或业务重试预算。
- 不重新实现 quic-go 已经负责的 HTTP/3 GOAWAY 识别和安全协议层重试。
- 不把未被调用的旧连接池包迁入新架构，也不借此变更执行无关清理。

## Decisions

### 1. transport 是协议选择器，不是底层网络类型

用户可见集合固定为：

```text
https  = HTTP/1.1 -> TLS -> TCP
https2 = HTTP/2   -> TLS -> TCP
https3 = HTTP/3   -> QUIC/TLS 1.3 -> UDP
```

三者的 URL scheme 都是 `https`。内部枚举相应使用 `TransportHTTPS`、`TransportHTTPS2`、`TransportHTTPS3`；判断 HTTP/3 的辅助方法只对 `TransportHTTPS3` 返回 true。空 transport、CLI 默认值以及兼容命令硬编码值统一改为 `https3`。

不保留 `quic` 或 `http` alias。alias 虽能减轻滚动升级成本，但会让合法输入集合、序列化结果和弃用期限继续存在两套答案；本次选择一次性迁移并在错误中只列出三个规范值。原 `https` 的语义改为 HTTP/1.1 是明确的 breaking change，原 HTTP/2 调用改用 `https2`。

### 2. 三个独立 driver 分别约束协议和 ALPN

TCP driver 继续使用 Go 1.26 的 `http.Transport.NewClientConn`，使每个 pool lane 拥有一条明确可关闭的 TCP/TLS client connection：

- `https` driver 的 `http.Protocols` 只启用 HTTP/1，TLS ALPN 只提供 `http/1.1`。为兼容没有 ALPN 的合法旧式 HTTP/1.1 TLS 服务端，协商结果允许为空或 `http/1.1`，但不允许 `h2`。
- `https2` driver 的 `http.Protocols` 只启用 HTTP/2，TLS ALPN 只提供 `h2`。Go 在服务端未选择 ALPN 时可能仍构造 HTTP/1 client connection，因此仅设置 `Protocols` 不足以实现严格模式；TLS 配置需要组合 `VerifyConnection` 检查并要求 `NegotiatedProtocol == "h2"`，在任何 HTTP bytes 发出前拒绝空值或其他结果。
- `https3` driver 继续由 quic-go `http3.Transport` 使用 `NextProtos=["h3"]`，并保留 per-origin 物理连接 limiter。QUIC 的 TLS 1.3 握手属于 QUIC 协议栈，不描述为 TLS over TCP。

TLS ALPN 检查使用克隆后的每-driver 配置，不修改调用者共享的 `tls.Config`；若未来配置已有 `VerifyConnection`，先执行原 callback，再执行 transport 专属 ALPN 检查。TCP driver 继续支持现有环境代理；`https2` 经过 CONNECT tunnel 后仍执行相同严格 ALPN 检查。HTTP/3 继续保持当前直连 UDP 行为。

备选方案“`https` 同时提供 `h2,http/1.1`，由服务端选择”被拒绝，因为同一个 transport 会在握手后才确定连接容量模型。备选方案“只配置 `h2` 但允许空 ALPN”也被拒绝，因为它会产生表面为 `https2`、实际进入 HTTP/1.1 的静默 fallback。

### 3. registry、origin pool、connection lane 三层职责保持分离

连接池结构保持：

```text
transport registry
  ├─ https pool
  │    └─ origin -> TCP/TLS lanes
  ├─ https2 pool
  │    └─ origin -> TCP/TLS lanes
  └─ https3 pool
       └─ origin -> HTTP/3 lanes + shared physical QUIC permits
```

transport registry 防止跨协议复用；origin key 继续规范化 scheme、host 和默认端口，防止跨 authority 复用；origin pool 管理 FIFO waiter、lane 选择和关闭；driver 只负责创建、使用和判断本协议连接。

`connections=N` 创建的是容量为 N 的连接槽位集合，不是 N 条预热连接。lane 在首个请求需要时创建；`new` 和 `connecting` 状态已经占用槽位。ready 连接空闲超时后关闭，池可以回到零连接。draining 或 failed 连接只要尚未完全关闭也继续占用槽位，以保证替换时不会短暂出现第 N+1 条实际连接。

状态转换保持单向且由 origin pool 锁保护：

```text
new -> connecting -> ready -> draining -> closed
          |            |
          +-> failed <-+
                 |
                 +-> closed
```

ready 是唯一能够继续接收新请求的已建连状态；new/connecting 只承载已经为该 lane 预留的本地 lease。failed、draining 和 closed 不再接收新 lease。连接最终关闭并从 lane 集合移除后，释放的槽位才能用于替代 Dial。

### 4. 本地 lease 上限与对端协议上限是两层容量

本地池先执行用户配置的确定性上限：

```text
https  每 origin 本地上限 = connections
https2 每 origin 本地上限 = connections * streams
https3 每 origin 本地上限 = connections * streams（既有生命周期规则）
```

这只是上界，不承诺一定达到该吞吐量。HTTP/1.1 的 lane 容量固定为 1。HTTP/2 不再把 `streams` 静默压成 1，而把正整数配置传给 `MaxLeasesPerConnection`。每个 lane 优先选择当前活跃 lease 较少的 ready 连接；所有既有 lane 达到本地上限后，才在 `connections` 范围内按需创建新 lane。

第二层由协议库执行服务端限制。Go `http.ClientConn.RoundTrip` 在 HTTP/2 连接达到对端 `SETTINGS_MAX_CONCURRENT_STREAMS` 时等待可用 stream，不会由其内部另开一条不受 pool 控制的 TCP 连接；请求 context 取消时解除等待。可使用 `ClientConn.Available`、`Reserve`、`Release` 和 `SetStateHook` 改善 ready 连接的准入与唤醒，但这些动态值不能替代外层 `streams` 硬上限，也不能让 generic pool 依赖 HTTP/2 私有状态。

HTTP/3 的 `streams` 继续由现有 lease 模型执行；对端可打开的客户端请求 stream 数由 QUIC stream credit 控制。`quic.Config.MaxIncomingStreams` 限制的是对端向客户端发起的双向 stream，不是客户端请求并发，因此 SHALL NOT 用它实现 `--streams`。

备选方案“只依赖协议库的对端限制”被拒绝，因为服务端上限可能很高或动态变化，无法提供用户要求的本地资源硬边界。备选方案“把 `streams` 直接写入 QUIC MaxIncomingStreams”方向相反，不能限制客户端发出的请求。

### 5. lease 生命周期以完整响应体占用期为边界

一个 lease 只允许一次 RoundTrip。容量从 lane 分配开始占用；无响应体、请求错误、响应体 EOF 或 Close 时通过 `sync.Once` 归还。调用者获取 client 后没有发送请求时，release callback 归还未使用 lease。请求 origin 在 RoundTrip 前再次校验，防止一次 lease 被用于另一个 origin。

保持响应体阶段占用 lease 是必要的：HTTP/1.1 在 body 消费前不能安全复用连接，HTTP/2 的 stream 也尚未完成。仅在响应头到达时归还会让监控值低估真实并发，并可能突破本地 `streams` 上限。

### 6. TCP 失效采用安全排空和保守重试边界

HTTP/2 GOAWAY 或 client connection 不可继续使用时，lane 标记为 draining，不再分配新 lease；已开始且协议允许完成的 stream 继续持有 lease，最后一个 lease 结束后关闭连接并释放槽位。致命 TCP/TLS 错误进入 failed，并在活跃 lease 清零后关闭。空槽位出现时，FIFO waiter 可以触发替代 lane。

Go 的公开 `http.ClientConn` 提供 `Err` 和状态 hook，但没有导出完整 GOAWAY 原因。实现优先使用公开状态判断异步关闭和容量恢复；需要识别“连接不再接受新请求”的兼容逻辑集中在 HTTP driver 内，不把协议错误文本散布到 generic pool。无法确认请求未发送的 RoundTrip 错误标为 `RequestPossiblySent` 并返回业务层，连接池不自行重放。

HTTP/3 不套用上述 TCP 判断，继续使用标准 `http3.Transport.RoundTrip` 的内部判断：只有请求尚未打开 stream，或收到 `H3_REQUEST_REJECTED` 且 body 可复用时，才在连接替换中最多重试一次。该既有行为仍由 `http3-transport-lifecycle` 约束。

### 7. 参数规范化不再悄悄改变用户输入

`NormalizePoolConfig` 按 transport 执行以下规则：

- 三种模式都要求 `1 <= connections <= 1024`。
- `https` 要求 `streams == 1`。
- `https2`、`https3` 要求 `1 <= streams <= 1024` 并保留输入值。
- QUIC receive window override 仅接受 `https3`。

所有入口先分别校验 `connections` 和 `streams`，再计算 `connections * streams` 等派生容量。有效输入的乘积最大为 1,048,576，因此不会发生整数溢出，也不会让越界输入通过溢出后的较小结果绕过容量限制。新增上限只在代码中校验并通过参数错误反馈；不为此修改 `--connections`、`--streams` 的现有 CLI help 或命令行参数说明。

前台命令显式选择 `https --streams=N` 且 N 不等于 1 时直接返回现有 CLI 配置类错误。任一入口收到超过 1024 的 `connections`，或为 `https2`、`https3` 收到超过 1024 的 `streams` 时，也在建连和容量乘法前返回参数错误。qtransc serve 需要同时初始化三个 pool，因此其共享 multiplexed-stream 配置只传给 `https2`、`https3`；初始化 `https` 时显式传 1，而不是把共享值当作该用户选择的无效参数。

本变更保留 serve 现有 `quic.transports`、`quic.streamsPerTransport` 和对应旧 flag 作为配置来源，避免同时引入第二组配置迁移；Go 内部结构可以改为中性的 pool 命名。权威文档必须说明该历史配置中的 stream 值只用于 `https2`、`https3`。单独重命名这些配置键可由后续变更处理。

### 8. HTTP/3 只改选择名称，不重写生命周期

所有 `TransportQUIC` 分支、默认值、固定任务 JSON、错误文案和文档示例迁移为 `TransportHTTPS3`/`https3`。HTTP/3 driver、physical connection limiter、safe retry 和资源关闭路径保持现有设计。QUIC 专属内部类型、日志字段和库对象继续使用 `QUIC` 名称，因为那是准确的底层协议名。

`upload2`、`download2` 当前固定构造 `quic` 任务；它们改为固定构造 `https3`，仍不因全局 `--transport` 改变协议。qtransc serve 初始化 `https`、`https2`、`https3` 三个池，确保任务 API 可以按任务 transport 分派。

## Risks / Trade-offs

- [同名 `https` 的协议行为改变] → 发布说明和输入错误中给出明确迁移：需要 HTTP/2 的调用改为 `https2`；需要 HTTP/1.1 才继续使用 `https`。
- [不保留旧 alias 无法进行无协调滚动升级] → 控制端、任务 JSON 模板和 qtransc 二进制必须协调发布；升级前先把 `quic` 生产输入改为 `https3`，但只有新二进制接受新值。
- [严格 `https2` 遇到旧代理或未启用 h2 的 TLS endpoint 会失败] → 失败发生在请求发送前并清楚报告 ALPN 问题；需要兼容该 endpoint 时由调用者显式选择 `https`。
- [HTTP/1.1 吞吐受单连接单请求限制] → 通过增加 `connections` 获得并发；不启用已被现代客户端放弃的 HTTP/1.1 pipelining。
- [对端 HTTP/2 stream 上限低于本地配置时可能出现等待] → 由 `http.ClientConn` 在原请求 context 内等待，并在连接上限内允许其他 lane 承担请求；绝不绕过硬上限。
- [严格连接上限使 draining 期间出现等待] → 这是资源上限的预期结果；旧连接完全关闭后再建立替代连接。
- [Go `ClientConn` 的 GOAWAY 公开信息有限] → 把兼容判断封装在 HTTP driver，generic pool 只消费 ready/draining/failed 状态，避免协议细节扩散。
- [两个配置层仍使用 `quic.*` 历史命名] → 本次在文档中明确其作用域并把内部类型改为中性名称；外部键的原子迁移留给独立变更，避免扩大当前 breaking surface。

## Migration Plan

1. 协调更新所有 CLI 脚本、任务 JSON 生产者和调用 qtransc serve 的控制端：`quic` 改为 `https3`；依赖旧 `https` HTTP/2 行为的输入改为 `https2`；明文 `http` endpoint 先启用 TLS 后选择对应模式。
2. 实现并编译新版 qtransc；部署切换点需要同时启用新版二进制和新 transport 值，因为新旧名称互不兼容。
3. 重启 qtransc serve，使其建立 `https|https2|https3` 三个新 registry pool；现有上传恢复数据库和下载 progress 文件不保存 transport 迁移数据，无需 schema 变更。
4. 观察日志中的规范 transport、ALPN 失败、等待和连接替换错误，确认服务端分别支持所选 HTTP 版本。
5. 回滚旧二进制前，把 `https3` 输入还原为 `quic`、把 `https2` 输入还原为旧 `https`。新 `https` 的 HTTP/1.1 行为在旧二进制中没有等价 transport，回滚期间只能暂时改用旧 HTTP/2 `https` 或停止相应任务。
