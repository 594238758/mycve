## 1. 版本化 transport 模型

- [x] 1.1 将 `TransportMode` 的规范集合改为 `https|https2|https3`，同步空值默认、字符串输出、HTTP/3 判断、server scheme 校验和非法值错误，确保不接受 `quic`、`http` alias。
- [x] 1.2 把 CLI 默认值、任务请求规范化、URL 解析、capability cache key、固定 HTTP/3 兼容任务以及所有生产调用点迁移到新枚举，使需要序列化 transport 的路径只输出三个规范值。
- [x] 1.3 更新 `upload2`、`download2` 和其他固定 HTTP/3 入口为 `https3`，保持其既有“忽略用户 transport 选择并固定使用 HTTP/3”的兼容行为。

## 2. 严格 HTTPS 协议 driver

- [x] 2.1 将 `https` 接到只允许 HTTPS origin 的 HTTP/1.1 TLS driver，并将 `https2` 接到独立 HTTP/2 TLS driver；删除生产选择路径中的明文 HTTP/h2c driver 分支。
- [x] 2.2 为每个 TCP driver 克隆 TLS 配置并组合 transport 专属 ALPN 校验：`https` 只允许空值或 `http/1.1`，`https2` 必须为 `h2`，且校验失败发生在发送 HTTP bytes 之前并保留既有环境代理路径。
- [x] 2.3 将现有 HTTP/3 driver 映射到 `https3`，保留 `h3` ALPN、QUIC 配置、物理连接 limiter、GOAWAY 安全重试和 UDP 资源生命周期，不把用户可见改名扩散到准确的内部 QUIC 协议对象命名。

## 3. TCP 连接池容量与生命周期

- [x] 3.1 修改 pool 配置规范化：所有模式只接受 `1..1024` 的 `connections`，`https` 只接受 `streams==1`，`https2|https3` 只接受 `1..1024` 的 `streams`，并使 QUIC receive-window override 只接受 `https3`；所有入口必须先校验两个操作数再计算总容量，避免整数溢出。
- [x] 3.2 让 `https2` 的 `MaxLeasesPerConnection` 使用配置的 `streams`，同时利用 Go `http.ClientConn` 的公开容量/状态接口，使 ready lane 在本地上限和对端 HTTP/2 stream 容量内分配请求、在容量恢复时唤醒等待者，并能在 `connections` 上限内选择其他可用 lane。
- [x] 3.3 审计并补齐 TCP lane 的 `new -> connecting -> ready -> draining/failed -> closed` 转换，确保 Dial、ready、draining 和尚未关闭的 failed 连接都占用硬上限，已知不可用连接不接收新 lease，最终关闭后等待者能够建立替代连接。
- [x] 3.4 保持一次性 lease 覆盖完整响应体生命周期，补齐未使用 release、请求错误、Body EOF/Close、origin mismatch、重复调用和 context 取消路径的恰好一次容量归还。
- [x] 3.5 保持同一 origin 的本地容量 waiter FIFO，补齐等待取消、Dial 取消、pool Close 唤醒和幂等关闭路径；HTTP driver 内集中处理 Go `ClientConn` 的不可用/GOAWAY 兼容判断，generic pool 不解析协议错误。
- [x] 3.6 保持 TCP pool 不自动重放可能已发送的请求，准确区分建连/ALPN 阶段的 `RequestNotSent` 与 RoundTrip 阶段的 `RequestPossiblySent`，不扩大业务层现有重试范围。

## 4. serve 配置与多池初始化

- [x] 4.1 让 qtransc serve 初始化 `https`、`https2`、`https3` 三个 pool：连接数配置应用于三者，multiplexed-stream 配置只传给 `https2|https3`，`https` 显式使用 1。
- [x] 4.2 将 serve 内部 `QUICConfig` 等实际承载通用 pool 容量的 Go 命名改为中性名称，同时保留现有 `quic.transports`、`quic.streamsPerTransport` 和对应 flag 输入，避免增加未批准的外部配置迁移。
- [x] 4.3 更新 transport 和 `--mcrw-size` 的 CLI help、日志字段与错误消息，使 `https3` 是唯一用户可见的 HTTP/3 名称且 QUIC 专属参数不能用于 TCP 模式；新增 `connections`、`streams` 上限只在代码校验和参数错误中体现，不修改这两个参数的现有 CLI help 或命令行参数说明。

## 5. 权威文档与迁移说明

- [x] 5.1 更新 `qtransc/docs/qtransc-apis.md` 中任务 `transport` 的合法值、空值默认、URL 约束、错误示例、breaking migration 和三种固定协议栈。
- [x] 5.2 更新 `qtransc/docs/CLI_GUIDE.md`，精确定义 `--connections` 是每 origin 按需使用的物理连接硬上限、`--streams` 在三种模式下的语义、严格 ALPN 和无 fallback 行为；不因新增 1024 上限修改现有命令行参数说明。
- [x] 5.3 更新 `qtransc/docs/DESIGN.md`，记录 registry/origin/lane 分层、TCP lane 状态、lease 生命周期、HTTP/2 对端限制，以及 `https3` 继续遵守既有 HTTP/3 生命周期规格。
- [x] 5.4 更新 `qtransc/docs/TEST_PLAN.md` 和其他生产示例中的旧 transport 值；保留准确的 QUIC 底层协议描述，并确认用户可见示例不再建议 `quic` 或明文 `http`。

## 6. 格式化与静态验证

- [x] 6.1 对修改的 Go 文件执行 gofmt，使用定向搜索审查生产代码、help 和文档中的旧 transport 值，逐项保留仅指底层 QUIC 协议或历史迁移说明的出现。
- [x] 6.2 编译 qtransc 全部生产包，确认三个 driver、CLI、serve 和任务调用链通过编译；不新增或运行 test、benchmark。
- [x] 6.3 运行严格 OpenSpec 校验，确认 proposal、两份 delta spec、design 和 tasks 保持一致。
