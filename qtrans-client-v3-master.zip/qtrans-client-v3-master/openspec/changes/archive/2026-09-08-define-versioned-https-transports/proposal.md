## Why

qtransc 当前以 `http`、`https`、`quic` 命名传输模式，但名称没有精确表达 HTTP 版本：`https` 实际选择 HTTP/2，却把单连接并发限制为 1，文档又允许 HTTP/1.1 或 HTTP/2，导致协议协商、连接池容量和参数含义不一致。需要用版本化 HTTPS 模式建立稳定的外部契约，使每种模式在建连前即可确定协议栈和连接池模型。

## What Changes

- 将 qtransc 的用户可见 transport 集合定义为 `https`、`https2`、`https3`，默认值为 `https3`：
  - `https` 固定使用 HTTP/1.1 over TLS over TCP；
  - `https2` 固定使用 HTTP/2 over TLS over TCP，并要求 TLS ALPN 协商为 `h2`；
  - `https3` 固定使用 HTTP/3 over QUIC over UDP，并要求协商为 `h3`。
- 三种 transport 均要求 `https://` server URL；任何模式都不得向其他 HTTP 版本静默回退。
- 精确定义按 transport 和 origin 隔离的客户端连接池：`connections` 是每个 origin 的物理连接硬上限；HTTP/1.1 每连接最多一个活跃请求；HTTP/2 和 HTTP/3 的本地每连接活跃请求流上限由 `streams` 控制，并同时受对端协议流量控制限制。
- 明确连接建立、容量预留、等待、归还、失效、draining、空闲回收和关闭时的资源边界，避免并发建连突破硬上限或连接失效后永久损失容量。
- 对不适用于所选 transport 的参数执行显式校验；`connections` 对所有 transport 限制为 `1..1024`，`https` 的 `streams` 必须为 1，`https2`、`https3` 的 `streams` 限制为 `1..1024`，QUIC 专属参数只适用于 `https3`。新增容量上限只通过代码校验和错误返回执行，不修改 `--connections`、`--streams` 的现有命令行参数说明。
- **BREAKING**：删除用户可见的 `http` 和 `quic` transport 值，不提供长期别名；原 `quic` 配置必须迁移为 `https3`，原明文 `http` 配置必须先为服务端启用 TLS 再迁移为对应 HTTPS 模式。
- **BREAKING**：`https` 从当前实现意图中的 HTTP/2-only 改为 HTTP/1.1 over TLS；依赖 HTTP/2 的现有调用必须迁移为 `https2`。
- 同步更新 qtransc CLI、API 文档、设计说明和使用示例；不改变 qtserver 业务 HTTP API、认证协议或文件传输语义。

## Capabilities

### New Capabilities

- `versioned-https-transports`: 定义 qtransc 的 `https`、`https2`、`https3` transport、严格协议选择、参数校验以及旧 transport 的迁移行为。
- `tcp-transport-pooling`: 定义 HTTP/1.1 over TLS 和 HTTP/2 over TLS 的连接池容量、请求 lease、等待、draining、失效替换与资源关闭行为。

### Modified Capabilities

无。

## Impact

- 受影响代码：`qtransc/internal/types`、`qtransc/internal/netclient`、`qtransc/internal/transportpool`、transport 相关 CLI 参数和直接传输入口。
- 受影响文档：`qtransc/docs/qtransc-apis.md`、`qtransc/docs/CLI_GUIDE.md`、`qtransc/docs/DESIGN.md`、`qtransc/docs/TEST_PLAN.md` 及包含旧 transport 值的示例。
- 外部兼容性：脚本、配置和 API 请求中的 `transport="quic"`、`transport="http"` 或依赖旧 `https` 含义的调用需要显式迁移；不进行静默转换。
- 运行依赖：不新增第三方依赖；继续使用 Go HTTP/TLS 栈和 quic-go，但按固定协议分别构造 driver。
- 规格关系：已完成的 `fix-http3-goaway-connection-recovery` 变更继续作为 HTTP/3 物理连接、stream、GOAWAY 和安全重试生命周期的权威定义；本变更只把其用户可见 transport 名称从 `quic` 迁移为 `https3`，不重写该生命周期。
- 非目标：不新增 raw TCP、自定义 TCP 应用协议、明文 HTTP/2、HTTP 版本自动协商或跨版本 fallback；不修改服务端 API。
