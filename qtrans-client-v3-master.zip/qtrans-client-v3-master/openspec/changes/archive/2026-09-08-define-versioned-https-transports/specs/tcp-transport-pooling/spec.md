## Purpose

定义 qtransc 的 HTTPS/HTTP1.1 与 HTTPS/HTTP2 客户端连接池如何隔离 origin、约束物理 TCP/TLS 连接和请求并发，并在等待、取消、排空与关闭期间可靠回收容量。

## ADDED Requirements

### Requirement: TCP 连接池按 transport 和 origin 隔离

qtransc SHALL 以 transport 与规范化 origin 的组合隔离 `https` 和 `https2` 连接池。规范化 origin SHALL 由小写 scheme、小写 host 和显式有效端口组成，省略的 HTTPS 端口 SHALL 规范化为 `443`。一个 origin 的连接、容量、等待队列和故障状态 SHALL NOT 被其他 origin 或 transport 共享。

#### Scenario: 同一 HTTPS origin 的等价写法

- **WHEN** 请求分别使用 `https://EXAMPLE.COM` 与 `https://example.com:443`，且 transport 相同
- **THEN** qtransc SHALL 将两者归入同一个规范化 origin 池

#### Scenario: 相同地址使用不同 TCP transport

- **WHEN** 同一个 `https://` 地址分别使用 `https` 和 `https2`
- **THEN** qtransc SHALL 使用两个相互隔离的连接池，并 SHALL NOT 跨池复用物理连接

#### Scenario: lease 被用于其他 origin

- **WHEN** 已从一个 origin 获取的请求 lease 被用于不同 origin 的请求
- **THEN** qtransc SHALL 在发送请求前拒绝该请求并释放对应容量

### Requirement: connections 是按 origin 的硬上限而非保有量

`connections` SHALL 是每个 TCP transport、每个 origin 的连接槽位硬上限，而不是启动时预建或持续保有的连接数量。连接池 SHALL 按需建立连接，并 SHALL 允许空闲回收后连接数降为零。尚未完成的 Dial 以及尚未完全关闭的 ready、draining 或 failed TCP/TLS 连接 SHALL 占用连接槽位，使实际并发物理连接数始终不超过 `connections`。

#### Scenario: 首个请求触发按需建连

- **WHEN** 某 origin 尚无连接且收到首个请求
- **THEN** qtransc SHALL 先预留一个连接槽位再开始 Dial，而 SHALL NOT 在池初始化时预建 `connections` 条连接

#### Scenario: 并发建连达到上限

- **WHEN** 某 origin 已有 `connections` 个被 Dial 或未关闭连接占用的槽位
- **THEN** qtransc SHALL NOT 为该 origin 再创建物理连接，直到已有槽位释放

#### Scenario: 空闲连接全部回收

- **WHEN** 某 origin 的全部连接均无活跃请求并超过配置的空闲时间
- **THEN** qtransc SHALL 关闭这些连接并释放槽位，且下一次请求 SHALL 能重新按需建连

### Requirement: TCP 请求并发受本地和对端容量共同约束

`https` 每条 TCP/TLS 连接 SHALL 最多准入一个活跃请求 lease。`https2` 的 `streams` SHALL 表示每条连接由 qtransc 准入的活跃请求 lease 上限；实际 HTTP/2 并发 stream 数 SHALL 同时受对端 `SETTINGS_MAX_CONCURRENT_STREAMS` 限制。对端限制更小时，qtransc SHALL 等待协议容量或使用 `connections` 上限内的其他可用连接，而 SHALL NOT 突破连接硬上限。

#### Scenario: https 不进行请求多路复用

- **WHEN** `https` 的一条 TCP/TLS 连接已有一个活跃请求
- **THEN** qtransc SHALL NOT 在该连接上准入第二个请求

#### Scenario: https2 使用本地 stream 容量

- **WHEN** `https2` 的一条连接已准入少于 `streams` 个活跃请求，且该连接仍有对端协议容量
- **THEN** qtransc SHALL 能在不新建物理连接的情况下把请求分配给该连接

#### Scenario: origin 的本地总容量耗尽

- **WHEN** 某 origin 已占用全部 `connections` 槽位，且每条可用连接均达到对应的本地或对端请求容量
- **THEN** 后续获取请求容量的调用 SHALL 等待容量释放或其 context 结束

#### Scenario: HTTP2 对端 stream 限制更小

- **WHEN** `https2` 对端允许的并发 stream 数小于本地 `streams`
- **THEN** 实际 HTTP/2 stream 数 SHALL NOT 超过对端限制，且 qtransc SHALL 能使用连接上限内的其他可用连接

### Requirement: 请求 lease 覆盖完整响应占用期

连接池 SHALL 为每个请求分配一次性 lease。lease 的容量 SHALL 从请求获准使用连接开始持续到请求失败、无响应体响应完成、响应体读到 EOF 或响应体被关闭；任一路径 SHALL 恰好释放一次容量。仅获取但尚未发送请求的 lease 被调用者释放时 SHALL 立即归还容量。

#### Scenario: 响应体仍在读取

- **WHEN** 请求已收到响应头但响应体尚未读完或关闭
- **THEN** 对应 lease SHALL 继续占用连接的一个请求名额

#### Scenario: 响应体完成

- **WHEN** 响应体读到 EOF 或调用者关闭响应体
- **THEN** qtransc SHALL 恰好一次归还 lease，并 SHALL 使等待中的请求能够获得释放的容量

#### Scenario: 请求未开始即释放

- **WHEN** 调用者获取 lease 后未发送请求便释放它
- **THEN** qtransc SHALL 立即归还容量且 SHALL NOT 发送网络请求

#### Scenario: 重复使用 lease

- **WHEN** 调用者尝试第二次使用或使用已经释放的 lease
- **THEN** qtransc SHALL 在发送请求前拒绝该操作且 SHALL NOT 重复释放容量

### Requirement: 容量等待公平且可取消

同一 origin 中因本地连接池容量不足而等待的获取操作 SHALL 按进入等待队列的顺序获得后续容量，新请求 SHALL NOT 绕过已有等待者。等待调用的 context 取消、超时或池关闭 SHALL 及时解除等待，并 SHALL NOT 泄漏 lease 或连接槽位。

#### Scenario: 多个请求等待本地容量

- **WHEN** 同一 origin 的本地容量耗尽后依次出现多个等待者
- **THEN** 容量释放时 qtransc SHALL 按等待顺序分配可用 lease

#### Scenario: 等待者取消

- **WHEN** 一个仍在队列中的等待者 context 被取消或超时
- **THEN** qtransc SHALL 移除该等待者并返回对应错误，后续等待者 SHALL 继续正常获得容量

#### Scenario: Dial 期间调用者取消

- **WHEN** 请求正在等待其 TCP/TLS 连接完成 Dial，且请求 context 被取消
- **THEN** qtransc SHALL 停止该请求的等待并归还其 lease；共享 Dial 是否继续 SHALL 由池内其他有效 lease 决定

### Requirement: 失效和 draining TCP 连接可安全替换

连接池 SHALL NOT 向已知 failed、closed 或 draining 的 TCP 连接分配新请求。收到 HTTP/2 GOAWAY 等协议级 graceful shutdown 信号时，连接 SHALL 进入 draining，已开始且协议允许继续的请求 SHALL 能完成；连接无活跃请求后 SHALL 被关闭并释放槽位。连接或 Dial 失败释放槽位后，等待中的请求 SHALL 能触发替代连接，但替代过程 SHALL 继续遵守 `connections` 硬上限。

#### Scenario: HTTP2 连接进入 draining

- **WHEN** `https2` 连接收到 GOAWAY 或等价的禁止新请求信号
- **THEN** qtransc SHALL 停止向该连接分配新请求，在活跃请求结束后关闭它并释放槽位

#### Scenario: TCP 连接发生致命错误

- **WHEN** TCP/TLS 连接被对端关闭或出现其他不可继续使用的错误
- **THEN** qtransc SHALL 将其标记为不可用、归还最终释放的槽位，并允许后续请求建立替代连接

#### Scenario: draining 连接仍占硬上限

- **WHEN** draining 连接仍承载活跃请求且全部连接槽位已被占用
- **THEN** 新请求 SHALL 等待槽位，而 SHALL NOT 临时突破 `connections` 建立替代连接

### Requirement: 关闭 TCP 连接池释放全部资源

关闭 TCP transport 池 SHALL 拒绝新的获取操作、唤醒已有等待者、取消尚未完成的 Dial，并关闭该池拥有的 TCP/TLS 连接。关闭 SHALL 可重复调用，并 SHALL 等待已启动的资源关闭流程结束。

#### Scenario: 有请求等待时关闭

- **WHEN** TCP 连接池关闭时存在等待容量或等待 Dial 的调用
- **THEN** 这些调用 SHALL 以池已关闭错误结束且 SHALL NOT 永久阻塞

#### Scenario: 重复关闭

- **WHEN** 同一 TCP 连接池被多次关闭
- **THEN** qtransc SHALL 不重复释放资源或发生 panic，并 SHALL 返回稳定的关闭结果

### Requirement: TCP 连接池不重放可能已发送的请求

TCP 连接池 SHALL NOT 因连接失效或替换而自动重放无法证明尚未发送的请求。请求级重试 SHALL 由业务层依据方法幂等性、请求体可重建性和既有重试预算决定。

#### Scenario: 请求可能已经发送

- **WHEN** HTTP/1.1 或 HTTP/2 请求因连接错误失败且无法证明请求尚未发送
- **THEN** 连接池 SHALL 返回带有“可能已发送”语义的错误，并 SHALL NOT 自行重放请求

#### Scenario: Dial 在发送请求前失败

- **WHEN** TCP/TLS Dial 或严格 ALPN 校验在任何 HTTP 请求 bytes 发送前失败
- **THEN** 连接池 SHALL 返回带有“未发送”语义的错误，使业务层能够按既有策略决定是否重试
