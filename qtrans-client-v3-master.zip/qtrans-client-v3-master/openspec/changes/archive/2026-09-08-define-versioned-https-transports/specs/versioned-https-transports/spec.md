## Purpose

定义 qtransc 如何以稳定的版本化 HTTPS transport 名称选择 HTTP/1.1、HTTP/2 或 HTTP/3，并确保 URL、协议协商、参数校验和旧配置迁移具有一致且可验证的行为。

## ADDED Requirements

### Requirement: 版本化 HTTPS transport 集合

qtransc SHALL 只接受 `https`、`https2`、`https3` 三个用户可见 transport 值，并 SHALL 在 transport 为空时规范化为 `https3`。三种模式的 server URL SHALL 均为包含 scheme 和 host 的绝对 `https://` URL；transport 名称 SHALL NOT 被解释为 URL scheme。

#### Scenario: transport 为空

- **WHEN** CLI、任务 JSON 或内部公开入口收到空 transport
- **THEN** qtransc SHALL 使用 `https3`，并在持久化、日志或响应中需要输出 transport 时使用规范值 `https3`

#### Scenario: 使用三个合法模式

- **WHEN** 调用者提供 `https`、`https2` 或 `https3`，且 server URL 是合法绝对 `https://` URL
- **THEN** qtransc SHALL 接受该 transport 与 URL 组合

#### Scenario: 使用非 HTTPS URL

- **WHEN** 任一合法 transport 搭配 `http://`、相对 URL 或缺少 host 的 URL
- **THEN** qtransc SHALL 在发起网络请求前拒绝该输入

#### Scenario: 使用旧 transport

- **WHEN** 调用者提供 `quic`、`http` 或其他未定义 transport
- **THEN** qtransc SHALL 在发起网络请求前拒绝该输入，并 SHALL 在错误中列出 `https`、`https2`、`https3` 三个合法值

### Requirement: transport 固定选择 HTTP 版本

`https` SHALL 只使用 HTTP/1.1 over TLS over TCP；`https2` SHALL 只使用 HTTP/2 over TLS over TCP；`https3` SHALL 只使用 HTTP/3 over QUIC over UDP。qtransc SHALL NOT 在三个 transport 之间自动协商、回退或升级。

#### Scenario: https 连接支持 HTTP/1.1

- **WHEN** `https` 与服务端完成 TLS 握手，且服务端选择 `http/1.1` ALPN 或未返回 ALPN 并接受 HTTP/1.1
- **THEN** qtransc SHALL 使用 HTTP/1.1 发送请求，并 SHALL NOT 提议或切换到 `h2`

#### Scenario: https 服务端不能使用 HTTP/1.1

- **WHEN** `https` 无法建立可承载 HTTP/1.1 的 TLS/TCP 连接
- **THEN** qtransc SHALL 返回连接或协议错误，并 SHALL NOT 改用 `https2` 或 `https3`

#### Scenario: https2 成功协商 h2

- **WHEN** `https2` 的 TLS ALPN 协商结果为 `h2`
- **THEN** qtransc SHALL 在该 TLS/TCP 连接上使用 HTTP/2

#### Scenario: https2 未协商到 h2

- **WHEN** `https2` 的服务端未选择 `h2`、只支持 HTTP/1.1 或 TLS ALPN 结果不是 `h2`
- **THEN** qtransc SHALL 在发送 HTTP 请求前使连接失败，并 SHALL NOT 回退到 HTTP/1.1

#### Scenario: https3 协商 h3

- **WHEN** `https3` 建立 QUIC 连接
- **THEN** qtransc SHALL 使用 `h3` ALPN 和 HTTP/3，并 SHALL NOT 改用 TCP、HTTP/2 或 HTTP/1.1

#### Scenario: https3 不可用

- **WHEN** UDP、QUIC、TLS 握手或 `h3` 协商失败
- **THEN** qtransc SHALL 返回对应连接或协议错误，并 SHALL NOT 自动回退到 `https2` 或 `https`

### Requirement: transport 参数严格校验

`connections` SHALL 对所有 transport 为 `1..1024` 范围内的整数。`https` 的 `streams` SHALL 等于 1；`https2` 和 `https3` 的 `streams` SHALL 为 `1..1024` 范围内的整数。只影响 QUIC 的参数 SHALL 仅适用于 `https3`。无效组合 SHALL 在连接池创建或网络访问之前失败，而 SHALL NOT 被静默修正。任何 `connections * streams` 派生计算 SHALL 在两个操作数分别通过范围校验之后执行，使每个 origin 的最大配置本地容量不超过 1,048,576 且计算不会发生整数溢出。

#### Scenario: https 配置多个 streams

- **WHEN** 调用者为 `https` 配置 `streams` 大于 1
- **THEN** qtransc SHALL 返回参数错误，而 SHALL NOT 把它静默压缩为 1

#### Scenario: 容量参数超出范围

- **WHEN** `connections` 小于 1 或大于 1024，或 `https2`、`https3` 的 `streams` 小于 1 或大于 1024
- **THEN** qtransc SHALL 在建连前返回参数错误

#### Scenario: 校验后计算总容量

- **WHEN** qtransc 需要根据 `connections` 与 `streams` 派生每个 origin 的本地总容量
- **THEN** qtransc SHALL 先分别完成范围校验再执行乘法，且有效输入得到的结果 SHALL NOT 大于 1,048,576

#### Scenario: QUIC 专属参数用于 TCP transport

- **WHEN** 调用者把 QUIC receive window 等 QUIC 专属参数用于 `https` 或 `https2`
- **THEN** qtransc SHALL 在建连前返回参数错误

#### Scenario: serve 同时初始化三种 transport

- **WHEN** qtransc serve 使用一个共享的 multiplexed-stream 配置初始化全部 transport 池
- **THEN** `https` 池 SHALL 固定使用每连接容量 1，`https2` 与 `https3` 池 SHALL 使用该共享配置值

### Requirement: 所有入口使用同一 transport 语义

前台命令、qtransc serve 任务 API、`upload2`、`download2`、文件管理命令和内部任务模型 SHALL 使用同一组规范 transport 值和协议映射。固定使用 HTTP/3 的兼容入口 SHALL 输出并使用 `https3`，而 SHALL NOT 继续生成 `quic`。

#### Scenario: API 创建未指定 transport 的任务

- **WHEN** qtransc serve 收到未提供 transport 的合法任务
- **THEN** 任务 SHALL 规范化并保存为 `https3`

#### Scenario: 兼容命令创建 HTTP/3 任务

- **WHEN** `upload2` 或 `download2` 构造其固定 HTTP/3 任务
- **THEN** 任务中的 transport SHALL 是 `https3`

#### Scenario: 不同入口收到旧值

- **WHEN** 任一入口收到 `quic` 或 `http`
- **THEN** 该入口 SHALL 按自身既有输入错误映射拒绝请求，且 SHALL NOT 将旧值静默转换为新值

### Requirement: https3 保持既有 HTTP3 生命周期契约

把用户可见名称从 `quic` 改为 `https3` SHALL NOT 改变既有 HTTP/3 物理连接硬上限、stream 硬上限、GOAWAY 排空、连接替换、UDP 资源关闭和安全协议层重试行为；这些行为 SHALL 继续遵守 `http3-transport-lifecycle` capability。

#### Scenario: https3 连接收到 GOAWAY

- **WHEN** `https3` 连接收到 GOAWAY，且替代连接需要等待物理连接名额
- **THEN** qtransc SHALL 继续按既有 HTTP/3 生命周期等待、排空和安全替换，而 SHALL NOT 因 transport 改名放宽连接或 stream 上限
