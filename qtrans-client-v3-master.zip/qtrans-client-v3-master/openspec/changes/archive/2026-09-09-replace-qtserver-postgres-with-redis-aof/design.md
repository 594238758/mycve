## Context

参见 [proposal.md](proposal.md) 的动机。当前 Qtserver 已用 Redis 保存上传 session、chunk checkpoint、协调锁和身份缓存，但正式文件 hash 及其 worker 状态机位于 PostgreSQL。`hashmanager.Manager` 因而同时依赖 PostgreSQL 和 Redis，server lifecycle 也分别初始化和健康检查两个共享数据服务。

本变更受以下既有约束影响：

- Qtserver 可多实例运行，hash worker 必须避免旧计算覆盖新文件结果。
- 正式文件位于共享文件系统；Redis 不能和 rename、unlink 或 fsync 组成事务。
- file hash API 继续使用异步 `202 HASH_PENDING`、stale-while-revalidate 和既有算法；qtransc 协议不变。
- upload session、lock 和 lease 已有 TTL 语义；AOF 会持久化整个 Redis dataset，不能按 key 选择只持久化一部分。
- `appendfsync everysec` 在 Qtserver/Redis 正常重启时提供恢复，但在异常停止时允许最近约一秒写入丢失。

## Goals / Non-Goals

**Goals:**

- 用一套 Redis 状态模型替代 `file_hashes` 表，同时保留多实例领取、heartbeat、超时接管、失败退避和 generation fencing。
- 使 Redis 配置错误、AOF 写入异常和容量耗尽都能 fail closed，而不是静默丢失上传控制状态。
- 对 Redis/AOF 恢复出的状态给出确定行为，并让缺失的 hash 状态可从正式文件重建。
- 让 hash cache 容量有界，同时保留一段明显长于 revalidate 窗口的 stale hash 可用期。

**Non-Goals:**

- 不把 Redis 设计成正式文件内容或跨文件系统提交的事实源。
- 不为 Redis Cluster 设计 hash slot，不引入 Sentinel、replica failover 或跨机房恢复。
- 不在本变更中提供 PostgreSQL hash 导入器、Redis 数据格式升级框架或在线混跑新旧 Qtserver。
- 不承诺对异常断电后的每一条已确认 Redis 写入做到零丢失。

## Decisions

### 1. 单 Redis dataset，全量 AOF，按 TTL 表达数据寿命

Qtserver 继续使用现有 `[redis]` 连接和 `key_prefix`，所有共享状态进入同一 logical DB。Redis 实例必须使用持久 volume、`appendonly yes`、`appendfsync everysec` 和 `maxmemory-policy noeviction`。RDB 可以作为额外备份，但不能代替 AOF 要求。

Qtserver 启动时执行 `PING`、`CONFIG GET appendonly appendfsync maxmemory-policy` 和 `INFO persistence`；任何配置不匹配、`aof_last_write_status` 异常或返回无法解析都会拒绝启动。运行期每五秒重复 `PING` 与 `INFO persistence`，并把 `MISCONF`、OOM、unexpected script/protocol error 等无法保证状态写入的错误交给现有 fatal reporter。`redis.Nil`、CAS miss、锁冲突和脚本定义的业务状态不属于 fatal error。

选择 `noeviction` 是因为同一 dataset 同时包含可重建 hash 和不可随意淘汰的 active session。若使用 LRU/LFU，Redis 可能为了一个 hash 写入静默淘汰 session，外部表现会变成不可预测的 `SESSION_NOT_FOUND`。`noeviction` 把容量问题转换为可观测的写失败和服务退出，运维可在数据丢失前扩容。

各类状态寿命如下：

| 状态 | 恢复/过期策略 |
|---|---|
| active/committed upload、chunk、intent | 沿用 `upload_session_retention_seconds` 及续期事件 |
| namespace/session/scanner lock | 沿用 30 秒 lease 和 token 校验，AOF 恢复不重置 TTL |
| identity cache | 沿用 provider 决定的短 TTL |
| stateless task ID、下载 HMAC grant URL | 不新增 Redis 状态，仍由签名和 `expires_at` 决定 |
| official hash record | 使用新增 `file_hash_retention_seconds`，默认 30 天，滑动续期 |
| hash pending/calculating record | 计算和 heartbeat 期间续期，避免活动任务被 GC |

备选方案是只为部分 key 持久化，或拆成 persistent/ephemeral 两个 Redis 实例。Redis 的 RDB/AOF 针对整个实例 dataset，第一种不可直接实现；第二种会重新引入第二套依赖和故障边界，与本次简化目标相反。

### 2. hash record、due queue 和 path index 组成 Redis 状态模型

新格式使用版本化 namespace，避免把当前 `official-hash` JSON cache 误认为新状态。逻辑 key 采用下列结构；实际 helper 统一编码 principal/object key 并限制单 key 长度。

| 结构 | 用途 |
|---|---|
| `<prefix>:v2:hash:record:<identity-digest>` HASH | 保存 identity、fingerprint、generation、state、hash、calculation_id、时间和 retry 字段 |
| `<prefix>:v2:hash:due` ZSET | score 为可领取时间或 calculating lease deadline，member 为 identity digest |
| `<prefix>:v2:hash:path:<principal-digest>:<algorithm>:<version>` ZSET | score 固定为 0，member 使用 binary-safe `object_key + NUL + digest`，支持 subtree lexicographic scan |
| `<prefix>:v2:hash:expiry` ZSET | score 为 retention deadline，驱动 hash GC 并同步清理 record、due 和 path index |
| `<prefix>:v2:hash:namespace-generation:<principal-digest>` STRING | 文件 namespace mutation 的跨 worker epoch |

identity digest 对 `principal + NUL + normalized object key + NUL + algorithm + NUL + version` 做 SHA-256；record 仍保存原 identity，用于防御摘要/key 构造错误和供 worker 解析。对象路径已经过现有 normalized object key 校验，因此 path index 可以安全使用 NUL 作为分隔符。目录 subtree 查询用 `object_key + "/"` 的 lexicographic prefix range，并单独处理 exact object。

hash record 不依赖关系型 schema。字段解析严格检查 state、整数范围、digest 对应 identity 和必要字段；不合法记录视为共享状态损坏并触发 fatal shutdown，不能当普通 cache miss 静默跳过。

备选方案一是每次目录 mutation 用 `SCAN` 搜索所有 hash key，它会扫描无关 session/identity key且延迟不可控。备选方案二是完全依赖 lookup 时 fingerprint 自愈，它能避免返回大多数旧 hash，但不能主动废止 subtree worker。path index 保留现有主动失效能力，并把扫描范围限定到 principal/algorithm/version。

### 3. 所有 hash 状态转换使用 Lua 和 Redis server time

`internal/store` 暴露面向状态机的方法，不把通用 Redis client 泄漏给 `hashmanager`。脚本以 `EVALSHA` 执行，遇到 `NOSCRIPT` 时加载后重试一次。所有 deadline、heartbeat、calculated_at 和 retry 计算使用脚本内 `TIME`，避免多 Qtserver 实例时钟偏差。

关键转换为：

1. `EnsurePending`：不存在时创建 generation=1 的 pending record，并原子加入 due/path/expiry；存在时根据 fingerprint、state 和 retry deadline 返回当前可用 hash或转换为 pending。
2. `ClaimDue`：从 due ZSET 取 score 不晚于 Redis 当前时间的候选；pending 进入 calculating，生成新的 calculation_id 和 30 秒 lease；过期 calculating 可被同一脚本接管。无效或已 GC 的 member 会顺手清理。
3. `Heartbeat`：同时校验 identity、generation、namespace generation 和 calculation_id，再延长 lease、record retention 与 due score；失败时 worker 取消本次提交资格。
4. `Submit`/`Fail`：仅在 generation、namespace generation 和 calculation_id 都匹配时更新。成功转 idle 并从 due 移除；失败保存指数退避信息，由到期后的访问重新置 pending。
5. `BeginKnownMutation`/`CommitKnown`：publish 前增加 object generation、清空旧 hash 并返回 token；不可逆文件操作成功后以 token CAS 写入已知 hash。旧 worker 或旧请求无法覆盖新结果。
6. `Invalidate`/`InvalidateTree`：exact record 直接失效；tree 通过 path index 分批删除 record、due 和 expiry member。每批由单个脚本原子完成，避免一个不受限 Lua script 长时间阻塞 Redis。
7. `CollectExpired`：从 expiry ZSET 分批领取到期记录，核对 record 当前 deadline 后同步清理所有索引；被近期访问续期的记录不会被旧 score 删除。

内存 `notify` channel 仍只负责降低 worker 唤醒延迟。即使 channel 满或进程重启，workers 每五秒查询 due ZSET，工作不会依赖内存通知。

备选方案是继续用 `WATCH`/`MULTI` 拼接所有转换。它适合简单 lock，但 hash 状态同时涉及 record 和多个索引，冲突重试与部分遗漏更难审计；Lua 更适合把每次转换封装成单个原子边界。

### 4. namespace generation 只 fence worker，不使所有缓存失效

目录 mutation 的 path index 清理需要分批执行，期间 hash lookup/worker 仍可能并发。为关闭这个窗口，持有 principal namespace lock 的 mutation 在文件系统操作前后各 bump 一次 namespace generation。worker claim 记录当时 epoch，heartbeat/submit 必须匹配当前 epoch；因此扫描前已领取以及扫描期间新领取的计算都不能在 mutation 完成后提交。

namespace generation 变化本身不使该 principal 的所有 idle hash 失效。未受影响路径的 cached hash 继续通过 fingerprint 校验后使用；受影响 subtree 的现有 record 由 path index 删除，极窄窗口中漏掉的 record也会在 lookup 时因文件缺失或 fingerprint 变化失效。这个设计以一次 principal 级 worker 重算为代价，避免实现复杂且容易遗漏的层级 fencing token。

单文件 create/complete 仍使用 object generation CAS；move/delete 目录额外使用 subtree invalidation。文件系统 syscall 达到既有业务成功点后，Redis 后续失败不得反向修改文件系统。

### 5. hash freshness 与 retention 分离

`file_hash_revalidate_seconds` 继续决定 fresh/stale，默认一天；新增 `file_hash_retention_seconds` 决定 Redis 最长不活跃时间，默认 2592000 秒（30 天）且必须严格大于 revalidate。每次成功 lookup、claim、heartbeat 或计算提交更新 expiry ZSET deadline。

- 年龄不超过 revalidate：直接返回 fresh。
- 超过 revalidate、未超过 retention且 fingerprint 相同：立即返回 stale，并原子安排 refresh。
- record 缺失、retention 到期或 fingerprint 不同：不返回旧值，建立 pending 并返回 202。
- failed 且仍在 backoff：有旧 hash则返回 stale；没有旧值返回 503。

不让 retention 等于 revalidate，是为了避免缓存刚进入 stale 状态就被删除，从而破坏 stale-while-revalidate。备选方案是永久保留所有 hash；这与 PostgreSQL 可接受，但在承担上传控制状态的 Redis 中会造成无上限内存增长。

### 6. AOF 恢复只信任实际存在的证据

正常 Qtserver 重启不改变 Redis 状态。Redis 重启后，TTL 使用原绝对 deadline，worker 从 due queue 接管已超时 lease；上传从恢复出的 confirmed offset 继续。

异常停止时，`everysec` 可能缺少最近写入：

- 丢失 PATCH checkpoint：客户端看到较旧 confirmed offset并覆盖重传；cache file 多出的 bytes 不被当成已确认进度。
- 丢失 hash/worker state：按 cache miss 重建；正式文件保持有效。
- 丢失 lock/lease：新请求可重新竞争；既有 advisory-lock 限制不变。
- 丢失 publish intent/committed：只有恢复出的 intent 与 target/cache identity 能证明本 session 发布时才收敛为 committed；证据不足时返回现有 session-missing 或 target-conflict 结果，由 qtransc 重新 init 并通过正式文件 size/hash 检查收敛。

不额外对每个关键写入调用同步磁盘 fsync，也不引入 `WAIT`/replica acknowledgement。这样保留 `everysec` 的延迟特性，但必须接受最后一秒幂等证据可能丢失。若以后业务要求“complete 一经确认绝不丢 committed”，需要另行提升 durability contract，而不是在此实现中暗示已有保证。

### 7. 删除 PostgreSQL 生命周期，不提供双写

server bootstrap 只构造 `RedisStore`、检查 AOF 并将其注入 handler/hashmanager。删除 `internal/database`、`db` Cobra command、`PostgresConfig`、schema health check 和 `pgx` 依赖。`config validate` 仍保持纯本地校验，不连接 Redis；AOF 校验只发生在 `run` 启动与运行期 health check。

迁移不双写 PostgreSQL 与 Redis。双写无法解决 Redis 与 PostgreSQL 之间的原子性，反而会延长两套状态源并存时间。新版本使用 `v2` hash namespace cold start，旧 `official-hash` cache 和 PostgreSQL `file_hashes` 都不参与读取。

## Risks / Trade-offs

- [Redis 成为更集中的单点，故障会同时影响上传、hash 和身份缓存] → 保持 fatal shutdown，要求持久 volume/AOF/容量告警；HA 属于后续独立变更。
- [AOF `everysec` 可能丢失最近约一秒状态] → 明确恢复边界，利用覆盖重传、cache miss 重算和文件系统事实收敛；不声称零丢失。
- [hash record 和 path/expiry/due 多索引可能产生 orphan member] → 所有变更用脚本维护；claim、tree invalidation 和 GC 都惰性清理缺失 record 的 member，并记录指标。
- [目录含大量缓存对象时 subtree invalidation 耗时] → 在 namespace lock 内按有界 batch 处理，续租 lock并暴露批次数/耗时；避免单个长 Lua 阻塞 Redis。
- [全局 `noeviction` 使内存满时新写直接失败] → hash 使用 30 天滑动 retention，部署前估算峰值 session/chunk/hash 数，监控 `used_memory`、`maxmemory`、rejected writes 和 key cardinality。
- [AOF rewrite 增加磁盘空间与 I/O] → 持久卷预留 rewrite 峰值空间，监控 AOF size、rewrite status 和 fsync latency；rewrite failure 本身告警，实际 AOF write failure 触发服务退出。
- [旧 PostgreSQL 在新版本运行期间变 stale，不能直接无损回滚] → 回滚前停止新版本并清空旧 `file_hashes` hash 数据后 cold start，保留正式文件和 Redis upload 数据。
- [Redis ACL 若禁止 CONFIG/INFO 会使启动失败] → 部署显式授予最小只读 `CONFIG GET`/`INFO persistence` 权限；不授予运行期修改配置权限。

## Migration Plan

1. 维护前备份 Qtserver 配置和 PostgreSQL；确认 Redis 版本支持所用 Lua/command，并核算 persistent volume、AOF rewrite 和峰值内存空间。
2. 为 Redis 配置持久 volume、`appendonly yes`、`appendfsync everysec`、`maxmemory-policy noeviction` 和所需 ACL。若要保留当前 active session，先冻结 Qtserver 写流量，再把现有 Redis dataset 以快照方式导入新持久实例，等待 AOF initial rewrite 完成且 persistence 状态正常；否则明确接受 session cold start和 orphan scanner 清理。
3. 停止入口流量及全部 Qtserver 实例。新旧版本不得滚动混跑，因为 hash coordination source 不同。
4. 部署新 binary 和删除 `[postgres]`、新增 `file_hash_retention_seconds` 的配置。启动一个实例，确认 AOF preflight、hash cold-cache worker、上传恢复和 fatal health check正常，再启动其余实例并恢复流量。
5. 观察 Redis memory、AOF size/fsync、hash due/expiry cardinality、worker claim/接管和 `SESSION_NOT_FOUND`。PostgreSQL 暂时只读保留，不再接受 Qtserver 连接。
6. 稳定期结束后由运维单独下线 PostgreSQL，并按数据保留策略删除旧 `official-hash` Redis namespace；不得用宽泛 `FLUSHDB` 清理。

回滚时先停止流量和所有新 Qtserver，恢复旧 binary 与包含 `[postgres]` 的旧配置。由于新版本期间的文件 mutation 未双写 PostgreSQL，恢复服务前必须备份后清空旧 `file_hashes` 内容，使旧版本按 cold cache 重建；不得复用其中可能过期的 generation/hash。Redis AOF 和 upload keys 保留，旧版本若兼容现有 upload key 格式可继续恢复，否则按 `SESSION_NOT_FOUND` 重新 init。完成单实例验证后再恢复其他旧实例与流量。
