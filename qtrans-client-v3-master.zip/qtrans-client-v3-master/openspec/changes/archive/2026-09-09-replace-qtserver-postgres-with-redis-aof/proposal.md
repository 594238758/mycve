## Why

Qtserver 当前仅使用 PostgreSQL 保存可由正式文件重建的 hash 元数据和 worker 状态，却因此引入第二套共享数据服务、独立 migration 与全服务 fatal dependency。既有 Redis 已承担上传控制状态和跨实例协调，统一由启用 AOF 的 Redis 保存这些状态，可以降低部署与运维复杂度，同时继续保留双实例共享、上传恢复和 hash 异步计算能力。

## What Changes

- **BREAKING** 移除 Qtserver 的 `[postgres]` 配置、PostgreSQL 启动/运行期健康检查、schema 校验和 `qtserver db migrate` CLI；旧配置继续包含 `[postgres]` 时将因未知字段被拒绝。
- Redis 成为 Qtserver 唯一的共享状态服务和 fatal data dependency，并要求部署使用持久 volume、启用 AOF 和 `appendfsync everysec`；上传 session、chunk、publish intent、committed result、锁、短期身份缓存和 hash 状态均进入同一持久化数据集。
- 将正式文件 hash 从 PostgreSQL 可靠元数据改为 Redis 中可丢失、可重建的缓存；正式文件系统仍是内容事实源，cache miss、过期或 fingerprint 不匹配时继续通过异步 worker 计算并由客户端轮询。
- 使用 Redis 原子操作或 Lua 脚本实现 hash generation fencing、任务领取、heartbeat、超时接管、失败退避和已知 hash 提交，保持多 Qtserver 实例下的协调语义。
- Redis/AOF 恢复后的未过期上传和 committed 状态继续可用；锁和 lease 按原绝对过期时间继续失效。AOF 最近写入丢失、hash retention 到期或显式清空仍按可恢复状态丢失处理，不把 Redis 提升为正式文件内容的事实源。
- 保持现有 HTTP API、请求/响应结构、hash 算法、下载 grant HMAC 与 TTL、qtransc 本地 SQLite 恢复协议不变。首次部署不迁移 PostgreSQL 中的历史 hash，按 cold cache 重新计算。
- 非目标：不引入 Redis Cluster、Sentinel、跨 Redis 与文件系统事务、按 key 部分持久化、PostgreSQL hash 数据导入或新的客户端协议。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `service-capability-discovery`: 移除 PostgreSQL 配置、migration 和 fatal dependency，规定 Redis AOF 持久化部署及唯一共享状态依赖。
- `file-hash-management`: 将 PostgreSQL hash 状态机替换为 Redis 持久化缓存和原子 worker 协调，重新定义缓存丢失与恢复语义。
- `resumable-upload`: 移除 complete/create 路径中的 PostgreSQL 提交边界，并规定 Redis AOF 恢复、最近写入丢失和正式文件发布后的收敛行为。
- `file-management`: 移除文件 mutation 对 PostgreSQL generation 的依赖，改为 Redis hash generation/cache 失效与发布后 best-effort 更新。

## Impact

- 代码：删除 `qtserver/internal/database`、`pgx` 依赖、数据库 CLI 与 PostgreSQL handler wiring；扩展 `internal/store` 和 `internal/hashmanager` 的 Redis 状态模型及原子脚本。
- 配置/CLI：删除 `[postgres].dsn` 和 `qtserver db migrate`；新增 `file_hash_retention_seconds`，部署额外要求 Redis AOF、持久 volume、`noeviction` 和容量监控。
- API：无结构性协议变更；迁移后的 cold cache 可能使首次 file verify 或同大小目标检查暂时返回既有 `202 HASH_PENDING`。
- 部署迁移：维护窗口内停止入口流量和 Qtserver，升级 Redis 持久化配置并挂载数据目录，部署删除 `[postgres]` 的配置和新 Qtserver；旧 PostgreSQL 暂时保留可支持回滚，确认稳定后再由运维单独下线。
- 可靠性：减少 PostgreSQL 一个公共故障点，但 Redis 成为更集中的共享状态与恢复边界；AOF `everysec` 允许最近约一秒写入丢失，必须继续依赖 session 幂等、checkpoint 覆盖重传和文件系统事实收敛。
