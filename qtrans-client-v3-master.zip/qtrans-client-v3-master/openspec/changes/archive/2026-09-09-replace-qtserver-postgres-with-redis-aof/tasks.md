## 1. 配置、CLI 与依赖收敛

- [x] 1.1 从 `Config`、默认值、严格校验和 redaction 中移除 `PostgresConfig`/`[postgres]`，新增默认 2592000 且大于 `file_hash_revalidate_seconds` 的 `file_hash_retention_seconds`。
- [x] 1.2 删除 `qtserver db migrate` Cobra command、`internal/database` 和 server bootstrap/health check 中的 PostgreSQL 生命周期，确保 `config validate` 仍不连接外部服务。
- [x] 1.3 删除 `pgx`/PostgreSQL 的 Go module 依赖并更新 qtserver 的默认、demo 和本地部署配置，使旧 `[postgres]` 配置被严格拒绝。

## 2. Redis durability 与 fatal dependency

- [x] 2.1 在 `RedisStore` 中实现 `PING`、`CONFIG GET appendonly appendfsync maxmemory-policy` 和 `INFO persistence` 的解析与 preflight，拒绝非 AOF、非 `everysec`、非 `noeviction` 或 AOF write status 异常的 Redis。
- [x] 2.2 将五秒运行期健康检查改为 Redis/AOF 和已启用 introspection provider 检查，移除 PostgreSQL 分支并保持 30 秒 graceful shutdown 语义。
- [x] 2.3 扩展 Redis error 分类，使连接、协议、`MISCONF`、OOM、损坏状态和意外 script error 触发 fatal reporter，同时排除 `redis.Nil`、CAS miss、锁冲突和脚本业务结果。

## 3. Redis hash 状态模型

- [x] 3.1 在 `internal/store` 定义版本化 hash record、SHA-256 identity digest、严格字段编解码以及 record/due/path/expiry/namespace-generation key helper。
- [x] 3.2 实现 `EnsurePending` 和 lookup Lua 状态转换，原子维护 fingerprint、generation、fresh/stale/failed 结果、due/path/expiry 索引，并使用 Redis `TIME` 计算 deadline。
- [x] 3.3 实现 `ClaimDue`、`Heartbeat`、`Submit` 和 `Fail` Lua 转换，支持五秒 polling/heartbeat、30 秒 lease 接管、calculation_id 与 generation/namespace-generation fencing、指数退避和 `NOSCRIPT` reload。
- [x] 3.4 实现 `BeginKnownMutation`、`CommitKnown`、exact invalidation 和有界 batch subtree invalidation，保证 record、due、path 与 expiry 索引在每批内原子一致。
- [x] 3.5 实现滑动 hash retention 和 `CollectExpired` batch GC，使 lookup、claim、heartbeat、submit 能续期，并惰性清理各索引中的 orphan member。

## 4. Hash manager 切换

- [x] 4.1 将 `hashmanager.Manager` 构造和 lookup 路径改为只依赖 RedisStore 与文件系统，删除 PostgreSQL query/cache 双层读取并保留 fingerprint 核对、202、503 和 stale-while-revalidate 结果。
- [x] 4.2 将 worker loop 改接 Redis due queue、lease 和原子提交 API，保留内存 notify 仅作唤醒优化，并在 heartbeat 丧失提交资格时停止或丢弃结果。
- [x] 4.3 接入 retention GC 与 namespace generation fencing，确保重启后的 pending/过期 calculating 可继续领取，长期不活跃 hash 可 cold-cache 重建。

## 5. 文件 mutation 与上传恢复边界

- [x] 5.1 将 create、complete、move 和 delete 的 hash mutation 调用切换到 Redis generation token；对目录 mutation 在文件系统操作前后 bump namespace generation 并完成 subtree invalidation。
- [x] 5.2 保持 rename/unlink 业务成功点：publish 前 Redis 故障阻止 mutation，publish 后 Redis/hash/committed 写入故障不回滚文件并触发 fatal shutdown。
- [x] 5.3 审核 upload session、chunk checkpoint、publish intent 和 committed 读写，使 AOF 恢复的较旧 offset 可覆盖重传，缺失 session/intent 不伪造幂等成功，并保持现有 HTTP/qtransc wire contract。
- [x] 5.4 将 file verify 和同大小目标检查接到 Redis hash manager，确认 chunk verify 仍同步计算且不创建正式 hash record。

## 6. 部署配置与编译验证

- [x] 6.1 更新仓库维护的 Redis 启动/部署配置，显式使用持久 volume、`appendonly yes`、`appendfsync everysec`、`maxmemory-policy noeviction` 及 Qtserver preflight 所需最小 ACL。
- [x] 6.2 对修改的 Go 源码执行格式化和 module metadata 整理，确认 qtserver 源码、配置示例和命令帮助中不再残留 PostgreSQL runtime 或 migration 入口。
- [x] 6.3 仅执行 qtserver 必需的编译检查，确认 server 和 CLI 成功构建；不在本 change 中新增或运行 test/benchmark。
