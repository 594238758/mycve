## MODIFIED Requirements

### Requirement: Redis 是上传控制状态唯一事实源

Redis SHALL 保存 active/committed session、chunk state、stored offset、chunk hash、retention、publish intent 和 coordination locks，并通过 AOF 持久化。二进制 SHALL 只保存在 temp_root 中一个未预分配 sparse cache file。Qtserver SHALL NOT 使用其他数据库保存未完成 session 或 chunk 进度。

#### Scenario: Redis 中 session 丢失

- **WHEN** cache 可能仍存在但恢复后 Redis active/committed key 不存在
- **THEN** 上传 API SHALL 返回 `SESSION_NOT_FOUND`
- **AND** cache SHALL 只由 orphan scanner 清理

#### Scenario: AOF 恢复未过期 session

- **WHEN** Redis 重启并从 AOF 恢复尚未过期的 active 或 committed session
- **THEN** Qtserver SHALL 按恢复的 chunk、offset、intent 或结果继续提供现有恢复协议
- **AND** SHALL NOT 因 Qtserver 或 Redis 重启创建新的 session identity

#### Scenario: 创建 cache file 失败

- **WHEN** init 已创建 Redis session 但无法创建 cache file
- **THEN** 服务 SHALL 删除 Redis session 并返回请求级错误

#### Scenario: Redis 连接失败

- **WHEN** init、PATCH checkpoint 或其他命令发生 Redis 连接级故障
- **THEN** 当前请求 SHALL 返回 500 `INTERNAL_ERROR`（若仍可响应）
- **AND** Qtserver SHALL 触发 fatal graceful shutdown

#### Scenario: AOF 只恢复较旧 checkpoint

- **WHEN** Redis 异常停止且最近 PATCH checkpoint 未进入 AOF
- **THEN** GET session SHALL 返回 AOF 中实际恢复的较旧 confirmed offset
- **AND** qtransc SHALL 按现有 offset 协议覆盖重传未确认 bytes

### Requirement: 正式 hash persistence 不回滚已发布文件

complete SHALL 在 publish 前原子更新 Redis generation，并在 publish 后以 generation CAS 写入已知 file hash。Redis 在 publish 前故障 SHALL 阻止发布并触发 shutdown；publish 后写入时才发现依赖故障 SHALL 保留文件、best-effort 返回成功并触发 shutdown，SHALL NOT 回滚。恢复时缺少最近已知 hash SHALL 被视为 cache miss，不得使正式文件失效。

#### Scenario: rename 后 Redis 断开

- **WHEN** 文件已发布但正式 hash 写入检测到 Redis 连接故障
- **THEN** 新文件 SHALL 保持可见
- **AND** Qtserver SHALL 触发 fatal graceful shutdown

#### Scenario: publish 后 hash 写入未进入 AOF

- **WHEN** 文件已发布且 Redis 曾接受已知 hash，但恢复后的 AOF 不包含该写入
- **THEN** 新文件 SHALL 保持可见
- **AND** 后续 hash 请求 SHALL 重新建立 pending 计算

### Requirement: complete 使用 publish intent 收敛提交窗口

no-overwrite complete SHALL 在不可逆 publish 前保存包含 target 和 cache 文件身份的 Redis publish intent。intent SHALL 只用于幂等协调文件系统事实与 AOF 中实际恢复的 session 状态，不得被视为文件系统与 Redis 之间的分布式事务或 fencing token。complete 重试 SHALL 比对 cache、target 和恢复出的 intent：由本 session 发布的同一文件身份 SHALL 收敛为 committed；不同文件身份 SHALL 按目标冲突处理且不得覆盖。若最近 intent 或 committed 写入未进入 AOF，服务 SHALL 降级到恢复出的 Redis 状态和文件系统事实，SHALL NOT 在缺少证据时伪造幂等成功。

#### Scenario: intent 后 publish 前重启且 intent 已恢复

- **WHEN** publish intent 已进入 AOF、target 尚未创建且服务重启
- **THEN** complete 重试 SHALL 使用保留的 cache 继续原子发布

#### Scenario: publish 后 committed 前重启且 intent 已恢复

- **WHEN** target 已由本 session 发布、committed 尚未保存且 intent 已从 AOF 恢复
- **THEN** complete 重试 SHALL 识别 target 文件身份并继续写入 committed 结果
- **AND** SHALL NOT 返回 target conflict 或重新传输文件内容

#### Scenario: intent 存在但 target 属于其他 writer

- **WHEN** complete 重试发现 target 文件身份与 intent 记录的 cache 身份不同
- **THEN** complete SHALL 按目标冲突处理且不得覆盖

#### Scenario: 最近 intent 未进入 AOF

- **WHEN** target 已发布但 Redis 恢复状态不包含可证明本 session 所有权的 publish intent 或 committed 结果
- **THEN** complete SHALL NOT 猜测 target 由本 session 发布
- **AND** MAY 返回 `SESSION_NOT_FOUND` 或现有 target conflict，使客户端通过现有重新 init 和同 hash 检查收敛

#### Scenario: 两个 no-overwrite writer 并发

- **WHEN** 两个 no-overwrite complete 并发发布同一路径
- **THEN** 至多一个 SHALL 新建成功
- **AND** 另一个 SHALL 得到已存在冲突或可证明的幂等结果而不得覆盖
