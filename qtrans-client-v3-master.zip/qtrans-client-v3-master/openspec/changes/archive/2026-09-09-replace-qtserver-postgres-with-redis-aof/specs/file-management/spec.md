## MODIFIED Requirements

### Requirement: create 写入正式hash并遵守成功点

create SHALL 生成固定空文件 hash，在 publish 前原子更新 Redis generation，并在 publish 后以 generation CAS 写入已知 hash。rename 前的 permission、fsync 或 Redis 故障 SHALL 阻止发布；rename 后 parent fsync 或依赖故障 SHALL NOT 回滚，服务 SHALL 尽量返回成功并按规则记录或退出。恢复时缺少最近 hash 写入 SHALL 被视为可重建的 cache miss。

#### Scenario: rename后parent fsync失败

- **WHEN** empty file已rename到target但parent fsync失败
- **THEN** create SHALL 返回成功并记录高等级错误
- **AND** SHALL NOT unlink新文件

#### Scenario: rename 后 Redis 断开

- **WHEN** 文件已发布而 hash persistence 检测到 Redis 连接故障
- **THEN** 文件 SHALL 保持正式可见
- **AND** Qtserver SHALL 触发 fatal graceful shutdown

#### Scenario: 已知空文件 hash 未从 AOF 恢复

- **WHEN** 文件已发布但恢复后的 Redis 不包含其已知 hash
- **THEN** create 的文件事实 SHALL 保持有效
- **AND** 后续 hash 请求 SHALL 重新建立 cache

### Requirement: verify 区分file和chunk

file verify SHALL 使用 Redis 正式 hash cache：无可用 hash 时返回 202，hash 可用时返回 200 并包含 match、calculated_hash 和 hash_algorithm，mismatch 也 SHALL 是 200。chunk verify SHALL 同步读取最多一个 104857600-byte 区间并计算 `xxh3_128`，不得创建或修改正式 file hash record。

#### Scenario: file hash pending

- **WHEN** verify file 没有可返回正式 hash
- **THEN** 服务 SHALL 返回 202 `HASH_PENDING` 和 Retry-After 5

#### Scenario: verify mismatch

- **WHEN** client hash 与正式 hash 不同
- **THEN** 服务 SHALL 返回 200、`match=false` 和 calculated hash

#### Scenario: verify 单 chunk

- **WHEN** 请求验证一个合法 chunk 区间
- **THEN** 服务 SHALL 同步读取该区间并返回 `xxh3_128`
- **AND** SHALL NOT 创建 Redis file hash record
