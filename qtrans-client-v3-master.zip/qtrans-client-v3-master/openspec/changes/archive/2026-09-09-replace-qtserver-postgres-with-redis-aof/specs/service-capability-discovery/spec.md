## ADDED Requirements

### Requirement: Redis 是唯一共享状态 fatal dependency

Qtserver SHALL 在启动时成功执行 Redis PING 并校验 Redis AOF 状态；`identity.mode="oauth2-introspection"` 时，Qtserver SHALL 在开始监听前使用内置 client authentication 和一个进程内生成的 UUID v4 probe token 调用 introspection endpoint，并确认 response 符合 RFC 7662。Redis 或已启用 introspection provider 的连接、TLS、timeout、认证、HTTP status 或协议失败 SHALL 拒绝启动。服务 SHALL NOT 提供共享状态或身份服务的启动降级，也 SHALL NOT 在 fatal dependency 恢复后继续使用同一进程。

#### Scenario: Redis 启动时不可用

- **WHEN** Qtserver 无法完成 Redis PING 或读取必需的 persistence 状态
- **THEN** Qtserver SHALL 以非零状态拒绝启动

#### Scenario: introspection provider 启动时不可用

- **WHEN** 启用 `oauth2-introspection` 且 endpoint 无法完成 authenticated probe
- **THEN** Qtserver SHALL 以非零状态拒绝启动

#### Scenario: introspection probe 返回标准 active 结果

- **WHEN** probe 返回 HTTP 200 和结构合法的 boolean `active`
- **THEN** Qtserver SHALL 将 endpoint 判定为可用

### Requirement: Redis 使用可校验的 AOF 持久化

Qtserver 所连接的 Redis SHALL 使用持久 volume，启用 AOF，并配置 `appendfsync everysec`。Qtserver SHALL 在监听前校验 `appendonly=yes`、`appendfsync=everysec` 和 AOF 最近写入状态正常，并在每五秒健康检查中校验 AOF 仍启用且最近写入状态正常。Redis ACL SHALL 允许完成这些只读校验。该持久化等级 SHALL NOT 被解释为零数据丢失保证；Redis 或宿主机异常停止时，最近约一秒已确认写入 MAY 不在恢复后的 AOF 中。

#### Scenario: AOF 未启用

- **WHEN** Redis 可连接但 `appendonly` 不是 `yes` 或 `appendfsync` 不是 `everysec`
- **THEN** Qtserver SHALL 以非零状态拒绝启动

#### Scenario: AOF 写入状态异常

- **WHEN** 周期健康检查发现 AOF 最近写入状态不是正常状态
- **THEN** Qtserver SHALL 立即触发 fatal graceful shutdown

#### Scenario: Redis 从 AOF 重启

- **WHEN** Redis 重启并成功重放 AOF
- **THEN** AOF 中存在且尚未过期的上传、hash、intent、committed、lock 和 lease 状态 SHALL 可由 Qtserver 继续使用
- **AND** TTL 与 lease SHALL 按原绝对过期时间继续计算而不得因重启重新获得完整时长

#### Scenario: 最近写入未进入 AOF

- **WHEN** Redis 异常停止且恢复后的 AOF 不包含最近已确认的写入
- **THEN** Qtserver SHALL 只按实际恢复的 Redis 状态和文件系统事实处理请求
- **AND** SHALL NOT 推断丢失的 session、intent、lock、lease 或 hash 状态仍然存在

### Requirement: 仅 Redis 依赖故障终止共享状态服务

Redis 连接、TLS、timeout、认证、协议、AOF 配置或 AOF 写入状态故障 SHALL 按 fatal dependency 处理。锁冲突、CAS miss、key 不存在和查询无结果 SHALL NOT 被判定为依赖故障。既有 `auth` mode 的身份服务超时或拒绝、任意 provider 返回无效 token、单个 principal 目录错误、单次文件 I/O、磁盘满和客户端错误 SHALL 是请求级错误且 SHALL NOT 终止 Qtserver。只有启用 `oauth2-introspection` 时，该 provider 的连接、TLS、timeout、内置 client authentication、HTTP status 或协议故障 SHALL 按 fatal dependency 处理。

#### Scenario: 上传磁盘空间不足

- **WHEN** 单次 PATCH 因磁盘空间不足失败
- **THEN** 请求 SHALL 返回 507
- **AND** Qtserver SHALL 继续处理其他请求

#### Scenario: namespace lock 冲突

- **WHEN** 请求未获取同 principal namespace lock
- **THEN** 请求 SHALL 返回 409 `NAMESPACE_BUSY`
- **AND** Qtserver SHALL NOT 退出

#### Scenario: introspection 返回 inactive

- **WHEN** `oauth2-introspection` 返回结构合法的 `active=false`
- **THEN** 当前请求 SHALL 作为无效 token 失败
- **AND** Qtserver SHALL NOT 退出

#### Scenario: 既有 auth 服务超时

- **WHEN** `identity.mode="auth"` 的既有 `/userinfo` 请求超时
- **THEN** 请求 SHALL 按既有行为失败
- **AND** Qtserver SHALL NOT 因本变更退出

## MODIFIED Requirements

### Requirement: fatal dependency 故障触发 graceful shutdown

Qtserver SHALL 每五秒检查 Redis、Redis AOF persistence 和已启用 `oauth2-introspection` provider 的健康状态。健康检查或业务命令发现 connection refused、连接断开、TLS、timeout、认证、AOF 状态、HTTP status 或协议错误时，服务 SHALL 在第一次故障时立即开始 shutdown，SHALL NOT 等待连续多次失败或重试阈值。服务 SHALL 停止接受新连接，给予现有请求最多 30 秒完成，然后以非零状态退出。直接观察到 introspection provider 故障且仍可响应的认证请求 SHALL 返回 HTTP 503 `DEPENDENCY_UNAVAILABLE`；其他尚可响应且未完成的业务请求 SHALL 返回 HTTP 500 `INTERNAL_ERROR`，而不是降级结果。

#### Scenario: 运行期 Redis 断开

- **WHEN** Redis 健康检查或业务命令检测到连接级故障
- **THEN** Qtserver SHALL 触发 graceful shutdown
- **AND** SHALL NOT 等待 Redis 恢复后继续服务

#### Scenario: 运行期 Redis AOF 故障

- **WHEN** Redis persistence 健康检查或写命令检测到 AOF 已禁用或写入失败
- **THEN** Qtserver SHALL 触发同一 graceful shutdown 流程

#### Scenario: 正常 signal 停止

- **WHEN** Qtserver 收到 SIGINT 或 SIGTERM 且没有 fatal dependency
- **THEN** graceful shutdown 完成后的进程退出码 SHALL 为 0

#### Scenario: 运行期 introspection provider 故障

- **WHEN** 周期 probe 或业务 introspection 检测到 provider 故障
- **THEN** Qtserver SHALL 触发同一 graceful shutdown 流程
- **AND** SHALL NOT 等待第二次健康检查确认
- **AND** SHALL NOT 等待 provider 恢复后继续服务

### Requirement: 已完成文件系统修改不因依赖故障回滚

文件系统操作达到 rename、unlink 等业务成功点后，随后检测到 Redis 故障 SHALL NOT 回滚已经完成的正式文件修改。服务 SHALL best-effort 向当前请求返回成功，再触发 shutdown；如果来不及响应，客户端 MAY 看到连接断开。

#### Scenario: complete rename 后 Redis 断开

- **WHEN** complete 已原子发布正式文件但尚未写 committed response 时 Redis 断开
- **THEN** Qtserver SHALL 保留已发布文件且 SHALL NOT 反向 rename
- **AND** SHALL 触发 graceful shutdown

#### Scenario: delete unlink 后 Redis 断开

- **WHEN** delete 已完成不可逆 unlink 后检测到 Redis 故障
- **THEN** 删除 SHALL 保持生效
- **AND** 服务 SHALL 尽量返回成功后退出

### Requirement: 配置 schema 严格且 secrets 不泄漏

Qtserver SHALL 拒绝未知或旧配置字段，不从环境变量覆盖配置。`qtserver run` SHALL 只允许 `--port`、`--host`、`--loglevel` 和 `--logpath` 覆盖。配置 SHALL NOT 接受 `[postgres]` section；普通日志和配置输出 SHALL redact Redis password、HMAC secret、fake token keys、Authorization 和 anonymous token。

#### Scenario: config validate

- **WHEN** 运维运行 `config validate`
- **THEN** 命令 SHALL 只执行配置和本地路径的只读校验
- **AND** SHALL NOT 连接 Redis 或身份服务，也 SHALL NOT 创建目录

#### Scenario: 使用旧配置字段

- **WHEN** 配置包含 `[postgres]`、其他已删除字段或未知字段
- **THEN** validate 和启动 SHALL 失败

## REMOVED Requirements

### Requirement: PostgreSQL 和 Redis 是 fatal dependencies

**Reason**: Qtserver 不再连接 PostgreSQL；Redis 成为唯一共享状态服务和 fatal data dependency。

**Migration**: 部署先为 Redis 启用持久 volume、AOF 和 `appendfsync everysec`，再删除配置中的 `[postgres]` section 后启动新版本。

### Requirement: 仅连接级 PostgreSQL 和 Redis 故障终止服务

**Reason**: 故障分类不再包含 PostgreSQL，并新增 Redis AOF 配置及写入健康状态。

**Migration**: 使用新增的“仅 Redis 依赖故障终止共享状态服务”规则替代。

### Requirement: PostgreSQL migration 必须显式执行

**Reason**: Qtserver 删除 PostgreSQL schema 和 migration CLI，不再有数据库 DDL 生命周期。

**Migration**: 新版本不得运行 `qtserver db migrate`；旧 PostgreSQL 仅在回滚观察期由运维保留，稳定后单独下线。
