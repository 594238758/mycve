## ADDED Requirements

### Requirement: Redis 是正式 hash 的可重建缓存和协调状态源

Redis SHALL 保存 hash、fingerprint、`idle|pending|calculating|failed` 状态、calculation_id、generation、started/heartbeat、error/retry 和 next_retry_at。正式文件系统 SHALL 是内容事实源；Redis hash 状态丢失、过期或被明确清理时，Qtserver SHALL 从当前文件事实重新建立计算状态，SHALL NOT 要求从其他数据库恢复历史 hash。

#### Scenario: Qtserver 重启时存在 pending

- **WHEN** Redis AOF 恢复出尚未过期的 pending 记录
- **THEN** workers SHALL 继续从 Redis 领取这些记录
- **AND** 不得依赖重启前的内存 notification queue

#### Scenario: hash cache 丢失

- **WHEN** 正式文件存在但 Redis 不存在对应 hash 记录
- **THEN** 服务 SHALL 建立 pending 状态并按首次计算协议返回

#### Scenario: 已知 hash 写入未进入 AOF

- **WHEN** Redis 重启后的 AOF 不包含最近 create 或 complete 写入的已知 hash
- **THEN** 正式文件 SHALL 保持有效
- **AND** 后续 hash 请求 SHALL 按 cache miss 重新计算

### Requirement: workers 通过 Redis queue lease 和 heartbeat 协调

workers SHALL 每五秒从 Redis 的持久 pending 索引以原子操作领取到期记录。calculating worker SHALL 每五秒更新 heartbeat 和 lease；超过 30 秒无 heartbeat 的记录 MAY 由另一 worker以新的 calculation_id 原子接管。领取、续租、接管、失败退避和 generation CAS 提交 SHALL 使用 Redis 原子命令或 Lua script 完成，并使用 Redis server time 判断到期。默认 `hash_worker_count=2`、`hash_queue_size=1000`，两者 SHALL 大于 0。`file_hash_revalidate_seconds` SHALL 默认 86400 且必须大于 0。

#### Scenario: worker 进程退出

- **WHEN** calculating 记录超过 30 秒未更新 heartbeat
- **THEN** 另一健康实例 SHALL 能以新 calculation_id 原子接管并重新计算

#### Scenario: 必需计算 notification queue 已满

- **WHEN** 无 hash 请求创建 pending 但内存 notification queue 已满
- **THEN** pending SHALL 保留在 Redis 持久索引
- **AND** 请求 SHALL 继续返回 202 而不是丢失工作

#### Scenario: 旧 worker 延迟提交

- **WHEN** 记录已被接管或 generation 已被 mutation 更新
- **THEN** 旧 calculation_id 的提交 SHALL 被原子拒绝

### Requirement: 非活跃 hash cache 按固定 retention 清理

`file_hash_retention_seconds` SHALL 默认 2592000、必须大于 `file_hash_revalidate_seconds`，并作为 hash 记录的滑动 retention。成功读取、计算、领取或 heartbeat SHALL best-effort 续期；长期未访问且没有活动计算的记录 MAY 过期。服务 SHALL 使用显式 TTL 清理 hash cache，并要求 Redis `maxmemory-policy=noeviction`，不得以 maxmemory eviction 静默移除上传控制状态。

#### Scenario: 文件长期未访问

- **WHEN** hash 记录超过 retention 且没有活动计算
- **THEN** Redis MAY 删除该记录
- **AND** 下一次请求 SHALL 作为首次计算处理

#### Scenario: stale hash 仍在 retention 内

- **WHEN** fingerprint 匹配、hash 超过 revalidate 时间但记录尚未超过 retention
- **THEN** 服务 SHALL 继续按 stale-while-revalidate 返回旧值

#### Scenario: Redis 达到内存上限

- **WHEN** `noeviction` 下 Redis 拒绝写入而不是淘汰 key
- **THEN** Qtserver SHALL 将该 Redis 命令错误按 fatal dependency 处理
- **AND** SHALL NOT 静默丢弃 session 或 hash 协调状态

### Requirement: Redis 故障不使用同步 hash fallback

Redis 是 fatal dependency。运行期连接、协议或写入级故障 SHALL 触发 Qtserver graceful shutdown；服务 SHALL NOT 改为请求内同步扫描、只关闭 hash capability 或继续普通文件接口。

#### Scenario: verify 时 Redis 断开

- **WHEN** file verify 查询 Redis 时发生连接级故障
- **THEN** 请求 SHALL 返回 500 `INTERNAL_ERROR`（若仍可响应）
- **AND** Qtserver SHALL 触发 graceful shutdown

## MODIFIED Requirements

### Requirement: 正式 hash 按逻辑对象和算法版本标识

Redis hash identity SHALL 至少包含 principal、normalized object key、algorithm 和 version。不同逻辑路径 SHALL 有独立记录，即使它们当时指向同一个 inode。

#### Scenario: 同一 inode 有两个逻辑路径

- **WHEN** 两个 object key 通过 hard link 或 symlink 最终读取同一 inode
- **THEN** 服务 SHALL 独立缓存、失效和返回各自路径的正式 hash

#### Scenario: 算法升级

- **WHEN** 同一逻辑对象请求不同 algorithm/version
- **THEN** Redis SHALL 保存互不覆盖的记录

### Requirement: 正式 fingerprint 只使用 ctime mtime 和 size

Qtserver SHALL 以 `ctime_ns,mtime_ns,file_size` 判断正式文件事实是否变化，SHALL NOT 使用 inode 或 device ID。对服务外修改后同时恢复这三个属性导致 stale hash 的情况，SHALL 归入受信任运维边界。

#### Scenario: fingerprint 发生变化

- **WHEN** 当前 stat 的 ctime、mtime 或 size 与 hash 记录不同
- **THEN** 旧 hash SHALL 立即失效且不得作为 stale 值返回

#### Scenario: 正式文件已不存在

- **WHEN** hash lookup 发现对应 logical object 已不存在
- **THEN** 服务 SHALL 使 Redis generation、hash record 和相关索引失效
- **AND** SHALL 按对象不存在返回而不得返回旧 hash

#### Scenario: 运维恢复全部 fingerprint 字段

- **WHEN** 运维原地改变 bytes 后恢复 ctime、mtime 和 size 到记录值
- **THEN** 服务 MAY 继续返回旧 hash
- **AND** 本 change SHALL NOT 增加额外内容探测

### Requirement: 文件管理 mutation 主动失效 hash

create、complete、move 和 delete SHALL 对受影响逻辑路径主动更新 Redis generation 并失效 hash record。move SHALL NOT 把 source hash 记录迁移到 destination；destination 第一次需要 hash 时 SHALL 重新计算。目录 move 或 delete SHALL 对 source subtree 的所有已索引逻辑对象执行同样失效。

#### Scenario: move 文件

- **WHEN** `/a` 被移动为 `/b`
- **THEN** `/a` 的 hash SHALL 失效
- **AND** `/b` SHALL NOT 直接继承 `/a` 的记录

#### Scenario: 删除文件

- **WHEN** 正式文件被删除
- **THEN** 对应 Redis hash 状态和索引 SHALL 失效

#### Scenario: 移动目录

- **WHEN** `/dir` 被移动为 `/new-dir`
- **THEN** `/dir` subtree 中已索引 object key 的旧 generation SHALL 全部失效
- **AND** `/new-dir` subtree SHALL 不继承旧路径 hash

### Requirement: fresh 和 stale hash 使用 stale-while-revalidate

fingerprint 匹配且 hash 年龄不超过 `file_hash_revalidate_seconds` 时 SHALL 直接返回 fresh hash。超过该时长但仍在 retention 内时 SHALL 立即返回现有 hash 并 best-effort 安排后台刷新；普通下载 SHALL NOT 等待刷新。

#### Scenario: hash 已到 revalidate 时间

- **WHEN** 请求命中 fingerprint 相同的过期 hash
- **THEN** 服务 SHALL 返回旧值
- **AND** SHALL 原子地将记录置为或保留为 pending refresh

#### Scenario: refresh notification queue 已满

- **WHEN** stale hash 已可返回但内存 notification queue 已满
- **THEN** 请求 SHALL 仍成功
- **AND** worker SHALL 通过 Redis pending 索引最终发现工作

### Requirement: 首次计算使用 202 轮询

fingerprint 当前但没有可用 hash 时，请求 SHALL 在 Redis 建立或保留 pending 状态，并返回 HTTP 202 `HASH_PENDING` 和 `Retry-After: 5`；SHALL NOT 在长 HTTP 请求内同步扫描完整正式文件。普通 download 不要求 hash 时 SHALL 正常传输。

#### Scenario: init 检查同大小正式目标

- **WHEN** overwrite=false、目标 size 相同但正式 hash 尚不可用
- **THEN** init SHALL 返回 202 `HASH_PENDING` 与 Retry-After 5

#### Scenario: 普通文件正在计算 hash

- **WHEN** 客户端只请求普通下载而 hash 状态是 pending
- **THEN** 下载 SHALL 不等待 hash worker

### Requirement: Redis hash cache 仍须核对 fingerprint

Redis hash record SHALL 包含 hash、algorithm、version、fingerprint、calculated_at 和 generation。cache hit 时 Qtserver SHALL 重新 stat 并比较 fingerprint；记录超过 revalidate 时间 SHALL 按 stale-while-revalidate 处理，记录缺失或 retention 过期 SHALL 按首次计算处理。

#### Scenario: cache entry 对应旧 fingerprint

- **WHEN** Redis 命中但当前 ctime、mtime 或 size 不同
- **THEN** 服务 SHALL 丢弃 cache hit 并原子失效旧 generation

## REMOVED Requirements

### Requirement: PostgreSQL 是正式 hash 可靠状态源

**Reason**: 正式文件 hash 改为 Redis 中可丢失、可重建的缓存和 worker 协调状态，文件系统承担内容事实源。

**Migration**: 不导入 PostgreSQL 历史 hash；升级后按 cold cache 在首次访问时重建。

### Requirement: PostgreSQL schema 必须由显式 migration 管理

**Reason**: hash 状态不再依赖关系型 schema 或 DDL migration。

**Migration**: 删除 `file_hashes` migration 和 `qtserver db migrate` 使用路径。

### Requirement: workers 通过数据库 polling 和 heartbeat 协调

**Reason**: worker 状态机改由 Redis 持久 pending 索引、lease 和原子脚本协调。

**Migration**: 使用新增的“workers 通过 Redis queue lease 和 heartbeat 协调”规则替代。

### Requirement: 正式 hash 不按访问年龄主动清理

**Reason**: Redis 是容量有限的共享状态服务，hash 又可从正式文件重建，因此需要有界 retention。

**Migration**: 使用 `file_hash_retention_seconds`；过期记录在下次访问时重算。

### Requirement: PostgreSQL 故障不使用同步 fallback

**Reason**: PostgreSQL 已删除，fatal dependency 边界转移到 Redis。

**Migration**: 使用新增的“Redis 故障不使用同步 hash fallback”规则替代。
