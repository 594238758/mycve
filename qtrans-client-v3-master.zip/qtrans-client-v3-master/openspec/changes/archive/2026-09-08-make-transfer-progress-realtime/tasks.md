## 1. 上传实时进度基础

- [x] 1.1 为上传 chunk、文件和任务补齐并发安全的 live logical、server-confirmed 与 network bytes 计数及有界访问方法
- [x] 1.2 实现按 chunk 绝对 live 值传播原子差值到文件和任务的更新路径，保证并行 chunk、重试和回退不会重复累计或越界
- [x] 1.3 在上传 PATCH request body 每次读取到 payload 后立即更新 chunk、文件和任务 live progress 与 network bytes
- [x] 1.4 在 PATCH 成功、失败、offset mismatch、session 恢复和服务端 offset 重置路径中校准 confirmed/live progress，同时保持既有 finalize/complete 完成判定

## 2. 内部速率采样与事件发布

- [x] 2.1 将上传任务、活动文件和活动 chunk 的 rate 改为按实际 network bytes 由不超过 300ms 的任务级内部采样器更新
- [x] 2.2 将普通下载任务、活动文件和活动 chunk 的 rate 统一为按实际 network bytes 由不超过 300ms 的任务级内部采样器更新
- [x] 2.3 将 task/file/chunk progress event reporter 与 rate sampler 分离，使 `sse.progressInterval` 只节流周期发布，并在生命周期终态强制发布最终快照

## 3. 下载实时文件生命周期

- [x] 3.1 确认并调整普通下载 payload reader，使每次正数字节读取都并发安全地更新 chunk、文件和任务 live progress 与 network bytes
- [x] 3.2 为 small download 建立活动文件生命周期，在读取 tar payload 时加入 `TransferingFiles` 并逐次更新文件和任务的 logical/network 计数与 rate
- [x] 3.3 在 small download 文件成功、失败及 fallback 路径强制发布最终 progress/status、清理活动文件，并保持非 payload tar 字节不计入进度

## 4. 实时快照与兼容性

- [x] 4.1 统一 task/file/chunk 的并发安全快照访问，确保 CLI 与 REST summary/detail 每次读取当前内存 progress 和 rate
- [x] 4.2 调整 upload2/download2 WebSocket `query-progress` 快照读取，保持现有字段、单位、状态映射和 SSE `transfered` 拼写兼容
- [x] 4.3 更新 `qtransc/docs/qtransc-apis.md`，说明实时内存进度、上传回退、内部 rate 采样及 `sse.progressInterval` 发布语义

## 5. 代码质量验证

- [x] 5.1 对变更的 Go 源文件执行 `gofmt`
- [x] 5.2 执行 `go build ./...`，确认 qtransc 相关代码编译通过
- [x] 5.3 执行 `git diff --check`，检查本次变更没有空白错误
