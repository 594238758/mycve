## Why

qtransc 当前上传任务只在一个 canonical chunk 的 PATCH 完成后推进文件和任务 `transferred`，导致大文件上传期间进度长时间停滞、文件速率为零后突增；small download 也没有可持续观察的活动文件进度。进度状态应由实际字节流持续驱动，CLI、REST、SSE 或 WebSocket 的读取周期只决定观察频率，不应决定内存状态的新鲜度。

## What Changes

- 上传过程中按 HTTP request body 实际读取的 payload bytes 持续更新 chunk、文件和任务的内存进度，不再等待整个 100 MiB chunk PATCH 完成。
- 上传分别维护 server-confirmed progress、当前 in-flight progress 和实际 network bytes；失败或恢复时按服务端 offset 校准，重传字节不伪造新的逻辑完成量。
- 上传文件速率改为根据该文件实际发送的 network bytes 计算，任务速率继续根据任务实际 network bytes 计算，避免 confirmed progress 跳变造成零速或虚高。
- 普通下载继续按 response body 每次读取更新进度，并把文件速率更新周期缩短为独立的近实时内存采样，不依赖外部查询或 SSE 周期。
- small download 在写入每个 tar payload 时登记活动文件、持续更新文件和任务内存进度与速度，并在文件完成后移出活动集合。
- `sse.progressInterval` 只控制进度事件的对外发布节流；REST、CLI 和 WebSocket 每次读取均直接获得当时最新的内存快照。
- 修正 task/file/chunk progress 的发布周期实现与 qtransc API 文档，使配置周期对各层级一致生效；不因进度事件订阅者数量改变内部计数。
- 保持现有 REST、SSE、WebSocket JSON 字段和 CLI 参数兼容，不新增必填字段。

非目标：不改变 Qtserver 上传、下载 HTTP 协议，不改变 canonical chunk size、断点续传持久化周期、任务完成判定、业务日志统计口径或限速语义。

## Capabilities

### New Capabilities

- `client-transfer-progress`: 定义 qtransc 上传、普通下载和 small download 的实时内存进度、速率采样及 CLI/REST/SSE/WebSocket 观察语义。

### Modified Capabilities

无。

## Impact

- 主要代码：`qtransc/internal/uploadtask`、`qtransc/internal/downloadtask`、进度事件发布与 CLI 快照展示。
- 外部接口：现有 REST task summary/detail、SSE `task_progress|file_progress|chunk_progress` 和 upload2/download2 WebSocket 进度对象的字段不变，但运行中数值将更及时、上传进度可能在请求失败并与服务端 offset 校准时回退。
- 文档：同步更新 `qtransc/docs/qtransc-apis.md` 中的进度新鲜度、采样与发布周期说明。
- 迁移：无需配置、数据库或协议迁移；现有调用方可以继续按原频率轮询或订阅。
