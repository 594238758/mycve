## Context

当前 qtransc 有两套不同的进度来源：普通下载在 response body `Read` 时同时增加 chunk、file和task transferred；canonical upload 的 request body reader只增加task `NetworkSent`，file/task transferred直到整个PATCH返回204后才按server-confirmed chunk size跳变。任务rate每300ms从network bytes采样，而文件rate每1秒从logical transferred差值计算，因此上传文件rate与实际发送流量脱节。small download虽然逐32 KiB增加file/task计数，却不把当前文件放入`TransferingFiles`，也没有周期性文件rate。

CLI每120ms直接读取task对象；REST summary/detail与legacy WebSocket也直接构造快照；SSE通过event bus发布节流后的快照。设计需要让这些观察方式共享同一实时内存事实，同时保留上传服务端offset对断点恢复的权威性。

## Goals / Non-Goals

**Goals:**

- payload读操作完成后立即反映到内存live progress。
- 将logical progress、confirmed progress和actual network traffic分开，保证重试与恢复可校准。
- 任务、文件和chunk rate由固定内部采样器维护，不依赖任何外部读取或事件订阅。
- 所有对外快照读取并发安全且字段兼容。
- 统一SSE task/file/chunk progress的发布节流。

**Non-Goals:**

- 不把客户端读取request body解释成Qtserver持久确认或业务成功。
- 不改变Qtserver offset checkpoint、chunk/finalize/complete协议或`.progress`/SQLite持久化频率。
- 不保证一次快照的所有字段来自同一个全局事务时刻；只保证各计数有效且不会撕裂。
- 不新增精确到TCP/QUIC wire overhead的速度统计，rate仍只统计文件payload bytes。

## Decisions

### 1. 每层进度同时维护logical、confirmed和network三个概念

上传chunk增加独立的live logical counter与network counter，既有server stored状态作为confirmed counter。每次PATCH开始时以confirmed offset作为attempt base；request body每次正数Read后，把该chunk live值设为`base + attemptRead`并用新旧差值原子调整file/task live transferred，同时分别增加chunk/file/task network bytes。

使用“设为绝对live值并传播差值”，而不是在file/task上直接累加每次Read，可以在并行chunk、重试和服务端校准时避免重复累计。PATCH成功后confirmed/live设为chunk total；失败或GET session返回新stored offset时用同一setter校准，允许运行中进度回退。finalize mismatch重置为0时也按服务端事实回退。task/file完成状态继续使用现有协议状态。

备选方案是把每次发送都永久累加到`transferred`。它能保证单调但会把重传算成逻辑完成量并可能提前到100%，因此只适合`network bytes`，不用于progress。

### 2. 固定内部rate sampler与外部event reporter分离

upload和download task各自保留一个生命周期内的固定300ms rate sampler。Sampler从task及活动file/chunk的network counters计算实际elapsed区间速率并应用当前滑动平均；它不读取`sse.progressInterval`，也不检查publisher/subscriber。

另设progress event ticker，仅按`sse.progressInterval`读取当前内存快照并发布task以及当时活动的file/chunk progress。生命周期边界可以强制发布最终快照。这样把配置为300ms或5s都只改变事件量，不改变CLI/REST/WebSocket可读取的内存新鲜度和rate采样。

备选方案是在现有file tracker中同时计算rate和发布事件，但它使内部rate周期受SSE配置影响，并继续为每个文件/分片创建重复ticker，因此不采用。

### 3. 上传和下载为每个活动文件维护network counter

上传增加file/chunk实际发送bytes；任务既有`NetworkSent`保持外部detail和最终平均速度语义。普通下载的`NetworkReceived`继续记录实际payload；file/chunk也各自记录network bytes。Logical progress与network bytes在无重试时通常相同，但hash mismatch、offset回退和重传时允许不同。

rate读取network counter，因此服务端确认停顿时上传文件rate仍反映当前发送速度；logical progress校准回退不会制造负速率或虚高峰值。

### 4. small download显式进入活动文件生命周期

处理tar payload entry时，在第一个payload read前设置文件上下文、发布started并加入`TransferingFiles`；每次read同时增加file/task logical与network计数。结束时强制发布file progress，随后发布completed并移出活动集合。失败时发布最终progress和failed，并移出集合；完整性失败后的普通下载fallback先按现有规则回滚logical进度，network bytes保留实际成本。

Tar session、manifest、header与padding不属于文件payload，不进入progress和rate。极小文件可能在外部周期事件发生前完成，但强制终态事件保证SSE观察者至少获得最终状态；REST/CLI只有在文件仍活动时才可能看到它，这是轮询快照的自然边界。

### 5. 快照字段使用原子读取并集中做边界归一化

所有并发写入的transferred、network和rate使用atomic；summary/detail、CLI和WebSocket构造器统一通过访问方法读取，不再混用普通读写。文件/任务live setter将值限制在`0..total`，task汇总通过chunk/file差值维护，避免每次查询遍历后再计算导致观察接口行为不一致。

现有JSON字段保持不变，包括SSE历史拼写`transfered`。不新增confirmed或network字段到summary；upload/download detail中已有的task network字段继续保留。confirmed仅是内部正确性事实。

### 6. 进度发布只遍历当前活动对象

task reporter在每个event tick发布一个task progress，并从`TransferingFiles`快照中发布活动file progress；普通下载只发布当前活动chunk，上传也只发布已开始且未终态的chunk。最终chunk/file progress在生命周期结束时强制发布，避免当前上传实现每秒为全部未开始chunk产生零值事件。

## Risks / Trade-offs

- [上传失败后live progress可能回退] → 文档明确live包含in-flight且Qtserver offset权威；UI不得把progress单调性当作成功判定。
- [每次payload Read增加atomic操作] → 每次网络读通常是KB级，额外固定原子操作相对I/O成本较小；不在每字节执行。
- [rate sampler遍历大量活动chunk] → 只遍历受并发上限约束的活动file/chunk，不遍历整个任务的全部未开始chunk。
- [极小small文件无法被低频REST轮询捕获为active] → 内存生命周期仍正确，并强制发布最终SSE事件；REST不保留历史active快照。
- [状态校准与并发snapshot产生短暂跨字段时差] → 每个字段原子且有界，任务状态仍独立决定完成；不引入全局锁阻塞数据流。

## Migration Plan

1. 部署新版qtransc；无需Qtserver、数据库或配置迁移。
2. 现有CLI、REST、SSE和WebSocket调用方保持原字段解析逻辑；允许运行中上传百分比在错误恢复时回退。
3. 回滚到旧版只会恢复chunk完成后跳变的展示行为，不影响服务端session或本地恢复数据。
