## Why

`upload2`/`download2` 当前仅在传输结束后等待协调方查询终态 2 秒。GUI 的 `query-progress` 定时器一旦因主进程繁忙或调度延迟错过该窗口，qtransc 就会在未返回 `1003` 或错误码的情况下关闭 WebSocket，导致 GUI 长期停留在最后一次 `1002` 的 100% 进度状态。

## What Changes

- 将 `upload2` 和 `download2` 的 WebSocket 终态确认窗口从 2 秒统一延长为 30 秒。
- 保持现有请求—响应协议不变：qtransc 仍在收到 `query-progress` 后返回 `1003` 或错误码，不新增主动推送、请求类型、字段或确认帧。
- 30 秒内未收到终态查询时，qtransc 仍按原有 best-effort 语义关闭连接，并由传输结果决定进程退出码。
- 兼容性：GUI 无需迁移；正常轮询路径行为不变，只会延长终态查询缺失时 qtransc 进程和 WebSocket 最多保留的时间。
- 非目标：本变更不增加 GUI 的进程退出兜底，不改变进度百分比含义，也不修改 WebSocket 关闭码和关闭原因。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `legacy-websocket-protocol`: 将 `upload2`/`download2` 的终态确认等待上限从 2 秒调整为 30 秒。

## Impact

- 受影响代码：`qtransc/cmd/qtransc/cmd_upload2.go`、`qtransc/cmd/qtransc/cmd_download2.go`。
- 受影响契约：`openspec/specs/legacy-websocket-protocol/spec.md` 中的终态确认窗口。
- 运行影响：协调方不再查询终态时，qtransc 子进程和本地 WebSocket 连接最长多保留约 28 秒；文件传输结果和退出码语义不变。
- 依赖与部署：不新增依赖，不需要修改 GUI 或 qtserver 配置。
