## MODIFIED Requirements

### Requirement: 终态确认窗口

传输结束后，`upload2`/`download2` SHALL 最多等待 30 秒，以便协调方查询并收到终态响应（1003 或错误码）；超时后 SHALL 关闭连接。进程退出码 SHALL 由传输结果决定，WebSocket 上报失败 SHALL NOT 覆盖传输成功结果，传输失败 SHALL NOT 因 WebSocket 正常关闭而被掩盖。

#### Scenario: 主进程不再查询

- **WHEN** 传输完成但协调方在 30 秒内未再发送 `query-progress`
- **THEN** 进程 SHALL 在窗口结束后关闭连接
- **AND** 退出码 SHALL 仍反映传输结果

#### Scenario: 传输失败且 WebSocket 正常关闭

- **WHEN** 传输失败且连接以 code 1000 关闭
- **THEN** 进程 SHALL 以传输失败对应的非零状态退出
