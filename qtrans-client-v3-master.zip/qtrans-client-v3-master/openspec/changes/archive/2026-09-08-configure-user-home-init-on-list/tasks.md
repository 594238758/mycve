## 1. 配置模型

- [x] 1.1 在 `ServerConfig` 和配置默认值中加入 `user_home_init_on_list`，默认设为 `false`，保持严格 TOML schema 解析。
- [x] 1.2 在生成 demo、生产默认模板及仓库内 Qtserver 配置示例中显式加入新字段，并保持默认不初始化。

## 2. 根目录 list 初始化

- [x] 2.1 调整 `FileListHandler`，仅在开关与 `write_enabled` 同时开启、principal 为普通用户且规范化路径为 `/` 时处理缺失家目录初始化。
- [x] 2.2 对缺失家目录取得 principal namespace lock，在锁内复用 `EnsureHome`，正确返回 `NAMESPACE_BUSY`、`HOME_INITIALIZATION_FAILED` 并保护损坏 symlink。
- [x] 2.3 保持开关关闭、write 关闭、anonymous、非根 list 和已有家目录的现有行为，且不改变 list 请求或响应结构。

## 3. 文档

- [x] 3.1 更新 `qtserver/docs/config.md`，说明字段默认值、与 `write_enabled` 的 AND 关系、已有目录不回填以及旧版本回滚方式。
- [x] 3.2 更新 `qtserver/docs/qtserver-apis.md`，说明根 list 在配置生效时的初始化副作用、锁冲突和初始化失败响应。

## 4. 验证

- [x] 4.1 对修改的 Go 文件执行格式化，并在 `qtserver` 模块执行 `go build ./...`，确认源代码编译通过。
