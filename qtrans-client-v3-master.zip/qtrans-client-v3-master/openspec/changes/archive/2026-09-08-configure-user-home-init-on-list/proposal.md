## Why

GUI 首次浏览用户文件空间时，当前 Qtserver 会对缺失的普通用户家目录返回空列表，但不会创建家目录及 `user_home_init_dirs`，导致 GUI 无法展示部署方约定的初始目录。该行为应由 Qtserver 部署配置统一控制，而不应增加由客户端逐次传入的 list query 参数。

## What Changes

- 新增 `[server]` 配置字段 `user_home_init_on_list`，默认值为 `false`。
- 当 `user_home_init_on_list=true` 且 `write_enabled=true` 时，已认证普通用户首次请求根目录 list，Qtserver 在其家目录缺失时创建家目录、执行一次性 `user_home_init_dirs` 初始化，然后返回实际目录列表。
- 初始化纳入 principal namespace lock；锁冲突返回 `409 NAMESPACE_BUSY`，初始化失败返回 `500 HOME_INITIALIZATION_FAILED`。
- `write_enabled=false` 时配置不产生目录副作用；缺失家目录继续按原行为返回空根目录列表。
- 不为 list API 增加 query 字段或响应字段，不改变 qtransc/GUI 请求格式。
- 不对已有普通用户家目录补建初始化目录，不修复或替换损坏 symlink，也不改变 anonymous 家目录的现有生命周期。
- 兼容性：旧配置省略新字段时行为不变；包含新字段的配置不能由采用严格旧 schema 的旧版 Qtserver 读取，回滚旧版本前需删除该字段。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `user-file-space`：允许部署方在开启写能力时，通过配置使普通用户首次根目录 list 按需创建并初始化家目录。

## Impact

- 配置模型、默认值、严格解析和配置示例：`qtserver/internal/config/`、`qtserver/docs/config.md`、`qtserver/deploy/qtserver_config_default.toml`。
- 文件 list 与家目录初始化流程：`qtserver/internal/handlers/files_handler.go`、现有 `filespace.Space.EnsureHome` 和 namespace lock。
- HTTP API 的条件性副作用及错误响应说明：`qtserver/docs/qtserver-apis.md`。
- 行为契约：`openspec/specs/user-file-space/spec.md`。
- 不新增第三方依赖，不改变 URL、请求参数、响应 JSON 或客户端调用方式。
