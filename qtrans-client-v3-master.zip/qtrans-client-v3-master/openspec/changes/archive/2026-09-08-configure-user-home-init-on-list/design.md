## Context

当前 `GET /files/list` 在普通 principal 根目录缺失时直接返回空 entries；`filespace.Space.EnsureHome` 已为写操作提供一次性家目录初始化和失败回滚，文件 mutation handler 也已有基于 principal 的可续期 namespace lock。此次变更需要复用这些机制，使部署方可以为 GUI 首次浏览启用初始化，同时保持默认行为和 HTTP 消息格式不变。

Qtserver 使用严格配置 schema，旧二进制会拒绝它不认识的新字段。anonymous 家目录由启动校验独立管理，不应进入普通 principal 的按需初始化流程。

## Goals / Non-Goals

**Goals:**

- 以单个服务端布尔配置控制首次根 list 是否初始化缺失的普通用户家目录。
- 将 list 触发的初始化约束在 `write_enabled` 总开关和现有 namespace lock 内。
- 复用现有一次性初始化、权限策略和回滚语义，避免形成第二套家目录创建逻辑。
- 保持 list URL、query、响应 JSON 和客户端实现不变。

**Non-Goals:**

- 不把 list 初始化开放为客户端逐请求选择。
- 不补建已有家目录中缺失的 `user_home_init_dirs`，不修复家目录 symlink。
- 不改变 anonymous 家目录的启动期管理方式。
- 不把非根 list、download 或其他只读 API 扩展为家目录初始化触发器。

## Decisions

### 1. 使用显式的 `server.user_home_init_on_list` 配置

该字段为 bool，默认 `false`。字段名直接表达触发点，避免 `auto_init` 一类名称让运维误解为启动扫描或任意请求初始化。

有效条件为：

```text
user_home_init_on_list && write_enabled && ordinary_principal && path == "/"
```

`user_home_init_on_list=true` 与 `write_enabled=false` 的组合是合法配置，但实际行为等同于关闭初始化。这样可以在只读维护期间关闭全局写能力而无需修改并随后恢复该策略配置。

备选方案是对此组合启动报错；它能更早暴露配置矛盾，但会削弱 `write_enabled` 作为运维总开关的独立性，因此不采用。

### 2. 仅在认证和路径规范化完成后处理初始化

handler 先沿用现有 read principal 鉴权并规范化 `path`。只有普通 principal 的规范化根路径进入初始化分支；anonymous、非根路径以及开关未生效的请求完全沿用现有 list 流程。

这保证非法路径不会创建目录，也防止 anonymous 意外应用 `user_home_init_dirs`。配置控制服务行为而非请求权限，因此不增加 query 或 response 字段。

### 3. 缺失时在 namespace lock 内复用 `EnsureHome`

根 list 先检查现有家目录。仅当检查结果为 `NOT_FOUND` 且初始化条件生效时，获取该 principal 的 namespace lock，在锁内调用 `EnsureHome`，随后释放锁并执行正常枚举。

`EnsureHome` 再次检查家目录，因此能够处理“初次检查缺失，但等待锁期间另一个请求已经创建成功”的竞争；此时将已有目录视为幂等成功且不回填 init dirs。现有 namespace lock 的租约续期和冲突行为继续复用，不新增锁类型。

备选方案是在每次根 list 前无条件获取 namespace lock；这会让常规浏览与 mutation 产生不必要竞争，因此不采用。

### 4. 保持现有初始化失败与损坏节点保护

成功创建家目录后，list 按正常逻辑枚举，因此首个响应会自然包含 `user_home_init_dirs`，无需增加 `home_created`。

namespace lock 冲突映射为 `409 NAMESPACE_BUSY` 并携带 `Retry-After: 1`。`EnsureHome` 的失败映射为 HTTP 500 `HOME_INITIALIZATION_FAILED`，包括损坏家目录 symlink；服务不得替换该节点。若初始化中途失败，继续采用现有 best-effort 整体回滚策略。

### 5. 同步所有配置入口和外部说明

配置模型与 Viper 默认值加入新字段；生成 demo 和生产默认模板显式写出 `false`。`qtserver/docs/config.md` 作为字段权威说明有效条件和回滚兼容性，`qtserver/docs/qtserver-apis.md` 说明 list 在该配置下可能产生受控副作用及新增的错误结果。

## Risks / Trade-offs

- [开启配置后 GET 具有文件系统副作用，HTTP 中间缓存或自动重试可能重复调用] → 初始化是幂等的一次性操作，默认关闭，且文档明确该部署语义；不依赖 GET 请求体或逐请求标志。
- [首次 list 与写操作并发可能重复初始化或观察中间状态] → 对缺失家目录的初始化使用现有 principal namespace lock，并由 `EnsureHome` 在锁内重新检查。
- [初始化后枚举失败会让客户端收到失败，但家目录已创建] → 初始化完成即形成持久事实，不因只读枚举错误回滚；后续 list 可直接重试。
- [新配置导致旧版二进制回滚时严格解析失败] → 新版默认无需迁移；回滚旧版前从配置中删除 `user_home_init_on_list`。

## Migration Plan

1. 部署新 Qtserver 时保留默认 `user_home_init_on_list=false`，行为与旧版本一致。
2. 需要 GUI 首次浏览初始化的部署显式设置 `user_home_init_on_list=true`，并确认 `write_enabled=true` 与 `user_home_init_dirs` 符合预期。
3. 回滚旧版 Qtserver 前删除新字段；已经创建的家目录作为普通既有家目录保留，回滚过程不删除用户数据。
