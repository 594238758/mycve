## RENAMED Requirements

- FROM: `### Requirement: 缺失家目录仅由产生新对象的写操作创建`
- TO: `### Requirement: 缺失普通用户家目录按受控条件创建`

## MODIFIED Requirements

### Requirement: 普通用户家目录允许指向外部目录

普通 principal 家目录可以是有效 symlink，Qtserver SHALL 跟随其目标，即使目标位于 user_home_root 外。API 调用方 SHALL NOT 能通过逻辑根路径操作家目录 symlink 节点本身。

#### Scenario: 家目录链接有效

- **WHEN** `<user_home_root>/<principal_id>` 是指向外部普通目录的有效 symlink
- **THEN** 文件 API SHALL 在该目标目录中工作

#### Scenario: 家目录链接损坏且 list 初始化未生效

- **WHEN** 家目录 symlink 损坏，且 `user_home_init_on_list` 与 `write_enabled` 未同时开启
- **THEN** 根 list SHALL 返回空空间且不修复链接
- **AND** 具体读请求 SHALL 返回 404
- **AND** 写请求 SHALL 失败且不得替换该链接

#### Scenario: 家目录链接损坏且 list 初始化生效

- **WHEN** 家目录 symlink 损坏，且 `user_home_init_on_list=true`、`write_enabled=true` 的普通 principal 请求根 list
- **THEN** 服务 SHALL 返回 HTTP 500 `HOME_INITIALIZATION_FAILED`
- **AND** SHALL NOT 修复或替换该链接

### Requirement: 缺失普通用户家目录按受控条件创建

`user_home_init_on_list` SHALL 是 `[server]` 下的布尔配置且默认 `false`。缺失普通家目录时，只有 mkdir、create、已经成功进入发布阶段的 complete，以及同时满足 `user_home_init_on_list=true`、`write_enabled=true` 的普通 principal 根 list MAY 创建家目录。具体对象读取、非根 list、upload init、move 和 delete SHALL NOT 因缺失家目录产生目录副作用。list 请求与响应 SHALL NOT 为此能力增加字段。

#### Scenario: 默认首次根目录 list

- **WHEN** 普通 principal 家目录不存在、`user_home_init_on_list` 缺省或为 `false`，并请求 list `/`
- **THEN** 服务 SHALL 返回 200、空 entries 和 `truncated=false`
- **AND** 家目录 SHALL 仍不存在

#### Scenario: 配置开启后的首次根目录 list

- **WHEN** 普通 principal 家目录不存在、`user_home_init_on_list=true`、`write_enabled=true`，并请求 list `/`
- **THEN** 服务 SHALL 创建并初始化该 principal 家目录
- **AND** SHALL 返回 200 及初始化后的实际根目录 entries

#### Scenario: write 关闭时首次根目录 list

- **WHEN** 普通 principal 家目录不存在、`user_home_init_on_list=true`、`write_enabled=false`，并请求 list `/`
- **THEN** 服务 SHALL 返回 200、空 entries 和 `truncated=false`
- **AND** 家目录 SHALL 仍不存在

#### Scenario: 首次非根目录 list

- **WHEN** 普通 principal 家目录不存在且请求根目录以外的 list，无论 `user_home_init_on_list` 取值如何
- **THEN** 服务 SHALL 返回 404 `NOT_FOUND`
- **AND** SHALL NOT 创建家目录或初始化目录

#### Scenario: 首次根目录 list 遇到 namespace lock 冲突

- **WHEN** 已配置生效的首次根目录 list 无法取得该 principal 的 namespace lock
- **THEN** 服务 SHALL 返回 409 `NAMESPACE_BUSY` 和 `Retry-After: 1`
- **AND** SHALL NOT 在未持有锁时开始初始化

#### Scenario: 首次 move 或 delete

- **WHEN** 普通 principal 家目录不存在并调用 move 或 delete
- **THEN** 服务 SHALL 返回 404 `NOT_FOUND`
- **AND** SHALL NOT 创建家目录或初始化目录

#### Scenario: 首次上传只执行 init

- **WHEN** 普通 principal 家目录不存在并创建 upload session
- **THEN** init MAY 创建缓存状态但 SHALL NOT 创建正式家目录

### Requirement: 新普通家目录执行一次性初始化

`user_home_init_dirs` SHALL 只应用于本次调用新建的普通 principal 家目录。配置项名称 SHALL 是唯一一级 UTF-8 目录名，并拒绝空、`.`、`..`、分隔符和 NUL；uid 与 gid SHALL 同时出现且非负；mode SHALL 接受 `700`、`0700` 或 `0o700` 并限制在 `0000..0777`。非法配置 SHALL 使启动失败。

#### Scenario: 新建家目录初始化成功

- **WHEN** mkdir、create、complete 或配置生效的根 list 新建普通 principal 家目录
- **THEN** 服务 SHALL 创建全部 init dirs 并应用配置的 ownership 和 mode

#### Scenario: 新建家目录初始化中途失败

- **WHEN** 初始化操作失败
- **THEN** 服务 SHALL best-effort 删除本次新建的整个家目录
- **AND** 若仍有残留 SHALL 返回 `HOME_INITIALIZATION_FAILED`
- **AND** 后续请求 SHALL NOT 自动补建残留家目录

#### Scenario: 根 list 初始化失败

- **WHEN** 配置生效的根 list 创建或初始化普通 principal 家目录失败
- **THEN** 服务 SHALL 返回 HTTP 500 `HOME_INITIALIZATION_FAILED`

#### Scenario: 家目录已经存在

- **WHEN** principal 家目录在调用前已经存在
- **THEN** 服务 SHALL NOT 补建 init dirs，也 SHALL NOT 重新 chmod 或 chown

### Requirement: managed 权限只作用于新创建对象

Qtserver SHALL 以规范化逻辑路径的第一个 segment 选择 managed policy。mkdir、create、complete 和配置生效的首次根 list SHALL 对其创建的新目录或新 inode 应用策略；除首次根 list 创建初始化目录外，list、download、move 和 delete SHALL NOT 应用或重写策略。无匹配策略时，新文件 SHALL 使用 `0666 & umask`，新目录 SHALL 使用 `0777 & umask`。

#### Scenario: 在 managed 一级目录中发布文件

- **WHEN** complete 在匹配 managed policy 的路径下创建新 inode
- **THEN** rename 前 SHALL 对缓存文件应用精确 managed mode 和 ownership

#### Scenario: managed 一级目录是外部 symlink

- **WHEN** 匹配的第一级是指向外部目录的有效 symlink
- **THEN** 服务 SHALL 跟随链接并对其后新创建对象应用策略

#### Scenario: move 已有对象

- **WHEN** 文件被 move 到另一个 managed 路径
- **THEN** move SHALL NOT 重新应用 destination 的 mode 或 ownership

### Requirement: capability 开关决定路由是否存在

`read_enabled` SHALL 只控制下载路由是否注册：`POST /d/grant`、`POST /d/small`、`POST /d/verify` 和 `GET /d/down/*objectKey`。当 `read_enabled=false` 时，这些路由 SHALL 不注册并返回 404 `ROUTE_NOT_FOUND`。

`write_enabled` SHALL 是全部远端 mutation 的总开关。关闭时，canonical upload 的全部路由，以及 `POST /files/mkdir`、`POST /files/move`、`POST /files/delete` 和 `POST /files/create` SHALL 不注册并返回 404 `ROUTE_NOT_FOUND`，且 `GET /files/list` SHALL NOT 初始化普通用户家目录。

`GET /files/list` SHALL 始终注册，且 SHALL NOT 因 `read_enabled` 或 `write_enabled` 被关闭而返回 route-not-found；其访问仍受对应 principal 鉴权和文件空间规则约束。

#### Scenario: write 关闭

- **WHEN** 客户端访问 upload 或文件管理写路由
- **THEN** 服务 SHALL 返回 404 `ROUTE_NOT_FOUND`

#### Scenario: read 关闭

- **WHEN** 客户端访问任一下载路由且 read 关闭
- **THEN** 服务 SHALL 返回 404 `ROUTE_NOT_FOUND`

#### Scenario: 读写均关闭时浏览

- **WHEN** read 与 write 均关闭且已鉴权客户端访问 `GET /files/list`
- **THEN** 服务 SHALL 注册并按正常 list 契约处理该请求，而不得返回 `ROUTE_NOT_FOUND`
- **AND** SHALL NOT 初始化缺失的普通用户家目录
