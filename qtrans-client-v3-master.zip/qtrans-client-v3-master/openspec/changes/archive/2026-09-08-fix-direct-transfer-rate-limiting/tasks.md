## 1. 任务级限速实现

- [x] 1.1 调整 `qtransc/internal/ratelimit` 的推荐读取 quantum，使合法低速率按约 100ms 额度从最小 1 byte 起步、保持 256KiB 上限，并避免极大 bytes/s 转换为 `int` 时溢出。
- [x] 1.2 在 canonical upload PATCH body 上按 `SectionReader -> shared rate limiter -> progressReader -> HTTP transport` 顺序接入 `UploadTask` 既有 limiter，保持 Content-Length、offset、并发共享和重试计费语义。
- [x] 1.3 检查直接 `upload` 与 `download` 仍只在本次命令设置任务限速，保持 upload state DB、`upload2`、`download2`、`serve` 和 Qtserver 不变。

## 2. 文档同步

- [x] 2.1 更新 `qtransc/docs/CLI_GUIDE.md`，明确 `--limit-rate` 只支持直接 `upload`/`download`，说明 bytes/s 单位、任务聚合 payload、并发、重试、协议开销和恢复时重新传参的边界。

## 3. 格式与编译校验

- [x] 3.1 对修改的 Go 文件执行 `gofmt`，运行 `make -C qtransc build` 确认 qtransc 编译通过。
- [x] 3.2 运行 `git diff --check` 和 `openspec validate fix-direct-transfer-rate-limiting --type change --strict`，确认源码、文档和 OpenSpec artifacts 一致；不运行测试或 benchmark。
