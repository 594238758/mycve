## Purpose

定义 qtransc 直接 `upload` 与 `download` 命令的任务级 payload 限速契约，使用户在不同传输方向、并发设置和重试场景下获得一致且可预测的带宽控制行为。

## ADDED Requirements

### Requirement: 直接传输命令接受统一限速参数

qtransc 直接 `upload` 和 `download` 命令 SHALL 接受 `--limit-rate`。参数 SHALL 支持正数裸 bytes/s、十进制 `B|KB|MB|GB` 和二进制 `KiB|MiB|GiB`，并允许 `/s` 或 `ps` 速率后缀且单位不区分大小写。显式零值、负值、未知单位、非数字或溢出值 SHALL 在传输开始前作为 CLI 输入错误拒绝并使用退出码 2；省略参数 SHALL 表示不限速。

#### Scenario: 使用二进制速率单位上传

- **WHEN** 用户执行直接 `upload` 并指定 `--limit-rate 5MiB/s`
- **THEN** qtransc SHALL 将任务持续 payload 速率限制为每秒 `5 * 1024 * 1024` bytes

#### Scenario: 使用裸字节速率下载

- **WHEN** 用户执行直接 `download` 并指定 `--limit-rate 1048576`
- **THEN** qtransc SHALL 将任务持续 payload 速率限制为每秒 `1048576` bytes

#### Scenario: 未指定限速

- **WHEN** 用户执行直接 `upload` 或 `download` 且未指定 `--limit-rate`
- **THEN** qtransc SHALL NOT 因本能力主动限制任务 payload 速率

#### Scenario: 拒绝非法速率

- **WHEN** 用户指定零值、负值、未知单位、非数字或溢出的 `--limit-rate`
- **THEN** qtransc SHALL 在创建传输任务前以 CLI 输入错误和退出码 2 失败

### Requirement: 限速是单个任务的聚合 payload 速率

每个直接上传或下载任务 SHALL 使用一个由该任务全部并发文件、chunk、连接和 stream 共享的限速额度。配置值 SHALL 表示任务 payload bytes 的持续速率；实现 MAY 产生有界的初始或调度 burst，但 SHALL NOT 因增加 `--transfers`、`--connections` 或 `--streams` 而把配置额度按并发数倍增。

#### Scenario: 多 chunk 并发上传

- **WHEN** 一个直接上传任务以多个并发 chunk 运行且指定 `--limit-rate 10MB/s`
- **THEN** 所有并发 PATCH body SHALL 共同受每秒 `10000000` payload bytes 的任务额度约束
- **AND** 每个 chunk SHALL NOT 分别获得每秒 `10000000` bytes 的独立额度

#### Scenario: 多文件并发下载

- **WHEN** 一个直接下载任务并发传输多个普通或 small 文件且指定限速
- **THEN** 所有响应 body SHALL 共享同一个任务额度

### Requirement: 实际重传 payload 重新计入限速

限速 SHALL 计算传输层实际消费的请求或响应 payload bytes。失败尝试后再次发送或接收的 payload SHALL 再次占用额度；HTTP headers、TLS、QUIC 和 TCP 协议开销 SHALL NOT 计入该值。逻辑文件完成进度 SHALL 与实际网络 payload 计数保持独立。

#### Scenario: 上传 PATCH 重试

- **WHEN** 一个上传 chunk 已发送部分 payload 后失败并重试
- **THEN** 首次尝试和重试实际发送的 payload bytes SHALL 分别占用同一个任务限速额度
- **AND** 逻辑文件完成进度 SHALL NOT 因重试字节重复增长

#### Scenario: 协议开销不计入额度

- **WHEN** 任务使用 TLS、HTTP/2 或 HTTP/3 传输
- **THEN** `--limit-rate` SHALL 约束应用 payload bytes
- **AND** 实际网卡吞吐 MAY 因协议开销略高于配置值

### Requirement: 合法低速率保持请求进展

对于 CLI 接受的正数限速，qtransc 的限速调度 SHALL 按小块持续释放 payload，且 SHALL NOT 仅因 limiter 的内部读取粒度产生一次达到 Qtserver 60 秒无 byte progress deadline 的等待。上下文取消 SHALL 中断正在等待额度的传输。

#### Scenario: 极低上传速率

- **WHEN** 用户为直接上传指定一个合法但低于 `10KiB/s` 的速率
- **THEN** qtransc SHALL 以与该速率相适应的小读取粒度持续发送 payload
- **AND** SHALL NOT 先突发固定 `1KiB` 后因补充同等额度而等待 60 秒或更久

#### Scenario: 等待期间取消任务

- **WHEN** 直接传输任务正在等待限速额度且用户取消任务
- **THEN** qtransc SHALL 响应取消并停止继续读取传输 payload

### Requirement: 限速是本次直接命令的运行策略

qtransc SHALL NOT 把 `--limit-rate` 保存到上传恢复 SQLite。暂停、中断或服务端 session 恢复后，新的直接命令 SHALL 只使用该次命令显式提供的限速；未再次提供时 SHALL 按不限速运行。

#### Scenario: 恢复时重新指定限速

- **WHEN** 用户中断一个有限速的直接上传，并使用相同 local/server/remote 业务键和新的 `--limit-rate` 恢复
- **THEN** qtransc SHALL 恢复原上传 session并使用新命令的限速值

#### Scenario: 恢复时省略限速

- **WHEN** 用户中断一个有限速的直接上传，随后恢复时未指定 `--limit-rate`
- **THEN** qtransc SHALL 恢复原上传 session且不沿用上次命令的限速值
