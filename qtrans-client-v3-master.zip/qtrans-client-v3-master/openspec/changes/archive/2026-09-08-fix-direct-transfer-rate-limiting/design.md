## Context

直接 `upload` 已把 `--limit-rate` 解析为 bytes/s、写入 `UploadTask.LimitRate`，并在任务执行时构造一个共享的 `ratelimit.Limiter`；缺口仅在 canonical PATCH body 仍直接读取 `io.SectionReader`。直接 `download` 的普通 chunk 和 small batch 已通过同一种任务级 limiter 包装响应 body。行为目标见 `specs/direct-transfer-rate-limiting/spec.md`。

Qtserver 对持续 PATCH 使用 60 秒无 byte progress deadline。现有 limiter 的读取 quantum 最小固定为 `1KiB`，在极低速率下会先突发 `1KiB`，随后为同等额度等待超过 60 秒，因此上传接线时也必须修正这一通用边界。

## Goals / Non-Goals

**Goals:**

- 复用现有 limiter，让直接上传与直接下载拥有相同的任务级聚合 payload 限速模型。
- 在文件、chunk、连接和 stream 并发下只创建一个任务额度。
- 让上传进度计数发生在 payload 通过 limiter 之后，并让重试 payload 重新计费。
- 保持极低速率下的持续小块进展和 context cancellation。

**Non-Goals:**

- 不增加服务端、principal、全局进程或多任务聚合限速。
- 不修改 `upload2`、`download2`、`serve` 或本地任务 API。
- 不把限速策略保存到上传恢复 SQLite，也不修改 session 身份或恢复键。
- 不承诺包含 HTTP/TLS/QUIC/TCP overhead 的精确网卡速率。

## Decisions

### 1. canonical PATCH body 接入既有任务 limiter

上传请求体采用以下读取链：

```text
io.SectionReader
    -> task shared rate-limited reader
    -> progressReader(NetworkSent)
    -> HTTP transport
```

`progressReader` 放在 limiter 外层，使 `NetworkSent` 只在 limiter 已允许数据交给 transport 时增长；如果放在 limiter 内层，进度会在等待额度期间提前显示。请求的 `Content-Length`、`Upload-Offset` 和 SectionReader 范围保持不变。

每次 PATCH 尝试都创建新的 SectionReader 和包装 reader，但复用 `UploadTask` 上的同一个 limiter。这样并发请求共享额度，认证刷新、offset mismatch 或传输故障产生的新尝试也继续消耗同一 token bucket，而不会在重试时重置速率。

备选方案是在每个 chunk 上创建 limiter。该方案会使总速率随 chunk 并发倍增，与“任务总速率”冲突，因此不采用。另一个备选是让 Qtserver 或 Nginx 限制入口带宽；这无法表达当前客户端命令的每任务策略，且会扩大部署和协议范围，因此不采用。

### 2. 继续以 payload reader 作为计费边界

上传在 request body reader、下载在 response body reader 上等待 token。该边界直接对应应用 payload bytes，并天然覆盖 transport 实际拉取的重试数据。控制请求、header、加密和传输协议 overhead 不进入 limiter；逻辑完成进度仍根据服务端确认的 chunk 状态维护，不直接使用网络重试字节。

备选方案是读取系统网卡统计或在 transport connection 层限速。它会混入同进程其他请求、协议开销和连接复用，无法稳定归属单个任务，因此不采用。

### 3. 将 limiter quantum 调整为约 100ms 的合法额度

通用 limiter 的推荐 quantum 继续使用 `bytesPerSec / 10` 并保留 `256KiB` 上限，但下限从固定 `1KiB` 调整为 `1 byte`。计算时先在 `int64` 范围内裁剪再转换，避免极大输入转换为 `int` 时溢出。

该选择让常用速率保持每秒约十次放行，并让 `1B/s` 等已被 CLI 接受的极低速率以小块持续进展，而不是产生长达数分钟的内部等待。极低速率会增加 reader 调用次数，但其绝对数据量很小，CPU 代价可接受。

备选方案是新增上传最小速率并拒绝低值。它会改变现有统一参数语法，并使上传和下载接受范围不同，因此不采用。

### 4. 限速只属于本次直接命令

直接 `upload` 和 `download` 继续在构造任务后设置 `LimitRate`。不向 `TaskCreateRequest` 增加字段，也不修改 upload state DB。恢复命令使用本次 CLI 值，避免运行策略成为 session 身份的一部分。

`--limit-rate` 当前作为 persistent flag 注册；本变更只在文档中明确支持范围，不为其他子命令增加透传或新的错误行为，避免顺带扩大 CLI 兼容性变化。

## Risks / Trade-offs

- [Token bucket 允许有界初始 burst，短窗口观测可能高于配置值] -> 文档和规格使用 sustained payload rate 语义，并通过约 100ms quantum 限制 burst 大小。
- [网卡观测速率包含协议 overhead，可能略高于配置值] -> 明确 limiter 只计算 payload bytes，不宣称 wire-rate shaping。
- [极低速率产生较多小 Read 调用] -> quantum 仍按速率的十分之一增长，并在常用速率下快速达到更大的读取块。
- [上传在 limiter 等待期间取消] -> 继续把任务 context 传给共享 limiter，等待必须随 context cancellation 结束。
- [重试会降低逻辑有效吞吐] -> 重试 payload 实际消耗带宽，继续计费是有意行为；逻辑进度与 NetworkSent 分离。

## Migration Plan

1. 发布包含修复的新 qtransc 二进制并同步 CLI 文档；Qtserver 和部署配置无需变更。
2. 现有未指定 `--limit-rate` 的调用保持原行为；显式指定参数的直接上传在升级后开始实际限速。
3. 回滚只需恢复旧 qtransc 二进制，不涉及数据库、SQLite schema 或服务端 session 迁移；回滚后直接上传会恢复为参数可解析但不实际限速的旧缺陷。
