## Why

qtransc 已公开 `--limit-rate` 作为任务总速率限制，并且直接 `download` 已实际应用该限制，但直接 `upload` 只解析和保存参数，没有在 HTTP PATCH 请求体上执行限速。当前行为会让用户误以为上传带宽已受控，实际仍可能占满可用链路。

## What Changes

- 让直接 `qtransc upload` 的所有并发文件和 chunk 共享一个任务级上传 limiter，使 `--limit-rate` 真正限制任务上传 payload 总速率。
- 保持直接 `qtransc download` 已有的任务级下载限速行为，并将上传、下载的共同语义正式记录为行为契约。
- 限速统计实际传输和重试的 payload bytes，不包含 HTTP/TLS 协议开销；未指定 `--limit-rate` 时继续不限速。
- 保持现有数值与单位格式，包括裸 bytes/s、`MB/s` 和 `MiB/s`，并使极低合法速率不会因固定读取粒度产生超长无数据间隔。
- 恢复上传时不持久化上一次命令的限速值；每次直接命令按本次显式参数决定限速。
- 非目标：不为 `upload2`、`download2`、`serve` 或 qtransc 本地任务 API 增加限速支持，不增加 Qtserver 配置或服务端限速。
- 兼容性：没有 breaking change；省略参数的现有命令行为不变。依赖当前上传未限速缺陷的调用方在显式传入 `--limit-rate` 时将观察到预期的较低上传速率，无需迁移配置或状态数据。

## Capabilities

### New Capabilities

- `direct-transfer-rate-limiting`: 定义直接 `upload` 和 `download` 的参数解析、任务级聚合 payload 限速、并发与重试计费以及恢复边界。

### Modified Capabilities

无。

## Impact

- qtransc CLI：直接 `upload` 的既有参数从“可解析但不生效”修复为实际限速；直接 `download` 行为保持不变。
- qtransc 传输内核：上传 PATCH body 接入既有共享 limiter；通用 limiter 调整极低速率的读取粒度。
- 文档：同步限定 `--limit-rate` 只适用于直接 `upload` 和 `download`，并说明单位与任务总速率语义。
- Qtserver、HTTP API、Redis session、上传恢复 SQLite schema、第三方依赖均不变。
