# Tasks

## 1. 请求与规划

- [x] 1.1 新增 v2 路由、严格请求及 host[:port]/路径校验；检查旧字段拒绝、公共配置与凭据复用的代码路径。
- [x] 1.2 实现完整复制计划、身份、限制及冲突检查；核查文件/目录/空目录和一源多目标的映射。
- [x] 1.3 分离两版 HTTP 请求字段及转换，消除 v2 对 v1 请求类型的直接依赖；保留共同内部请求、任务管理器与上传下载任务。
- [x] 1.4 CLI --server 和 v2 serverAddr 共用默认端口 23500；保留域名、IPv4、方括号 IPv6 校验，拒绝空显式端口、非法端口及 URL 前缀，并更新相关文档。

## 2. 任务执行

- [x] 2.1 上传任务在能力检查后展开，将结果保存到 FileList/DirPaths 和已展开标记，删除长期 copyPlan；重启复用清单并检查目标，所有规划失败点先于 mkdir 和内容传输。
- [x] 2.2 下载使用 FileList/DirPaths 和已展开标记，重启仅重置运行状态；将元数据、授权和目标准备移出路径展开，复用本轮 grant，保留独立副本、小文件分批与磁盘检查。
- [x] 2.3 使用最终目标文件完整路径标识 v2 文件，删除新增 FileID/fileId，调整运行索引、HTTP 视图和 SSE；保留 v1/CLI/WebSocket 兼容行为及续传文件命名。
- [x] 2.4 更新新接口介绍文档，记录已确定的路由、统计、根目录及查询字段；检查 JSON 示例和相对链接。

## 3. 集成检查

- [x] 3.1 gofmt、OpenSpec 验证、git diff --check 和必要 Go 编译检查；不编写或执行测试。

## Workflow follow-up

- 维护者 review 新接口及文档后，可再调整行为并归档 change。

## Validation evidence

- `go build ./qtransc/...`：通过。
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build ./qtransc/...`：通过。
- `openspec validate add-task-path-mappings --strict`：通过。
- gofmt、git diff --check、新文件空白检查、介绍文档 3 个 JSON 示例与相对链接检查：通过。
- 遵循仓库约定，未编写或运行测试；本次未做运行时联调。
- 创建入口拆分及文件标识改为最终目标路径后，重新完成 Linux 构建、Windows 交叉编译、OpenSpec 验证和 git diff --check，均通过。
- 展开状态简化后，再次完成 Linux 构建、Windows 交叉编译、OpenSpec 验证和 git diff --check，均通过；确认任务中无 copyPlan，展开文件中无 grant 处理，已展开标记只在完整清单提交时设置。
- CLI 与 v2 默认端口统一为 23500 后，Linux 构建、Windows 交叉编译、OpenSpec 验证和 git diff --check 均通过；未编写或运行测试。
