## MODIFIED Requirements

### Requirement: serve 路由集合保持稳定

qtransc serve SHALL 保留现有 token、健康、任务控制、查询及 SSE 路由，并新增 POST /api/v2/tasks。v1 创建格式、CLI 与旧 WebSocket SHALL 保持兼容。两种创建入口 SHALL 共享任务 ID 空间、接纳容量、查询、控制和 SSE。

#### Scenario: 调用既有详情接口

- **WHEN** 调用方请求 GET /api/v1/tasks/:task_id/detail
- **THEN** SHALL 返回该 ID 的任务详情，包括通过 v2 创建的任务

#### Scenario: 订阅既有事件接口

- **WHEN** 调用方请求 GET /api/v1/events
- **THEN** SHALL 建立 SSE 事件流并包含两种入口创建的任务

## ADDED Requirements

### Requirement: v2 创建使用源与目标目录配对

POST /api/v2/tasks SHALL 接受非空 pathMappings 数组，每项仅接受非空字符串 src、dst。dst SHALL 始终表示目录。新入口 SHALL 拒绝 fileList、sourceDir、targetDir、dirPaths 和旧文件字段。其余公共字段、严格 JSON、认证隔离、配置继承、接纳和响应信封 SHALL 沿用 v1。入队前 SHALL 仅进行语法及接纳检查；能力、源类型、重复映射与展开检查 SHALL 在 running 执行。

#### Scenario: 混用旧路径字段

- **WHEN** v2 请求同时携带 pathMappings 和 fileList
- **THEN** SHALL 拒绝请求且不登记任务

#### Scenario: 上传与下载的路径方向

- **WHEN** mode 为 upload 或 download
- **THEN** upload 的 src SHALL 是本地绝对路径、dst 是远端逻辑绝对目录；download SHALL 相反
- **AND** SHALL 拒绝源根目录、通配符、非法逻辑路径；允许目标根目录并保留根路径

### Requirement: v2 服务地址接受主机和可选端口

v2 serverAddr SHALL 仅接受域名或 IP 及可选端口，IPv6 SHALL 使用方括号。省略端口时 SHALL 使用 23500；显式端口 SHALL 是 1..65535 的十进制整数。SHALL 拒绝 scheme、路径、userinfo、query、fragment、空的显式端口和无效端口。transport SHALL 决定网络传输配置。

#### Scenario: 使用 URL 前缀

- **WHEN** serverAddr 为 https://qt.example.com:8443
- **THEN** SHALL 在入队前返回请求无效

#### Scenario: 合法地址

- **WHEN** serverAddr 为 qt.example.com:8443 或 [2001:db8::1]:8443
- **THEN** SHALL 接受地址语法并使用已有 TLS 传输实现

#### Scenario: 省略端口

- **WHEN** serverAddr 为 qt.example.com、192.0.2.10 或 [2001:db8::1]
- **THEN** SHALL 分别使用 qt.example.com:23500、192.0.2.10:23500 或 [2001:db8::1]:23500

#### Scenario: 显式端口无效

- **WHEN** serverAddr 为 qt.example.com:、qt.example.com:0 或 qt.example.com:65536
- **THEN** SHALL 在入队前返回请求无效，不以默认端口替代

### Requirement: v2 文件记录以最终目标路径标识

v2 任务详情 SHALL 返回 pathMappings，并通过 fileList 展示完整文件计划，不再使用旧任务的 readyFiles/authorizedFiles 分类列表。已规划文件的详情和摘要 SHALL 增加 src、dst，dst 为最终文件完整路径。最终目标文件路径 SHALL 在同一任务内唯一，并在后续执行中保持稳定；SHALL 不增加独立 fileId 字段。文件及分片事件的 fileKey SHALL 等于该记录的完整 dst，不移除前导斜杠。调用方 SHALL 使用 taskId 与 fileKey 关联具体任务中的文件。旧任务的字段与事件身份 SHALL 保持原契约。

#### Scenario: 同源多份副本

- **WHEN** 同一远端文件复制到两个本地目录
- **THEN** 查询 SHALL 返回两条拥有不同 dst 的记录，事件 SHALL 使用对应的完整目标文件路径分别关联

#### Scenario: 多个文件共用目标目录

- **WHEN** 两个源文件 a.txt、b.txt 的请求 dst 均为 /backup
- **THEN** 展开后的目标 /backup/a.txt、/backup/b.txt SHALL 分别作为文件标识；SHALL 不把请求中的目标目录当作文件标识
