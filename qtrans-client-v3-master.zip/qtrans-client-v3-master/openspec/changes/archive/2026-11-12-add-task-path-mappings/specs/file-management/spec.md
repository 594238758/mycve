## MODIFIED Requirements

### Requirement: 多source映射和冲突必须确定

CLI 与旧任务入口的 upload destination SHALL 总是目录：单文件映射为`destination/basename`，目录映射为`destination/source-basename`，多source均保留basename；第一版不得在upload中同时改名。CLI 的 download多source也 SHALL 保留basename。规划 SHALL 在执行前检测多个source映射到同一local/remote target；本地冲突 SHALL 使用实际OS大小写语义。新 v2 创建入口 SHALL 使用下述目标目录内容复制规则，不自动追加源目录 basename。

#### Scenario: 两个source basename相同

- **WHEN** 多source会映射到同一destination path
- **THEN** qtransc SHALL 在传输前失败而不得静默覆盖

#### Scenario: 用户需要上传时改名

- **WHEN** 用户希望单文件上传到不同basename
- **THEN** 第一版 SHALL 要求上传后显式move

## ADDED Requirements

### Requirement: CLI 服务地址省略端口时使用 23500

qtransc CLI 的 --server SHALL 接受 host[:port]。省略端口时 SHALL 使用 23500；显式指定端口时 SHALL 使用该端口，并继续校验端口范围、IPv6 方括号及现有地址格式约束。

#### Scenario: CLI 省略端口

- **WHEN** 用户执行 qtransc --server qt.example.com list /
- **THEN** SHALL 连接 qt.example.com:23500

#### Scenario: CLI 显式覆盖端口

- **WHEN** 用户执行 qtransc --server qt.example.com:8443 list /
- **THEN** SHALL 连接 qt.example.com:8443

### Requirement: v2 任务目标始终为目录

v2 src 为文件时 SHALL 复制到 dst/basename(src)；src 为目录时 SHALL 将内容按源内相对层级复制到 dst。非根路径尾部斜杠 SHALL 不改变含义。缺失目标目录及父目录 SHALL 自动创建；空目录 SHALL 保留；已有目录 SHALL 合并且保留额外内容。目标文件 SHALL 沿用既有校验与默认覆盖策略，文件与目录 SHALL NOT 相互替换。

#### Scenario: 目录复制内容

- **WHEN** src=/data/dir1 包含 sub/a.txt，dst=/backup
- **THEN** 最终文件 SHALL 为 /backup/sub/a.txt
- **AND** 空源目录 SHALL 使 /backup 存在

#### Scenario: 目标为文件

- **WHEN** dst 或所需父目录已被文件占用
- **THEN** 任务 SHALL 在传输前失败且不替换该节点

### Requirement: v2 任务只提交一次完整复制计划

v2 任务每轮进入 running 后 SHALL 先检查能力。没有成功计划时 SHALL 展开源并检查全部映射、目标类型和限制，通过后一次提交文件与目录清单。提交前 SHALL NOT 创建目标目录或传输内容。未提交时 start/autoRetry SHALL 可重新规划；已提交后 SHALL 复用清单、不递归重扫，仍重新检查文件元数据、授权、目标状态及续传数据。停止 SHALL 取消当前规划，计划仅在当前进程任务生命周期内保留。

#### Scenario: 已提交后源增加文件

- **WHEN** 原目录新增文件并再次 start
- **THEN** 新增文件 SHALL 不加入已有计划

#### Scenario: 规划中失败或暂停

- **WHEN** 展开未完成就失败或取消
- **THEN** SHALL 不发布部分计划，下次执行可重新展开

#### Scenario: 已提交后源消失

- **WHEN** 计划内文件被删除
- **THEN** 后续执行 SHALL 报告错误而不静默删除该记录

### Requirement: v2 计划检查副本冲突与限制

每份副本 SHALL 计入普通文件数和总字节数，源重叠 SHALL 不隐式去重；每次映射枚举的节点 SHALL 计入累计条目数。SHALL 沿用 100000 文件、200000 条目、128 层及逻辑路径长度上限。完全重复配对、重复最终文件目标、文件占用目录或祖先、实际本地大小写冲突 SHALL 使整个计划失败。不同目录 SHALL 可合并到同一 dst，且一源 SHALL 可映射多个不同目标。任何截断目录列表 SHALL 使规划失败。

#### Scenario: 同源两份副本

- **WHEN** 一个大小为 10 字节的源文件分别复制到 /a 与 /b
- **THEN** SHALL 生成两条记录并计为两个文件、20 字节

#### Scenario: 两个目录包含同名文件

- **WHEN** 两个源目录都含 a.txt 且 dst 相同
- **THEN** SHALL 在创建目录或内容传输前失败，不以默认覆盖解决任务内部冲突

### Requirement: v2 扫描变化及特殊节点处理

扫描 SHALL 不承诺内容快照；新增节点只有被本次枚举观察到才纳入计划。已观察条目消失、不可读或无法确定类型 SHALL 使规划失败。显式本地链接或特殊节点 SHALL 拒绝，嵌套链接或特殊节点 SHALL 跳过并警告；远端正常链接 SHALL 按既有目标类型跟随。源根目录 SHALL 拒绝，目标根目录 SHALL 允许且不得请求远端 mkdir 根路径。传输期间文件错误与已完成内容 SHALL 沿用原有失败和续传规则。

#### Scenario: 枚举后子项消失

- **WHEN** 本地 stat 失败或远端列表含 ENTRY_CHANGED/ENTRY_UNREADABLE
- **THEN** SHALL 放弃本次计划并报告执行错误

#### Scenario: 目标为远端根

- **WHEN** 上传文件到 dst=/
- **THEN** SHALL 按原名写入逻辑根下且不请求 mkdir /
