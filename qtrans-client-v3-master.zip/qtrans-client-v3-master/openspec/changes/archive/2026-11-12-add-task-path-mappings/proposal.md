# Proposal

## Why

现有任务创建接口需要调用方理解 sourceDir/targetDir 与文件项的组合规则，且上传目录展开只能在 CLI 中完成。新增独立创建入口，让调用方直接描述源文件或目录及目标目录，由运行中的任务生成并固定传输清单。

## What Changes

- 新增 POST /api/v2/tasks，使用 pathMappings: [{src,dst}]，dst 始终为目录；文件按原名放入，目录复制内容。
- serverAddr 接受 host[:port]，省略端口时使用 23500；CLI --server 省略端口时也使用 23500。其他公共任务选项、认证、接纳与生命周期沿用 v1。
- running 内先检查 capabilities，再展开并原子提交完整清单；已提交的清单在 start/autoRetry 中复用。
- 规划阶段检测路径、类型、目标冲突及数量限制，保留空目录，支持同源多目标。
- 新任务的查询文件记录增加 src/dst；事件的 fileKey 使用最终目标文件完整路径，以区分同一远端文件的不同副本，不增加 fileId。
- v1、CLI、旧 WebSocket 的输入及行为保持兼容，迁移调用方只需选择新创建路由并提交新格式；控制、查询、SSE 仍使用 v1 路由。
- 本次不增加覆盖策略参数、持久化任务管理器或文件重命名功能。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `qtransc-serve-api-contract`: 新增 v2 创建入口、严格请求格式和可区分复制记录的视图。
- `file-management`: 新入口的目录内容映射、一次成功展开、完整规划及冲突语义。

## Impact

影响 qtransc serve 路由、请求转换、上传下载任务规划、文件身份与 HTTP/SSE 视图，以及 CLI 的省略端口默认值。不改 Qtserver 协议，不引入新依赖或新错误码。实现依据用户已确认设计和本轮“待决策项自行决定”的授权；补充决定记录在 design.md 供 review。
