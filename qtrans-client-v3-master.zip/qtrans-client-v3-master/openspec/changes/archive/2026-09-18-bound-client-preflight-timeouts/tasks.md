## 1. 限定 capabilities 预检

- [x] 1.1 在直接命令和 serve 任务启动共用的 `FetchCapabilities` 为整个预检及其重试派生 15 秒 deadline，并保留调用方更早 deadline；验证代码路径仅覆盖 capabilities 获取而不改变文件数据传输 context。

## 2. DNS 重试分类

- [x] 2.1 调整可用性错误分类，使永久 `net.DNSError` 在 transport-pool 包装前被识别为不可重试，临时 DNS 失败仍受既有退避和预检 deadline 约束；验证其他网络错误的分类分支保持不变。

## 3. 编译和命令行验证

- [x] 3.1 运行 `go build ./...`，并以默认 `https3` 访问静默丢包端口和不存在域名，验证命令不会无限等待、失败时输出既有 `SERVER_UNAVAILABLE`，且文件数据传输路径未被引入 15 秒总期限。
