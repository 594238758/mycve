## Why

当 `qtransc` 访问不存在的域名或被静默丢包的端口时，capabilities 预检会无限重试，前台命令没有输出也不会结束。错误地址应在有限时间内报告服务不可用，而不能要求用户手动中断。

## What Changes

- 为 qtransc 直接命令及 qtransc serve 任务启动时的 qtserver capabilities 连接预检设置 15 秒总期限，覆盖 DNS、建连、TLS/QUIC 握手、响应读取和预检重试。
- 永久 DNS 解析失败不再作为可用性故障无限重试；可恢复的网络故障仅可在总期限内重试。
- 预检总期限到达时，直接命令使用既有 `SERVER_UNAVAILABLE` 错误契约返回；serve 任务启动返回既有的任务创建错误。
- 实际文件内容的上传和下载不使用该 15 秒预检期限。

## Capabilities

### New Capabilities

- `client-preflight-timeouts`: 定义 qtransc 在连接 qtserver 前执行 capabilities 预检时的总期限、重试边界和失败行为。

### Modified Capabilities

无。

## Impact

- 受影响代码：`qtransc/internal/qtserverapi` 的 capabilities 获取及其重试上下文、`qtransc/internal/transferretry` 的 DNS 错误分类。
- CLI 与 serve 兼容性：不增加新参数；不可达服务器会从无限等待变为至多约 15 秒后结束预检。直接命令继续使用既有 `SERVER_UNAVAILABLE`，serve 继续使用既有任务创建错误格式。
- 不修改 qtserver API、传输协议选择、认证语义或文件数据传输的时限。
