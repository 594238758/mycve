## Context

`FetchCapabilities` 将调用方的无 deadline context 直接传给可重试的 `DoJSON`。网络层将连接错误包装为 transport-pool 错误，而重试分类在检查 DNS 原因之前已把这类包装错误视为可恢复，因此永久 DNS 失败与静默丢包端口都会进入无限退避循环。详见 `proposal.md` 与 `client-preflight-timeouts` spec。

## Goals / Non-Goals

**Goals:**

- 限定 capabilities 预检的整个生命周期，而非只限制单次 Dial 或单次 HTTP 请求。
- 让永久 DNS 错误在首次失败后结束，保留临时网络故障的有限重试。
- 直接命令复用现有 `SERVER_UNAVAILABLE` 映射，serve 复用现有任务创建错误映射；不增加 CLI 参数或新的错误原因码。

**Non-Goals:**

- 不限制上传、下载的文件内容流或更改其断点续传行为。
- 不修改 transport 的 `https`、`https2`、`https3` 选择和回退规则。
- 不为所有 JSON API 请求引入全局 15 秒上限。

## Decisions

### 在 capabilities 边界创建 15 秒子 context

`FetchCapabilities` 是直接命令和 serve 任务启动共用的 capabilities 边界，将从调用方 context 派生 15 秒 deadline；调用方已有更早 deadline 时，context 的父子关系自然保留更早限制。该 context 传入整个 `DoJSON` 重试循环，因此覆盖 DNS、连接、握手、HTTP 响应和退避等待。deadline 到达后，重试分类看到 context 已结束并退出循环；直接命令由既有 capabilities 访问错误映射为 `SERVER_UNAVAILABLE`，serve 使用既有任务创建错误映射。

选择此边界而非给 `http.Client` 或单次 Dial 单独设超时：单次超时无法限制无限重试；给 `DoJSON` 全局设限会把与本变更无关的控制操作也变为 15 秒失败。

### 在包装 transport-pool 错误前识别 DNS 原因

重试分类先检查错误链中的 `net.DNSError`。非临时且非 timeout 的 DNS 失败不可恢复，直接返回不可重试；DNS timeout 或临时 DNS 错误仍可由既有退避策略处理。随后再处理 transport-pool 错误，保持其他网络错误的现有重试语义。

## Risks / Trade-offs

- [高延迟网络在 15 秒内尚未完成 capabilities] → 命令返回可重试的 `SERVER_UNAVAILABLE`，用户可重新执行；文件数据传输不受该限制。
- [QUIC 实现未及时响应请求 context] → 外层 capabilities deadline 仍停止退避；手工命令验证确认默认 HTTPS3 无响应端口可在期限内退出。
- [DNS 错误包装形态不同] → 使用 `errors.As` 检查完整错误链，并对真实不存在域名和临时 DNS 错误类型进行验证。

## Migration Plan

1. 发布新的 qtransc 二进制。
2. 自动化脚本和 serve 调用方无需传入新参数；不可达 server 将不再无限阻塞，直接命令收到既有 `SERVER_UNAVAILABLE`，serve 收到既有任务创建错误。
3. 若需回滚，移除 capabilities 子 context 与 DNS 分类顺序调整；无需数据或服务端迁移。
