## ADDED Requirements

### Requirement: serve 创建任务 API 接收可选 taskpid

qtransc `serve` 的 `POST /api/v1/tasks` 请求体 SHALL 接受可选 string 字段 `taskpid`。字段缺失或值为空字符串时 SHALL 使用空字符串创建任务；该情况 SHALL NOT 使任务创建、启动或传输失败。`taskpid` SHALL 是不透明的日志关联值，SHALL NOT 具有 task ID、用户 ID、授权标识或幂等键语义。

非空 `taskpid` SHALL 至多为128 bytes且只包含可安全作为HTTP header field value传播的UTF-8文本；不符合该输入格式时serve API SHALL 返回现有invalid-request类别的400响应。qtransc的CLI子命令 SHALL NOT 新增 `taskpid` 参数，非serve创建的任务 SHALL 使用空字符串。

#### Scenario: serve 调用方传入 taskpid

- **WHEN** 调用方使用合法非空`taskpid`创建upload或download任务
- **THEN** qtransc SHALL 保存该原始string作为本任务的日志关联值
- **AND** `taskpid` SHALL NOT 改变任务ID、文件选择或传输结果

#### Scenario: serve 调用方省略 taskpid

- **WHEN** 创建任务请求没有`taskpid`字段或该字段是空字符串
- **THEN** qtransc SHALL 正常创建和启动任务
- **AND** 该任务的日志关联值 SHALL 是空字符串

#### Scenario: CLI 创建任务

- **WHEN** 用户通过非serve CLI子命令创建传输任务
- **THEN** CLI SHALL NOT 提供`taskpid`参数
- **AND** 该任务所有需要共现的日志 SHALL 使用空字符串`taskpid`

#### Scenario: 非法 taskpid

- **WHEN** serve请求提供超过128 bytes或包含非法HTTP field-value字符的非空`taskpid`
- **THEN** qtransc SHALL 以400 invalid request拒绝创建该任务
- **AND** SHALL NOT 截断、改写或部分传播该值

### Requirement: taskpid 与 task ID 同任务传播但不参与业务

qtransc SHALL 在同一upload/download task内保存固定`taskpid`，并在该task所有携带`X-Task-ID`的Qtserver HTTP请求中同时携带`X-Task-PID`；空值也 SHALL 以空string语义传播。Nginx SHALL 显式转发`X-Task-PID`，Qtserver SHALL 将其作为当前请求日志上下文读取。除serve创建任务API外，系统 SHALL NOT 从CLI flag、Qtserver响应、download grant、路径、token、session或其他字段生成或覆盖`taskpid`。

`taskpid` SHALL NOT 参与认证、授权、principal、文件空间、路径规范化、download grant或HMAC、upload session ownership、业务幂等、`file_key`、Range、hash、重试、任务状态或传输结果。相同业务请求在`taskpid`缺失、为空、不同或由第三方伪造时，除日志内容外 SHALL 具有相同业务行为。

Canonical upload session SHALL 保存创建session时与初始task ID一起收到的初始`taskpid`，并为该session后续原始业务事件继续使用这组初始日志关联值；后续请求当前`X-Task-PID`不同只 MAY 出现在请求运行日志中，SHALL NOT 改变session或原始事件的文件活动关联。

#### Scenario: 任务请求携带两个日志关联header

- **WHEN** qtransc为一个serve任务发送带`X-Task-ID`的Qtserver请求
- **THEN** 同一请求 SHALL 同时携带`X-Task-PID`
- **AND** 其值 SHALL 等于任务创建时保存的`taskpid`

#### Scenario: 空 taskpid 继续传输

- **WHEN** qtransc任务的`taskpid`为空字符串
- **THEN** Qtserver SHALL 按现有task ID、身份和业务参数执行请求
- **AND** SHALL NOT 因`X-Task-PID`缺失或为空拒绝请求

#### Scenario: 第三方改变 taskpid

- **WHEN** 两个其他条件相同的请求携带不同`X-Task-PID`
- **THEN** Qtserver SHALL 只在对应日志中记录各自值
- **AND** 授权、session、文件状态和HTTP业务结果 SHALL 不因此改变

#### Scenario: canonical upload后续请求改变 taskpid

- **WHEN** 同principal对已有canonical upload session发送与创建时不同的`X-Task-PID`
- **THEN** Qtserver SHALL 按现有session契约继续处理请求
- **AND** 该session的原始业务事件 SHALL 继续使用创建时保存的初始`taskpid`

### Requirement: 结构化运行日志中的 task ID 与 taskpid 必须共现

qtransc、Qtserver和Nginx的结构化运行或访问日志中，只要一条记录包含名为`taskid`或`task_id`的结构化字段，同一条记录 SHALL 同时包含名为`taskpid`的string字段。存在关联值时 SHALL 记录该值；无值时 SHALL 显式记录空字符串，不得省略、写`null`或用占位符替代。该共现规则只约束日志记录，不要求含`task_id`的普通HTTP API响应或内部非日志数据模型新增`taskpid`。

Qtserver请求日志 SHALL 使用当前请求`X-Task-PID`，且其值 SHALL 经过结构化JSON日志编码。日志 SHALL NOT 因`taskpid`内容改变级别、消息、错误处理或采样决策。Authorization、grant、HMAC secret或token仍 SHALL NOT 因该关联值而进入日志。

#### Scenario: serve任务写qtransc运行日志

- **WHEN** qtransc为带非空`taskpid`的任务写出一条含`taskid`或`task_id`字段的结构化日志
- **THEN** 同一条日志 SHALL 包含值相同的string字段`taskpid`

#### Scenario: CLI任务写qtransc运行日志

- **WHEN** 非serve CLI任务写出一条含`taskid`或`task_id`字段的结构化日志
- **THEN** 同一条日志 SHALL 包含`"taskpid":""`

#### Scenario: Qtserver请求错误日志

- **WHEN** 携带`X-Task-ID`和`X-Task-PID`的请求在Qtserver产生结构化错误日志
- **THEN** 该记录的task ID字段与`taskpid` SHALL 同时存在
- **AND** `taskpid` SHALL NOT 改变返回给客户端的业务错误
