## ADDED Requirements

### Requirement: schema v1 使用包含 taskpid 的最小公共 envelope

当前 Qtserver 和 Nginx producer SHALL 输出 schema v1 原始业务事件。每条事件 SHALL 是单行 JSON object，并且公共字段 SHALL 恰好是 `schema_version`、`event_type`、`occurred_at`、`task_id`、`taskpid`、`file_key` 和 object 类型 `payload`。七项 SHALL 全部存在；`task_id` 与 `file_key` SHALL 是非空 string，`taskpid` SHALL 是允许为空的 string，`schema_version` SHALL 是 integer `1`。Envelope 未知字段 SHALL 使整行无效。

`occurred_at`、typed payload、事件时间、未知 payload 字段、attempt、去重和时钟规则 SHALL 保持 schema v1 的既有契约。Schema v1 SHALL NOT 新增 event ID、operation ID、session ID、report ID、fingerprint、producer instance、source sequence、started event 或客户端状态 event。当前 producer SHALL 只输出本 spec 为对应 event type 定义的已知 payload 字段。

本项目当前只开发 schema v1，producer 和本变更 SHALL NOT 实现或声明多版本读取、版本迁移或版本协商。

#### Scenario: v1事件携带非空taskpid

- **WHEN** producer为带非空日志关联值的请求输出原始业务事件
- **THEN** envelope SHALL 同时包含非空`task_id`和相同string值的`taskpid`
- **AND** `schema_version` SHALL 是 integer `1`

#### Scenario: v1事件的taskpid为空

- **WHEN** 文件活动没有外部`taskpid`
- **THEN** 每条 v1 事件仍 SHALL 显式包含`"taskpid":""`
- **AND** producer SHALL NOT 省略该字段或写`null`

#### Scenario: v1出现额外envelope字段

- **WHEN** schema v1 行在七个规定字段之外包含其他顶层字段
- **THEN** decoder SHALL 将该行作为无效envelope隔离

### Requirement: schema v1只定义七类原始业务事件

Schema v1 合法`event_type` SHALL 继续限于：

```text
file.registered
upload.chunk_finished
upload.verify_finished
upload.finished
download.chunk_finished
download.verify_finished
download.small_file_sent
```

Producer SHALL NOT 因新增`taskpid`输出`task.registered`、task state、file result、operation started、pause、resume或客户端completed/failed/abandoned事件。七类事件的payload、活动窗口、成功事实、timeout和修订职责 SHALL 保持 schema v1 既有契约；`taskpid` SHALL NOT 新增事件类型、状态或归约分支。

#### Scenario: taskpid变化不产生新事件类型

- **WHEN** 同一文件活动后续请求的`taskpid`与注册时不同
- **THEN** producer SHALL 仍只输出对应传输事实的既有event type
- **AND** SHALL NOT 输出taskpid changed或task级事件

### Requirement: taskpid 在原始事件中只作记录

每条 schema v1 原始业务事件 SHALL 在`task_id`旁记录`taskpid`，有值时原样记录，无值时显式记录空字符串。

Canonical upload SHALL 使用session创建时保存的初始task ID和初始`taskpid`输出该session的全部原始事件。普通下载和small事件 SHALL 使用对应请求的可信Qtserver日志上下文；X-Accel普通下载chunk事件 SHALL 使用Qtserver交给Nginx的内部`taskpid` handoff，而不得直接信任客户端同名内部header。

`taskpid` SHALL NOT 参与`file_key`算法、注册合法性、上下文冲突、事件有效性、attempt、inactivity deadline、transmitted、retry count、speed、result、result reason或其他业务判断。

#### Scenario: 原始事件记录taskpid

- **WHEN** Qtserver 为带非空`taskpid`的文件活动输出原始事件
- **THEN** 同一 envelope SHALL 同时包含原`task_id`和相同 string 值的`taskpid`
- **AND** typed payload SHALL 与空`taskpid`时保持相同

#### Scenario: 后续事件携带不同taskpid

- **WHEN** 最早合法注册之后的chunk、verify或finished事件携带不同`taskpid`
- **THEN** producer SHALL 在各事件中记录对应的日志上下文值
- **AND** 该差异 SHALL NOT 改变事件类型、payload或业务结果

#### Scenario: taskpid不同但文件活动相同

- **WHEN** 两个请求只在`taskpid`上不同而task ID、路径、principal和action相同
- **THEN** `file_key` SHALL 保持相同
- **AND** `taskpid` SHALL NOT 创建新的文件活动

## MODIFIED Requirements

### Requirement: 原始业务事件和调试日志相互隔离

Qtserver SHALL 将 schema v1 原始业务事件以 UTF-8 JSON Lines 写入独立 `business_events.log`；Nginx SHALL 将普通下载完成事件以 JSON Lines 写入独立 `download_events.log`。`qtserver.log`、`gin.log`、Nginx `access.log`/`error.log`、stdout/stderr 和 qtransc 本地日志 SHALL 属于调试或运行日志，SHALL NOT 作为业务分析输入。

只有完成业务准入、获得可信 principal 与规范路径并实际进入文件传输流程的请求才能产生原始业务事件。未认证、非法参数、非法路径、扫描请求及业务准入前失败 SHALL 只进入访问、安全或调试日志。

#### Scenario: 调试级别改变

- **WHEN** 运维关闭 debug 日志或提高日志级别
- **THEN** 原始业务事件 SHALL 继续按相同契约输出
- **AND** 分析结果 SHALL 不受调试级别影响

#### Scenario: 非法请求

- **WHEN** 请求在形成合法文件活动前因认证、参数或路径校验失败
- **THEN** Qtserver SHALL NOT 为它输出原始业务事件

### Requirement: 普通下载完成事件覆盖实际响应与整文件校验

普通下载每个 `/d/down` GET SHALL 使用请求头 `X-QT-Chunk-Index` 携带非负十进制integer `chunk_index`，包括Range GET与无Range完整文件GET；同一客户端分片的断点续传和重试 SHALL 保持相同chunk index，单请求完整GET SHOULD 使用0。该请求头缺失、格式非法或超出实现可接受整数范围时，Qtserver SHALL 在输出 `file.registered` 或开始发送数据前拒绝请求，并 SHALL NOT 为该请求输出原始业务事件。该值 SHALL 只用于原始日志分片关联和 retry count 分组，SHALL NOT 参与认证、授权、grant校验、文件定位、Range计算或传输成功判定。

普通`/d/down` SHALL 只为`file_size>0`的文件产生数据和chunk事件：Range GET使用规范非空半开区间，完整GET使用`[0,file_size)`。零字节下载 SHALL 走small路径，Qtserver SHALL NOT 为它构造`[0,0)`的`download.chunk_finished`。

#### Scenario: 无Range完整文件GET

- **WHEN** qtransc以`X-QT-Chunk-Index: 0`对非空普通文件执行无Range完整GET
- **THEN** `download.chunk_finished`的Range SHALL 是`[0,file_size)`且expected status为200

#### Scenario: 零字节文件不走普通GET

- **WHEN** download grant表示file size为0
- **THEN** qtransc SHALL 使用small路径而不调用`/d/down`
- **AND** Qtserver SHALL NOT 输出空Range的download chunk事件

Qtserver SHALL 校验外部请求头并通过以下八个只对Nginx可见的内部响应头重新构造可信handoff：

```text
X-QT-Log-Task-ID
X-QT-Log-Task-PID
X-QT-Log-File-Key
X-QT-Log-Chunk-Index
X-QT-Log-Range-Start
X-QT-Log-Range-End
X-QT-Log-Expected-Status
X-QT-Log-Expected-Bytes
```

它们 SHALL 分别表示`task_id`、允许为空的`taskpid`、`file_key`、已校验`chunk_index`、规范半开Range两端、预期200或206状态及`range_end-range_start`。Nginx SHALL 只使用对应的`$upstream_http_x_qt_log_*`值构造业务事件，SHALL NOT 直接读取客户端`X-QT-Chunk-Index`、`X-Task-PID`或客户端提交的任意内部同名header，并 SHALL 从客户端响应隐藏全部八项。Schema version 1与`event_type=download.chunk_finished` SHALL 是专用Nginx log format常量；Qtserver SHALL NOT 为schema v1 handoff传递event ID、operation ID、started time、producer或file size。

Nginx SHALL 在写专用业务事件前使用map或等价配置验证除允许为空的`taskpid`外七项upstream handoff结构合法：task ID与file key非空，chunk index、Range端点与expected bytes为非负十进制integer文本，expected status为`200|206`。`taskpid`为空 SHALL NOT 阻止事件写入。只有结构检查通过时，internal location才 SHALL 使用条件`access_log`写入`download_events.log`。缺失或非法必要handoff、客户端直接访问internal location以及非X-Accel请求 SHALL NOT 向业务事件文件写入含`-`占位符或非JSON数值的行；它们 MAY 由普通access/error log记录。Range顺序、expected bytes与Range宽度等跨字段关系仍 SHALL 由schema decoder校验。

实际数据发送方 SHALL 在普通下载响应结束时输出 `download.chunk_finished`，payload 包含非负`chunk_index`、`range_start`、`range_end`、非负 `actual_bytes`、`http_status`和`result=succeeded|interrupted|failed`。范围 SHALL 满足`0 <= range_start < range_end <= file_size`，actual bytes SHALL 不大于Range宽度，HTTP status SHALL 是`100..599` integer，succeeded SHALL 只允许状态200或206且actual bytes等于Range宽度。启用X-Accel时producer SHALL 是Nginx，direct模式 SHALL 是qtserver；两者 SHALL 使用完全相同的payload语义。`actual_bytes` SHALL 是本响应实际发送的文件内容字节。

两种producer SHALL 按以下规则确定结果：

- 实际HTTP状态等于expected status、200没有Content-Range或206具有合法单区间Content-Range、请求正常结束且实际body bytes等于expected bytes时，`result` SHALL 是`succeeded`、`actual_bytes` SHALL 是实际body bytes。
- 状态与Content-Range仍表示预期文件数据响应，但请求未正常结束或body bytes与expected bytes不同，`result` SHALL 是`interrupted`、`actual_bytes` SHALL 是实际发送的文件body bytes。
- 实际状态不等于expected status，或206 Content-Range格式无效，`result` SHALL 是`failed`、`actual_bytes` SHALL 是0。错误响应body SHALL NOT 计作文件内容传输字节。

Nginx SHALL 使用`$request_completion`、`$status`、`$sent_http_content_range`和`$body_bytes_sent`形成上述事实，`occurred_at` SHALL 使用log phase时间。第一版 SHALL NOT 要求Nginx再次逐字符证明Content-Range与handoff Range完全相等；预期状态、Range格式与expected bytes校验 SHALL 是本契约要求的边界。Direct模式 SHALL 使用可获得的请求context、响应状态和实际writer bytes实现同一可观察语义。

Qtserver 每次通过认证、参数、路径等前置校验并实际开始读取、计算或比较hash的普通下载校验结束后 SHALL 输出 `download.verify_finished`，其已知payload字段 SHALL 是 `verification_scope=chunk|file`、适用的`chunk_index`与`verification_result=matched|mismatched|failed`。完成比较且一致时 SHALL 使用`matched`，完成比较但不一致时 SHALL 使用`mismatched`，进入校验执行后因读取、计算或依赖错误无法得出结论时 SHALL 使用`failed`。请求前置校验失败以及服务端hash为`HASH_PENDING`或`HASH_UNAVAILABLE`、尚无可比较结果时 SHALL NOT 输出verify完成事件，也 SHALL NOT 刷新文件不活动deadline。当前producer SHALL NOT 输出其他payload字段；consumer仍 SHALL 按公共规则保留并忽略未来未知payload字段。Scope为chunk时chunk index SHALL 是非负integer；scope为file时chunk index SHALL 是null。只有整文件 `matched` SHALL 是 `SUCCESS/DOWNLOADED_AND_VERIFIED` 的权威成功事实；分片 matched 和整文件 mismatched/failed 都不结束文件。

#### Scenario: 下载服务端hash仍在生成

- **WHEN** 整文件`/d/verify`得到`HASH_PENDING`或`HASH_UNAVAILABLE`且尚未开始比较hash
- **THEN** Qtserver SHALL NOT 输出`download.verify_finished`
- **AND** 该请求 SHALL NOT 刷新日志不活动deadline

#### Scenario: 下载hash计算执行失败

- **WHEN** Qtserver已经开始读取或计算下载校验hash但因I/O或依赖错误无法完成比较
- **THEN** SHALL 输出`download.verify_finished{verification_result=failed}`
- **AND** 该事件 SHALL 刷新当前有效的不活动deadline但不得建立文件失败终态

Schema v1 payload SHALL NOT 要求或输出expected hash、actual hash、hash algorithm、请求级reason code或异常文本。现有文件hash存储和调试日志 MAY 保存其职责内的信息，但分析程序 SHALL NOT 读取它们补齐或覆盖原始业务事件。

普通用户与内置 `anonymous` 用户 SHALL 使用相同 Range、整文件 verify 和日志分析流程。两者的身份解析方式 MAY 不同，但 SHALL NOT 形成不同的下载业务类型。整文件 matched 已经证明客户端持有一致内容，因此 qtransc SHALL NOT 再调用独立下载完成确认 API。

#### Scenario: 断点续传改变 Range 起点

- **WHEN** qtransc 对同一个 chunk 从后续 offset继续 Range 下载
- **THEN** 新请求的 `X-QT-Chunk-Index` SHALL 保持原 `chunk_index` 并携带实际新 Range
- **AND** 分析程序 SHALL 将它计作该 chunk 的额外 attempt

#### Scenario: 下载请求缺少 chunk index

- **WHEN** 普通 `/d/down` 请求缺少合法 `X-QT-Chunk-Index`
- **THEN** Qtserver SHALL 在注册文件或发送数据前拒绝请求
- **AND** SHALL NOT 输出 `file.registered` 或 `download.chunk_finished`

#### Scenario: 客户端伪造 Nginx 日志字段

- **WHEN** 客户端同时提交`X-QT-Chunk-Index`、`X-Task-PID`和任意`X-QT-Log-*`内部header
- **THEN** Qtserver SHALL 只校验外部chunk index并从当前请求日志上下文重新构造全部内部handoff
- **AND** Nginx SHALL 只使用qtserver upstream的`X-QT-Log-*`值

#### Scenario: Nginx专用格式固定schema和event type

- **WHEN** Nginx记录一条X-Accel普通下载完成事件
- **THEN** log format SHALL 直接输出integer`schema_version=1`和string`event_type=download.chunk_finished`
- **AND** SHALL NOT 从handoff读取这两个常量或输出其他公共字段

#### Scenario: Nginx缺少完整必要handoff

- **WHEN** internal location请求没有结构合法的task、file、chunk、Range、expected status和expected bytes upstream handoff
- **THEN** Nginx SHALL NOT 向`download_events.log`写入该请求
- **AND** SHALL NOT 生成包含`-`或非JSON数值的半条schema v1 JSON

#### Scenario: Nginx收到空taskpid

- **WHEN** 其他必要handoff合法但`X-QT-Log-Task-PID`为空或缺失
- **THEN** Nginx SHALL 写出合法 v1 事件并包含`"taskpid":""`

#### Scenario: 未启用Nginx加速

- **WHEN** qtserver direct模式处理一个普通Range下载
- **THEN** qtserver SHALL 在响应结束后输出`download.chunk_finished`
- **AND** 分析程序 SHALL 与Nginx事件使用相同规则归约

#### Scenario: X-Accel连接中途断开

- **WHEN** Nginx已经开始合法文件数据响应但`$request_completion`不是`OK`
- **THEN** Nginx SHALL 输出`download.chunk_finished{result=interrupted}`
- **AND** `actual_bytes` SHALL 使用已经发送的文件body bytes

#### Scenario: X-Accel返回错误状态

- **WHEN** internal文件发送实际状态不等于qtserver handoff的expected status
- **THEN** Nginx SHALL 输出`download.chunk_finished{result=failed}`
- **AND** `actual_bytes` SHALL 是0，即使错误响应本身发送了body

#### Scenario: Nginx内部日志header不暴露

- **WHEN** 客户端收到X-Accel普通下载响应
- **THEN** SHALL 看不到上述八个tasks、task、file、chunk、Range、expected status或expected bytes handoff header

#### Scenario: 响应完整但没有整文件 verify

- **WHEN** 所有 Range 响应均成功但没有整文件 matched 事实
- **THEN** 普通下载 SHALL NOT 成为成功
- **AND** SHALL 在 inactivity deadline 后形成 `FAILED/TIMEOUT`

#### Scenario: anonymous 用户执行普通下载

- **WHEN** 使用 `anonymous` 用户的 qtransc 完成普通下载并通过整文件 verify
- **THEN** 文件 SHALL 成为 `SUCCESS/DOWNLOADED_AND_VERIFIED`
- **AND** principal 与 username SHALL 使用 `anonymous`

### Requirement: 原始事件写入、轮转和凭据边界明确

Qtserver active 文件 SHALL 固定为 `log.file_path/business_events.log`；Nginx active 文件 SHALL 固定为 `/opt/qtrans/nginx/logs/download_events.log`。每个事件 SHALL 完整占一行并以换行结束；压缩 SHALL 只处理已经关闭的轮转段。Active 文件末尾未换行内容 SHALL 留待下次采集，关闭段中的不完整行 SHALL 被隔离。

Qtserver writer SHALL 串行append完整行，并在`file.registered`、`upload.finished`、整文件matched的`download.verify_finished`以及`download.small_file_sent`上完成sync后才报告事件持久成功。处于logging-unhealthy时Qtserver SHALL 拒绝所有下一步会产生schema v1事件的传输或校验API，而不只是新文件起点；不产业务事件的健康、恢复和查询操作 MAY 继续。Writer或健康组件 SHALL 能在不写伪业务事件且不依赖事件生产API越过gate的情况下独立执行reopen与文件级sync/状态探测；成功后 SHALL 先清除gate，再恢复事件生产API。恢复流程 SHALL NOT 因业务请求被gate拒绝而自锁。

Writer SHALL 在每次append前记录受同一串行锁保护的active文件边界。完整行已经写入但sync失败时 SHALL 只重试sync，不得再次append；partial write后只有成功truncate并sync回写前边界时才 MAY 重试append。无法确认边界、truncate失败或无法验证最后完整换行时 SHALL 保持logging-unhealthy，不得盲目重写。独立恢复流程 MAY 截断active文件最后一个完整换行之后的不完整尾部并完成sync；SHALL NOT 改写已经关闭的segment。轮转 SHALL 与append使用同一串行边界。上述规则 SHALL 防止producer把一次chunk事实自身重复写成多个真实attempt。

`file.registered`写入或sync失败 SHALL 在业务动作前返回稳定、可重试的日志不可用错误。Qtserver过程事件在请求业务事实已经发生后写失败 SHALL NOT 回滚已经接收、写入或校验的数据，当前请求 SHALL 返回其真实业务结果，同时 SHALL 进入logging-unhealthy并gate后续事件生产API。Producer SHALL NOT 为促使重试而把已经成功接受的PATCH伪装成业务失败。

真实committed、already-present或整文件verify matched发生后，Qtserver SHALL 在对应终态事件append并sync成功前不向客户端返回成功。写入失败 SHALL NOT 回滚真实文件或hash一致事实，但当前请求 SHALL 返回可重试的日志不可用错误；客户端以后对同一幂等API重试时，Qtserver SHALL 能再次输出内容一致的成功事件并在持久成功后返回业务成功。分析程序 SHALL 使用最早合法成功事实，不要求event ID。

Direct下载响应完成后写chunk事件失败 SHALL NOT 回滚响应，但 SHALL 使Qtserver logging-unhealthy并接受本次统计事实缺失。Small文件entry结束后 SHALL append并sync其成功事件再开始下一个entry；写入或sync失败 SHALL 停止继续生成该批次的后续文件响应、使Qtserver logging-unhealthy且不得撤回当前entry，第一版接受当前文件成功事实缺失。Nginx access-log phase写入失败 SHALL 通过Nginx error log与采集监控暴露，已发送响应不得回滚；第一版 SHALL NOT 要求Nginx反向修改Qtserver健康状态。

原始事件 SHALL NOT 包含 Authorization、access/refresh token、download grant、HMAC secret、anonymous fixed token、TLS key、请求 body或其他 credential。客户端 metadata SHALL 只用作日志上下文，服务端权威身份、IP、路径、大小、hash与发布结果 SHALL 使用已验证事实。

#### Scenario: commit 后日志写入失败

- **WHEN** 文件已原子发布但 `upload.finished` 无法写入
- **THEN** Qtserver SHALL NOT 回滚已发布文件
- **AND** 当前complete请求 SHALL 返回可重试的日志不可用错误
- **AND** SHALL 进入logging-unhealthy并拒绝后续事件生产API

#### Scenario: writer恢复后重试已提交文件

- **WHEN** writer恢复后客户端重试一个文件已经committed但终态日志曾失败的complete请求
- **THEN** Qtserver SHALL 再次构造内容一致的`upload.finished{result=committed}`并可靠写入
- **AND** 写入成功后 SHALL 返回业务成功

#### Scenario: 过程事件写入失败

- **WHEN** 上传chunk数据已经被接受但对应`upload.chunk_finished`最终无法写入
- **THEN** Qtserver SHALL NOT 回滚或伪造未接收该数据
- **AND** 当前PATCH SHALL 返回已经接受数据的真实业务结果
- **AND** SHALL 进入logging-unhealthy并拒绝后续事件生产API

#### Scenario: 完整行写入后sync失败

- **WHEN** writer已确认当前chunk事件完整行存在但后续sync失败
- **THEN** writer SHALL 只重试sync且不得再次append该事件
- **AND** 分析结果 SHALL NOT 因writer恢复产生虚假的额外attempt

#### Scenario: partial write无法安全回滚

- **WHEN** writer发生partial write且无法truncate并sync回写前边界
- **THEN** SHALL 保持logging-unhealthy且不得盲目重写该行
- **AND** 独立恢复流程 SHALL 只清除active文件最后完整换行之后的不完整尾部

#### Scenario: small事件写入失败

- **WHEN** 当前small tar entry已经结束但`download.small_file_sent`无法写入
- **THEN** Qtserver SHALL NOT 撤回已经写出的entry
- **AND** SHALL 停止继续写该批次后续文件并进入logging-unhealthy

#### Scenario: small事件sync成功后继续批次

- **WHEN** 当前small tar entry结束且其`download.small_file_sent`已经append并sync成功
- **THEN** Qtserver MAY 开始写下一个文件entry
- **AND** 后续entry失败 SHALL NOT 撤回当前文件成功事实

#### Scenario: 内部 handoff header

- **WHEN** Nginx 返回一个普通下载响应
- **THEN** 所有 qtserver 提供的日志 handoff header SHALL 对客户端隐藏
