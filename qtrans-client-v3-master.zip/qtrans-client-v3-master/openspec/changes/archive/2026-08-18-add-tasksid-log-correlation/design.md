## Context

见 [proposal.md](proposal.md) 的 Why。当前 `task_id` 存在三条相连路径：qtransc 内存 task 与运行日志、qtransc 到 Qtserver 的 `X-Task-ID` 请求上下文、Qtserver/Nginx 产生的 schema v1 原始业务事件。`TaskCreateRequest` 虽已有 `server_task_id`，但它会替代对 Qtserver 使用的 task ID，不是可并行记录的第二关联值，不能复用为 `taskpid`。

项目仍在开发第一版协议。`taskpid` 直接加入 schema v1，不建立多版本读取或迁移契约。Canonical upload 会跨请求保存初始 task ID 并用它产生后续事件，`taskpid` 采用相同的日志连续性，但不得进入 session ownership 或 qtransc 本地恢复业务键。

## Goals / Non-Goals

**Goals:**

- 用一个固定名称贯通 serve API、HTTP header、运行日志和 schema v1 原始事件。
- 让 qtransc 和 Qtserver 中所有具有 task ID 结构化字段的日志稳定共现 string `taskpid`，无值时显式写空字符串。
- 通过集中式 helper 和 task 接口减少新增请求或日志漏带 `taskpid` 的风险。

**Non-Goals:**

- 不把 `taskpid` 加入普通任务 API 响应、SSE 事件协议、WebSocket 协议或 CLI flags。
- 不以 `taskpid` 查询、划分、授权或恢复 task、file、session 和 principal。
- 不把 `taskpid` 加入 qtransc upload SQLite 业务键或 `file_key` 输入。
- 不新增配置开关或 schema 版本协商。

## Decisions

### 1. 外部命名固定且不复用 server_task_id

外部名称固定为：serve JSON 字段 `taskpid`、HTTP 请求 header `X-Task-PID`、结构化日志和原始事件 JSON 字段 `taskpid`、Qtserver 到 Nginx 内部 header `X-QT-Log-Task-PID`。Go 字段使用 `TaskPID`。

qtransc `TaskCreateRequest`、`UploadTask` 和 `DownloadTask` 新增独立 `TaskPID`；现有 `TaskID` 和 `ServerTaskID` 语义不变。`domain.Task` 新增 `GetTaskPID() string`，使只持有接口的日志点能同时输出两个字段。CLI 构建的 request 不赋值，因此自然得到 empty string，不新增 flag 或隐式生成值。

### 2. 仅做传输安全校验，不解释业务格式

Serve handler 在创建 task 前验证 `taskpid` 最多 128 bytes、是合法 UTF-8 且不含 HTTP field value 禁止的控制字符；empty string 合法。验证不 trim、不截断、不生成、不解析前缀，也不校验 UUID 或其他业务格式。非法值返回现有 400 invalid-request 响应。

所有合法值进入 task 后保持不可变。该输入边界不赋予 `taskpid` 业务语义。

### 3. qtransc 集中设置相关 header 和日志属性

qtransc 为 task 相关请求提供统一 helper，接收 `taskID, taskPID` 并同时设置 `X-Task-ID` 和 `X-Task-PID`。现有 `qtserverapi.DoJSON*` 调用链增加 `taskPID` 参数；手写 upload/download 请求也调用同一 helper。

UploadTask 和 DownloadTask 的 logger 同时绑定 `taskid` 与 `taskpid`。TaskManager、scheduler 和 serve handler 中自行输出 `task_id` 的日志通过 `domain.Task.GetTaskPID()` 或删除前捕获的 task 值补齐 `taskpid`。Upload2/download2 及 legacy WebSocket 等非 serve 日志只要显式输出 task ID，就显式输出 empty string `taskpid`。

### 4. Qtserver 区分当前请求值与文件活动初始值

请求 logger middleware 读取 `X-Task-ID` 与 `X-Task-PID`，始终把 `task_id` 和 `taskpid` 绑定到派生 logger。原始业务事件构造函数和 `fileLogContext` 显式接收 `taskpid`。

普通上传 init 创建 canonical session 时，把初始 `TaskPID` 与现有 `TaskID`、`FileKey` 一起保存在服务端 session JSON；后续 chunk/finalize/complete 事件从 session 读取这组初始值。当前请求 logger 仍记录当前 header，因此恢复请求改变 `X-Task-PID` 时只体现为调试信息，不改变原始文件活动历史。

### 5. taskpid 直接进入 schema v1 envelope

Qtserver `businessevents.Envelope` 保持 schema version 1，并新增非 omitempty 的 `TaskPID string`。所有 Qtserver producer 输出严格七字段 v1 envelope。Writer 的 durability、轮转、unhealthy gate、事件类型和 payload 类型完全不变。

`taskpid` 是公共日志关联字段，因此放在 envelope 的 `task_id` 旁，不在七种 payload 内重复，也不增加事件类型、状态或归约分支。本次不实现其他 schema version 的读写或兼容逻辑。

### 6. Nginx 使用可信 handoff 输出 schema v1

生成的 Nginx 代理 location 显式设置 `X-Task-PID $http_x_task_pid`。Qtserver 处理普通下载后设置 `X-QT-Log-Task-PID`，Nginx business log format 使用 `escape=json` 把它写为顶层 `taskpid`，`schema_version` 常量保持为 1。该内部 header 与现有 handoff 一起被 `proxy_hide_header` 隐藏。

现有必要 handoff 有效性检查不使用 `taskpid`；它允许为空，不影响真实下载完成事件是否落盘。Nginx 不得直接使用客户端 `X-Task-PID` 构造业务事件，只读取 Qtserver upstream handoff。

### 7. 文档与范围

`qtransc/docs/qtransc-apis.md` 记录 serve 请求字段、输入限制和不返回该字段的边界；`qtserver/docs/qtserver-apis.md` 记录 `X-Task-PID` 只用于日志。Qtserver 部署和配置文档使用 schema v1，并删除多版本迁移表述。配置权威文件不变，因为本 change 没有配置字段。

## Risks / Trade-offs

- [请求构造点分散导致漏 header] -> 使用统一 correlation helper，并审计所有设置 `X-Task-ID` 的请求点。
- [结构化日志点遗漏 `taskpid`] -> 审计 qtransc/Qtserver 所有显式 `taskid`/`task_id` 日志字段。
- [Canonical upload 恢复时当前值与初始值不同] -> 请求日志记录当前值，原始业务事件固定 session 初始值。
- [taskpid 高基数或恶意内容放大日志] -> serve 入口限制 128 bytes 并拒绝控制字符；Qtserver 不使用它进行权限或业务判断。
