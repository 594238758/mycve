## Why

调用 qtransc `serve` API 的上层业务需要提供一个独立于 `task_id` 的日志关联值 `taskpid`，以便在既有任务日志中关联外部业务。该值允许为空，只用于原样记录和跨组件传播，不得改变传输、授权、状态或业务结果。

## What Changes

- qtransc `serve` 的创建任务 API 新增可选 string 字段 `taskpid`；未提供或提供空值时任务仍正常创建，CLI 子命令不新增对应参数。
- qtransc 在任务生命周期内保存 `taskpid`，并在所有携带 `X-Task-ID` 的 qtserver 请求中同时携带 `X-Task-PID`。Nginx 显式转发该 header。
- qtransc 和 qtserver 的结构化运行日志建立共现约束：只要一条日志包含 `taskid` 或 `task_id` 字段，同一条日志就必须包含 string 字段 `taskpid`；没有关联值时写空字符串，而不是省略字段。
- 当前原始业务事件协议仍为 schema v1。Qtserver 与 Nginx 产生的 v1 envelope 在 `task_id` 旁直接增加必填 string 字段 `taskpid`，允许为空；不建立多版本读取或版本迁移。
- `taskpid` 不参与身份认证、权限、路径、download grant/HMAC、upload session ownership、业务幂等、`file_key`、任务状态、重试判断或业务结果计算。
- 非目标：不新增 `/taskid` 的服务端状态，不为 CLI 增加 `taskpid` flag，不允许其他请求字段覆盖 `taskpid`，也不把它作为可信审计身份。
- 本次实现范围仅包括 qtransc、qtserver、Nginx 配置及其文档。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `transfer-task-correlation`：定义 serve API 的可选 `taskpid`、任务内传播、HTTP header、运行日志共现和非业务语义。
- `raw-business-event-log`：定义 schema v1 的 `taskpid` envelope 字段以及 Qtserver/Nginx producer 行为。

## Impact

- qtransc：创建任务请求模型、serve handler、upload/download task 运行模型、所有携带 task ID 的 HTTP 请求构造、结构化日志上下文和 `qtransc/docs/qtransc-apis.md`。
- qtserver：请求日志 middleware、canonical upload session 日志上下文、schema v1 原始业务事件 envelope、download Nginx handoff、生成的 Nginx 配置及 qtserver 文档。
- 不新增第三方依赖，不新增配置字段。
