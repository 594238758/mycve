## 1. qtransc taskpid 输入与任务模型

- [x] 1.1 为 `TaskCreateRequest` 增加 `taskpid` JSON 字段，实现 empty 合法、128 bytes 和安全 HTTP field-value 校验，并保持所有 CLI 构造路径默认 empty 且不新增 flag。
- [x] 1.2 为 upload/download task 和 `domain.Task` 增加固定 `TaskPID`/`GetTaskPID()`，保持 `TaskID`、`ServerTaskID` 及 qtransc SQLite 业务键不变。
- [x] 1.3 让 TaskManager、scheduler、task logger 及 upload2/download2/legacy 显式 task ID 日志同步输出 string `taskpid`，非 serve 路径固定 empty，并审计 qtransc 全部结构化 task ID 日志点。

## 2. qtransc 到 Qtserver 的传播

- [x] 2.1 增加统一 task correlation header helper，同时设置 `X-Task-ID` 与 `X-Task-PID`，并扩展 `qtserverapi.DoJSON*` 调用链传递 `TaskPID`。
- [x] 2.2 将 upload init/chunk/finalize/complete/cancel/release 及 download browse/grant/small/down/verify 等所有现有 `X-Task-ID` 请求点切换到统一 helper，保证 empty `taskpid` 不改变请求业务结果。

## 3. Qtserver 请求日志与原始事件

- [x] 3.1 在 Qtserver 请求 logger middleware 中读取当前 `X-Task-PID` 并与 `task_id` 共现绑定，补齐其他显式 task ID 运行日志点且不改变错误处理或授权。
- [x] 3.2 保持原始业务事件为严格 schema v1，在 envelope 中增加非 omitempty `taskpid`，扩展 `fileLogContext` 和所有 Qtserver 事件构造路径传递该字段。
- [x] 3.3 在 canonical upload session 中保存初始 `taskpid`，后续 session 事件使用初始 task ID 和 `taskpid`，当前请求 logger 仍使用当前 header。
- [x] 3.4 为普通下载增加可信 `X-QT-Log-Task-PID` 内部 handoff，确保 direct、verify 和 small 事件使用正确请求日志上下文，且所有内部日志 header 对客户端隐藏。

## 4. Nginx schema v1 日志

- [x] 4.1 更新 Nginx 生成配置，显式代理 `X-Task-PID`、隐藏 `X-QT-Log-Task-PID`，并在 `qtrans_business_event` 中输出 `schema_version=1` 及 JSON 转义的 `taskpid`。
- [x] 4.2 保持现有必要 handoff 有效性检查，允许 `taskpid` 为空且不以它决定是否记录 download chunk 事件，并同步生产部署模板中的 Nginx 示例。

## 5. 文档同步

- [x] 5.1 更新 `qtransc/docs/qtransc-apis.md`，记录 serve `taskpid` 输入、校验、empty 行为、header 传播及不进入响应/SSE/CLI 的边界。
- [x] 5.2 更新 `qtserver/docs/qtserver-apis.md`、`qtserver/docs/deploy.md` 和 `qtserver/docs/config.md`，记录 `X-Task-PID` 日志语义、schema v1 envelope、Nginx handoff 和非业务边界，删除多版本迁移表述。

## 6. 编译与一致性验证

- [x] 6.1 对改动 Go 文件执行 `gofmt`，静态审计所有 `X-Task-ID` 请求点均携带 `X-Task-PID`，以及 qtransc/Qtserver 所有结构化 `taskid`/`task_id` 日志点均共现 string `taskpid`。
- [x] 6.2 分别编译 `qtransc` 和 `qtserver` 全部 packages，确认 schema v1 及跨模块签名变更编译通过；不运行 test 或 benchmark。
