# Proposal

## Why

serve 已具备每任务独占连接池及统一默认设置，但创建 API 只能覆盖协议，无法为不同任务选择连接数、流数和文件并发。此次实现已讨论并获用户明确要求实施的逐任务覆盖方案。

## What Changes

- `POST /api/v1/tasks` 增加可选整数 `connections`、`streams`、`transfers`；沿用已有 `transport`，按字段覆盖服务默认值。
- 严格区分未传与无效值；C/S 为 1..1024，F 为正整数。先确定协议，https 未传 streams 时使用 1，显式非 1 拒绝；无效配置在入队前按现有请求无效错误返回。
- 创建时固定生效配置，暂停再启动沿用该配置，建池时机和任务隔离保持不变。服务启动值只作为默认值，不充当覆盖值上限。
- 创建响应及上传、下载任务详情新增 `transport`、`connections`、`streams`，已有 `fileConcurrency` 返回生效的 transfers，不新增同义响应字段。
- 旧请求继续有效；严格检查响应未知字段的调用方需接纳三个新增字段。摘要、SSE、旧 WebSocket、CLI 默认值和 Qtserver 协议保持不变。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `qtransc-serve-api-contract`：创建参数覆盖、入队前校验及生效配置回显。
- `versioned-https-transports`：serve 按请求与默认值合并后的配置建池，以及 HTTP/1.1 的省略与显式 streams 语义。

## Impact

修改 serve 请求解码、handler、任务管理器、详情转换及必要 CLI/API 文档；不引入依赖，不改错误码注册表。只做编译和静态检查，不编写或运行测试及 benchmark。外部文档修改仍作为草稿交由人工审核。
