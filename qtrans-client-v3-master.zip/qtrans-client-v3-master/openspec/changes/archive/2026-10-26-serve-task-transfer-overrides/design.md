# Design

## Context

动机见 proposal.md。serve 使用严格的独立请求 DTO，TaskManager 保存服务默认值，任务构造函数接收 network 配置并延迟到 Execute 建池。现有详情转换与旧 WebSocket 共用内部视图，需要保持后者 JSON 不变。

## Goals / Non-Goals

- 目标：在入队前解析覆盖值并得到完整配置快照，任务执行与详情使用同一配置来源。
- 非目标：不改运行中参数，不引入全局请求限额或新的调度算法，不扩展 Qtserver 协议及 SSE。

## Decisions

1. 请求 DTO 使用带存在标记的可选整数，在自定义 JSON 解码时拒绝 null 与非整数。单纯 int 无法区分缺失和零，单纯 *int 会把 null 与缺失合并，因此不采用这两种直接解码方式。
2. 通过独立的内部覆盖值结构把可选 C/S/F 交给 TaskManager 合并，不往共享 TaskCreateRequest 的 JSON 增加字段。handler 先得到已校验的 TransferSettings，再完成现有请求校验与入队；原有 API 入口负责将错误映射为请求无效。
3. 先确定 transport，再逐字段覆盖 C/S/F；https 且 S 未提供时为 1，显式 S 仍交由既有严格规则校验。服务默认设置以值复制，任务持有自己的数值快照。TaskManager 构造任务时使用该快照，不再读取服务默认 C/S/F。
4. 详情从任务已保存的 transport、networkConfig 和 FileConcurrency 取值，不访问活动 client，因而 pending、停止和重启均可回显。内部详情新增字段使用 json:"-"，只在 serve DTO 映射中输出，避免改变旧 WebSocket 帧。
5. 对外保持 fileConcurrency，表示请求的 transfers；不增加重复的 transfers 响应字段。摘要和 SSE 维持现有结构。

## Risks / Trade-offs

- 新响应字段可能被严格 schema 调用方拒绝 → API 文档说明需要接纳 transport、connections、streams。
- 默认值不是上限，多个任务可请求不同容量 → 保留 C/S 的既有范围和任务数量限制，不扩大此次范围引入全局限额。
- 编译与静态审查不能证明实际网络行为 → 明确记录验证边界，不新增或运行测试。

## Migration Plan

先按已确认方案修订 OpenSpec，再实现。旧请求无需调整；升级调用方后可逐字段启用覆盖。回退时调用方需停止发送新增字段。必要 API/CLI 文档修改作为草稿交由人工审核。
