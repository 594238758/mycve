## MODIFIED Requirements

### Requirement: transport 参数严格校验

`connections` SHALL 对所有 transport 为 `1..1024` 范围内的整数。`https` 的 `streams` SHALL 等于 1；`https2` 和 `https3` 的 `streams` SHALL 为 `1..1024` 范围内的整数。只影响 QUIC 的参数 SHALL 仅适用于 `https3`。无效组合 SHALL 在连接池创建或网络访问之前失败，而 SHALL NOT 被静默修正。任何 `connections * streams` 派生计算 SHALL 在两个操作数分别通过范围校验之后执行，使每个 origin 的最大配置本地容量不超过 1,048,576 且计算不会发生整数溢出。

#### Scenario: https 配置多个 streams

- **WHEN** 调用者为 `https` 配置 `streams` 大于 1
- **THEN** qtransc SHALL 返回参数错误，而 SHALL NOT 把它静默压缩为 1

#### Scenario: 容量参数超出范围

- **WHEN** `connections` 小于 1 或大于 1024，或 `https2`、`https3` 的 `streams` 小于 1 或大于 1024
- **THEN** qtransc SHALL 在建连前返回参数错误

#### Scenario: 校验后计算总容量

- **WHEN** qtransc 需要根据 `connections` 与 `streams` 派生每个 origin 的本地总容量
- **THEN** qtransc SHALL 先分别完成范围校验再执行乘法，且有效输入得到的结果 SHALL NOT 大于 1,048,576

#### Scenario: QUIC 专属参数用于 TCP transport

- **WHEN** 调用者把 QUIC receive window 等 QUIC 专属参数用于 `https` 或 `https2`
- **THEN** qtransc SHALL 在建连前返回参数错误

#### Scenario: serve 按任务 transport 创建池

- **WHEN** qtransc serve 启动时校验并保存默认 transport、connections 和 streams，任务开始执行
- **THEN** 该轮任务 SHALL 按创建时合并并校验的任务配置创建独占池；`https` SHALL 使用每连接容量 1，`https2` 与 `https3` SHALL 使用请求覆盖值或继承的默认值

#### Scenario: HTTP1 任务未提供 streams

- **WHEN** serve 请求的最终 transport 为 https 且未提供 streams，即使服务默认 streams 大于 1
- **THEN** 任务 SHALL 使用 streams=1

#### Scenario: HTTP1 任务显式覆盖 streams

- **WHEN** serve 请求的最终 transport 为 https 且显式提供 streams
- **THEN** 只有整数 1 SHALL 被接受，其他值 SHALL 在创建任务前被拒绝
