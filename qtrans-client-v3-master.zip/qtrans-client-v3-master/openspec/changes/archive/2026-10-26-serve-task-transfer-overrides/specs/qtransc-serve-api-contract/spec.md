## MODIFIED Requirements

### Requirement: 并发改造保持任务接口兼容

未提供并发覆盖字段时，连接池容量和普通文件并发 SHALL 从 serve 启动配置取得。创建任务 SHALL 接受可选的 connections、streams、transfers，且 SHALL NOT 引入 P。任务详情 fileConcurrency SHALL 继续表示普通文件并发上限；HTTP 原有字段、SSE 字段、状态枚举及错误结构 SHALL 保持现有契约。旧请求 SHALL 不要求迁移，创建响应和详情 SHALL 追加生效配置字段。

#### Scenario: 调用方继续使用已有请求

- **WHEN** 调用方以现有合法请求创建任务并订阅 SSE
- **THEN** 请求 SHALL 继续被接受，响应 SHALL 保留既有字段并追加生效配置，事件 SHALL 保持既有结构
- **AND** 普通分片操作 SHALL 按任务共享额度并行执行

## ADDED Requirements

### Requirement: 创建任务按字段覆盖传输默认值

POST /api/v1/tasks SHALL 接受可选整数 connections、streams、transfers，分别表示每轮任务每个 origin 的连接上限、每连接请求上限及普通文件并发上限。每个缺失字段 SHALL 继承服务默认值；transport 缺失或 trim 后为空 SHALL 保留继承语义。显式合法值 SHALL 覆盖对应默认值而不影响其他字段。启动默认值 SHALL NOT 充当请求覆盖值的上限。最终配置 SHALL 在接受任务前固定，暂停再启动 SHALL 沿用此配置，同时重建独占池与分片额度。

#### Scenario: 全部使用默认值

- **WHEN** 请求未提供四项传输设置，且服务使用内置默认值
- **THEN** 任务 SHALL 使用 https3、connections=10、streams=1、transfers=5

#### Scenario: 部分覆盖

- **WHEN** 服务默认 https2、connections=3、streams=4、transfers=5，请求只提供 connections=8
- **THEN** 任务 SHALL 使用 https2、connections=8、streams=4、transfers=5
- **AND** 该覆盖 SHALL NOT 改变其他任务或服务默认值

#### Scenario: 暂停后重新启动

- **WHEN** 调用方暂停一个使用显式覆盖值的任务，随后启动同一任务
- **THEN** 任务 SHALL 继续使用创建时确定的配置且使用新的执行资源

### Requirement: 传输覆盖值在入队前严格校验

connections SHALL 是 1..1024 整数；https2/https3 的 streams SHALL 是 1..1024 整数；transfers SHALL 是 Go int 可表示的正整数。已传入的数字字段 SHALL 拒绝 null、字符串、布尔值、数组、对象、小数形式和溢出值；零与负数 SHALL NOT 被解释为缺省。无效值或协议与 streams 的冲突 SHALL 在入队、登记 taskId 或访问 Qtserver 前返回现有请求无效错误，HTTP 信封及错误码注册表 SHALL 保持不变。

#### Scenario: 数字字段显式无效

- **WHEN** 任一新增字段为 null、0、负数、字符串或小数，或 connections/streams 大于 1024
- **THEN** API SHALL 返回请求无效错误，不创建任务且不访问 Qtserver

#### Scenario: 拒绝后修正重试

- **WHEN** 调用方修正无效并发值并重新提交同一 taskId，且该 ID 未被其他请求使用
- **THEN** 请求 SHALL 不因前一次参数拒绝而返回任务已存在

### Requirement: 创建响应和详情回显生效配置

成功创建响应及上传、下载任务详情 SHALL 返回 transport、connections、streams，并用已有 fileConcurrency 返回生效的 transfers。返回值 SHALL 表示合并及校验后的任务配置上限，而非当前实际活跃连接、流或文件数。该信息 SHALL 在 pending 阶段可用，停止及完成后 SHALL 保留。响应 SHALL NOT 另增 transfers 同义字段，任务摘要和 SSE SHALL 不新增配置字段；旧 WebSocket JSON SHALL 保持不变。

#### Scenario: 查询排队任务

- **WHEN** 合法任务已接受但尚未开始执行
- **THEN** 创建响应及详情 SHALL 返回该任务完整生效配置，且 SHALL NOT 为获取这些字段提前建池

#### Scenario: 请求 HTTP1 且未提供 streams

- **WHEN** 服务默认 streams=8，任务选择 https 且省略 streams
- **THEN** 创建响应和后续详情 SHALL 返回 transport=https、streams=1

#### Scenario: 详情文件并发字段兼容

- **WHEN** 上传或下载请求提供 transfers=3
- **THEN** 创建响应及详情 SHALL 返回 fileConcurrency=3 并保留其他既有字段
