# Tasks

## 1. 创建请求与任务配置

- [x] 1.1 增加严格可选整数解码与请求白名单，入队前合并、校验并传递独立配置快照；静态审查缺失、null、零、越界、HTTP/1.1、任务隔离及重启路径，并更新 API 请求与 CLI 默认值说明。

## 2. 生效配置回显

- [x] 2.1 创建响应及上传、下载详情返回 transport、connections、streams 和既有 fileConcurrency；审查 pending、停止、重启后的配置来源及旧 WebSocket JSON 隔离，更新 API 响应说明。

## 3. 集成检查

- [x] 3.1 完成必要 Go 编译、gofmt、差异格式及 OpenSpec 严格校验，记录静态审查结果与未做运行验证的边界；不编写或运行测试、benchmark。

## 验证记录

- qtransc `make dev` 编译成功，已更新 `bin/qtransc-dev`；修改的 Go 文件通过 gofmt，`git diff --check` 与本 change 的 OpenSpec 严格校验通过。
- 静态审查：解码保留缺失标记并拒绝 null/非整数；C/S 复用既有范围校验；F 必须为正数；HTTP/1.1 仅在 S 缺失时默认 1。失败路径在任务登记和网络访问前返回请求无效。
- 静态审查：服务默认值以值复制，上传和下载使用传入的 C/S/F；旧轮结束后新轮从任务保存配置重建池和分片额度；详情读取配置而不依赖活动 client。新增内部详情字段使用 json:"-"，SSE 与旧 WebSocket 序列化路径未扩展。
- 未编写或运行测试、benchmark，也未验证实际 HTTP 调用或传输性能。API/CLI 文档修改仍需人工审核。
