## Why

本地全量测试暴露出多个核心稳定性缺陷：同一 principal 的并发上传会在 `complete` 的宽临界区产生持续锁竞争，大文件落盘压力可能放大 Redis 超时并使 Qtserver 退出，HTTP/2 已关闭连接不能在请求发送前重建，同时 CLI 和生成的 Nginx 配置未遵守既有错误与上传边界。需要在继续扩大传输规模前修复这些会导致任务不收敛、服务退出或自动化无法判断错误的路径。

## What Changes

- 缩短 canonical upload `complete` 持有 principal namespace lock 的时间，同时保留 session lock、原子发布、Redis committed 状态和正式 hash CAS 的既有一致性要求。
- 在 chunk 被标记为 verified 前同步缓存数据，并保留 `complete` 的最终 cache sync，避免把大规模脏数据刷新集中到 namespace lock 临界区。
- 区分调用方 context 结束与 Redis 依赖自身的 timeout；前者仅结束请求，后者和独立健康检查失败仍触发 fatal graceful shutdown。
- 允许 HTTP/2 lane 在请求尚未发送且既有 `ClientConn` 已关闭时重建物理连接，不重放结果不确定的请求。
- 让 qtransc 从参数解析、规划、任务执行到 CLI 输出持续保留 typed error；新增稳定本地错误码并统一退出码。
- 生成的 Qtserver Nginx proxy location 增加 `client_max_body_size 128m`，允许固定 100 MiB upload chunk。
- 补充覆盖锁生命周期、sync 顺序、Redis 故障分类、HTTP/2 重连、CLI 错误和真实大批量传输的测试与结果记录。

不改变上传 HTTP API、响应结构、chunk 大小、传输并发默认值、业务日志持久性等级或 principal namespace lock 的粒度；不处理 Darwin 编译、`config gendemo` 路径和 Redis 7 兼容性。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `resumable-upload`: 明确 verified 前的数据同步、`complete` 的 namespace lock 临界区和锁后事实重检要求。
- `service-capability-discovery`: 区分调用方 context 到期与 Redis 依赖 timeout，并规定生成网关配置的 upload body 上限。
- `client-transfer-concurrency`: 明确请求发送前发现已关闭 HTTP/2 连接时的安全重建行为。
- `client-error-contract`: 增加本地路径和任务大小错误码，并统一参数、规划、远端和中断退出码。

## Impact

- Qtserver canonical upload handler、Redis failure hook、Nginx 配置生成器及相应测试。
- qtransc HTTP/2 transport pool、直接 upload/download CLI 错误传播及相应测试。
- 外部兼容性：HTTP API 不变；CLI 新增 `LOCAL_FILE_NOT_FOUND`、`LOCAL_PATH_INVALID`、`TASK_SIZE_LIMIT_EXCEEDED`，原先泛化为 `CLIENT_ERROR` 的场景将返回更具体的 reason code；生成的 Nginx 配置新增 128 MiB body limit，无需迁移配置。
- 部署和验收需要 Redis、Nginx 以及 10,000 小文件和 10×10 GiB 数据集。
