## Context

变更动机见 [proposal.md](./proposal.md)。当前 canonical upload 的 `complete` 在取得 session lock 后过早取得 principal namespace lock，并在锁内完成 chunk 枚举、组合 hash、cache sync、Redis commit、业务日志同步和 HTTP 响应。慢磁盘与高并发会把一个文件的准备成本放大成同一 principal 下所有完成请求的锁竞争。

Qtserver 通过 Redis hook 和独立健康检查识别 fatal dependency failure。当前 hook 缺少调用方 context 信息，可能把请求 deadline 误判为 Redis dependency timeout。qtransc 的 HTTP/2 lane 则会永久保留已经关闭的 `ClientConn`，而 CLI 部分路径会把 typed error 降级为字符串。上述路径相互独立，但都影响传输任务能否在故障后收敛，因此在同一变更中按各自边界修复。

设计必须继续满足本 change 的 delta specs：上传原子发布和持久性不降低；客户端不新增 complete 串行器；已经可能发送的 HTTP 请求不由 transport 自动重放；错误码和退出码对自动化稳定。

## Goals / Non-Goals

**Goals:**

- 把 namespace lock 的持有时间收敛到真正修改 principal namespace 的步骤，同时让所有锁在业务日志与 HTTP 响应前释放。
- 将大部分 cache 脏数据在 chunk finalize 阶段持久化，使 complete 的最终 sync 通常只承担兜底确认。
- 用可验证的 context 归因规则区分请求取消与 Redis 依赖故障。
- 仅在请求发送前安全地修复 HTTP/2 陈旧连接，并让业务恢复层处理发送结果不确定的失败。
- typed error 在 CLI 全链路不丢失，且本地、远端与中断具有稳定退出码。

**Non-Goals:**

- 不改变 namespace lock 粒度，不引入路径级锁、complete singleflight、任务级 dispatcher 或新并发参数。
- 不修改上传状态模型、HTTP API、chunk 大小、并发默认值或业务日志持久性要求。
- 不由 transport 猜测请求是否幂等，也不自动重放已经进入 `RoundTrip` 的请求。
- 不在本变更处理 Darwin 编译、`config gendemo` 路径或 Redis 7 兼容。

## Decisions

### 1. 将 complete 分成锁前准备、namespace mutation 和锁后通知三段

`complete` 继续先取得 renewable session lock，以串行化同一 session 的 `complete`、`cancel` 和 `release`。在只持有 session lock 时重新加载 session，并处理 committed 幂等返回；随后执行 chunk 枚举与 verified 检查、组合文件 hash、cache policy、最终 `cache.Sync()` 和 cache fingerprint。这些工作不会改变 principal namespace，因此不取得 namespace lock。

准备完成后才取得 principal namespace lock。锁内必须重新解析并读取目标状态，不能复用锁前的目标检查结果。锁内只执行：验证 publish intent、创建 parents、准备正式 hash generation、再次确认两把 lock token、保存 publish intent、原子 publish、同步 parent directory、写入 committed session 状态，以及正式 hash 的 CAS/失效处理。

committed 状态保存完成后立即释放 namespace lock 和 session lock，再同步发送业务日志并生成 HTTP 响应。业务日志仍保持同步和现有失败语义，但其 I/O 不再扩大 namespace 临界区。客户端仍可并发 complete；`SESSION_BUSY` 和 `NAMESPACE_BUSY` 继续依据 `Retry-After` 做无上限的幂等重试，直到成功、取消或不可重试错误。

两把锁的 release 必须是幂等的。实现使用 `sync.Once` 或等价的一次性释放包装：函数入口注册 defer 作为异常路径兜底，成功提交后又可显式提前释放，避免 double release。

备选方案是客户端用 singleflight 或串行队列限制 complete。该方案只能隐藏服务端宽临界区，而且会让小文件完成吞吐再次受客户端并发限制，因此不采用。另一个备选是取消 principal lock 或改成路径锁；这会改变现有一致性契约和冲突范围，也不在本变更中采用。

### 2. verified 状态只在 cache 数据同步成功后写入

chunk finalize 在 hash 匹配后、写入 Redis verified 状态前，对缓存文件执行数据同步。同步失败返回可诊断的请求级错误，不发布目标、不写 verified；chunk 数据仍可由同一 session 的幂等 finalize 重试验证和同步。对已经是同一 hash 的 finalized chunk 保持现有幂等快路径，不重复同步。

complete 中的最终 `cache.Sync()` 继续保留以满足现有持久性规范并覆盖旧 session、边界写入和文件系统语义；正常路径的大量脏页已经在各 chunk finalize 时分散刷新。

备选方案是移除 complete sync，或在写 verified 之后异步 sync。前者降低持久性保证，后者可能让 verified 指向尚未稳定落盘的数据，均不采用。

### 3. 为 complete 阶段增加结构化耗时观测

记录至少包括：锁前 chunk/hash 准备、final cache sync、等待 namespace lock、namespace 内目标重检与 parent 准备、publish、Redis committed/hash CAS、锁后业务日志。正常请求用 debug 级别记录完整阶段数据；超过现有慢请求阈值时写 warning。字段只包含 session/request 标识和耗时，不记录 lock token、Redis key 内容、凭据或本地敏感路径。

选择阶段耗时而不是逐函数日志，是为了能直接区分磁盘 sync、锁等待、publish、Redis commit 和业务日志阻塞，同时避免高并发下日志量失控。

### 4. Redis fatal hook 使用调用方 context 做严格归因

Redis hook 的错误报告入口接收命令 context、有限的操作元数据和底层错误。当且仅当 `ctx.Err()` 非空，且返回错误可通过 `errors.Is(err, ctx.Err())` 归因到同一个 `context.Canceled` 或 `context.DeadlineExceeded` 时，hook 不上报 fatal；错误仍原样返回调用方并终止当前请求。

当调用方 context 仍有效时，连接、TLS、认证、协议、I/O timeout 和 AOF 类错误继续立即上报 fatal。pipeline 只报告安全的命令名称或数量，不包含参数、key、token 或凭据。独立五秒健康检查保持原逻辑：它使用自己的 deadline，`CheckFatalDependencies` 返回的失败仍由 monitor 直接上报，因此健康检查 timeout 是独立的 fatal dependency 证据，不会被 hook 的请求归因规则吞掉。

备选方案是统一忽略所有 `context.DeadlineExceeded`，但网络 timeout 可能被同一错误类型包装，会漏报真实 Redis 故障；因此采用 context 与错误链同时匹配的窄规则。

### 5. HTTP/2 lane 仅在发送前淘汰陈旧 ClientConn

`managedHTTP2Connection.ensureConnected` 在互斥区内检查现有 `ClientConn.Err()`。发现连接已关闭时，原子摘除该 `ClientConn`，清理对应连接状态并退出互斥区关闭旧连接，然后循环调用 `NewClientConn` 建立新物理连接。并发调用继续通过现有 connect coordination 共享同一次建连。

一旦进入 `RoundTrip`，任何连接错误都直接返回上层；lane 标记为不健康并从池中淘汰，但 transport 不自动重放。因为此时服务端是否已经接收或处理请求不可判定，只有具备 session/chunk 幂等语义的业务恢复层可以决定重试。

备选方案是对所有 HTTP/2 连接错误透明重放。它可能重复执行非幂等请求，因此不采用。

### 6. CLI 在错误产生点建立 typed error，并在边界用 errors.As 分类

新增 `LOCAL_FILE_NOT_FOUND`、`LOCAL_PATH_INVALID` 和 `TASK_SIZE_LIMIT_EXCEEDED` 常量与默认中文消息。本地文件打开/stat、路径规划和任务大小校验在具有语义上下文的产生点直接构造 typed error；不能全局把所有 `not found` 文本映射成本地文件不存在，因为远端对象不存在具有不同契约。

任务轮询和进度展示返回任务保存的 typed error，不通过格式化字符串重新构造。最终 JSON/文本渲染只做脱敏和展示，不改变 reason code。Cobra 的未知命令、未知 flag、缺失值和参数约束统一包装为 `CLI_INVALID_ARGUMENT`。

退出码解析通过 `errors.As` 穿透包装：成功为 0；远端、认证、网络和传输失败为 1；CLI 参数、配置、规划、本地路径和任务状态错误为 2；SIGINT 为 130。已有明确分类优先于兜底分类。

备选方案是在 CLI 最外层按错误字符串匹配。字符串受本地化和上下文包装影响，不足以形成稳定公共契约，因此只允许对尚未 typed 的遗留错误做最小兼容兜底。

### 7. Nginx body limit 在 canonical proxy location 中显式生成

Qtserver 生成的 canonical upload proxy location 固定加入 `client_max_body_size 128m`。该上限高于当前 100 MiB chunk，并保留协议和编码开销空间；不改变 Qtserver 自身的请求限制，也不扩大其他 location 的 body 上限。

选择 128 MiB 而不是无限制或 100 MiB，是为了允许当前协议最大 chunk，同时保留明确部署边界并避免单位与请求封装造成临界 413。

## Risks / Trade-offs

- [finalize 的 `File.Sync` 增加每个 chunk 的响应延迟和磁盘调用次数] → 将刷新成本从 complete 的全文件临界路径分散到 chunk 生命周期；保留阶段耗时并用 10×10 GiB 测试确认吞吐和服务存活。
- [锁前准备与取得 namespace lock 之间目标状态发生变化] → namespace lock 内强制重新解析和读取所有 namespace 敏感事实，锁前结果仅用于不改变命名空间的计算。
- [提前释放锁后业务日志失败，重试 complete 可能再次进入接口] → committed 状态已经持久化，重试走 committed 幂等路径；业务日志仍同步执行并保持既有一致性/去重机制。
- [release 的显式调用与 defer 兜底重复执行] → 用一次性释放包装保证幂等，并覆盖所有错误和取消测试路径。
- [Redis 错误包装使请求 deadline 与网络 timeout 难以区分] → 只在 `ctx.Err()` 与错误链精确匹配时忽略 hook fatal；独立健康检查继续提供第二条证据。
- [HTTP/2 连接可能在发送前检查后立刻关闭] → `RoundTrip` 错误不透明重放，交给业务恢复层按请求语义重试。
- [新增 typed error 改变部分脚本观察到的 reason code 和退出码] → HTTP/JSON 结构不变，新增稳定契约并补充 JSON、中文消息、脱敏和 exit code 回归测试。
- [128 MiB Nginx 上限未来可能小于新的 chunk 大小] → chunk 协议若改变，必须同步修改 OpenSpec 和配置生成器；本变更不把上限动态化。

## Migration Plan

1. 先部署 Qtserver：包含锁临界区、finalize sync、Redis hook 和阶段耗时；观察 complete 锁等待、sync 与 Redis 指标。
2. 重新生成并部署 Nginx 配置，执行配置校验后 reload；用完整 100 MiB chunk 验证不再返回 413。
3. 再发布 qtransc：启用 HTTP/2 发送前重连、typed error 和稳定退出码。
4. 按独立用例执行故障注入和规模回归；单项失败只记录，不阻断其余独立用例，结果追加到 `qtransc/docs/TEST_RESULTS.md`。

本变更没有 Redis schema 或上传 session 数据迁移。回滚时可分别回滚 qtransc 和 Qtserver 二进制；Nginx 配置通过旧生成器重新生成并校验后 reload。已经写入的 committed/verified 状态与旧版本兼容。若 Qtserver 回滚，必须确认没有正在执行的部署切换请求，但不需要清理已完成 session。
