## 1. 上传锁与持久化路径

- [x] 1.1 为 renewable session/namespace lock 实现幂等 release，使显式提前释放与 defer 兜底可以共存；用单元测试验证成功、错误、取消和重复 release 都只释放一次。
- [x] 1.2 重排 canonical upload `complete`：只持有 session lock 完成 chunk 状态检查、组合 hash、cache policy、最终 cache sync 和 fingerprint，之后才申请 namespace lock；用并发测试验证不同 session 可并行执行锁前准备。
- [x] 1.3 将 namespace lock 临界区限制为目标重检、parent 准备、hash generation、原子 publish、committed 状态和 hash CAS，并在 committed 后释放两把锁；用测试验证 namespace mutation 同时最多一个、锁后目标状态会重新读取、业务日志阻塞时锁已可被其他请求取得。
- [x] 1.4 审计 `complete` 的所有返回与取消路径并补充测试，验证 session lock 和 namespace lock 均不会泄漏，且 `SESSION_BUSY`/`NAMESPACE_BUSY` 的现有幂等重试契约不变。
- [x] 1.5 在 chunk finalize 的 hash 匹配后、Redis verified 写入前同步 cache 文件，并保留 complete 最终 sync；用可注入 sync 失败测试验证失败时不写 verified、不 publish，重试成功后才 verified，已 finalized 同 hash快路径不重复 sync。
- [x] 1.6 为 complete 增加锁前准备、cache sync、namespace lock 等待、目标/parent、publish、Redis commit/hash CAS 和业务日志的结构化阶段耗时；用日志测试验证慢阶段可定位且不泄露 lock token、Redis key、凭据和敏感路径。

## 2. Redis 故障归因

- [x] 2.1 让 Redis hook 同时接收命令 context、安全操作元数据和底层错误，并仅在 `ctx.Err()` 与错误链精确匹配时忽略请求级 canceled/deadline；用单元测试验证调用方取消和到期只终止当前请求且不触发 fatal shutdown。
- [x] 2.2 保留 Redis 连接、TLS、I/O timeout、认证、协议和 AOF 错误的 fatal 上报，并确保 pipeline 日志只含安全命令名或数量；用错误注入测试验证真实依赖错误触发 shutdown 且日志无参数、key 或凭据。
- [x] 2.3 保持五秒独立健康检查的 deadline 为 fatal dependency 证据；用 monitor 测试验证健康检查 timeout/断连导致非零退出，而普通调用方 deadline 后服务仍继续响应。

## 3. HTTP/2 连接恢复

- [x] 3.1 在 `managedHTTP2Connection.ensureConnected` 中原子摘除已关闭的 `ClientConn` 并协调重建，避免并发请求重复建连；运行现有 HTTP/2 stream-limit/reconnect 测试并验证服务端关闭空闲连接后的下一请求成功。
- [x] 3.2 保持 `RoundTrip` 后连接错误直接返回并淘汰 lane，不在 transport 层自动重放；补充结果不确定场景测试，验证服务端观察到的请求次数不会因 transport 重试而增加。

## 4. CLI typed error 与退出码

- [x] 4.1 在 client error 契约中新增 `LOCAL_FILE_NOT_FOUND`、`LOCAL_PATH_INVALID`、`TASK_SIZE_LIMIT_EXCEEDED` 及稳定中文默认消息；用表驱动测试验证文本和 JSON 输出的 reason code、消息与脱敏。
- [x] 4.2 在本地 stat/open、路径规划和任务大小校验的语义产生点构造 typed error，并将 Cobra 未知命令、未知 flag、缺失值和参数约束归类为 `CLI_INVALID_ARGUMENT`；逐项运行参数与本地文件错误测试验证不再降级为 `CLIENT_ERROR`。
- [x] 4.3 修复任务等待、进度展示和最终输出的错误传播，直接保留任务 typed error；用上传和下载失败测试验证实时进度开启或关闭时 reason code 均一致。
- [x] 4.4 将退出码解析改为 `errors.As` 并统一 0/1/2/130 契约；用包装错误、远端失败、本地规划失败、SIGINT 和成功用例验证退出码。

## 5. Nginx 生成配置

- [x] 5.1 在生成的 Qtserver canonical proxy location 中加入 `client_max_body_size 128m`，不影响其他 location；运行配置生成器测试并检查生成文本只有目标 location 具备该指令。
- [x] 5.2 使用生成配置执行 `nginx -t` 并上传完整 100 MiB chunk，验证请求不再返回 413且 Qtserver 仍执行自身的请求边界。

## 6. 构建与自动化回归

- [x] 6.1 运行受影响 Qtserver 包的锁、sync、Redis hook、monitor 和 Nginx 单元/集成测试；逐项保存命令、环境、结果和失败诊断，任何单项失败均继续其余独立用例。
- [x] 6.2 运行受影响 qtransc 包的 HTTP/2、clienterror、CLI 和进度错误传播测试；逐项保存命令、结果和失败诊断，任何单项失败均继续其余独立用例。
- [x] 6.3 运行 Qtserver 与 qtransc 的全量 Go 测试及构建检查，确认没有引入编译或既有契约回归；Darwin、`config gendemo` 和 Redis 7 已知非目标问题单独标注而不扩展本 change。

## 7. 真实环境规模与故障验收

- [x] 7.1 在本地部署 Qtserver、Redis 和生成的 Nginx 配置，记录版本、配置摘要和健康状态；验证 qtransc 的 mkdir/delete/move/list/upload/download 基础操作后再执行规模用例。
- [x] 7.2 上传 10,000 个小文件并逐文件校验内容，验证全部 complete 收敛、可恢复 409 不遗留永久 active handler、业务日志完整；记录吞吐、complete 重试数、锁等待和阶段耗时。
- [x] 7.4 分别注入调用方 deadline、Redis I/O timeout、断连和可控 AOF 故障，验证请求 deadline 不关闭服务、真实 Redis 故障使服务非零退出，并在服务恢复后由客户端续传完成。
- [x] 7.5 在 HTTP/2 下让服务端关闭空闲连接并验证下一请求重连；注入发送结果不确定错误并确认 transport 不自动重放，再执行 HTTP/3 基础回归确认未受改动影响。
- [x] 7.7 覆盖权限失败、远端/本地文件不存在、非法路径、重复目标、空间不足、网络中断、服务重启、取消和 SIGINT 等错误路径，逐项核对 reason code、中文消息、JSON、脱敏、退出码和资源清理。
- [x] 7.8 将本 change 的所有测试命令、数据集、结果、耗时、失败和复测结论继续追加到 `qtransc/docs/TEST_RESULTS.md`；保持每项独立记录并确认失败用例未阻断后续测试。
