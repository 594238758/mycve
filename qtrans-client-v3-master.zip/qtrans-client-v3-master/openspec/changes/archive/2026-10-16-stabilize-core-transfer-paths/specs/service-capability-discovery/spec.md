## MODIFIED Requirements

### Requirement: fatal dependency 故障触发 graceful shutdown

Qtserver SHALL 每五秒检查 Redis、Redis AOF persistence 和已启用 `oauth2-introspection` provider 的健康状态。健康检查或业务命令发现 dependency 自身的 connection refused、连接断开、TLS、I/O timeout、认证、AOF 状态、HTTP status 或协议错误时，服务 SHALL 在第一次故障时立即开始 shutdown，SHALL NOT 等待连续多次失败或重试阈值。调用方主动取消或调用方 context deadline 到期所产生的 `context.Canceled` 或 `context.DeadlineExceeded` SHALL 只结束当前请求，不得仅凭该错误触发 fatal shutdown；独立健康检查在自身 deadline 内未完成仍 SHALL 作为 dependency timeout 触发 shutdown。

服务 SHALL 停止接受新连接，给予现有请求最多 30 秒完成，然后以非零状态退出。直接观察到 introspection provider 故障且仍可响应的认证请求 SHALL 返回 HTTP 503 `DEPENDENCY_UNAVAILABLE`；其他尚可响应且未完成的业务请求 SHALL 返回 HTTP 500 `INTERNAL_ERROR`，而不是降级结果。

#### Scenario: 运行期 Redis 断开

- **WHEN** Redis 健康检查或业务命令检测到连接级故障
- **THEN** Qtserver SHALL 触发 graceful shutdown
- **AND** SHALL NOT 等待 Redis 恢复后继续服务

#### Scenario: 业务请求 deadline 到期

- **WHEN** Redis命令因调用该命令的业务请求context已到期而返回 `context.DeadlineExceeded`
- **THEN** 当前请求 SHALL 结束
- **AND** Qtserver SHALL NOT 仅凭该错误触发 graceful shutdown

#### Scenario: 独立 Redis 健康检查超时

- **WHEN** Redis未能在周期健康检查自身的deadline内完成检查
- **THEN** Qtserver SHALL 将其判定为dependency timeout并触发 graceful shutdown

#### Scenario: 运行期 Redis AOF 故障

- **WHEN** Redis persistence 健康检查或写命令检测到 AOF 已禁用或写入失败
- **THEN** Qtserver SHALL 触发同一 graceful shutdown 流程

#### Scenario: 正常 signal 停止

- **WHEN** Qtserver 收到 SIGINT 或 SIGTERM 且没有 fatal dependency
- **THEN** graceful shutdown 完成后的进程退出码 SHALL 为 0

#### Scenario: 运行期 introspection provider 故障

- **WHEN** 周期 probe 或业务 introspection 检测到 provider 故障
- **THEN** Qtserver SHALL 触发同一 graceful shutdown 流程
- **AND** SHALL NOT 等待第二次健康检查确认
- **AND** SHALL NOT 等待 provider 恢复后继续服务

### Requirement: 仅 Redis 依赖故障终止共享状态服务

Redis 连接、TLS、dependency I/O timeout、认证、协议、AOF 配置或 AOF 写入状态故障 SHALL 按 fatal dependency 处理。调用方context结束、锁冲突、CAS miss、key不存在和查询无结果 SHALL NOT 被判定为依赖故障。既有 `auth` mode 的身份服务超时或拒绝、任意 provider 返回无效 token、单个 principal 目录错误、单次文件 I/O、磁盘满和客户端错误 SHALL 是请求级错误且 SHALL NOT 终止 Qtserver。只有启用 `oauth2-introspection` 时，该 provider 的连接、TLS、timeout、内置 client authentication、HTTP status 或协议故障 SHALL 按 fatal dependency 处理。

#### Scenario: 上传磁盘空间不足

- **WHEN** 单次 PATCH 因磁盘空间不足失败
- **THEN** 请求 SHALL 返回 507
- **AND** Qtserver SHALL 继续处理其他请求

#### Scenario: namespace lock 冲突

- **WHEN** 请求未获取同 principal namespace lock
- **THEN** 请求 SHALL 返回 409 `NAMESPACE_BUSY`
- **AND** Qtserver SHALL NOT 退出

#### Scenario: Redis底层I/O超时

- **WHEN** 调用方context仍有效但Redis连接的读写发生I/O timeout
- **THEN** Qtserver SHALL 触发fatal graceful shutdown

#### Scenario: introspection 返回 inactive

- **WHEN** `oauth2-introspection` 返回结构合法的 `active=false`
- **THEN** 当前请求 SHALL 作为无效 token 失败
- **AND** Qtserver SHALL NOT 因本变更退出

#### Scenario: 既有 auth 服务超时

- **WHEN** `identity.mode="auth"` 的既有 `/userinfo` 请求超时
- **THEN** 请求 SHALL 按既有行为失败
- **AND** Qtserver SHALL NOT 因本变更退出

## ADDED Requirements

### Requirement: 生成的 Nginx 配置允许固定上传 chunk

Qtserver生成的canonical API proxy location SHALL 配置 `client_max_body_size 128m`，使固定104857600字节的upload chunk可以通过网关。该配置 SHALL 不改变Qtserver自身的请求body校验、单文件上限或其他location的body限制。

#### Scenario: 通过生成配置上传完整 chunk

- **WHEN** Nginx使用Qtserver生成的配置代理一个Content-Length为104857600的合法PATCH
- **THEN** Nginx SHALL NOT因body size返回413
- **AND** 请求 SHALL 到达Qtserver并由canonical upload规则处理
