## MODIFIED Requirements

### Requirement: finalize 独立验证完整 chunk

finalize body SHALL 只接受 lowercase 32-hex `chunk_hash`。malformed hash SHALL 返回 400 `INVALID_CHUNK_HASH`；未完整 SHALL 返回 409；服务 SHALL 读取该 chunk 区间计算 `xxh3_128`。匹配后服务 SHALL 在把状态保存为 verified 前同步 cache 数据；同步失败 SHALL 返回请求级错误且不得保存 verified 状态。mismatch SHALL 返回 409、重置当前 chunk为 partial/stored 0并返回 offset header。相同 verified hash重试 SHALL 200成功且不重读或重复同步 chunk，不同 hash SHALL 409。

#### Scenario: chunk hash 匹配

- **WHEN** chunk已 complete、提交 hash匹配且 cache 数据同步成功
- **THEN** finalize SHALL 返回 200并保存 verified hash

#### Scenario: chunk cache 同步失败

- **WHEN** chunk hash匹配但 cache 数据同步失败
- **THEN** finalize SHALL 返回请求级错误
- **AND** 该 chunk SHALL NOT 被保存为 verified
- **AND** Qtserver SHALL 保持运行

#### Scenario: chunk hash 不匹配

- **WHEN** 服务计算值与提交值不同
- **THEN** finalize SHALL 返回 409 hash mismatch
- **AND** 该 chunk SHALL 回到 partial/stored 0

#### Scenario: verified finalize 幂等重试

- **WHEN** 客户端以相同 hash再次 finalize
- **THEN** 服务 SHALL 返回 200且不重读或重复同步 chunk

### Requirement: terminal 操作共享 renewable session lock

complete、cancel和release SHALL 获取同一 session operation lock；complete还 SHALL 获取principal namespace lock。两个lock lease均为30秒、每10秒续租。complete SHALL 在持有 session operation lock 时完成 chunk、hash、cache policy、cache fingerprint 与最终 cache sync 检查，但 SHALL 只在这些检查成功后获取 principal namespace lock。namespace lock SHALL 只覆盖锁后重新读取 namespace 敏感事实、创建parents、准备正式hash generation、原子publish、保存committed状态和正式hash CAS；committed状态保存及正式hash处理完成后 SHALL 在同步业务日志和发送HTTP响应前释放两把lock。

冲突 SHALL 分别返回409 `SESSION_BUSY`或`NAMESPACE_BUSY`并带`Retry-After: 1`。qtransc 对 active session 的 canonical `complete` 收到这两种冲突时 SHALL 保留 session 并持续幂等重试，直到其 task context 被取消；不得因固定 30 秒窗口报告失败。每次等待 SHALL 遵守合法的 `Retry-After`，并在其缺失或无效时使用既有退避规则。该重试 SHALL 不重新 init、PATCH、finalize 或发送已完成的文件内容。

#### Scenario: cancel与complete并发

- **WHEN** complete持有session operation lock
- **THEN** cancel SHALL 返回409 `SESSION_BUSY`
- **AND** SHALL NOT 删除session/cache

#### Scenario: 不持有 namespace lock 执行慢速预检查

- **WHEN** complete正在组合hash、检查cache或执行最终cache sync
- **THEN** 其他session的complete、mkdir或create SHALL NOT 因本次complete持有principal namespace lock而收到 `NAMESPACE_BUSY`

#### Scenario: namespace被其他mutation占用

- **WHEN** complete完成锁前检查但无法取得principal namespace lock
- **THEN** SHALL 返回409 `NAMESPACE_BUSY`

#### Scenario: 锁后重新检查目标事实

- **WHEN** complete在锁前检查后等待并最终取得principal namespace lock
- **THEN** 服务 SHALL 在publish前重新读取target和其他namespace敏感事实
- **AND** SHALL NOT仅依据锁前结果发布

#### Scenario: committed后业务日志同步缓慢

- **WHEN** complete已经保存committed状态并完成正式hash处理，随后业务日志同步发生延迟
- **THEN** 其他session SHALL NOT 因本次日志同步继续占用session或namespace lock
- **AND** 本次响应仍 SHALL 遵守既有业务日志持久性要求

#### Scenario: qtransc持续等待complete锁冲突

- **WHEN** qtransc 的 active upload session 在 canonical complete 时持续收到 `SESSION_BUSY` 或 `NAMESPACE_BUSY` 超过30秒
- **THEN** qtransc SHALL 保持该上传任务运行并继续重试complete
- **AND** SHALL NOT重新发送已完成的文件内容或创建新session

#### Scenario: 等待complete锁时取消任务

- **WHEN** qtransc 正在为 canonical complete 的 busy 冲突退避等待且任务 context 被取消
- **THEN** 它 SHALL 及时停止等待
- **AND** SHALL 保留现有active session与本地恢复状态供后续任务继续
