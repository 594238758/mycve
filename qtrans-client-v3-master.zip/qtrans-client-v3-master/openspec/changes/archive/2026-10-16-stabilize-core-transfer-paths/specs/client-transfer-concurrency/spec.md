## MODIFIED Requirements

### Requirement: 最终网络错误释放容量并返回业务恢复

底层 transport 已完成其协议内安全处理后仍返回的网络错误 SHALL 结束当前请求尝试并释放对应 lane 名额。网络层 SHALL NOT 盲目重放无法证明未被处理的请求，也 SHALL NOT 要求业务层申请、持有或替换物理连接；业务层重新调度可恢复操作时 SHALL 重新获取网络容量，并 MAY 被分配到其他 lane。第一版 SHALL NOT 因单个 lane 的历史失败建立额外的持久熔断、健康探测或自适应并发状态。

对于HTTP/2，lane在发送请求前确认既有物理连接已经关闭或不可接受新request stream时，SHALL 淘汰该连接并在同一lane按需建立替代连接；因为请求尚未发送，该动作 SHALL NOT 计为重放。若连接错误与请求发送发生竞态且transport无法证明请求未发送，SHALL 按结果可能已产生处理，不得在网络层自动重放。

#### Scenario: 一条 lane 建连失败而其他 lane 可用

- **WHEN** 客户端配置的 lane 数大于服务端当前可接受的连接数，且一次请求最终收到建连或传输错误
- **THEN** qtransc SHALL 释放失败请求占用的本地容量并把结果交给业务恢复策略
- **AND** 其他可工作的 lane SHALL 能继续传输
- **AND** 可恢复操作的下一次尝试 SHALL NOT 被固定到原失败物理连接

#### Scenario: HTTP2请求发送前发现连接已关闭

- **WHEN** HTTP/2 lane持有的既有连接已经关闭，且下一个请求尚未发送
- **THEN** qtransc SHALL 在该lane建立替代连接并发送该请求
- **AND** SHALL NOT仅因旧连接关闭使任务失败

#### Scenario: 请求结果可能已经产生副作用

- **WHEN** transport无法证明一个带请求体的操作尚未被服务端处理
- **THEN** 网络层 SHALL 返回该结果而不盲目重放请求
- **AND** 业务层 SHALL 按该操作的幂等或断点恢复契约决定后续动作
