## MODIFIED Requirements

### Requirement: CLI 使用稳定原因码和中文可读错误

qtransc 的直接命令在非 JSON 模式发生可报告错误时 SHALL 在 stderr 使用 `Error [REASON_CODE]: 中文说明` 格式。`REASON_CODE` SHALL 是稳定的大写下划线标识符；来自 qtserver 结构化错误的 `reason_code` SHALL 原样传递。客户端自身产生的错误 SHALL 使用稳定客户端原因码，至少包括 `CLI_INVALID_ARGUMENT`、`AUTH_CONFIG_INVALID`、`AUTH_LOGIN_REJECTED`、`AUTH_LOGIN_FAILED`、`AUTH_REFRESH_FAILED`、`ANONYMOUS_READ_UNAVAILABLE`、`ANONYMOUS_WRITE_UNAVAILABLE`、`CAPABILITY_UNAVAILABLE`、`SERVER_UNAVAILABLE`、`RECURSIVE_DELETE_PARTIAL`、`MUTATION_RESULT_UNKNOWN`、`FILE_TOO_LARGE`、`TASK_FILE_LIMIT_EXCEEDED`、`LOCAL_FILE_NOT_FOUND`、`LOCAL_PATH_INVALID` 和 `TASK_SIZE_LIMIT_EXCEEDED`。

参数解析、规划、任务执行、进度展示和最终CLI输出 SHALL 保留typed error及其reason code，不得在中间层只保存或重新构造错误字符串。`--debug` SHALL 保留额外的底层诊断信息，但所有模式均 SHALL NOT 输出用户名、密码、access token、refresh token、OAuth client secret 或 Authorization header。用户名密码认证被拒绝时 SHALL 使用 `AUTH_LOGIN_REJECTED`，不得声称是用户名或密码中某一项错误。

#### Scenario: 路径不存在

- **WHEN** 直接 CLI 命令收到 qtserver 的 `NOT_FOUND`
- **THEN** stderr SHALL 输出 `Error [NOT_FOUND]:` 开头的中文说明

#### Scenario: 本地上传源不存在

- **WHEN** qtransc在规划时发现指定的本地上传源不存在
- **THEN** 它 SHALL 使用 `LOCAL_FILE_NOT_FOUND` 和中文说明报告错误

#### Scenario: 本地目标路径无效

- **WHEN** qtransc在规划时发现下载目标路径无效或无法作为本地目标使用
- **THEN** 它 SHALL 使用 `LOCAL_PATH_INVALID` 和中文说明报告错误

#### Scenario: limit-size超过任务总量

- **WHEN** 上传任务总量超过用户明确配置的 `--limit-size`
- **THEN** qtransc SHALL 在远端写入前使用 `TASK_SIZE_LIMIT_EXCEEDED` 报告错误

#### Scenario: 本地发现单文件超限

- **WHEN** qtransc 在传输规划中发现文件大小超过有效单文件上限
- **THEN** 它 SHALL 使用 `FILE_TOO_LARGE` 和中文说明报告错误

#### Scenario: 本地发现任务文件数超限

- **WHEN** qtransc 在传输规划中发现去重普通文件数超过 100000
- **THEN** 它 SHALL 使用 `TASK_FILE_LIMIT_EXCEEDED` 和中文说明报告错误

#### Scenario: 非法服务器端口

- **WHEN** 用户以 `--server aaa.cn:port` 执行直接 CLI 命令
- **THEN** stderr SHALL 输出 `Error [CLI_INVALID_ARGUMENT]: --server 参数不合法`

#### Scenario: 非法服务器地址格式

- **WHEN** 用户的 `--server` 值包含协议、路径或其他不符合 `host[:port]` 的内容
- **THEN** stderr SHALL 输出 `Error [CLI_INVALID_ARGUMENT]: --server 参数不合法`

#### Scenario: 用户名密码认证被拒绝

- **WHEN** qtransc 的用户名密码登录被认证服务拒绝
- **THEN** stderr SHALL 输出 `Error [AUTH_LOGIN_REJECTED]:` 开头的中文说明
- **AND** SHALL NOT 指出用户名或密码中哪一项错误

#### Scenario: 调试模式的敏感信息保护

- **WHEN** 用户以 `--debug` 执行命令且认证请求失败
- **THEN** qtransc SHALL 提供额外诊断
- **AND** SHALL NOT 输出任何认证凭据或令牌值

## ADDED Requirements

### Requirement: CLI 退出码按错误来源稳定分类

qtransc直接命令 SHALL 对成功使用退出码0，对远端、认证、网络和传输失败使用退出码1，对CLI参数、本地配置、规划、本地路径和state DB错误使用退出码2，对SIGINT使用退出码130。未知命令、未知flag、无效transport及无效connections、streams或transfers SHALL 作为 `CLI_INVALID_ARGUMENT` 并退出2。

#### Scenario: 未知命令

- **WHEN** 用户调用已移除或从未注册的命令
- **THEN** qtransc SHALL 输出 `CLI_INVALID_ARGUMENT`
- **AND** 进程 SHALL 退出2

#### Scenario: 无效传输并发参数

- **WHEN** connections、streams或transfers不满足所选transport的约束
- **THEN** qtransc SHALL 输出 `CLI_INVALID_ARGUMENT`
- **AND** 进程 SHALL 退出2

#### Scenario: 远端NOT_FOUND

- **WHEN** 已通过本地规划的命令收到qtserver `NOT_FOUND`
- **THEN** qtransc SHALL 保留 `NOT_FOUND`
- **AND** 进程 SHALL 退出1

#### Scenario: 用户中断活动任务

- **WHEN** 活动传输收到SIGINT
- **THEN** qtransc SHALL 停止当前执行并保留适用的恢复状态
- **AND** 进程 SHALL 退出130
