## Why

部分部署使用的 NFS 文件系统不支持 `renameat2(RENAME_NOREPLACE)`，导致 `POST /files/move` 对所有有效移动固定返回 500 `ATOMIC_NOREPLACE_UNSUPPORTED`。在现有 namespace lock 已协调 Qtserver 实例内写入的前提下，需要允许用户明确接受较弱的外部并发保护，以恢复这些文件系统上的移动能力。

## What Changes

- `POST /files/move` 仍优先使用原子 no-replace rename。
- 仅当平台或文件系统明确报告不支持该 primitive 时，Qtserver 先检查 destination 不存在，再使用普通原子 rename 完成移动。
- 兼容降级继续对检查时已存在的 destination 返回 409，并继续依赖 namespace lock 协调所有 Qtserver 实例内的写入。
- 放宽兼容降级路径的并发保证：不受 namespace lock 约束的外部 writer 若在检查与 rename 之间创建 destination，该节点可能被普通 rename 覆盖。
- 支持原子 no-replace rename 的文件系统继续维持现有强保证；跨文件系统移动及其他错误的响应保持不变。

## Non-Goals

- 不使用 `link + unlink` 模拟移动，不引入 source 与 destination 同时可见或崩溃后留下双路径的中间状态。
- 不为外部直接写共享存储的程序引入分布式锁或 fencing。
- 不改变 endpoint、请求体、成功响应或 qtransc 调用方式。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `file-management`: 放宽 move 在原子 no-replace rename 不受支持时的失败要求，定义检查 destination 后使用普通 rename 的兼容降级及其并发保证边界。

## Impact

- 影响 `qtserver/internal/filespace` 的 no-replace rename 错误分类及 `qtserver/internal/handlers` 的 move 流程。
- API 兼容性：原先在不支持 `RENAME_NOREPLACE` 的文件系统上返回 500 的请求可能改为 200 或 409；支持该 primitive 的部署无行为变化。
- 数据安全边界：只有兼容降级路径无法保证抵御外部并发 writer，运维侧需确保正式用户文件空间只由 Qtserver 写入，或接受极窄竞态窗口内覆盖外部新建 destination 的风险。
- 不新增配置、数据库 migration 或第三方依赖；升级部署后自动生效。
