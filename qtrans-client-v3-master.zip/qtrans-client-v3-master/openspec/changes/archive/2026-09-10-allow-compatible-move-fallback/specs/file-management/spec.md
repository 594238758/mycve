## MODIFIED Requirements

### Requirement: move 使用精确destination和原子no-replace rename

move SHALL 将source移动到exact destination，SHALL NOT把destination解释为目录容器，也 SHALL NOT自动创建destination parent。parent缺失或source缺失 SHALL 返回404。source==destination、检查时destination已存在任意节点 SHALL 返回409。目录移入自身后代 SHALL 返回409 `INVALID_MOVE`。final source symlink SHALL 移动链接本身；特殊source SHALL 返回422。move SHALL 优先使用`renameat2(RENAME_NOREPLACE)`或等价原子primitive；不支持时 SHALL 在namespace lock内重新检查destination不存在，再使用普通原子rename完成移动，SHALL NOT使用link后unlink或复制后删除。兼容降级路径对不受namespace lock约束的并发writer SHALL NOT提供严格no-overwrite保证。

#### Scenario: target不存在

- **WHEN** source存在、destination parent存在且destination不存在
- **THEN** move SHALL 原子rename并返回200

#### Scenario: destination是已有目录

- **WHEN** destination节点在move检查时已经存在
- **THEN** move SHALL 返回409且不得把source放入该目录

#### Scenario: 跨文件系统

- **WHEN** rename返回EXDEV
- **THEN** move SHALL 返回500 `CROSS_DEVICE_MOVE`
- **AND** SHALL NOT复制后删除source

#### Scenario: 文件系统不支持原子no-replace

- **WHEN** 平台不能为move提供等价的atomic no-replace rename
- **AND** 兼容降级重新检查时destination不存在且namespace lock仍有效
- **THEN** move SHALL 使用普通原子rename并返回200
- **AND** source与destination SHALL NOT经历由服务执行的link后unlink双路径状态

#### Scenario: 兼容降级重新检查时target已存在

- **WHEN** atomic no-replace rename不受支持
- **AND** 兼容降级重新检查时destination已存在任意节点
- **THEN** move SHALL 返回409
- **AND** source与destination SHALL 保持未修改

#### Scenario: 兼容降级遇到外部并发writer

- **WHEN** 不受namespace lock约束的writer在兼容降级的最终检查之后、普通rename之前创建destination
- **THEN** move的no-overwrite保证 SHALL NOT覆盖该竞态
- **AND** 普通rename SHALL 按底层文件系统语义成功覆盖destination或返回错误

#### Scenario: move成功后hash

- **WHEN** source被rename到destination
- **THEN** source和destination旧hash generation SHALL 失效
- **AND** destination SHALL 在首次需要时重新计算
