## Context

Qtserver 当前先检查 destination，再调用 `RenameNoReplace` 完成 move；Linux 实现将 `renameat2(RENAME_NOREPLACE)` 返回的 `ENOSYS`、`EINVAL` 或 `EOPNOTSUPP` 转换为 `ATOMIC_NOREPLACE_UNSUPPORTED`。部分 NFS 部署对该 flag 返回 `EINVAL`，因此即使 source 与 destination 位于同一文件系统，move 也无法成功。

move 支持普通文件、目录和 final symlink，且要求 namespace 从 source 到 destination 以一次 rename 切换。上传 publish 使用的 hard-link方案只适用于不可见 regular cache，不能直接复用于通用 move。现有 principal namespace lock 能协调正常运行的 Qtserver 实例，但规范已声明其不是严格 fencing，也不能约束直接写共享存储的外部程序。

## Goals / Non-Goals

**Goals:**

- 在原子 no-replace rename 不受支持时，通过普通 rename 恢复文件、目录和 symlink 的 move 能力。
- 保持一次 rename 的 namespace 切换，不产生服务主动创建的双路径中间状态。
- 将较弱的 no-overwrite 边界限制在兼容降级路径，并尽量缩小检查与 rename 之间的竞态窗口。
- 保持支持 `RENAME_NOREPLACE` 的部署、create 和 upload publish 的现有语义。

**Non-Goals:**

- 不保证兼容降级能够防止外部 writer 或 namespace lock fencing 缺口造成的目标覆盖。
- 不使用 hard link、复制后删除、事务日志或两阶段提交实现通用 move。
- 不增加运行时配置开关；是否降级只由 strict primitive 返回的明确“不支持”错误决定。

## Decisions

### 1. strict primitive失败后在move handler中执行专用降级

`RenameNoReplace` 的跨平台契约保持不变，仍返回带 reason 的 `ATOMIC_NOREPLACE_UNSUPPORTED`。`FileMoveHandler` 只对这一 reason 执行兼容降级：

1. 使用 `Lstat` 重新检查 exact destination，使 dangling symlink 等任意已有节点都构成冲突。
2. destination存在时返回409；除not-exist之外的检查错误返回500且不执行rename。
3. 在不可逆操作前再次验证 namespace lock；失效时返回409 `NAMESPACE_LOCK_LOST`。
4. 调用普通 `os.Rename(sourcePath, destinationPath)`。

降级放在 move handler而不是 `RenameNoReplace` 内部，可以避免 create 等其他调用方无意继承较弱语义，也让 namespace lock验证和HTTP错误映射保持在现有控制层。

### 2. 只对明确unsupported错误降级

仅 `ENOSYS`、`EINVAL`、`EOPNOTSUPP` 经现有 typed error映射得到的 `ATOMIC_NOREPLACE_UNSUPPORTED` 触发降级。`EXDEV` 继续返回500 `CROSS_DEVICE_MOVE`；`EEXIST` 继续返回409；permission、I/O及其他未知错误不得改用普通rename重试，以免把真实故障误判为能力不足。

普通rename本身返回 `EXDEV` 时同样映射为 `CROSS_DEVICE_MOVE`。若外部竞态使普通rename返回已存在类错误，则返回409；其他错误沿用通用 move failure。

### 3. 保留原子移动，显式放宽外部并发no-overwrite

普通rename仍以单个文件系统操作移除source名称并发布destination名称，因而比 `link + unlink` 更符合通用 move 的可观察语义，也支持目录与final symlink。

最终 `Lstat` 与普通rename之间仍存在TOCTOU窗口。持有 namespace lock 时，正常Qtserver mutation不会进入该窗口；但外部writer以及锁失效后的未fenced实例不受约束。底层rename允许时，它们在窗口内创建的destination可能被覆盖。这是本变更接受的明确取舍，不通过额外一次检查声称消除。

### 4. 成功点与后处理保持不变

strict或compatible rename成功后均进入现有成功路径：fsync source与destination parent、使两侧hash generation失效并返回200。普通rename成功后发生的fsync或hash依赖故障不得尝试把namespace移回source。

## Risks / Trade-offs

- [外部writer在TOCTOU窗口创建destination] → 节点可能被覆盖；部署应将用户文件空间的写入收敛到Qtserver，无法做到时需接受该风险。
- [namespace lock不是严格fencing] → 极端lease失效竞态仍可能造成覆盖；在普通rename前再次验证token只能缩小窗口，不能提供数学上的排他保证。
- [将真实 `EINVAL` 误判为能力不支持] → 沿用现有错误分类；路径和请求约束在调用前已校验，降级只发生于该已知分类。
- [不同文件类型的rename覆盖规则不同] → destination的常规已存在情况由最终 `Lstat` 返回409；最终检查后的外部竞态按底层文件系统语义处理，不承诺统一结果。

## Migration Plan

1. 部署新版Qtserver，不需要配置、数据库或Redis迁移。
2. 在不支持 `RENAME_NOREPLACE` 的目标NFS上分别验证普通文件、目录和symlink移动能够完成，并确认预先存在的destination仍返回409。
3. 继续要求运维避免Qtserver之外的程序直接写正式用户文件空间；若必须允许外部writer，应视兼容move为best-effort no-overwrite。
4. 回滚到旧版本不会改变已完成移动的数据，但该NFS上的后续move将重新返回500 `ATOMIC_NOREPLACE_UNSUPPORTED`。
