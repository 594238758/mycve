## 1. 实现move兼容降级

- [x] 1.1 在 `FileMoveHandler` 中只捕获 `ATOMIC_NOREPLACE_UNSUPPORTED`，重新 `Lstat` exact destination并在继续前再次验证namespace lock。
- [x] 1.2 destination仍不存在时执行普通 `os.Rename`，将已存在类错误映射为409、`EXDEV`映射为`CROSS_DEVICE_MOVE`，其他错误保持move失败语义。
- [x] 1.3 确认strict rename成功路径、create no-overwrite及upload publish不继承兼容降级，成功后的fsync和hash失效流程保持不变。

## 2. 格式化与编译检查

- [x] 2.1 对修改的Go源文件运行gofmt。
- [x] 2.2 编译qtserver全部包，确认变更通过编译且不新增依赖。
