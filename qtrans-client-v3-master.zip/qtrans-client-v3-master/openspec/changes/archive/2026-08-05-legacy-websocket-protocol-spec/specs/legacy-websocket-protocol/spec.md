## Purpose

定义 qtrans-client-web 主进程与 qtransc upload2/download2 子进程之间的本地 WebSocket 兼容协议：参与者、连接生命周期、消息信封、状态码、进度对象、关闭语义和兼容性约束。本协议是旧 GUI 外部契约，不是 `qtransc serve` 的实时控制通道。

## ADDED Requirements

### Requirement: 协议定位与参与者

本协议 SHALL 只用于 qtrans-client-web 主进程（WebSocket Server）与 qtransc `upload2`/`download2` 子进程（WebSocket Client）之间的本地兼容交互。qtransc 子进程 SHALL 作为客户端主动连接主进程提供的 WebSocket 地址。`qtransc serve` 模式 SHALL NOT 注册该 WebSocket 通道，其实时接口继续由 REST 与 SSE 承担。

#### Scenario: 子进程主动回连

- **WHEN** `upload2` 或 `download2` 收到非空的 `--wss-url`
- **THEN** qtransc SHALL 主动 Dial 该地址
- **AND** 主进程 SHALL 处于 WebSocket Server 角色

#### Scenario: serve 模式不提供兼容通道

- **WHEN** 调用方连接 `qtransc serve` 并期望旧 WebSocket 协议
- **THEN** 服务 SHALL NOT 提供该协议
- **AND** 调用方 SHALL 使用 REST 或 SSE 接口

### Requirement: 启用条件与注册帧

`upload2`/`download2` 只有在同时提供 `--taskid` 与 `--wss-url` 时 SHALL 启用 WebSocket；缺少 `--wss-url` 时 SHALL 不建立连接并直接启动传输。`--taskid` 缺省时 qtransc SHALL 自动生成任务 ID（`upload2` 使用 `compat-ul-<UnixNano>`，`download2` 使用 `compat-dl-<UnixNano>`）。连接建立成功后，qtransc SHALL 立即发送注册帧：

```json
{"taskid":"<task-id>","code":1000}
```

注册帧 SHALL 是连接上第一个出站帧，SHALL NOT 携带 `data`。

#### Scenario: 未提供 wss-url

- **WHEN** 调用方只提供 `--taskid` 而未提供 `--wss-url`
- **THEN** qtransc SHALL 不进行 WebSocket 交互
- **AND** 传输 SHALL 直接开始

#### Scenario: 注册帧

- **WHEN** 子进程完成 Dial
- **THEN** 子进程 SHALL 发送 `{"taskid":"<task-id>","code":1000}`
- **AND** 该帧 SHALL NOT 包含 `data`

#### Scenario: Dial 失败

- **WHEN** 子进程无法连接 `--wss-url`
- **THEN** 命令 SHALL 在启动传输前失败
- **AND** 进程 SHALL 以非零状态退出

### Requirement: 主进程服务端行为与轮询时序

当前 qtrans-client-web 主进程 SHALL 在 `127.0.0.1:31313` 启动 WebSocket Server，并在收到注册帧后 SHALL 立即发送第一次 `query-progress`。收到 `code=1001` 后 SHALL 在 300ms 后再次查询；收到 `code=1002` 后 SHALL 在 1000ms 后再次查询。收到 `code=1003` 后 SHALL 以 code 1000、reason `Server disconnect when received complete message` 关闭连接。应用退出时 SHALL 以 code 1001、reason `Server disconnect when server shutdown` 关闭全部连接。对无法解析或未知 code 的客户端消息，主进程 SHALL 回复 `{"type":400,"message":"<原因>"}` 错误帧。

#### Scenario: 注册后立即查询

- **WHEN** 主进程收到注册帧
- **THEN** 主进程 SHALL 立即发送 `{"taskId":"<task-id>","type":"query-progress"}`
- **AND** 无需等待额外间隔

#### Scenario: 开始中与传输中的轮询间隔

- **WHEN** 子进程回复 `code=1001`
- **THEN** 主进程 SHALL 在 300ms 后再次查询
- **AND** 子进程回复 `code=1002` 后，主进程 SHALL 在 1000ms 后再次查询

#### Scenario: 完成后的关闭

- **WHEN** 主进程收到 `code=1003`
- **THEN** 主进程 SHALL 以 code 1000 关闭连接
- **AND** close reason SHALL 为 `Server disconnect when received complete message`

### Requirement: taskid 是不透明字符串

`taskid` SHALL 被视为不透明字符串：qtransc SHALL NOT 解析其格式、路径语义或长度，也 SHALL NOT 将其作为业务对象键使用。当前 qtrans-client-web 生成 `upload-<本地路径>-<时间戳>` 或 `download-<本地路径>-<时间戳>` 形式；历史协议文档曾直接使用 object key 作为 taskid。协议 SHALL 不承诺任何 taskid 格式。

#### Scenario: taskid 包含本地路径

- **WHEN** 主进程传入 `upload-C:\Users\demo\file.zip-1720000000000` 作为 taskid
- **THEN** qtransc SHALL 原样使用该字符串进行注册与响应
- **AND** SHALL NOT 解析其中路径

### Requirement: 主进程请求信封

主进程发送的请求 SHALL 是 JSON text frame，包含 `type` 和任务 ID；任务 ID 字段 SHALL 接受 `taskid` 与 `taskId` 两种拼写，同时出现时 `taskid` SHALL 优先。`message` 字段为可选。当前受支持的 `type` SHALL 仅为 `query-progress` 与 `update-token`；未知 `type` 或无法解码的 JSON SHALL 使 qtransc 停止传输并以非零状态退出。

#### Scenario: 驼峰 taskId 查询

- **WHEN** 主进程发送 `{"taskId":"legacy-task-1","type":"query-progress"}`
- **THEN** qtransc SHALL 接受该请求
- **AND** SHALL 按该任务 ID 回复状态

#### Scenario: 未知 type

- **WHEN** 主进程发送 `{"taskid":"legacy-task-1","type":"unknown-command"}`
- **THEN** qtransc SHALL 停止当前传输
- **AND** 进程 SHALL 以非零状态退出

### Requirement: query-progress 请求

`query-progress` SHALL 返回当前任务状态快照。请求不需要 `message`。qtransc SHALL 对每次 `query-progress` 同步回复一个状态包；状态包 `code` SHALL 按任务状态映射，`data` SHALL 按 `code` 为进度对象或状态描述字符串。

#### Scenario: 任务尚未开始

- **WHEN** 任务处于 `pending` 且收到 `query-progress`
- **THEN** qtransc SHALL 回复 `code=1001`、`data` 为中文字符串 `任务开始中`

#### Scenario: 任务运行中

- **WHEN** 任务处于 `running` 且收到 `query-progress`
- **THEN** qtransc SHALL 回复 `code=1002` 和进度对象
- **AND** 进度对象 `status` SHALL 为 `0`

#### Scenario: 任务已完成

- **WHEN** 任务处于 `completed` 且收到 `query-progress`
- **THEN** qtransc SHALL 回复 `code=1003` 和进度对象
- **AND** 进度对象 `status` SHALL 为 `1`

### Requirement: 响应信封与状态码集合

qtransc 的所有响应 SHALL 使用统一信封 `{"taskid":"<task-id>","code":<int>,"data":<any>}`；`taskid` SHALL 与请求任务一致，`data` 在无内容时 SHALL 省略。状态码 SHALL 固定为：

| code | 含义 | `data` 形态 |
| --- | --- | --- |
| `1000` | 注册成功 / 正常连通 | 无 |
| `1001` | 任务开始中 | 中文字符串 |
| `1002` | 任务运行中 | 进度对象 |
| `1003` | 任务已完成 | 进度对象 |
| `1010` | `update-token` 成功 | `{"message":"token updated"}` |
| `2000` | 未知错误 | 中文字符串 `未知错误` 或进度对象 |
| `2001` | 鉴权失败 / token 失效 | 中文字符串 `认证失败` |
| `2002` | 磁盘空间不足 | 中文字符串 `磁盘空间不足` |
| `2010` | `update-token` 参数非法 | `{"message":"bearer_token is required"}` |
| `2011` | `update-token` 执行失败 | `{"message":"token update failed: <原因>"}` |

#### Scenario: 注册响应无 data

- **WHEN** qtransc 发送注册帧
- **THEN** 帧 SHALL 为 `{"taskid":"<task-id>","code":1000}`
- **AND** SHALL NOT 包含 `data` 字段

#### Scenario: 鉴权失败

- **WHEN** 任务失败且错误被识别为鉴权错误
- **THEN** qtransc SHALL 回复 `code=2001`
- **AND** `data` SHALL 为字符串 `认证失败`

### Requirement: 进度对象字段

`1002`、`1003` 与未知状态下的进度对象 SHALL 使用固定字段：

```json
{
  "status": 0,
  "progress_percent": 42.5,
  "transferred": 4250,
  "total": 10000,
  "rate": "12.34 KB/s",
  "inprogressfiles": [
    {
      "file": "/abs/path/file1.txt",
      "progress_percent": 42.5,
      "transferred": 4250,
      "total": 10000,
      "rate": "12.34 KB/s"
    }
  ]
}
```

`status` SHALL 为 `-1`（失败或未知）、`0`（传输中）或 `1`（已完成）。`transferred`/`total` SHALL 为字节整数；`rate` SHALL 为 `xx.xx KB/s` 格式字符串。`inprogressfiles` SHALL 只包含尚未完成且正在传输的文件条目；已上传/已校验完成或进度为 100% 的文件 SHALL NOT 出现。`file` SHALL 为本地绝对路径。

#### Scenario: 运行中进度快照

- **WHEN** 任务运行中收到 `query-progress`
- **THEN** 响应 `data.status` SHALL 为 `0`
- **AND** `inprogressfiles` SHALL 包含活动文件，排除已完成文件

#### Scenario: 完成进度快照

- **WHEN** 任务完成后收到 `query-progress`
- **THEN** 响应 `data.status` SHALL 为 `1`
- **AND** `inprogressfiles` SHALL 为空或仅包含未完成条目

### Requirement: 任务状态到状态码映射

`upload2` 与 `download2` SHALL 按以下规则映射任务状态：`pending`→1001；`running`→1002；`completed`→1003。`failed` 或带错误的 `stopped` SHALL 映射为：鉴权错误→2001；download2 的磁盘空间不足错误→2002；其余→2000。无错误的 `stopped` SHALL 按 `completed` 语义回复 1003 且进度 `status=1`。未知任务状态 SHALL 回复 2000 且进度 `status=-1`。

#### Scenario: 下载磁盘空间不足

- **WHEN** download2 任务失败且错误为磁盘空间不足
- **THEN** qtransc SHALL 回复 `code=2002`
- **AND** `data` SHALL 为字符串 `磁盘空间不足`

#### Scenario: 停止但无错误

- **WHEN** 任务状态为 `stopped` 且无错误
- **THEN** qtransc SHALL 回复 `code=1003`
- **AND** 进度对象 `status` SHALL 为 `1`

### Requirement: update-token 请求

`update-token` 请求 SHALL 携带 `message`，其中 `message.bearer_token` 为新 static token。`bearer_token` 缺失或为空时 SHALL 回复 2010；authmanager 设置失败（包括模式锁定）时 SHALL 回复 2011；成功时 SHALL 回复 1010。`update-token` SHALL NOT 中断正在运行的传输。

#### Scenario: 成功更新 token

- **WHEN** 主进程发送 `{"taskid":"<task-id>","type":"update-token","message":{"bearer_token":"new-token"}}`
- **THEN** qtransc SHALL 更新进程内 static token
- **AND** SHALL 回复 `{"taskid":"<task-id>","code":1010,"data":{"message":"token updated"}}`

#### Scenario: token 参数非法

- **WHEN** `message.bearer_token` 缺失或为空
- **THEN** qtransc SHALL 回复 `code=2010`
- **AND** 后续请求 SHALL 继续使用原 token

#### Scenario: authmanager 模式锁定

- **WHEN** authmanager 已锁定为 `userandpass` 且收到 `update-token`
- **THEN** qtransc SHALL 回复 `code=2011`
- **AND** 传输 SHALL NOT 中断

### Requirement: 首次 query-progress 作为传输启动门控

`upload2`/`download2` SHALL NOT 启动文件传输，直到处理完第一次 `query-progress` 请求。仅收到 `update-token` 或连接空闲 SHALL NOT 释放该门控。若连接在第一次 `query-progress` 前正常关闭（code 1000/1001），qtransc SHALL 不使用 WebSocket 上报并直接启动传输；若连接错误，命令 SHALL 在启动传输前失败。

#### Scenario: 只发 update-token 不查询

- **WHEN** 主进程只发送 `update-token` 且从未发送 `query-progress`
- **THEN** qtransc SHALL 回复 token 结果
- **AND** SHALL NOT 开始文件传输

#### Scenario: 首次查询前正常关闭

- **WHEN** 连接建立、注册完成后主进程以 code 1000/1001 关闭连接且未发送 `query-progress`
- **THEN** qtransc SHALL 直接启动传输
- **AND** 传输结果 SHALL 决定退出码

### Requirement: 关闭与暂停语义

连接关闭 SHALL 按以下规则处理：

- code 1000（`CloseNormalClosure`）或 1001（`CloseGoingAway`）：SHALL 视为协调方结束会话，传输 SHALL 继续，进程 SHALL 在传输结束后退出。
- code 1002（`CloseProtocolError`）且 reason 文本包含 `delete or pause`（大小写不敏感）：SHALL 视为协调方暂停或删除任务，qtransc SHALL 停止当前传输（upload2 优雅停止，download2 取消上下文）并以正常路径结束。当前 qtrans-client-web 使用的 reason 为 `Server disconnect when event(delete or pause) happend`，尾随空白 SHALL 被忽略。
- 其他关闭或读取错误：SHALL 停止传输并以非零状态退出。

#### Scenario: 暂停或删除

- **WHEN** 主进程以 code 1002 和 reason `Server disconnect when event(delete or pause) happend` 关闭连接
- **THEN** qtransc SHALL 识别为暂停/删除
- **AND** SHALL 停止传输

#### Scenario: 正常关闭不取消传输

- **WHEN** 主进程在传输中以 code 1000 关闭连接
- **THEN** qtransc SHALL 继续传输
- **AND** 不再提供 WebSocket 状态上报

#### Scenario: 应用退出关闭

- **WHEN** 主进程以 code 1001 和 reason `Server disconnect when server shutdown` 关闭连接
- **THEN** qtransc SHALL 按正常关闭处理
- **AND** 是否终止传输由主进程对子进程的进程管理决定

### Requirement: 终态确认窗口

传输结束后，`upload2`/`download2` SHALL 最多等待 2 秒，以便协调方查询并收到终态响应（1003 或错误码）；超时后 SHALL 关闭连接。进程退出码 SHALL 由传输结果决定，WebSocket 上报失败 SHALL NOT 覆盖传输成功结果，传输失败 SHALL NOT 因 WebSocket 正常关闭而被掩盖。

#### Scenario: 主进程不再查询

- **WHEN** 传输完成但协调方在 2 秒内未再发送 `query-progress`
- **THEN** 进程 SHALL 在窗口结束后关闭连接
- **AND** 退出码 SHALL 仍反映传输结果

#### Scenario: 传输失败且 WebSocket 正常关闭

- **WHEN** 传输失败且连接以 code 1000 关闭
- **THEN** 进程 SHALL 以传输失败对应的非零状态退出

### Requirement: 兼容命令输入契约

`upload2` SHALL 通过 `--jf` 读取 JSON 数组，元素为 `{"local_abs_path":"<绝对路径>","remote_rel_path":"<远端逻辑路径>"}`；`download2` SHALL 通过 `--jf` 读取 JSON 数组，元素为 `{"local_rel_path":"<本地相对路径>","remote_url":"<远端 URL 或 object key>"}`。download2 的 `remote_url` SHALL 接受绝对下载 URL、以 `/qtserver/v1/d/down/` 开头的根相对路径或纯 object key。upload2 SHALL 拒绝匿名写 token `00000000-0000-4000-8000-000000000000`。upload2 与 download2 的传输 SHALL 固定使用 QUIC；download2 对显式指定其他 `--transport` SHALL 忽略并告警。

upload2/download2 支持的启动参数 SHALL 限定为：`--taskid`/`-t`、`--wss-url`、`--jf`/`-j`、download2 的 `--destination`/`-d`，以及全局 `--server`、认证参数、并发参数、`--debug`/`--log-path` 等现有全局参数。upload2/download2 SHALL NOT 接受已移除的旧版启动参数：`-upload`、`-download`、`--upload-url`、`--download-url`、`--bearer`、`--simple`、`--O`、`--disk-free-percent`、`--server-taskid`、`--js`、`--conns`、`--streams-per-conn`、`--max-transfer-files`、`--threads`、`--requests-per-conn`、`--retries`、`--retry-delay`、`--transinfo`、`--verify-url`、`--log-level`、`--insecure`、`--enable-0rtt`、`--buffer-size`。调用方 SHALL 使用全局 `--server` 指定服务端、`--auth-token` 或认证参数提供凭据。当前 qtrans-client-web 仍以旧参数启动子进程，属于已知集成缺口，qtransc 在收到这些参数时 SHALL 按 CLI 解析错误失败。

#### Scenario: download2 三种 remote_url

- **WHEN** `remote_url` 分别为绝对 URL、`/qtserver/v1/d/down/...` 和 `gsa/CRA025038/file.gz`
- **THEN** qtransc SHALL 从三种形式提取同一逻辑 object key

#### Scenario: upload2 匿名写 token

- **WHEN** `--auth-token` 为固定匿名写 token
- **THEN** upload2 SHALL 拒绝启动

#### Scenario: 旧版启动参数

- **WHEN** 调用方以 `--upload-url`、`--bearer`、`--simple` 等旧参数启动 upload2 或 download2
- **THEN** 命令 SHALL 以 CLI 参数错误失败
- **AND** SHALL NOT 静默忽略或猜测参数含义

### Requirement: 兼容性与协议变更边界

本协议 SHALL 保持对旧 GUI 的兼容：入站请求 SHALL 接受 `taskId`/`taskid` 双拼写；出站响应 SHALL 固定使用 `taskid`；SHALL NOT 新增 request id 或要求 ack；暂停/删除 SHALL 继续通过 close reason 文本表达。任何改变协议字段、状态码、关闭语义或新增请求类型的变更 SHALL 先修改本 spec 并经 OpenSpec 审批。

#### Scenario: 旧客户端只发 query-progress

- **WHEN** 旧客户端只发送 `query-progress`
- **THEN** 传输与上报 SHALL 与当前行为一致
- **AND** 不要求旧客户端理解 `update-token`

#### Scenario: 协议字段统一

- **WHEN** 未来试图将出站 `taskid` 改为 `taskId`
- **THEN** 该变更 SHALL 先更新本 spec
- **AND** 在旧客户端完成适配前 SHALL NOT 合入
