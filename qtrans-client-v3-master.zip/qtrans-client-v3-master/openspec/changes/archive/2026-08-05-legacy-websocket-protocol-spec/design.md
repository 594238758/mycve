## Context

本 change 是纯文档基线。所有需求都来自当前代码的可观察行为，而不是设想中的“更规范”的协议。权威代码位置：

- `qtransc/cmd/qtransc/cmd_upload2.go`：`upload2CompatReporter`
- `qtransc/cmd/qtransc/cmd_download2.go`：`download2CompatReporter`
- `qtransc/cmd/qtransc/legacy_compat.go`：消息结构、状态码、`update-token` 处理
- ~~`qtransc/docs/websocket_compat_analysis.md`~~：原有梳理文档，已被本 change 取代并移除（git 历史保留）
- ~~`qtransc/docs/legacy_qtrans_client_upload_interface.md`~~：旧接口整理文档，已移除；其中的 CLI 参数对照表已并入本 spec 的“兼容命令输入契约”，任务 JSON 与 WebSocket 摘要内容由本 change 覆盖（git 历史保留）

## Decisions

### 1. 协议定位：本地兼容轮询协议，不是 serve 实时通道

该 WebSocket 只服务 qtrans-client-web 主进程与 `upload2`/`download2` 子进程。连接方向是子进程主动回连主进程，主进程按 300ms/1000ms 轮询 `query-progress`，子进程按需回复状态快照。`qtransc serve` 模式的实时接口是 REST + SSE，不提供该 WebSocket 路由。

### 2. 启用条件与 taskid 缺省值

代码中 `usesWebSocket()` 要求 `taskid` 与 `wss-url` 同时非空；而 `upload2`/`download2` 在进入 reporter 前会为空的 `--taskid` 生成 `compat-ul-<UnixNano>` / `compat-dl-<UnixNano>`，因此实际生效条件是 `--wss-url` 非空。规格按可观察行为描述：两个参数都提供时启用；缺省 taskid 由客户端自动生成。

### 3. 消息模型：单请求/单响应，无 request id

子进程连接后只主动发送一次注册帧；此后所有子进程出站帧都是对主进程请求的同步响应。没有 request id 或 ack 机制，任务绑定完全依赖 `taskid` 字段。入站接受 `taskId`/`taskid` 两种拼写（`taskid` 优先），出站固定 `taskid`，这是对旧 Electron 客户端的兼容约束，不是缺陷。

### 4. 状态码映射

`pending`→1001、`running`→1002、`completed`→1003。错误映射在 upload2 与 download2 略有差异：download2 额外识别 `ErrTargetDirNoSpace`→2002；两者都识别鉴权错误→2001，其余错误→2000。`stopped` 无错误时按完成（1003）上报，有错误时按错误码上报。`update-token` 使用独立码段 1010/2010/2011，与传输状态码段互不重叠。

### 5. 暂停/删除通过 close frame reason 表达

主进程暂停或删除任务时使用 close code 1002（`CloseProtocolError`）和固定 reason 文本 `Server disconnect when event(delete or pause) happend`。子进程按“code=1002 且 reason 包含 `delete or pause`（大小写不敏感）”识别为用户动作并停止传输。该机制脆弱但属于当前兼容契约，固化为 spec 而非继续放任模糊；未来若要正式化，必须走 OpenSpec 审批。

### 6. 首次 query-progress 是传输启动门控

当前实现中，`upload2`/`download2` 在收到第一次 `query-progress` 并返回 1001 前不会启动文件传输；主进程只发 `update-token` 不会释放该门控。若连接在首次查询前正常关闭，子进程仍会直接启动传输（此时无 WebSocket 上报）；若连接错误，则命令失败且不启动传输。这是隐含的时序约束，规格将其显式化，避免未来重构时无意改变。

### 7. 终态 best-effort 确认窗口

传输结束后，进程最多等待 2 秒让主进程查询并收到终态响应（1003 或错误码），然后关闭连接。该窗口是 best-effort：主进程不再查询时，进程按传输结果决定退出码。

### 8. update-token 只支持 static token 热更新

`update-token` 调用进程内 authmanager 设置 static token，后续请求立即使用新 token。若 authmanager 已锁定为 `userandpass` 模式，设置失败并返回 2011；协议不承担用户名密码配置下发。

### 9. 主进程侧行为已用 qtrans-client-web 源码核对

本 change 已对照 `/home/xiang/workspace/82026/qtrans-client-web` 源码核实主进程侧行为：

- `src/renderer/src/utils/Constants.js`：WebSocket Server 固定 `127.0.0.1:31313`；`taskId` 生成格式为 `upload-<本地路径>-<时间戳>` / `download-<本地路径>-<时间戳>`。
- `src/main/wss.js`：注册帧后立即查询；1001 后 300ms、1002 后 1000ms 轮询；1003 后以 code 1000 关闭；暂停/删除以 code 1002 + `delete or pause` reason 关闭；应用退出以 code 1001 关闭；`update-token` 已实现并由主进程在 token 刷新/登录后向活动授权任务广播。
- `src/main/index.js`：上传与受控下载通过 `upload2`/`download2` 启动子进程，公开下载走另一旧二进制（`qtransc.exe`），不属于本协议范围。
- `docs/wss通信协议.txt`：历史文档，字段与当前实现存在出入（如 `action`、`type`、`taskId` 语义、端口 31314），不作为权威依据。

### 10. 当前 GUI 启动参数与 v3 CLI 存在已知缺口

WebSocket 消息协议与任务 JSON 结构与 v3 实现兼容，但 qtrans-client-web 的 `startProcess` 仍向 `upload2`/`download2` 传递旧版参数：`--upload-url`/`--download-url`、`--bearer`、`--simple`、`--O`、`--conns`、`--streams-per-conn`、`--max-transfer-files`、`--threads`。v3 的 upload2/download2 不接受这些参数，也没有兼容别名。该缺口已与 GUI 负责同事确认，对方正在适配 v3 启动参数；适配完成前，当前 GUI 不能直接驱动 v3 的上传与受控下载。本 change 不参与修复。

## Risks / Trade-offs

- close reason 文本承载业务动作，主进程改动文案或大小写会破坏暂停/删除识别；当前靠兼容性测试与文档约束。
- 首次 query-progress 门控使传输开始依赖主进程轮询；若主进程只连接不查询，子进程会一直等待。
- 主进程注册后立即查询，正常联调下门控不会造成实际延迟，但该时序仍是隐含约束。
- 无 request id，无法区分迟到的响应与当前响应；单连接串行处理规避了大部分问题。
- 轮询模型有 300ms/1000ms 延迟，不是状态变化即推送。
- 协议字段存在 `taskId`/`taskid` 双拼写，任何“统一命名”的改动都会破坏旧客户端，必须先经 OpenSpec 审批并协调前端。
- 与 serve 模式的 REST + SSE 长期并存，属于有意的兼容边界。
- 当前 GUI 启动参数与 v3 CLI 不兼容，GUI 迁移到 serve 或适配 v3 参数前，upload2/download2 兼容链路无法被当前 GUI 直接驱动。

## Verification

- 逐条对照 `cmd_upload2.go`、`cmd_download2.go`、`legacy_compat.go` 与 spec，确认规格描述与当前行为一致。
- 对照 `qtrans-client-web/src/main/wss.js`、`src/main/index.js`、`src/renderer/src/utils/Constants.js` 与 `docs/wss通信协议.txt`，确认主进程侧描述一致。
- 执行 `go build ./...`（qtransc 与 qtserver），确认文档变更未破坏构建。
- 不运行测试、不编写测试。
