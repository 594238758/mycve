## 1. 规格定稿

- [x] 1.1 对照 `cmd_upload2.go`、`cmd_download2.go`、`legacy_compat.go` 以及 `qtrans-client-web/src/main/wss.js`、`src/main/index.js`、`src/renderer/src/utils/Constants.js` 逐条核对 `specs/legacy-websocket-protocol/spec.md`，确认启用条件、消息信封、状态码、进度对象、启动门控、轮询时序、关闭语义与终态窗口描述一致；发现偏差时修订 spec 并在 commit message 中说明依据
- [x] 1.2 核对 `design.md` 中的决策与风险是否覆盖所有可观察行为；补充遗漏的决策，不引入未经批准的协议扩展

## 2. 文档同步

- [x] 2.1 移除 `qtransc/docs/websocket_compat_analysis.md`，将权威契约收敛到本 change，并更新 `authmanager_upgrade_plan.md` 中的引用
- [x] 2.2 移除 `qtransc/docs/legacy_qtrans_client_upload_interface.md`，将 CLI 参数对照表并入 spec 的“兼容命令输入契约”，任务 JSON 与 WebSocket 内容由本 change 覆盖

## 3. 构建验证

- [x] 3.1 在 `qtransc/` 与 `qtserver/` 分别执行 `go build ./...`，确认文档变更未破坏构建
- [x] 3.2 不编写测试、不运行测试；仅做只读核对
