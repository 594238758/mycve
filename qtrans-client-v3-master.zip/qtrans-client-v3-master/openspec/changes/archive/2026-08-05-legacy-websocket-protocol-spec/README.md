# legacy-websocket-protocol-spec

固化 qtrans-client-web 主进程与 qtransc upload2/download2 子进程之间的本地 WebSocket 兼容协议。
