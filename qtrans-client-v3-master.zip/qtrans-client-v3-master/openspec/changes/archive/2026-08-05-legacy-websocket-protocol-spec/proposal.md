## Why

旧 GUI 与 qtransc 之间的 WebSocket 兼容协议目前只存在于散落的代码、一份分析文档和旧版接口说明片段中，没有一个可被审核、回归和变更控制的单一权威契约。`unify-user-file-space` change 承诺“upload2/download2 外部协议保持不变”，但由于外部协议没有正式基线，这个承诺无法被验证，后续任何字段、状态码或连接语义的调整也没有审批依据。

本 change 把当前实现固化为一组可观察行为规格，不改动任何代码或运行时行为，为协议演进建立 OpenSpec 基线。

## What Changes

- 新增 capability `legacy-websocket-protocol`，定义 qtrans-client-web 主进程（WebSocket Server）与 qtransc upload2/download2 子进程（WebSocket Client）之间的本地兼容轮询协议。
- 固化连接启用条件、连接方向、注册帧、请求与响应信封、状态码、进度对象、任务状态映射、关闭语义和终态确认窗口。
- 固化 `upload2` / `download2` 与本协议相关的 CLI 参数和任务 JSON 输入契约。
- 主进程侧行为已对照 `qtrans-client-web` 源码核实：监听地址与端口、注册后立即查询与 300ms/1000ms 轮询、完成与暂停/删除/退出的 close 语义、`update-token` 调用时机、taskid 生成格式。
- 明确本协议不是 `qtransc serve` 的实时控制通道；serve 模式的实时接口继续由 REST + SSE 承担。
- 纯文档变更：不修改 Go 代码、不改变任何外部可观察行为、不引入协议扩展。

## Capabilities

### New Capabilities

- `legacy-websocket-protocol`: 定义旧 GUI 兼容 WebSocket 的参与者、连接生命周期、消息格式、状态码、进度对象、关闭语义和兼容性约束。

### Modified Capabilities

当前 `openspec/specs/` 为空，没有需要修改的既有 capability。

## Impact

- 影响 qtransc 的 `upload2`、`download2` 兼容命令的文档与协议基线，不改变其行为。
- 影响 qtrans-client-web 主进程的 WebSocket Server 消费语义（仅作为文档基线，不涉及本仓库代码）。
- 已确认的集成缺口：qtrans-client-web 当前仍以旧 CLI 参数（`--upload-url`/`--download-url`/`--bearer`/`--simple`/`--O`/并发参数）启动 upload2/download2，v3 不接受这些参数；WebSocket 消息协议与任务 JSON 本身兼容。该缺口已与 GUI 负责同事确认，对方正在适配，本 change 不参与修复。
- 为后续任何协议修改（新增命令、统一字段、正式化 pause/delete 消息）提供审批边界：必须先修改本 change 或新开 change。
- `qtransc/docs/websocket_compat_analysis.md` 与 `legacy_qtrans_client_upload_interface.md` 均已移除（git 历史保留），权威契约仅存于本 change；两份文档中的 CLI 参数对照、任务 JSON 与 WebSocket 摘要内容已吸收进 spec/design。

## Non-Goals

- 不扩展协议：不新增请求类型、request id、ack、暂停/恢复/删除正式消息。
- 不把 WebSocket 扩展为 `qtransc serve` 的统一实时接口；新 UI 继续优先走 REST + SSE。
- 不修改 `upload2` / `download2` 的命令行参数、任务 JSON 结构或退出码语义。
- 不实现旧 CLI 参数兼容层，也不修改 qtrans-client-web 的启动参数；GUI 与 v3 的参数缺口由后续独立决策解决。
- 不编写测试或 benchmark，不运行测试；只做代码对照核对和编译验证。
