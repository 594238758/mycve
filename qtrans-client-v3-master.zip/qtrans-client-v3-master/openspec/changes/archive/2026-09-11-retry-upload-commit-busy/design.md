## Context

现有 `qtserverapi.DoJSONWithHeadersAndCorrelation` 将 `SESSION_BUSY` 与 `NAMESPACE_BUSY` 作为可重试的幂等冲突，但以 30 秒 `semanticRetryWindow` 截止。`UploadFileInfo.completeUploadSession` 通过该通用入口调用 canonical `/complete`；窗口耗尽后，文件上传协程返回错误，任务汇总失败。服务端的 complete 与 GET session 具有既有幂等契约，成功后本地 SQLite row 才清理。

见 `proposal.md` 的动机与范围，以及本变更的 `resumable-upload`、`file-management` delta specs。

## Goals / Non-Goals

**Goals:**

- 仅使 active upload session 的 canonical `/complete` 能持续等待 `SESSION_BUSY` 与 `NAMESPACE_BUSY`。
- 复用现有 `Retry-After`、指数退避、jitter、context 取消和 session 恢复机制。
- 保持文件内容、分片和本地 SQLite state；busy 等待期间不重复发送 payload。

**Non-Goals:**

- 不调整 qtserver 的锁实现、lease、路由或响应格式。
- 不改变 init、PATCH、finalize、mkdir、move、delete 或 download 的重试期限。
- 不新增 CLI 配置项、总超时、后台 daemon 或跨进程提交协调。

## Decisions

### 为幂等请求增加窄化的 persistent busy 重试模式

在 `qtserverapi` 的现有 retry mode 中加入仅用于 canonical complete 的模式。它仍要求调用方选择幂等操作，并继续保留 HTTP `500` 的三次预算和其他既有错误分类；唯一变化是 `SESSION_BUSY` / `NAMESPACE_BUSY` 不检查 30 秒 semantic 窗口。

`completeUploadSession` 显式使用该模式。其他当前使用 `IdempotentRetry` 的调用保持原行为，避免把目录创建、session init 或不相关请求变成不可预期的无限等待。

替代方案是全局移除 semantic 窗口。该做法会扩大所有调用点的阻塞语义，与本次只解决 upload complete 锁冲突的批准范围不符，因此不采用。

### 以服务端 complete 幂等性保证安全

重复 complete 对已经 committed 的 session 返回固定成功结果；active session 的 successful complete 是唯一发布点。因此重试同一 `/complete` 不会重新 PATCH 或重新发布另一个文件。实现只重放空 JSON complete 请求，保留原有 correlation headers、认证刷新及本地 state 行。

替代方案是任务级重新执行整个文件上传。该做法虽然也会从 SQLite 恢复，但会重新进入 init/准备路径，扩大冲突面且无法保证只重试提交阶段，因此不采用。

### 取消是持续等待的唯一正常终止开关

每个退避继续使用传入的 task context；前台 Ctrl-C、serve stop 或上游取消会立即打断定时等待。非 busy API error、认证/授权错误、不可恢复的本地 state error 和无法恢复的 session 结果照常返回，避免隐藏永久失败。

替代方案是新增默认总超时或 CLI 参数。用户明确要求持续重试；这会重新引入时间上限，故不采用。

## Risks / Trade-offs

- [其他客户端长期持有或持续抢占锁时，上传命令可能一直运行] → 这是批准的语义；CLI 仍可 Ctrl-C，serve 仍可停止，session/state 保留以便继续。
- [高并发 complete 产生较多请求] → 每次仍遵守 qtserver 的 `Retry-After`，并使用现有指数退避和 jitter，避免忙等。
- [错误地将永久冲突归为 busy 会掩盖问题] → 只匹配稳定原因码 `SESSION_BUSY` 与 `NAMESPACE_BUSY`；`NAMESPACE_LOCK_LOST`、普通 `CONFLICT` 和其他错误保持失败。

## Migration Plan

部署新的 qtransc 二进制即可生效，无服务端迁移或状态库迁移。升级前因 busy 失败而留下的 SQLite upload state，会在下一次上传时按既有恢复逻辑继续使用；不需要人工删除 state DB。
