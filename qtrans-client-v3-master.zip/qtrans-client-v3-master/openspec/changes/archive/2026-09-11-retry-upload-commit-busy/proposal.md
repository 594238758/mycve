## Why

当大量小文件以高 `--transfers` 并发上传时，文件内容可能已经全部传完，但多个 canonical `/complete` 同时争用 qtserver 的 session 或 principal namespace lock。当前 qtransc 在 30 秒 busy 重试窗口耗尽后结束任务，用户必须手动重新执行命令才能利用 SQLite 中保留的 session 完成提交。

用户已明确要求：对上传完成阶段的 `SESSION_BUSY` 与 `NAMESPACE_BUSY` 持续重试；只要任务未被取消，就不应因为这两种锁冲突而失败。

## What Changes

- qtransc 对 canonical upload `/complete` 收到的 `409 SESSION_BUSY` 或 `409 NAMESPACE_BUSY` 持续重试，不再使用固定 30 秒窗口。
- 每次重试继续遵守服务端 `Retry-After`；缺失或无效时沿用现有的指数退避与 jitter。等待必须响应任务 context 取消。
- 该恢复只重试幂等的 `/complete`，保留现有 upload session、已确认的分片、hash 和 SQLite 状态，不重新发送已完成的文件内容。
- `NAMESPACE_LOCK_LOST`、冲突、认证、权限、会话丢失且无法恢复、本地状态和其他非 busy 错误仍按既有错误语义处理；不得把它们变为无限重试。
- 前台 upload、serve upload task 和 upload2 均使用同一 `UploadTask` 路径，因此获得相同行为；不新增 CLI 参数、HTTP API 或 WebSocket 字段。

## Capabilities

### New Capabilities

- 无。

### Modified Capabilities

- `resumable-upload`: 修改 canonical complete 的 `SESSION_BUSY` / `NAMESPACE_BUSY` 客户端恢复期限。
- `file-management`: 修改 qtransc 有界重试规则，为幂等 upload complete 的两类锁冲突增加明确例外。

## Impact

- 受影响实现为 `qtransc/internal/qtserverapi` 的重试模式和 `qtransc/internal/uploadtask` 对 `/complete` 的调用。
- 无 qtserver API、锁实现、协议字段或配置格式变更；唯一可观察差异是遇到这两种锁冲突时上传任务保持运行并等待，而不是约 30 秒后失败。
- 长时间被其他写入持续占用时，用户须以 Ctrl-C 或 serve 的既有停止操作结束等待；届时未完成 session 继续保留供后续恢复。
