## MODIFIED Requirements

### Requirement: terminal 操作共享 renewable session lock

complete、cancel和release SHALL 获取同一 session operation lock；complete还 SHALL 获取principal namespace lock。两个lock lease均为30秒、每10秒续租。冲突 SHALL 分别返回409 `SESSION_BUSY`或`NAMESPACE_BUSY`并带`Retry-After: 1`。qtransc 对 active session 的 canonical `complete` 收到这两种冲突时 SHALL 保留 session 并持续幂等重试，直到其 task context 被取消；不得因固定 30 秒窗口报告失败。每次等待 SHALL 遵守合法的 `Retry-After`，并在其缺失或无效时使用既有退避规则。该重试 SHALL 不重新 init、PATCH、finalize 或发送已完成的文件内容。

#### Scenario: cancel与complete并发

- **WHEN** complete持有session operation lock
- **THEN** cancel SHALL 返回409 `SESSION_BUSY`
- **AND** SHALL NOT 删除session/cache

#### Scenario: namespace被其他mutation占用

- **WHEN** complete无法取得principal namespace lock
- **THEN** SHALL 返回409 `NAMESPACE_BUSY`

#### Scenario: qtransc持续等待complete锁冲突

- **WHEN** qtransc 的 active upload session 在 canonical complete 时持续收到 `SESSION_BUSY` 或 `NAMESPACE_BUSY` 超过30秒
- **THEN** qtransc SHALL 保持该上传任务运行并继续重试complete
- **AND** SHALL NOT重新发送已完成的文件内容或创建新session

#### Scenario: 等待complete锁时取消任务

- **WHEN** qtransc 正在为 canonical complete 的 busy 冲突退避等待且任务 context 被取消
- **THEN** 它 SHALL 及时停止等待
- **AND** SHALL 保留现有active session与本地恢复状态供后续任务继续
