## MODIFIED Requirements

### Requirement: qtransc retry有界且mutation不盲重试

除 canonical upload `complete` 的锁冲突外，qtransc SHALL 对需要修复业务语义后才能继续的失败使用有限次数策略：HTTP `500` 对可恢复传输操作 SHALL 最多自动重试 3 次并使用退避；hash `202` 轮询不计入该次数；`SESSION_BUSY` 与 `NAMESPACE_BUSY` 继续使用各自最多 30 秒窗口；同一请求收到 `401` 后 SHALL 最多 refresh 一次。active upload session 的 canonical `complete` 收到 `SESSION_BUSY` 或 `NAMESPACE_BUSY` 时 SHALL 持续幂等重试，直到 task context 被取消；不得因为固定次数或固定 30 秒窗口失败。move、delete 或其他非幂等 mutation 在结果不确定时 SHALL NOT 自动重复执行。

可恢复传输操作即使同时符合可用性恢复条件，也 SHALL 先遵守其安全语义：PATCH 在响应不确定时先查询服务端确认的 offset，下载重新请求确定的文件范围，complete 仅按幂等结果契约恢复。除上述 canonical complete 的两类锁冲突外，有限语义修复用尽后 SHALL 返回对应业务失败，而 SHALL NOT 把同一状态重新归类为无限可用性恢复。

#### Scenario: PATCH响应不确定

- **WHEN** PATCH连接在response前断开
- **THEN** qtransc SHALL 先GET offset再决定重传

#### Scenario: complete响应不确定

- **WHEN** complete请求断连
- **THEN** qtransc MAY 幂等重试complete或GET session

#### Scenario: complete持续发生namespace锁冲突

- **WHEN** active upload session 的canonical complete持续收到 `NAMESPACE_BUSY` 超过30秒
- **THEN** qtransc SHALL 继续按 `Retry-After` 或既有退避规则重试
- **AND** SHALL NOT仅因该等待超过30秒而结束任务

#### Scenario: complete持续发生session锁冲突

- **WHEN** active upload session 的canonical complete持续收到 `SESSION_BUSY`
- **THEN** qtransc SHALL 继续幂等重试直到成功、任务取消或出现非 busy 错误

#### Scenario: move断连

- **WHEN** move可能已经完成但response丢失
- **THEN** qtransc SHALL 报告不确定结果且不得自动重复mutation

#### Scenario: 服务返回HTTP-date Retry-After

- **WHEN** 可重试响应携带合法HTTP-date
- **THEN** qtransc SHALL 以该时间约束下次尝试

#### Scenario: HTTP/3请求尚未发送即遇到GOAWAY

- **WHEN** HTTP/3协议栈确认请求因旧连接GOAWAY而未打开stream、尚未发送
- **THEN** qtransc SHALL 在连接与stream硬上限内等待或建立替代连接并最多重试一次
- **AND** 该重试 SHALL NOT 被视为结果不确定的mutation重复执行

#### Scenario: HTTP 500重复失败

- **WHEN** 一个可恢复传输操作连续收到 HTTP `500` 且已完成 3 次自动重试
- **THEN** qtransc SHALL 停止自动重试该操作并报告服务端业务失败
