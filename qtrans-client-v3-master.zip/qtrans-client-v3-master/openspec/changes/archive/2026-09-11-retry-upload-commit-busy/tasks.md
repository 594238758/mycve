## 1. 持续 busy 重试

- [x] 1.1 在 `qtserverapi` 增加仅允许幂等调用使用的 persistent busy 重试模式，使 `SESSION_BUSY` / `NAMESPACE_BUSY` 保留 `Retry-After`、退避、jitter 和 context 取消语义但不再受 30 秒窗口限制，并保持其他错误的既有预算；以 `cd qtransc && go build ./...` 验证编译。
- [x] 1.2 让 canonical upload `/complete` 使用该模式，确保前台 upload、serve upload task 与 upload2 共享持续重试，且不重发已完成 payload；以定向代码检查确认 init、PATCH、finalize、mkdir、move、delete 和 download 未改为无限 busy 重试。

## 2. 规范同步

- [x] 2.1 将批准的 `resumable-upload` 与 `file-management` delta 合入主规范，明确 canonical complete 的两类 busy 冲突持续到任务取消、其余重试边界不变；以 `openspec validate retry-upload-commit-busy --strict` 验证。

## 3. 范围验证

- [x] 3.1 运行 `cd qtransc && go build ./...`、`openspec validate retry-upload-commit-busy --strict` 与 `git diff --check`，复查变更未触及 qtserver、CLI 参数、HTTP API、WebSocket 字段或无关的 retry 调用点。
