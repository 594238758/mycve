## 1. qtransc 标签输入与任务模型

- [x] 1.1 在 `TaskCreateRequest` 增加可选 `enterprise_id`，复用辅助标签的 SP/HTAB trim、128 bytes、UTF-8、HTTP field-value 与非 string/null 拒绝规则，并保持字段缺失或空值时任务正常创建
- [x] 1.2 在 upload/download task 与 domain task 接口中不可变保存并读取 `EnterpriseID`，确保 CLI 构造空值且任务详情、摘要、SSE、WebSocket 等输出模型不暴露该字段
- [x] 1.3 引入带命名字段的 task correlation 上下文，集中设置 `X-Task-ID`、`X-Task-PID` 和 `X-Enterprise-ID`，迁移全部 qtransc 到 Qtserver 的 upload/download 请求调用点
- [x] 1.4 清点 qtransc task logger、task manager、scheduler、handler 和 legacy CLI 路径，使所有含 `taskid`/`task_id` 的结构化日志同时包含 string `taskpid` 与 `enterprise_id`

## 2. Qtserver 关联上下文与原始事件

- [x] 2.1 在 Qtserver 请求关联上下文和结构化请求日志中读取当前 `X-Enterprise-ID`，保持缺失/空值不拒绝请求且不改变认证、授权、路径、grant、session 或业务结果
- [x] 2.2 将 business event envelope 与构造入口改为包含命名 correlation 上下文的严格八字段 schema v1，保证所有 Qtserver producer 显式输出 string `enterprise_id`
- [x] 2.3 扩展普通上传、普通下载、verify 和 Small 路径的 file log context，使注册、过程和成功事件从正确的当前请求或已固定上下文取得整组标签
- [x] 2.4 在 canonical upload session 中持久化初始 `enterprise_id`，并让 chunk、verify、complete 与 already-present 事件继续使用 session 创建时的 `(task_id, taskpid, enterprise_id)`
- [x] 2.5 为 X-Accel 普通下载增加 `X-QT-Log-Enterprise-ID` 内部 handoff，并确保该 header 与现有全部 `X-QT-Log-*` 字段一样从客户端响应隐藏

## 3. Nginx 业务事件配置

- [x] 3.1 同步修改 Nginx 配置生成模板与 `qtserver/deploy/nginx.conf`，向 Qtserver 转发 `X-Enterprise-ID`，隐藏内部企业标签 handoff，并从 upstream 值输出八字段 schema v1 JSON
- [x] 3.2 保持 handoff 有效性只校验七项必要结构字段，让 `taskpid` 与 `enterprise_id` 都允许为空；确认客户端外部或伪造的内部 header 不能直接进入 Nginx 业务事件

## 4. 文档与下游契约

- [x] 4.1 更新 `docs/server-business-logging-design.md`，完整记录两个辅助标签、八字段 schema v1、九项 Nginx handoff、24 字段最终日志、同事件 tuple 选择和协调部署边界
- [x] 4.2 更新 `qtransc/docs/qtransc-apis.md`，记录 `enterprise_id` 请求字段、校验规则、传播范围、非业务语义和不出现在响应中的约束
- [x] 4.3 更新 `qtserver/docs/qtserver-apis.md` 与 `qtserver/docs/deploy.md`，记录新外部/内部 header、session 固定、严格 envelope 和 Nginx 信任边界

## 5. 一致性与编译验证

- [x] 5.1 使用 `rg` 审计 qtransc/Qtserver 中所有 `taskpid`、`X-Task-PID`、business event 和 `taskid` 日志调用点，确认对应路径均已传播或记录 `enterprise_id`，且 API 输出模型未意外暴露标签
- [x] 5.2 分别对 qtransc 与 Qtserver 执行 `go build ./...`，修复接口或调用点遗漏；不运行测试或 benchmark
- [x] 5.3 执行 `openspec validate --all --strict`、`git diff --check`，并检查设计文档、delta specs、API 文档、静态 Nginx 配置和生成模板对字段名、数量及 schema v1 兼容性描述一致
