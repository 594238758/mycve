## MODIFIED Requirements

### Requirement: 最终标准业务日志具有项目内固定字段契约

日志分析程序 SHALL 为每个已经得到最终结论的文件活动保存一条当前最终标准业务日志。产品要求的基础字段 SHALL 按下表存在，外部《日志格式.xlsx》只作为本契约形成时的历史需求来源，不得成为构建、运行或审核依赖。

| 字段 | 类型 | 规范语义 |
| --- | --- | --- |
| `task_type` | string | 文件注册时生效的 qtserver `log.task_type` 配置值；`"0"`表示多中心，`"1"`表示C/S |
| `server_ip` | string | 文件第一次进入系统时实际使用的外部入口IP；两种`task_type`均原样输出可信值 |
| `task_id` | string | 客户端关联 ID |
| `taskpid` | string | 外部日志关联值，允许为空，不参与业务判断 |
| `enterprise_id` | string | 外部企业日志关联值，允许为空，不参与业务判断 |
| `client_id` | string | 客户端持久设备标识；两种`task_type`均原样输出可信值 |
| `client_ip` | string | qtserver 从可信网络边界观察到的客户端 IP |
| `client_os` | string | 客户端系统类型；两种`task_type`均原样输出可信值 |
| `client_version` | string | 客户端版本 |
| `client_username` | string | 一期固定等于服务端可信 `principal_id`；这是产品兼容字段，不表示独立展示名 |
| `action` | string | `upload` 或 `download` |
| `transmitted` | integer | 有合法完成事件证明的文件内容传输字节总和，单位 bytes |
| `file_path` | string | qtserver 校验并规范化后的逻辑路径 |
| `file_size` | integer | 文件大小，单位 bytes |
| `start_time` | string | 文件活动开始时间，UTC RFC3339且固定三位毫秒 |
| `end_time` | string | 权威成功事实发生时间或 timeout deadline，UTC RFC3339且固定三位毫秒 |
| `duration` | number | `end_time-start_time` 的 wall-clock 秒数，按整数毫秒计算并保留三位小数 |
| `log_time` | string | 当前结果首次写入或最近一次内容实际修订的分析时间，UTC RFC3339且固定三位毫秒 |

最终记录还 SHALL 包含下列分析扩展字段：

| 字段 | 类型 | 规范语义 |
| --- | --- | --- |
| `file_key` | string | 文件活动确定性关联键和当前结果修订键 |
| `principal_id` | string | 服务端得到的稳定身份 ID；内置 `anonymous` 用户固定为 `anonymous` |
| `result` | string | `SUCCESS` 或 `FAILED` |
| `result_reason` | string | 本 spec 定义的稳定原因码 |
| `retry_count` | integer | 相同 chunk index 的额外data attempt数之和；不是错误响应数量 |
| `speed` | number 或 null | 当前活动`transmitted>0`、成功且duration与file size均大于0时的端到端有效速度，单位bytes/s并四舍五入到三位小数；零传输、失败、`ALREADY_PRESENT`、零字节或无法计算时为null |

所有string时间字段 SHALL 使用UTC RFC3339并固定三位毫秒。分析程序 SHALL 先用时间戳差得到非负integer `duration_ms`，输出`duration=duration_ms/1000`且固定三位小数；满足speed条件时 SHALL 使用decimal或等价无溢出算法计算`file_size*1000/duration_ms`并四舍五入到三位小数，不得从格式化后的浮点duration反算。`duration_ms=0`时duration SHALL 是`0.000`且speed SHALL 是null。`transmitted` 与 `file_size` SHALL 是 `0..9223372036854775807` 的 integer。`transmitted` MAY 大于 `file_size`，因为失败、中断、hash mismatch 和重传产生的完成事件仍计入实际网络成本。最终结果原因只允许：

```text
SUCCESS / UPLOADED_AND_COMMITTED
SUCCESS / ALREADY_PRESENT
SUCCESS / DOWNLOADED_AND_VERIFIED
SUCCESS / SMALL_FILE_SENT
FAILED  / TIMEOUT
```

`log.task_type` SHALL 只允许字符串 `"0"` 或 `"1"`并默认使用`"1"`。原始事件与最终记录 SHALL 始终保留完整且可信的`server_ip`、`client_id`和`client_os`；无论`task_type`为`"0"`还是`"1"`，分析程序 SHALL 原样输出这三个字段。Task type SHALL 只表示场景分类，SHALL NOT 改变其他字段、传输协议、授权、文件空间、事件类型或状态机。

系统 SHALL NOT 把 anonymous 定义为一种下载类型。`anonymous` SHALL 是一个没有密码、任何调用方都可选择的内置用户；Qtserver SHALL 直接构造该用户的可信 principal而不查询外部身份服务，并 SHALL 固定 `principal_id=anonymous` 与 `client_username=anonymous`。普通用户与 anonymous用户 SHALL 使用相同的原始事件协议和分析状态机；本契约 SHALL NOT 改变既有文件空间或 API 权限。

一期所有用户的 `client_username` SHALL 固定等于服务端可信 `principal_id`。Producer SHALL NOT 使用客户端自报 username，也 SHALL NOT 为满足该字段单独查询或扩展身份服务。该字段当前 SHALL 视为产品格式兼容字段而不是独立展示名；未来改变其语义需要修订本契约。

#### Scenario: 使用 anonymous 用户

- **WHEN** 一个合法文件请求选择内置 `anonymous` 用户
- **THEN** Qtserver SHALL NOT 为该用户查询外部身份服务
- **AND** 原始事件与最终记录的 `principal_id` 和 `client_username` SHALL 都是 `anonymous`
- **AND** 分析程序 SHALL NOT 把它归入另一种下载类型或状态机

#### Scenario: 普通用户生成 username字段

- **WHEN** Qtserver 为合法文件请求得到可信普通用户 `principal_id`
- **THEN** 原始事件与最终记录的 `client_username` SHALL 等于该 `principal_id`
- **AND** Qtserver SHALL NOT 使用 qtransc 提交的登录名或其他客户端字段覆盖它

#### Scenario: 项目外需求附件不可用

- **WHEN** producer、分析程序或审核者无法访问原始 Excel 附件
- **THEN** SHALL 能仅依据本 requirement 确定最终记录的字段、类型和语义

#### Scenario: 多中心最终字段映射

- **WHEN** 合法原始事件的`task_type`是`"0"`
- **THEN** 原始事件 SHALL 仍包含完整且可信的`server_ip`、`client_id`和`client_os`
- **AND** 最终记录 SHALL 原样使用这三个字段

#### Scenario: C/S最终字段映射

- **WHEN** 合法原始事件的`task_type`是`"1"`
- **THEN** 最终记录 SHALL 原样使用原始上下文中的`server_ip`、`client_id`和`client_os`

#### Scenario: 校验失败后重传成功

- **WHEN** 同一上传 chunk 传输两次并最终提交成功
- **THEN** 最终记录 SHALL 是 `SUCCESS/UPLOADED_AND_COMMITTED`
- **AND** `transmitted` SHALL 累加两次完成事件的实际字节
- **AND** `retry_count` SHALL 至少增加 1

#### Scenario: 最终内容未改变

- **WHEN** 分析程序再次得到与数据库当前行完全相同的候选结果
- **THEN** SHALL NOT 仅为重复分析改变 `log_time`

### Requirement: schema v1 使用包含 taskpid 的最小公共 envelope

产品 Excel《日志格式.xlsx》的 `原始日志格式` sheet SHALL 只作为旧分片级原始格式的历史需求来源，SHALL NOT 作为 schema v1 的字段或事件契约。Producer、分析程序和审核者 SHALL 只使用本 spec 定义的 envelope、七种 typed payload 与归约规则，不得从外部 Excel 补字段或恢复旧事件。

每条原始事件 SHALL 是单行 JSON object，并且公共字段 SHALL 恰好是 `schema_version`、`event_type`、`occurred_at`、`task_id`、`taskpid`、`enterprise_id`、`file_key` 和 object 类型 `payload`。八项 SHALL 全部存在，`task_id` 与 `file_key` SHALL 是非空 string，`taskpid` 与 `enterprise_id` SHALL 是允许为空的 string。`schema_version` SHALL 是 integer `1`；`occurred_at` SHALL 表示业务事实完成时间，并编码为UTC RFC3339且恰好三位毫秒，例如`2026-08-12T10:00:00.123Z`。Envelope未知字段 SHALL 使整行无效。

Schema v1 SHALL NOT 要求 `event_id`、`operation_id`、`session_id`、`report_id`、fingerprint、producer instance、source sequence、started event 或客户端状态 event。每个 chunk finished 事件本身 SHALL 表示一次真实完成 attempt；相同 `file_key` 与 `chunk_index` 的多条合法完成事件 SHALL 表示重试，但只有位于本spec结果统计窗口内的attempt SHALL 参与`transmitted`与`retry_count`。

本契约假定采集链路不会重复导入同一原始行。Qtserver、Nginx和正式分析程序 SHALL NOT 为通用重复导入增加事件身份或去重协议。未知 schema version、无效 JSON、必填字段缺失或 typed payload 已知字段类型错误 SHALL 被隔离，且不得与 schema v1 一起归约。当前 schema v1 producer SHALL 只输出本spec为对应event type定义的已知payload字段；同一schema以后新增的未知payload字段 SHALL 随原始JSON保存在ClickHouse，但旧分析器 SHALL 忽略该字段且不得因此隔离整行。本项目当前只开发扩展后的八字段 schema v1，不建立旧七字段 v1、其他 schema version 的读取、迁移或协商契约。

Qtserver、Nginx和分析基础设施的部署 SHALL 使用NTP或等价机制同步系统时钟。Qtserver SHALL 把事件时间与small `started_at`截断到UTC毫秒，Nginx SHALL 使用UTC `$msec`构造同样格式；分析时间与`log_time` SHALL 归一到UTC毫秒，最终JSON时间 SHALL 固定使用相同格式。Decoder SHALL 拒绝非UTC、非恰好三位小数或不可解析的wire事件时间，防止写入`DateTime64(3)`时静默改变排序。第一版分析程序 SHALL NOT 估算或修正producer时钟偏差。每次归约 SHALL 只应用`occurred_at`不晚于本次analysis time的事件；合法未来事件 SHALL 保留在ClickHouse和inspect中，但在分析时钟追上前 SHALL NOT 建立状态、刷新deadline、参与统计或形成结果。持续未来时间或跨producer明显倒序 SHALL 作为部署监控问题处理。

#### Scenario: 相同 chunk index出现两条完成事实

- **WHEN** 一个文件的同一 chunk index有两条合法 `chunk_finished`
- **THEN** 分析程序 SHALL 将它们视为两个真实 attempt
- **AND** SHALL NOT 以“可能重复采集”为由删除其中一条

#### Scenario: 事件时间晚于分析时钟

- **WHEN** ClickHouse存在结构和语义合法但`occurred_at`晚于本次analysis time的事件
- **THEN** 分析程序 SHALL 保留并在inspect中展示该事件
- **AND** 本轮 SHALL NOT 使用它建立状态、刷新deadline、参与统计或形成最终结果

#### Scenario: v1事件携带非空辅助标签

- **WHEN** producer 为带非空日志关联值的请求输出原始业务事件
- **THEN** envelope SHALL 同时包含非空 `task_id` 以及对应 string 值的 `taskpid` 与 `enterprise_id`
- **AND** `schema_version` SHALL 是 integer `1`

#### Scenario: v1事件的辅助标签为空

- **WHEN** 文件活动没有外部 `taskpid` 或 `enterprise_id`
- **THEN** 每条 v1 事件仍 SHALL 为缺失的标签显式写入空字符串
- **AND** producer SHALL NOT 省略任一字段或写 `null`

#### Scenario: 旧七字段v1事件

- **WHEN** schema v1 行缺少 `enterprise_id` 但其余七个旧字段合法
- **THEN** decoder SHALL 将该行作为缺少必填 envelope 字段的无效事件隔离
- **AND** SHALL NOT 为开发阶段旧日志补写默认值

#### Scenario: v1出现额外envelope字段

- **WHEN** schema v1 行在八个规定字段之外包含其他顶层字段
- **THEN** decoder SHALL 将该行作为无效envelope隔离

### Requirement: 普通下载完成事件覆盖实际响应与整文件校验

普通下载每个 `/d/down` GET SHALL 使用请求头 `X-QT-Chunk-Index` 携带非负十进制integer `chunk_index`，包括Range GET与无Range完整文件GET；同一客户端分片的断点续传和重试 SHALL 保持相同chunk index，单请求完整GET SHOULD 使用0。该请求头缺失、格式非法或超出实现可接受整数范围时，Qtserver SHALL 在输出 `file.registered` 或开始发送数据前拒绝请求，并 SHALL NOT 为该请求输出原始业务事件。该值 SHALL 只用于原始日志分片关联和 retry count 分组，SHALL NOT 参与认证、授权、grant校验、文件定位、Range计算或传输成功判定。

普通`/d/down` SHALL 只为`file_size>0`的文件产生数据和chunk事件：Range GET使用规范非空半开区间，完整GET使用`[0,file_size)`。零字节下载 SHALL 走small路径，Qtserver SHALL NOT 为它构造`[0,0)`的`download.chunk_finished`。

#### Scenario: 无Range完整文件GET

- **WHEN** qtransc以`X-QT-Chunk-Index: 0`对非空普通文件执行无Range完整GET
- **THEN** `download.chunk_finished`的Range SHALL 是`[0,file_size)`且expected status为200

#### Scenario: 零字节文件不走普通GET

- **WHEN** download grant表示file size为0
- **THEN** qtransc SHALL 使用small路径而不调用`/d/down`
- **AND** Qtserver SHALL NOT 输出空Range的download chunk事件

Qtserver SHALL 校验外部请求头并通过以下九个只对Nginx可见的内部响应头重新构造可信handoff：

```text
X-QT-Log-Task-ID
X-QT-Log-Task-PID
X-QT-Log-Enterprise-ID
X-QT-Log-File-Key
X-QT-Log-Chunk-Index
X-QT-Log-Range-Start
X-QT-Log-Range-End
X-QT-Log-Expected-Status
X-QT-Log-Expected-Bytes
```

它们 SHALL 分别表示`task_id`、允许为空的`taskpid`、允许为空的`enterprise_id`、`file_key`、已校验`chunk_index`、规范半开Range两端、预期200或206状态及`range_end-range_start`。Nginx SHALL 只使用对应的`$upstream_http_x_qt_log_*`值构造业务事件，SHALL NOT 直接读取客户端`X-QT-Chunk-Index`、`X-Task-PID`、`X-Enterprise-ID`或客户端提交的任意内部同名header，并 SHALL 从客户端响应隐藏全部九项。Schema version 1与`event_type=download.chunk_finished` SHALL 是专用Nginx log format常量；Qtserver SHALL NOT 为schema v1 handoff传递event ID、operation ID、started time、producer或file size。

Nginx SHALL 在写专用业务事件前使用map或等价配置验证除允许为空的`taskpid`和`enterprise_id`外七项upstream handoff结构合法：task ID与file key非空，chunk index、Range端点与expected bytes为非负十进制integer文本，expected status为`200|206`。任一辅助标签为空 SHALL NOT 阻止事件写入。只有结构检查通过时，internal location才 SHALL 使用条件`access_log`写入`download_events.log`。缺失或非法必要handoff、客户端直接访问internal location以及非X-Accel请求 SHALL NOT 向业务事件文件写入含`-`占位符或非JSON数值的行；它们 MAY 由普通access/error log记录。Range顺序、expected bytes与Range宽度等跨字段关系仍 SHALL 由schema decoder校验。

实际数据发送方 SHALL 在普通下载响应结束时输出 `download.chunk_finished`，payload 包含非负`chunk_index`、`range_start`、`range_end`、非负 `actual_bytes`、`http_status`和`result=succeeded|interrupted|failed`。范围 SHALL 满足`0 <= range_start < range_end <= file_size`，actual bytes SHALL 不大于Range宽度，HTTP status SHALL 是`100..599` integer，succeeded SHALL 只允许状态200或206且actual bytes等于Range宽度。启用X-Accel时producer SHALL 是Nginx，direct模式 SHALL 是qtserver；两者 SHALL 使用完全相同的payload语义。`actual_bytes` SHALL 是本响应实际发送的文件内容字节。

两种producer SHALL 按以下规则确定结果：

- 实际HTTP状态等于expected status、200没有Content-Range或206具有合法单区间Content-Range、请求正常结束且实际body bytes等于expected bytes时，`result` SHALL 是`succeeded`、`actual_bytes` SHALL 是实际body bytes。
- 状态与Content-Range仍表示预期文件数据响应，但请求未正常结束或body bytes与expected bytes不同，`result` SHALL 是`interrupted`、`actual_bytes` SHALL 是实际发送的文件body bytes。
- 实际状态不等于expected status，或206 Content-Range格式无效，`result` SHALL 是`failed`、`actual_bytes` SHALL 是0。错误响应body SHALL NOT 计作文件内容传输字节。

Nginx SHALL 使用`$request_completion`、`$status`、`$sent_http_content_range`和`$body_bytes_sent`形成上述事实，`occurred_at` SHALL 使用log phase时间。第一版 SHALL NOT 要求Nginx再次逐字符证明Content-Range与handoff Range完全相等；预期状态、Range格式与expected bytes校验 SHALL 是本契约要求的边界。Direct模式 SHALL 使用可获得的请求context、响应状态和实际writer bytes实现同一可观察语义。

Qtserver 每次通过认证、参数、路径等前置校验并实际开始读取、计算或比较hash的普通下载校验结束后 SHALL 输出 `download.verify_finished`，其已知payload字段 SHALL 是 `verification_scope=chunk|file`、适用的`chunk_index`与`verification_result=matched|mismatched|failed`。完成比较且一致时 SHALL 使用`matched`，完成比较但不一致时 SHALL 使用`mismatched`，进入校验执行后因读取、计算或依赖错误无法得出结论时 SHALL 使用`failed`。请求前置校验失败以及服务端hash为`HASH_PENDING`或`HASH_UNAVAILABLE`、尚无可比较结果时 SHALL NOT 输出verify完成事件，也 SHALL NOT 刷新文件不活动deadline。当前producer SHALL NOT 输出其他payload字段；consumer仍 SHALL 按公共规则保留并忽略未来未知payload字段。Scope为chunk时chunk index SHALL 是非负integer；scope为file时chunk index SHALL 是null。只有整文件 `matched` SHALL 是 `SUCCESS/DOWNLOADED_AND_VERIFIED` 的权威成功事实；分片 matched 和整文件 mismatched/failed 都不结束文件。

#### Scenario: 下载服务端hash仍在生成

- **WHEN** 整文件`/d/verify`得到`HASH_PENDING`或`HASH_UNAVAILABLE`且尚未开始比较hash
- **THEN** Qtserver SHALL NOT 输出`download.verify_finished`
- **AND** 该请求 SHALL NOT 刷新日志不活动deadline

#### Scenario: 下载hash计算执行失败

- **WHEN** Qtserver已经开始读取或计算下载校验hash但因I/O或依赖错误无法完成比较
- **THEN** SHALL 输出`download.verify_finished{verification_result=failed}`
- **AND** 该事件 SHALL 刷新当前有效的不活动deadline但不得建立文件失败终态

Schema v1 payload SHALL NOT 要求或输出expected hash、actual hash、hash algorithm、请求级reason code或异常文本。现有文件hash存储和调试日志 MAY 保存其职责内的信息，但分析程序 SHALL NOT 读取它们补齐或覆盖原始业务事件。

普通用户与内置 `anonymous` 用户 SHALL 使用相同 Range、整文件 verify 和日志分析流程。两者的身份解析方式 MAY 不同，但 SHALL NOT 形成不同的下载业务类型。整文件 matched 已经证明客户端持有一致内容，因此 qtransc SHALL NOT 再调用独立下载完成确认 API。

#### Scenario: 断点续传改变 Range 起点

- **WHEN** qtransc 对同一个 chunk 从后续 offset继续 Range 下载
- **THEN** 新请求的 `X-QT-Chunk-Index` SHALL 保持原 `chunk_index` 并携带实际新 Range
- **AND** 分析程序 SHALL 将它计作该 chunk 的额外 attempt

#### Scenario: 下载请求缺少 chunk index

- **WHEN** 普通 `/d/down` 请求缺少合法 `X-QT-Chunk-Index`
- **THEN** Qtserver SHALL 在注册文件或发送数据前拒绝请求
- **AND** SHALL NOT 输出 `file.registered` 或 `download.chunk_finished`

#### Scenario: 客户端伪造 Nginx 日志字段

- **WHEN** 客户端同时提交`X-QT-Chunk-Index`、`X-Task-PID`、`X-Enterprise-ID`和任意`X-QT-Log-*`内部header
- **THEN** Qtserver SHALL 只校验外部chunk index并从当前请求日志上下文重新构造全部内部handoff
- **AND** Nginx SHALL 只使用qtserver upstream的`X-QT-Log-*`值

#### Scenario: Nginx专用格式固定schema和event type

- **WHEN** Nginx记录一条X-Accel普通下载完成事件
- **THEN** log format SHALL 直接输出integer`schema_version=1`和string`event_type=download.chunk_finished`
- **AND** SHALL NOT 从handoff读取这两个常量或输出其他公共字段

#### Scenario: Nginx缺少完整必要handoff

- **WHEN** internal location请求没有结构合法的task、file、chunk、Range、expected status和expected bytes upstream handoff
- **THEN** Nginx SHALL NOT 向`download_events.log`写入该请求
- **AND** SHALL NOT 生成包含`-`或非JSON数值的半条schema v1 JSON

#### Scenario: Nginx收到空辅助标签

- **WHEN** 其他必要handoff合法但`X-QT-Log-Task-PID`或`X-QT-Log-Enterprise-ID`为空或缺失
- **THEN** Nginx SHALL 写出合法 v1 事件并为对应字段写入空字符串

#### Scenario: 未启用Nginx加速

- **WHEN** qtserver direct模式处理一个普通Range下载
- **THEN** qtserver SHALL 在响应结束后输出`download.chunk_finished`
- **AND** 分析程序 SHALL 与Nginx事件使用相同规则归约

#### Scenario: X-Accel连接中途断开

- **WHEN** Nginx已经开始合法文件数据响应但`$request_completion`不是`OK`
- **THEN** Nginx SHALL 输出`download.chunk_finished{result=interrupted}`
- **AND** `actual_bytes` SHALL 使用已经发送的文件body bytes

#### Scenario: X-Accel返回错误状态

- **WHEN** internal文件发送实际状态不等于qtserver handoff的expected status
- **THEN** Nginx SHALL 输出`download.chunk_finished{result=failed}`
- **AND** `actual_bytes` SHALL 是0，即使错误响应本身发送了body

#### Scenario: Nginx内部日志header不暴露

- **WHEN** 客户端收到X-Accel普通下载响应
- **THEN** SHALL 看不到上述九个task、辅助标签、file、chunk、Range、expected status或expected bytes handoff header

#### Scenario: 响应完整但没有整文件 verify

- **WHEN** 所有 Range 响应均成功但没有整文件 matched 事实
- **THEN** 普通下载 SHALL NOT 成为成功
- **AND** SHALL 在 inactivity deadline 后形成 `FAILED/TIMEOUT`

#### Scenario: anonymous 用户执行普通下载

- **WHEN** 使用 `anonymous` 用户的 qtransc 完成普通下载并通过整文件 verify
- **THEN** 文件 SHALL 成为 `SUCCESS/DOWNLOADED_AND_VERIFIED`
- **AND** principal 与 username SHALL 使用 `anonymous`

### Requirement: 普通文件字段使用完成事实确定性归约

普通文件 `start_time` SHALL 使用最早合法 `file.registered.occurred_at`。分析程序 SHALL 先确定包含两个边界的结果统计窗口：SUCCESS是`start_time..最早权威成功时间`，TIMEOUT是`start_time..首次inactivity deadline`。普通事件早于start time SHALL 非法；晚于结果窗口的普通事件 MAY 保留在ClickHouse和inspect中，但 SHALL NOT 参与最终字段。

普通文件的公共上下文 SHALL 使用最早合法注册payload，small SHALL 使用自身payload。两条路径都 SHALL 原样保留上下文中的可信字段；`task_type`只表示场景分类，`"0"`和`"1"`均不得导致`server_ip`、`client_id`、`client_os`或其他最终字段被删除、清空或改写。

全部24个最终字段 SHALL 确定如下：普通文件的`task_type`、`server_ip`、`client_id`、`client_ip`、`client_os`、`client_version`、`client_username`、`action`、`file_path`、`file_size`与`principal_id`来自最早合法注册payload，small的这些字段来自其自包含payload；`task_id`与`file_key`来自对应envelope并通过四元组校验；普通文件的`taskpid`与`enterprise_id`来自同一条被选定的最早合法注册envelope，small的两项标签来自同一条形成当前结果的small成功envelope。普通文件`start_time`来自最早合法注册时间，small来自`started_at`；普通文件`end_time`来自最早权威成功时间或首次deadline，small来自事件时间；`duration`为两者非负毫秒差，`log_time`为候选首次写入或内容实际修订时的固定analysis time。普通文件`result`与`result_reason`按committed、already-present、整文件matched或timeout映射，small固定为`SUCCESS/SMALL_FILE_SENT`。`transmitted`、`retry_count`与`speed` SHALL 按下述规则计算。除此之外不得从调试日志、qtserver数据库或客户端状态补字段。

除already-present外，上传 `transmitted` SHALL 是结果统计窗口内合法 `upload.chunk_finished.actual_bytes` 之和；下载 SHALL 是结果统计窗口内合法 `download.chunk_finished.actual_bytes` 之和。`retry_count` SHALL 在相同窗口内按 `chunk_index` 分组，对每组计算 `max(finished_count-1,0)` 后求和，不要求前一个attempt结果是failed或interrupted。`SUCCESS/ALREADY_PRESENT` SHALL 固定 `transmitted=0` 与 `retry_count=0`。

上传成功 `end_time` SHALL 使用最早合法 `upload.finished.occurred_at`；下载成功 SHALL 使用最早合法整文件 matched 时间；失败 SHALL 使用 timeout deadline。除already-present外，成功且`transmitted>0`、`duration_ms>0`、`file_size>0`时speed SHALL 按本spec的三位小数规则计算，其他情况为null；already-present的speed SHALL 固定为null。校验请求、HTTP header、TLS 和授权数据 SHALL NOT 计入 transmitted。

#### Scenario: 新task复用完整下载现场只执行verify

- **WHEN** 新task ID的文件活动没有任何download chunk finished，但第一次携带metadata的整文件verify得到matched
- **THEN** 最终记录 SHALL 是`SUCCESS/DOWNLOADED_AND_VERIFIED`
- **AND** `transmitted=0`、`retry_count=0`且`speed=null`

#### Scenario: 原task ID继续完整下载现场

- **WHEN** 调用方复用原task ID且四元组其余字段不变，并在已有历史chunk后执行整文件matched verify
- **THEN** 分析程序 SHALL 按同一file key完整历史计算transmitted与retry count

普通文件duration SHALL 包含注册后的传输、校验、重试等待、退避和客户端静默wall-clock时间；服务端 SHALL NOT 猜测或扣除客户端暂停。并行chunk持续时间 SHALL NOT 相加。Speed SHALL 使用file size而非transmitted作为分子，表示端到端有效速度而非链路吞吐率。Small文件duration只覆盖当前tar响应内该文件从started_at到entry完成，不包含grant或客户端接收与本地校验时间。

#### Scenario: 客户端暂停后继续

- **WHEN** 普通文件注册后客户端静默一段时间并在deadline前继续直到成功
- **THEN** duration SHALL 包含该静默时间
- **AND** 分析程序 SHALL NOT 扣除未上报的暂停区间

#### Scenario: 并行分片

- **WHEN** 多个chunk并行传输并最终成功
- **THEN** duration SHALL 只等于文件start到end的wall-clock差
- **AND** SHALL NOT 累加各chunk耗时

#### Scenario: 成功响应丢失后再次请求

- **WHEN** 最早权威成功事实之后出现chunk、verify或相同成功事实重试
- **THEN** 最终结果 SHALL 保持第一次成功
- **AND** 成功之后的chunk SHALL NOT 进入transmitted或retry count

#### Scenario: 上传成功事实冲突

- **WHEN** 同一file key同时存在合法`upload.finished{committed}`与`upload.finished{already_present}`
- **THEN** 分析程序 SHALL 报告producer终态冲突
- **AND** SHALL NOT 按到达顺序或时间猜测其中一个结果

本模型没有 started 事件，因此完全没有留下完成事件的调用无法计入 transmitted 或 retry。分析程序 SHALL NOT 猜测其字节数，也 SHALL NOT 为此引入 `statistics_complete`、operation pairing 或全局序号。

连接中断后从后续offset续传、hash mismatch后重传或客户端重新请求同一chunk SHALL 都作为额外data attempt计数。Init、grant、verify、complete和查询请求的重复调用 SHALL NOT 增加`retry_count`。

#### Scenario: 中断 attempt有完成事件

- **WHEN** 一个 `chunk_finished{result=interrupted}` 记录了非零 actual bytes，随后重试并成功
- **THEN** 两个完成事件的实际字节 SHALL 都计入 transmitted
- **AND** 相同 chunk index SHALL 使 retry count增加 1

#### Scenario: 完成事件整行丢失

- **WHEN** 一次请求没有留下任何 finished 事件
- **THEN** 分析程序 SHALL 不猜测该请求的实际字节或 attempt
- **AND** 本契约允许最终统计小于真实网络成本

## ADDED Requirements

### Requirement: enterprise_id 作为辅助标签进入原始事件和最终日志

每条 schema v1 原始业务事件 SHALL 在 `taskpid` 后显式记录 string 字段 `enterprise_id`；无值时 SHALL 记录空字符串。Canonical upload SHALL 使用 session 创建时保存的初始 `enterprise_id` 输出该 session 的全部原始事件。普通下载和 Small 事件 SHALL 使用对应请求的 Qtserver 日志上下文；X-Accel 普通下载 chunk 事件 SHALL 使用 Qtserver 交给 Nginx 的内部 handoff，而不得直接信任客户端提交的同名内部 header。

`enterprise_id` SHALL NOT 参与 `file_key` 算法、注册合法性、上下文冲突、事件有效性、attempt、inactivity deadline、transmitted、retry count、speed、result、result reason 或其他业务判断，也不得产生企业级状态或新的事件类型。后续事件中的不同值 SHALL 只保留为原始证据，不得覆盖最终值。

普通文件最终日志 SHALL 从被选定的最早合法 `file.registered` envelope 同时取得 `taskpid` 与 `enterprise_id`；Small 文件 SHALL 从形成当前 `SMALL_FILE_SENT` 结果的同一条 `download.small_file_sent` 同时取得两项标签。最早候选事件的 `occurred_at` 并列、业务内容完全相同且仅辅助标签不同时，分析程序 SHALL 按 `(taskpid, enterprise_id)` 的 UTF-8 bytes 字典序选择最小 tuple 对应的整条事件，禁止分别选择两个字段或依赖导入顺序。

#### Scenario: 原始事件记录 enterprise_id

- **WHEN** Qtserver 为带非空 `enterprise_id` 的文件活动输出原始事件
- **THEN** 同一 envelope SHALL 包含相同归一化 string 值的 `enterprise_id`
- **AND** typed payload SHALL 与空企业标签时保持相同

#### Scenario: 后续事件携带不同 enterprise_id

- **WHEN** 最早合法注册之后的 chunk、verify 或 finished 事件携带不同 `enterprise_id`
- **THEN** producer SHALL 在各事件中记录对应日志上下文允许采用的值
- **AND** 该差异 SHALL NOT 改变事件类型、payload、状态、指标或业务结果

#### Scenario: 企业标签不同但文件活动相同

- **WHEN** 两个请求只在 `enterprise_id` 上不同而 task ID、路径、principal 和 action 相同
- **THEN** `file_key` SHALL 保持相同
- **AND** `enterprise_id` SHALL NOT 创建新的文件活动或企业聚合状态

#### Scenario: 同时间注册的辅助标签并列

- **WHEN** 两条最早合法注册具有相同 `occurred_at` 和业务内容，但标签 tuple 分别为 `("b","a")` 与 `("a","z")`
- **THEN** 分析程序 SHALL 选择 tuple `("a","z")` 对应的整条注册事件
- **AND** SHALL NOT 合成不存在的 `("a","a")`
