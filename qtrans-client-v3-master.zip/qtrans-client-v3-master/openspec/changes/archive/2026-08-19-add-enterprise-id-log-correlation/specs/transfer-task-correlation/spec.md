## ADDED Requirements

### Requirement: serve 创建任务 API 接收可选 enterprise_id

qtransc `serve` 的 `POST /api/v1/tasks` 请求体 SHALL 接受可选 string 字段 `enterprise_id`。qtransc SHALL 先去除输入值首尾的 ASCII SP 和 HTAB，内部空白 SHALL 保留；字段缺失、值为空字符串或 trim 后为空时 SHALL 使用空字符串创建任务。归一化后的非空值 SHALL 至多为 128 bytes、是合法 UTF-8，且只包含可安全作为 HTTP header field value 传播的文本。不符合输入格式或显式使用 `null`、number、boolean、array 或 object 时，serve API SHALL 返回现有 invalid-request 类别的 400 响应，且不得创建任务。

`enterprise_id` SHALL 是不透明的外部企业日志关联标签，SHALL NOT 具有可信企业身份、tenant、principal、授权标识或幂等键语义。qtransc 的 CLI 子命令 SHALL NOT 新增对应参数，非 serve 创建的任务 SHALL 使用空字符串。创建任务响应、任务详情与摘要、SSE、WebSocket 和其他 API 响应 SHALL NOT 返回 `enterprise_id`。

#### Scenario: serve 调用方传入 enterprise_id

- **WHEN** 调用方使用首尾含 ASCII SP 或 HTAB、trim 后合法的非空 `enterprise_id` 创建 upload 或 download 任务
- **THEN** qtransc SHALL 保存 trim 后的 string 并保留内部空白
- **AND** 后续请求 header、原始事件和最终日志 SHALL 使用相同的归一化值

#### Scenario: serve 调用方省略 enterprise_id

- **WHEN** 创建任务请求没有 `enterprise_id`、值为空字符串或 trim 后为空
- **THEN** qtransc SHALL 正常创建任务
- **AND** 该任务的企业关联标签 SHALL 是空字符串

#### Scenario: 非法 enterprise_id

- **WHEN** serve 请求的 `enterprise_id` 在 trim 后超过 128 bytes、不是合法 UTF-8、包含非法 HTTP field-value 字符或不是 string
- **THEN** qtransc SHALL 以 400 invalid request 拒绝创建任务
- **AND** 除规定的 trim 外 SHALL NOT 截断、改写或部分传播该值

#### Scenario: CLI 创建任务

- **WHEN** 用户通过非 serve CLI 子命令创建传输任务
- **THEN** CLI SHALL NOT 提供 `enterprise_id` 参数
- **AND** 该任务所有需要共现的日志 SHALL 使用空字符串 `enterprise_id`

#### Scenario: 查询任务不暴露企业标签

- **WHEN** 调用方创建带非空 `enterprise_id` 的 serve 任务后查询任务或订阅实时事件
- **THEN** 对应 API、SSE 和 WebSocket 输出 SHALL NOT 包含 `enterprise_id`

### Requirement: enterprise_id 随 task ID 传播但不参与业务

qtransc SHALL 在同一 upload/download task 内不可变地保存 `enterprise_id`。该 task 的所有 Qtserver HTTP 请求只要携带当前有效的 `X-Task-ID`，就 SHALL 同时携带 `X-Task-PID` 与 `X-Enterprise-ID`；两项标签为空时也 SHALL 使用空 string 语义传播。当前有效 task ID MAY 是 qtransc 本地 task ID 或显式保存的 ServerTaskID，标签 SHALL 跟随最终写入 `X-Task-ID` 的值发送，但 SHALL NOT 参与选择或生成该 task ID。

Nginx SHALL 显式转发 `X-Enterprise-ID`，Qtserver SHALL 将其作为当前请求日志上下文读取。除 serve 创建任务 API 外，系统 SHALL NOT 从 CLI flag、Qtserver 响应、download grant、路径、token、session、principal 或其他字段生成、推导或覆盖 `enterprise_id`。

`enterprise_id` SHALL NOT 参与认证、授权、principal、企业或用户文件空间、路径规范化、download grant 或 HMAC、upload session ownership、业务幂等、`file_key`、Range、hash、重试、任务状态、指标或传输结果。相同业务请求在 `enterprise_id` 缺失、为空、不同或由第三方伪造时，除日志内容外 SHALL 具有相同业务行为。系统 SHALL NOT 按企业标签建立 Task aggregate 或企业级传输状态。

Canonical upload session SHALL 保存创建 session 时收到的初始 `(task_id, taskpid, enterprise_id)`，并为该 session 后续原始业务事件继续使用整组初始日志关联值。后续请求当前 `X-Task-ID`、`X-Task-PID` 或 `X-Enterprise-ID` 不同 MAY 出现在请求运行日志中，但 SHALL NOT 改变 session、`file_key` 或原始事件采用的初始值。

#### Scenario: 任务请求携带三项关联 header

- **WHEN** qtransc 为一个 serve 任务发送带 `X-Task-ID` 的 Qtserver 请求
- **THEN** 同一请求 SHALL 同时携带 `X-Task-PID` 与 `X-Enterprise-ID`
- **AND** 两项值 SHALL 等于任务创建时保存的归一化标签

#### Scenario: 本地 task ID 与 ServerTaskID 不同

- **WHEN** qtransc task 保存了与本地 task ID 不同的 ServerTaskID
- **THEN** Qtserver 请求 SHALL 使用 ServerTaskID 作为 `X-Task-ID`
- **AND** SHALL 继续携带该 qtransc task 不可变保存的 `taskpid` 与 `enterprise_id`

#### Scenario: 空企业标签继续传输

- **WHEN** qtransc 任务的 `enterprise_id` 为空字符串
- **THEN** Qtserver SHALL 按现有 task ID、身份和业务参数执行请求
- **AND** SHALL NOT 因 `X-Enterprise-ID` 缺失或为空拒绝请求

#### Scenario: 第三方改变企业标签

- **WHEN** 两个其他条件相同的请求携带不同 `X-Enterprise-ID`
- **THEN** Qtserver SHALL 只在对应日志上下文中记录各自值
- **AND** 授权、session、文件状态和 HTTP 业务结果 SHALL 不因此改变

#### Scenario: canonical upload 后续请求改变标签

- **WHEN** 同 principal 对已有 canonical upload session 发送与创建时不同的 `X-Task-PID` 或 `X-Enterprise-ID`
- **THEN** Qtserver SHALL 按现有 session 契约继续处理请求
- **AND** 该 session 的原始业务事件 SHALL 继续使用创建时保存的整组初始关联值

### Requirement: 结构化运行日志中的 task ID 与两个辅助标签必须共现

qtransc、Qtserver 和 Nginx 的结构化运行或访问日志中，只要一条记录包含名为 `taskid` 或 `task_id` 的结构化字段，同一条记录 SHALL 同时包含名为 `taskpid` 和 `enterprise_id` 的 string 字段。存在关联值时 SHALL 记录对应值；无值时 SHALL 显式记录空字符串，不得省略、写 `null` 或使用占位符。该规则只约束日志记录，不要求含 `task_id` 的普通 HTTP API 响应或内部非日志数据模型暴露两个标签。

Qtserver 请求日志 SHALL 分别使用当前请求 `X-Task-PID` 与 `X-Enterprise-ID`，并对两项值执行结构化 JSON 日志编码。任一标签 SHALL NOT 改变日志级别、消息、错误处理或采样决策。Authorization、grant、HMAC secret 和 token SHALL NOT 因标签共现而进入日志。

#### Scenario: serve 任务写 qtransc 运行日志

- **WHEN** qtransc 为带非空辅助标签的任务写出一条含 `taskid` 或 `task_id` 字段的结构化日志
- **THEN** 同一条日志 SHALL 包含值相同的 string 字段 `taskpid` 与 `enterprise_id`

#### Scenario: CLI 任务写 qtransc 运行日志

- **WHEN** 非 serve CLI 任务写出一条含 `taskid` 或 `task_id` 字段的结构化日志
- **THEN** 同一条日志 SHALL 包含 `"taskpid":""` 与 `"enterprise_id":""`

#### Scenario: Qtserver 请求错误日志

- **WHEN** 携带三项关联 header 的请求在 Qtserver 产生结构化错误日志
- **THEN** 该记录的 task ID、`taskpid` 与 `enterprise_id` SHALL 同时存在
- **AND** 两项辅助标签 SHALL NOT 改变返回给客户端的业务错误
