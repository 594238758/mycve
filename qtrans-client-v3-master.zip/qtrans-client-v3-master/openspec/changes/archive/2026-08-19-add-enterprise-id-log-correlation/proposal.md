## Why

外部业务除 `taskpid` 外还需要使用企业 ID 检索和关联同一批传输日志。系统需要增加一个随 `task_id` 传播的 `enterprise_id` 标签，同时明确它与 `taskpid` 一样只提供日志关联能力，不改变现有传输、身份和授权行为。

## What Changes

- `qtransc serve` 的任务创建请求新增可选 string 字段 `enterprise_id`，采用与 `taskpid` 相同的 trim、长度、UTF-8 和 HTTP header 安全校验规则；CLI 任务继续使用空值。
- qtransc 在任务生命周期内不可变地保存 `taskpid` 与 `enterprise_id`，并在所有携带 `X-Task-ID` 的 Qtserver 请求中同时发送 `X-Task-PID` 与 `X-Enterprise-ID`。
- Qtserver 把 `enterprise_id` 作为不可信的纯日志标签读取和记录；canonical upload session 固定创建时的 `(task_id, taskpid, enterprise_id)`，Nginx X-Accel 下载通过 `X-QT-Log-Enterprise-ID` 接收内部可信 handoff。
- schema v1 原始业务事件 envelope 从七个固定字段扩展为八个固定字段并始终显式包含 `enterprise_id`；最终业务日志从 23 个字段扩展为 24 个字段。
- 普通文件最终标签取自最早合法 `file.registered`，Small 文件取自形成当前结果的 `download.small_file_sent`；同时间候选按整组 `(taskpid, enterprise_id)` 的 UTF-8 bytes 字典序确定，禁止混合不同事件的字段。
- 结构化运行日志只要包含 `taskid` 或 `task_id`，就同时包含 string 类型的 `taskpid` 与 `enterprise_id`；无值使用空字符串。任务详情、摘要、SSE、WebSocket 和其他 API 响应仍不返回这两个标签。
- 同步更新完整业务日志设计、qtransc/Qtserver API 文档和 Nginx 部署文档。
- **BREAKING**：未发布的 schema v1 原地扩展为八字段。此前开发阶段产生的七字段 v1 原始事件不再满足严格 envelope，旧 consumer 也不能读取新事件。业务日志能力尚未进入任何 release tag，因此不提供旧开发日志迁移或双 schema 兼容，producer、Nginx 配置和正式 consumer 必须同批升级。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `transfer-task-correlation`：增加 `enterprise_id` 的任务输入、归一化、传播、session 固定和结构化日志共现契约。
- `raw-business-event-log`：把 schema v1 envelope 扩展为八字段，并把 `enterprise_id` 纳入原始事件、Nginx handoff、确定性归约和 24 字段最终日志。

## Impact

- 外部 API：`POST /api/v1/tasks` 请求体新增可选 `enterprise_id`；缺失时行为不变，响应结构不变。
- HTTP：qtransc 到 Qtserver 新增 `X-Enterprise-ID`；Qtserver 到 Nginx 新增内部 `X-QT-Log-Enterprise-ID`。两者均不得参与授权、路由、grant/HMAC、session ownership 或业务判断。
- 原始日志：Qtserver 与 Nginx schema v1 producer、严格 decoder、采集表结构和最终日志表结构需要同步更新。
- 代码：影响 qtransc 请求模型、task/domain 关联上下文、Qtserver API client、运行日志、Qtserver handler/session/event envelope 和 Nginx 配置生成。
- 文档：影响 `docs/server-business-logging-design.md`、`qtransc/docs/qtransc-apis.md`、`qtserver/docs/qtserver-apis.md` 与 `qtserver/docs/deploy.md`。
- 依赖与配置：不新增第三方依赖，不新增服务端配置字段或数据库 migration。
- 非目标：不建立企业聚合状态，不验证企业真实性，不把 `enterprise_id` 暴露到任务查询或事件 API，不兼容开发阶段七字段 schema v1 日志。
