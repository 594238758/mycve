## Context

当前 qtransc task 分别保存本地 `TaskID`、可选 ServerTaskID 和 `TaskPID`。向 Qtserver 发请求时使用当前有效的 task ID 作为 `X-Task-ID`，并把 `TaskPID` 作为 `X-Task-PID` 同请求传播。Qtserver 将当前标签用于请求运行日志，canonical upload session 还会固定初始 task ID 与 `taskpid`；原始业务事件采用严格七字段 schema v1，X-Accel 下载由 Qtserver 通过八个内部响应 header 把可信日志上下文交给 Nginx。

本变更横跨 qtransc、Qtserver、Nginx、原始事件和下游分析契约。业务日志协议在 `v0.4.0` 之后才进入当前开发分支，尚未进入 release tag；因此按 proposal 直接扩展 schema v1，而不建立 v2 或旧七字段兼容层。行为要求见本 change 的三份 delta spec。

## Goals / Non-Goals

**Goals:**

- 在不改变传输行为的前提下，让 `enterprise_id` 与 `taskpid` 一起可靠地跟随当前有效 task ID 穿过所有请求和日志生产路径。
- 让 qtransc、Qtserver、Nginx 和正式 consumer 对八字段 schema v1、标签来源与 24 字段最终日志形成单一解释。
- 保持两项辅助标签来自同一候选事件，避免确定性归约时合成不存在的关联组合。
- 通过内部关联上下文减少新增标签后参数列表扩张和字段传错风险。

**Non-Goals:**

- 不验证企业 ID 的真实性，不把它解释为 tenant、principal 或企业权限边界。
- 不按企业聚合 Task 或文件状态，不改变 `file_key`、授权、路径、grant、session ownership、重试、指标或结果。
- 不向任务查询、摘要、SSE、WebSocket 或 CLI 暴露新的标签输入或输出。
- 不兼容、迁移或回填开发阶段七字段 schema v1 原始日志。
- 不增加 qtserver PostgreSQL migration、配置字段或第三方依赖。

## Decisions

### 1. 使用 enterprise_id / X-Enterprise-ID / X-QT-Log-Enterprise-ID

外部 JSON 与日志字段固定为 snake_case `enterprise_id`，qtransc 到 Qtserver 的公开请求 header 使用 `X-Enterprise-ID`，Qtserver 到 Nginx 的内部可信 handoff 使用已有命名族中的 `X-QT-Log-Enterprise-ID`。

这样既符合现有 JSON 风格，也能清楚区分客户端可提交的日志标签和只允许 Qtserver 构造的 Nginx 内部字段。备选 `enterpriseid` 与 `X-Task-Enterprise-ID` 会造成不一致或错误暗示企业 ID 是 task ID 的组成部分，因此不采用。

### 2. enterprise_id 完全继承 taskpid 的输入边界

qtransc 在 `TaskCreateRequest` 解码时拒绝显式 `null` 和其他非 string 类型，在验证时仅 trim 首尾 ASCII SP/HTAB，再对归一化值执行 128 bytes、UTF-8 与 HTTP field-value 校验。内部空白保留，空值合法。实现应提取可复用的辅助标签归一化/校验函数，使 `taskpid` 与 `enterprise_id` 使用同一规则和错误类别，但错误消息仍指出具体字段。

Qtserver 不为新 header 增加影响请求成功的新校验；非 qtransc 客户端提交的值仍只受 HTTP server 自身 header 限制，并在结构化日志和 JSON event 中安全转义。这与现有 `taskpid` 信任边界一致，避免新增标签改变传输 API 行为。

### 3. 用关联上下文聚合 task_id 与两个标签

跨函数或模块同时传递三项值时使用内部 correlation value object，语义上包含：

```go
type TaskCorrelation struct {
    TaskID       string
    TaskPID      string
    EnterpriseID string
}
```

具体包名可服从现有模块边界，但 qtransc HTTP client、Qtserver event constructor 和 handler 日志上下文不应继续通过多个相邻 string 参数扩展 `...taskID, taskPID, enterpriseID...`。命名字段可以降低编译器无法发现的参数错位风险，也为 header 设置和空值规则提供单一入口。

qtransc task/domain 接口增加企业标签读取能力，upload/download task 保存不可导出的 `EnterpriseID`。当前有效 task ID 仍按现有本地 `TaskID`/ServerTaskID 规则选择，关联上下文只携带选择结果，不参与选择。CLI 任务构造空标签。

### 4. canonical upload 固定完整初始关联上下文

canonical upload session 的持久模型增加 `enterprise_id`，init 时一次性保存初始 `(task_id, taskpid, enterprise_id)`。chunk、verify、complete 和 already-present 等后续事件全部从 session 读取整组值；当前请求 header 只进入请求运行日志，不能覆盖 session。

旧开发 session JSON 缺少新字段时 Go 解码自然得到空字符串。由于标签不影响业务，这类 session 可以继续传输，但其后续原始事件企业标签保持为空；部署前可等待现有 session 完成或接受该日志缺口，不设计 session migration。

普通下载和 Small 路径没有持久 session，继续从当前请求构造文件日志上下文。qtransc task 自身不可变，保证同一正常任务的每个请求携带相同标签。

### 5. schema v1 原地扩展为严格八字段

Envelope 字段顺序和 JSON 名称固定为：

```text
schema_version, event_type, occurred_at,
task_id, taskpid, enterprise_id, file_key, payload
```

Qtserver event model、direct producer 和 Nginx `log_format` 都显式输出八项。空标签写 JSON 空字符串，不使用 `omitempty`。Decoder 继续拒绝缺字段和未知顶层字段，因此旧七字段 v1 行会进入 quarantine；不通过默认空值悄悄兼容旧开发日志。

不升级为 v2 的原因是当前协议尚未进入 release tag，新增 v2 只会制造未使用的兼容分支。代价是同一 version 的开发阶段格式发生变化，因此部署必须协调，且 proposal 将其标为 breaking。

### 6. Nginx 只信任九项 upstream handoff

Qtserver X-Accel 响应增加 `X-QT-Log-Enterprise-ID`，生成配置和仓库部署模板都显式隐藏该 header。Nginx `log_format ... escape=json` 从 `$upstream_http_x_qt_log_enterprise_id` 输出 `enterprise_id`，不得读取客户端 `$http_x_enterprise_id` 构造业务事件。

handoff 有效性 map 继续只验证 task、file、chunk、Range、status 和 bytes 七项必要结构；两个辅助标签都允许为空，不进入有效性判定。这样旧 qtransc 缺少 `X-Enterprise-ID` 时仍能传输并生成合法八字段事件。

### 7. 最终标签从同一事件整体选取

普通文件选择最早合法 `file.registered`，Small 文件选择形成当前结果的 `download.small_file_sent`。`taskpid` 与 `enterprise_id` 必须从这条事件一起复制。若最早 `occurred_at` 并列、业务内容相同而辅助标签不同，则比较 `(taskpid, enterprise_id)` 的 UTF-8 bytes tuple 并选择对应的整条事件。

不分别对两个字段取最小值，因为那可能合成原始历史中不存在的标签组合。标签差异不构成注册冲突，也不改变状态或指标；inspect 只需要解释采用来源和未采用证据。

### 8. 结构化运行日志按 task ID 共现两个标签

qtransc task logger、task manager、scheduler、handler 和 CLI compatibility 路径在包含 `taskid`/`task_id` 时统一附加 `taskpid` 与 `enterprise_id`。Qtserver request logger 从当前外部 header 记录两项值，而业务事件可按 session 使用初始值；两种日志用途不得混淆。

标签继续从所有普通 API 响应和实时事件中隐藏。它们用于跨系统日志查询，不是客户端查询 task 的业务数据。

### 9. 分析存储增加独立 non-null 列

正式 consumer 的原始表应在 `task_id` 后增加 non-null string `enterprise_id`，最终表增加 non-null text `enterprise_id`，并按 24 字段契约 UPSERT。企业标签需要可直接检索，不能只保存在 payload JSON。

## Risks / Trade-offs

- [同一 schema version 存在两种开发阶段字段集合] → 明确拒绝七字段旧行，不提供隐式默认值；部署时暂停相关传输并协调 producer、Nginx 与 consumer，避免混合窗口。
- [新增 string 参数导致 taskpid 与 enterprise_id 传反] → 在跨边界调用使用带命名字段的 correlation value object，header 与 event 构造集中处理。
- [客户端把 enterprise_id 当作权限或企业隔离标识] → Spec、API 文档和代码命名均明确其为不可信日志标签，禁止进入授权、principal、file key 和 session ownership。
- [标签包含特殊字符污染日志或 Nginx JSON] → qtransc 做 header-safe 校验；Qtserver 使用结构化 JSON 编码；Nginx 使用 `escape=json` 且只读取 upstream handoff。
- [遗漏某个请求或日志调用点导致标签不共现] → 实现任务按 qtransc task、HTTP client、Qtserver middleware/handler/session、direct event 和 Nginx 分层清点，并用 `rg` 做全仓残留审计；编译两个 Go module捕获接口遗漏。
- [旧 active upload session 没有 enterprise_id] → 缺字段按空字符串读取且不影响业务；不允许后续请求覆盖，接受开发升级窗口内的日志标签缺口。
## Migration Plan

1. 在开发分支完成 qtransc、Qtserver、Nginx 配置和正式 consumer 的同批变更，并同步全部文档；不导入旧七字段 fixture 或日志。
2. 部署环境如存在活动 canonical upload session，优先等待完成；无法等待时允许其企业标签继续为空，不改变传输结果。
3. 暂停会产生业务事件的流量，先安装能输出八字段事件的 Nginx 配置，再部署 Qtserver 和正式 consumer，最后部署 qtransc 并恢复流量。不得在旧 Nginx 仍输出七字段事件时启用新 consumer。
4. consumer 的 ClickHouse/PostgreSQL 业务日志表按所属平台流程增加 non-null `enterprise_id` 列并以空字符串作为无值表示；这不是 qtserver PostgreSQL migration。
5. 回滚必须把 qtransc、Qtserver、Nginx 和 consumer 作为一个协议单元一起回滚。升级或回滚混合窗口产生的结构不匹配事件进入 quarantine，不做字段猜测或历史重写。
