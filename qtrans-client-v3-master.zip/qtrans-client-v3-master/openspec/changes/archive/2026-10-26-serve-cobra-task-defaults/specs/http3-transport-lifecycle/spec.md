## MODIFIED Requirements

### Requirement: HTTP/3 实际连接数受硬上限约束

qtransc SHALL 将现有连接数量配置解释为每轮任务、每个 origin 的实际存活 QUIC 连接硬上限；前台命令和 serve SHALL 使用 `--connections`；serve 的历史配置文件键 `quic.transports` SHALL 继续作为该设置的文件来源。连接名额 SHALL 从一次底层 QUIC Dial 开始占用，Dial 失败或连接 Context 结束后 SHALL 恰好释放一次。连接处于 ready、draining 或仍承载既有 stream 时 SHALL 继续占用名额。

qtransc SHALL NOT 为 GOAWAY 替换、重试或其他内部恢复临时建立超过该上限的 QUIC 连接。连接数按需增长且 MAY 低于上限；本要求不要求预建或始终维持固定数量。

#### Scenario: 单连接收到 GOAWAY 且仍有活跃 stream

- **GIVEN** 某 origin 的连接上限为 1，唯一 QUIC 连接仍有活跃 stream
- **WHEN** 该连接收到 GOAWAY 且新请求需要替代连接
- **THEN** qtransc SHALL 等待旧连接关闭并释放名额后再开始替代连接 Dial
- **AND** 任意时刻该任务该 origin 的实际存活 QUIC 连接数 SHALL NOT 超过 1

#### Scenario: Dial 失败释放名额

- **WHEN** HTTP/3 Dial 在返回可用 QUIC 连接前失败
- **THEN** qtransc SHALL 释放该次 Dial 占用的连接名额和底层网络资源
- **AND** 后续请求 SHALL 能够在连接上限内再次 Dial

#### Scenario: 连接池关闭

- **WHEN** qtransc 关闭 HTTP/3 连接池
- **THEN** qtransc SHALL 关闭 ready 与 draining 连接并释放对应连接名额、UDP 资源和等待中的 Dial

### Requirement: 单条 QUIC 连接的活跃 stream 数受硬上限约束

qtransc SHALL 将现有 stream 数量配置解释为单条实际 QUIC 连接的活跃 HTTP 请求 stream 硬上限；前台命令和 serve SHALL 使用 `--streams`；serve 的历史配置文件键 `quic.streamsPerTransport` SHALL 继续作为该设置的文件来源。一个请求从获得传输 Lease 到 RoundTrip 失败，或 Response Body 到达 EOF/被关闭期间 SHALL 占用一个 stream 名额。

连接替换与协议层重试 SHALL NOT 绕过或额外扩张该上限。draining 连接 SHALL NOT 接收新 stream，其已有 stream MAY 继续完成。

#### Scenario: 并发请求达到 stream 上限

- **GIVEN** 某条 QUIC 连接的 stream 上限为 4 且已有 4 个活跃请求
- **WHEN** 第 5 个请求申请同一连接的传输资源
- **THEN** qtransc SHALL 等待 stream 名额或选择连接上限内的其他可用连接
- **AND** 该 QUIC 连接的活跃 stream 数 SHALL NOT 超过 4

#### Scenario: GOAWAY 不接收新 stream

- **WHEN** QUIC 连接对应的 HTTP/3 会话已收到 GOAWAY
- **THEN** qtransc SHALL NOT 在该连接上创建 GOAWAY 禁止的新 request stream
- **AND** 已被服务端接受的既有 stream SHALL 继续按正常响应、取消或超时语义结束
