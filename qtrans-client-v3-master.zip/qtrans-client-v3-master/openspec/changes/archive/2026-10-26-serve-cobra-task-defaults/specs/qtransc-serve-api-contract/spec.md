## MODIFIED Requirements

### Requirement: 并发改造保持任务接口兼容

连接池容量和普通文件并发 SHALL 从 serve 启动配置取得，本次变更的创建任务请求 SHALL NOT 新增 C、S、F 或 P 参数。任务详情 fileConcurrency SHALL 继续表示普通文件并发上限，上传和下载均 SHALL 使用 serve 的 `--transfers` 设置，内置默认值为 5。任务省略 transport 或传入空值时 SHALL 使用 serve 的默认 transport；显式合法值 SHALL 覆盖默认协议。HTTP 和 SSE 的字段、状态枚举及错误结构 SHALL 保持现有契约；取消 P SHALL 不要求调用方迁移请求格式。

#### Scenario: 调用方继续使用已有请求

- **WHEN** 调用方以现有合法请求创建任务并订阅 SSE
- **THEN** 请求 SHALL 继续被接受，响应及事件 SHALL 保持既有结构
- **AND** 普通分片操作 SHALL 按任务共享额度并行执行
