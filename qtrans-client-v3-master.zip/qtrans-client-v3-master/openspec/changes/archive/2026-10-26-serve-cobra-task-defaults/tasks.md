# Tasks

## 1. 统一命令入口

- [x] 1.1 serve 改用 Cobra，配置模块接收已解析参数，删除旧参数并统一默认值；审查没有独立参数解析或 os.Args 重写，并更新 CLI 文档。

## 2. 应用任务默认值

- [x] 2.1 TaskManager 保存传输默认值，在请求校验前应用默认协议，入队前设置文件并发；审查显式协议、HTTP/1.1 和重启路径，更新 API 文档及本变更设计说明。

## 3. 集成检查

- [x] 3.1 完成必要 Go 编译、gofmt、差异格式及 OpenSpec 严格校验；不编写或运行测试、benchmark，并记录验证边界。

## 验证记录

- `go build ./qtransc/...` 和 qtransc 的 `make dev` 编译成功，已生成 `bin/qtransc-dev`。
- 修改的 Go 文件已通过 gofmt，`git diff --check` 和本 change 的 OpenSpec 严格校验通过。
- 静态审查确认：共享参数由 Cobra 继承；显式参数优先于 engine.toml；请求校验前填入默认协议；上传、下载在入队前设置 F；HTTP/1.1 使用 S=1；重启继续使用任务自身配置快照。
- 未编写或运行测试、benchmark，未验证实际传输行为。CLI/API 文档修改仍需人工审核。
