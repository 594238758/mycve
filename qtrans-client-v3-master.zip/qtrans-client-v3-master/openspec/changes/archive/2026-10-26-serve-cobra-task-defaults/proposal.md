# Proposal

## Why

serve 绕过 Cobra 自行解析参数，导致同一传输设置存在两套名称和默认值。用户要求统一参数解析及任务默认设置，为后续 API 按任务覆盖做好基础。

## What Changes

- serve 使用 Cobra 的正常参数、帮助和错误处理；四个传输参数直接继承根命令。
- **BREAKING** 删除 `--transports`、`--streamspertransport`，分别迁移为 `--connections`、`--streams`。已有 engine.toml 的 `quic.transports`、`quic.streamspertransport` 配置键继续有效，仅作为新参数的文件配置来源。
- 统一内置默认：transport=https3、connections=10、streams=1、transfers=5。显式命令行配置优先于配置文件，未配置时使用 Cobra 默认值。
- serve 任务使用启动时的配置快照；现有 transport 字段显式值保持有效，省略或空值使用服务默认协议。普通文件并发统一来自 transfers，上传默认由 2 改为 5。
- 本次不增加 API 的 connections、streams、fileConcurrency 字段，不调整重试、连接池生命周期或小文件流程。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `versioned-https-transports`: 统一 CLI 参数默认值及 serve 协议继承。
- `http3-transport-lifecycle`: 更新连接和流参数入口名称。
- `qtransc-serve-api-contract`: 任务采用服务默认协议和文件并发，保持请求结构。

## Impact

修改 root/serve 命令、配置加载、任务管理器和默认值填充。用户本轮已明确批准该范围并要求实施。先前并发改造已经单独提交；本次作为后续变更保留。只做编译与静态检查，不新增或运行测试、benchmark。
