# Design

## Context

参见 [proposal.md](proposal.md) 的 Why。当前 `serve` handler 直接序列化传输任务内部 view，JSON tag 与 CLI 快照共用；HTTP 错误由 handler、鉴权中间件、Gin 默认路由和 recovery 分散生成。SSE 则直接序列化内部 `TaskEvent`，文件失败事件没有携带可分类 cause。任务管理器会在入队前登记任务并发布 pending/created，worker pool 又在发送到 channel 后才包装完成回调，存在失败残留和容量槽竞态。

## Goals / Non-Goals

**Goals:**

- 在独立 serve wire 边界实现新协议，内部传输模型仍可保留字符串原因码和现有字段。
- 所有可生成的 HTTP JSON 经过同一响应构造路径，所有 SSE 经过同一事件转换路径。
- 错误分类依赖 typed/sentinel error 和结构化下游错误，不匹配对外或底层 message 文本。
- 任务只有在调度器接受后才对外表现为已创建，容量计数在并发完成时准确释放。

**Non-Goals:**

- 不重构传输算法、进度统计、认证流程或 Qtserver API client。
- 不改变 CLI、upload2/download2 WebSocket、Qtserver wire DTO 或业务日志 schema。
- 不为 REST 任务快照补充历史数字失败码，也不提供 snake_case 兼容模式。
- 不在本变更中重排 `qtransc-apis.md` 的整体章节结构。

## Decisions

### 1. 使用独立 `internal/serveapi` wire 层

新增 `qtransc/internal/serveapi`，集中定义：

- HTTP `Response`、成功/失败构造器，以及遵循错误码规范注册表的数字码/default message/`meta` 实现登记；
- 仅供 `serve` 使用的 camelCase request/response DTO 与内部 `types` 之间的转换；
- SSE `Envelope`、messageType 映射和内部事件到 wire data 的转换；
- 通用执行错误到数字码的分类。

内部 task/file view 继续保留 CLI 所需字段和字符串原因码，wire converter 删除原因码并把外发 `error`/`message` 归一化为码表文案。这样不会通过批量改 JSON tag 意外改变 CLI、Qtserver 或旧 WebSocket。

备选方案是直接修改 `internal/types` 的 JSON tag 并删除字段；该方案改动较少，但共用类型的未来调用方容易被隐式破坏，也无法在不改变 CLI 文案的情况下安全化 REST 错误，因此不采用。

### 2. 严格解码只发生在 serve HTTP 边界

创建任务和 token 更新使用 wire request DTO，通过单一 decoder 完成以下检查：顶层首个非空白字符必须为 `{`、`DisallowUnknownFields`、一次 `Decode` 后必须立即得到 EOF。所有公开请求字段只接受 lowerCamelCase；wire `taskPid` 转换到既有内部 `TaskPID`，内部日志键和非 serve 协议不随之改名。

不全局开启 Gin binding 选项，因为它可能影响仓库内其他 JSON 边界；也不复用当前带 snake_case tag 的内部 request 作为 wire schema。

### 3. 数字码分类分为通用执行错误和控制面错误

`serveapi` 根据现有 `clienterror.Error`、Qtserver 结构化错误、认证错误、传输限制及本地 I/O typed error，按照 `qtransc/docs/qtransc-error-codes.md` 的研发触发条件映射执行类错误。task manager 和 scheduler 新增可用 `errors.Is/As` 判断的 sentinel/typed error；handler 先识别任务不存在、状态冲突、重复和容量错误，再调用通用分类器。未分类错误映射到规范注册表指定的内部兜底条目。

分类器只返回规范注册表登记的 code；Go 实现登记为每个 code 保存与规范注册表一致的安全英文 message、`retryable` 和 `visible`。HTTP 与 SSE 的失败构造器共同查询该实现登记；成功省略 `meta`，失败必须输出两个显式布尔字段。输入为成功码或未登记码时，构造器统一归一为规范注册表指定的内部兜底条目，避免出现未知 code 配合其他 message 和元数据。handler 和事件发布路径把完整 cause 交给现有结构化日志，wire 不拼接 `err.Error()`。禁止以底层 message 子串作为新增 API 分类依据；仍存在的旧内部字符串启发式只服务 CLI，不作为 serve 判定。

具体码值、元数据、出现位置/任务终态和分类边界不在 design 中复制，以规范注册表为准。实现映射只负责把 typed/sentinel error、结构化 HTTP 状态与结构化 reason 映射到注册表条目，并确保 HTTP 与 SSE 只在该条目允许的位置输出；当分类边界或出现位置变化时，先修改并批准规范注册表，再同步本 design 与分类器。

### 4. 路由与中间件不允许绕过统一响应

Gin 关闭 trailing-slash/fixed-path 自动重定向并启用 method-not-allowed 处理。`NoRoute`、`NoMethod` 和自定义 recovery 使用 `serveapi.Response`；recovery 仅在 response 尚未提交时写 HTTP `200` 和规范注册表指定的内部兜底错误，已经提交时只记录并终止连接。

控制面鉴权放到已注册的受保护路由组，而非全局 middleware：健康接口保持公开，已知受保护路由鉴权失败返回规范注册表的访问拒绝条目，未知 route/method 不会先被误报为鉴权失败。CORS 仍为全局最外层并在 `OPTIONS` 时直接返回 `204`。

### 5. SSE 内部事件携带 cause，wire 统一转换

内部 `TaskEvent` 继续作为事件总线载体，但增加不参与 JSON 的 error cause。任务状态转换把当前 task error 放入事件；文件失败发布函数接收并保存本次失败 error。`writeSSEEvent` 不再直接 marshal 内部事件，而是调用 `serveapi` 转换：

- messageType 从七个内部 event kind 映射到 `qtrans.*`；
- 只有任务 `failed` 或文件 `failed` 事件才把 cause 交给同一分类器生成 code，并由遵循规范注册表的统一实现登记生成 message/meta；其他状态事件即使内部保留 cause，也使用 `0/Success` 并省略 meta；
- data 使用专用 camelCase DTO，任务状态 data 不再携带 error/reason；
- 任务状态事件直接输出内部五态 `pending/running/completed/stopped/failed`，不再转换为 `created/started/paused`；
- 内部删除标记转换为独立的 `qtrans.task.deleted`，data 只携带 `taskId`，不把 `deleted` 混入任务状态枚举；
- heartbeat timestamp 保留现有 RFC3339 字符串。

这样 HTTP 与 SSE 共享同一份规范注册表的实现，同时内部事件仍可供进程内代码读取。

### 6. 调度接受使用显式门控并先安装完成回调

worker pool 在 work item 进入 channel 前安装容量槽释放回调，避免 worker 立即完成时漏释放。work item 增加接受门控：worker 取到 item 后必须等待 manager 完成任务登记、状态提交和 created 事件发布，再开始执行。

创建流程为：构造任务与 work item → 尝试入队 → 入队失败则取消 item、清理任务资源且不保留 map entry → 入队成功后提交任务登记并发布 created → 打开执行门控。重启流程在入队失败时恢复原状态和错误，不能留下未排队的 pending 任务。已打开门控后即视为接受成功，即使 HTTP 响应丢失也保留任务，后续同 ID 创建返回规范注册表的任务已存在条目。

备选方案是仅在 `Submit` 失败后删除 map entry；它无法防止 created/started 乱序，也不能正确恢复重启任务状态，因此不采用。

### 7. 错误码注册表独立且稳定维护

QTrans 五位码表从 `qtransc-apis.md` 拆到 `qtransc/docs/qtransc-error-codes.md`。独立注册表包含 code、固定 message、retryable、visible、出现位置/任务终态和研发触发条件，不再包含“调用方处置”；`qtransc-apis.md` 只保留信封说明、HTTP/SSE 观察差异、代表性示例和注册链接，避免两份码表漂移。

该注册表是错误码唯一规范源并加入长期维护清单。码值、message、meta、出现位置/任务终态或研发触发条件变化必须先修改该注册表并由维护者审核批准，再同步 OpenSpec 与代码；OpenSpec 只约束信封、分类机制和位置语义，不复制完整码表，也不能覆盖注册表。普通 API 文档整理不得顺带改动注册表。

## Risks / Trade-offs

- [调用方错过失败 SSE 后无法恢复数字码] → 这是已接受契约；REST 快照只保留任务终态和安全文案，Agent 必须保证事件转发可靠或接受信息降级。文件 `failed` / 任务 `stopped` 类型的错误同样不会由后续 HTTP 查询补发。
- [全部 HTTP 200 降低基于 status 的监控可见性] → access log 同时记录业务 code；健康判断继续依赖周期 health/SSE，而不是单次业务 status。
- [wire DTO 与内部 view 字段漂移] → 转换集中在 `serveapi`，文档和编译检查核对所有 9 个接口；不使用反射自动转换。
- [任务接受流程改动引入死锁或事件乱序] → 门控只允许单向关闭，取消路径始终释放 worker slot；manager 不在等待 worker 完成时持有互斥锁。
- [响应已提交后 panic 无法改写为 JSON] → 按传输层失败处理并记录 stack，规范明确不承诺第二次写响应。
- [三方不同步发布导致完全不兼容] → qtransc 与 Agent 使用同一发布窗口；不提供长期双格式，失败时整体回滚。
- [任务状态枚举切换破坏旧 Agent] → Agent 在同一发布窗口将 `created/started/paused` 切换为 `pending/running/stopped`，并单独处理 `qtrans.task.deleted`。
- [`taskpid` 改名破坏旧 Agent 请求] → Agent 在同一发布窗口切换为 `taskPid`；严格解码明确拒绝旧字段，避免两套 wire schema 长期共存。
- [处置元数据被错误扩散] → `retryable` 和 `visible` 只从遵循规范注册表的集中实现登记生成；调用方不得从 message 或 code 范围自行推断。
- [当前所有错误文案均允许直接展示] → 当前规范注册表将所有登记项设为可展示；固定 message 虽已安全化但仍为英文。后续发现某一码不适合展示时，必须先逐码评审并修改规范注册表，不能由 handler 临时覆盖。

## Migration Plan

1. 建立并批准独立错误码规范注册表，再使本 OpenSpec change 遵循该注册表。
2. 实现 wire DTO、注册表对应的编译期登记、严格 decoder、路由响应、SSE 转换与调度接受边界。
3. 仅执行 qtransc `go build ./...` 编译验证，不新增或运行测试。
4. 最小化同步 `qtransc-apis.md` 的信封说明和注册链接，并由维护者人工审核两份对外文档。
5. 与 Agent 在同一发布窗口切换；若联调失败，双方整体回滚到旧版本。
