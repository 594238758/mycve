# Proposal

## Why

qtransc `serve` 当前同时依赖 HTTP status、旧数值码、字符串 `reason_code` 和自由文本判断失败，REST 与 SSE 又使用不同的字段命名和事件信封，导致 Agent 无法只按一个稳定字段处理结果。需要一次性切换为 QTrans 自治的五位码、统一驼峰字段和固定 SSE 信封，并消除框架自动错误响应造成的协议旁路。

## What Changes

- **BREAKING**：qtransc `serve` 的 9 个 JSON 接口全部改为成功 `code=0`、失败 `code=3xxxx`；只要 qtransc 能生成统一 JSON，HTTP status 一律为 `200`。
- **BREAKING**：HTTP 请求体和响应业务字段一次性切换为 lowerCamelCase；日志关联字段使用 `taskPid`，`transfering_files` 修正为 `transferringFiles`，不提供旧字段兼容期。
- **BREAKING**：serve HTTP、任务摘要/详情和 SSE 不再输出 `reason_code`/`reasonCode`；REST 失败快照不新增替代失败码。
- **BREAKING**：SSE 事件统一为 `{messageType, code, message, data, meta?}`，事件名切换为 `qtrans.*` 点分词汇，`transfered` 修正为 `transferred`。
- **BREAKING**：`qtrans.task.status.data.status` 与 HTTP 任务快照统一使用 `pending`、`running`、`completed`、`stopped`、`failed`；任务删除改为不携带 `status` 的 `qtrans.task.deleted` 事件。
- JSON 请求采用严格解析，拒绝未知字段、旧 snake_case、错误类型、非对象和一个对象后的额外 JSON 值。
- 新增 QTrans 五位错误码规范注册表；码值、默认 message、`retryable`、`visible`、出现位置/任务终态和研发触发条件均以该注册表为准，OpenSpec 与代码不得另行定义一份码表。外发文案不拼接底层错误、绝对路径或敏感凭据。
- HTTP 与 SSE 的每个失败信封都随码携带注册表规定的 `meta{retryable,visible}`；成功信封省略 `meta`。
- 未知路由、方法错误、控制面鉴权失败和响应尚未提交时的 panic 也返回统一 JSON；CORS `OPTIONS` 仍返回 `204`。
- 任务创建的注册、入队和 created 事件形成一致的接受边界；入队失败不留下孤立任务，调度容量槽释放不再存在回调安装竞态。
- 将 `qtransc/docs/qtransc-error-codes.md` 确立为稳定的错误码规范和唯一权威源，综合 API 文档只说明信封和链接到该注册表；错误码变更先修订并批准注册表，再同步 OpenSpec 与代码，整体 API 文档结构重写不在本变更范围。

## Capabilities

### New Capabilities

- `qtransc-serve-api-contract`: 定义 qtransc `serve` 的 HTTP 路由、JSON 信封、字段命名、严格请求解析、错误码规范引用、SSE 信封及兼容边界。

### Modified Capabilities

- `client-error-contract`: 用数字 `3xxxx` 和安全英文文案替换 serve 的字符串 `reason_code` 契约，同时保持 CLI 错误契约不变。
- `client-transfer-progress`: REST 与 SSE 的进度字段改为 lowerCamelCase，SSE 事件切换为统一信封；旧 WebSocket 进度协议继续保持不变。

## Impact

- 影响 qtransc `serve` 的全部 HTTP/SSE 调用方，Agent 必须与 qtransc 在同一发布窗口切换；旧客户端不能继续发送 snake_case 或 `taskpid` 请求字段、解析旧 SSE，或依赖 `created`、`started`、`paused`、`deleted` 任务状态值。
- 主要影响路由和中间件、HTTP handler、serve wire DTO、错误分类、任务管理与 worker pool 接受流程、事件发布、`qtransc/docs/qtransc-apis.md` 和独立错误码注册表。
- 不改变 qtransc CLI、qtransc 到 Qtserver 的 JSON 协议、upload2/download2 旧 WebSocket 帧、任务内部进度事实、数据库结构或业务日志 schema。
- 发布采用三方协同的一次性切换；回滚时 qtransc 与 Agent 必须一起回退，不长期维护新旧两套 serve wire 格式。
