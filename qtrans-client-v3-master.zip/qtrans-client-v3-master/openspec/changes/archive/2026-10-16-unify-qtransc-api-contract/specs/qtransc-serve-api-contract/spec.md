# Spec Delta

## Purpose

定义 qtransc `serve` 对 Agent 暴露的 HTTP 与 SSE 线协议，使调用方能够仅依据统一数字码和固定信封判断结果，并明确一次性字段迁移、安全文案及旧协议兼容边界。

## ADDED Requirements

### Requirement: serve 路由集合保持稳定

qtransc `serve` SHALL 继续暴露 token 更新、健康检查、任务创建、删除、详情、摘要、启动、暂停和列表共 9 个 JSON 接口，以及一个 SSE 事件接口；现有 HTTP method 与 path SHALL 保持不变。

#### Scenario: 调用既有详情接口

- **WHEN** 调用方请求 `GET /api/v1/tasks/:task_id/detail`
- **THEN** qtransc SHALL 继续按该 method 与 path 提供任务详情

#### Scenario: 订阅既有事件接口

- **WHEN** 调用方请求 `GET /api/v1/events`
- **THEN** qtransc SHALL 建立 SSE 事件流

### Requirement: JSON 业务响应使用统一信封和 HTTP 200

qtransc 能生成 JSON 业务响应时 SHALL 使用 `{code,message,data?,meta?}`；成功 SHALL 为 `code=0`、`message="Success"` 且省略 `meta`，失败 SHALL 为 `3xxxx`、非空安全英文文案和必填 `meta{retryable,visible}`。`meta.retryable` 与 `meta.visible` 均 SHALL 为显式布尔值，即使为 `false` 也不得省略。无载荷时 SHALL 省略 `data`，不得输出 `null` 或空对象；空列表 SHALL 输出 `data:[]`。上述 JSON 响应的 HTTP status SHALL 为 `200`。

#### Scenario: 无载荷成功

- **WHEN** token 更新、任务启动、暂停或删除成功
- **THEN** HTTP status SHALL 为 `200`
- **AND** body SHALL 为 `code=0`、`message="Success"` 且不含 `data` 或 `meta`

#### Scenario: 业务失败

- **WHEN** 请求可由 qtransc 处理但业务结果失败
- **THEN** HTTP status SHALL 为 `200`
- **AND** body SHALL 包含一个 `3xxxx` code 和对应稳定 message
- **AND** body SHALL 包含该 code 对应的 `meta.retryable` 与 `meta.visible`
- **AND** body SHALL NOT 包含 `data`

#### Scenario: 空任务列表

- **WHEN** 当前没有任务且调用方请求任务列表
- **THEN** 响应 SHALL 为 `code=0`、`message="Success"` 和 `data:[]`

### Requirement: 协议旁路错误使用统一 JSON

控制面鉴权失败、未知路由、错误 HTTP method 以及响应尚未提交时恢复的 panic SHALL 使用统一 JSON 信封和 HTTP `200`。CORS `OPTIONS` SHALL 继续返回 `204`；HTTP 解析失败、连接中断、无响应和响应提交后的中断 SHALL 作为传输层失败，不要求生成 JSON。

#### Scenario: 控制面密钥错误

- **WHEN** 受保护接口收到缺失或不匹配的 server secret
- **THEN** qtransc SHALL 返回 HTTP `200`
- **AND** body SHALL 使用规范注册表中“访问拒绝”条目的完整 code、message 和 meta

#### Scenario: 未知路由

- **WHEN** 请求没有匹配的公开路由或 method
- **THEN** qtransc SHALL 返回 HTTP `200`
- **AND** body SHALL 使用规范注册表中“请求无效”条目的完整 code、message 和 meta

#### Scenario: CORS 预检

- **WHEN** 请求 method 为 `OPTIONS`
- **THEN** qtransc SHALL 返回 HTTP `204`
- **AND** SHALL NOT 输出 JSON 业务信封

#### Scenario: 响应提交前 panic

- **WHEN** handler 在写入响应前发生 panic
- **THEN** qtransc SHALL 返回 HTTP `200`
- **AND** body SHALL 使用规范注册表指定的未分类内部错误条目

### Requirement: HTTP JSON 字段使用严格 lowerCamelCase

serve 的 HTTP 请求体与响应字段 SHALL 全部使用 lowerCamelCase。日志关联字段 SHALL 使用 `taskPid`，`transfering_files` SHALL 修正为 `transferringFiles`。JSON body SHALL 恰好包含一个符合目标 schema 的对象；未知字段、旧 snake_case、旧 `taskpid`、错误类型、`null` 顶层值和第二个 JSON 值 SHALL 使用规范注册表的“请求无效”条目拒绝。

#### Scenario: 驼峰创建请求

- **WHEN** 创建请求使用 `taskId`、`taskPid`、`enterpriseId`、`callerVersion`、`serverAddr`、`fileList` 等 lowerCamelCase 字段并满足校验规则
- **THEN** qtransc SHALL 按该请求创建任务

#### Scenario: 旧 taskpid 字段被拒绝

- **WHEN** 创建请求携带旧字段 `taskpid`
- **THEN** qtransc SHALL 返回规范注册表的“请求无效”条目

#### Scenario: 旧字段被拒绝

- **WHEN** 创建请求携带 `task_id`、`server_addr`、`file_list` 或其他旧 snake_case 字段
- **THEN** qtransc SHALL 返回规范注册表的“请求无效”条目

#### Scenario: 多个 JSON 值

- **WHEN** body 在合法请求对象后还包含第二个 JSON 值
- **THEN** qtransc SHALL 返回规范注册表的“请求无效”条目

### Requirement: serve wire 不输出字符串原因码

serve 的 HTTP 信封、任务 summary/detail、文件视图和 SSE 事件 SHALL NOT 输出 `reason_code` 或 `reasonCode`。成功查询失败任务时，外层 code SHALL 仍为 `0`，任务数据 MAY 保留安全化 `error` 文案，但 SHALL NOT 新增 `failureCode` 或其他历史数字失败码。

#### Scenario: 查询失败任务

- **WHEN** 调用方成功查询一个 `status="failed"` 的任务
- **THEN** 外层响应 SHALL 为 `code=0`
- **AND** task data SHALL NOT 包含 `reasonCode` 或 `failureCode`

#### Scenario: 查询失败文件

- **WHEN** 任务详情包含一个失败文件
- **THEN** file data SHALL NOT 包含 `reasonCode` 或其他字符串机器原因码

### Requirement: 错误码遵循唯一规范注册表

`qtransc/docs/qtransc-error-codes.md` SHALL 是 qtransc `serve` 五位错误码的唯一规范源。code、默认 message、`retryable`、`visible`、出现位置/任务终态、研发触发条件和未登记错误的归一规则 SHALL 以该注册表为准；本 OpenSpec SHALL 只定义信封、分类机制和其他协议行为，不得维护第二份完整码表。OpenSpec 或代码与注册表冲突时 SHALL 修正 OpenSpec 或代码，调用方 SHALL NOT 解析 message 决定业务行为。

#### Scenario: 认证配置无效

- **WHEN** qtransc 识别出传输认证配置无效
- **THEN** SHALL 输出规范注册表中研发触发条件覆盖该情况的完整条目

#### Scenario: 任务容量耗尽

- **WHEN** qtransc 无法接受更多运行或排队任务
- **THEN** SHALL 输出规范注册表中研发触发条件覆盖该情况的完整条目

#### Scenario: 本地资源不存在

- **WHEN** qtransc 识别出本地源文件或目录不存在
- **THEN** SHALL 输出规范注册表中研发触发条件覆盖该情况的完整条目

#### Scenario: 未分类错误

- **WHEN** qtransc 无法把错误安全归入其他稳定语义
- **THEN** SHALL 输出规范注册表指定的未分类内部错误条目

### Requirement: 错误出现位置与任务终态遵循规范注册表

规范注册表 SHALL 为每个错误码登记允许的对外出现位置及适用的任务终态。标记为 `HTTP API` 的错误 SHALL 只作为同步 HTTP 失败响应出现；包含“任务 `failed`”的错误 MAY 在任务被接受后通过任务或文件失败 SSE 事件出现，并使任务终态为 `failed`；标记为“文件 `failed` / 任务 `stopped`”的错误 SHALL 由文件失败 SSE 事件携带，随后的任务 `stopped` SSE 事件 SHALL 保持 `code=0`；标记为“预留”的错误在当前实现中 SHALL NOT 输出。一个错误同时登记 `HTTP API` 和“任务 `failed`”时，表示它在请求处理和任务执行两个阶段都可能出现，而不是要求两个位置同时输出。

#### Scenario: HTTP API 专用错误

- **WHEN** 规范注册表把一个错误登记为仅 `HTTP API`
- **THEN** qtransc SHALL NOT 在任务或文件 SSE 失败事件中使用该错误码

#### Scenario: 文件失败后任务停止

- **WHEN** 规范注册表把一个错误登记为“文件 `failed` / 任务 `stopped`”
- **THEN** 文件失败 SSE 事件 SHALL 使用该错误码及其固定 message/meta
- **AND** 随后的任务状态 SSE SHALL 使用 `status="stopped"`、`code=0`、`message="Success"` 并省略 `meta`

#### Scenario: 预留错误码

- **WHEN** 一个错误码在规范注册表中登记为“预留”
- **THEN** 当前 qtransc `serve` 实现 SHALL NOT 在 HTTP 或 SSE 信封中输出该错误码

### Requirement: 失败处置元数据固定随码

每个 HTTP 或 SSE 失败信封 SHALL 携带 `meta.retryable` 与 `meta.visible`，其值 SHALL 与规范注册表对应条目完全一致。handler 和事件转换 SHALL NOT 临时覆盖登记值。

#### Scenario: 容量错误携带登记元数据

- **WHEN** qtransc 输出规范注册表中的任务容量错误
- **THEN** meta SHALL 与该条目的 `retryable` 和 `visible` 完全一致

#### Scenario: 不可自动重试的内部错误

- **WHEN** qtransc 输出规范注册表指定的未分类内部错误
- **THEN** meta SHALL 与该条目的 `retryable` 和 `visible` 完全一致

### Requirement: 重复任务 ID 始终冲突

同一 `serve` 进程中只要 `taskId` 对应任务尚未删除，再次创建 SHALL 返回规范注册表中的“任务已存在”条目，不得按请求内容推断幂等成功。任务已成功入队但响应丢失时，使用同一 `taskId` 重试也 SHALL 返回冲突。

#### Scenario: 完全相同的重复请求

- **WHEN** 调用方用一个尚未删除的 `taskId` 重发相同创建请求
- **THEN** qtransc SHALL 返回规范注册表中的“任务已存在”完整条目

#### Scenario: 入队前失败

- **WHEN** 任务因容量不足或入队失败而未被接受
- **THEN** qtransc SHALL NOT 保留该任务 ID
- **AND** 后续相同 `taskId` 请求 SHALL NOT 因前一次失败返回“任务已存在”条目

### Requirement: 未登记失败码归一为内部错误

HTTP 或 SSE 构造失败信封时，如果输入 code 为成功码、未登记值或登记范围之外的值，qtransc SHALL 将其归一为规范注册表指定的未分类内部错误完整条目，不得组合未知 code 与该条目的 message/meta。

#### Scenario: 未登记错误码

- **WHEN** 内部调用方尝试以未登记 code 构造失败信封
- **THEN** wire SHALL 输出规范注册表指定的未分类内部错误完整条目

### Requirement: SSE 使用统一结果信封

每条 SSE `data:` JSON SHALL 为 `{messageType,code,message,data,meta?}`，其中前四个字段均必填。正常事件 SHALL 使用 `code=0`、`message="Success"` 并省略 `meta`；带失败原因的任务或文件状态事件 SHALL 使用对应 `3xxxx` 并携带该 code 固定的 `meta{retryable,visible}`。事件 data SHALL 使用 lowerCamelCase，且 SHALL NOT 包含 `error`、`reasonCode` 或 `reason_code`。

#### Scenario: 任务失败事件

- **WHEN** 任务因本地资源不存在而进入失败状态
- **THEN** SSE SHALL 使用 `messageType="qtrans.task.status"`
- **AND** SHALL 使用规范注册表中“本地资源不存在”条目的完整 code、message 和 meta
- **AND** data SHALL 包含 `taskId` 和 `status="failed"`

#### Scenario: 查询失败任务不补发错误码

- **WHEN** 调用方通过 HTTP 查询一个已经 `failed` 或 `stopped` 的任务
- **THEN** HTTP 外层 SHALL 使用 `code=0`
- **AND** SHALL NOT 补发此前 SSE 失败事件中的五位错误码

#### Scenario: 正常文件进度

- **WHEN** qtransc 发布文件进度事件
- **THEN** SSE SHALL 使用 `messageType="qtrans.file.progress"`、`code=0`、`message="Success"`
- **AND** SSE SHALL NOT 包含 `meta`
- **AND** data SHALL 使用 `taskId`、`fileKey`、`total`、`transferred` 和 `rate`

#### Scenario: 心跳事件

- **WHEN** qtransc 建立 SSE 连接或心跳周期到期
- **THEN** SHALL 发布 `messageType="qtrans.heartbeat"`、`code=0`、`message="Success"`
- **AND** data.timestamp SHALL 继续使用 RFC3339 字符串

### Requirement: 综合 API 文档链接规范注册表

综合 `qtransc-apis.md` SHALL 只说明信封规则、HTTP 与 SSE 的观察差异并链接唯一规范源 `qtransc/docs/qtransc-error-codes.md`，不得复制完整码表。规范注册表 SHALL NOT 包含“调用方处置”列；任何码值、message、meta、出现位置/任务终态或研发触发条件变化 SHALL 先修订并批准规范注册表，再同步 OpenSpec 与代码。

#### Scenario: 调用方查找错误码

- **WHEN** 调用方从综合 API 文档查找 QTrans 错误码定义
- **THEN** 文档 SHALL 指向独立错误码注册表
- **AND** 综合 API 文档 SHALL NOT 维护第二份完整码表

### Requirement: SSE 事件类型使用 qtrans 点分词汇

SSE messageType SHALL 限定为 `qtrans.heartbeat`、`qtrans.task.status`、`qtrans.task.deleted`、`qtrans.file.status`、`qtrans.chunk.status`、`qtrans.task.progress`、`qtrans.file.progress` 和 `qtrans.chunk.progress`。旧 `heartbeat`、`task_status` 等值 SHALL 不再出现在 wire 中。

#### Scenario: 分片进度事件

- **WHEN** qtransc 发布分片进度
- **THEN** messageType SHALL 为 `qtrans.chunk.progress`
- **AND** data SHALL 使用 `chunkIndex` 和 `transferred`

### Requirement: SSE 与 HTTP 使用统一任务状态枚举

`qtrans.task.status.data.status` SHALL 与 HTTP 任务 summary/detail 的 `status` 使用同一组 `pending`、`running`、`completed`、`stopped`、`failed` 枚举。SSE SHALL NOT 使用 `created`、`started` 或 `paused` 作为任务状态。任务删除不是任务状态，SHALL 使用 `messageType="qtrans.task.deleted"`，其 data SHALL 只包含 `taskId`，不得包含 `status`。

#### Scenario: 新任务进入调度队列

- **WHEN** 一个新任务被调度器接受并处于 HTTP `status="pending"`
- **THEN** SSE SHALL 发布 `messageType="qtrans.task.status"`
- **AND** data.status SHALL 为 `pending`

#### Scenario: 任务开始运行

- **WHEN** 任务的 HTTP 状态变为 `running`
- **THEN** 对应 SSE task status SHALL 为 `running`
- **AND** SHALL NOT 为 `started`

#### Scenario: 任务被暂停

- **WHEN** 任务的 HTTP 状态变为 `stopped`
- **THEN** 对应 SSE task status SHALL 为 `stopped`
- **AND** SHALL NOT 为 `paused`

#### Scenario: 任务被删除

- **WHEN** 调用方成功删除任务
- **THEN** SSE SHALL 发布 `messageType="qtrans.task.deleted"`、`code=0`、`message="Success"`
- **AND** data SHALL 只包含 `taskId`

### Requirement: 非 serve 协议保持不变

本变更 SHALL NOT 改变 qtransc CLI 的错误格式、qtransc 与 Qtserver 的请求响应字段、upload2/download2 旧 WebSocket 帧或业务日志 schema。内部可以继续使用字符串原因码，但 SHALL NOT 将其泄露到 serve wire。

#### Scenario: 旧 WebSocket 查询进度

- **WHEN** upload2 或 download2 收到 `query-progress`
- **THEN** 响应字段、状态码和关闭语义 SHALL 与 `legacy-websocket-protocol` 保持一致

#### Scenario: Qtserver 结构化错误

- **WHEN** qtransc 内部解析 Qtserver 的 `reason_code`
- **THEN** SHALL 继续按 Qtserver 协议读取该字段
- **AND** SHALL NOT 因 serve wire 改造而要求 Qtserver 改名
