# Spec Delta

## MODIFIED Requirements

### Requirement: 所有观察接口读取同一实时内存事实

CLI 和 REST task summary/detail SHALL 在每次读取时直接使用当前内存 task/file progress 与 rate；upload2/download2 WebSocket SHALL 在每次 `query-progress` 时读取同一当前事实。上述读取频率只影响调用方看到快照的频率，SHALL NOT触发、缓存或延迟内部进度计算。数值类型和单位 SHALL 保持不变；serve REST 字段 SHALL 按 `qtransc-serve-api-contract` 一次性切换为 lowerCamelCase，serve SSE 任务状态 SHALL 与 REST 任务状态统一；正常进度 SSE SHALL 省略 `meta`，失败状态 SSE SHALL 携带 `qtransc/docs/qtransc-error-codes.md` 规范注册表中与数字码固定绑定的 `meta{retryable,visible}`。upload2/download2 WebSocket wire contract SHALL 保持不变。

#### Scenario: 高频 REST 轮询

- **WHEN** 调用方在一个未完成 chunk 内连续请求 task detail
- **THEN** 后续响应 SHALL 能观察到期间新增的 live payload bytes
- **AND** SHALL NOT必须等到 chunk 完成才变化
- **AND** 响应进度字段 SHALL 使用 `transferredBytes`、`totalSize`、`transferRate` 和 `transferringFiles`

#### Scenario: 兼容 WebSocket 查询

- **WHEN** upload2 或 download2 在传输中收到 `query-progress`
- **THEN** `transferred`、`progress_percent`、`rate` 与 `inprogressfiles` SHALL 由查询时当前内存事实生成
- **AND** JSON wire contract SHALL 保持不变
