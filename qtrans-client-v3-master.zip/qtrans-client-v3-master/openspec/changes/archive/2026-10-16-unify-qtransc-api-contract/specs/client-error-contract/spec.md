# Spec Delta

## ADDED Requirements

### Requirement: serve 控制面使用数字五位码

qtransc `serve` 的 HTTP 和 SSE SHALL 使用 `qtransc/docs/qtransc-error-codes.md` 规范注册表登记的数字 `3xxxx` 表达失败，并使用该注册表规定的固定安全英文 message。每个失败信封 SHALL 携带该 code 在注册表中绑定的 `meta{retryable,visible}`，成功信封 SHALL 省略 `meta`。serve wire SHALL NOT 输出 `reason_code` 或 `reasonCode`；内部字符串原因码 MAY 继续用于分类，但不得成为 Agent 的外部契约。

#### Scenario: serve HTTP 参数错误

- **WHEN** serve HTTP 路由因请求格式或字段无效而失败
- **THEN** 响应 SHALL 使用规范注册表中“请求无效”条目的完整 code、message 和 meta
- **AND** SHALL NOT 包含 `reason_code` 或 `reasonCode`

#### Scenario: serve 任务 failed 事件

- **WHEN** serve 管理的上传或下载任务因可分类错误进入 `failed`
- **THEN** `qtrans.task.status` SSE 事件 SHALL 使用对应数字 `3xxxx`
- **AND** SHALL 携带该 code 固定的 `meta.retryable` 与 `meta.visible`
- **AND** data SHALL NOT 包含字符串原因码或自由文本 error

#### Scenario: 文件失败但任务 stopped

- **WHEN** 规范注册表把某个任务执行错误的出现位置/任务终态登记为“文件 `failed` / 任务 `stopped`”
- **THEN** `qtrans.file.status` 失败 SSE 事件 SHALL 使用该错误对应的数字 `3xxxx` 和 meta
- **AND** 随后的 `qtrans.task.status` SHALL 使用 `status="stopped"`、`code=0` 和 `message="Success"`

#### Scenario: serve 任务失败快照

- **WHEN** 调用方成功查询一个已经失败的任务
- **THEN** 外层 HTTP 响应 SHALL 保持 `code=0`
- **AND** task data SHALL NOT 新增历史 `failureCode` 或保留 `reasonCode`
- **AND** 调用方错过当时的 SSE 失败事件后 SHALL NOT 从该快照恢复历史五位错误码

### Requirement: serve 改造不改变 CLI 错误契约

直接 CLI 的 stderr 和 JSON error object SHALL 继续遵守本 capability 已有字符串 `REASON_CODE` 与 `reason_code` 契约；Qtserver 结构化 JSON body 中的 `reason_code` SHALL 继续原样保留。serve 的数字码切换 SHALL NOT 改变 upload2/download2 旧 WebSocket 错误帧。

#### Scenario: CLI JSON 参数错误

- **WHEN** 带 `--json` 的直接命令因本地参数无效而失败
- **THEN** stdout SHALL 继续包含 `reason_code=CLI_INVALID_ARGUMENT`

#### Scenario: 旧 WebSocket 错误帧

- **WHEN** upload2 或 download2 旧 WebSocket 客户端收到错误帧
- **THEN** 帧字段和既有错误格式 SHALL 保持不变

## REMOVED Requirements

### Requirement: serve 控制面透出稳定 reason_code

**Reason**: serve 对 Agent 的机器判断字段统一为数字 `3xxxx`，继续输出字符串原因码会形成第二套可判定契约，并与统一 SSE 信封冲突。

**Migration**: Agent 改为只读取 HTTP/SSE 顶层 `code`；成功任务查询使用 `code=0`，任务终止失败码从 SSE 终止事件获取。CLI 与 Qtserver 的 `reason_code` 不参与此次迁移。
