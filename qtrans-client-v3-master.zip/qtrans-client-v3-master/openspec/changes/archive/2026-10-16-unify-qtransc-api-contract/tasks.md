# Tasks

## 1. 保存对外契约草案

- [x] 1.1 在 `qtransc/docs/qtransc-apis.md` 文末追加明确标为“待实施”的完整 QTrans 五位码表、默认英文文案和处置语义，并核对该章节没有声称当前代码已经生效

## 2. 建立 serve wire 边界

- [x] 2.1 新增 `internal/serveapi` 的数字码登记表、统一 HTTP response 和固定安全 message 构造器，并通过静态检查确认全部码值与错误码规范一致且无原始错误拼接
- [x] 2.2 新增创建任务与 token 更新的 camelCase wire request DTO、严格单对象 JSON decoder 和内部 request 转换，并通过代码审查确认未知字段、旧 snake_case、顶层 null 与尾随第二个 JSON 值均映射为 `30001`
- [x] 2.3 新增 health、任务 summary/detail 及嵌套文件/分片的 camelCase wire response DTO 与显式转换，并核对 `transferringFiles` 拼写、空数组以及所有 `reasonCode`/原始错误移除行为
- [x] 2.4 实现通用执行错误分类器，将现有结构化认证、限制、本地 I/O、Qtserver 和 clienterror 语义映射到登记码，并通过静态映射清单确认未分类错误只落到 `39999`

## 3. 收敛任务控制与调度错误

- [x] 3.1 为 scheduler 的未运行、关闭中、队列满和总容量满增加 typed/sentinel error，并在入队前安装完成回调；通过并发路径代码审查确认 worker 不能在回调安装前完成并泄漏容量槽
- [x] 3.2 为 task manager 的重复、未找到、状态冲突和容量失败建立可由 `errors.Is/As` 判断的错误边界，并确认 handler 不再依赖错误文本分类
- [x] 3.3 为创建和重启工作项增加接受门控及失败回滚：入队失败不保留新任务或 created 事件，重启失败恢复原状态，入队成功后才开放执行；通过状态/锁顺序代码审查确认没有孤立 pending 任务和 manager-worker 互等

## 4. 切换全部 HTTP 接口

- [x] 4.1 将 9 个 JSON handler 全部切换到严格 wire request、serve response DTO 和集中式码表，确认成功使用 `0/Success`、失败省略 `data`、空列表输出 `[]`，且所有 JSON 响应为 HTTP `200`
- [x] 4.2 重构 Gin 路由和中间件：关闭自动重定向，启用统一 NoRoute/NoMethod，按已注册路由应用 secret 鉴权，并让 recovery 仅在未提交时写 `200/39999`；核对 `OPTIONS` 仍为 `204`、health 仍公开
- [x] 4.3 核对重复 taskId、任务不存在、状态冲突、容量不足、认证和下游错误在所有相关 handler 中分别映射到已登记唯一 code，且日志保留 cause、wire 只包含安全 message

## 5. 切换 SSE 事件线协议

- [x] 5.1 扩展内部任务/文件状态事件以携带不序列化的 error cause，并让文件失败发布点传入真实错误；核对正常、完成、暂停与失败路径不会把自由文本写入 wire data
- [x] 5.2 实现七类内部事件到 `{messageType,code,message,data}` 的集中转换，核对 `qtrans.*` 词汇、camelCase、`transferred` 拼写、RFC3339 心跳及失败任务/文件的数字码
- [x] 5.3 将 SSE writer 切换为只序列化 serve envelope，并通过静态搜索确认 serve wire 不再产生 `event_type`、`reason_code`、`reasonCode`、`transfered` 或 task status `error`

## 6. 同步对外说明并编译验证

- [x] 6.1 最小化修正 `qtransc/docs/qtransc-apis.md` 中与实现冲突的旧 HTTP status/code、snake_case、reason_code 和 SSE 示例，将文末码表改为已生效说明，同时保持原章节结构并标注需人工审核
- [x] 6.2 静态核对 CLI、Qtserver DTO、upload2/download2 WebSocket 与业务日志 schema 未发生 wire 变更，并记录发现的任何非预期 diff
- [x] 6.3 在 `qtransc` 模块运行 `go build ./...`，修复所有编译错误；不新增或运行 test/benchmark

## 7. 统一 HTTP 与 SSE 任务状态

- [x] 7.1 让 `qtrans.task.status.data.status` 直接使用 `pending`、`running`、`completed`、`stopped`、`failed`，并把任务删除转换为不携带 `status` 的 `qtrans.task.deleted`
- [x] 7.2 最小化更新 `qtransc/docs/qtransc-apis.md` 中的 SSE 任务状态、事件类型和示例，并保留人工复核标记
- [x] 7.3 静态核对 serve SSE 不再输出任务状态 `created`、`started`、`paused`、`deleted`，然后在 `qtransc` 模块运行 `go build ./...`；不新增或运行 test/benchmark

## 8. 统一 taskPid 字段命名

- [x] 8.1 将 serve 创建任务 wire DTO 和严格字段白名单中的 `taskpid` 改为 `taskPid`，确认旧字段映射为 `30001`，且内部 `TaskPID`、日志键和非 serve 协议保持不变
- [x] 8.2 最小化更新 `qtransc/docs/qtransc-apis.md` 中公开请求字段、说明和示例为 `taskPid`，并保留人工复核标记
- [x] 8.3 静态核对 serve wire 不再接受 `taskpid`，然后在 `qtransc` 模块运行 `go build ./...`；不新增或运行 test/benchmark

## 9. 增加失败处置元数据

- [x] 9.1 将默认 message、`retryable` 和 `visible` 收敛到同一数字码登记表，为 HTTP/SSE 失败信封增加必填 `meta`，成功省略 `meta`，并把成功码或未登记失败码归一为 `39999`
- [x] 9.2 最小化更新 `qtransc/docs/qtransc-apis.md` 的 HTTP/SSE 信封说明、失败示例和五位码表，新增 `retryable`、`visible`、研发触发条件三列并标记需要人工复核
- [x] 9.3 静态核对 `retryable=true` 仅属于 `30104`、`30301`、`30302`、所有 `visible` 与当时批准的码表一致、成功信封不含 meta、失败信封不含 `data:null`，然后在 `qtransc` 模块运行 `go build ./...`；不新增或运行 test/benchmark

## 10. 稳定错误码注册表并开放错误文案展示

- [x] 10.1 将所有登记失败码的 `visible` 改为 `true`，保持 `retryable` 取值不变，并同步 HTTP/SSE 失败示例
- [x] 10.2 新建稳定的 `qtransc/docs/qtransc-error-codes.md`，迁移不含“调用方处置”的五位码表；从 `qtransc-apis.md` 删除完整码表并改为链接
- [x] 10.3 将错误码注册表加入长期维护清单并写明变更门槛；静态核对综合 API 文档无重复码表、所有失败码 `visible=true`，然后严格校验 OpenSpec 并在 `qtransc` 模块运行 `go build ./...`；不新增或运行 test/benchmark

## 11. 确立错误码规范源

- [x] 11.1 将 `qtransc/docs/qtransc-error-codes.md` 确立为错误码唯一规范源，删除 OpenSpec 中的重复码表和固定元数据清单，改为规范性引用
- [x] 11.2 调整项目文档权威顺序、错误码维护流程、综合 API 文档和 `serveapi` 代码说明，明确 OpenSpec 与代码均以规范注册表为准
- [x] 11.3 静态核对规范注册表、OpenSpec 和代码当前内容一致，严格校验 OpenSpec 并在 `qtransc` 模块运行 `go build ./...`；不新增或运行 test/benchmark

## 12. 标注错误出现位置和任务终态

- [x] 12.1 在错误码规范注册表增加“出现位置 / 任务终态”列，区分 HTTP API、任务 `failed`、文件 `failed` / 任务 `stopped` 和当前预留码，不改变既有码值、message 或 meta
- [x] 12.2 修订 serve API 和错误契约 delta 及 design，明确任务执行错误码只随当时的 SSE 失败事件发送，后续 HTTP 任务快照不补发历史错误码
- [x] 12.3 最小化更新 `qtransc-apis.md` 的 HTTP/SSE 观察差异说明并执行 OpenSpec 严格校验；本项不修改源代码，不运行测试、benchmark 或构建

## Workflow follow-up

- 与 Agent 在同一发布窗口完成联调和切换，失败时双方整体回滚。
- 维护者人工审核 `qtransc/docs/qtransc-error-codes.md` 和 `qtransc/docs/qtransc-apis.md` 后再将其作为正式对外交付文档。
- 实现与联调完成后归档本 OpenSpec change。
