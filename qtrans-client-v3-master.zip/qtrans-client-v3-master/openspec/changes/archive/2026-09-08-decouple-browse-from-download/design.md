## Context

当前 Qtserver 在一个 `read_enabled` 条件分支中注册 `GET /files/list` 和全部下载路由；qtransc 又把 list 预检绑定到 `read`。这使关闭下载同时关闭浏览。参见 [proposal.md](proposal.md) 的动机和范围。

## Goals / Non-Goals

**Goals:**

- 保持现有 TOML 字段、默认值和配置校验兼容。
- 让目录浏览始终可路由，并按现有 principal 隔离与鉴权模型工作。
- 让下载和任何远端修改仍可由两个既有开关独立控制。
- 使 Qtserver capabilities 和 qtransc 预检与路由行为一致。

**Non-Goals:**

- 不新增 `browse_enabled`、不新增文件级或目录级 ACL，也不引入跨 principal 浏览。
- 不改变匿名写 token、身份 provider、存储布局、下载协议或 Nginx 下载配置生成条件。
- 不为旧版 qtransc 模拟新行为；获得 `read_enabled=false` 时的 list 支持需要升级客户端。

## Decisions

### 保留配置 schema，并将 read 解释为下载能力

Qtserver 保留 `read_enabled`、`write_enabled` 和 `anonymous_enabled` 的解析、默认值和校验。路由注册将 list 从 read 分支中移出，read 分支只保留 `/d/*` 下载工作流。这样部署文件无需迁移，且 `read`/`download` capabilities 可以继续作为同义的下载开关。

备选的 `browse_enabled` 会提供更细粒度的开关，但会扩展已部署配置的运维表面，并违背本变更的兼容目标，因此不采用。

### write 是全部 mutation 的总开关

`write_enabled` 继续同时保护上传 session 和 canonical 文件管理的所有 POST mutation。`upload` 只是 capabilities 中面向传输客户端的同义能力；它不把 mkdir、move、delete 或 create 排除在写入控制之外。

只用 write 控制 upload、让其他 mutation 始终可用，会让运维无法禁止远端修改，也与此变更的安全目标矛盾，因此不采用。

### 浏览复用现有 principal 鉴权，而不建立独立访问模式

list 继续使用现有 read-principal 认证流程，因为它是读取元数据的访问操作，而不是下载能力。无 Authorization 时，只有 `anonymous_enabled=true` 才解析为 anonymous；关闭 anonymous 后，无凭据 list 返回认证错误。有效普通用户凭据始终解析为该用户自己的 principal，不能因为 anonymous 关闭而被拒绝。

### capabilities 将“路由可浏览”和“允许 mutation”分开表达

不增加新的 capability 键。既有 `file_management` 表示 canonical list 可用，固定为 enabled/available；`write` 继续表达 mutation 是否可用。qtransc list 因此只预检 `file_management`，下载仍额外检查 `read` 和 `download`，mutation 仍额外检查 `write`。

`anonymous.read` 表示 anonymous principal 是否可用于浏览；匿名下载必须再结合全局 `download` 判断。这个组合避免新增字段，同时使无凭据 list 的客户端能在发送请求前获得准确结果。

## Risks / Trade-offs

- [关闭下载的部署将暴露目录元数据] → 在配置/API 文档和发行说明中明确：`read_enabled=false` 不再隐藏目录名、大小和时间；需要禁止匿名浏览时设置 `anonymous_enabled=false`，普通用户访问仍由身份凭据控制。
- [旧 qtransc 仍把 list 视为 read 操作] → 服务器先于客户端升级；旧客户端不会错误下载，但会继续在本地拒绝 list，直到客户端升级。
- [新版 qtransc 先连接旧服务] → 在旧服务且 `read_enabled=false` 的情况下可能收到 list 404；发布顺序必须为 Qtserver 后 qtransc，回滚时一起回滚客户端或保留新服务。
- [`file_management` 名称包含 mutation 的历史含义] → 文档明确它只说明 list 路由存在，调用 mutation 必须另外检查 `write`。

## Migration Plan

1. 发布包含本变更的 Qtserver，并更新配置/API 文档；现有配置文件无需改动。
2. 升级 qtransc，使 list 使用新的 capability 预检。
3. 对 `read_enabled=false` 的部署，确认其目录元数据暴露范围符合预期；如不需要匿名浏览，将 `anonymous_enabled` 保持为 false。
4. 若需回滚，在回退 Qtserver 前同时回退 qtransc，或继续保留新版 Qtserver 以免新版 qtransc 对 list 收到旧服务的 404。
