## MODIFIED Requirements

### Requirement: anonymous 读写使用最小鉴权模型

`anonymous_enabled` SHALL 默认 false。启用时，无 Authorization 的 `GET /files/list` SHALL 映射到 anonymous principal，且该映射 SHALL NOT 依赖 `read_enabled`。无凭据的内容下载请求只有在 anonymous 与 `read_enabled` 同时开启、对应下载路由已注册时，才 SHALL 映射到 anonymous principal。

anonymous write 必须携带代码内固定公开 token `00000000-0000-4000-8000-000000000000`；该 UUID-v4 结构常量不是 secret，也不得配置。anonymous 与 write 同时启用时，持有者 SHALL 具有 canonical upload 和文件管理的完整权限，包括 overwrite。

qtransc 普通 `upload`、`mkdir`、`move`、`delete` 未显式提供 token 或用户名密码时 SHALL 自动使用固定 anonymous 写 token，且 SHALL NOT 要求用户手工输入该常量。显式认证 SHALL 优先并保持对应普通用户语义。该客户端默认行为 SHALL NOT 应用于 `upload2`。

#### Scenario: 无认证匿名浏览

- **WHEN** anonymous 开启且 `GET /files/list` 没有 Authorization，无论 `read_enabled` 取值如何
- **THEN** 请求 SHALL 在 anonymous 空间执行

#### Scenario: 无认证匿名下载

- **WHEN** anonymous 与 read 同时开启，且下载请求没有 Authorization
- **THEN** 请求 SHALL 在 anonymous 空间执行

#### Scenario: anonymous 未开启时无凭据浏览

- **WHEN** anonymous 未开启且客户端无 Authorization 调用 `GET /files/list`
- **THEN** 服务 SHALL 返回 401

#### Scenario: anonymous 未开启时普通用户浏览

- **WHEN** anonymous 未开启、普通 principal 可用且客户端携带有效普通用户凭据调用 `GET /files/list`
- **THEN** 服务 SHALL 按该普通 principal 的文件空间执行请求，而不得因 anonymous 未开启拒绝请求

#### Scenario: 无认证匿名写入

- **WHEN** anonymous write 路由收到缺失 Authorization 的请求
- **THEN** 服务 SHALL 返回 401

#### Scenario: 固定 token 写入

- **WHEN** anonymous 与 write 均开启且 canonical write 请求携带固定 token
- **THEN** 服务 SHALL 以 anonymous principal 执行，包括覆盖和删除既有 anonymous 对象

#### Scenario: qtransc canonical 写命令未指定认证

- **WHEN** 用户执行 qtransc 普通 `upload`、`mkdir`、`move` 或 `delete` 且未提供 token 或用户名密码
- **THEN** qtransc SHALL 使用固定 anonymous 写 token 执行对应 canonical 写操作

#### Scenario: qtransc canonical 写命令显式认证

- **WHEN** 用户执行 qtransc 普通 `upload`、`mkdir`、`move` 或 `delete` 且显式提供 token 或用户名密码
- **THEN** qtransc SHALL 使用该认证且 SHALL NOT 回退 anonymous

#### Scenario: 非法 token 尝试匿名回退

- **WHEN** list、download 或 write 请求携带无效 token
- **THEN** 服务 SHALL 返回认证错误且 SHALL NOT 回退 anonymous

#### Scenario: anonymous 未开启

- **WHEN** 请求携带固定 token 但 anonymous 未开启
- **THEN** 服务 SHALL 返回 401

#### Scenario: upload2 收到固定 token

- **WHEN** upload2 请求携带固定 anonymous token
- **THEN** qtransc SHALL 在传输前拒绝该请求

### Requirement: capability 开关决定路由是否存在

`read_enabled` SHALL 只控制下载路由是否注册：`POST /d/grant`、`POST /d/small`、`POST /d/verify` 和 `GET /d/down/*objectKey`。当 `read_enabled=false` 时，这些路由 SHALL 不注册并返回 404 `ROUTE_NOT_FOUND`。

`write_enabled` SHALL 是全部远端 mutation 的总开关。关闭时，canonical upload 的全部路由，以及 `POST /files/mkdir`、`POST /files/move`、`POST /files/delete` 和 `POST /files/create` SHALL 不注册并返回 404 `ROUTE_NOT_FOUND`。

`GET /files/list` SHALL 始终注册，且 SHALL NOT 因 `read_enabled` 或 `write_enabled` 被关闭而返回 route-not-found；其访问仍受对应 principal 鉴权和文件空间规则约束。

#### Scenario: write 关闭

- **WHEN** 客户端访问 upload 或文件管理写路由且 write 关闭
- **THEN** 服务 SHALL 返回 404 `ROUTE_NOT_FOUND`

#### Scenario: read 关闭

- **WHEN** 客户端访问任一下载路由且 read 关闭
- **THEN** 服务 SHALL 返回 404 `ROUTE_NOT_FOUND`

#### Scenario: 读写均关闭时浏览

- **WHEN** read 与 write 均关闭且已鉴权客户端访问 `GET /files/list`
- **THEN** 服务 SHALL 注册并按正常 list 契约处理该请求，而不得返回 `ROUTE_NOT_FOUND`
