## MODIFIED Requirements

### Requirement: capabilities 公布协议版本和关键限制

capabilities SHALL 至少公布 list 上限 100000、逻辑路径上限 1024 bytes、segment 上限 255 bytes、grant 上限 1000、chunk size 104857600，以及 small download 的默认文件数、单文件和总大小限制。algorithms SHALL 包含 `xxh3_128` 和 `layered_xxh3_128_v1`。

capabilities SHALL 保留 `read`、`download`、`write`、`upload` 和 `file_management` 键。`read` 与 `download` 的 `enabled`/`available` SHALL 均等于 `read_enabled`，表示内容下载是否可用；`write` 与 `upload` 的 `enabled`/`available` SHALL 均等于 `write_enabled`，表示远端 mutation 是否可用；`file_management` 的 `enabled`/`available` SHALL 始终为 true，表示 canonical list 路由可用，而不得被解释为 mutation 已获准。

响应 SHALL 公布 anonymous read/write 可用性。`anonymous.read` SHALL 等于 `anonymous_enabled`，表示无凭据 caller 能否浏览 anonymous 空间；anonymous 内容下载仍同时要求 `anonymous.read=true` 和全局 `download.enabled=true`。`anonymous.write` SHALL 仅在 `anonymous_enabled=true` 且 `write_enabled=true` 时为 true。

#### Scenario: 下载关闭时的 capabilities

- **WHEN** `read_enabled=false`、`write_enabled=false` 且 `anonymous_enabled=true`
- **THEN** `read` 与 `download` SHALL 均为 disabled/unavailable，`write` 与 `upload` SHALL 均为 disabled/unavailable，`file_management` SHALL 为 enabled/available，`anonymous.read` SHALL 为 true，且 `anonymous.write` SHALL 为 false

#### Scenario: qtransc 读取服务契约

- **WHEN** qtransc 查询 capabilities
- **THEN** 它 SHALL 能从响应确定 API major version、所需能力、限制和 hash algorithms
- **AND** SHALL NOT 根据 Qtserver 应用版本号猜测兼容性

### Requirement: qtransc 在创建任务或操作前预检 capability

qtransc upload、download、list、mkdir、move 和 delete SHALL 在创建 task 或发送操作前查询 capabilities，并 MAY 缓存同一服务响应五秒。普通 upload SHALL 要求 `upload`；目录 upload SHALL 同时要求 `upload` 和 `file_management`；download SHALL 同时要求 `read`、`download` 和 `file_management`；list SHALL 只要求 `file_management`；mkdir、move 和 delete SHALL 同时要求 `write` 和 `file_management`。无凭据 list SHALL 额外要求 `anonymous.read=true`。

#### Scenario: read 关闭时 qtransc 浏览

- **WHEN** `read_enabled=false`、`file_management` 可用且 qtransc 执行 list
- **THEN** qtransc SHALL 通过 capability 预检并向 `GET /files/list` 发起请求

#### Scenario: 服务没有所需能力

- **WHEN** 预检发现所需 capability disabled 或 API major version 不兼容
- **THEN** qtransc SHALL 在传输或 mutation 开始前失败

#### Scenario: 服务连接失败

- **WHEN** 创建 task 前无法连接 Qtserver
- **THEN** qtransc SHALL NOT 创建 task
- **AND** SHALL 报告服务不可用
