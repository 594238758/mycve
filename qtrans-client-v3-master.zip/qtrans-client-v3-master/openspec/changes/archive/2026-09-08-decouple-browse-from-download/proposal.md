## Why

现有 `read_enabled` 会同时关闭目录浏览和下载，和其作为“禁止下载”开关的运维直觉不一致。已部署配置不能新增或改名字段，因此需要在保持配置 schema 不变的前提下，将浏览从下载能力中解耦，并继续用 `write_enabled` 统一控制所有远端修改。

## What Changes

- 保持 `read_enabled`、`write_enabled` 和 `anonymous_enabled` 的字段名、默认值和严格配置 schema 不变。
- 将 `read_enabled` 的作用收窄为下载能力：它只决定 canonical download、small download、download grant、下载校验和内容下载路由是否注册。
- 使 `GET /qtserver/v1/files/list` 始终注册；该接口仍按 caller 的 principal 浏览其自身文件空间，不提供跨 principal 浏览。
- 将 `write_enabled` 明确为全部远端 mutation 的总开关，继续同时控制 canonical upload 与 `mkdir`、`move`、`delete`、`create`。
- 调整 capabilities 与 qtransc 预检，使列表浏览不再依赖 `read`/`download`，而下载和 mutation 仍分别依赖其原有能力。
- 无凭据 list 仅在 `anonymous_enabled=true` 时映射到 anonymous；关闭 anonymous 时应返回认证错误，携带有效普通用户凭据的 list 不受影响。

## Capabilities

### New Capabilities

- 无。

### Modified Capabilities

- `user-file-space`：修改 read/write 路由开关和 anonymous 浏览的行为契约。
- `service-capability-discovery`：修改 capabilities 的含义以及 qtransc 对 list 的预检要求。

## Impact

- 影响 Qtserver 路由注册、capabilities 响应及匿名读鉴权的可观察行为。
- 影响 qtransc `list` 的 capability 预检；新客户端在 `read_enabled=false` 时可以正常浏览，旧客户端仍会在本地预检阶段拒绝该操作，需升级 qtransc 才能获得新行为。
- 对采用 `read_enabled=false` 的部署，`/files/list` 会从 404 变为已注册的受鉴权接口；这是刻意的访问能力扩展，应在升级说明中明确其元数据可见性影响。
- 需同步更新 `qtserver/docs/config.md`、`qtserver/docs/qtserver-apis.md`、qtransc API 文档和相关 capability 文档；不新增配置迁移步骤，也不改变 Nginx 下载配置生成条件。
