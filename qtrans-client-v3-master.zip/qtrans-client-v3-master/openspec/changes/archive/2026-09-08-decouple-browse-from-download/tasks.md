## 1. Qtserver 路由与能力

- [x] 1.1 调整 Qtserver 路由注册，使 `GET /files/list` 始终注册，`read_enabled` 仅控制 `/d/*` 下载路由，`write_enabled` 继续控制全部远端 mutation 路由。
- [x] 1.2 调整 capabilities 响应，使 `read/download`、`write/upload`、`file_management` 和 anonymous read/write 状态符合已批准的语义。

## 2. qtransc capability 预检

- [x] 2.1 调整 qtransc list 预检，使其只要求 `file_management`，并在无凭据时按 anonymous read 状态拒绝或放行。
- [x] 2.2 保持 download 和所有 mutation 的 capability 预检分别依赖下载能力和 write 能力，避免目录上传与文件管理命令绕过 mutation 开关。

## 3. 文档与行为契约

- [x] 3.1 更新 `qtserver/docs/config.md`，明确三个现有开关的下载、mutation 和匿名浏览语义及兼容性影响。
- [x] 3.2 更新 `qtserver/docs/qtserver-apis.md` 与 qtransc API 文档，说明 list 始终可路由、capabilities 的字段含义和客户端升级要求。
- [x] 3.3 将已批准的 delta specs 同步到主 OpenSpec specs。

## 4. 编译验证

- [x] 4.1 在 `qtserver` 模块执行 `go build ./...`。
- [x] 4.2 在 `qtransc` 模块执行 `go build ./...`。
