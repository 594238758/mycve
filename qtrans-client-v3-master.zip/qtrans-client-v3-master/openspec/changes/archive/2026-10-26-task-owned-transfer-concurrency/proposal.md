# Proposal

## Why

C=3、S=3、F=3 时，CLI 静态推导 P=3；实际只有一个文件时只能推进三个分片，无法利用九个请求名额。取消固定 P，并让任务独占池，可以明确容量归属并保留现有重试流程。

## What Changes

- 普通文件受 F 限制，任务共享 N=C×S 个分片操作额度；额度覆盖分片重试和退避。
- 每轮执行独占网络客户端，控制请求和数据请求共享该实例；完成和停止后关闭，重启重新创建。
- **BREAKING（容量作用域）** C 从进程共享上限改为每轮任务、每个 origin 的上限；活动任务数会放大总容量。保留任务数量上限，不新增全局限流。
- API、SSE、CLI 参数和默认值保持不变；无需请求格式迁移，部署方应按活动任务数评估连接容量。
- 按用户要求删除仓库自有 Go 测试及失效 benchmark 入口，只进行编译和静态检查。
- 不重写重试调度，不改变认证管理、协议驱动或 v2 小文件流程。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `client-transfer-concurrency`: 取消 P，使用任务共享分片额度及任务级网络容量。
- `tcp-transport-pooling`: 明确 TCP 池和连接上限的任务作用域。
- `http3-transport-lifecycle`: 明确 QUIC 连接上限的任务作用域。
- `versioned-https-transports`: serve 校验配置，每轮按 transport 创建实例。
- `qtransc-serve-api-contract`: 保持外部接口，关闭任务时释放所属连接池。

## Impact

影响 netclient、qtserverapi、taskidclient、上传下载任务、CLI 和 serve 调度接入。用户已在本轮明确要求实施完整计划；本 change 将该已批准方案落为规范，不增加功能范围。对外 CLI/API 文档修改为待人工审核草稿。
