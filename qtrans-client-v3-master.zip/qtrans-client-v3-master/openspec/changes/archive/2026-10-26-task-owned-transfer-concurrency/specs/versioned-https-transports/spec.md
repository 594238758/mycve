## MODIFIED Requirements

### Requirement: transport 参数严格校验

`connections` SHALL 对所有 transport 为 `1..1024` 范围内的整数。`https` 的 `streams` SHALL 等于 1；`https2` 和 `https3` 的 `streams` SHALL 为 `1..1024` 范围内的整数。只影响 QUIC 的参数 SHALL 仅适用于 `https3`。无效组合 SHALL 在连接池创建或网络访问之前失败，而 SHALL NOT 被静默修正。任何 `connections * streams` 派生计算 SHALL 在两个操作数分别通过范围校验之后执行，使每个 origin 的最大配置本地容量不超过 1,048,576 且计算不会发生整数溢出。

#### Scenario: https 配置多个 streams

- **WHEN** 调用者为 `https` 配置 `streams` 大于 1
- **THEN** qtransc SHALL 返回参数错误，而 SHALL NOT 把它静默压缩为 1

#### Scenario: 容量参数超出范围

- **WHEN** `connections` 小于 1 或大于 1024，或 `https2`、`https3` 的 `streams` 小于 1 或大于 1024
- **THEN** qtransc SHALL 在建连前返回参数错误

#### Scenario: 校验后计算总容量

- **WHEN** qtransc 需要根据 `connections` 与 `streams` 派生每个 origin 的本地总容量
- **THEN** qtransc SHALL 先分别完成范围校验再执行乘法，且有效输入得到的结果 SHALL NOT 大于 1,048,576

#### Scenario: QUIC 专属参数用于 TCP transport

- **WHEN** 调用者把 QUIC receive window 等 QUIC 专属参数用于 `https` 或 `https2`
- **THEN** qtransc SHALL 在建连前返回参数错误

#### Scenario: serve 按任务 transport 创建池

- **WHEN** qtransc serve 启动时校验并保存共享的 multiplexed-stream 配置，任务开始执行
- **THEN** 该轮任务 SHALL 按所选 transport 创建独占池；`https` SHALL 固定使用每连接容量 1，`https2` 与 `https3` SHALL 使用保存的配置值
