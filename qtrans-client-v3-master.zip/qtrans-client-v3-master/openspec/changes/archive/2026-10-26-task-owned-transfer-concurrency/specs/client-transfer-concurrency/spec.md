## RENAMED Requirements

- FROM: `### Requirement: 业务层分别约束文件并发和单文件分片并发`
- TO: `### Requirement: 业务层约束文件并发和任务共享分片并发`

## MODIFIED Requirements

### Requirement: 业务层约束文件并发和任务共享分片并发

qtransc SHALL 保留活动普通文件上限 F，并取消固定单文件分片并发 P。每轮任务的所有普通文件 SHALL 共享 N=C×S 个分片操作额度，HTTP/1.1 的 S SHALL 为 1。分片 SHALL 先取得额度再启动工作协程，直到该分片操作成功、失败或取消退出才归还额度；重试与退避期间 SHALL 继续持有额度。等待额度 SHALL 可取消且不消耗重试次数，不得为全部待传分片预建阻塞协程。文件之间不保证平均分配。

#### Scenario: 多文件并行分片传输

- **WHEN** C=3、S=3、F=3，多个普通文件包含足够多待传分片
- **THEN** 活动普通文件 SHALL 不超过 3，总活跃分片操作 SHALL 不超过 9
- **AND** 已完成操作释放的额度 SHALL 可被其他文件使用

#### Scenario: 单个文件包含大量分片

- **WHEN** C=3、S=3、F=3，但只有一个文件且待传分片充足
- **THEN** 该文件 SHALL 能使用全部 9 个分片额度
- **AND** 下载 SHALL 在首次注册响应头确认后继续填充剩余额度

#### Scenario: 退避和取消

- **WHEN** 分片在请求之间退避，或任务在等待额度时取消
- **THEN** 退避中的分片 SHALL 保留分片额度并释放已结束请求的网络名额
- **AND** 取消的等待 SHALL 退出且不泄漏额度

### Requirement: 网络层以连接 lane 和本地请求上限约束容量

qtransc SHALL 在每轮任务独占池内，为每个 transport 与规范化 origin 维护最多 `connections` 个相互独立的连接 lane。`streams` SHALL 表示一条 lane 同时准入的本地在途 HTTP 请求上限；`https` 的该值 SHALL 固定为 1，`https2` 与 `https3` SHALL 使用有效配置值。每个请求从获准进入 lane 起，直到请求失败、无响应体请求完成、响应体读到 EOF 或响应体关闭期间 SHALL 占用一个本地名额。

`connections` 与 `streams` SHALL 仅定义客户端上限，不声明服务端实际连接或 stream 容量。连接 SHALL 按需建立；当业务需求和服务端能力足够时，qtransc SHALL 能将请求分散到多个 lane，使 `connections` 能形成多个独立物理连接，而 SHALL NOT 要求先耗尽第一条连接的对端 stream 容量后才使用其他 lane。

#### Scenario: 本地网络容量上限

- **WHEN** 一个 `https2` origin 配置 `connections=4`、`streams=8`
- **THEN** qtransc SHALL 为该 origin 维护最多 4 个连接 lane
- **AND** 每条 lane SHALL 最多准入 8 个本地在途请求
- **AND** 该 origin SHALL NOT 准入超过 32 个本地在途请求

#### Scenario: 多连接承载并发请求

- **WHEN** 至少有 `connections` 个并发请求、服务端接受相应连接且本地未受其他资源限制
- **THEN** qtransc SHALL 能让不同 lane 按需建立相互独立的物理连接并承载请求

#### Scenario: 响应体仍未消费完成

- **WHEN** 一个请求已收到响应头但响应体尚未读完或关闭
- **THEN** 该请求 SHALL 继续占用所在 lane 的一个本地请求名额

### Requirement: 小文件下载并发由网络 lane 独立约束

qtransc SHALL NOT 使用 `transfers` 限制 v2 小文件批次的并发数，也 SHALL NOT 让小文件批次占用普通大文件的文件并发名额。每个活动 v2 批次 SHALL 占用一个 HTTP 请求名额；本地最大活动批次数 SHALL 只受对应 origin 的可用 lane 容量以及本任务内其他共享该 origin 的在途请求约束，其中 `https` 的容量为 `connections`，`https2` 和 `https3` 的客户端容量上限为 `connections * streams`，实际容量仍 SHALL 服从对端协议限制。

#### Scenario: transfers 小于可用 lane 数

- **WHEN** `transfers=1`，所选 transport 有 8 个可用请求 lane，且至少有 8 个已成形的小文件批次
- **THEN** qtransc SHALL 允许最多 8 个 v2 小文件批次同时传输
- **AND** SHALL NOT 因 `transfers=1` 把活动小文件批次限制为 1 个

#### Scenario: 小文件和大文件使用不同并发约束

- **WHEN** 小文件阶段已经收敛并进入普通大文件阶段
- **THEN** 普通大文件 SHALL 继续受 `transfers` 和任务共享分片额度规则约束
- **AND** 小文件阶段使用过的并发数 SHALL NOT 改变大文件并发上限

## ADDED Requirements

### Requirement: 任务执行独占网络资源

每轮任务 SHALL 独占连接池；同任务控制请求和数据请求 SHALL 使用同一池，控制请求 SHALL NOT 再次申请分片额度。排队任务 SHALL 不创建池。任务工作协程和必要清理结束后 SHALL 关闭池，重启 SHALL 创建新池。CLI 预检客户端 SHALL 交给首轮执行，预执行失败 SHALL 关闭；独立文件命令和删除后清理 SHALL 在各自作用域结束时关闭短期池。容量不跨任务共享，SHALL 保留现有 serve 任务数量限制。

#### Scenario: 同地址的两个任务

- **WHEN** 两个任务使用相同 transport、origin、C 和 S
- **THEN** 两者 SHALL 各自拥有 C 个连接和 C×S 个请求容量上限
- **AND** 停止其中一个 SHALL 不关闭另一个的连接池

#### Scenario: 重启任务

- **WHEN** 任务旧执行资源仍在释放
- **THEN** 重启 SHALL 被拒绝；旧轮释放完成后的新轮 SHALL 使用新的池和分片额度
