## MODIFIED Requirements

### Requirement: serve 正常关闭先停止全部活动任务

正常关闭 SHALL 先禁止创建、启动并使用注册表的关闭条目拒绝这些请求，再逐个停止 pending/running 任务并等待退出。已有终态 SHALL 保留，最终故障 SHALL 优先。每轮任务 SHALL 在协程和必要清理收敛后关闭自己的传输池。完成任务收尾和终态发布后 SHALL 关闭 worker pool、SSE、HTTP 及日志。停止阶段 SHALL NOT 新增强杀期限，HTTP 收尾 SHALL 沿用五秒期限。

#### Scenario: 正常停服

- **WHEN** 收到正常退出信号
- **THEN** SHALL 先逐个 stop 活动任务，再结束服务，主动停止任务 SHALL stopped 且无 error

#### Scenario: 关闭期间创建或启动

- **WHEN** 服务已进入关闭阶段且收到创建或启动请求
- **THEN** SHALL 返回注册表的请求类关闭条目，不接受新执行

## ADDED Requirements

### Requirement: 并发改造保持任务接口兼容

连接池容量 SHALL 从 serve 启动配置取得，创建任务请求 SHALL NOT 新增 C、S、F 或 P 参数。任务详情 fileConcurrency SHALL 继续表示普通文件并发上限，上传为 2、下载为 5。HTTP 和 SSE 的字段、状态枚举及错误结构 SHALL 保持现有契约；取消 P SHALL 不要求调用方迁移请求格式。

#### Scenario: 调用方继续使用已有请求

- **WHEN** 调用方以现有合法请求创建任务并订阅 SSE
- **THEN** 请求 SHALL 继续被接受，响应及事件 SHALL 保持既有结构
- **AND** 普通分片操作 SHALL 按任务共享额度并行执行
