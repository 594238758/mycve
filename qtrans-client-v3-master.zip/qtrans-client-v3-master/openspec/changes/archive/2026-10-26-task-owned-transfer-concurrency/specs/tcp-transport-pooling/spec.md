## MODIFIED Requirements

### Requirement: TCP 连接池按 transport 和 origin 隔离

qtransc SHALL 在每轮任务独占池内，以 transport 与规范化 origin 的组合隔离 `https` 和 `https2` 连接池。规范化 origin SHALL 由小写 scheme、小写 host 和显式有效端口组成，省略的 HTTPS 端口 SHALL 规范化为 `443`。一个 origin 的连接、容量、等待队列和故障状态 SHALL NOT 被其他 origin 或 transport 共享。

#### Scenario: 同一 HTTPS origin 的等价写法

- **WHEN** 请求分别使用 `https://EXAMPLE.COM` 与 `https://example.com:443`，且属于同一任务执行、transport 相同
- **THEN** qtransc SHALL 将两者归入同一个规范化 origin 池

#### Scenario: 相同地址使用不同 TCP transport

- **WHEN** 同一个 `https://` 地址分别使用 `https` 和 `https2`
- **THEN** qtransc SHALL 使用两个相互隔离的连接池，并 SHALL NOT 跨池复用物理连接

#### Scenario: lease 被用于其他 origin

- **WHEN** 已从一个 origin 获取的请求 lease 被用于不同 origin 的请求
- **THEN** qtransc SHALL 在发送请求前拒绝该请求并释放对应容量

### Requirement: connections 是按 origin 的硬上限而非保有量

`connections` SHALL 是每轮任务、每个 TCP transport、每个 origin 的连接槽位硬上限，而不是启动时预建或持续保有的连接数量。连接池 SHALL 按需建立连接，并 SHALL 允许空闲回收后连接数降为零。尚未完成的 Dial 以及尚未完全关闭的 ready、draining 或 failed TCP/TLS 连接 SHALL 占用连接槽位，使实际并发物理连接数始终不超过 `connections`。

#### Scenario: 首个请求触发按需建连

- **WHEN** 某 origin 尚无连接且收到首个请求
- **THEN** qtransc SHALL 先预留一个连接槽位再开始 Dial，而 SHALL NOT 在池初始化时预建 `connections` 条连接

#### Scenario: 并发建连达到上限

- **WHEN** 某 origin 已有 `connections` 个被 Dial 或未关闭连接占用的槽位
- **THEN** qtransc SHALL NOT 为该 origin 再创建物理连接，直到已有槽位释放

#### Scenario: 空闲连接全部回收

- **WHEN** 某 origin 的全部连接均无活跃请求并超过配置的空闲时间
- **THEN** qtransc SHALL 关闭这些连接并释放槽位，且下一次请求 SHALL 能重新按需建连
