## MODIFIED Requirements

### Requirement: HTTP/3 实际连接数受硬上限约束

qtransc SHALL 将现有连接数量配置解释为每轮任务、每个 origin 的实际存活 QUIC 连接硬上限；前台命令使用 `--connections`，serve 使用现有 `quic.transports`/`--transports` 输入。连接名额 SHALL 从一次底层 QUIC Dial 开始占用，Dial 失败或连接 Context 结束后 SHALL 恰好释放一次。连接处于 ready、draining 或仍承载既有 stream 时 SHALL 继续占用名额。

qtransc SHALL NOT 为 GOAWAY 替换、重试或其他内部恢复临时建立超过该上限的 QUIC 连接。连接数按需增长且 MAY 低于上限；本要求不要求预建或始终维持固定数量。

#### Scenario: 单连接收到 GOAWAY 且仍有活跃 stream

- **GIVEN** 某 origin 的连接上限为 1，唯一 QUIC 连接仍有活跃 stream
- **WHEN** 该连接收到 GOAWAY 且新请求需要替代连接
- **THEN** qtransc SHALL 等待旧连接关闭并释放名额后再开始替代连接 Dial
- **AND** 任意时刻该任务该 origin 的实际存活 QUIC 连接数 SHALL NOT 超过 1

#### Scenario: Dial 失败释放名额

- **WHEN** HTTP/3 Dial 在返回可用 QUIC 连接前失败
- **THEN** qtransc SHALL 释放该次 Dial 占用的连接名额和底层网络资源
- **AND** 后续请求 SHALL 能够在连接上限内再次 Dial

#### Scenario: 连接池关闭

- **WHEN** qtransc 关闭 HTTP/3 连接池
- **THEN** qtransc SHALL 关闭 ready 与 draining 连接并释放对应连接名额、UDP 资源和等待中的 Dial
