# Tasks

## 1. 网络实例与执行生命周期

- [x] 1.1 将 netclient 改为实例，qtserverapi/taskidclient 显式接收实例；检索确认无生产全局池访问。
- [x] 1.2 接入 CLI、serve、独立命令和远端清理的客户端所有权；静态核对预检失败、取消、完成、重启关闭路径。

## 2. 任务共享分片额度

- [x] 2.1 删除 P，上传下载在启动协程前取得任务共享额度；静态核对取消竞态、下载注册屏障和恢复收敛。
- [x] 2.2 更新改造方案及 CLI/API 必要并发说明，保留接口和参数默认值；对照代码审阅文档，标明人工审核要求。

## 3. 用户要求的清理和整体验证

- [x] 3.1 删除全部仓库自有 Go 测试与 bench-auth 入口，检索确认无遗留；保留既有文档删除。
- [x] 3.2 执行 Go 编译、OpenSpec 验证和 git diff --check；不运行测试或 benchmark，记录验证范围。

## 验证记录

- 使用本机 Go 1.26.0，`go build ./qtransc/... ./qtserver/... ./qtuser/...` 通过；最后修改 serve 参数帮助后，重新编译 qtransc 通过。
- `openspec validate task-owned-transfer-concurrency --strict` 和 `git diff --check` 通过；修改的 Go 文件符合 gofmt。
- 静态检索确认无自有 `*_test.go`、`bench-auth`、生产全局 netclient 池调用、P 字段或推导。删除数量：qtransc 12、qtserver 8。
- API 请求/响应 DTO、handler、SSE 格式代码没有修改。静态核对了共享额度获取/释放、下载注册屏障、执行锁内关闭、CLI 预执行退出及删除后短期客户端路径。
- 未运行单元测试、集成测试、benchmark 或实际传输；编译与静态检查不证明吞吐或并发行为已获运行验证。

## Workflow follow-up

- `qtransc/docs/qtransc-cli-guide.md` 和 `qtransc/docs/qtransc-apis.md` 的并发说明需维护者人工审核；本次变更保留为未归档 change。
