## Context

参见 `proposal.md` 的问题说明和 `specs/http3-transport-lifecycle/spec.md` 的行为契约。

当前 HTTP/3 driver 为每条 pool lane 手工创建 UDP socket、`quic.Transport` 和 `quic.Conn`，再通过 `http3.Transport.NewClientConn` 直接执行请求。这个模型使一条 lane 精确绑定一条物理 QUIC 连接，但也绕过了 `http3.Transport.RoundTrip` 对 GOAWAY 的内部处理：quic-go 用未导出的 `errConnUnusable` 区分“打开 stream 前连接已经不可用”，移除旧 client connection，并只在能够保证安全时重试一次。qtransc 无法通过稳定的公开类型在 `NewClientConn` 路径复用这项判断。

现有通用传输池在每个 origin 下最多创建 `MaxConnections` 条 lane，并以 `MaxLeasesPerConnection` 限制每条 lane 的活跃 Lease。HTTP/3 当前把 `Healthy` 等同于底层 QUIC Context 尚未结束；GOAWAY 期间该 Context 仍可能存活以排空既有 stream，因此该健康判断不足以识别 draining。

实现必须同时保留两个硬约束：每个 origin 的实际 QUIC 连接数不得超过 connection limit，任一实际连接的活跃 stream 不得超过 stream limit。为了遵守前一个约束，GOAWAY 替换不能依赖临时创建第 `N+1` 条连接。

## Goals / Non-Goals

**Goals:**

- 使用 quic-go 的公开标准 Transport 路径处理 GOAWAY 和请求尚未发送的安全重试。
- 对 Dial、ready、draining 和关闭中的物理 QUIC 连接执行同一个 per-origin 硬上限。
- 继续用现有 Lease 名额约束 HTTP/3 stream 并发，不让内部重试绕过名额。
- pool Close、Dial 失败、Context 取消和正常连接结束均能确定地释放名额与 UDP 资源。
- 保持现有 CLI、serve 配置和业务请求重试契约。

**Non-Goals:**

- 不自行解析 HTTP/3 GOAWAY frame，也不依赖 quic-go 未导出的错误类型或错误字符串。
- 不让通用传输池接管所有业务请求重试。
- 不修改 HTTP/1.1、HTTP/2 driver，亦不修改 Nginx 请求上限。
- 不保证 GOAWAY 期间无等待；物理连接硬上限优先于无缝超配切换。

## Decisions

### 1. 每条 HTTP/3 lane 使用标准 `http3.Transport.RoundTrip`

HTTP/3 driver 不再预建 `quic.Conn` 后调用 `NewClientConn`。每条 lane 持有独立的 `http3.Transport`，普通请求调用其 `RoundTrip`。Transport 继续使用现有 TLS、QUIC window、0-RTT、keepalive、handshake timeout 和 compression 配置。

选择这一方式是因为 GOAWAY 是否发生在 request stream 打开前属于 HTTP/3 协议栈内部事实。quic-go 的标准 Transport 能稳定识别该状态、从缓存移除旧连接并进行最多一次安全重试；qtransc 若继续使用 `NewClientConn`，只能匹配未导出的错误实现或把所有 RoundTrip 错误粗略视为连接失败。

备选方案“保留 `NewClientConn` 并匹配 `connection in graceful shutdown` 文本”被拒绝，因为错误字符串不是兼容 API。备选方案“任意 RoundTrip 错误都销毁连接并由业务层重试”虽然能避免继续复用坏连接，但无法可靠判断 mutation 是否已经发送，且第一次撞上 GOAWAY 的任务仍可能失败。

### 2. Transport lane 与物理连接配额分离

外层 `managedOriginPool` 继续限制 lane 数量和每条 lane 的活跃 Lease。HTTP/3 driver 为同一 origin 的所有 lane 共享一个 connection limiter，容量等于 `MaxConnections`。每个 `http3.Transport` 使用自定义 `Dial`：

1. 使用请求 Context 和 origin-pool Close Context 获取一个 connection permit。
2. 获取 permit 后创建 UDP socket、`quic.Transport` 并执行 `DialEarly`。
3. Dial 失败时通过 `sync.Once` 释放 permit，并关闭本次创建的全部网络资源。
4. Dial 成功后注册物理连接资源，并等待 `quic.Conn.Context().Done()`；Context 结束后通过同一个 `sync.Once` 注销资源、关闭 UDP 资源并释放 permit。
5. origin pool Close 先取消等待中的 Dial，再关闭所有 lane Transport 和已注册底层资源，最后等待回收 goroutine 退出。

permit 从 Dial 开始前占用，因此“正在建立 + 已存活”的连接总数也不会超过配置上限。draining 连接的 QUIC Context 在既有 stream 排空前不会结束，所以它自然持续占用 permit。标准 Transport 尝试替换连接时，如果没有 permit，其 Dial 会在原请求 Context 内等待。

一个 lane 在 GOAWAY 期间可能同时关联旧 draining 连接和新连接，但只有当该 origin 仍有未使用 permit 时才允许发生；per-origin 实际连接总数始终不超过上限。若连接上限为 1，替代 Dial 必须等旧连接完全关闭。

备选方案“每条 lane 独立允许旧、新连接短暂重叠”被拒绝，因为它会把 `--connections=N` 弱化为稳定态上限。备选方案“把 `keepalive_requests` 调大”只会延迟下一次 GOAWAY，不能修复客户端生命周期。

### 3. 现有 Lease 上限继续承担 stream 并发控制

`MaxLeasesPerConnection` 继续作为每条 HTTP/3 lane 的本地并发名额。一个 Lease 覆盖一次完整 RoundTrip，包括 Transport 内部因连接不可用执行的单次安全重试，直到响应 Body EOF/Close 或错误返回才释放。

标准 Transport 的内部重试不重新 Acquire Lease，因此不会凭空增加 stream 名额。即使一个 lane 在 GOAWAY 排空期间短暂关联旧、新两条物理连接，该 lane 跨两条连接的活跃 Lease 总数仍不超过 stream limit，因而任一物理连接上的活跃 stream 数也必然不超过该限制。这个选择可能低于协议栈或服务端允许的最大并发，但满足用户要求的硬上限。

### 4. 仅接受协议栈证明安全的内部重试

不在 qtransc 中新增字符串匹配或通用 mutation 重放。使用 quic-go v0.54.0 标准 Transport 现有规则：

- 打开 request stream 前返回 `errConnUnusable` 时，请求尚未发送，可在新连接上重试。
- 服务端以 `H3_REQUEST_REJECTED` 明确拒绝且 request body 可安全复用时，可以重试。
- 其他错误直接返回；业务层继续使用现有 transport/HTTP 退避、offset 查询、幂等 complete 和禁止 move/delete 盲重试规则。

协议层重试最多一次并复用原请求 Context。控制请求现有的连续 30 秒无有效 response/progress 窗口继续作为总边界；实现阶段需要审核调用链，确保等待 connection permit 不会脱离该 Context。

### 5. HTTP/3 lane 的健康语义改为可自恢复 Transport

标准 `http3.Transport` 自己淘汰不可用的内部 client connection，因此 lane 不再通过某一条 `quic.Conn.Context` 判断整体 Healthy。lane 只在自身被关闭、Transport 无法继续使用或资源管理器终止时标记失败；单条内部 QUIC 连接 GOAWAY 不再使 lane 永久失败。

通用 pool 的 lane 计数与物理 QUIC 连接计数是两个概念。连接硬上限由 limiter 的 permit 保证，不能再从 `len(lanes)` 推断当前物理连接数量。现有外部接口没有暴露该 Snapshot，因此本变更不新增监控 API；debug 日志可以记录 Dial、permit 等待、连接关闭原因和当前 permit 使用量，但不得输出凭据。

## Risks / Trade-offs

- [严格连接上限可能增加等待] → replacement Dial 复用原请求 Context；超时或取消立即退出，绝不通过创建第 `N+1` 条连接规避等待。
- [标准 Transport 隐藏内部 GOAWAY 状态] → 让 quic-go 管理协议 draining，qtransc 只以 QUIC Context 生命周期管理硬配额，不重复维护可能失真的 GOAWAY 状态机。
- [permit 或 UDP 资源泄漏会阻塞后续任务] → Dial 失败、正常关闭、pool Close 统一使用幂等 release 对象，并等待资源回收 goroutine；编译阶段同时进行静态调用路径审查。
- [Transport 内部重试可能被误认为 mutation 盲重试] → 只采用 quic-go 对“stream 未打开”或 `H3_REQUEST_REJECTED` 的安全判断，不增加 qtransc 自定义的结果不确定重放。
- [lane 与物理连接不再一一对应] → CLI 语义明确约束实际连接总数和单连接 stream 上限，而不是要求稳定 lane 身份；limiter 与 Lease 分别执行两项硬约束。

## Migration Plan

1. 修改 HTTP/3 driver 和资源生命周期管理，保持现有配置默认值与输入名称不变。
2. 更新 qtransc 传输池设计说明中“传输池完全不自动重试”的表述，注明仅有协议栈已证明请求未发送时的单次连接替换重试。
3. 仅执行 qtransc 编译验证；本变更不新增 test 或 benchmark。
4. 生成新二进制后按现有部署方式替换并重启 qtransc。无需数据库、任务状态或配置迁移。
5. 如需回滚，恢复旧二进制并重启；没有持久化格式需要回退。
