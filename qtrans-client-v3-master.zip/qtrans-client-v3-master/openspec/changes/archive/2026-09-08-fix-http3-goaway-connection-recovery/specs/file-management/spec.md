## MODIFIED Requirements

### Requirement: qtransc retry有界且mutation不盲重试

transport和HTTP 408/429/500/502/503/504 SHALL 从1秒指数退避到5秒并加20% jitter；连续30秒无有效response/progress后 SHALL停止。hash 202轮询不计入该窗口；SESSION/NAMESPACE_BUSY另有最多30秒窗口。401只refresh一次。move/delete在结果不确定时 SHALL NOT自动重试。

当HTTP/3协议栈能够证明请求因GOAWAY或连接不可用而尚未打开stream、没有发送给服务端时，qtransc SHALL 允许在符合连接与stream硬上限的替代连接上进行最多一次协议层重试。该连接替换重试 SHALL 复用原请求Context并受现有连续30秒无有效response/progress窗口约束；它不属于结果不确定的mutation重放。对于已经可能发送或已经收到response的mutation，qtransc SHALL继续按业务幂等性与状态查询规则处理，不得因本变更扩大盲目重试范围。

qtransc SHALL 同时支持`Retry-After`的delta-seconds和HTTP-date形式。

#### Scenario: HTTP/3请求尚未发送即遇到GOAWAY

- **WHEN** HTTP/3协议栈确认请求因旧连接GOAWAY而未打开stream、尚未发送
- **THEN** qtransc SHALL 在连接与stream硬上限内等待或建立替代连接并最多重试一次
- **AND** 该重试 SHALL NOT 被视为结果不确定的mutation重复执行

#### Scenario: PATCH响应不确定

- **WHEN** PATCH连接在response前断开
- **THEN** qtransc SHALL 先GET offset再决定重传

#### Scenario: complete响应不确定

- **WHEN** complete请求断连
- **THEN** qtransc MAY 幂等重试complete或GET session

#### Scenario: move断连

- **WHEN** move可能已经完成但response丢失
- **THEN** qtransc SHALL 报告不确定结果且不得自动重复mutation

#### Scenario: 服务返回HTTP-date Retry-After

- **WHEN** 可重试响应携带合法HTTP-date
- **THEN** qtransc SHALL 以该时间约束下次尝试
