## Why

qtransc 当前通过 `http3.Transport.NewClientConn` 直接复用单条 HTTP/3 连接，但没有完整处理服务端 GOAWAY：Nginx 达到每连接请求上限后，连接已进入 graceful shutdown，qtransc 仍把它视为可用，导致尚未发出的目录查询直接使整个任务失败。需要在不放宽 `--connections` 实际 QUIC 连接硬上限和 `--streams` 单连接并发 stream 硬上限的前提下，让连接安全排空、替换并恢复请求。

## What Changes

- HTTP/3 lane 改由标准 `http3.Transport.RoundTrip` 执行普通 HTTP 请求，使用 quic-go 对 GOAWAY、不可用连接和“请求尚未发出”的内建识别。
- 在 HTTP/3 `Dial` 层增加按 origin 共享的物理连接配额；draining 连接在完全关闭前继续占用配额，保证实际存活 QUIC 连接数始终不超过 `--connections`。
- 保留每条 lane 的 Lease 并发控制，保证任一实际 QUIC 连接的活跃请求 stream 不超过 `--streams`。
- GOAWAY 后禁止旧连接接受新 stream；已有 stream 继续排空。没有空闲物理连接配额时，替代连接等待旧连接关闭后再建立。
- 对协议栈能够证明尚未发送的请求允许在新连接上安全重试；请求结果不确定的 mutation 继续禁止盲目重放。
- 让物理连接配额跟随底层 QUIC 连接生命周期：Dial 失败或连接关闭时准确释放，连接池关闭时取消等待并回收 UDP 资源。
- 不修改 Nginx 的 `keepalive_requests`，不通过提高服务端请求上限掩盖客户端连接生命周期缺陷。

兼容性与迁移：

- 无 CLI、HTTP API、SSE、WebSocket、任务数据库或配置字段变更，现有部署无需迁移。
- 前台命令的 `--connections` 与 serve 的现有 `quic.transports`/`--transports` 输入继续表示每个 origin 的实际存活 QUIC 连接硬上限，而不是预建并始终维持的固定数量。
- 前台命令的 `--streams` 与 serve 的现有 `quic.streamsPerTransport`/`--streamspertransport` 输入继续表示单条实际 QUIC 连接的活跃 stream 硬上限。
- 当全部连接都在 draining 且仍有活跃 stream 时，新请求可能等待旧 stream 排空；这是维持物理连接硬上限的预期行为。

非目标：

- 不改变 HTTP/1.1、HTTP/2、上传/下载业务协议或服务端 GOAWAY 策略。
- 不增加 mutation 的通用自动重试，也不改变任务级 30 秒网络重试窗口之外的业务语义。
- 不要求连接切换期间以 `--connections + 1` 临时超配来换取无等待切换。

## Capabilities

### New Capabilities

- `http3-transport-lifecycle`: 定义 qtransc HTTP/3 实际连接与 stream 硬上限、GOAWAY 排空、连接替换和资源释放行为。

### Modified Capabilities

- `file-management`: 明确已证实请求尚未发出的 HTTP/3 连接替换可安全重试，并继续禁止结果不确定的 mutation 被盲目重放。

## Impact

- 主要影响 `qtransc/internal/transportpool/driver_http3.go`、连接 lane 生命周期与 `internal/netclient` 的错误/重试衔接。
- 继续使用现有 `github.com/quic-go/quic-go v0.54.0`，不新增外部协议或运行时依赖。
- client-1、client-2 等长驻 `qtransc serve` 实例在累计请求触发 Nginx GOAWAY 后将等待连接安全替换，而不再使下载规划任务失败。
