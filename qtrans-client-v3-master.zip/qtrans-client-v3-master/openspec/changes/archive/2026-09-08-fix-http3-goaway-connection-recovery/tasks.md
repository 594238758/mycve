## 1. 物理连接资源与硬上限

- [x] 1.1 在 HTTP/3 origin 生命周期内实现容量为 `MaxConnections` 的 connection limiter，使 Dial 等待同时响应请求 Context 与 origin pool Close。
- [x] 1.2 实现幂等的物理连接资源句柄，覆盖 permit、UDP socket、`quic.Transport`、`quic.Conn` 的注册与释放，并保证 Dial 失败和连接 Context 结束各自不会泄漏或重复释放。
- [x] 1.3 为 HTTP/3 origin pool 增加关闭包装，取消等待中的 Dial、关闭 ready/draining 底层连接并等待资源回收完成。

## 2. 标准 HTTP/3 Transport 接入

- [x] 2.1 将 HTTP/3 lane 从 `NewClientConn` 直连改为独立的标准 `http3.Transport.RoundTrip`，通过自定义 `Dial` 复用现有 TLS、QUIC window、0-RTT、keepalive 与建连超时配置。
- [x] 2.2 调整 HTTP/3 lane 的 Close/Healthy 语义，使单条内部 QUIC 连接 GOAWAY 后由标准 Transport 自恢复，而 lane 仅在自身关闭或资源管理器终止时失效。
- [x] 2.3 保留 `MaxLeasesPerConnection` 对完整 RoundTrip（含协议层单次重试）的占位，确认连接替换不会额外 Acquire Lease 或突破单 lane stream 上限。
- [x] 2.4 审核控制请求调用链，确保 replacement Dial 和 quic-go 内部重试复用原请求 Context、受现有连续 30 秒无有效 response/progress 窗口约束，且不扩大结果不确定 mutation 的重试范围。

## 3. 文档与编译验证

- [x] 3.1 更新 `qtransc/docs/DESIGN.md` 的传输池重试说明，记录“仅协议栈证明请求尚未发送时允许单次连接替换重试”以及连接/stream 硬上限。
- [x] 3.2 对修改的 Go 文件执行格式化，并编译 `qtransc`，确认全部生产代码通过编译；不新增或运行 test、benchmark。
