# Design

## Context

参见 `proposal.md` 的 Why。当前实现已经在 serve wire 使用 lowerCamelCase 和 HTTP 200，但旧的关联规格仍描述 snake_case/HTTP 400。错误码注册表已经删除“全部 visible=true”的总括规则，因此逐码表格成为 `retryable` 与 `visible` 的唯一有效定义；集中 Go 登记表和综合 API 文档中的部分示例尚未同步。

## Goals / Non-Goals

**Goals:**

- 让同一个外部字段在两个主规格中只有一种 wire 拼写和一种失败响应。
- 让 HTTP 与 SSE 继续从同一份 Go 登记结构取得逐码 message 和 meta，并与规范注册表完全一致。
- 保留 wire lowerCamelCase 与内部日志/传播字段 snake_case 之间的明确边界。

**Non-Goals:**

- 不重新评审注册表中各错误码的处置策略、出现位置或分类边界。
- 不改变 Qtserver 请求、业务日志 schema、CLI 或旧 WebSocket。
- 不处理本次审查发现的其他分类器、删除边界或日志共现问题。

## Decisions

### 1. serve wire 使用 lowerCamelCase，内部关联名称保持不变

仅 `POST /api/v1/tasks` JSON schema 使用 `taskPid`、`enterpriseId`、`callerVersion`。解码后继续写入内部 `TaskPID`、`EnterpriseID`、`CallerVersion`，HTTP header 和结构化日志继续使用 `X-Task-PID`、`X-Enterprise-ID`、`taskpid`、`enterprise_id`、`caller_version`。

选择该边界是因为新 serve 契约已经一次性切换 wire 字段，而关联传播和日志 schema 明确不在此次兼容性改造范围。备选方案是连内部字段一起改名，但会扩大到 Qtserver、Nginx 和业务日志，且没有外部收益。

### 2. 非法旧字段走统一失败信封

旧 snake_case 字段继续由严格 JSON 解码视为未知字段，并返回 HTTP 200 的规范“请求无效”信封。不增加别名、兼容窗口或自动转换，避免一个接口长期接受两套 schema。

### 3. 元数据逐码照抄规范注册表

实现阶段逐项对照 `qtransc-error-codes.md` 表格更新集中 `codeDefinitions`。不在 handler 或 SSE 转换处增加覆盖逻辑；两条输出路径继续调用同一登记结构。注册表当前明确的四个新增可重试码为 `30204`、`30205`、`30207`、`30208`，逐码 `visible=false` 的条目也在集中登记表中显式保留 false。

备选方案是只修四个 `retryable`，但会留下已经确认的 `visible` 漂移，因此不采用。

### 4. 综合 API 文档只修代表性示例

逐个核对 `qtransc-apis.md` 中出现 `meta` 的示例，仅把值改为对应注册表条目，不新增完整码表。该文件属于对外文档，修改结果必须由维护者人工复核。

## Risks / Trade-offs

- [部分错误响应的 `visible` 将由当前实现的 true 变为 false] → 这是按已批准逐码注册表纠正实现；调用方应读取布尔值而不是假定全为 true。
- [`retryable=true` 只表达调用方处置策略，不保证原任务可直接再次启动] → 本变更严格服从注册表，不顺带改变任务状态机或自动重试实现。
- [旧 snake_case 调用方继续失败] → 在文档和 delta 中明确这是已经生效的一次性迁移，不增加双写兼容。

## Migration Plan

1. 归档时把 delta 同步进 `transfer-task-correlation` 主规格。
2. 更新集中错误登记和综合 API 文档示例。
3. 静态核对每个错误码的 message、retryable、visible 与注册表相同，并核对 HTTP/SSE 共用该登记结构。
4. 仅在 `qtransc` 模块执行 `go build ./...`。

若需要回滚，应整体回滚规格、集中登记和 API 示例，不能只回滚其中一层。
