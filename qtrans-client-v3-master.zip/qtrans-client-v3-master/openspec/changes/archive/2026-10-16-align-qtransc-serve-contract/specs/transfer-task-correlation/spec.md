# Spec Delta

## MODIFIED Requirements

### Requirement: serve 创建任务 API 接收可选 taskpid

qtransc `serve` 的 `POST /api/v1/tasks` 请求体 SHALL 接受可选 string 字段 `taskPid`。qtransc SHALL 先去除输入值首尾的 ASCII SP 和 HTAB，内部空白 SHALL 保留。字段缺失、值为空字符串或 trim 后为空时 SHALL 使用空字符串作为内部 `taskpid` 创建任务；该情况 SHALL NOT 使任务创建、启动或传输失败。内部 `taskpid` SHALL 是不透明的日志关联值，SHALL NOT 具有 task ID、用户 ID、授权标识或幂等键语义。

归一化后的非空 `taskPid` SHALL 至多为 128 bytes、是合法 UTF-8，且只包含可安全作为 HTTP header field value 传播的文本。不符合输入格式时，serve API SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封，且不得创建任务。旧字段 `taskpid` SHALL 作为未知字段被拒绝。qtransc 的 CLI 子命令 SHALL NOT 新增对应参数，非 serve 创建的任务 SHALL 使用空字符串作为内部 `taskpid`。

#### Scenario: serve 调用方传入 taskpid

- **WHEN** 调用方使用合法非空 `taskPid` 创建 upload 或 download 任务
- **THEN** qtransc SHALL 保存该 trim 后的 string 作为本任务的内部 `taskpid`
- **AND** `taskpid` SHALL NOT 改变任务 ID、文件选择或传输结果

#### Scenario: serve 调用方传入首尾空白

- **WHEN** 调用方使用首尾含 ASCII SP 或 HTAB、trim 后合法的 `taskPid` 创建任务
- **THEN** qtransc SHALL 去除首尾 SP 和 HTAB 并保留内部空白
- **AND** 后续 header、原始事件和最终日志 SHALL 使用相同的归一化值

#### Scenario: serve 调用方省略 taskpid

- **WHEN** 创建任务请求没有 `taskPid` 字段、该字段是空字符串或 trim 后为空
- **THEN** qtransc SHALL 正常创建和启动任务
- **AND** 该任务的内部日志关联值 SHALL 是空字符串

#### Scenario: CLI 创建任务

- **WHEN** 用户通过非 serve CLI 子命令创建传输任务
- **THEN** CLI SHALL NOT 提供对应参数
- **AND** 该任务所有需要共现的日志 SHALL 使用空字符串 `taskpid`

#### Scenario: 非法 taskpid

- **WHEN** serve 请求提供 trim 后超过 128 bytes、不是合法 UTF-8 或包含非法 HTTP field-value 字符的非空 `taskPid`
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务、截断、改写或部分传播该值

#### Scenario: 旧 taskpid 字段

- **WHEN** serve 请求使用旧字段 `taskpid`
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务

### Requirement: serve 创建任务 API 接收可选 enterprise_id

qtransc `serve` 的 `POST /api/v1/tasks` 请求体 SHALL 接受可选 string 字段 `enterpriseId`。qtransc SHALL 先去除输入值首尾的 ASCII SP 和 HTAB，内部空白 SHALL 保留；字段缺失、值为空字符串或 trim 后为空时 SHALL 使用空字符串作为内部 `enterprise_id` 创建任务。归一化后的非空值 SHALL 至多为 128 bytes、是合法 UTF-8，且只包含可安全作为 HTTP header field value 传播的文本。不符合输入格式或显式使用 `null`、number、boolean、array 或 object 时，serve API SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封，且不得创建任务。旧字段 `enterprise_id` SHALL 作为未知字段被拒绝。

内部 `enterprise_id` SHALL 是不透明的外部企业日志关联标签，SHALL NOT 具有可信企业身份、tenant、principal、授权标识或幂等键语义。qtransc 的 CLI 子命令 SHALL NOT 新增对应参数，非 serve 创建的任务 SHALL 使用空字符串。创建任务响应、任务详情与摘要、SSE、WebSocket 和其他 API 响应 SHALL NOT 返回 `enterpriseId` 或内部 `enterprise_id`。

#### Scenario: serve 调用方传入 enterprise_id

- **WHEN** 调用方使用首尾含 ASCII SP 或 HTAB、trim 后合法的非空 `enterpriseId` 创建 upload 或 download 任务
- **THEN** qtransc SHALL 保存 trim 后的 string 作为内部 `enterprise_id` 并保留内部空白
- **AND** 后续请求 header、原始事件和最终日志 SHALL 使用相同的归一化值

#### Scenario: serve 调用方省略 enterprise_id

- **WHEN** 创建任务请求没有 `enterpriseId`、值为空字符串或 trim 后为空
- **THEN** qtransc SHALL 正常创建任务
- **AND** 该任务的内部企业关联标签 SHALL 是空字符串

#### Scenario: 非法 enterprise_id

- **WHEN** serve 请求的 `enterpriseId` 在 trim 后超过 128 bytes、不是合法 UTF-8、包含非法 HTTP field-value 字符或不是 string
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务、截断、改写或部分传播该值

#### Scenario: 旧 enterprise_id 字段

- **WHEN** serve 请求使用旧字段 `enterprise_id`
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务

#### Scenario: CLI 创建任务

- **WHEN** 用户通过非 serve CLI 子命令创建传输任务
- **THEN** CLI SHALL NOT 提供对应参数
- **AND** 该任务所有需要共现的日志 SHALL 使用空字符串 `enterprise_id`

#### Scenario: 查询任务不暴露企业标签

- **WHEN** 调用方创建带非空 `enterpriseId` 的 serve 任务后查询任务或订阅实时事件
- **THEN** 对应 API、SSE 和 WebSocket 输出 SHALL NOT 包含 `enterpriseId` 或 `enterprise_id`

### Requirement: serve 创建任务 API 接收可选 caller_version

qtransc `serve` 的 `POST /api/v1/tasks` 请求体 SHALL 接受可选 string 字段 `callerVersion`。qtransc SHALL 去除其首尾 ASCII SP 和 HTAB、保留内部字符，并在归一化后要求值为合法 UTF-8、至多 256 bytes 且可安全作为 HTTP header field value 传播。字段缺失、值为空字符串或 trim 后为空时 SHALL 使用空字符串作为内部 `caller_version` 创建任务；显式 `null`、非 string、超长或包含非法 header value 字符时 SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封，且不得创建任务。旧字段 `caller_version` SHALL 作为未知字段被拒绝。

内部 `caller_version` SHALL 是创建任务的 GUI 或 Agent 自报版本，仅用于诊断日志。它 SHALL NOT 具有客户端二进制版本、身份、授权、tenant、任务 ID、幂等键或能力协商语义。创建任务响应、任务详情与摘要、SSE、WebSocket 和其他 API 响应 SHALL NOT 返回 `callerVersion` 或内部 `caller_version`。除 `upload2`/`download2 --callerversion` 与 serve 创建任务 API 外，其他 qtransc CLI 创建的任务 SHALL 使用空字符串。

#### Scenario: serve 调用方传入 caller_version

- **WHEN** 调用方以合法 string `callerVersion` 创建 upload 或 download 任务
- **THEN** qtransc SHALL 在任务生命周期内保存归一化后的内部 `caller_version`
- **AND** 该值 SHALL NOT 改变任务 ID、文件选择、授权或传输结果

#### Scenario: serve 调用方省略 caller_version

- **WHEN** 创建任务请求没有 `callerVersion`、值为空字符串或 trim 后为空
- **THEN** qtransc SHALL 正常创建任务
- **AND** 该任务的内部 `caller_version` SHALL 是空字符串

#### Scenario: serve 调用方提交非法 caller_version

- **WHEN** `callerVersion` 是 `null`、非 string、trim 后超过 256 bytes、不是合法 UTF-8 或包含非法 HTTP header value 字符
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务、截断或部分传播该值

#### Scenario: 旧 caller_version 字段

- **WHEN** serve 请求使用旧字段 `caller_version`
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务

#### Scenario: 查询任务不暴露 caller_version

- **WHEN** 调用方创建带非空 `callerVersion` 的 serve 任务后查询任务或订阅实时事件
- **THEN** 对应 API、SSE 与 WebSocket 输出 SHALL NOT 包含 `callerVersion` 或 `caller_version`
