# Proposal

## Why

已归档的 qtransc serve 改造没有同步修订 `transfer-task-correlation` 中的旧 snake_case 请求字段和 HTTP 400 约定，同时 `serveapi` 的错误处置元数据仍与唯一权威注册表逐码不一致。这使主规格、对外文档与实际 wire 行为无法形成单一契约。

## What Changes

- 修订 `transfer-task-correlation` 的 serve 创建任务请求契约：外部 JSON 字段统一为 `taskPid`、`enterpriseId`、`callerVersion`，非法值统一使用 HTTP 200 的 `30001` 失败信封；内部字段、HTTP header 和业务日志继续使用既有命名。
- **BREAKING**：明确拒绝旧请求字段 `taskpid`、`enterprise_id`、`caller_version`；调用方必须一次性迁移到 lowerCamelCase。代码当前已经执行该行为，本次消除残留规格冲突。
- 以 `qtransc/docs/qtransc-error-codes.md` 的逐码表格为准，同步 `serveapi` 中所有 `retryable` 与 `visible` 值；重点补齐 `30204`、`30205`、`30207`、`30208` 的 `retryable=true`。
- 修正 `qtransc-apis.md` 中与注册表冲突的代表性错误示例；不复制完整码表，并保留对外文档人工复核要求。
- 不改变错误码、默认 message、出现位置、任务终态、分类边界、CLI、Qtserver 或旧 WebSocket 契约。

## Capabilities

### New Capabilities

无。

### Modified Capabilities

- `transfer-task-correlation`：使 serve 创建任务的三个辅助关联字段及非法请求响应与统一 lowerCamelCase、HTTP 200 契约一致。

## Impact

- OpenSpec：`transfer-task-correlation`。
- qtransc：`internal/serveapi` 集中错误码登记表。
- 对外文档：`qtransc/docs/qtransc-apis.md`，修改后需要维护者人工复核。
- 调用方：旧 snake_case 字段不再属于有效 serve 请求；失败 `meta` 将严格采用注册表逐码值。
- 不新增或运行测试、benchmark；实现阶段仅执行 `qtransc` 模块必要的 `go build ./...`。
