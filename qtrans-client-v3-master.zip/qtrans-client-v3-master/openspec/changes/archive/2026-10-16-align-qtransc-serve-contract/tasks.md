# Tasks

## 1. Serve 关联字段契约

- [x] 1.1 核对 `serveapi.TaskCreateRequest` 的 wire 字段、严格字段白名单和 HTTP 失败入口均符合 delta 中的 `taskPid`、`enterpriseId`、`callerVersion` 与 HTTP 200 约定，并用静态搜索确认旧 snake_case 只保留在内部模型、日志和 Qtserver 协议中

## 2. 错误处置元数据

- [x] 2.1 按 `qtransc-error-codes.md` 逐码更新 `serveapi` 集中登记表的 `retryable` 与 `visible`，并静态核对 23 个失败码的 code、message 和 meta 均无缺失、额外项或取值漂移
- [x] 2.2 修正 `qtransc-apis.md` 中所有代表性失败示例的 meta，使其与对应注册表条目一致，确认未复制完整码表，并在交付说明中标记该对外文档需要人工复核

## 3. 验证

- [x] 3.1 执行 OpenSpec strict validation，确认 change delta 结构有效且不再与 `qtransc-serve-api-contract` 的 lowerCamelCase/HTTP 200 规则冲突
- [x] 3.2 不运行测试或 benchmark，仅在 `qtransc` 模块执行 `go build ./...` 并确认编译成功

## Workflow follow-up

- 实现完成并经维护者确认后归档 change，使 delta 同步进入主规格。
