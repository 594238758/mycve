# Change: 递归删除与统一错误契约

## Why

`qtransc delete` 当前仅能删除单个文件、符号链接或空目录；用户删除目录树时需要自行逐层处理，既不符合命令行直觉，也无法清楚报告部分完成的结果。

同时，CLI、`serve` HTTP API 和任务事件对相同故障的展示不一致：有些错误直接泄露服务端英文原文，有些只有数字错误码，认证、权限、路径和后端依赖故障难以快速辨认或与服务端日志关联。

## What Changes

- 为 `qtransc delete` 增加显式的 `--recursive` / `-r` 模式。该模式在客户端以现有单节点文件 API 按后序遍历执行，不新增或修改 qtserver 的递归删除 API。
- 保持未带 `--recursive` 的删除语义不变；根目录仍不可删除，最终符号链接仅删除链接本身而不会跟随目标。
- 为递归删除定义遍历上限、并发变化、部分完成、JSON 输出和退出状态的稳定行为。
- 新增统一的客户端错误契约：人类可读 CLI 错误采用 `Error [REASON_CODE]: 中文说明`，并在 CLI JSON、`serve` HTTP 错误、任务查询结果及 SSE 事件中提供可选的稳定 `reason_code`。
- 保留现有 HTTP 状态码、数值 `code`、服务端原因码以及旧 WebSocket 帧的兼容性；不在错误中暴露用户名、密码、令牌或 OAuth 密钥。

## Capabilities

### New Capabilities

- `client-error-contract`: 定义 qtransc CLI 与 serve 模式共享的稳定错误原因码、显示格式、认证故障脱敏和传递规则。

### Modified Capabilities

- `file-management`: 将 qtransc 的显式递归删除纳入规范，并规定其安全遍历、部分完成和 JSON 输出行为；qtserver 单节点删除 API 保持不变。

## Impact

- `qtransc/cmd/qtransc`：新增递归删除编排和统一 CLI 错误格式。
- `qtransc/internal/handlers`、`qtransc/internal/types`、任务事件收集：向 serve 响应、任务状态和 SSE 暴露可选 `reason_code`。
- 不修改 qtserver 文件 API、CLI 命令名、已有参数名、HTTP 状态码、既有数值 `code` 或 upload2/download2 WebSocket 协议。
- 现有脚本若逐字匹配人类可读 stderr，需要适配新的稳定错误格式；`--json` 消费者可继续读取既有字段，并可选择读取新增 `reason_code`。
