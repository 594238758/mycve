## Context

参见 [proposal.md](proposal.md) 的动机。qtserver 现有 `POST /files/delete` 有意只执行单节点移除：这保证 final symlink 可安全 unlink，也让服务端在并发文件系统变化时只对一次 syscall 的结果负责。qtransc 目前将部分 `qtserverapi.APIError` 直接显示为英文字符串，serve 的一般响应和任务事件也没有统一的机器可读错误原因。

## Goals / Non-Goals

**Goals:**

- 在不改变 qtserver 删除 API 的前提下，为 qtransc 提供明确选择的目录树删除。
- 令一个错误在 CLI 文本、CLI JSON、serve HTTP、任务查询与 SSE 中可以用同一稳定原因码关联。
- 将认证错误解释为用户可执行的中文提示，同时确保凭据不会从常规或 debug 输出泄露。

**Non-Goals:**

- 不实现服务端原子递归删除、不引入 namespace lock，也不承诺递归删除可回滚。
- 不修改文件 API 的 HTTP status、服务端 `reason_code` 或旧 upload2/download2 WebSocket 协议。
- 不试图从认证服务响应中区分“用户名错误”与“密码错误”。

## Decisions

### 1. 递归删除由 CLI 以“先删、遇非空再列举”的后序方式编排

客户端先对每个路径调用现有单节点 delete；返回 `DIRECTORY_NOT_EMPTY` 才 list 直接子项并递归，全部子项完成后再次删除目录。这使 final symlink 在首次 delete 即被 unlink，不会被误当目录进入，也保留服务端对单节点竞争、权限与特殊节点的权威判断。

备选方案是先完整 list 后删除。该方案看似便于预先检查限制，却会把 final directory symlink 当作可展开目录，并在预扫描与删除之间扩大竞态窗口，因此不采用。

### 2. 递归删除是非原子的，部分完成使用专门结果

单节点 delete 成功即不可由客户端回滚。因此实现记录 `deleted_nodes`、首个失败路径和是否已发生成功删除；只有已开始删除后失败才转换为 `RECURSIVE_DELETE_PARTIAL`。初始请求的错误则保留原始原因码，避免将“目标不存在”等无副作用失败误报为部分删除。

枚举限制采用现有递归传输的一致边界（128 层、200000 条目）。由于安全的删除流程不能在变更前完整规划，后续命中限制仍可能产生部分完成；这比继续删除未知范围更安全。

### 3. 对竞争变化采取有限重枚举，而不是 mutation 重试

列表后子项被其他操作者删除时，子项 `NOT_FOUND` 可视为达到该子项的删除目标。目录再次返回 `DIRECTORY_NOT_EMPTY` 时，对该目录最多重新枚举三次，之后报告部分完成。任何已经发出的、结果可能不确定的 delete 或 move 都不会自动重试，以免把未知结果变为额外破坏。

### 4. 引入集中式错误归一化而非逐命令解析英文文本

新增内部错误类型/归一化函数承载 `reason_code`、面向用户的中文说明以及可选安全诊断。它优先读取 `qtserverapi.APIError.ReasonCode` 和已知 auth/capability 错误；无法分类时使用稳定通用客户端码。各直接命令、serve response、任务状态和事件从该结构取值，而不是从 `Error()` 文本推测语义。

服务端给出的原因码原样保留；客户端增加的码与服务端码位于同一字段但名称空间通过稳定标识符区分。该方式保持 HTTP API 和既有 JSON 消费者的向后兼容，因为 `reason_code` 仅为可选新增字段。

### 5. 控制面错误按边界写入 reason_code

`GeneralResponse` 增加可选 `reason_code`，任务汇总、详情和 SSE 所用状态结构也增加可选字段。任务的错误被设置、清除或重启时，由同一归一化结果同步更新文本与原因码，从而避免 REST 与 SSE 漂移。旧 WebSocket 独立于该控制面，不改字段。

## Risks / Trade-offs

- [并发写入使目录反复非空] → 每目录有限重枚举；超过次数后停止而非无限循环。
- [达到递归限制已产生删除] → 明确 `RECURSIVE_DELETE_PARTIAL`、计数与失败路径；不继续扩展破坏范围。
- [错误码覆盖不足] → 对已知结构化/API/auth/capability 错误优先分类，对其余错误使用稳定通用码且保留仅 debug 可见的安全诊断。
- [已有脚本匹配 stderr 文本] → 保留 `Error:` 前缀并增加方括号原因码；机器使用推荐迁移至 `--json` 的 `reason_code`。
- [敏感信息出现在包装错误中] → 显式从人类消息与诊断中剔除令牌、密码和 Authorization 内容，不把认证请求原文拼入输出。

## Migration Plan

1. 先发布兼容字段与新的 CLI 显示格式：HTTP status、数值 `code`、服务端 JSON 字段和 WebSocket 保持不变。
2. 使用 `qtransc delete --recursive` 逐步替代外部 shell 递归脚本；不带标志的 delete 继续是单节点操作。
3. 运维与自动化读取 `reason_code` 进行分类，逐步停止依赖英文 `message`。
4. 如需回滚，移除客户端递归编排与新增可选字段即可；已完成的单节点删除无法回滚，故执行前仍要求用户显式传入 `--recursive`。
