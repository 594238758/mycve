## ADDED Requirements

### Requirement: qtransc 显式递归删除远端目录树

`qtransc delete <remote-path>` SHALL 保持调用 canonical 单节点 delete API 的现有语义。`qtransc delete --recursive <remote-path>` 与 `qtransc delete -r <remote-path>` SHALL 显式启用客户端递归删除；它 SHALL 不调用不存在的递归服务端 API，也不得改变 qtserver 单节点 delete API 的行为。两种模式都 SHALL 拒绝根路径 `/`。

递归模式 SHALL 先尝试删除当前节点；仅当该尝试返回 `DIRECTORY_NOT_EMPTY` 时，才 list 其直接子项、处理子项并在全部子项处理后再次删除该目录。它 SHALL 以该后序规则逐节点调用既有单节点 delete API，且 SHALL NOT 跟随 final symlink；final symlink、broken symlink 和 symlink loop SHALL 仅删除链接节点。特殊节点无法删除时 SHALL 导致递归操作失败。

#### Scenario: 未带递归标志删除非空目录

- **WHEN** 用户执行 `qtransc delete /tree` 且 `/tree` 是非空目录
- **THEN** qtransc SHALL 保留服务端的 409 `DIRECTORY_NOT_EMPTY` 结果
- **AND** SHALL NOT 枚举或删除任何 descendant

#### Scenario: 显式递归删除目录树

- **WHEN** 用户执行 `qtransc delete --recursive /tree` 且 `/tree` 下所有节点均可删除
- **THEN** qtransc SHALL 在删除 `/tree` 前删除其全部 descendant
- **AND** SHALL 以成功状态退出

#### Scenario: 递归删除 final symlink

- **WHEN** 递归遍历遇到 final symlink、broken symlink 或 symlink loop
- **THEN** qtransc SHALL 仅删除该链接节点
- **AND** SHALL NOT list、跟随或删除链接目标

#### Scenario: 递归删除根路径

- **WHEN** 用户执行 `qtransc delete --recursive /`
- **THEN** qtransc SHALL 在发起文件 API 请求前失败

### Requirement: qtransc 递归删除限制并明确部分完成结果

递归删除 SHALL 将目录深度限制为 128、累计枚举条目限制为 200000；任何 list 响应的 `truncated=true` SHALL 被视为不可安全完成的失败。初始目标不存在 SHALL 失败；已由并发操作删除的已枚举 descendant SHALL 作为已删除继续处理。客户端不得对任何已发出且结果不确定的 move 或 delete mutation 自动重试。

目录与其他写入并发变化时，客户端 SHALL 为因 `DIRECTORY_NOT_EMPTY` 而重新出现子项的目录重新枚举，单个目录最多重新枚举三次；超出该次数 SHALL 失败。因为删除从第一个成功单节点删除开始不可回滚，达到限制、遇到不可删除节点、目录持续变化或 mutation 结果不确定时，qtransc SHALL 保留已删除节点并以 `RECURSIVE_DELETE_PARTIAL` 报告部分完成、已删除节点数和首个失败路径。失败在任何节点删除前发生时，SHALL 报告原始稳定原因码而非 `RECURSIVE_DELETE_PARTIAL`。

#### Scenario: 枚举结果被截断

- **WHEN** 递归删除所需的任一 list 返回 `truncated=true`
- **THEN** qtransc SHALL 停止后续删除
- **AND** 若此前已删除节点，SHALL 以 `RECURSIVE_DELETE_PARTIAL` 非零退出

#### Scenario: 已枚举子项被并发删除

- **WHEN** 某个已枚举 descendant 的 delete 返回 `NOT_FOUND`
- **THEN** qtransc SHALL 将该 descendant 视为已不存在并继续处理其余节点

#### Scenario: 特殊节点导致中断

- **WHEN** 递归删除遇到服务端拒绝删除的特殊节点且此前已有节点被删除
- **THEN** qtransc SHALL 停止后续删除并以 `RECURSIVE_DELETE_PARTIAL` 非零退出
- **AND** 输出 SHALL 标识该特殊节点路径

#### Scenario: 持续并发写入目录

- **WHEN** 同一目录已三次重新枚举后仍在实际删除时返回 `DIRECTORY_NOT_EMPTY`
- **THEN** qtransc SHALL 停止递归删除并以 `RECURSIVE_DELETE_PARTIAL` 非零退出

### Requirement: 递归删除 JSON 输出是客户端定义的单一结果

`qtransc delete --recursive --json` 成功时 SHALL 在 stdout 输出单一有效 JSON 对象，包含 `code`、`path`、`recursive=true` 和 `deleted_nodes`。部分完成时 SHALL 在 stdout 输出单一有效 JSON error object，包含既有 `code`、`reason_code=RECURSIVE_DELETE_PARTIAL`、`message`、`path`、`deleted_nodes` 和 `failed_path`，并以非零状态退出。未带递归标志的 `delete --json` SHALL 继续原样保留服务端 JSON 结构，不得用该客户端对象替代。

#### Scenario: 递归 JSON 成功

- **WHEN** 用户执行 `qtransc delete -r --json /tree` 并成功完成
- **THEN** stdout SHALL 只包含一个含 `recursive=true` 与 `deleted_nodes` 的 JSON 对象

#### Scenario: 递归 JSON 部分完成

- **WHEN** 用户执行 `qtransc delete -r --json /tree` 且部分节点已经删除后失败
- **THEN** stdout SHALL 只包含一个含 `reason_code=RECURSIVE_DELETE_PARTIAL` 和 `failed_path` 的 JSON error object

## MODIFIED Requirements

### Requirement: qtransc 文件管理CLI使用canonical能力

qtransc SHALL 提供 list、mkdir、move 和 delete 对 canonical API 的调用；create SHALL 只作为 API 能力，本 change SHALL NOT 增加 touch/create CLI。文本输出用于人类，`--json` SHALL 保留服务端结构，包括 symlink 真实 type 和非递归 delete 的 `DIRECTORY_NOT_EMPTY` 错误。`delete --recursive` 的客户端定义 JSON 结果服从递归删除要求。所有文件管理 CLI 错误 SHALL 服从 `client-error-contract` 的稳定 `reason_code` 与人类可读格式。

#### Scenario: 文本list

- **WHEN** 用户执行qtransc list
- **THEN** stdout SHALL 展示人类可读结果，正常symlink按target_type展示

#### Scenario: JSON list

- **WHEN** 用户执行qtransc list --json且请求成功
- **THEN** stdout SHALL 输出单一有效JSON对象并保留entry字段

#### Scenario: delete 非空目录的 JSON 错误

- **WHEN** 用户执行 qtransc delete --json 且服务返回 409 `DIRECTORY_NOT_EMPTY`
- **THEN** qtransc SHALL 以非零状态退出并原样保留服务端结构化错误

#### Scenario: 调用旧CLI命令

- **WHEN** 用户调用`dlist|ulist|umkdir|umove|udelete`
- **THEN** qtransc SHALL 按未知命令失败且 SHALL NOT 保留兼容别名
