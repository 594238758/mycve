## Purpose

为 qtransc 的直接命令与 serve 控制面提供统一、脱敏且可自动处理的错误原因码，使人类用户和运维系统能稳定识别同一类故障。

## ADDED Requirements

### Requirement: CLI 使用稳定原因码和中文可读错误

qtransc 的直接命令在非 JSON 模式发生可报告错误时 SHALL 在 stderr 使用 `Error [REASON_CODE]: 中文说明` 格式。`REASON_CODE` SHALL 是稳定的大写下划线标识符；来自 qtserver 结构化错误的 `reason_code` SHALL 原样传递。客户端自身产生的错误 SHALL 使用稳定客户端原因码，至少包括 `CLI_INVALID_ARGUMENT`、`AUTH_CONFIG_INVALID`、`AUTH_LOGIN_REJECTED`、`AUTH_LOGIN_FAILED`、`AUTH_REFRESH_FAILED`、`ANONYMOUS_READ_UNAVAILABLE`、`ANONYMOUS_WRITE_UNAVAILABLE`、`CAPABILITY_UNAVAILABLE`、`SERVER_UNAVAILABLE`、`RECURSIVE_DELETE_PARTIAL` 和 `MUTATION_RESULT_UNKNOWN`。

`--debug` SHALL 保留额外的底层诊断信息，但所有模式均 SHALL NOT 输出用户名、密码、access token、refresh token、OAuth client secret 或 Authorization header。用户名密码认证被拒绝时 SHALL 使用 `AUTH_LOGIN_REJECTED`，不得声称是用户名或密码中某一项错误。

#### Scenario: 路径不存在

- **WHEN** 直接 CLI 命令收到 qtserver 的 `NOT_FOUND`
- **THEN** stderr SHALL 输出 `Error [NOT_FOUND]:` 开头的中文说明

#### Scenario: 用户名密码认证被拒绝

- **WHEN** qtransc 的用户名密码登录被认证服务拒绝
- **THEN** stderr SHALL 输出 `Error [AUTH_LOGIN_REJECTED]:` 开头的中文说明
- **AND** SHALL NOT 指出用户名或密码中哪一项错误

#### Scenario: 调试模式的敏感信息保护

- **WHEN** 用户以 `--debug` 执行命令且认证请求失败
- **THEN** qtransc SHALL 提供额外诊断
- **AND** SHALL NOT 输出任何认证凭据或令牌值

### Requirement: CLI JSON 错误携带稳定 reason_code

当 CLI 自身生成 JSON error object 时，它 SHALL 包含既有 `code`、人类可读 `message` 和稳定 `reason_code`。服务端已经提供结构化 JSON error body 时，CLI SHALL 保留该 body；服务端 `reason_code` SHALL 不被客户端重命名或删除。该要求 SHALL NOT 改变 upload2/download2 旧 WebSocket 帧。

#### Scenario: 客户端参数错误的 JSON 输出

- **WHEN** 带 `--json` 的直接命令因本地参数无效而失败
- **THEN** stdout SHALL 输出含 `reason_code=CLI_INVALID_ARGUMENT` 的单一有效 JSON error object

#### Scenario: 服务端结构化错误的 JSON 输出

- **WHEN** 带 `--json` 的文件管理命令收到 qtserver 结构化 JSON error body
- **THEN** stdout SHALL 保留该 body及其原始 `reason_code`

### Requirement: serve 控制面透出稳定 reason_code

qtransc `serve` 的 HTTP 错误响应 SHALL 在不改变既有数值 `code`、HTTP status 和 `message` 的前提下，增加可选 `reason_code`。任务查询的 summary/detail 与其 SSE 事件在任务具有终止错误时 SHALL 透出同一稳定 `reason_code`；任务重启或错误被清除时 SHALL 同时清除该字段。无法分类的本地错误 SHALL 使用稳定的通用客户端原因码，而不得只依赖易变的英文错误文本。

#### Scenario: serve HTTP 参数错误

- **WHEN** serve HTTP 路由因客户端参数无效而返回错误
- **THEN** 响应 SHALL 保留既有数值 `code` 和 `message`
- **AND** SHALL 包含 `reason_code=CLI_INVALID_ARGUMENT`

#### Scenario: 任务失败事件

- **WHEN** serve 管理的上传或下载任务以可分类错误终止
- **THEN** 随后的任务查询和终止 SSE 事件 SHALL 包含同一 `reason_code`

#### Scenario: 旧 WebSocket 协议兼容

- **WHEN** upload2 或 download2 旧 WebSocket 客户端收到错误帧
- **THEN** 帧字段和既有错误格式 SHALL 保持不变
