## 1. 统一错误契约

- [x] 1.1 增加集中式错误归一化和脱敏显示，覆盖 API、认证、能力与本地参数错误；以 qtransc 编译成功验证。
- [x] 1.2 将直接 CLI 命令的文本和客户端 JSON 错误接入稳定 `reason_code`；以 qtransc 编译成功验证。
- [x] 1.3 为 serve HTTP 错误、任务状态和 SSE 事件增加可选 `reason_code`，并保持旧 WebSocket 不变；以 qtransc 编译成功验证。

## 2. 递归删除

- [x] 2.1 为 `qtransc delete` 增加 `--recursive` / `-r`，实现后序单节点删除、final symlink 安全性和根路径拒绝；以 qtransc 编译成功验证。
- [x] 2.2 实现递归删除的条目/深度限制、有限重枚举、并发缺失处理与部分完成报告；以 qtransc 编译成功验证。
- [x] 2.3 实现递归删除专用 JSON 结果，同时保留非递归 delete 的原始服务端 JSON body；以 qtransc 编译成功验证。

## 3. 验证与归档

- [x] 3.1 运行 `openspec validate recursive-delete-and-unified-errors --strict`，并执行 qtransc 与 qtserver 编译检查。
- [x] 3.2 同步并归档完成的 OpenSpec changes，确认归档后主规格校验通过。
- [x] 3.3 审阅差异并创建本地 Git 提交，确认工作区仅保留不属于本次变更的内容。
