# service-capability-discovery Specification

## Purpose
定义 Qtserver 的依赖生命周期、capabilities 发现、配置和迁移边界，以及 qtransc 的预检行为。
## Requirements

### Requirement: fatal dependency 故障触发 graceful shutdown

Qtserver SHALL 每五秒检查 Redis、Redis AOF persistence 和已启用 `oauth2-introspection` provider 的健康状态。健康检查或业务命令发现 dependency 自身的 connection refused、连接断开、TLS、I/O timeout、认证、AOF 状态、HTTP status 或协议错误时，服务 SHALL 在第一次故障时立即开始 shutdown，SHALL NOT 等待连续多次失败或重试阈值。调用方主动取消或调用方 context deadline 到期所产生的 `context.Canceled` 或 `context.DeadlineExceeded` SHALL 只结束当前请求，不得仅凭该错误触发 fatal shutdown；独立健康检查在自身 deadline 内未完成仍 SHALL 作为 dependency timeout 触发 shutdown。

服务 SHALL 停止接受新连接，给予现有请求最多 30 秒完成，然后以非零状态退出。直接观察到 introspection provider 故障且仍可响应的认证请求 SHALL 返回 HTTP 503 `DEPENDENCY_UNAVAILABLE`；其他尚可响应且未完成的业务请求 SHALL 返回 HTTP 500 `INTERNAL_ERROR`，而不是降级结果。

#### Scenario: 运行期 Redis 断开

- **WHEN** Redis 健康检查或业务命令检测到连接级故障
- **THEN** Qtserver SHALL 触发 graceful shutdown
- **AND** SHALL NOT 等待 Redis 恢复后继续服务

#### Scenario: 业务请求 deadline 到期

- **WHEN** Redis 命令因调用该命令的业务请求 context 已到期而返回 `context.DeadlineExceeded`
- **THEN** 当前请求 SHALL 结束
- **AND** Qtserver SHALL NOT 仅凭该错误触发 graceful shutdown

#### Scenario: 独立 Redis 健康检查超时

- **WHEN** Redis 未能在周期健康检查自身的 deadline 内完成检查
- **THEN** Qtserver SHALL 将其判定为 dependency timeout 并触发 graceful shutdown

#### Scenario: 运行期 Redis AOF 故障

- **WHEN** Redis persistence 健康检查或写命令检测到 AOF 已禁用或写入失败
- **THEN** Qtserver SHALL 触发同一 graceful shutdown 流程

#### Scenario: 正常 signal 停止

- **WHEN** Qtserver 收到 SIGINT 或 SIGTERM 且没有 fatal dependency
- **THEN** graceful shutdown 完成后的进程退出码 SHALL 为 0

#### Scenario: 运行期 introspection provider 故障

- **WHEN** 周期 probe 或业务 introspection 检测到 provider 故障
- **THEN** Qtserver SHALL 触发同一 graceful shutdown 流程
- **AND** SHALL NOT 等待第二次健康检查确认
- **AND** SHALL NOT 等待 provider 恢复后继续服务

### Requirement: 已完成文件系统修改不因依赖故障回滚

文件系统操作达到 rename、unlink 等业务成功点后，随后检测到 Redis 故障 SHALL NOT 回滚已经完成的正式文件修改。服务 SHALL best-effort 向当前请求返回成功，再触发 shutdown；如果来不及响应，客户端 MAY 看到连接断开。

#### Scenario: complete rename 后 Redis 断开

- **WHEN** complete 已原子发布正式文件但尚未写 committed response 时 Redis 断开
- **THEN** Qtserver SHALL 保留已发布文件且 SHALL NOT 反向 rename
- **AND** SHALL 触发 graceful shutdown

#### Scenario: delete unlink 后 Redis 断开

- **WHEN** delete 已完成不可逆 unlink 后检测到 Redis 故障
- **THEN** 删除 SHALL 保持生效
- **AND** 服务 SHALL 尽量返回成功后退出

### Requirement: capabilities 在健康运行时始终可访问

Qtserver 健康运行期间 SHALL 无认证注册 `/qtserver/v1/capabilities`。响应 SHALL 包含 `qtserver_version`、`api_version`、capabilities 的 `enabled`/`available`、limits 和 algorithms。进程健康时所有 enabled capability SHALL 具有 `available=true`；fatal dependency 被检测后不承诺该接口仍可查询。

#### Scenario: 查询健康服务

- **WHEN** 客户端无认证查询 capabilities
- **THEN** 服务 SHALL 返回 200
- **AND** 每个启用能力 SHALL 返回 `enabled=true,available=true`

#### Scenario: 能力被配置关闭

- **WHEN** read 或 write 被关闭
- **THEN** 对应 capability SHALL 返回 `enabled=false,available=false`

### Requirement: capabilities 公布协议版本和关键限制

capabilities SHALL 至少公布 list 上限 100000、逻辑路径上限 1024 bytes、segment 上限 255 bytes、grant 上限 1000、chunk size 104857600、当前 `max_file_bytes`，以及 small download 的默认文件数、单文件和总大小限制。`limits.max_file_bytes` SHALL 是当前有效 `[transfer].max_file_bytes` 的正整数。algorithms SHALL 包含 `xxh3_128` 和 `layered_xxh3_128_v1`。

capabilities SHALL 保留 `read`、`download`、`write`、`upload` 和 `file_management` 键。`read` 与 `download` 的 `enabled`/`available` SHALL 均等于 `read_enabled`，表示内容下载是否可用；`write` 与 `upload` 的 `enabled`/`available` SHALL 均等于 `write_enabled`，表示远端 mutation 是否可用；`file_management` 的 `enabled`/`available` SHALL 始终为 true，表示 canonical list 路由可用，而不得被解释为 mutation 已获准。

响应 SHALL 公布 anonymous read/write 可用性。`anonymous.read` SHALL 等于 `anonymous_enabled`，表示无凭据 caller 能否浏览 anonymous 空间；anonymous 内容下载仍同时要求 `anonymous.read=true` 和全局 `download.enabled=true`。`anonymous.write` SHALL 仅在 `anonymous_enabled=true` 且 `write_enabled=true` 时为 true。

#### Scenario: 下载关闭时的 capabilities

- **WHEN** `read_enabled=false`、`write_enabled=false` 且 `anonymous_enabled=true`
- **THEN** `read` 与 `download` SHALL 均为 disabled/unavailable，`write` 与 `upload` SHALL 均为 disabled/unavailable，`file_management` SHALL 为 enabled/available，`anonymous.read` SHALL 为 true，且 `anonymous.write` SHALL 为 false

#### Scenario: qtransc 读取服务契约

- **WHEN** qtransc 查询 capabilities
- **THEN** 它 SHALL 能从响应确定 API major version、所需能力、限制、`max_file_bytes` 和 hash algorithms
- **AND** SHALL NOT 根据 Qtserver 应用版本号猜测兼容性

### Requirement: qtransc 在创建任务或操作前预检 capability

qtransc upload、download、list、mkdir、move 和 delete SHALL 在创建 task 或发送操作前查询 capabilities，并 MAY 缓存同一服务响应五秒。普通 upload SHALL 要求 `upload`；目录 upload SHALL 同时要求 `upload` 和 `file_management`；download SHALL 同时要求 `read`、`download` 和 `file_management`；list SHALL 只要求 `file_management`；mkdir、move 和 delete SHALL 同时要求 `write` 和 `file_management`。无凭据 list SHALL 额外要求 `anonymous.read=true`。

#### Scenario: read 关闭时 qtransc 浏览

- **WHEN** `read_enabled=false`、`file_management` 可用且 qtransc 执行 list
- **THEN** qtransc SHALL 通过 capability 预检并向 `GET /files/list` 发起请求

#### Scenario: 服务没有所需能力

- **WHEN** 预检发现所需 capability disabled 或 API major version 不兼容
- **THEN** qtransc SHALL 在传输或 mutation 开始前失败

#### Scenario: 服务连接失败

- **WHEN** 创建 task 前无法连接 Qtserver
- **THEN** qtransc SHALL NOT 创建 task
- **AND** SHALL 报告服务不可用

### Requirement: 路由、method 和业务对象不存在可区分

Qtserver SHALL 只注册精确版本化路由，不自动重定向尾随 slash，也不注册无版本或旧别名。未知或能力关闭路由 SHALL 返回 404 `ROUTE_NOT_FOUND`；已注册路由的错误 method SHALL 返回 405；业务对象不存在 SHALL 返回对应 404 reason code。

#### Scenario: write 关闭时访问 upload

- **WHEN** write capability 关闭且客户端调用 canonical upload route
- **THEN** 服务 SHALL 返回 404 `ROUTE_NOT_FOUND`

#### Scenario: 文件不存在

- **WHEN** read route 已注册且鉴权成功但对象不存在
- **THEN** 服务 SHALL 返回 404 `NOT_FOUND`

#### Scenario: 对 download 使用 HEAD

- **WHEN** 客户端对只注册 GET 的 `/d/down` 发送 HEAD
- **THEN** 服务 SHALL 返回 405

#### Scenario: 浏览器发送 CORS preflight

- **WHEN** 客户端对业务路由发送未显式注册的 OPTIONS
- **THEN** Qtserver SHALL NOT 自动添加 CORS handler
- **AND** 请求 SHALL 按 route/method 基线返回404或405

### Requirement: 配置 schema 严格且 secrets 不泄漏

Qtserver SHALL 拒绝未知或已删除的配置字段，不从环境变量覆盖配置。`qtserver run` SHALL 只允许 `--port`、`--host`、`--loglevel` 和 `--logpath` 覆盖。作为存量配置的过渡兼容，配置 MAY 包含只带字符串 `dsn` 字段的 `[postgres]` section；Qtserver SHALL 完全忽略该值，不建立 PostgreSQL 连接、不校验 DSN、不执行 migration，也不得在普通日志或配置输出中暴露它。`[postgres]` 内其他字段和其余未知配置仍 SHALL 被拒绝。普通日志和配置输出 SHALL redact Redis password、HMAC secret、fake token keys、Authorization 和 anonymous token。

#### Scenario: config validate

- **WHEN** 运维运行 `config validate`
- **THEN** 命令 SHALL 只执行配置和本地路径的只读校验
- **AND** SHALL NOT 连接 Redis、PostgreSQL 或身份服务，也 SHALL NOT 创建目录

#### Scenario: 使用旧 PostgreSQL 配置

- **WHEN** 配置包含只带字符串 `dsn` 的 `[postgres]` section 且其他字段均有效
- **THEN** validate 和启动 SHALL 接受该配置
- **AND** Qtserver SHALL 忽略 DSN 且不产生任何 PostgreSQL 网络访问

#### Scenario: 使用其他未知配置字段

- **WHEN** 配置包含 `[postgres]` 下除 `dsn` 之外的字段、非字符串 `dsn`、其他已删除字段或未知字段
- **THEN** validate 和启动 SHALL 失败

### Requirement: HTTP 基线适合长传输

Qtserver SHALL 使用 `ReadHeaderTimeout=10s` 和 `IdleTimeout=120s`，不得设置覆盖完整上传或下载的全局 ReadTimeout/WriteTimeout。PATCH 和 direct download 连续 60 秒没有 bytes progress 时 SHALL 取消当前请求。

#### Scenario: 慢速但持续传输

- **WHEN** 长传输持续产生 byte progress
- **THEN** 它 SHALL NOT 因全局请求时长而被取消

#### Scenario: 数据流停滞

- **WHEN** PATCH 或 direct download 连续 60 秒没有 byte progress
- **THEN** 服务 SHALL 取消当前请求

### Requirement: 生成的 Nginx 配置允许固定上传 chunk

Qtserver 生成的 canonical API proxy location SHALL 配置 `client_max_body_size 128m`，使固定 104857600 字节的 upload chunk 可以通过网关。该配置 SHALL NOT 改变 Qtserver 自身的请求 body 校验、单文件上限或其他 location 的 body 限制。

#### Scenario: 通过生成配置上传完整 chunk

- **WHEN** Nginx 使用 Qtserver 生成的配置代理一个 Content-Length 为 104857600 的合法 PATCH
- **THEN** Nginx SHALL NOT 因 body size 返回 413
- **AND** 请求 SHALL 到达 Qtserver 并由 canonical upload 规则处理

### Requirement: fatal shutdown 后活动传输保持可恢复

已开始的前台 upload/download 在 Qtserver 因 fatal dependency 退出或暂时无法连接时 SHALL 保留可恢复状态，并按 `file-management` 的可用性恢复契约持续退避，直到服务恢复、任务 context 取消、用户停止、显式总期限到达或出现永久错误。serve 中的活动任务在相同情况下 SHALL 保持可恢复的活动状态，而 SHALL NOT 仅因固定网络重试窗口结束自动进入 `stopped`。

本要求只适用于已经开始且具有安全恢复路径的传输；创建任务前的 capability 预检、配置错误、认证错误以及不可恢复业务错误 SHALL 继续按各自契约失败。未完成上传的 SQLite 状态和下载恢复状态 SHALL 在等待和显式停止后继续保留。

#### Scenario: 前台上传期间服务暂时退出

- **WHEN** Qtserver 在前台上传期间退出且超过 30 秒后恢复
- **THEN** qtransc SHALL 在任务未被取消且没有显式总期限到达时继续退避等待
- **AND** 服务恢复后 SHALL 从服务端确认状态继续上传

#### Scenario: serve上传期间服务暂时退出

- **WHEN** serve 中的活动上传任务暂时无法连接 Qtserver
- **THEN** 任务 SHALL 保持可恢复的活动状态并持续退避
- **AND** SHALL NOT 仅因经过固定 30 秒自动进入 `stopped`

#### Scenario: 等待服务恢复时显式停止

- **WHEN** 调用方在活动任务等待 Qtserver 恢复期间暂停、取消或使显式总期限到达
- **THEN** qtransc SHALL 及时结束恢复等待
- **AND** SHALL 按既有任务状态规则保留可恢复状态

#### Scenario: 创建任务前服务不可用

- **WHEN** qtransc 在创建任务前无法完成必要的 Qtserver capability 预检
- **THEN** qtransc SHALL NOT 创建任务
- **AND** SHALL 按既有契约报告服务不可用

### Requirement: Redis 是唯一共享状态 fatal dependency

Qtserver SHALL 在启动时成功执行 Redis PING 并校验 Redis AOF 状态；`identity.mode="oauth2-introspection"` 时，Qtserver SHALL 在开始监听前使用内置 client authentication 和一个进程内生成的 UUID v4 probe token 调用 introspection endpoint，并确认 response 符合 RFC 7662。Redis 或已启用 introspection provider 的连接、TLS、timeout、认证、HTTP status 或协议失败 SHALL 拒绝启动。服务 SHALL NOT 提供共享状态或身份服务的启动降级，也 SHALL NOT 在 fatal dependency 恢复后继续使用同一进程。

#### Scenario: Redis 启动时不可用

- **WHEN** Qtserver 无法完成 Redis PING 或读取必需的 persistence 状态
- **THEN** Qtserver SHALL 以非零状态拒绝启动

#### Scenario: introspection provider 启动时不可用

- **WHEN** 启用 `oauth2-introspection` 且 endpoint 无法完成 authenticated probe
- **THEN** Qtserver SHALL 以非零状态拒绝启动

#### Scenario: introspection probe 返回标准 active 结果

- **WHEN** probe 返回 HTTP 200 和结构合法的 boolean `active`
- **THEN** Qtserver SHALL 将 endpoint 判定为可用

### Requirement: Redis 使用可校验的 AOF 持久化

Qtserver 所连接的 Redis SHALL 使用持久 volume，启用 AOF，并配置 `appendfsync everysec`。Qtserver SHALL 在监听前校验 `appendonly=yes`、`appendfsync=everysec` 和 AOF 最近写入状态正常，并在每五秒健康检查中校验 AOF 仍启用且最近写入状态正常。Redis ACL SHALL 允许完成这些只读校验。该持久化等级 SHALL NOT 被解释为零数据丢失保证；Redis 或宿主机异常停止时，最近约一秒已确认写入 MAY 不在恢复后的 AOF 中。

#### Scenario: AOF 未启用

- **WHEN** Redis 可连接但 `appendonly` 不是 `yes` 或 `appendfsync` 不是 `everysec`
- **THEN** Qtserver SHALL 以非零状态拒绝启动

#### Scenario: AOF 写入状态异常

- **WHEN** 周期健康检查发现 AOF 最近写入状态不是正常状态
- **THEN** Qtserver SHALL 立即触发 fatal graceful shutdown

#### Scenario: Redis 从 AOF 重启

- **WHEN** Redis 重启并成功重放 AOF
- **THEN** AOF 中存在且尚未过期的上传、hash、intent、committed、lock 和 lease 状态 SHALL 可由 Qtserver 继续使用
- **AND** TTL 与 lease SHALL 按原绝对过期时间继续计算而不得因重启重新获得完整时长

#### Scenario: 最近写入未进入 AOF

- **WHEN** Redis 异常停止且恢复后的 AOF 不包含最近已确认的写入
- **THEN** Qtserver SHALL 只按实际恢复的 Redis 状态和文件系统事实处理请求
- **AND** SHALL NOT 推断丢失的 session、intent、lock、lease 或 hash 状态仍然存在

### Requirement: 仅 Redis 依赖故障终止共享状态服务

Redis 连接、TLS、dependency I/O timeout、认证、协议、AOF 配置或 AOF 写入状态故障 SHALL 按 fatal dependency 处理。调用方 context 结束、锁冲突、CAS miss、key 不存在和查询无结果 SHALL NOT 被判定为依赖故障。既有 `auth` mode 的身份服务超时或拒绝、任意 provider 返回无效 token、单个 principal 目录错误、单次文件 I/O、磁盘满和客户端错误 SHALL 是请求级错误且 SHALL NOT 终止 Qtserver。只有启用 `oauth2-introspection` 时，该 provider 的连接、TLS、timeout、内置 client authentication、HTTP status 或协议故障 SHALL 按 fatal dependency 处理。

#### Scenario: 上传磁盘空间不足

- **WHEN** 单次 PATCH 因磁盘空间不足失败
- **THEN** 请求 SHALL 返回 507
- **AND** Qtserver SHALL 继续处理其他请求

#### Scenario: namespace lock 冲突

- **WHEN** 请求未获取同 principal namespace lock
- **THEN** 请求 SHALL 返回 409 `NAMESPACE_BUSY`
- **AND** Qtserver SHALL NOT 退出

#### Scenario: Redis底层I/O超时

- **WHEN** 调用方 context 仍有效但 Redis 连接的读写发生 I/O timeout
- **THEN** Qtserver SHALL 触发 fatal graceful shutdown

#### Scenario: introspection 返回 inactive

- **WHEN** `oauth2-introspection` 返回结构合法的 `active=false`
- **THEN** 当前请求 SHALL 作为无效 token 失败
- **AND** Qtserver SHALL NOT 退出

#### Scenario: 既有 auth 服务超时

- **WHEN** `identity.mode="auth"` 的既有 `/userinfo` 请求超时
- **THEN** 请求 SHALL 按既有行为失败
- **AND** Qtserver SHALL NOT 因本变更退出

### Requirement: 单文件传输上限使用严格的 transfer 配置

Qtserver SHALL 接受 `[transfer].max_file_bytes` 作为上传和下载共同的单文件字节上限。该值 SHALL 为 `1..int64 max` 的整数，缺省值 SHALL 为 `1099511627776`。`config validate` 和启动 SHALL 拒绝零、负数、超过 `int64` 表示范围的值，以及 `max_small_file_bytes` 大于 `max_file_bytes` 的配置。

#### Scenario: 未显式设置单文件上限

- **WHEN** 有效配置省略 `transfer.max_file_bytes`
- **THEN** Qtserver SHALL 使用 `1099511627776` 作为上限

#### Scenario: 单文件上限无效

- **WHEN** 配置中的 `transfer.max_file_bytes` 为零、负数或小于 `max_small_file_bytes`
- **THEN** `config validate` 和启动 SHALL 失败

### Requirement: qtransc 预检单文件传输上限并兼容旧服务

qtransc SHALL 在 upload/download task 的文件规划期间读取 capabilities 的 `limits.max_file_bytes`，并用该值预检上传源文件的实际大小和下载 browse entry 的大小。服务响应不含该字段时，qtransc SHALL 使用 `1099511627776` 作为兼容回退值，而 SHALL NOT 仅因缺少该限制字段判定 API major 不兼容。客户端预检 SHALL 在任何目录创建、内容传输或 download grant 请求前完成；它不替代服务端强制检查。

#### Scenario: 新服务公布较小上限

- **WHEN** capabilities 的 `limits.max_file_bytes` 小于 qtransc 内置回退值
- **THEN** qtransc SHALL 使用服务公布的较小值规划 upload 和 download

#### Scenario: 旧服务未公布该字段

- **WHEN** API v1 capabilities 不含 `limits.max_file_bytes`
- **THEN** qtransc SHALL 使用 1 TiB 回退值继续执行其他兼容的 capability 预检

### Requirement: capabilities 显式公布 small download v2

支持 v2 mini-tar 的 Qtserver SHALL 在 `capabilities` 中公布 `small_download_v2`，其值 SHALL 使用与其他 capability 相同的 `enabled`、`available` 结构，并 SHALL 与全局 `download` 能力同时启用或关闭。服务端批次硬限制 SHALL 继续通过 `limits.small_files`、`limits.small_file_bytes` 和 `limits.small_total_bytes` 公布，v2 的哈希算法 SHALL 通过 `algorithms` 中的 `layered_xxh3_128_v1` 公布。客户端 SHALL 根据 capability 字段选择协议，而 SHALL NOT 根据 Qtserver 应用版本号猜测。

#### Scenario: 新服务支持 v2

- **WHEN** Qtserver 已实现 v2 且 read/download 已启用
- **THEN** `capabilities.small_download_v2` SHALL 为 `enabled=true,available=true`
- **AND** 响应 SHALL 公布当前 small 三项硬限制和 `layered_xxh3_128_v1`

#### Scenario: 下载能力关闭

- **WHEN** Qtserver 已实现 v2 但 read/download 被配置关闭
- **THEN** `capabilities.small_download_v2` SHALL 为 `enabled=false,available=false`

### Requirement: qtransc 以协商结果选择小文件协议

qtransc SHALL 仅在 `small_download_v2.enabled=true`、`small_download_v2.available=true`、服务端公布 `layered_xxh3_128_v1` 且三项 small 限制有效时调用 v2 端点。旧服务的 capabilities 不含 `small_download_v2` 时，qtransc SHALL 继续使用既有 v1 small 路径，而 SHALL NOT 将字段缺失视为整个下载任务不兼容。客户端生成的每个 v2 请求 SHALL 同时满足本地批次目标与服务端公布的硬限制。

#### Scenario: 连接旧服务端

- **WHEN** capabilities 包含既有 download 能力和 small 限制但不含 `small_download_v2`
- **THEN** qtransc SHALL 使用 `/qtserver/v1/d/small`
- **AND** SHALL NOT 因缺少 v2 字段拒绝整个下载任务

#### Scenario: 服务端限制小于客户端目标

- **WHEN** 服务端公布的 `small_files` 或 `small_total_bytes` 小于客户端的 100 文件或 32 MiB 目标
- **THEN** qtransc SHALL 使用较小值形成 v2 批次
- **AND** 每个请求 SHALL 满足服务端公布的单文件与批次硬限制

#### Scenario: v2 宣告存在但算法缺失

- **WHEN** `small_download_v2` 可用但 `algorithms` 不含 `layered_xxh3_128_v1`
- **THEN** qtransc SHALL NOT 调用 v2 端点
- **AND** SHALL 报告不一致的服务契约，而不得猜测哈希算法
