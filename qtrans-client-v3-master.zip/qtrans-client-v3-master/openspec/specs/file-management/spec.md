# file-management Specification

## Purpose
定义统一文件空间的 logical path、list、symlink/特殊节点、canonical 文件管理、qtransc 递归规划以及 download/grant/verify 行为。

## Requirements

### Requirement: canonical 文件管理 API 使用固定 wire contract

Qtserver SHALL 精确注册以下 API：

```text
GET  /qtserver/v1/files/list?path=/docs
POST /qtserver/v1/files/mkdir  {"path":"/docs"}
POST /qtserver/v1/files/move   {"source":"/a","destination":"/b"}
POST /qtserver/v1/files/delete {"path":"/docs"}
POST /qtserver/v1/files/create {"path":"/empty","overwrite":false}
```

成功状态 SHALL 是 list 200、mkdir新建201/已存在200、move200、delete200、create新建201/已有空文件200。所有这些成功响应 SHALL 是JSON且`code`等于HTTP status。

#### Scenario: 使用 canonical API

- **WHEN** 已鉴权客户端按上述 method和path调用文件管理
- **THEN** Qtserver SHALL 按定义的JSON schema和status响应

#### Scenario: 调用旧browse路由

- **WHEN** 客户端访问旧browse/file-management别名
- **THEN** 服务 SHALL 返回404 `ROUTE_NOT_FOUND`

#### Scenario: delete成功

- **WHEN** delete完成文件系统mutation
- **THEN** 服务 SHALL 返回200 JSON而不是204空响应

### Requirement: JSON与错误响应遵循统一基线

文件管理 POST SHALL 使用严格 `application/json`、2MiB body 上限、未知字段拒绝和单 JSON value 规则。错误 JSON SHALL 包含 HTTP status code、稳定 `reason_code`、human-readable `message` 和适用 typed extras，SHALL NOT 新增 request ID。鉴权 SHALL 先于 body 与 path 校验。delete 非空目录 SHALL 使用 409 `DIRECTORY_NOT_EMPTY`，且 SHALL NOT 返回 `partial=true` 或 `failed_path`。

#### Scenario: 未认证请求含坏路径

- **WHEN** write请求既未认证又包含非法logical path
- **THEN** 服务 SHALL 先返回认证错误

#### Scenario: delete 非空目录

- **WHEN** delete 的 target 在实际移除时是非空目录
- **THEN** error body SHALL 包含 `reason_code=DIRECTORY_NOT_EMPTY`
- **AND** SHALL NOT 包含递归删除专用的 `partial=true` 或 `failed_path`

### Requirement: logical path 必须绝对且确定地规范化

对象路径 SHALL 是有效UTF-8并以`/`开头。服务 SHALL 合并重复slash并去除非根尾随slash； SHALL 拒绝`.`、`..` segment、NUL、反斜杠和无效UTF-8。规范化后总长 SHALL 不超过1024 bytes，segment SHALL 不超过255 bytes。服务 SHALL NOT执行Unicode normalization。mkdir/move/delete/create SHALL 拒绝操作根`/`。

#### Scenario: 规范化重复slash

- **WHEN** JSON path是`//docs///a/`
- **THEN** 服务 SHALL 使用`/docs/a`进行授权、mutation和响应

#### Scenario: 两个Unicode表示

- **WHEN** 两个名称的Unicode codepoints不同但视觉等价
- **THEN** 服务 SHALL 将其视为不同byte名称

#### Scenario: 目录穿越

- **WHEN** path包含`.`、`..`、反斜杠或NUL
- **THEN** 服务 SHALL 返回path validation错误且不得访问宿主机路径

### Requirement: query和JSON路径解码规则不同

query path SHALL 由HTTP层percent-decode恰好一次，再执行logical path检查。JSON string SHALL NOT URL-decode，`%2F` SHALL 是名称中的字面字符。download URL `/d/down/docs/a.txt` SHALL 在授权和签名中对应规范化`/docs/a.txt`。

#### Scenario: query含encoded slash

- **WHEN** list query path percent-decode后产生新segment边界
- **THEN** 服务 SHALL 对解码后的path重新执行segment和dot检查

#### Scenario: JSON含percent文本

- **WHEN** create JSON path为`/docs/%2F.txt`
- **THEN** 服务 SHALL 操作名字字面为`%2F.txt`的文件

### Requirement: list 只返回单层无序无分页结果

`GET /files/list` SHALL 只枚举请求目录直接子项，不排序、不分页，最多返回文件系统首先枚举的100000项。200响应 SHALL 包含`code,path,truncated,entries`；entry SHALL 包含name、logical path、type、status及适用的target_type、special_type、reason_code、size和last_modified。时间 SHALL 为UTC RFC3339Nano，顺序不保证。

#### Scenario: 小目录完整返回

- **WHEN** 直接子项不超过100000且枚举完成
- **THEN** list SHALL 返回全部直接子项和`truncated=false`

#### Scenario: 大目录被截断

- **WHEN** 目录直接子项超过100000
- **THEN** list SHALL 返回至多100000项和`truncated=true`
- **AND** SHALL NOT 提供下一页token

#### Scenario: list普通文件

- **WHEN** 请求path最终是普通文件
- **THEN** 服务 SHALL 返回422 `NOT_A_DIRECTORY`

#### Scenario: list目标不存在

- **WHEN** 请求目录不存在
- **THEN** 服务 SHALL 返回404 `NOT_FOUND`

#### Scenario: list目标是坏链或循环

- **WHEN** 请求path最终节点是damaged symlink或symlink loop
- **THEN** 服务 SHALL 返回422及对应稳定reason_code

### Requirement: list 对并发变化采用entry级弱一致性

list SHALL 不持有namespace lock。枚举后子项消失或属性发生竞争时，整体 SHALL 仍返回200；该项 SHALL 使用`type=unknown,status=unavailable`以及`ENTRY_CHANGED`或`ENTRY_UNREADABLE`。请求目录本身的permission/I/O错误 SHALL 返回500且不得泄露物理路径。

#### Scenario: 子项在stat前消失

- **WHEN** readdir后该子项被并发删除
- **THEN** entry SHALL 标记`unknown/unavailable/ENTRY_CHANGED`
- **AND** 其他entries SHALL 正常返回

#### Scenario: 请求目录不可读

- **WHEN** Qtserver不能打开请求目录
- **THEN** 整个list SHALL 返回500请求级错误

### Requirement: list 显式表示symlink事实和目标类型

有效symlink entry SHALL 返回`type=symlink,status=normal,target_type=file|directory|special`。坏链或环 SHALL 返回`status=damaged,target_type=null`及对应reason_code。指向特殊节点 SHALL 返回`status=unsupported,target_type=special`。qtransc文本输出 SHALL 按target_type将正常链接展示为普通文件或目录；`--json` SHALL 保留真实`type=symlink`。

#### Scenario: symlink指向普通文件

- **WHEN** list枚举到有效file symlink
- **THEN** entry SHALL 是`type=symlink,status=normal,target_type=file`
- **AND** qtransc文本模式 SHALL 按文件展示

#### Scenario: symlink形成循环

- **WHEN** 子项symlink解析产生ELOOP
- **THEN** entry SHALL 是`status=damaged,target_type=null`
- **AND** reason_code SHALL 表示`SYMLINK_LOOP`

#### Scenario: symlink指向FIFO

- **WHEN** symlink目标是FIFO、socket或device
- **THEN** entry SHALL 是`status=unsupported,target_type=special`

### Requirement: final与intermediate symlink按操作区分

有效intermediate symlink SHALL 正常跟随，即使目标在用户家目录外。download SHALL 跟随final symlink-to-file；显式list和mkdir SHALL 跟随final symlink-to-directory。move/delete SHALL 操作final symlink节点本身。upload/create SHALL 拒绝final symlink。delete SHALL 是唯一允许删除坏链或环链接节点的操作。

#### Scenario: 下载final file symlink

- **WHEN** object key最终节点是指向普通文件的有效symlink
- **THEN** download SHALL 跟随并传输目标bytes

#### Scenario: list final directory symlink

- **WHEN** list path最终是指向普通目录的有效symlink
- **THEN** list SHALL 跟随并枚举目标目录

#### Scenario: delete final symlink

- **WHEN** delete path最终是symlink
- **THEN** 服务 SHALL unlink链接本身且不得删除target

#### Scenario: complete目标是symlink

- **WHEN** canonical upload要发布到任何final symlink
- **THEN** 服务 SHALL 返回422且不得跟随覆盖target

### Requirement: 特殊节点只允许安全枚举

FIFO、socket 和 device MAY 由 list 报告。直接 download、overwrite、move 或 delete 特殊节点 SHALL 返回 422 `UNSUPPORTED_FILE_TYPE`；文件管理 mutation SHALL NOT 打开、跟随或递归删除特殊节点。

#### Scenario: 直接删除FIFO

- **WHEN** delete的顶层path是FIFO
- **THEN** 服务 SHALL 返回422且不删除该节点

#### Scenario: move 覆盖已观察到的特殊节点

- **WHEN** move 校验时发现 source 或 destination 是特殊节点
- **THEN** 服务 SHALL 返回 422 且不得尝试 rename

### Requirement: mkdir 是幂等mkdir-p

mkdir SHALL 创建缺失parents并应用家目录和managed policy。最终已是普通目录或有效symlink-to-directory时 SHALL 返回200且`created=false`；新建一项或多项 SHALL 返回201且`created=true`。final symlink-to-file或普通文件 SHALL 返回409；坏链或环 SHALL 返回422。

#### Scenario: 部分父目录存在

- **WHEN** `/a`存在而mkdir请求`/a/b/c`
- **THEN** 服务 SHALL 创建`b/c`并返回201和normalized path

#### Scenario: 最终是directory symlink

- **WHEN** requested path已是有效symlink-to-directory
- **THEN** mkdir SHALL 跟随它并返回200而不替换链接

### Requirement: create 原子创建或清空普通文件

create SHALL mkdir-p，随后在目标parent创建`.qtserver-create-<random>.tmp`，应用文件mode/ownership并原子发布。overwrite默认false。新文件 SHALL 返回201；已有空普通文件且overwrite=false SHALL 返回200幂等；已有非空普通文件且未允许overwrite SHALL 返回409；overwrite=true SHALL 原子清空普通文件。目录、symlink和特殊target SHALL 返回422。

#### Scenario: 新建空文件

- **WHEN** target不存在
- **THEN** create SHALL 发布零字节普通文件并返回201

#### Scenario: 已有空文件

- **WHEN** target是零字节普通文件且overwrite=false
- **THEN** create SHALL 返回200且不替换inode

#### Scenario: 原子清空

- **WHEN** target是非空普通文件且overwrite=true
- **THEN** reader SHALL 看到完整旧inode或完整新空inode

#### Scenario: create进程崩溃留下temp

- **WHEN** 进程在发布前崩溃留下`.qtserver-create-*`
- **THEN** 启动 SHALL NOT 自动清理该文件
- **AND** 它 SHALL 作为普通隐藏文件被list/move/delete

#### Scenario: create正常失败

- **WHEN** create在进程仍健康时发布前失败
- **THEN** 服务 SHALL best-effort删除本次创建的`.qtserver-create-*`

### Requirement: no-overwrite create 必须原子

create no-overwrite SHALL 使用`renameat2(RENAME_NOREPLACE)`或等价原子primitive；不支持时 SHALL 返回500 `ATOMIC_NOREPLACE_UNSUPPORTED`，不得stat后rename。

#### Scenario: 并发创建同一target

- **WHEN** 两个no-overwrite create并发发布同一路径
- **THEN** 至多一个 SHALL 新建成功
- **AND** 另一个 SHALL 得到已存在冲突/幂等结果而不得覆盖

### Requirement: create 写入正式hash并遵守成功点

create SHALL 生成固定空文件 hash，在 publish 前原子更新 Redis generation，并在 publish 后以 generation CAS 写入已知 hash。rename 前的 permission、fsync 或 Redis 故障 SHALL 阻止发布；rename 后 parent fsync 或依赖故障 SHALL NOT 回滚，服务 SHALL 尽量返回成功并按规则记录或退出。恢复时缺少最近 hash 写入 SHALL 被视为可重建的 cache miss。

#### Scenario: rename后parent fsync失败

- **WHEN** empty file已rename到target但parent fsync失败
- **THEN** create SHALL 返回成功并记录高等级错误
- **AND** SHALL NOT unlink新文件

#### Scenario: rename 后 Redis 断开

- **WHEN** 文件已发布而 hash persistence 检测到 Redis 连接故障
- **THEN** 文件 SHALL 保持正式可见
- **AND** Qtserver SHALL 触发 fatal graceful shutdown

#### Scenario: 已知空文件 hash 未从 AOF 恢复

- **WHEN** 文件已发布但恢复后的 Redis 不包含其已知 hash
- **THEN** create 的文件事实 SHALL 保持有效
- **AND** 后续 hash 请求 SHALL 重新建立 cache

### Requirement: move 使用普通 rename 和底层覆盖语义

move SHALL 将 source 移动到 exact destination，SHALL NOT 把 destination 解释为目录容器，也 SHALL NOT 自动创建 destination parent。服务 SHALL 在固定数量的路径、权限和节点类型校验后直接尝试普通 rename；destination 已存在时是否可替换 SHALL 由底层文件系统的 rename 语义决定，服务 SHALL NOT 提供 no-overwrite 保证。source==destination 和目录移入自身后代 SHALL 返回 409；final source symlink SHALL 移动链接本身；校验时观察到的特殊 source 或特殊 destination SHALL 返回 422。跨文件系统 SHALL 返回 500 `CROSS_DEVICE_MOVE`，服务 SHALL NOT 复制后删除 source。

#### Scenario: destination 不存在

- **WHEN** source 存在、destination parent 存在且 destination 不存在
- **THEN** move SHALL 尝试一次普通 rename 并在成功时返回 200

#### Scenario: destination 是可替换节点

- **WHEN** destination 已存在且底层文件系统允许普通 rename 替换该节点
- **THEN** move SHALL 替换 destination 并返回 200
- **AND** 服务 SHALL NOT 因 destination 在校验时已存在而预先返回冲突

#### Scenario: destination 不能被底层 rename 替换

- **WHEN** 普通 rename 因节点类型冲突或 destination 是非空目录而拒绝替换
- **THEN** move SHALL 返回 409 `CONFLICT`
- **AND** 服务 SHALL NOT 递归清空 destination

#### Scenario: 跨文件系统

- **WHEN** rename 返回 EXDEV
- **THEN** move SHALL 返回 500 `CROSS_DEVICE_MOVE`
- **AND** SHALL NOT 复制后删除 source

#### Scenario: 并发修改 move 路径

- **WHEN** 其他操作在 move 校验和 rename 之间修改 source、destination 或 parent
- **THEN** move SHALL 以该次普通 rename 的实际结果作为响应依据
- **AND** 服务 SHALL NOT 承诺 no-overwrite、先到者优先或自动重试

### Requirement: delete 只删除单个文件、final symlink 或空目录

delete SHALL 只删除请求 path 对应的单个普通文件、final symlink 或空目录，SHALL NOT 递归遍历或删除任何 descendant。顶层不存在 SHALL 返回 404；特殊节点 SHALL 返回 422 `UNSUPPORTED_FILE_TYPE`；目录在实际移除时非空 SHALL 返回 409 `DIRECTORY_NOT_EMPTY`。服务 SHALL NOT 为判断目录是否为空而预扫描目录内容，目录是否为空 SHALL 由底层单节点移除操作判定。

#### Scenario: 删除普通文件

- **WHEN** target 是普通文件且底层文件系统允许移除
- **THEN** delete SHALL 只移除该节点并返回 200

#### Scenario: 删除 final symlink

- **WHEN** target 是有效、broken 或 loop final symlink
- **THEN** delete SHALL 移除链接本身并返回 200
- **AND** SHALL NOT 跟随或删除链接目标

#### Scenario: 删除空目录

- **WHEN** target 是在实际移除时仍为空的普通目录
- **THEN** delete SHALL 移除该目录并返回 200

#### Scenario: 删除非空目录

- **WHEN** target 目录在实际移除时包含至少一个 descendant
- **THEN** delete SHALL 返回 409 `DIRECTORY_NOT_EMPTY`
- **AND** 目录和全部 descendants SHALL 保持未被本次请求删除

#### Scenario: 空目录校验后出现新子项

- **WHEN** 其他操作在 delete 校验和实际移除之间向目录加入子项
- **THEN** 底层单节点移除 SHALL 失败且 delete SHALL 返回 409 `DIRECTORY_NOT_EMPTY`
- **AND** 服务 SHALL NOT 再次遍历或递归删除该目录

### Requirement: 文件系统mutation以不可逆syscall为业务成功点

create SHALL 在发布 rename 之前完成必须成功的 chmod、chown 和相关 fsync；发布后的 parent directory fsync 失败 SHALL 记录高等级错误但业务返回成功，SHALL NOT 回滚已完成 mutation。move 和 delete SHALL NOT 显式 fsync parent directory；普通 rename 或单节点移除操作成功返回即为业务成功点。服务 SHALL NOT 因 move/delete 已返回成功而额外承诺主机崩溃后的目录项持久性。

#### Scenario: move rename 成功

- **WHEN** move 的普通 rename 成功返回
- **THEN** move SHALL 返回成功且不得为 parent fsync 延迟响应

#### Scenario: delete 单节点移除成功

- **WHEN** delete 的单节点移除操作成功返回
- **THEN** delete SHALL 返回成功且不得为 parent fsync 延迟响应

#### Scenario: create 发布后 parent fsync 失败

- **WHEN** create 已成功发布 target 但 parent fsync 失败
- **THEN** create SHALL 返回成功且不得删除已发布 target

### Requirement: namespace mutation使用advisory renewable lock

mkdir、create 和 complete SHALL 使用 principal namespace lock，lease 30 秒且每 10 秒续租。此类操作的 lock 冲突 SHALL 返回 409 `NAMESPACE_BUSY` 和 `Retry-After: 1`；不可逆操作前 SHALL 检查 token，未修改即丢失返回 409 `NAMESPACE_LOCK_LOST`。move 和 delete SHALL NOT 获取、续租、等待或检查 principal namespace lock；它们与其他 mutation 并发时仅服从各自底层文件系统操作的实际结果，服务 SHALL NOT 提供跨操作串行化保证。该 lock SHALL NOT 宣称严格 fencing。

#### Scenario: mkdir 遇到 lock 冲突

- **WHEN** 同principal namespace lock已被另一mutation占用
- **THEN** mkdir SHALL 返回 409 `NAMESPACE_BUSY`

#### Scenario: move 在 namespace lock 被占用时到达

- **WHEN** 同 principal namespace lock 已被 mkdir、create 或 complete 占用
- **THEN** move SHALL 不等待该 lock，并继续执行自身固定校验和普通 rename

#### Scenario: delete 在 namespace lock 被占用时到达

- **WHEN** 同 principal namespace lock 已被 mkdir、create 或 complete 占用
- **THEN** delete SHALL 不等待该 lock，并继续执行自身固定校验和单节点移除

### Requirement: qtransc 文件管理CLI使用canonical能力

qtransc SHALL 提供 list、mkdir、move 和 delete 对 canonical API 的调用；create SHALL 只作为 API 能力，本 change SHALL NOT 增加 touch/create CLI。文本输出用于人类，`--json` SHALL 保留服务端结构，包括 symlink 真实 type 和非递归 delete 的 `DIRECTORY_NOT_EMPTY` 错误。`delete --recursive` 的客户端定义 JSON 结果服从递归删除要求。所有文件管理 CLI 错误 SHALL 服从 `client-error-contract` 的稳定 `reason_code` 与人类可读格式。

在未带 `--json` 的成功情况下，`mkdir` SHALL 根据服务端 `created` 事实输出“已创建远端目录：<path>”或“远端目录已存在：<path>”；`move` SHALL 输出“已移动远端路径：<source> -> <destination>”；单节点 `delete` SHALL 输出“已删除远端路径：<path>”。这些中文文本 SHALL 不包含服务端 JSON 字段名或原始 JSON。带 `--json` 的 mkdir、move 和单节点 delete SHALL 继续在 stdout 原样输出服务端成功 JSON。

#### Scenario: 文本list

- **WHEN** 用户执行qtransc list
- **THEN** stdout SHALL 展示人类可读结果，正常symlink按target_type展示

#### Scenario: JSON list

- **WHEN** 用户执行qtransc list --json且请求成功
- **THEN** stdout SHALL 输出单一有效JSON对象并保留entry字段

#### Scenario: 文本mkdir新建目录

- **WHEN** 用户执行未带 `--json` 的 `qtransc mkdir /docs` 且服务端返回 `created=true`
- **THEN** stdout SHALL 输出“已创建远端目录：/docs”

#### Scenario: 文本mkdir已有目录

- **WHEN** 用户执行未带 `--json` 的 `qtransc mkdir /docs` 且服务端返回 `created=false`
- **THEN** stdout SHALL 输出“远端目录已存在：/docs”

#### Scenario: 文本move和delete

- **WHEN** 用户执行未带 `--json` 的 move 或单节点 delete 且请求成功
- **THEN** stdout SHALL 分别输出包含源与目标路径的移动提示或包含目标路径的删除提示
- **AND** stdout SHALL 不输出原始 JSON

#### Scenario: JSON mutation成功

- **WHEN** 用户以 `--json` 执行 mkdir、move 或未带递归标志的 delete 且请求成功
- **THEN** stdout SHALL 原样输出服务端成功 JSON

#### Scenario: delete 非空目录的 JSON 错误

- **WHEN** 用户执行 qtransc delete --json 且服务返回 409 `DIRECTORY_NOT_EMPTY`
- **THEN** qtransc SHALL 以非零状态退出并原样保留服务端结构化错误

#### Scenario: 调用旧CLI命令

- **WHEN** 用户调用`dlist|ulist|umkdir|umove|udelete`
- **THEN** qtransc SHALL 按未知命令失败且 SHALL NOT 保留兼容别名

### Requirement: qtransc 递归规划在传输前完成并有固定上限

qtransc 的每个 upload/download task SHALL 在传输 bytes 前完成选择展开、路径规范化、映射校验并生成确定的文件清单。旧入口 SHALL 保留既有去重规则；v2 创建的任务 SHALL 按目标副本计数，不得因源相同而合并不同目标的副本。最终计划 SHALL 最多包含 100000 个普通文件副本；该限制同时适用于显式文件、多 source、目录递归、serve 任务以及 upload2/download2 的内部适配。递归规划仍限制 200000 总 entries、128 深度、1024-byte remote path 和 255-byte segment。任一 list 返回 `truncated=true` SHALL 使整个目录任务失败；不得使用前100000项启动部分任务。

超过普通文件上限或其他 planning limit 时，qtransc SHALL 在远端或本地目录创建、内容传输和 download grant 请求前失败。普通文件数超过上限 SHALL 使用 `TASK_FILE_LIMIT_EXCEEDED`；目录不计入 100000 文件数，但继续计入既有总 entries 上限。

#### Scenario: 目录超过服务端list上限

- **WHEN** 规划中的任一list响应`truncated=true`
- **THEN** qtransc SHALL 在传输开始前报“目录超过10万条目，无法启动任务”并失败

#### Scenario: 直接qtransc list被截断

- **WHEN** 用户直接list一个返回truncated的目录
- **THEN** 文本模式 SHALL 一个entry也不显示，只输出错误并非零退出
- **AND** `--json` SHALL 在stdout输出单一JSON error object且不得包含部分entries

#### Scenario: 任务展开超过文件数上限

- **WHEN** upload 或 download 任务在旧入口去重后，或在 v2 按目标副本计数后，包含 100001 个普通文件副本
- **THEN** qtransc SHALL 以 `TASK_FILE_LIMIT_EXCEEDED` 结束 planning
- **AND** SHALL NOT 创建本地或远端目录、传输 bytes 或申请 download grant

#### Scenario: 超过递归总entries

- **WHEN** 多层目录累计超过200000项
- **THEN** qtransc SHALL 在传输前以planning错误失败

### Requirement: 远端递归跟随正常directory symlink但不维护identity map

qtransc SHALL 通过list API递归远端目录，并跟随`status=normal,target_type=directory`的symlink，将其内容下载为普通本地目录。客户端 SHALL NOT额外维护inode/canonical-target去重。循环 SHALL 最终由`SYMLINK_LOOP`、depth、path或entry limit导致传输前失败，但不保证精确识别为目录环。

#### Scenario: 输入目录本身是symlink loop

- **WHEN** 首次list返回`SYMLINK_LOOP`
- **THEN** qtransc SHALL 在传输前失败

#### Scenario: 有效ancestor link形成逻辑递归

- **WHEN** 每次list单独成功但路径不断返回祖先内容
- **THEN** qtransc SHALL 最终命中固定planning限制并失败
- **AND** SHALL NOT开始部分传输

#### Scenario: 显式remote source是damaged或special

- **WHEN** 用户直接下载damaged symlink或special node
- **THEN** qtransc SHALL 在规划阶段失败

#### Scenario: remote目录内含damaged或special entry

- **WHEN** 递归list枚举到不能下载的damaged symlink或special node
- **THEN** qtransc SHALL 跳过该entry、记录warning并继续健康项

### Requirement: 本地目录上传不跟随symlink

显式local source是symlink或特殊节点时规划 SHALL 失败；递归目录内遇到这些节点 SHALL 跳过并warning。hard link SHALL 按每个logical path分别上传。空目录 SHALL 先通过mkdir保留；目录上传 SHALL 同时要求upload和file_management capabilities。

#### Scenario: 显式source是symlink

- **WHEN** 用户将local symlink直接作为upload source
- **THEN** qtransc SHALL 在规划阶段失败

#### Scenario: nested symlink

- **WHEN** 递归扫描普通目录遇到symlink
- **THEN** qtransc SHALL 跳过它、记录warning并继续其他健康项

#### Scenario: 空目录

- **WHEN** upload source tree包含空目录
- **THEN** qtransc SHALL 在传输文件bytes前调用mkdir创建对应remote目录

#### Scenario: 下载空目录

- **WHEN** remote规划包含空目录
- **THEN** qtransc SHALL 创建对应local目录，即使没有文件bytes需要下载

### Requirement: 多source映射和冲突必须确定

CLI 与旧任务入口的 upload destination SHALL 总是目录：单文件映射为`destination/basename`，目录映射为`destination/source-basename`，多source均保留basename；第一版不得在upload中同时改名。CLI 的 download多source也 SHALL 保留basename。规划 SHALL 在执行前检测多个source映射到同一local/remote target；本地冲突 SHALL 使用实际OS大小写语义。新 v2 创建入口 SHALL 使用下述目标目录内容复制规则，不自动追加源目录 basename。

#### Scenario: 两个source basename相同

- **WHEN** 多source会映射到同一destination path
- **THEN** qtransc SHALL 在传输前失败而不得静默覆盖

#### Scenario: 用户需要上传时改名

- **WHEN** 用户希望单文件上传到不同basename
- **THEN** 第一版 SHALL 要求上传后显式move

### Requirement: recursive task 保留健康项但规划错误整体失败

规划limit、目录list失败或mapping冲突 SHALL 在传输前使task失败。传输阶段单文件最终错误 SHALL 允许其他已规划健康文件继续；各文件内部的操作恢复与小文件批次重试 SHALL 遵守各自契约。任务 SHALL NOT 在本轮结束后增加文件级按轮重试队列或借此重置已耗尽的操作重试额度。本轮存在最终执行错误时 task SHALL failed；仅有 warnings 且健康文件全部成功时 SHALL completed。未完成上传和下载 SHALL 保留适用的恢复状态。后续手动 start 或 serve `autoRetry` SHALL 按任务生命周期启动新一轮，重新检查源和目标；已成功文件 MAY 按当前校验结果跳过内容传输，但 SHALL NOT 承诺只准备失败文件或复用上一轮 hash。

#### Scenario: nested特殊节点被跳过

- **WHEN** upload规划只有可跳过的nested symlink/special warnings
- **THEN** 健康文件 SHALL 继续且最终task MAY completed with warnings

#### Scenario: 子目录list权限失败

- **WHEN** remote递归规划无法读取任一目录
- **THEN** 整体 SHALL 在传输前失败且不得发布partial task计划

#### Scenario: 操作重试耗尽但其他文件成功

- **WHEN** 一个文件上传成功，另一个文件的 HTTP 500 操作重试耗尽，且任务未启用 autoRetry
- **THEN** 失败文件 SHALL 贡献本轮最终错误，已成功文件 SHALL 保持成功
- **AND** task SHALL failed，不得再通过文件级队列重新开启该操作的重试额度

#### Scenario: 未启用自动重排

- **WHEN** 一轮任务执行失败且未启用 autoRetry
- **THEN** task SHALL 保持 failed，等待调用方手动启动或新建任务
- **AND** 未完成传输的恢复状态 SHALL 保留

#### Scenario: 自动重排后重新检查文件

- **WHEN** serve autoRetry 接纳失败任务的新一轮执行
- **THEN** 该轮 SHALL 重新检查全部源和目标，并使用仍有效的恢复状态
- **AND** 已成功且内容仍一致的文件 MAY 按既有规则跳过内容传输
- **AND** SHALL NOT 要求只执行上一轮失败的文件或免除重新计算 hash 的准备工作

#### Scenario: 单文件永久错误

- **WHEN** 单文件发生本地文件变化、本地状态错误、认证或权限拒绝、非法请求或确定的hash错误
- **THEN** 该文件 SHALL 贡献本轮最终执行错误，而不得通过文件级队列重排
- **AND** 其他已规划健康文件 SHALL 继续
- **AND** 本轮 task SHALL failed；后续任务级自动重排 SHALL 遵守 serve 的 autoRetry 契约

### Requirement: download对象统一使用logical absolute object_key

grant、small、down和verify SHALL 使用规范化logical absolute object_key。grant和small SHALL 只接受显式普通文件；目录输入 SHALL 返回400 `INVALID_REQUEST`。final symlink-to-file按普通文件处理；special或damaged symlink SHALL 失败。

#### Scenario: 目录作为grant输入

- **WHEN** grant request包含directory object_key
- **THEN** 整个request SHALL 返回400且不签发任何grant

### Requirement: grant 批量验证并保持顺序

单次grant SHALL 最多1000个objects，服务 SHALL 先全量验证再签发。normalized duplicates SHALL 保留第一次；response SHALL 按首次请求顺序返回object_key、size和grant，不得部分成功。

#### Scenario: 批次中一个对象无效

- **WHEN** grant batch中任一object不存在或类型不支持
- **THEN** 整批 SHALL 失败且不返回其他对象grant

#### Scenario: normalized duplicate

- **WHEN** 两个输入规范化为同一object_key
- **THEN** response SHALL 只保留第一次出现

### Requirement: grant 保持现有taskid HMAC绑定和无Redis状态

download grant SHALL 保留现有body/query taskid和HMAC兼容绑定；默认TTL900秒、最小60秒。grant SHALL 自验证且不存Redis、不续期、不支持revoke。X-Task-ID仅用于日志，header与grant taskid不同不影响授权。qtransc在下载期间刷新grant时 SHALL 使用相同grant taskid，并 SHALL 保留已经建立的分片布局、已传输offset、分片完成状态和增量hash状态。

#### Scenario: grant过期

- **WHEN** qtransc下载收到410
- **THEN** qtransc SHALL 使用相同grant taskid重新申请
- **AND** SHALL 根据`.progress`用Range继续

#### Scenario: grant过期后原地续传

- **WHEN** qtransc下载收到410 `GRANT_EXPIRED`
- **THEN** qtransc SHALL 使用相同grant taskid重新申请grant
- **AND** SHALL 使用新grant根据现有分片offset发起Range请求
- **AND** SHALL NOT重新加载`.progress`、重新准备全部分片或重新hash已下载数据

#### Scenario: 多个并发分片发现同一grant过期

- **WHEN** 同一文件的一个或多个并发分片发现当前grant过期
- **THEN** qtransc SHALL 停止继续发起使用该过期grant的请求
- **AND** SHALL 对该文件只执行一次grant刷新
- **AND** 等待中的分片 SHALL 复用刷新后的grant继续传输

#### Scenario: grant刷新时远端文件大小变化

- **WHEN** 新grant返回的文件大小与初始分片布局对应的大小不同
- **THEN** qtransc SHALL 将其报告为远端文件已变化并停止该文件下载
- **AND** SHALL NOT使用旧分片布局下载已变化的远端文件

### Requirement: down 保证GET full和single Range

`/d/down` SHALL 只注册GET，HEAD SHALL 405。服务 SHALL 支持完整下载和单Range，不可满足返回416；multi-range行为不保证。成功 SHALL 设置`application/octet-stream`、基于logical basename的Content-Disposition、`Cache-Control: private, no-store`和`Accept-Ranges: bytes`。开始传输后读取错误 SHALL 断开连接而不得追加JSON。

#### Scenario: 有效single Range

- **WHEN** grant有效且请求一个可满足byte range
- **THEN** 服务 SHALL 返回206和对应bytes

#### Scenario: stream开始后文件读取失败

- **WHEN** headers/body已开始后底层read失败
- **THEN** 连接 SHALL 中断
- **AND** 服务 SHALL NOT在body尾部输出error JSON

### Requirement: download grant 与路径修改采用弱一致性

grant SHALL 授权normalized logical path而非inode snapshot。签发后该路径被overwrite、move或delete时，后续下载 MAY 读取新文件或得到not found；活动direct/Nginx下载 SHALL 不持有namespace lock。

#### Scenario: grant后target被覆盖

- **WHEN** 同object_key在下载前被原子overwrite
- **THEN** 有效grant MAY 下载新inode

#### Scenario: 下载中发生delete

- **WHEN** direct handler已打开旧inode后路径被delete
- **THEN** 当前流 MAY 继续读取旧inode

### Requirement: small download 使用固定批量限制和v1 manifest

small SHALL 默认最多100 files、每文件4MiB、总计128MiB。服务 SHALL 在发送headers前打开所有文件并同步计算其`layered_xxh3_128_v1`，manifest/session SHALL 使用v1。stream开始前错误 SHALL JSON失败；开始后错误 SHALL 断连接。

#### Scenario: small批次准备失败

- **WHEN** headers前某文件无法打开或hash
- **THEN** 整批 SHALL 返回JSON error且不开始stream

#### Scenario: small stream中断

- **WHEN** stream开始后任一文件失败
- **THEN** qtransc SHALL 丢弃该batch临时结果
- **AND** 相关文件 SHALL 改走普通download链路

### Requirement: verify 区分file和chunk

file verify SHALL 使用 Redis 正式 hash cache：无可用 hash 时返回 202，hash 可用时返回 200 并包含 match、calculated_hash 和 hash_algorithm，mismatch 也 SHALL 是 200。chunk verify SHALL 同步读取最多一个 104857600-byte 区间并计算 `xxh3_128`，不得创建或修改正式 file hash record。

#### Scenario: file hash pending

- **WHEN** verify file 没有可返回正式 hash
- **THEN** 服务 SHALL 返回 202 `HASH_PENDING` 和 Retry-After 5

#### Scenario: verify mismatch

- **WHEN** client hash 与正式 hash 不同
- **THEN** 服务 SHALL 返回 200、`match=false` 和 calculated hash

#### Scenario: verify 单 chunk

- **WHEN** 请求验证一个合法 chunk 区间
- **THEN** 服务 SHALL 同步读取该区间并返回 `xxh3_128`
- **AND** SHALL NOT 创建 Redis file hash record

### Requirement: qtransc 对下载hash mismatch只自动重下一次

普通下载第一次 file mismatch 时 qtransc SHALL 删除 `.progress` 并从零重下该文件一次；第二次仍 mismatch 时前台 SHALL 失败，serve task SHALL `failed`。v1 small SHALL 保持只重下失败文件且每个文件最多重新下载一次。v2 small SHALL 以整个批次为完整性重试单位，允许两次重新尝试，即最多三次完整传输；第三次仍有任一文件 mismatch 时前台 SHALL 失败，serve task SHALL `failed`。批量任务中已经通过普通或 v1 路径成功的其他文件 SHALL NOT 重下；v2 在批次通过 footer 提交门槛前 SHALL NOT 把其中的单文件视为已成功。

#### Scenario: 首次mismatch

- **WHEN** verify返回match=false且该文件尚未因mismatch重下
- **THEN** qtransc SHALL 从零重下一次

#### Scenario: 第二次mismatch

- **WHEN** 同一文件重下后再次mismatch
- **THEN** 前台 SHALL 非零失败或serve task SHALL failed

#### Scenario: v2 首次或第二次 mismatch

- **WHEN** v2 批次第一次或第二次完整传输出现任一 hash mismatch
- **THEN** qtransc SHALL 丢弃本次整个批次的临时结果并重新传输整个批次

#### Scenario: v2 第三次 mismatch

- **WHEN** v2 批次第三次完整传输仍出现任一 hash mismatch
- **THEN** 前台 SHALL 非零失败或 serve task SHALL failed
- **AND** SHALL NOT 启动第四次完整性尝试

### Requirement: qtransc retry有界且mutation不盲重试

除 canonical upload `complete` 的锁冲突外，qtransc SHALL 对需要修复业务语义后才能继续的失败使用有限次数策略：HTTP `500` 对可恢复传输操作 SHALL 最多自动重试 3 次并使用退避；hash `202` 轮询不计入该次数；`SESSION_BUSY` 与 `NAMESPACE_BUSY` 继续使用各自最多 30 秒窗口；同一请求收到 `401` 后 SHALL 最多 refresh 一次。active upload session 的 canonical `complete` 收到 `SESSION_BUSY` 或 `NAMESPACE_BUSY` 时 SHALL 持续幂等重试，直到 task context 被取消；不得因为固定次数或固定 30 秒窗口失败。move、delete 或其他非幂等 mutation 在结果不确定时 SHALL NOT 自动重复执行。

可恢复传输操作即使同时符合可用性恢复条件，也 SHALL 先遵守其安全语义：PATCH 在响应不确定时先查询服务端确认的 offset，下载重新请求确定的文件范围，complete 仅按幂等结果契约恢复。除上述 canonical complete 的两类锁冲突外，有限语义修复用尽后 SHALL 返回对应业务失败，而 SHALL NOT 把同一状态重新归类为无限可用性恢复。

#### Scenario: PATCH响应不确定

- **WHEN** PATCH连接在response前断开
- **THEN** qtransc SHALL 先GET offset再决定重传

#### Scenario: complete响应不确定

- **WHEN** complete请求断连
- **THEN** qtransc MAY 幂等重试complete或GET session

#### Scenario: complete持续发生namespace锁冲突

- **WHEN** active upload session 的canonical complete持续收到 `NAMESPACE_BUSY` 超过30秒
- **THEN** qtransc SHALL 继续按 `Retry-After` 或既有退避规则重试
- **AND** SHALL NOT仅因该等待超过30秒而结束任务

#### Scenario: complete持续发生session锁冲突

- **WHEN** active upload session 的canonical complete持续收到 `SESSION_BUSY`
- **THEN** qtransc SHALL 继续幂等重试直到成功、任务取消或出现非 busy 错误

#### Scenario: move断连

- **WHEN** move可能已经完成但response丢失
- **THEN** qtransc SHALL 报告不确定结果且不得自动重复mutation

#### Scenario: 服务返回HTTP-date Retry-After

- **WHEN** 可重试响应携带合法HTTP-date
- **THEN** qtransc SHALL 以该时间约束下次尝试

#### Scenario: HTTP/3请求尚未发送即遇到GOAWAY

- **WHEN** HTTP/3协议栈确认请求因旧连接GOAWAY而未打开stream、尚未发送
- **THEN** qtransc SHALL 在连接与stream硬上限内等待或建立替代连接并最多重试一次
- **AND** 该重试 SHALL NOT 被视为结果不确定的mutation重复执行

#### Scenario: HTTP 500重复失败

- **WHEN** 一个可恢复传输操作连续收到 HTTP `500` 且已完成 3 次自动重试
- **THEN** qtransc SHALL 停止自动重试该操作并报告服务端业务失败

### Requirement: qtransc task状态和退出码保持现有集合

serve SHALL 只公开`pending|running|completed|stopped|failed`，不新增paused或partial。主动 pause/stop SHALL 为 stopped 且无任务错误；因执行故障终止 SHALL 为 failed 并保留最终错误，已确认故障 SHALL 优先于后续停止。操作内部可恢复重试期间 SHALL 保持 running。CLI退出码 SHALL 是0成功含warnings、1 remote/auth/network/transfer、2 CLI/local config/planning/state DB、130 SIGINT。stdout SHALL 用于结果，stderr SHALL 用于progress/warnings/errors；`list --json`失败 SHALL 在stdout输出单一JSON error。

显式携带 bearer token 的 download、download2 或 serve download SHALL 使用 self 空间，即使 token 已转存到进程内 auth manager；未显式要求授权下载时，auth manager 中存在 token 不得把匿名下载隐式改成 self。serve HTTP 任务 SHALL 在创建时固定请求级凭据；进程级 token 更新 SHALL NOT 改变已有任务的凭据，使用新凭据 SHALL 重新创建任务。

completed、failed 或 stopped 任务通过 start 重新进入 pending 时 SHALL 只修改状态，保留上一轮内部 error、进度、文件信息及执行时间；HTTP 查询在 pending 阶段 SHALL 隐藏上一轮任务和文件错误及仅用于表达该错误的 message，保留进度与时间，下一次 Run 初始化时才清除内部旧错误。serve SSE SHALL 使用 `qtrans.task.status` 和与 HTTP 相同的状态枚举；主动 pause 导致的取消 SHALL 表达为 `status=stopped`，不得发布文件 failed。旧 WebSocket 帧 SHALL 继续遵守 `legacy-websocket-protocol`。下载选择不存在时，前台 CLI SHALL 在 stderr 输出`未找到该文件`，不得暴露`internal error`或 browse expansion 实现细节。

#### Scenario: task只有warnings

- **WHEN** 所有可传输文件成功且只有skip warnings
- **THEN** task SHALL completed且CLI退出0

#### Scenario: planning limit失败

- **WHEN** 目录规划超过固定限制
- **THEN** task SHALL failed且CLI退出2

#### Scenario: 显式token下载私有对象

- **WHEN** download2或serve download显式携带有效bearer token
- **THEN** browse和下载 SHALL 使用self空间
- **AND** 不得回退到anonymous空间

#### Scenario: 失败任务重新进入等待队列

- **WHEN** failed 任务的 start 请求被接受，任务进入 pending
- **THEN** 内部 SHALL 保留上一轮错误、进度、文件信息及执行时间，HTTP 查询 SHALL 隐藏旧任务和文件错误
- **AND** 下一次 Run 开始时 SHALL 初始化本轮数据并清除旧错误

#### Scenario: 更新进程级 token 后启动原任务

- **WHEN** serve HTTP 任务因凭据失败，调用方更新进程级 token 并重新启动原任务
- **THEN** 原任务 SHALL 继续使用创建时固定的请求级凭据
- **AND** 使用新凭据 SHALL 重新创建任务

#### Scenario: 主动暂停上传

- **WHEN** 运行中的上传任务被主动 pause、文件协程收到 context cancellation，且此前没有已确认的最终故障
- **THEN** serve HTTP 任务状态 SHALL 为 `stopped` 且省略任务 error
- **AND** SSE SHALL 发布 `qtrans.task.status`、`status=stopped`
- **AND** SHALL NOT 因主动取消发布文件 failed

#### Scenario: 执行故障后收到停止

- **WHEN** 任务最终执行故障已记录，随后收到主动停止或清理取消
- **THEN** 本轮 task SHALL 保留 failed 和原故障

#### Scenario: 下载选择不存在

- **WHEN** 前台download请求不存在的远端选择
- **THEN** CLI SHALL 以退出码1结束并输出`未找到该文件`
- **AND** 输出 SHALL NOT 包含`internal error`

### Requirement: 旧GUI外部协议只做内部适配

upload2和download2面向旧GUI的WebSocket、进程和HTTP外部协议 SHALL 保持现有兼容契约；实现 SHALL 只把其内部文件空间、hash算法和canonical API适配到本change。

#### Scenario: 旧GUI启动download2

- **WHEN** 兼容GUI使用既有download2协议
- **THEN** qtransc SHALL 保持原外部消息与进程交互
- **AND** 内部 SHALL 使用统一logical object空间

### Requirement: download恢复准备支持取消

qtransc从`.progress`恢复下载并读取本地数据重建分片hash时 SHALL 响应任务context取消，且 SHALL 保留已持久化的断点数据供后续恢复。

#### Scenario: 本地恢复hash期间暂停任务

- **WHEN** GUI在qtransc读取已有分片并重建hash期间暂停或终止任务
- **THEN** qtransc SHALL 中断恢复准备并退出当前传输
- **AND** SHALL NOT等待全部已有分片完成hash后才响应取消

### Requirement: qtransc 可用性恢复持续至明确终止

活动 upload/download 遇到 transport 错误、临时 DNS 或握手错误、HTTP `408`、`429`、`502`、`503` 或 `504` 时，SHALL 将对应操作视为可用性恢复候选。每次失败尝试 SHALL 先释放网络容量，再从 1 秒开始指数退避到最多 5 秒并加 20% jitter；响应携带合法 `Retry-After` 时 SHALL 同时支持 delta-seconds 与 HTTP-date，并 SHALL 以不早于该值的时间开始下一次尝试。

上述可用性恢复 SHALL NOT 使用固定尝试次数或固定 30 秒无进展窗口作为终止条件。只要任务 context 仍有效、用户未停止、显式总期限尚未到达且没有永久错误，qtransc SHALL 持续重新调度操作并保持可观察的等待或重试状态。该规则 SHALL NOT 允许盲目重放结果不确定的非幂等 mutation，也 SHALL NOT 覆盖本规格中的有限语义修复上限。

#### Scenario: Nginx连接限制返回503

- **WHEN** 一个可恢复上传或下载操作因 Nginx 容量限制收到 HTTP `503`
- **THEN** qtransc SHALL 释放本次请求占用的网络容量并退避后重新调度该操作
- **AND** SHALL NOT 仅因累计超过 30 秒或固定次数而终止任务

#### Scenario: 服务返回HTTP-date Retry-After

- **WHEN** 可重试响应携带合法 HTTP-date `Retry-After`
- **THEN** qtransc SHALL 以该时间约束下次尝试

#### Scenario: 可用性恢复期间取消任务

- **WHEN** 操作正在退避等待且任务 context 被取消
- **THEN** qtransc SHALL 及时停止等待并按既有取消或停止语义结束任务

#### Scenario: 不确定mutation遇到可用性错误

- **WHEN** move 或 delete 可能已经生效但响应丢失
- **THEN** qtransc SHALL 保持不确定结果并 SHALL NOT 因 transport 错误属于可用性候选而自动重放该 mutation

### Requirement: qtransc 显式递归删除远端目录树

`qtransc delete <remote-path>` SHALL 保持调用 canonical 单节点 delete API 的现有语义。`qtransc delete --recursive <remote-path>` 与 `qtransc delete -r <remote-path>` SHALL 显式启用客户端递归删除；它 SHALL 不调用不存在的递归服务端 API，也不得改变 qtserver 单节点 delete API 的行为。两种模式都 SHALL 拒绝根路径 `/`。

递归模式 SHALL 先尝试删除当前节点；仅当该尝试返回 `DIRECTORY_NOT_EMPTY` 时，才 list 其直接子项、处理子项并在全部子项处理后再次删除该目录。它 SHALL 以该后序规则逐节点调用既有单节点 delete API，且 SHALL NOT 跟随 final symlink；final symlink、broken symlink 和 symlink loop SHALL 仅删除链接节点。特殊节点无法删除时 SHALL 导致递归操作失败。

#### Scenario: 未带递归标志删除非空目录

- **WHEN** 用户执行 `qtransc delete /tree` 且 `/tree` 是非空目录
- **THEN** qtransc SHALL 保留服务端的 409 `DIRECTORY_NOT_EMPTY` 结果
- **AND** SHALL NOT 枚举或删除任何 descendant

#### Scenario: 显式递归删除目录树

- **WHEN** 用户执行 `qtransc delete --recursive /tree` 且 `/tree` 下所有节点均可删除
- **THEN** qtransc SHALL 在删除 `/tree` 前删除其全部 descendant
- **AND** SHALL 以成功状态退出

#### Scenario: 递归删除 final symlink

- **WHEN** 递归遍历遇到 final symlink、broken symlink 或 symlink loop
- **THEN** qtransc SHALL 仅删除该链接节点
- **AND** SHALL NOT list、跟随或删除链接目标

#### Scenario: 递归删除根路径

- **WHEN** 用户执行 `qtransc delete --recursive /`
- **THEN** qtransc SHALL 在发起文件 API 请求前失败

### Requirement: qtransc 递归删除限制并明确部分完成结果

递归删除 SHALL 将目录深度限制为 128、累计枚举条目限制为 200000；任何 list 响应的 `truncated=true` SHALL 被视为不可安全完成的失败。初始目标不存在 SHALL 失败；已由并发操作删除的已枚举 descendant SHALL 作为已删除继续处理。客户端不得对任何已发出且结果不确定的 move 或 delete mutation 自动重试。

目录与其他写入并发变化时，客户端 SHALL 为因 `DIRECTORY_NOT_EMPTY` 而重新出现子项的目录重新枚举，单个目录最多重新枚举三次；超出该次数 SHALL 失败。因为删除从第一个成功单节点删除开始不可回滚，达到限制、遇到不可删除节点、目录持续变化或 mutation 结果不确定时，qtransc SHALL 保留已删除节点并以 `RECURSIVE_DELETE_PARTIAL` 报告部分完成、已删除节点数和首个失败路径。失败在任何节点删除前发生时，SHALL 报告原始稳定原因码而非 `RECURSIVE_DELETE_PARTIAL`。

#### Scenario: 枚举结果被截断

- **WHEN** 递归删除所需的任一 list 返回 `truncated=true`
- **THEN** qtransc SHALL 停止后续删除
- **AND** 若此前已删除节点，SHALL 以 `RECURSIVE_DELETE_PARTIAL` 非零退出

#### Scenario: 已枚举子项被并发删除

- **WHEN** 某个已枚举 descendant 的 delete 返回 `NOT_FOUND`
- **THEN** qtransc SHALL 将该 descendant 视为已不存在并继续处理其余节点

#### Scenario: 特殊节点导致中断

- **WHEN** 递归删除遇到服务端拒绝删除的特殊节点且此前已有节点被删除
- **THEN** qtransc SHALL 停止后续删除并以 `RECURSIVE_DELETE_PARTIAL` 非零退出
- **AND** 输出 SHALL 标识该特殊节点路径

#### Scenario: 持续并发写入目录

- **WHEN** 同一目录已三次重新枚举后仍在实际删除时返回 `DIRECTORY_NOT_EMPTY`
- **THEN** qtransc SHALL 停止递归删除并以 `RECURSIVE_DELETE_PARTIAL` 非零退出

### Requirement: 递归删除 JSON 输出是客户端定义的单一结果

`qtransc delete --recursive --json` 成功时 SHALL 在 stdout 输出单一有效 JSON 对象，包含 `code`、`path`、`recursive=true` 和 `deleted_nodes`。部分完成时 SHALL 在 stdout 输出单一有效 JSON error object，包含既有 `code`、`reason_code=RECURSIVE_DELETE_PARTIAL`、`message`、`path`、`deleted_nodes` 和 `failed_path`，并以非零状态退出。未带递归标志的 `delete --json` SHALL 继续原样保留服务端 JSON 结构，不得用该客户端对象替代。

#### Scenario: 递归 JSON 成功

- **WHEN** 用户执行 `qtransc delete -r --json /tree` 并成功完成
- **THEN** stdout SHALL 只包含一个含 `recursive=true` 与 `deleted_nodes` 的 JSON 对象

#### Scenario: 递归 JSON 部分完成

- **WHEN** 用户执行 `qtransc delete -r --json /tree` 且部分节点已经删除后失败
- **THEN** stdout SHALL 只包含一个含 `reason_code=RECURSIVE_DELETE_PARTIAL` 和 `failed_path` 的 JSON error object

### Requirement: 超大普通文件可浏览但不得传输内容

`transfer.max_file_bytes` 只限制内容上传和下载，不限制 canonical `GET /files/list`。list SHALL 对超过该值的普通文件继续返回实际 `size` 与正常可枚举的 entry 事实，不得因其大小隐藏、改写为 unsupported 或使 list 请求失败。

canonical grant SHALL 在签发前验证 batch 中每个去重普通文件的当前大小；任一文件超过上限时，整个 batch SHALL 返回 HTTP 413 `FILE_TOO_LARGE`，包含超限文件的 `file_size` 和 `max_file_bytes`，且不得签发任何 grant。small 和 direct download（含经 Nginx 加速的 direct path）也 SHALL 在开始成功响应或内部重定向前验证当前普通文件大小；超过上限时 SHALL 返回同一 413 错误而不得发送内容 bytes。

#### Scenario: list 超大文件

- **WHEN** 目录含有大小大于 `transfer.max_file_bytes` 的普通文件
- **THEN** list SHALL 成功返回该 entry 的实际 `size`
- **AND** entry SHALL 不因大小限制被隐藏或标记为 unsupported

#### Scenario: grant batch 含超大文件

- **WHEN** grant batch 中任一显式普通文件的当前大小超过 `transfer.max_file_bytes`
- **THEN** 服务 SHALL 返回 HTTP 413 `FILE_TOO_LARGE`，包含该文件大小和上限
- **AND** 服务 SHALL 不返回该 batch 中任何文件的 grant

#### Scenario: 已签发 grant 后文件变大

- **WHEN** direct download 在发送 headers 前观察到获授权路径当前指向的普通文件超过上限
- **THEN** direct 或 Nginx 加速入口 SHALL 返回 HTTP 413 `FILE_TOO_LARGE`
- **AND** SHALL NOT 开始内容流或内部重定向

### Requirement: small download v2 使用独立的可提交 mini-tar 协议

Qtserver SHALL 在 read/download 启用且 `small_download_v2` 可用时注册 `POST /qtserver/v1/d/small-v2`，并继续保留既有 `/qtserver/v1/d/small` v1 路由。v2 请求 SHALL 复用 v1 的 `taskid` 和非空 `files` 对象列表 wire contract。服务端 SHALL 在发送成功响应 headers 前完成所有对象的授权、打开、类型和大小校验，但 SHALL NOT 为构造响应而预先读取完整文件或预先计算整文件哈希。

v2 成功响应 SHALL 为流式 tar，条目顺序 SHALL 固定为：首个 `.qtrans/manifest.json`、manifest 顺序对应的 `payload/000000` 起连续十进制编号 payload、最后一个 `.qtrans/checksums.json`，随后正常结束 tar。Manifest SHALL 包含 `version=2`、`taskid`、`file_count`、`total_unpacked_bytes`、`hash_algorithm=layered_xxh3_128_v1`，以及每个文件的顺序编号、规范化 `object_key`、payload entry 名和字节大小；manifest SHALL NOT 包含预计算 hash。Checksum footer SHALL 使用相同版本、taskid、算法和文件顺序，并包含每个文件的编号、`object_key`、实际发送字节数和服务端边发送边计算的 hash。远端 `object_key` SHALL NOT 直接作为 tar payload 路径。

客户端 SHALL 拒绝重复、缺失、越序、未知或路径不匹配的控制及 payload 条目。只有 footer 完整、一致、所有本地计算 hash 匹配且 footer 后得到正常 tar EOF 时，响应 SHALL 被视为完成；footer 自身存在但 tar 尾部损坏 SHALL NOT 被视为成功。

#### Scenario: v2 正常响应

- **WHEN** 请求内全部对象在 headers 前通过校验且流式读取保持一致
- **THEN** Qtserver SHALL 返回按固定顺序组成的 v2 tar
- **AND** 每个文件 SHALL 只为响应 payload 读取一次
- **AND** checksum footer SHALL 反映实际发送字节和增量计算的哈希

#### Scenario: headers 前批次校验失败

- **WHEN** 任一对象在 headers 前发生授权、打开、类型或限制错误
- **THEN** 整批 SHALL 返回统一 JSON error
- **AND** SHALL NOT 开始 tar 响应

#### Scenario: footer 后 tar 未正常结束

- **WHEN** 客户端读到完整 checksum footer，但随后未得到合法 tar 结束
- **THEN** 当前尝试 SHALL NOT 被提交
- **AND** SHALL 按响应中断规则处理整个批次

#### Scenario: manifest 使用编号 payload

- **WHEN** 请求包含带特殊字符或多层目录的合法 `object_key`
- **THEN** manifest SHALL 保存规范化 `object_key` 与编号 payload 的映射
- **AND** tar payload entry 名 SHALL NOT 直接使用该远端路径

### Requirement: v2 small 批次同时受文件数和总字节数约束

Qtserver SHALL 对 v1 和 v2 保持当前默认硬限制：每批最多 100 个文件、单文件最多 4 MiB、总计最多 128 MiB；实际请求 SHALL 服从 capabilities 公布的当前有效值。qtransc 的 v2 调度目标 SHALL 为每批最多 100 个文件且最多 32 MiB，并 SHALL 同时取客户端目标与服务端限制的较小值。按已规划顺序加入文件时，只要加入下一文件会超过文件数或总字节数任一上限，qtransc SHALL 结束当前非空批次并开始下一批；最后一个非空不足目标的批次 SHALL 立即可调度，不得为凑满目标无限等待。

#### Scenario: 文件数先达到目标

- **WHEN** 100 个小文件总大小小于 32 MiB，且后续仍有小文件
- **THEN** qtransc SHALL 用前 100 个文件形成一个批次
- **AND** 后续文件 SHALL 进入下一批次

#### Scenario: 总字节数先达到目标

- **WHEN** 当前批次不足 100 个文件，但加入下一文件会使总大小超过 32 MiB
- **THEN** qtransc SHALL 结束当前非空批次
- **AND** 下一文件 SHALL 作为新批次的首个文件

#### Scenario: 最后一个批次未达到目标

- **WHEN** 小文件计划已遍历完成且当前批次非空
- **THEN** 该批次 SHALL 立即进入等待 lane 的可调度状态

### Requirement: 下载任务先收敛小文件阶段再进入大文件阶段

混合下载任务 SHALL 先处理 v2 小文件批次。小文件阶段中的每个文件 SHALL 达到成功、明确重分类为普通大文件或终态失败之一后，小文件阶段才 SHALL 收敛；随后 qtransc SHALL 使用既有普通下载链路和 `transfers` 约束处理原计划的大文件及重分类文件。第一版 SHALL NOT 同时运行小文件和大文件阶段。

服务端在开始 v2 响应前发现某个对象已超过当前 small 单文件限制、但未超过普通 `max_file_bytes` 时，SHALL 返回包含该 `object_key` 的稳定 `NOT_SMALL` 错误且不开始 tar。qtransc SHALL 将该文件移入大文件阶段，并使用批次剩余文件重新形成 small 批次；该重分类 SHALL NOT 作为任务错误。

#### Scenario: 混合任务阶段顺序

- **WHEN** 一个任务同时包含 small 文件和普通大文件
- **THEN** qtransc SHALL 先让 small 阶段收敛
- **AND** 在此之前 SHALL NOT 启动普通大文件数据传输

#### Scenario: 文件在请求前增长

- **WHEN** v2 批次中的一个文件已超过 small 单文件限制但仍可普通下载
- **THEN** Qtserver SHALL 在 headers 前返回指明该文件的 `NOT_SMALL`
- **AND** qtransc SHALL 将该文件转入大文件阶段并重新安排批次剩余文件
- **AND** SHALL NOT 把 `NOT_SMALL` 记录为最终错误

### Requirement: v2 小文件以批次为重试和收敛单位

v2 尝试在合法 footer 和 tar 结束前发生连接错误、超时、响应截断或 HTTP `408`、`429`、`502`、`503`、`504` 时，qtransc SHALL 丢弃当前尝试并按既有可用性恢复策略重试整个批次，直到成功、任务 context 取消、显式总期限到达或出现永久错误。HTTP `500` SHALL 以整个批次为操作单位应用既有“最多自动重试 3 次”的有界策略。格式完整的 v2 响应存在任一文件 hash mismatch 时，qtransc SHALL 重试整个批次，最多允许两次重新尝试，即最多三次完整传输；第三次仍 mismatch SHALL 形成终态完整性错误。

`401` refresh 次数、`Retry-After`、不可恢复认证或授权、业务对象不存在、本地磁盘错误以及其他既有错误分类 SHALL 保持原契约。结构非法但网络传输完整的 manifest、footer 或 tar SHALL 形成不可自动重试的协议错误。v2 批次内部重试 SHALL 独立于 recursive task 的“无文件成功则停止下一轮”规则；一次可恢复批次尝试没有文件完成 SHALL NOT 提前阻止本 Requirement 明确允许的下一次尝试。

#### Scenario: HTTP 500 后整批成功

- **WHEN** 一个 v2 批次首次请求收到 HTTP `500`，并在允许次数内重新请求成功
- **THEN** qtransc SHALL 重新请求整个批次
- **AND** 首次 `500` SHALL NOT 使任何批次文件形成最终失败

#### Scenario: HTTP 500 重试耗尽

- **WHEN** 一个 v2 批次在首次尝试后又完成 3 次自动重试且均收到 HTTP `500`
- **THEN** qtransc SHALL 停止自动重试该批次
- **AND** SHALL 将该业务失败作为终态错误

#### Scenario: 连续两次 hash mismatch 后成功

- **WHEN** 同一 v2 批次前两次完整响应均发生 hash mismatch，第三次全部匹配
- **THEN** qtransc SHALL 提交第三次批次结果
- **AND** 前两次 mismatch SHALL NOT 使任务最终状态异常

#### Scenario: 连续三次 hash mismatch

- **WHEN** 同一 v2 批次连续三次完整响应均发生 hash mismatch
- **THEN** qtransc SHALL 停止自动重试整个批次
- **AND** SHALL 报告终态完整性错误

#### Scenario: availability 重试不持有 lane

- **WHEN** 一个截断的 v2 响应需要退避后重试
- **THEN** qtransc SHALL 先关闭响应体并释放当前 lane
- **AND** 下一次整批尝试 SHALL 重新申请 lane

#### Scenario: 完整但非法的 footer

- **WHEN** HTTP 响应完整结束但 footer 的版本、taskid、文件集合或条目映射与 manifest 不一致
- **THEN** qtransc SHALL 报告终态协议错误
- **AND** SHALL NOT 将其归类为无限可用性恢复

### Requirement: qtransc 递归删除提供人类可读的活动状态

未带 `--json` 的 `qtransc delete -r/--recursive` SHALL 在 stderr 提供递归删除的活动状态，且不得等待全部节点完成后才首次输出。状态 SHALL 标识当前是枚举目录还是删除节点，并提供已确认删除的节点数、近期节点速率、已用时间和当前处理的逻辑路径。节点数只计入服务端已成功确认的 delete；客户端 SHALL NOT 为生成总数或百分比而预扫描整棵目录树，也不得展示推测的总数或百分比。

当 stderr 是交互终端时，客户端 SHALL 原位刷新单条状态；当 stderr 不是交互终端时，客户端 SHALL 输出完整的、带换行的状态行，并将连续状态限频至最多每秒一次。两种模式在结束前都 SHALL 完成当前状态行，随后再输出既有成功摘要或错误。该状态仅用于人类观察，SHALL NOT 改变递归删除顺序、已删除节点计数、退出码、错误原因码或重试语义。

`qtransc delete -r/--recursive --json` SHALL 不输出上述人类状态；它的 stdout 继续只包含既有的单一最终 JSON 对象。

#### Scenario: 交互终端中删除大量节点

- **WHEN** 用户在交互终端执行 `qtransc delete -r /tree` 且删除持续进行
- **THEN** stderr SHALL 持续原位展示已确认删除节点数、速率、已用时间和当前逻辑路径
- **AND** 在枚举目录时 SHALL 表示正在扫描该目录
- **AND** stdout SHALL 只保留既有的最终成功摘要

#### Scenario: 重定向 stderr 的递归删除

- **WHEN** 用户执行 `qtransc delete -r /tree 2>delete.log`
- **THEN** `delete.log` SHALL 包含完整的换行状态记录而非终端控制字符
- **AND** 连续状态记录 SHALL 不超过每秒一行

#### Scenario: JSON 递归删除

- **WHEN** 用户执行 `qtransc delete -r --json /tree`
- **THEN** stdout SHALL 只包含既有的单一最终 JSON 对象
- **AND** 客户端 SHALL NOT 输出人类进度状态

### Requirement: CLI 服务地址省略端口时使用 23500

qtransc CLI 的 --server SHALL 接受 host[:port]。省略端口时 SHALL 使用 23500；显式指定端口时 SHALL 使用该端口，并继续校验端口范围、IPv6 方括号及现有地址格式约束。

#### Scenario: CLI 省略端口

- **WHEN** 用户执行 qtransc --server qt.example.com list /
- **THEN** SHALL 连接 qt.example.com:23500

#### Scenario: CLI 显式覆盖端口

- **WHEN** 用户执行 qtransc --server qt.example.com:8443 list /
- **THEN** SHALL 连接 qt.example.com:8443

### Requirement: v2 任务目标始终为目录

v2 src 为文件时 SHALL 复制到 dst/basename(src)；src 为目录时 SHALL 将内容按源内相对层级复制到 dst。非根路径尾部斜杠 SHALL 不改变含义。缺失目标目录及父目录 SHALL 自动创建；空目录 SHALL 保留；已有目录 SHALL 合并且保留额外内容。目标文件 SHALL 沿用既有校验与默认覆盖策略，文件与目录 SHALL NOT 相互替换。

#### Scenario: 目录复制内容

- **WHEN** src=/data/dir1 包含 sub/a.txt，dst=/backup
- **THEN** 最终文件 SHALL 为 /backup/sub/a.txt
- **AND** 空源目录 SHALL 使 /backup 存在

#### Scenario: 目标为文件

- **WHEN** dst 或所需父目录已被文件占用
- **THEN** 任务 SHALL 在传输前失败且不替换该节点

### Requirement: v2 任务只提交一次完整复制计划

v2 任务每轮进入 running 后 SHALL 先检查能力。没有成功计划时 SHALL 展开源并检查全部映射、目标类型和限制，通过后一次提交文件与目录清单。提交前 SHALL NOT 创建目标目录或传输内容。未提交时 start/autoRetry SHALL 可重新规划；已提交后 SHALL 复用清单、不递归重扫，仍重新检查文件元数据、授权、目标状态及续传数据。停止 SHALL 取消当前规划，计划仅在当前进程任务生命周期内保留。

#### Scenario: 已提交后源增加文件

- **WHEN** 原目录新增文件并再次 start
- **THEN** 新增文件 SHALL 不加入已有计划

#### Scenario: 规划中失败或暂停

- **WHEN** 展开未完成就失败或取消
- **THEN** SHALL 不发布部分计划，下次执行可重新展开

#### Scenario: 已提交后源消失

- **WHEN** 计划内文件被删除
- **THEN** 后续执行 SHALL 报告错误而不静默删除该记录

### Requirement: v2 计划检查副本冲突与限制

每份副本 SHALL 计入普通文件数和总字节数，源重叠 SHALL 不隐式去重；每次映射枚举的节点 SHALL 计入累计条目数。SHALL 沿用 100000 文件、200000 条目、128 层及逻辑路径长度上限。完全重复配对、重复最终文件目标、文件占用目录或祖先、实际本地大小写冲突 SHALL 使整个计划失败。不同目录 SHALL 可合并到同一 dst，且一源 SHALL 可映射多个不同目标。任何截断目录列表 SHALL 使规划失败。

#### Scenario: 同源两份副本

- **WHEN** 一个大小为 10 字节的源文件分别复制到 /a 与 /b
- **THEN** SHALL 生成两条记录并计为两个文件、20 字节

#### Scenario: 两个目录包含同名文件

- **WHEN** 两个源目录都含 a.txt 且 dst 相同
- **THEN** SHALL 在创建目录或内容传输前失败，不以默认覆盖解决任务内部冲突

### Requirement: v2 扫描变化及特殊节点处理

扫描 SHALL 不承诺内容快照；新增节点只有被本次枚举观察到才纳入计划。已观察条目消失、不可读或无法确定类型 SHALL 使规划失败。显式本地链接或特殊节点 SHALL 拒绝，嵌套链接或特殊节点 SHALL 跳过并警告；远端正常链接 SHALL 按既有目标类型跟随。源根目录 SHALL 拒绝，目标根目录 SHALL 允许且不得请求远端 mkdir 根路径。传输期间文件错误与已完成内容 SHALL 沿用原有失败和续传规则。

#### Scenario: 枚举后子项消失

- **WHEN** 本地 stat 失败或远端列表含 ENTRY_CHANGED/ENTRY_UNREADABLE
- **THEN** SHALL 放弃本次计划并报告执行错误

#### Scenario: 目标为远端根

- **WHEN** 上传文件到 dst=/
- **THEN** SHALL 按原名写入逻辑根下且不请求 mkdir /
