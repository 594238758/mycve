# user-file-space Specification

## Purpose
定义 Qtserver 的统一 principal 文件空间、存储根、家目录生命周期、anonymous 边界、权限策略和基础读写能力。
## Requirements

### Requirement: 所有正式文件使用统一 principal 空间

Qtserver SHALL 将 principal 的全部正式上传、下载和文件管理对象映射到 `<user_home_root>/<principal_id>/`，文件系统 SHALL 是正式内容的事实来源。服务 SHALL NOT 继续暴露或自动迁移旧上传目录、旧 staging 或旧 session。

#### Scenario: 上传完成后立即读取

- **WHEN** `/docs/a.bin` 的 canonical upload 完成原子发布
- **THEN** list、download 和文件管理 API SHALL 在同一 principal 空间看到该对象

#### Scenario: 切换到新空间

- **WHEN** 新版本首次部署
- **THEN** 服务 SHALL NOT 合并、复制或解释旧版存储目录中的数据

### Requirement: user_home_root 必须通过严格启动校验

`user_home_root` SHALL 是运维预先创建的绝对 Clean path、可访问的真实目录，并且该目录节点自身 SHALL NOT 是 symlink。服务 SHALL 使用解析祖先 symlink 后的实际位置判断根目录关系。

#### Scenario: 根目录无效

- **WHEN** user_home_root 缺失、是相对路径、是 symlink、不是目录或不可访问
- **THEN** Qtserver SHALL 拒绝启动

#### Scenario: 根目录祖先包含 symlink

- **WHEN** user_home_root 自身是真实目录但其祖先包含有效 symlink
- **THEN** 启动校验 SHALL 允许该路径并按实际位置比较目录关系

### Requirement: temp_root 是独占上传缓存根

write 能力开启时，Qtserver SHALL 使用绝对 temp_root 保存上传缓存；未配置时 SHALL 使用 `<user_home_root>/.uploadtemp`。除该默认位置外，temp_root SHALL 位于 user_home_root 外，且不得等于、包含 user_home_root 或被 user_home_root 包含。temp_root SHALL NOT 是 symlink、文件或特殊节点。

#### Scenario: 创建缺失的 temp_root

- **WHEN** write 开启且合法 temp_root 不存在
- **THEN** Qtserver SHALL 以 `0700` 创建它

#### Scenario: 已有 temp_root 权限过宽

- **WHEN** write 开启且已有合法目录的 mode 不是 `0700`
- **THEN** Qtserver SHALL 收紧为 `0700`，失败则拒绝启动

#### Scenario: 只读服务配置 temp_root

- **WHEN** write 能力关闭
- **THEN** Qtserver SHALL NOT 创建、检查或清理 temp_root

### Requirement: 原子发布要求缓存和目标位于同一文件系统

Qtserver SHALL 只使用原子 rename 发布上传缓存，SHALL NOT 退化为跨文件系统复制后删除。服务无需在启动时扫描所有实际用户家目录。

#### Scenario: complete 遇到跨文件系统目标

- **WHEN** cache 与实际目标不支持同文件系统原子 rename
- **THEN** complete SHALL 返回 HTTP 500 `CROSS_DEVICE_PUBLISH`
- **AND** cache 与 session SHALL 保留以便运维修复后重试

### Requirement: principal ID 原样采用受信任身份结果

Qtserver SHALL 原样使用 access token 解析、身份服务或 fake-token 映射给出的 principal ID，不校验格式、长度、字符、路径安全或保留名，也不 trim、规范化或编码。身份适配层和 fake-token 配置 SHALL 被视为完全可信。

#### Scenario: 身份结果包含普通点号

- **WHEN** 上游返回包含点号或 Unicode 的 principal ID
- **THEN** Qtserver SHALL 原样拼入用户家目录路径

#### Scenario: 身份结果不安全

- **WHEN** 上游返回路径分隔符、`..`、`anonymous` 或 `.uploadtemp` 等危险值
- **THEN** Qtserver SHALL NOT 提供额外隔离保证
- **AND** 目录逃逸、空间碰撞或跨 principal 访问 SHALL 被视为身份适配或部署错误

### Requirement: 普通用户家目录允许指向外部目录

普通 principal 家目录可以是有效 symlink，Qtserver SHALL 跟随其目标，即使目标位于 user_home_root 外。API 调用方 SHALL NOT 能通过逻辑根路径操作家目录 symlink 节点本身。

#### Scenario: 家目录链接有效

- **WHEN** `<user_home_root>/<principal_id>` 是指向外部普通目录的有效 symlink
- **THEN** 文件 API SHALL 在该目标目录中工作

#### Scenario: 家目录链接损坏

- **WHEN** 家目录 symlink 损坏
- **THEN** 根 list SHALL 返回空空间且不修复链接
- **AND** 具体读请求 SHALL 返回 404
- **AND** 写请求 SHALL 失败且不得替换该链接

#### Scenario: 家目录链接损坏且 list 初始化未生效

- **WHEN** 家目录 symlink 损坏，且 `user_home_init_on_list` 与 `write_enabled` 未同时开启
- **THEN** 根 list SHALL 返回空空间且不修复链接
- **AND** 具体读请求 SHALL 返回 404
- **AND** 写请求 SHALL 失败且不得替换该链接

#### Scenario: 家目录链接损坏且 list 初始化生效

- **WHEN** 家目录 symlink 损坏，且 `user_home_init_on_list=true`、`write_enabled=true` 的普通 principal 请求根 list
- **THEN** 服务 SHALL 返回 HTTP 500 `HOME_INITIALIZATION_FAILED`
- **AND** SHALL NOT 修复或替换该链接

### Requirement: 缺失普通用户家目录按受控条件创建

`user_home_init_on_list` SHALL 是 `[server]` 下的布尔配置且默认 `false`。缺失普通家目录时，只有 mkdir、create、已经成功进入发布阶段的 complete，以及同时满足 `user_home_init_on_list=true`、`write_enabled=true` 的普通 principal 根 list MAY 创建家目录。具体对象读取、非根 list、upload init、move 和 delete SHALL NOT 因缺失家目录产生目录副作用。list 请求与响应 SHALL NOT 为此能力增加字段。

#### Scenario: 首次根目录 list

- **WHEN** 普通 principal 家目录不存在并请求 list `/`
- **THEN** 服务 SHALL 返回 200、空 entries 和 `truncated=false`
- **AND** 家目录 SHALL 仍不存在

#### Scenario: 首次 move 或 delete

- **WHEN** 普通 principal 家目录不存在并调用 move 或 delete
- **THEN** 服务 SHALL 返回 404 `NOT_FOUND`
- **AND** SHALL NOT 创建家目录或初始化目录

#### Scenario: 首次上传只执行 init

- **WHEN** 普通 principal 家目录不存在并创建 upload session
- **THEN** init MAY 创建缓存状态但 SHALL NOT 创建正式家目录

#### Scenario: 默认首次根目录 list

- **WHEN** 普通 principal 家目录不存在、`user_home_init_on_list` 缺省或为 `false`，并请求 list `/`
- **THEN** 服务 SHALL 返回 200、空 entries 和 `truncated=false`
- **AND** 家目录 SHALL 仍不存在

#### Scenario: 配置开启后的首次根目录 list

- **WHEN** 普通 principal 家目录不存在、`user_home_init_on_list=true`、`write_enabled=true`，并请求 list `/`
- **THEN** 服务 SHALL 创建并初始化该 principal 家目录
- **AND** SHALL 返回 200 及初始化后的实际根目录 entries

#### Scenario: write 关闭时首次根目录 list

- **WHEN** 普通 principal 家目录不存在、`user_home_init_on_list=true`、`write_enabled=false`，并请求 list `/`
- **THEN** 服务 SHALL 返回 200、空 entries 和 `truncated=false`
- **AND** 家目录 SHALL 仍不存在

#### Scenario: 首次非根目录 list

- **WHEN** 普通 principal 家目录不存在且请求根目录以外的 list，无论 `user_home_init_on_list` 取值如何
- **THEN** 服务 SHALL 返回 404 `NOT_FOUND`
- **AND** SHALL NOT 创建家目录或初始化目录

#### Scenario: 首次根目录 list 遇到 namespace lock 冲突

- **WHEN** 已配置生效的首次根目录 list 无法取得该 principal 的 namespace lock
- **THEN** 服务 SHALL 返回 409 `NAMESPACE_BUSY` 和 `Retry-After: 1`
- **AND** SHALL NOT 在未持有锁时开始初始化

### Requirement: 新普通家目录执行一次性初始化

`user_home_init_dirs` SHALL 只应用于本次调用新建的普通 principal 家目录。配置项名称 SHALL 是唯一一级 UTF-8 目录名，并拒绝空、`.`、`..`、分隔符和 NUL；uid 与 gid SHALL 同时出现且非负；mode SHALL 接受 `700`、`0700` 或 `0o700` 并限制在 `0000..0777`。非法配置 SHALL 使启动失败。

#### Scenario: 新建家目录初始化成功

- **WHEN** mkdir、create、complete 或配置生效的根 list 新建普通 principal 家目录
- **THEN** 服务 SHALL 创建全部 init dirs 并应用配置的 ownership 和 mode

#### Scenario: 新建家目录初始化中途失败

- **WHEN** 初始化操作失败
- **THEN** 服务 SHALL best-effort 删除本次新建的整个家目录
- **AND** 若仍有残留 SHALL 返回 `HOME_INITIALIZATION_FAILED`
- **AND** 后续请求 SHALL NOT 自动补建残留家目录

#### Scenario: 家目录已经存在

- **WHEN** principal 家目录在调用前已经存在
- **THEN** 服务 SHALL NOT 补建 init dirs，也 SHALL NOT 重新 chmod 或 chown

#### Scenario: 根 list 初始化失败

- **WHEN** 配置生效的根 list 创建或初始化普通 principal 家目录失败
- **THEN** 服务 SHALL 返回 HTTP 500 `HOME_INITIALIZATION_FAILED`

### Requirement: managed 权限只作用于新创建对象

Qtserver SHALL 以规范化逻辑路径的第一个 segment 选择 managed policy。mkdir、create、complete 和配置生效的首次根 list SHALL 对其创建的新目录或新 inode 应用策略；除首次根 list 创建初始化目录外，list、download、move 和 delete SHALL NOT 应用或重写策略。无匹配策略时，新文件 SHALL 使用 `0666 & umask`，新目录 SHALL 使用 `0777 & umask`。

#### Scenario: 在 managed 一级目录中发布文件

- **WHEN** complete 在匹配 managed policy 的路径下创建新 inode
- **THEN** rename 前 SHALL 对缓存文件应用精确 managed mode 和 ownership

#### Scenario: managed 一级目录是外部 symlink

- **WHEN** 匹配的第一级是指向外部目录的有效 symlink
- **THEN** 服务 SHALL 跟随链接并对其后新创建对象应用策略

#### Scenario: move 已有对象

- **WHEN** 文件被 move 到另一个 managed 路径
- **THEN** move SHALL NOT 重新应用 destination 的 mode 或 ownership

### Requirement: 上传缓存权限不得泄漏到正式文件

principal 缓存子目录 SHALL 使用 `0700`，传输中的缓存文件 SHALL 使用 `0600`。complete SHALL 在发布前应用 managed mode 或 `0666 & umask`，不得把缓存 `0600` 无条件继承为正式权限。

#### Scenario: 发布非 managed 文件

- **WHEN** 一个 `0600` cache file 完成发布且路径不匹配 managed policy
- **THEN** rename 前正式 mode SHALL 被设置为 `0666 & umask`

### Requirement: anonymous 空间必须显式启用

`anonymous_enabled` SHALL 默认 false。启用时，Qtserver SHALL 确保 `<user_home_root>/anonymous` 是真实目录：缺失则创建，已有非空真实目录可直接使用，symlink、文件或特殊节点 SHALL 使启动失败。

#### Scenario: 使用已有 anonymous 数据

- **WHEN** anonymous 已启用且 anonymous 目录是真实非空目录
- **THEN** Qtserver SHALL 保留其内容并正常启动

#### Scenario: anonymous 节点是 symlink

- **WHEN** anonymous 已启用但对应节点是 symlink
- **THEN** Qtserver SHALL 拒绝启动

### Requirement: anonymous 读写使用最小鉴权模型

`anonymous_enabled` SHALL 默认 false。启用时，无 Authorization 的 `GET /files/list` SHALL 映射到 anonymous principal，且该映射 SHALL NOT 依赖 `read_enabled`。无凭据的内容下载请求只有在 anonymous 与 `read_enabled` 同时开启、对应下载路由已注册时，才 SHALL 映射到 anonymous principal。

anonymous write 必须携带代码内固定公开 token `00000000-0000-4000-8000-000000000000`；该 UUID-v4 结构常量不是 secret，也不得配置。anonymous 与 write 同时启用时，持有者 SHALL 具有 canonical upload 和文件管理的完整权限，包括 overwrite。

qtransc 普通 `upload`、`mkdir`、`move`、`delete` 未显式提供 token 或用户名密码时 SHALL 自动使用固定 anonymous 写 token，且 SHALL NOT 要求用户手工输入该常量。显式认证 SHALL 优先并保持对应普通用户语义。该客户端默认行为 SHALL NOT 应用于 `upload2`。

#### Scenario: 无认证匿名浏览

- **WHEN** anonymous 开启且 `GET /files/list` 没有 Authorization，无论 `read_enabled` 取值如何
- **THEN** 请求 SHALL 在 anonymous 空间执行

#### Scenario: 无认证匿名下载

- **WHEN** anonymous 与 read 同时开启，且下载请求没有 Authorization
- **THEN** 请求 SHALL 在 anonymous 空间执行

#### Scenario: anonymous 未开启时无凭据浏览

- **WHEN** anonymous 未开启且客户端无 Authorization 调用 `GET /files/list`
- **THEN** 服务 SHALL 返回 401

#### Scenario: anonymous 未开启时普通用户浏览

- **WHEN** anonymous 未开启、普通 principal 可用且客户端携带有效普通用户凭据调用 `GET /files/list`
- **THEN** 服务 SHALL 按该普通 principal 的文件空间执行请求，而不得因 anonymous 未开启拒绝请求

#### Scenario: 无认证匿名写入

- **WHEN** anonymous write 路由收到缺失 Authorization 的请求
- **THEN** 服务 SHALL 返回 401

#### Scenario: 固定 token 写入

- **WHEN** anonymous 与 write 均开启且 canonical write 请求携带固定 token
- **THEN** 服务 SHALL 以 anonymous principal 执行，包括覆盖和删除既有 anonymous 对象

#### Scenario: qtransc canonical 写命令未指定认证

- **WHEN** 用户执行 qtransc 普通 `upload`、`mkdir`、`move` 或 `delete` 且未提供 token 或用户名密码
- **THEN** qtransc SHALL 使用固定 anonymous 写 token 执行对应 canonical 写操作

#### Scenario: qtransc canonical 写命令显式认证

- **WHEN** 用户执行 qtransc 普通 `upload`、`mkdir`、`move` 或 `delete` 且显式提供 token 或用户名密码
- **THEN** qtransc SHALL 使用该认证且 SHALL NOT 回退 anonymous

#### Scenario: 非法 token 尝试匿名回退

- **WHEN** list、download 或 write 请求携带无效 token
- **THEN** 服务 SHALL 返回认证错误且 SHALL NOT 回退 anonymous

#### Scenario: anonymous 未开启

- **WHEN** 请求携带固定 token 但 anonymous 未开启
- **THEN** 服务 SHALL 返回 401

#### Scenario: upload2 收到固定 token

- **WHEN** upload2 请求携带固定 anonymous token
- **THEN** qtransc SHALL 在传输前拒绝该请求

### Requirement: anonymous 不使用普通用户初始化策略

anonymous SHALL 始终使用进程 umask 创建对象，SHALL NOT 应用 `user_home_init_dirs` 或普通 principal managed ownership/mode。

#### Scenario: anonymous 首次写入

- **WHEN** 固定 token 首次在 anonymous 空间创建目录和文件
- **THEN** 新目录 SHALL 使用 `0777 & umask`
- **AND** 新文件 SHALL 使用 `0666 & umask`

### Requirement: capability 开关决定路由是否存在

`read_enabled` SHALL 只控制下载路由是否注册：`POST /d/grant`、`POST /d/small`、`POST /d/verify` 和 `GET /d/down/*objectKey`。当 `read_enabled=false` 时，这些路由 SHALL 不注册并返回 404 `ROUTE_NOT_FOUND`。

`write_enabled` SHALL 是全部远端 mutation 的总开关。关闭时，canonical upload 的全部路由，以及 `POST /files/mkdir`、`POST /files/move`、`POST /files/delete` 和 `POST /files/create` SHALL 不注册并返回 404 `ROUTE_NOT_FOUND`，且 `GET /files/list` SHALL NOT 初始化普通用户家目录。

`GET /files/list` SHALL 始终注册，且 SHALL NOT 因 `read_enabled` 或 `write_enabled` 被关闭而返回 route-not-found；其访问仍受对应 principal 鉴权和文件空间规则约束。

#### Scenario: write 关闭

- **WHEN** 客户端访问 upload 或文件管理写路由
- **THEN** 服务 SHALL 返回 404 `ROUTE_NOT_FOUND`

#### Scenario: read 关闭

- **WHEN** 客户端访问任一下载路由且 read 关闭
- **THEN** 服务 SHALL 返回 404 `ROUTE_NOT_FOUND`

#### Scenario: 读写均关闭时浏览

- **WHEN** read 与 write 均关闭且已鉴权客户端访问 `GET /files/list`
- **THEN** 服务 SHALL 注册并按正常 list 契约处理该请求，而不得返回 `ROUTE_NOT_FOUND`
- **AND** SHALL NOT 初始化缺失的普通用户家目录

### Requirement: 新配置不兼容旧存储字段

新配置 schema SHALL 直接替换旧存储配置，不接受旧 storage roots、staging、HMAC CLI secret 或其他兼容别名。配置校验 SHALL 拒绝未知字段。

#### Scenario: 旧配置启动新服务

- **WHEN** 配置仍包含被删除的旧存储字段
- **THEN** `config validate` 和 Qtserver 启动 SHALL 失败并指出未知或废弃字段

### Requirement: nginx_acc 只接受安全内部 URI prefix

`nginx_acc` 为空时 SHALL 使用 direct download。非空值 SHALL 以 `/` 开头、不是根、不含 scheme、host、query、fragment、percent、反斜杠、NUL 或 dot segment，并在保存时去除尾随 slash。

#### Scenario: nginx_acc 合法

- **WHEN** read 开启且 nginx_acc 通过校验
- **THEN** Qtserver SHALL 生成逐 segment UTF-8 percent-encoded 的 internal URI
- **AND** Nginx SHALL decode 一次并 alias 到 user_home_root

#### Scenario: Nginx 无法读取外部 symlink 目标

- **WHEN** Qtserver 签发 X-Accel 响应后 Nginx 无权读取实际目标
- **THEN** 服务 SHALL NOT 回退 direct
- **AND** 客户端 MAY 收到 Nginx 原生 403、404 或 5xx

### Requirement: X-Accel-Redirect 数据面由 Nginx 直接发送文件

read 开启且 `nginx_acc` 非空时，Qtserver SHALL 在授权下载成功后返回 `X-Accel-Redirect` 内部 URI；Nginx SHALL 在 internal location 按 `user_home_root` alias 直接发送文件字节。Qtserver SHALL 只做存在性与类型校验（stat），不得读取或流式传输正式文件内容。Nginx SHALL 原生处理 HTTP Range，完整请求返回 200，单 Range 返回 206。

#### Scenario: X-Accel 下载由 Nginx 发送

- **WHEN** 授权下载使用 X-Accel-Redirect
- **THEN** Nginx SHALL 从 `user_home_root` alias 发送文件
- **AND** Qtserver SHALL 不读取该文件的内容字节

#### Scenario: Range 由 Nginx 处理

- **WHEN** 客户端对 X-Accel 下载发送单 Range
- **THEN** Nginx SHALL 返回 206
- **AND** 完整下载 SHALL 返回 200
