# client-preflight-timeouts Specification

## Purpose

为 qtransc 的 qtserver capabilities 连接预检提供有限、可预期的完成时间，避免错误域名或不可达端口使前台命令无限等待，同时不限制实际文件内容传输。

## Requirements

### Requirement: capabilities 预检具有总期限

qtransc 在直接命令或 qtransc serve 任务启动中获取 qtserver capabilities 时 SHALL 使用不晚于预检开始后 15 秒到期的 context deadline。该期限 SHALL 覆盖 DNS 解析、TCP 或 UDP 建连、TLS 或 QUIC 握手、HTTP 响应读取及所有可用性重试；调用方已经提供更早 deadline 时 SHALL 使用该更早 deadline。预检失败后，直接命令 SHALL 结束；serve SHALL 完成本轮任务收尾而不得无限等待。serve 预检 SHALL 在任务接受后的执行准备阶段进行，使用本轮任务 context，主动停止 SHALL 能取消该预检。

该期限只适用于 capabilities 预检；实际文件内容的上传和下载 SHALL NOT 因此获得 15 秒总期限。

#### Scenario: 默认 v3 端口无响应

- **WHEN** 用户以默认 `v3` 执行直接命令，且 `--server` 指向一个 UDP 数据包被静默丢弃的端口
- **THEN** capabilities 预检 SHALL 在开始后不晚于约 15 秒结束
- **AND** CLI SHALL 使用既有 `SERVER_UNAVAILABLE` 错误契约报告失败

#### Scenario: 调用方提供更早期限

- **WHEN** capabilities 预检的调用方提供了早于 15 秒的 context deadline
- **THEN** qtransc SHALL 在该更早 deadline 到达时停止预检和重试

#### Scenario: serve 任务使用不可达服务器

- **WHEN** qtransc serve 为新上传或下载任务执行 capabilities 预检，且任务指定的 server 不可达
- **THEN** 预检 SHALL 在开始后不晚于约 15 秒结束
- **AND** serve SHALL 使已接受任务 failed 并保存对应执行错误，创建及查询成功时 HTTP 外层 SHALL 保持成功，而不得无限等待

#### Scenario: 文件传输持续超过预检期限

- **WHEN** capabilities 预检已成功，随后实际文件上传或下载持续超过 15 秒
- **THEN** qtransc SHALL NOT 仅因该预检期限取消文件数据传输

### Requirement: 永久 DNS 失败不重试

qtransc 在 capabilities 预检中识别到永久 DNS 解析失败时 SHALL 停止当前预检，而不得将该失败作为可用性错误继续重试。临时 DNS 失败和其他可恢复网络错误 MAY 重试，但所有重试 SHALL 受 capabilities 预检总期限约束。

#### Scenario: 不存在的域名

- **WHEN** 用户执行直接命令且 `--server` 的主机名无法解析，并被 DNS 解析器标记为非临时错误
- **THEN** qtransc SHALL 不启动下一次 capabilities 重试
- **AND** CLI SHALL 使用既有 `SERVER_UNAVAILABLE` 错误契约报告失败

#### Scenario: 临时 DNS 故障

- **WHEN** capabilities 预检遇到 DNS 超时或被 DNS 解析器标记为临时错误
- **THEN** qtransc MAY 在预检总期限内按既有退避策略重试
- **AND** 总期限到达后 SHALL 结束预检
