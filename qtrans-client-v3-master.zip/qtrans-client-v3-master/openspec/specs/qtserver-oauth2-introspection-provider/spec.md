# qtserver-oauth2-introspection-provider Specification

## Purpose
定义 Qtserver 如何在不改变既有 `auth`、`fake`、`off` mode 的前提下，通过通用 RFC 7662 Token Introspection provider 将 bearer token 解析为可信 principal，并保持授权决策位于 Qtserver 内部。

## Requirements

### Requirement: oauth2-introspection 作为新增兼容 mode

Qtserver SHALL 在 `identity.mode` 的既有 `auth`、`fake`、`off` 之外新增 `oauth2-introspection`。现有三个 mode 的配置字段、token 解析、远程 `/userinfo` 调用方式、缓存 TTL 和 anonymous 行为 SHALL 保持不变；`auth` 身份结果及缓存中的邮箱按 `raw-business-event-log` 契约维护。Qtserver SHALL NOT 将既有 mode 重命名、迁移或隐式转换为新 provider。

#### Scenario: 继续使用 auth mode

- **WHEN** 现有部署使用合法 `identity.mode="auth"` 配置启动
- **THEN** Qtserver SHALL 继续使用既有 `/userinfo` 行为
- **AND** SHALL NOT 要求 introspection 配置

#### Scenario: 选择新 mode

- **WHEN** 配置设置 `identity.mode="oauth2-introspection"`
- **THEN** Qtserver SHALL 使用 RFC 7662 provider
- **AND** SHALL NOT 调用既有 `/userinfo` adapter

### Requirement: 新 provider 只配置 endpoint

Qtserver identity 配置 SHALL 只新增并在配置权威文档与生产模板中完整写出 `introspection_endpoint`。选择 `oauth2-introspection` 时该字段 SHALL 非空且为绝对 HTTP 或 HTTPS URL。Qtserver SHALL 按配置使用 endpoint，SHALL NOT 因 endpoint 使用 HTTP、目标为非 loopback 地址或跨机器访问而拒绝配置。其他 mode SHALL 忽略空的 endpoint 字段并继续使用各自既有字段。Qtserver SHALL NOT 提供 introspection client ID 或 client secret 配置项。

#### Scenario: 新 mode 缺少 endpoint

- **WHEN** `identity.mode="oauth2-introspection"` 但 `introspection_endpoint` 为空
- **THEN** `config validate` 和 Qtserver 启动 SHALL 失败

#### Scenario: 远程 endpoint 使用 HTTP

- **WHEN** introspection endpoint 配置为 `http://192.0.2.10:10020/oauth2/introspect`
- **THEN** `config validate` SHALL 接受该 endpoint
- **AND** Qtserver SHALL 直接通过 HTTP 调用它

#### Scenario: 既有 mode 的 endpoint 为空

- **WHEN** 完整生产模板包含空 `introspection_endpoint` 且 `identity.mode="fake"`
- **THEN** Qtserver SHALL 正常校验 fake mode

### Requirement: 新 provider 只接受标准 Bearer credential

当且仅当启用 `oauth2-introspection` 时，受保护请求的普通用户凭据 SHALL 使用 RFC 6750 `Authorization: Bearer <token>`；scheme 比较不区分大小写，Bearer 后 SHALL 有非空 token。裸 token、其他 scheme 和空 Bearer SHALL 返回 401 `INVALID_TOKEN` 且 SHALL NOT 调用 introspection endpoint。该严格解析 SHALL NOT 改变 `auth`、`fake`、`off` 的既有兼容行为。

#### Scenario: 标准 Bearer UUID

- **WHEN** 新 provider 收到 `Authorization: Bearer 3d797212-75fe-46fb-8707-97bd6896e4c1`
- **THEN** Qtserver SHALL 把 UUID token 交给 introspection provider

#### Scenario: 新 provider 收到裸 token

- **WHEN** Authorization header 只包含 UUID token 而没有 Bearer scheme
- **THEN** Qtserver SHALL 返回 401
- **AND** SHALL NOT 调用 introspection endpoint

### Requirement: Qtserver 按 RFC 7662 调用 introspection endpoint

Qtserver SHALL 使用 HTTP POST、`application/x-www-form-urlencoded` body 中的 `token` 与 `token_type_hint=access_token` 调用配置的 endpoint，并按 OAuth `client_secret_basic` 使用内置 `client_id="qtserver"` 和 `client_secret="qtserver-introspection"` 验证自身。第一版 SHALL NOT 允许配置或轮换这组值；它们是公开的协议标识而不是安全边界。请求 SHALL 拒绝 endpoint redirect，并使用既有 `identity.timeout_seconds` 作为单次调用 timeout。

#### Scenario: 调用 qtuser

- **WHEN** Qtserver 解析一个标准 bearer token
- **THEN** 它 SHALL 向精确配置的 endpoint 发送 authenticated form POST
- **AND** SHALL NOT 调用 `/userinfo`、`/oauth2/token` 或 OIDC endpoint

#### Scenario: endpoint 返回 redirect

- **WHEN** introspection endpoint 返回 3xx redirect
- **THEN** Qtserver SHALL NOT 跟随 redirect
- **AND** SHALL 将其判定为 provider 故障

#### Scenario: 调用第三方 introspection provider

- **WHEN** 部署方把 endpoint 指向 Keycloak 或其他 RFC 7662 provider
- **THEN** 该 provider SHALL 配置为接受内置 `qtserver` / `qtserver-introspection` credentials
- **AND** Qtserver SHALL NOT 为该 provider 改用其他 client identity

### Requirement: active 与 sub 构成 provider 身份结果

HTTP 200 JSON response 中 `active=true` 且 `sub` 为非空 string 时，Qtserver SHALL 创建普通 principal，principal ID SHALL 精确等于 `sub`；`active=false` SHALL 表示无效或失效 token，并使当前受保护请求返回 401 `INVALID_TOKEN`。Qtserver SHALL 忽略合法 response 中不需要的额外字段。

可选顶层 `email` 为 string 时，Qtserver SHALL 去除首尾空白并将其保留为 principal 的日志邮箱，供 `client_username` 使用。缺失、null、非 string 或空邮箱 SHALL 视为邮箱不可用，SHALL NOT 影响 `active`/`sub` 的身份判定，也 SHALL NOT 触发 provider 故障。Qtserver SHALL NOT 从 `username` 或 `sub` 推测邮箱；邮箱 SHALL NOT 参与本地授权。

非 200、非 JSON、缺失或非 boolean `active`、`active=true` 但缺失非空 `sub`、连接、TLS 或 timeout 错误 SHALL 是 provider 故障而不是无效 token。Qtserver SHALL NOT 从 `id`、`data.id`、`code` 或登录 redirect 猜测身份。

#### Scenario: active token

- **WHEN** endpoint 返回 `200 {"active":true,"sub":"alice","token_type":"Bearer"}`
- **THEN** Qtserver SHALL 得到普通 principal `alice`

#### Scenario: inactive token

- **WHEN** endpoint 返回 `200 {"active":false}`
- **THEN** 当前请求 SHALL 返回 401 `INVALID_TOKEN`
- **AND** SHALL NOT 将该结果判定为 provider 故障

#### Scenario: active token 带邮箱

- **WHEN** endpoint 返回 `200 {"active":true,"sub":"user-42","email":"alice@example.com"}`
- **THEN** Qtserver SHALL 得到 ID 为 `user-42`、日志邮箱为 `alice@example.com` 的普通 principal
- **AND** 文件空间和授权 SHALL 仍使用 `user-42`

#### Scenario: 可选邮箱不可用

- **WHEN** active response 具有合法 `sub`，但没有可用的 string `email`
- **THEN** Qtserver SHALL 正常认证并使用空日志邮箱
- **AND** SHALL NOT 因该可选字段触发 graceful shutdown

#### Scenario: 私有 userinfo 响应

- **WHEN** endpoint 只返回 `code`、`id` 或 `data.id` 而没有 boolean `active`
- **THEN** Qtserver SHALL 将其判定为 provider 协议故障

### Requirement: provider 只认证身份且 Qtserver 本地授权

`oauth2-introspection` SHALL 只把 token 转换为普通 principal。Qtserver SHALL 原样信任非空 `sub`，不额外 trim、规范化或限制字符；文件空间、上传 session、transfer grant 和其他对象访问 SHALL 继续按现有 principal 规则在 Qtserver 内判断。Response 中的 `scope`、`aud`、`roles`、`groups` 和其他 claims SHALL NOT 扩大或缩小访问权限。

#### Scenario: response 包含 scope

- **WHEN** active response 同时包含 `scope` 或 `roles`
- **THEN** Qtserver SHALL 只使用 `sub` 确定 principal ID，可选 `email` 仅用于业务日志
- **AND** SHALL 按既有本地规则执行授权

### Requirement: 第一版不缓存 introspection 结果

Qtserver SHALL 对使用 `oauth2-introspection` mode 的每个普通 bearer token 请求调用 endpoint，SHALL NOT 把 active 或 inactive 结果写入 Redis 或进程内 token cache。既有 `auth` mode 的 `userinfo_cache_ttl_seconds` 行为 SHALL 保持不变。

#### Scenario: qtuser 替换 token

- **WHEN** 用户 token 已在 qtuser 中替换且旧 token 再次用于 Qtserver 请求
- **THEN** Qtserver SHALL 重新 introspect 旧 token
- **AND** SHALL 按 `active=false` 拒绝该请求

### Requirement: provider authentication 和响应不得泄漏

Qtserver SHALL NOT 在配置输出、普通日志、错误日志或客户端响应中记录或回显内置 introspection client credential、请求 bearer token、HTTP Authorization、introspection form body 或完整 response body。日志 MAY 记录 endpoint、失败阶段、HTTP status 和 timeout/cause。

#### Scenario: provider 返回含敏感内容的错误

- **WHEN** endpoint 返回非成功 status 且 body 包含 token 或用户信息
- **THEN** Qtserver 日志 SHALL NOT 记录完整 response body
