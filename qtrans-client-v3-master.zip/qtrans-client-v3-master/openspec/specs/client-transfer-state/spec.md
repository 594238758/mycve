# client-transfer-state Specification

## Purpose
定义 qtransc 使用 SQLite 恢复 canonical upload 的最小本地状态、源文件一致性、多进程缺陷边界和清理语义。
## Requirements
### Requirement: qtransc 只用 SQLite 持久化未完成上传

qtransc SHALL 使用 SQLite `upload_files` 保存 canonical upload 与 upload2 的未完成文件 session。下载、完整 serve task、task 状态、服务端 chunk map、token 和 principal SHALL NOT 写入该数据库。

#### Scenario: qtransc 进程重新启动

- **WHEN** 用户用相同业务键重新执行未完成上传
- **THEN** qtransc SHALL 从 upload_files 定位 session
- **AND** SHALL 从 Qtserver GET 返回的服务端进度继续

#### Scenario: serve 重新启动

- **WHEN** qtransc serve 进程重启
- **THEN** 它 SHALL NOT 自动重建旧 task
- **AND** 调用方重新创建相同业务键后 MAY 恢复 session

#### Scenario: 执行下载命令

- **WHEN** list 或 download 接受全局 state-db flag
- **THEN** 命令 SHALL NOT 打开或修改 SQLite

### Requirement: state_db 使用固定默认位置或显式绝对路径

qtransc SHALL 新增全局 `--state-db`，供 upload、upload2 和 serve 使用。显式值 SHALL 是绝对路径。Linux 默认 SHALL 固定为 `$HOME/.qtrans/state/upload.db`，并 SHALL 忽略 `XDG_STATE_HOME`。本 change SHALL NOT 增加 serve 配置字段或环境变量优先级。

#### Scenario: 未提供参数

- **WHEN** Linux 用户运行 upload 且未提供 `--state-db`
- **THEN** qtransc SHALL 使用 `$HOME/.qtrans/state/upload.db`

#### Scenario: 提供绝对路径

- **WHEN** 用户提供 `--state-db /srv/qtrans/state.db`
- **THEN** upload、upload2 或 serve SHALL 使用该文件

#### Scenario: 提供相对路径

- **WHEN** 用户提供相对 state-db
- **THEN** qtransc SHALL 以 CLI/local config 错误拒绝启动

### Requirement: SQLite 文件必须具有本地安全属性

qtransc SHALL 创建 DB parent 为 `0700`，DB、WAL 和 SHM 为 `0600`；final DB path SHALL NOT 是 symlink。Unix 上已有文件 owner SHALL 是当前 euid。SQLite SHALL 使用 `user_version=1`、WAL、`synchronous=FULL`、`busy_timeout=5000`、`foreign_keys=ON` 和 `wal_autocheckpoint=1000`。

#### Scenario: 数据库路径是 symlink

- **WHEN** final state-db 节点是 symlink
- **THEN** qtransc SHALL 拒绝打开并报告本地状态错误

#### Scenario: 数据库被其他 Unix 用户拥有

- **WHEN** 已有数据库 owner 不是当前 euid
- **THEN** qtransc SHALL 拒绝使用它

#### Scenario: 短暂写锁竞争

- **WHEN** 另一个 qtransc 短暂持有 SQLite 写锁
- **THEN** 当前进程 SHALL 等待最多 busy_timeout

### Requirement: 不自动删除损坏或不兼容数据库

qtransc SHALL 在 SQLite 损坏、schema 不兼容或 `user_version` 高于 1 时停止并报告错误，SHALL NOT 自动删除、重建或降级数据库。

#### Scenario: SQLite 损坏

- **WHEN** integrity/open 检测到数据库损坏
- **THEN** qtransc SHALL 失败并保留原文件供用户诊断

#### Scenario: 数据库来自未来版本

- **WHEN** user_version 大于当前程序支持值
- **THEN** qtransc SHALL 拒绝运行且 SHALL NOT 修改数据库

### Requirement: upload_files 使用整数主键和业务唯一键

`upload_files` SHALL 使用 `INTEGER PRIMARY KEY` 且 SHALL NOT 使用 AUTOINCREMENT。唯一键 SHALL 是 `(local_absolute_path,server,remote_absolute_path)`；local path SHALL 使用 `filepath.Abs` 与 `Clean` 且不 EvalSymlinks，server SHALL 使用现有 normalized origin，remote SHALL 使用规范化逻辑绝对路径。

#### Scenario: 同一本地文件上传到两个 remote

- **WHEN** local 与 server 相同但 remote 不同
- **THEN** SHALL 存为两行独立 session

#### Scenario: 相同业务键重复 init

- **WHEN** qtransc 需要用新 session 替换旧 session
- **THEN** SHALL 在同一业务键行内事务性替换 session 数据

### Requirement: state_db 不区分 principal 也不提供业务 lease

本 change SHALL 接受多个 qtransc 进程共享 SQLite，但 SHALL NOT 为行增加 owner/lease，也 SHALL NOT 把 principal 放入 unique key。同一业务键被多个进程或账号同时使用可能竞争、覆盖 session ID 或并发发送同一 chunk，属于已知客户端设计缺陷。

#### Scenario: 两个进程上传同一业务键

- **WHEN** 两个 qtransc 同时恢复同一行
- **THEN** SQLite busy timeout MAY 保护单次事务
- **AND** qtransc SHALL NOT 承诺只有一个进程执行该上传

#### Scenario: 两个账号共享 state_db 和业务键

- **WHEN** 两个 principal 使用相同 local/server/remote key
- **THEN** 其记录 MAY 冲突
- **AND** 用户 SHALL 通过使用不同 state-db 自行隔离

### Requirement: upload_files 只保存恢复定位字段

每行 SHALL 保存 session ID、normalized business key、size、mtime、ctime、可用时的平台 file ID、完整 hash/algorithm 和 updated_at。当前客户端新建或替换的行 SHALL 保存 init 使用的完整 hash 和算法；既有空 hash 恢复记录 MAY 继续按原恢复协议读取，但 SHALL NOT 放宽新 init 的必填 hash 契约。行 SHALL NOT 保存 session expires、Authorization/token、principal、完整 chunk 状态或 task。

#### Scenario: 新 session 在 init 前完成 hash 计算

- **WHEN** qtransc 为本地文件创建新的 canonical upload session
- **THEN** 它 SHALL 先完成完整 file hash 计算，再提交 init
- **AND** init 成功后的本地行 SHALL 保存该 hash 和算法

#### Scenario: 本地行很旧

- **WHEN** updated_at 很久以前但服务端 session 仍存在
- **THEN** qtransc SHALL 尝试 GET session
- **AND** SHALL NOT 仅凭本地时间判定过期

### Requirement: init 后必须先提交本地 row 再传 bytes

qtransc SHALL 在 init 成功后事务性写入 upload_files，只有事务 commit 成功后才能发送第一个 PATCH。写入失败 SHALL best-effort cancel 新 session 并返回 `LOCAL_STATE_ERROR`。init 成功到 row commit 之间的进程崩溃 MAY 留下服务端 orphan。

#### Scenario: SQLite 写入失败

- **WHEN** init 已返回 session 但本地事务不能 commit
- **THEN** qtransc SHALL NOT 发送文件 bytes
- **AND** SHALL best-effort cancel session

#### Scenario: 进程在 commit 前崩溃

- **WHEN** 服务端 session 已创建而本地行尚未提交
- **THEN** 客户端 SHALL NOT 假定能恢复该 session
- **AND** 服务端 TTL/orphan scanner SHALL 最终清理它

### Requirement: 服务端进度始终覆盖 SQLite 推测

SQLite SHALL 只定位 session。qtransc 恢复时 SHALL 以 GET session/chunk 返回的 stored offset、state 和 committed result 为事实，SHALL NOT 保存或信任本地 chunk map。

#### Scenario: 服务端未 checkpoint 最后几秒

- **WHEN** 本地曾发送的 bytes 超过服务端 GET stored offset
- **THEN** qtransc SHALL 从服务端 offset 覆盖重传

#### Scenario: 服务端已经 committed

- **WHEN** 本地仍有行但 GET session 返回 committed result
- **THEN** qtransc SHALL 将上传视为成功并只执行本地清理/release

### Requirement: 每个文件任务使用单一 source handle

qtransc SHALL 为一个上传文件只打开一次 source handle，并由并行 chunks 使用 `ReadAt` 读取。fingerprint SHALL 从该 handle 获取。Linux file ID SHALL 使用 dev+ino；Windows SHALL 在可用时使用 volume serial+file index，不可用时可为空。

#### Scenario: 路径被替换但旧 handle 仍有效

- **WHEN** 上传开始后路径名被 rename/replaced而打开的 inode 未变化
- **THEN** workers SHALL 继续读取原 handle

#### Scenario: 已打开 inode 内容发生变化

- **WHEN** size、mtime、ctime 或可用的平台 file ID 与任务 fingerprint 不同
- **THEN** qtransc SHALL 触发 `LOCAL_FILE_CHANGED`

### Requirement: 本地 fingerprint 变化先删除 row 再停止上传

检测到本地源 fingerprint 变化后，qtransc SHALL 先删除对应 SQLite 行，再停止 workers并 best-effort cancel旧 session。无论 cancel 是否成功，下次执行 SHALL NOT 恢复旧 session。前台命令 SHALL 非零退出；serve task SHALL 进入 `failed` 并提示传输期间不可修改本地文件。

serve 创建时显式启用 `autoRetry` 的任务 SHALL 在该轮完全结束后重新排队，保留客户端 taskId，但为新内容生成新的服务端执行 ID，并重新打开源文件、获取 fingerprint、计算 hash。变化文件 SHALL 按新开始流程初始化；未变化文件的可恢复状态仍 SHALL 按既有指纹和服务端状态校验后使用。未启用该选项 SHALL 保持要求新建任务的行为。

#### Scenario: 运行中检测到本地变化

- **WHEN** 任一 worker 或 complete 前检查发现 fingerprint 变化
- **THEN** SQLite row SHALL 在 cancel 之前删除
- **AND** 前台 SHALL 退出或 serve task SHALL failed

#### Scenario: cancel 请求失败

- **WHEN** 删除 row 后无法连接 Qtserver cancel
- **THEN** qtransc SHALL 继续新的开始流程而 SHALL NOT 恢复旧 session

### Requirement: SESSION_NOT_FOUND 创建新 session 并原子替换 row

服务端返回 `SESSION_NOT_FOUND` 时，qtransc SHALL 保留仍匹配的 fingerprint 和本地 hash，重新 init，并在事务 commit 新 session ID 后才发送 PATCH。

#### Scenario: 服务端 TTL 已删除 session

- **WHEN** SQLite 行仍存在但 GET 返回 404 `SESSION_NOT_FOUND`
- **THEN** qtransc SHALL init 新 session
- **AND** 新 row commit 之前 SHALL NOT 开始上传 bytes

### Requirement: pause 与显式放弃必须区分

Ctrl+C、GUI pause 和暂时网络故障 SHALL 保留 active session 与 SQLite 行且不调用 cancel。用户显式放弃、LOCAL_FILE_CHANGED 或 session 被新 session 取代时 SHALL 删除行后 best-effort cancel。

#### Scenario: 用户按 Ctrl+C

- **WHEN** 前台上传收到 SIGINT
- **THEN** 命令 SHALL 以 130 退出
- **AND** SQLite 行和服务端 active session SHALL 保留

#### Scenario: serve DELETE task

- **WHEN** 调用方删除活动 task
- **THEN** qtransc SHALL 停止 workers、删除相关 SQLite rows并 best-effort cancel active sessions
- **AND** SHALL NOT 删除 remote 正式文件或本地用户文件

### Requirement: 成功后清理 row 再 release

complete 或服务端判定同目标内容相同后，qtransc SHALL 删除 upload_files 行，再 best-effort release committed session。删除失败 SHALL 不改变业务已完成事实，但 task SHALL 报告 `LOCAL_STATE_CLEANUP_FAILED` 且本次不 release。

#### Scenario: complete 后 SQLite 删除成功

- **WHEN** complete 返回 committed success且 row 删除成功
- **THEN** qtransc SHALL best-effort 调用 release

#### Scenario: complete 后 SQLite 删除失败

- **WHEN** 正式文件已成功但本地 row 无法删除
- **THEN** task SHALL 完成文件传输但报告 `LOCAL_STATE_CLEANUP_FAILED`
- **AND** 下次 GET committed SHALL 重试清理和 release

### Requirement: SQLite 丢失不能恢复原 session

客户端 SHALL NOT 从 Qtserver 枚举 principal 的 active sessions。state_db 行丢失时 SHALL 创建新 session，旧 session只由 TTL、cancel 或 orphan scanner 清理。

#### Scenario: 用户删除 state_db

- **WHEN** 本地没有业务键记录但服务端仍有旧 active session
- **THEN** qtransc SHALL 创建新 session
- **AND** SHALL NOT 猜测或搜索旧 session ID

### Requirement: 下载恢复状态保持在目标旁边

下载 SHALL 继续用目标文件和 `.progress` sidecar 表达局部进度，SHALL NOT 写入 upload state_db。完成校验前最终路径上的部分文件 MAY 可见。pause SHALL 保留这些文件；task delete SHALL 删除 qtransc-owned `.progress`/临时文件但 SHALL NOT 删除用户文件。

#### Scenario: 下载暂停

- **WHEN** 下载在 partial 状态暂停
- **THEN** 目标文件和 `.progress` SHALL 保留供恢复

#### Scenario: 删除下载 task

- **WHEN** 调用方删除 serve download task
- **THEN** qtransc SHALL 清理 `.progress`
- **AND** 已写入的用户目标文件 SHALL 保留

### Requirement: Windows 普通分片下载使用稀疏目标文件

qtransc 在 Windows 上执行普通分片下载时 SHALL 在分片写入前尝试启用目标文件的稀疏属性，成功后 SHALL 将逻辑大小设为预期文件大小，避免为未写入区间主动填零。续传 SHALL 保留预期范围内已有数据和 `.progress` 恢复语义，SHALL NOT 仅凭文件逻辑大小报告成功。无法启用稀疏属性时 SHALL 记录警告并回退普通写入；启用成功但设置大小失败时 SHALL 停止该文件下载并释放文件句柄。该行为 SHALL 覆盖 download、download2 和 serve 的普通分片链路，不改变非 Windows 和小文件批次行为。

#### Scenario: 新建文件并乱序写入

- **WHEN** Windows 普通分片下载在支持稀疏文件的目标文件系统上开始
- **THEN** 首个分片写入前目标文件 SHALL 已具有稀疏属性和预期逻辑大小
- **AND** 未下载区域 SHALL NOT 因预设逻辑大小而被计入已下载进度

#### Scenario: 暂停后续传

- **WHEN** 存在目标文件和 `.progress`，用户恢复 Windows 下载
- **THEN** 文件准备 SHALL 保留预期范围内已有数据，不得先截断至零
- **AND** 客户端 SHALL 继续按保存进度恢复分片并进行完整性校验

#### Scenario: 逻辑大小已匹配但内容不完整

- **WHEN** 稀疏目标文件已具有完整逻辑大小，但 `.progress` 丢失且部分内容未下载
- **THEN** 客户端 SHALL 进行内容校验，不得仅凭大小标记文件成功
- **AND** 校验失败后的整文件重试 SHALL 在再次写入前重新准备稀疏文件及逻辑大小

#### Scenario: 稀疏属性设置失败

- **WHEN** 文件系统不支持稀疏文件或稀疏属性设置被拒绝
- **THEN** 客户端 SHALL 记录警告，保留已有内容并沿用普通文件写入
- **AND** SHALL NOT 为模拟稀疏文件而主动填零或增加强制刷盘

#### Scenario: 设置逻辑大小失败

- **WHEN** 稀疏属性已启用，但无法设置目标逻辑大小
- **THEN** 该文件 SHALL 报告本地错误，关闭文件句柄且不启动分片写入

#### Scenario: 非 Windows 或小文件批次

- **WHEN** 客户端在非 Windows 系统运行，或文件经小文件批次传输
- **THEN** SHALL 保持原有文件创建、写入和发布流程

### Requirement: v2 小文件批次使用尝试级临时状态

qtransc SHALL 将 v2 批次的每个 payload 写入目标路径旁由 qtransc 唯一命名和管理的临时文件，并在写入过程中计算 `layered_xxh3_128_v1`。这些临时文件 SHALL NOT 写入 upload state DB，也 SHALL NOT 作为普通下载 `.progress` 恢复状态。响应缺少完整 checksum footer、tar 未正常结束、条目不完整或任一哈希不匹配时，当前尝试的全部未发布临时文件 SHALL 被删除后才进入整批重试。

#### Scenario: footer 前连接中断

- **WHEN** 客户端已写完部分或全部 payload，但未收到完整合法的 checksum footer 和 tar 结束标记
- **THEN** 当前批次 SHALL NOT 被视为验证成功
- **AND** 当前尝试的全部未发布临时文件 SHALL 被删除

#### Scenario: 任务在批次传输中暂停

- **WHEN** v2 批次正在传输且任务被主动 pause
- **THEN** 当前请求 SHALL 被取消
- **AND** 当前尝试的未发布临时文件 SHALL 被清理
- **AND** pause SHALL NOT 把相关文件记录为失败

#### Scenario: 删除下载任务

- **WHEN** 调用方删除包含 v2 小文件临时状态的下载任务
- **THEN** qtransc SHALL 删除仍存在的 qtrans-owned 批次临时文件
- **AND** SHALL NOT 删除已经发布的用户目标文件

### Requirement: v2 批次先整体验证再逐文件发布

qtransc SHALL 在 footer、tar 结束、文件集合、大小和全部哈希验证成功前不把本批次任何新临时文件发布为最终目标。验证成功后 SHALL 逐文件原子替换对应目标；跨文件发布不承诺形成单个文件系统事务。发布某个文件失败时，已经成功发布的文件 SHALL 保持成功，尚未发布的临时文件 SHALL 被清理，失败文件 SHALL 形成终态本地错误且 SHALL NOT 仅为重试本地发布而重新下载整个批次。

#### Scenario: 全批验证成功

- **WHEN** v2 响应包含与 manifest 一致的全部 payload、合法 footer、匹配哈希和正常 tar 结束
- **THEN** qtransc SHALL 在验证全部文件之后才开始逐文件发布
- **AND** 全部发布成功时该批次 SHALL 成功

#### Scenario: 发布中途发生本地错误

- **WHEN** 批次验证成功，第一个文件已发布，但后续文件无法替换目标路径
- **THEN** 已发布文件 SHALL 保持成功且不得被删除
- **AND** 失败文件 SHALL 报告终态本地错误
- **AND** 尚未发布的 qtrans-owned 临时文件 SHALL 被清理

### Requirement: 尝试错误与任务最终错误分离

小文件 worker SHALL 返回可区分的成功、重试、转入大文件和终态失败结果。一次请求、stream 或完整性尝试产生的临时错误 SHALL 只进入该批次的重试状态，不得直接追加到任务最终错误；批次后来成功或其文件成功转入大文件链路后，历史尝试错误 SHALL NOT 使任务进入异常终态。只有永久错误或重试策略耗尽后仍未完成的文件 SHALL 贡献任务最终错误。

#### Scenario: 首次失败后整批成功

- **WHEN** 一个 v2 批次首次尝试失败并在后续尝试中完整成功
- **THEN** 该批次所有文件 SHALL 记为成功
- **AND** 首次尝试错误 SHALL NOT 出现在任务最终错误中

#### Scenario: 文件转入大文件阶段后成功

- **WHEN** 服务端确认批次中的一个文件已不符合 small 限制，且该文件随后通过普通下载成功
- **THEN** small 尝试结果 SHALL 只触发阶段迁移
- **AND** SHALL NOT 使最终任务状态异常

#### Scenario: 完整性重试耗尽

- **WHEN** 同一 v2 批次连续三次完整传输均发生哈希不一致
- **THEN** 第三次完整性错误 SHALL 成为终态错误
- **AND** 任务 SHALL 按既有状态分类结束

### Requirement: v2 实时字节进度与批次完成状态分离

qtransc SHALL 在读取每个 v2 payload entry 前把对应文件登记为活动文件，并在每次从响应成功读取正数字节且写入尝试临时文件时，同步推进该文件和任务的 live logical transferred bytes 与实际 network bytes。文件和任务的 rate SHALL 继续根据实际 network payload bytes 按既有不大于 300ms 的内存采样周期计算，且 SHALL 汇总同时活动的多个 mini-tar；tar control entry、header、padding 和业务日志等待时间 SHALL NOT 计入 payload progress 或 rate。

单个文件的 logical transferred 达到文件大小时，文件 MAY 显示 100%，但在整个批次 footer、全部 hash、tar EOF 和该文件本地发布完成前 SHALL 保持 `in_progress`，SHALL NOT 增加 `VerifiedFileNum` 或发布 completed 状态。批次全部验证后，客户端 SHALL 按实际逐文件发布结果连续发布最终文件 progress 和 completed 状态，因此完成文件数 MAY 在一个观察周期内批量增长。

批次尝试失败并准备重试时，qtransc SHALL 在删除尝试临时文件的同时把本批次尚未发布文件的 logical transferred 重置为 0；任务 logical progress MAY 因此回退。实际 network bytes SHALL 保留失败尝试已经接收的 payload，后续重传 SHALL 继续计入 network rate，但 logical transferred SHALL NOT 因重复接收同一文件而超过文件或任务 total。外部 CLI、REST、SSE 和兼容 WebSocket SHALL 继续读取同一组实时内存事实。

#### Scenario: v2 payload 仍在传输

- **WHEN** 一个 v2 payload entry 只读取并写入了部分字节
- **THEN** 对应文件和任务的 live transferred SHALL 已包含这些字节
- **AND** rate SHALL 能在当前批次完成前反映实际网络吞吐

#### Scenario: payload 已写完但 footer 尚未到达

- **WHEN** v2 批次中的文件 payload 已完整写入临时文件，但 checksum footer 尚未完成验证
- **THEN** 该文件的 logical transferred MAY 等于 total
- **AND** 文件 SHALL 保持 `in_progress`
- **AND** `VerifiedFileNum` SHALL NOT 因此增加

#### Scenario: 批次验证后集中完成

- **WHEN** v2 批次的 footer、全部 hash 和 tar EOF 验证成功且多个文件连续发布成功
- **THEN** 每个文件 SHALL 发布最终 progress 与 completed 状态
- **AND** 调用方 MAY 在一次观察快照中看到完成文件数增加多个

#### Scenario: 批次失败后重试

- **WHEN** v2 批次已经接收部分 payload 后因连接中断或完整性错误进入重试
- **THEN** 该批次未发布文件的 logical transferred SHALL 重置为 0
- **AND** 任务 progress MAY 回退后随下一次尝试重新增长
- **AND** 实际 network bytes 与 rate SHALL 保留并继续统计重试流量

### Requirement: 每轮执行按需打开并收尾本地上传状态

上传任务 SHALL 在 pending 阶段不持有 `upload_files` 数据库连接。每轮 Run 需要恢复信息时 SHALL 按 `state-db` 打开 Store，执行及清理结束后 SHALL 关闭连接但保留 SQLite 中的续传数据。删除续传记录时 MAY 为清理重新打开 Store 并在结束后关闭。关闭 Store SHALL NOT 删除数据库、WAL 或续传行。

#### Scenario: completed 后状态连接关闭

- **WHEN** 一个上传任务成功完成一轮执行
- **THEN** 该轮 SHALL 关闭自己的 upload state Store
- **AND** 后续查询和 pending 阶段 SHALL NOT 依赖已关闭连接
- **AND** 下一次 Run 需要恢复时 SHALL 重新打开 Store

#### Scenario: 删除时清理续传记录

- **WHEN** 调用方删除一个已完成或已停止的上传任务
- **THEN** 清理 MAY 重新打开 Store 删除该任务的文件行
- **AND** SHALL 在清理结束后关闭连接

### Requirement: completed 重新执行必须重新确认目标

`completed` 任务通过 `/start` 进入新一轮时，qtransc SHALL 重新检查源和目标，而 SHALL NOT 依赖上一轮的 `Verified`、`Uploaded`、文件 `Exists` 或已 committed 的服务端会话。目标仍存在且校验一致时 MAY 沿用既有跳过/校验规则；目标已被删除时 SHALL 重新传输。

#### Scenario: completed 上传的远端目标被删除

- **WHEN** 上传任务 completed 后，服务端目标文件被删除，调用方再次启动同一任务
- **THEN** 下一轮 SHALL 重新创建上传会话并传输该文件
- **AND** SHALL NOT 因上一轮 completed 或旧会话 committed 标记跳过

#### Scenario: completed 下载的本地目标被删除

- **WHEN** 下载任务 completed 后，本地目标文件被删除，调用方再次启动同一任务
- **THEN** 下一轮 SHALL 重新下载该文件
- **AND** SHALL NOT 因上一轮文件对象仍保留 `Verified` 或 `Received` 而跳过

#### Scenario: 目标仍完整存在

- **WHEN** completed 任务重新执行且源和目标当前内容一致
- **THEN** qtransc MAY 按既有校验规则跳过实际字节传输
- **AND** 任务仍 SHALL 以当前轮的结果发布状态
