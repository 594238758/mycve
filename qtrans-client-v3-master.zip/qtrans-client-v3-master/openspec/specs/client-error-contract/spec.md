# client-error-contract Specification

## Purpose
为 qtransc 的直接命令与 serve 控制面提供统一、脱敏且可自动处理的错误原因码，使人类用户和运维系统能稳定识别同一类故障。

## Requirements

### Requirement: CLI 使用稳定原因码和中文可读错误

qtransc 的直接命令在非 JSON 模式发生可报告错误时 SHALL 在 stderr 使用 `Error [REASON_CODE]: 中文说明` 格式。`REASON_CODE` SHALL 是稳定的大写下划线标识符；来自 qtserver 结构化错误的 `reason_code` SHALL 原样传递。客户端自身产生的错误 SHALL 使用稳定客户端原因码，至少包括 `CLI_INVALID_ARGUMENT`、`AUTH_CONFIG_INVALID`、`AUTH_LOGIN_REJECTED`、`AUTH_LOGIN_FAILED`、`AUTH_REFRESH_FAILED`、`ANONYMOUS_READ_UNAVAILABLE`、`ANONYMOUS_WRITE_UNAVAILABLE`、`CAPABILITY_UNAVAILABLE`、`SERVER_UNAVAILABLE`、`RECURSIVE_DELETE_PARTIAL`、`MUTATION_RESULT_UNKNOWN`、`FILE_TOO_LARGE`、`TASK_FILE_LIMIT_EXCEEDED`、`LOCAL_FILE_NOT_FOUND`、`LOCAL_PATH_INVALID` 和 `TASK_SIZE_LIMIT_EXCEEDED`。

当本地 `--server` 校验失败时，CLI SHALL 保持 `CLI_INVALID_ARGUMENT` 原因码，并固定输出中文说明 `--server 参数不合法`。该说明 SHALL NOT 泄露认证凭据或令牌，也 SHALL NOT 按端口、协议、路径或其他具体失败原因改变文案。

参数解析、规划、任务执行、进度展示和最终 CLI 输出 SHALL 保留 typed error 及其 reason code，不得在中间层只保存或重新构造错误字符串。`--debug` SHALL 保留额外的底层诊断信息，但所有模式均 SHALL NOT 输出用户名、密码、access token、refresh token、OAuth client secret 或 Authorization header。用户名密码认证被拒绝时 SHALL 使用 `AUTH_LOGIN_REJECTED`，不得声称是用户名或密码中某一项错误。

#### Scenario: 路径不存在

- **WHEN** 直接 CLI 命令收到 qtserver 的 `NOT_FOUND`
- **THEN** stderr SHALL 输出 `Error [NOT_FOUND]:` 开头的中文说明

#### Scenario: 本地上传源不存在

- **WHEN** qtransc 在规划时发现指定的本地上传源不存在
- **THEN** 它 SHALL 使用 `LOCAL_FILE_NOT_FOUND` 和中文说明报告错误

#### Scenario: 本地目标路径无效

- **WHEN** qtransc 在规划时发现下载目标路径无效或无法作为本地目标使用
- **THEN** 它 SHALL 使用 `LOCAL_PATH_INVALID` 和中文说明报告错误

#### Scenario: limit-size超过任务总量

- **WHEN** 上传任务总量超过用户明确配置的 `--limit-size`
- **THEN** qtransc SHALL 在远端写入前使用 `TASK_SIZE_LIMIT_EXCEEDED` 报告错误

#### Scenario: 本地发现单文件超限

- **WHEN** qtransc 在传输规划中发现文件大小超过有效单文件上限
- **THEN** 它 SHALL 使用 `FILE_TOO_LARGE` 和中文说明报告错误

#### Scenario: 本地发现任务文件数超限

- **WHEN** qtransc 在传输规划中发现去重普通文件数超过 100000
- **THEN** 它 SHALL 使用 `TASK_FILE_LIMIT_EXCEEDED` 和中文说明报告错误

#### Scenario: 非法服务器端口

- **WHEN** 用户以 `--server aaa.cn:port` 执行直接 CLI 命令
- **THEN** stderr SHALL 输出 `Error [CLI_INVALID_ARGUMENT]: --server 参数不合法`

#### Scenario: 非法服务器地址格式

- **WHEN** 用户的 `--server` 值包含协议、路径或其他不符合 `host[:port]` 的内容
- **THEN** stderr SHALL 输出 `Error [CLI_INVALID_ARGUMENT]: --server 参数不合法`

#### Scenario: 用户名密码认证被拒绝

- **WHEN** qtransc 的用户名密码登录被认证服务拒绝
- **THEN** stderr SHALL 输出 `Error [AUTH_LOGIN_REJECTED]:` 开头的中文说明
- **AND** SHALL NOT 指出用户名或密码中哪一项错误

#### Scenario: 调试模式的敏感信息保护

- **WHEN** 用户以 `--debug` 执行命令且认证请求失败
- **THEN** qtransc SHALL 提供额外诊断
- **AND** SHALL NOT 输出任何认证凭据或令牌值

### Requirement: CLI 退出码按错误来源稳定分类

qtransc 直接命令 SHALL 对成功使用退出码 0，对远端、认证、网络和传输失败使用退出码 1，对 CLI 参数、本地配置、规划、本地路径和 state DB 错误使用退出码 2，对 SIGINT 使用退出码 130。未知命令、未知 flag、无效 transport 及无效 connections、streams 或 transfers SHALL 作为 `CLI_INVALID_ARGUMENT` 并退出 2。

#### Scenario: 未知命令

- **WHEN** 用户调用已移除或从未注册的命令
- **THEN** qtransc SHALL 输出 `CLI_INVALID_ARGUMENT`
- **AND** 进程 SHALL 退出 2

#### Scenario: 无效传输并发参数

- **WHEN** connections、streams 或 transfers 不满足所选 transport 的约束
- **THEN** qtransc SHALL 输出 `CLI_INVALID_ARGUMENT`
- **AND** 进程 SHALL 退出 2

#### Scenario: 远端 NOT_FOUND

- **WHEN** 已通过本地规划的命令收到 qtserver `NOT_FOUND`
- **THEN** qtransc SHALL 保留 `NOT_FOUND`
- **AND** 进程 SHALL 退出 1

#### Scenario: 用户中断活动任务

- **WHEN** 活动传输收到 SIGINT
- **THEN** qtransc SHALL 停止当前执行并保留适用的恢复状态
- **AND** 进程 SHALL 退出 130

### Requirement: CLI JSON 错误携带稳定 reason_code

当 CLI 自身生成 JSON error object 时，它 SHALL 包含既有 `code`、人类可读 `message` 和稳定 `reason_code`。服务端已经提供结构化 JSON error body 时，CLI SHALL 保留该 body；服务端 `reason_code` SHALL 不被客户端重命名或删除。该要求 SHALL NOT 改变 upload2/download2 旧 WebSocket 帧。

#### Scenario: 客户端参数错误的 JSON 输出

- **WHEN** 带 `--json` 的直接命令因本地参数无效而失败
- **THEN** stdout SHALL 输出含 `reason_code=CLI_INVALID_ARGUMENT` 的单一有效 JSON error object

#### Scenario: 服务端结构化错误的 JSON 输出

- **WHEN** 带 `--json` 的文件管理命令收到 qtserver 结构化 JSON error body
- **THEN** stdout SHALL 保留该 body及其原始 `reason_code`

### Requirement: serve 控制面使用数字五位码

serve SHALL 按唯一注册表将 HTTP 请求失败和任务、文件执行失败分开表达。HTTP 查询失败任务 SHALL 外层成功并在数据 error 中返回当前执行错误；SSE SHALL 保持顶层执行结果。CLI 字符串原因码 SHALL 保留，serve SHALL NOT 输出字符串原因码。

#### Scenario: serve HTTP 参数错误

- **WHEN** 请求格式或字段无效
- **THEN** SHALL 使用请求类条目，包含固定 message/meta

#### Scenario: serve 任务 failed 事件

- **WHEN** 已接受任务最终失败
- **THEN** SSE SHALL 使用执行类错误，data.status SHALL failed

#### Scenario: 文件失败并使任务失败

- **WHEN** 源文件变化或校验最终失败
- **THEN** 文件及任务 SHALL 使用相应执行错误，任务 SHALL failed

#### Scenario: serve 任务失败快照

- **WHEN** 成功查询失败任务
- **THEN** 外层 SHALL code=0，data.error SHALL 返回当前执行错误，与对应 SSE 一致

### Requirement: serve 改造不改变 CLI 错误契约

直接 CLI 的 stderr 和 JSON error object SHALL 继续遵守本 capability 已有字符串 `REASON_CODE` 与 `reason_code` 契约；Qtserver 结构化 JSON body 中的 `reason_code` SHALL 继续原样保留。serve 的数字码切换 SHALL NOT 改变 upload2/download2 旧 WebSocket 错误帧。

#### Scenario: CLI JSON 参数错误

- **WHEN** 带 `--json` 的直接命令因本地参数无效而失败
- **THEN** stdout SHALL 继续包含 `reason_code=CLI_INVALID_ARGUMENT`

#### Scenario: 旧 WebSocket 错误帧

- **WHEN** upload2 或 download2 旧 WebSocket 客户端收到错误帧
- **THEN** 帧字段和既有错误格式 SHALL 保持不变
