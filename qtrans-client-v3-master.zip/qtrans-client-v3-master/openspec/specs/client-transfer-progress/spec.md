# client-transfer-progress Specification

## Purpose
定义 qtransc 在上传、普通下载和 small download 中维护任务、文件与分片实时进度和速度的统一契约，并规定 CLI、REST、SSE 与兼容 WebSocket 观察同一内存事实时的新鲜度和兼容边界。

## Requirements

### Requirement: payload 字节实时推进内存进度

qtransc SHALL 在每次从上传 payload source 或下载 payload response 成功读取正数字节时，同步推进对应活动分片、文件和任务的 live transferred bytes，而不得等待整个 chunk、文件或任务完成。内部进度更新 SHALL NOT 依赖 CLI refresh、REST 请求、SSE/WebSocket 订阅者或 progress event 发布。文件 total 已知后，live transferred SHALL 保持在 `0..total`；任务 live transferred SHALL 是各文件当前逻辑进度之和并保持在 `0..task total`。

#### Scenario: 上传分片仍在发送

- **WHEN** 一个 100 MiB 上传分片只发送了其中一部分且 PATCH 尚未返回
- **THEN** 该分片、文件和任务的内存 transferred SHALL 已反映本次已读取发送的 payload bytes
- **AND** SHALL NOT 仍停留在该 PATCH 开始前的值

#### Scenario: 普通下载分片仍在接收

- **WHEN** 普通下载只接收了当前 Range response 的一部分
- **THEN** 该分片、文件和任务的内存 transferred SHALL 随已读取 payload bytes 推进

#### Scenario: 没有进度观察者

- **WHEN** 传输期间没有 CLI 展示、REST 轮询、SSE 订阅或 WebSocket query-progress
- **THEN** qtransc SHALL 继续维护与实际 payload 流一致的内存进度

### Requirement: 上传区分 live、confirmed 与 network bytes

上传 SHALL 区分用于进度展示的 live logical bytes、Qtserver 已确认的 confirmed bytes 和包含重试的实际 network bytes。运行中的 live transferred SHALL 包含当前 PATCH 已读取的 in-flight logical bytes；相同逻辑区间重传 SHALL NOT 重复增加 live transferred，但每次实际发送 SHALL 计入 network bytes。PATCH 失败、offset mismatch、hash mismatch、session 恢复或重新初始化时，qtransc SHALL 使用已知的 Qtserver stored offset 校准 live progress；校准 MAY 使运行中进度回退。文件和任务成功状态仍 SHALL 只由既有 finalize、complete 与正式校验契约决定，不得由 live progress 达到 total 提前决定。

#### Scenario: 上传请求中途失败

- **WHEN** 上传 PATCH 已读取部分 payload 后失败且 Qtserver 只确认了其中一部分
- **THEN** network bytes SHALL 保留本次实际发送量
- **AND** live transferred SHALL 在取得服务端状态后校准到当前 confirmed offset
- **AND** 后续重传相同逻辑区间 SHALL NOT使 live transferred 超过文件 total

#### Scenario: 上传数据发送完但尚未提交

- **WHEN** 文件 live transferred 已达到 total 但 finalize 或 complete 尚未成功
- **THEN** 文件和任务状态 SHALL 继续保持运行中
- **AND** SHALL NOT仅因进度为100%而报告完成

#### Scenario: 恢复已有上传 session

- **WHEN** qtransc 从 Qtserver GET session 获得各 chunk stored offset
- **THEN** confirmed 与 live transferred SHALL 从该服务端事实恢复
- **AND** SQLite 或进程内旧推测 SHALL NOT覆盖服务端 offset

### Requirement: 任务和文件速度独立近实时更新

活动任务、文件和分片的 rate SHALL 根据各自实际 network payload bytes 的时间增量计算，而不得根据 chunk 完成后跳变的 confirmed bytes计算。rate 的内存采样周期 SHALL 固定且不大于300ms，并与外部查询和 progress event 周期独立；重试实际传输的字节 SHALL 计入当前 network rate。没有新 network payload 时，rate SHALL 随采样窗口收敛到0。

#### Scenario: 上传分片长时间发送

- **WHEN** 一个上传 PATCH 持续发送超过一个采样周期
- **THEN** 活动文件和任务的内存 rate SHALL 在该 PATCH 完成前变为非零

#### Scenario: 外部低频查询

- **WHEN** REST 或 WebSocket 每十秒才读取一次进度
- **THEN** qtransc SHALL 仍按内部采样周期维护 rate
- **AND** 查询 SHALL 返回读取时最新的内存 rate，而不是最近一次查询触发计算的rate

### Requirement: small download 暴露活动文件实时状态

small download SHALL 在读取某个 tar payload entry 前将对应文件登记为活动文件，并在 entry payload 的每次正数字节读取时推进文件和任务 live transferred及network bytes。该文件活动期间 SHALL 具有可读取的当前 rate；完整写入并校验后 SHALL 发布最终文件进度和完成状态，再从活动集合移除。Tar header、session和manifest bytes SHALL NOT计入文件或任务 payload progress。

#### Scenario: small 文件仍在写入

- **WHEN** small download 的某个文件 entry 只写入了一部分
- **THEN** REST/CLI/WebSocket 当前快照 SHALL 能看到该活动文件及非终态 transferred
- **AND** 任务进度 SHALL 同步包含该文件已写入的 payload bytes

#### Scenario: 极小文件在一个发布周期内完成

- **WHEN** small 文件从开始到完成短于 progress event 周期
- **THEN** qtransc SHALL 至少发布该文件的最终 progress 与 completed status
- **AND** 内存任务进度 SHALL 包含其完整大小

### Requirement: 所有观察接口读取同一实时内存事实

CLI 和 REST task summary/detail SHALL 在每次读取时直接使用当前内存 task/file progress 与 rate；upload2/download2 WebSocket SHALL 在每次 `query-progress` 时读取同一当前事实。上述读取频率只影响调用方看到快照的频率，SHALL NOT触发、缓存或延迟内部进度计算。数值类型和单位 SHALL 保持不变；serve REST 字段 SHALL 按 `qtransc-serve-api-contract` 一次性切换为 lowerCamelCase，serve SSE 任务状态 SHALL 与 REST 任务状态统一；正常进度 SSE SHALL 省略 `meta`，失败状态 SSE SHALL 携带 `qtransc/docs/qtransc-error-codes.md` 规范注册表中与数字码固定绑定的 `meta{retryable,visible}`。upload2/download2 WebSocket wire contract SHALL 保持不变。

#### Scenario: 高频 REST 轮询

- **WHEN** 调用方在一个未完成 chunk 内连续请求 task detail
- **THEN** 后续响应 SHALL 能观察到期间新增的 live payload bytes
- **AND** SHALL NOT必须等到 chunk 完成才变化
- **AND** 响应进度字段 SHALL 使用 `transferredBytes`、`totalSize`、`transferRate` 和 `transferringFiles`

#### Scenario: 兼容 WebSocket 查询

- **WHEN** upload2 或 download2 在传输中收到 `query-progress`
- **THEN** `transferred`、`progress_percent`、`rate` 与 `inprogressfiles` SHALL 由查询时当前内存事实生成
- **AND** JSON wire contract SHALL 保持不变

### Requirement: progress event 周期只控制发布节流

`sse.progressInterval` SHALL 统一控制 task、活动 file 和活动 chunk progress snapshot 的周期性发布，且 SHALL NOT作为内部进度或rate更新周期。任务、文件或分片完成、失败、停止以及需要保证终态快照时，qtransc MAY 绕过周期节流强制发布最终progress。没有订阅者或事件因缓冲区满被丢弃 SHALL NOT影响内存进度。

#### Scenario: 配置300ms发布周期

- **WHEN** `sse.progressInterval=300ms` 且任务、文件和分片持续传输
- **THEN** task、file和chunk progress SHALL 以该配置作为共同的发布节流周期
- **AND** SHALL NOT保留固定1秒的file或chunk发布周期

#### Scenario: 配置5秒发布周期

- **WHEN** `sse.progressInterval=5s` 且CLI每120ms读取一次内存快照
- **THEN** SSE progress SHALL 按5秒节流
- **AND** CLI读取到的内存进度 SHALL 继续随payload字节实时推进

### Requirement: 并发进度快照保持有效

多文件或多chunk并发传输时，qtransc SHALL 以并发安全方式更新和读取进度。任一可观察快照中的 transferred、total和rate SHALL 为非负值；文件 transferred SHALL NOT超过文件total，任务 transferred SHALL NOT超过任务total。短暂跨字段采样时差 MAY 存在，但不得出现整数撕裂、数据竞争造成的无效值或重复累计同一逻辑区间。

#### Scenario: 多chunk并行上传

- **WHEN** 同一文件的多个chunk并行读取payload且外部同时查询任务详情
- **THEN** 文件和任务transferred SHALL 汇总各chunk当前live logical bytes
- **AND** SHALL NOT重复累计、超过total或产生负数
