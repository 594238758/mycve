# raw-business-event-log Specification

## Purpose
定义 qtserver 与 Nginx 输出的最小原始业务事件协议，以及仓库外日志汇聚与分析组件如何按单文件活动生成包含成功、失败、传输量、耗时、速度和重试信息的最终标准业务日志。本仓库只实现原始事件 producer，不实现或部署日志汇聚与分析组件。
## Requirements
### Requirement: 最终标准业务日志具有项目内固定字段契约

日志分析程序 SHALL 为每个已经得到最终结论的文件活动保存一条当前最终标准业务日志。产品要求的基础字段 SHALL 按下表存在，外部《日志格式.xlsx》只作为本契约形成时的历史需求来源，不得成为构建、运行或审核依赖。

| 字段 | 类型 | 规范语义 |
| --- | --- | --- |
| `task_type` | string | 文件注册时生效的 qtserver `log.task_type` 配置值；`"0"`表示多中心，`"1"`表示C/S |
| `server_ip` | string | 文件第一次进入系统时实际使用的外部入口IP；两种`task_type`均原样输出可信值 |
| `task_id` | string | 客户端关联 ID |
| `taskpid` | string | 外部日志关联值，允许为空，不参与业务判断 |
| `enterprise_id` | string | 外部企业日志关联值，允许为空，不参与业务判断 |
| `client_id` | string | 客户端持久设备标识；两种`task_type`均原样输出可信值 |
| `client_ip` | string | qtserver 从可信网络边界观察到的客户端 IP |
| `client_os` | string | 客户端系统类型；两种`task_type`均原样输出可信值 |
| `client_version` | string | 执行传输的 qtransc 版本 |
| `caller_version` | string | 创建任务的 GUI 或 agent 自报版本，允许为空 |
| `client_username` | string | 服务端可信身份结果中的用户邮箱；未提供时为空字符串，内置匿名用户固定为 `anonymous` |
| `action` | string | `upload` 或 `download` |
| `transmitted` | integer | 有合法完成事件证明的文件内容传输字节总和，单位 bytes |
| `file_path` | string | qtserver 校验并规范化后的逻辑路径 |
| `file_size` | integer | 文件大小，单位 bytes |
| `start_time` | string | 文件活动开始时间，UTC RFC3339且固定三位毫秒 |
| `end_time` | string | 权威成功事实发生时间或 timeout deadline，UTC RFC3339且固定三位毫秒 |
| `duration` | number | `end_time-start_time` 的 wall-clock 秒数，按整数毫秒计算并保留三位小数 |
| `log_time` | string | 当前结果首次写入或最近一次内容实际修订的分析时间，UTC RFC3339且固定三位毫秒 |

最终记录还 SHALL 包含下列分析扩展字段：

| 字段 | 类型 | 规范语义 |
| --- | --- | --- |
| `file_key` | string | 文件活动确定性关联键和当前结果修订键 |
| `principal_id` | string | 服务端得到的稳定身份 ID；内置 `anonymous` 用户固定为 `anonymous` |
| `result` | string | `SUCCESS` 或 `FAILED` |
| `result_reason` | string | 本 spec 定义的稳定原因码 |
| `retry_count` | integer | 相同 chunk index 的额外data attempt数之和；不是错误响应数量 |
| `speed` | number 或 null | 当前活动`transmitted>0`、成功且duration与file size均大于0时的端到端有效速度，单位bytes/s并四舍五入到三位小数；零传输、失败、`ALREADY_PRESENT`、零字节或无法计算时为null |

所有string时间字段 SHALL 使用UTC RFC3339并固定三位毫秒。分析程序 SHALL 先用时间戳差得到非负integer `duration_ms`，输出`duration=duration_ms/1000`且固定三位小数；满足speed条件时 SHALL 使用decimal或等价无溢出算法计算`file_size*1000/duration_ms`并四舍五入到三位小数，不得从格式化后的浮点duration反算。`duration_ms=0`时duration SHALL 是`0.000`且speed SHALL 是null。`transmitted` 与 `file_size` SHALL 是 `0..9223372036854775807` 的 integer。`transmitted` MAY 大于 `file_size`，因为失败、中断、hash mismatch 和重传产生的完成事件仍计入实际网络成本。最终结果原因只允许：

```text
SUCCESS / UPLOADED_AND_COMMITTED
SUCCESS / ALREADY_PRESENT
SUCCESS / DOWNLOADED_AND_VERIFIED
SUCCESS / SMALL_FILE_SENT
FAILED  / TIMEOUT
```

`log.task_type` SHALL 只允许字符串 `"0"` 或 `"1"`并默认使用`"1"`。原始事件与最终记录 SHALL 始终保留完整且可信的`server_ip`、`client_id`和`client_os`；无论`task_type`为`"0"`还是`"1"`，分析程序 SHALL 原样输出这些字段以及 `client_version` 与 `caller_version`。Task type SHALL 只表示场景分类，SHALL NOT 改变其他字段、传输协议、授权、文件空间、事件类型或状态机。

系统 SHALL NOT 把 anonymous 定义为一种下载类型。`anonymous` SHALL 是一个没有密码、任何调用方都可选择的内置用户；Qtserver SHALL 直接构造该用户的可信 principal而不查询外部身份服务，并 SHALL 固定 `principal_id=anonymous` 与 `client_username=anonymous`。普通用户与 anonymous用户 SHALL 使用相同的原始事件协议和分析状态机；本契约 SHALL NOT 改变既有文件空间或 API 权限。

普通用户的 `client_username` SHALL 使用服务端可信身份结果中的邮箱，并去除首尾空白；邮箱缺失、null、非 string 或去除首尾空白后为空时 SHALL 显式输出空字符串，SHALL NOT 回退到 `principal_id`，也 SHALL NOT 仅因邮箱不可用拒绝认证或传输。Producer SHALL NOT 使用客户端自报 username、邮箱、登录名或 token 填充该字段，SHALL NOT 从用户 ID 推测邮箱，也 SHALL NOT 为日志单独增加身份服务请求。邮箱 SHALL 只用于日志展示，SHALL NOT 参与认证、授权、文件空间、session ownership、grant HMAC 或 `file_key` 计算。

`auth` mode SHALL 从同一次成功 `/userinfo` response 按顶层 `email`、`data.email` 的顺序选取第一个去除首尾空白后非空的 string；不合类型的候选 SHALL 跳过。身份缓存 SHALL 同时保存用户 ID 和邮箱，并保持原有 TTL 与同 token 并发回源合并行为。升级时 SHALL 隔离只含用户 ID 的旧缓存，新实例 SHALL 重新获取完整身份结果；新旧实例 SHALL NOT 将对方缓存格式误解为用户 ID。`oauth2-introspection` SHALL 使用同一次 active response 的可选顶层 `email`，且继续不缓存身份结果。`fake` 仅有 token 到 ID 的映射，普通用户邮箱 SHALL 为空；`anonymous` SHALL 继续使用固定值 `anonymous`。

此次修订 SHALL 保持 schema v1 及字段名称不变。Consumer SHALL 接受 string 类型的空 `client_username`，但 SHALL NOT 接受字段缺失、null 或非 string。历史事件中已经记录的用户 ID SHALL 原样保留，SHALL NOT 从当前身份服务补写或改写历史邮箱；最终日志 SHALL 继续取最早合法注册或对应 Small 成功事件中的原值。部署新 producer 前 SHALL 先更新仍要求该字段非空的 consumer；邮箱变化或跨版本重试 SHALL 继续遵循注册上下文冲突规则，不得改变文件关联或覆盖最早上下文。

#### Scenario: 使用 anonymous 用户

- **WHEN** 一个合法文件请求选择内置 `anonymous` 用户
- **THEN** Qtserver SHALL NOT 为该用户查询外部身份服务
- **AND** 原始事件与最终记录的 `principal_id` 和 `client_username` SHALL 都是 `anonymous`
- **AND** 分析程序 SHALL NOT 把它归入另一种下载类型或状态机

#### Scenario: 普通用户生成邮箱字段

- **WHEN** Qtserver 为合法文件请求得到可信普通用户 `principal_id=user-42` 和邮箱 `alice@example.com`
- **THEN** 原始事件与最终记录的 `client_username` SHALL 是 `alice@example.com`，`principal_id` SHALL 仍是 `user-42`
- **AND** Qtserver SHALL NOT 使用 qtransc 提交的登录名或其他客户端字段覆盖它

#### Scenario: 普通用户没有邮箱

- **WHEN** 可信身份结果没有可用邮箱，或请求使用 `fake` mode
- **THEN** 原始事件与最终记录 SHALL 显式包含 `"client_username":""`
- **AND** 合法文件请求 SHALL 继续执行，字段 SHALL NOT 回退到用户 ID

#### Scenario: auth 身份缓存保留邮箱

- **WHEN** 同一 token 的成功身份结果已被缓存
- **THEN** 缓存命中 SHALL 返回同一用户 ID 和邮箱，供普通上传、普通下载和 Small 下载记录上下文
- **AND** SHALL NOT 为邮箱再次调用身份服务

#### Scenario: 升级时存在旧身份缓存

- **WHEN** Redis 中仍有旧版本写入的仅含用户 ID 的身份缓存
- **THEN** 新版本 SHALL 忽略该旧缓存并通过原有身份请求取得用户 ID 和邮箱
- **AND** 新缓存 SHALL NOT 被旧版本读取为用户 ID

#### Scenario: 项目外需求附件不可用

- **WHEN** producer、分析程序或审核者无法访问原始 Excel 附件
- **THEN** SHALL 能仅依据本 requirement 确定最终记录的字段、类型和语义

#### Scenario: 多中心最终字段映射

- **WHEN** 合法原始事件的`task_type`是`"0"`
- **THEN** 原始事件 SHALL 仍包含完整且可信的`server_ip`、`client_id`和`client_os`
- **AND** 最终记录 SHALL 原样使用这些字段以及 client 与 caller version

#### Scenario: C/S最终字段映射

- **WHEN** 合法原始事件的`task_type`是`"1"`
- **THEN** 最终记录 SHALL 原样使用原始上下文中的`server_ip`、`client_id`、`client_os`、`client_version`与`caller_version`

#### Scenario: 调用方版本为空

- **WHEN** 文件活动没有提供调用方版本
- **THEN** 最终记录 SHALL 显式包含 `"caller_version":""`
- **AND** SHALL NOT 省略该字段或写 `null`

#### Scenario: 校验失败后重传成功

- **WHEN** 同一上传 chunk 传输两次并最终提交成功
- **THEN** 最终记录 SHALL 是 `SUCCESS/UPLOADED_AND_COMMITTED`
- **AND** `transmitted` SHALL 累加两次完成事件的实际字节
- **AND** `retry_count` SHALL 至少增加 1

#### Scenario: 最终内容未改变

- **WHEN** 分析程序再次得到与数据库当前行完全相同的候选结果
- **THEN** SHALL NOT 仅为重复分析改变 `log_time`

### Requirement: 文件活动由四元组和确定性 file key关联

一项文件活动的权威身份 SHALL 是 `(task_id, normalized_file_path, principal_id, action)`。Qtserver SHALL 使用以下算法生成 `file_key`：

```text
base64url-no-padding(
  SHA-256(
    UTF-8("qtrans-file-v1") + NUL +
    UTF-8(task_id) + NUL +
    UTF-8(normalized_file_path) + NUL +
    UTF-8(principal_id) + NUL +
    UTF-8(action)
  )
)
```

路径 SHALL 使用 qtserver 已经完成业务校验后的规范逻辑路径，分析程序 SHALL NOT 再次改变大小写或重新规范化。`action` SHALL 固定为小写 `upload|download`。所有相关原始事件 SHALL 携带相同 `task_id` 与 `file_key`；`file_key` 只用于日志关联，不得参与授权或资源 ownership。

Canonical upload建立session后 SHALL 固定使用session创建时保存的task ID生成全部后续原始事件。后续请求的`X-Task-ID`不同 SHALL NOT 改变session授权或日志四元组，也不得把一次上传拆分到多个`file_key`。

#### Scenario: 注册四元组和 file key不一致

- **WHEN** `file.registered` 中的四元组按本算法计算后与 envelope 的 `file_key` 不一致
- **THEN** 分析程序 SHALL 将该注册事实视为非法
- **AND** SHALL NOT 在两者之间猜测权威值

#### Scenario: 同一路径不同 action

- **WHEN** 相同 task ID、路径和 principal 分别上传与下载
- **THEN** 两项文件活动 SHALL 使用不同 `file_key`

### Requirement: 原始业务事件和调试日志相互隔离

Qtserver SHALL 将 schema v1 原始业务事件以 UTF-8 JSON Lines 写入独立 `business-events.jsonl`；Nginx SHALL 将普通下载完成事件以 JSON Lines 写入独立 `download_events.log`。`qtserver.log`、`gin.log`、Nginx `access.log`/`error.log`、stdout/stderr 和 qtransc 本地日志 SHALL 属于调试或运行日志，SHALL NOT 作为业务分析输入。

只有完成业务准入、获得可信 principal 与规范路径并实际进入文件传输流程的请求才能产生原始业务事件。未认证、非法参数、非法路径、扫描请求及业务准入前失败 SHALL 只进入访问、安全或调试日志。

#### Scenario: 调试级别改变

- **WHEN** 运维关闭 debug 日志或提高日志级别
- **THEN** 原始业务事件 SHALL 继续按相同契约输出
- **AND** 分析结果 SHALL 不受调试级别影响

#### Scenario: 非法请求

- **WHEN** 请求在形成合法文件活动前因认证、参数或路径校验失败
- **THEN** Qtserver SHALL NOT 为它输出原始业务事件

### Requirement: 日志汇聚由仓库外组件负责且合并规则可复现

本仓库 SHALL 只实现 Qtserver 与 Nginx 原始业务事件 producer 及其对外接口契约，SHALL NOT 实现或部署日志采集调度、原始事件历史存储、当前结果存储或分析程序。未部署仓库外汇聚组件时，Qtserver 与 Nginx SHALL 仍按本 spec 生成原始事件，但本仓库 SHALL NOT 自动生成最终业务日志。

仓库外汇聚组件 SHALL 采集 Qtserver 的 active 文件 `log.file_path/business-events.jsonl`、已经关闭的 `business-events-<UTC timestamp>-<sequence>.jsonl[.gz]` 归档，以及 Nginx 运行时 prefix 下的 active 文件 `./logs/download_events.log` 和其已经关闭的轮转段。汇聚组件 SHALL 使用 source、文件身份和读取位置 checkpoint，确保同一物理文件段中的同一原始行不会被重复导入；因为 schema v1 不含 event ID，汇聚组件 SHALL NOT 猜测两条内容相同的合法事件是采集重复并执行通用事件去重。

每条输入流 SHALL 独立按 JSON Lines 解析，并且只解析以换行结束的完整行。Active 文件末尾未换行内容 SHALL 保持 pending 并等待后续补全；已经关闭的文件段末尾未换行内容 SHALL 进入 quarantine。合法行 SHALL 连同原始 JSON、source 和物理文件来源保存在外部原始事件历史中，无效行 SHALL 连同拒绝原因进入 quarantine。

跨 producer 合并 SHALL 是合法原始事件的逻辑并集，不得依赖文件拼接顺序、文件名顺序、采集顺序或导入顺序。汇聚组件 SHALL 将携带数字偏移的 `occurred_at` 换算为 UTC 毫秒绝对时间，随后按 `file_key` 读取完整历史、按 `occurred_at` 升序分组，并把相同时间的事实作为同一时间组，再应用本 spec 的状态机和归约规则。存储产品、采集器、调度器和执行框架 MAY 替换，但相同合法原始事件集合 SHALL 得到相同当前最终结果。

#### Scenario: 跨 producer 合并同一文件活动

- **WHEN** Qtserver 事件流包含某个 `file_key` 的注册和整文件校验事实，且 Nginx 事件流包含同一 `file_key` 的下载分片完成事实
- **THEN** 仓库外汇聚组件 SHALL 将这些事实保存到同一文件活动历史并共同归约
- **AND** SHALL NOT 按 producer 分别生成互不相关的最终结果

#### Scenario: 采集和文件到达顺序不同

- **WHEN** 同一组合法原始事件以不同的文件顺序或采集顺序到达汇聚组件
- **THEN** 汇聚组件 SHALL 按 `file_key` 和事件绝对时间归约出相同当前最终结果
- **AND** SHALL NOT 使用导入顺序解释业务先后

#### Scenario: active 文件末尾是不完整行

- **WHEN** active 文件的最后一段内容尚未以换行结束
- **THEN** 汇聚组件 SHALL 保留读取位置并等待该行补全
- **AND** SHALL NOT 解析、导入或隔离该不完整内容

#### Scenario: 关闭段末尾是不完整行

- **WHEN** 已经关闭的轮转段以未换行的不完整内容结束
- **THEN** 汇聚组件 SHALL 将该内容隔离并记录来源与拒绝原因
- **AND** SHALL 继续处理该关闭段中此前的完整行

#### Scenario: 未部署仓库外汇聚组件

- **WHEN** 仅运行本仓库提供的 Qtserver 和 Nginx producer
- **THEN** 两种 producer SHALL 继续输出各自的原始业务事件
- **AND** 本仓库 SHALL NOT 声称已经生成最终业务日志

### Requirement: schema v1 使用包含 taskpid 的最小公共 envelope

产品 Excel《日志格式.xlsx》的 `原始日志格式` sheet SHALL 只作为旧分片级原始格式的历史需求来源，SHALL NOT 作为 schema v1 的字段或事件契约。Producer、分析程序和审核者 SHALL 只使用本 spec 定义的 envelope、七种 typed payload 与归约规则，不得从外部 Excel 补字段或恢复旧事件。

每条原始事件 SHALL 是单行 JSON object，并且公共字段 SHALL 恰好是 `schema_version`、`event_type`、`occurred_at`、`task_id`、`taskpid`、`enterprise_id`、`file_key` 和 object 类型 `payload`。八项 SHALL 全部存在，`task_id` 与 `file_key` SHALL 是非空 string，`taskpid` 与 `enterprise_id` SHALL 是允许为空的 string。`schema_version` SHALL 是 integer `1`；`occurred_at` SHALL 表示业务事实完成时间，并按 producer 主机本地时区编码为 RFC3339/ISO 8601 扩展格式，恰好三位毫秒且始终携带数字时区偏移，例如`2026-08-12T18:00:00.123+08:00`。Envelope未知字段 SHALL 使整行无效。

Schema v1 SHALL NOT 要求 `event_id`、`operation_id`、`session_id`、`report_id`、fingerprint、producer instance、source sequence、started event 或客户端状态 event。每个 chunk finished 事件本身 SHALL 表示一次真实完成 attempt；相同 `file_key` 与 `chunk_index` 的多条合法完成事件 SHALL 表示重试，但只有位于本spec结果统计窗口内的attempt SHALL 参与`transmitted`与`retry_count`。

本契约要求采集链路通过物理文件 checkpoint 避免重复导入同一原始行。Qtserver、Nginx和仓库外分析程序 SHALL NOT 为通用事件去重增加事件身份或猜测内容相同的合法事件是重复数据。未知 schema version、无效 JSON、必填字段缺失或 typed payload 已知字段类型错误 SHALL 被隔离，且不得与 schema v1 一起归约。当前 schema v1 producer SHALL 只输出本spec为对应event type定义的已知payload字段；同一schema以后新增的未知payload字段 SHALL 随原始JSON保存在外部原始事件历史存储中，但旧分析器 SHALL 忽略该字段且不得因此隔离整行。本项目当前只开发扩展后的八字段 schema v1，不建立旧七字段 v1、其他 schema version 的读取、迁移或协商契约。

Qtserver、Nginx和分析基础设施的部署 SHALL 使用NTP或等价机制同步系统时钟。Qtserver SHALL 把事件时间与small `started_at`截断到毫秒，并按主机本地时区输出；Nginx SHALL 使用主机本地 `$time_iso8601` 与 `$msec` 构造同样格式。两种 producer SHALL NOT 要求服务启动环境额外配置时区。分析时间与`log_time` SHALL 归一到UTC毫秒，最终JSON时间 SHALL 继续使用UTC RFC3339并固定三位毫秒。Decoder SHALL 拒绝缺少数字时区偏移、非恰好三位小数或不可解析的wire事件时间，并 SHALL 在排序、比较或持久化前按偏移换算为同一绝对时间，防止持久化时静默改变排序。第一版分析程序 SHALL NOT 估算或修正producer时钟偏差。每次归约 SHALL 只应用`occurred_at`不晚于本次analysis time的事件；合法未来事件 SHALL 保留在外部原始事件历史存储和inspect中，但在分析时钟追上前 SHALL NOT 建立状态、刷新deadline、参与统计或形成结果。持续未来时间或跨producer明显倒序 SHALL 作为部署监控问题处理。

#### Scenario: 相同 chunk index出现两条完成事实

- **WHEN** 一个文件的同一 chunk index有两条合法 `chunk_finished`
- **THEN** 分析程序 SHALL 将它们视为两个真实 attempt
- **AND** SHALL NOT 以“可能重复采集”为由删除其中一条

#### Scenario: 事件时间晚于分析时钟

- **WHEN** 外部原始事件历史存储中存在结构和语义合法但`occurred_at`晚于本次analysis time的事件
- **THEN** 分析程序 SHALL 保留并在inspect中展示该事件
- **AND** 本轮 SHALL NOT 使用它建立状态、刷新deadline、参与统计或形成最终结果

#### Scenario: v1事件携带非空辅助标签

- **WHEN** producer 为带非空日志关联值的请求输出原始业务事件
- **THEN** envelope SHALL 同时包含非空 `task_id` 以及对应 string 值的 `taskpid` 与 `enterprise_id`
- **AND** `schema_version` SHALL 是 integer `1`

#### Scenario: v1事件的辅助标签为空

- **WHEN** 文件活动没有外部 `taskpid` 或 `enterprise_id`
- **THEN** 每条 v1 事件仍 SHALL 为缺失的标签显式写入空字符串
- **AND** producer SHALL NOT 省略任一字段或写 `null`

#### Scenario: 旧七字段v1事件

- **WHEN** schema v1 行缺少 `enterprise_id` 但其余七个旧字段合法
- **THEN** decoder SHALL 将该行作为缺少必填 envelope 字段的无效事件隔离
- **AND** SHALL NOT 为开发阶段旧日志补写默认值

#### Scenario: v1出现额外envelope字段

- **WHEN** schema v1 行在八个规定字段之外包含其他顶层字段
- **THEN** decoder SHALL 将该行作为无效envelope隔离

### Requirement: schema v1只定义七类原始业务事件

合法 `event_type` SHALL 限于：

```text
file.registered
upload.chunk_finished
upload.verify_finished
upload.finished
download.chunk_finished
download.verify_finished
download.small_file_sent
```

Producer SHALL NOT 为本契约输出 `task.registered`、task state、file result、operation started、pause、resume或客户端 completed/failed/abandoned 事件。客户端 SHALL 只调用传输业务 API，不需要调用独立日志状态上报 API。

七类事件的归约职责 SHALL 固定如下：`file.registered`只建立普通文件PROCESSING并初始化deadline；上传和下载`chunk_finished` SHALL 在当前有效活动窗口内刷新deadline，并按actual bytes与chunk index参与transmitted和retry count；`upload.verify_finished`以及非成功的`download.verify_finished` SHALL 在当前有效活动窗口内刷新deadline但不得参与字节或retry统计；`upload.finished` SHALL 只形成上传成功；整文件matched的`download.verify_finished` SHALL 只形成普通下载成功；`download.small_file_sent` SHALL 绕过普通状态机直接形成small成功。

权威成功事实 SHALL NOT 因其`occurred_at`晚于首次inactivity deadline或外部当前结果存储已经存在TIMEOUT而失效。合法`upload.finished`或整文件matched到达时，分析程序 SHALL 按完整历史和成功时间闭区间重新归约并按本spec修订当前结果。Deadline之后只有chunk或非成功verify事实时，SHALL 保持首次TIMEOUT且不得继续刷新deadline。

#### Scenario: 客户端暂停传输

- **WHEN** qtransc 在本地暂停一个文件并且没有调用新的传输 API
- **THEN** Qtserver SHALL NOT 输出 pause 业务事件
- **AND** 分析程序 SHALL NOT 冻结该文件的 inactivity timeout

#### Scenario: 权威成功事实晚于首次deadline

- **WHEN** 普通文件已经跨过首次inactivity deadline，随后外部原始事件历史存储出现合法`upload.finished`或整文件matched事实
- **THEN** 分析程序 SHALL NOT 以该成功事实晚于deadline为由丢弃它
- **AND** SHALL 按完整历史形成或修订SUCCESS结果

#### Scenario: taskpid变化不产生新事件类型

- **WHEN** 同一文件活动后续请求的`taskpid`与注册时不同
- **THEN** producer SHALL 仍只输出对应传输事实的既有event type
- **AND** SHALL NOT 输出taskpid changed或task级事件

### Requirement: taskpid 归一化后进入原始事件和最终日志

qtransc SHALL 在任务创建输入阶段去除`taskpid`首尾 ASCII SP和HTAB，并在trim后的值上执行UTF-8、HTTP header field value与128 bytes校验。除该trim外，系统 SHALL NOT 截断、生成、解析或改写该值；trim后为空时 SHALL 使用空字符串。每条schema v1原始业务事件 SHALL 在`task_id`旁记录归一化后的`taskpid`，无值时显式记录空字符串。

Canonical upload SHALL 使用session创建时保存的初始task ID和初始`taskpid`输出该session的全部原始事件。普通下载和small事件 SHALL 使用对应请求的可信Qtserver日志上下文；X-Accel普通下载chunk事件 SHALL 使用Qtserver交给Nginx的内部`taskpid` handoff，而不得直接信任客户端同名内部header。

最终日志 SHALL 保存选定事件envelope中的`taskpid`：普通文件使用最早合法`file.registered`的值，small文件使用形成当前`SMALL_FILE_SENT`结果的`download.small_file_sent`值。后续事件中的不同值 SHALL 只保留为原始日志证据，不得覆盖最终值或改变状态、指标和结果。候选事件`occurred_at`并列、其他内容完全相同且只有`taskpid`不同时，分析程序 SHALL 按UTF-8 bytes升序选择最小值，不得依赖导入顺序。

`taskpid` SHALL NOT 参与`file_key`算法、注册合法性、上下文冲突、事件有效性、attempt、inactivity deadline、transmitted、retry count、speed、result、result reason或其他业务判断。

#### Scenario: 原始事件记录taskpid

- **WHEN** Qtserver 为带非空`taskpid`的文件活动输出原始事件
- **THEN** 同一 envelope SHALL 同时包含原`task_id`和相同归一化string值的`taskpid`
- **AND** typed payload SHALL 与空`taskpid`时保持相同

#### Scenario: 后续事件携带不同taskpid

- **WHEN** 最早合法注册之后的chunk、verify或finished事件携带不同`taskpid`
- **THEN** producer SHALL 在各事件中记录对应的日志上下文值
- **AND** 该差异 SHALL NOT 改变事件类型、payload或业务结果

#### Scenario: taskpid不同但文件活动相同

- **WHEN** 两个请求只在`taskpid`上不同而task ID、路径、principal和action相同
- **THEN** `file_key` SHALL 保持相同
- **AND** `taskpid` SHALL NOT 创建新的文件活动

### Requirement: 普通文件注册事件固定完整上下文

Qtserver SHALL 在接受普通上传的第一个有效 init，或者普通下载携带完整client metadata的指定 `/d/down` 或整文件 `/d/verify` 请求时，为文件可靠写入 `file.registered` 后再执行该请求的传输或校验。Download grant同时服务small与普通路径，SHALL NOT 输出 `file.registered` 或其他原始业务事件。Payload SHALL 包含：

```text
task_type
action
file_path
file_size
principal_id
client_username
client_id
client_ip
client_os
client_version
caller_version
server_ip
server_instance
server_version
file_inactivity_timeout_seconds
```

`task_type` SHALL 使用当时 qtserver `log.task_type`配置值`"0"|"1"`，保存在原始事件中且只表示场景分类，不得影响其他字段、读取客户端Task-Type或改变传输逻辑。Client metadata SHALL 来自该文件的第一个请求；principal、client username、client IP、server IP、文件路径和下载文件大小 SHALL 使用服务端可信事实。Producer SHALL NOT 使用客户端自报 username 填充 `client_username`。上传file size SHALL 使用qtserver已校验接受的init声明值；下载file size SHALL 使用服务端已打开普通文件的stat事实。`server_instance` SHALL 使用派生完成后的`server.instance_id`（缺省为启动时hostname），`server_version` SHALL 使用当前qtserver构建版本；两者不得来自请求。`file_inactivity_timeout_seconds` SHALL 大于 0 并固定该文件历史的超时口径。

Qtserver SHALL 在当前文件首请求中构造上述上下文，SHALL NOT 从旧`/taskid`日志上下文回读字段。客户端在日志上下文中只提供`Client-ID`、`Client-OS`、`Client-Version`与允许为空的`Caller-Version`；其提交的Task-Type、username、server IP、server instance或server version SHALL NOT 覆盖服务端来源。

注册payload的`task_type` SHALL 是`"0"|"1"`；`file_path`、`principal_id`、`client_id`、`client_os`、`client_version`、`server_instance`与`server_version` SHALL 是非空string；`client_username`与`caller_version` SHALL 是允许为空但必须存在的string；`file_size` SHALL 是`0..MaxInt64` integer；`client_ip`与`server_ip` SHALL 是可解析且非unspecified的IP string。Nginx MAY 通过内部header提供本次入口`$server_addr`，但Qtserver SHALL 只在直接连接方属于`server.trusted_proxies`时信任它；否则 SHALL 使用本地监听地址或配置`server.external_ip`。任意客户端直接提交同名header SHALL NOT 改变`server_ip`。`client_ip` SHALL 同样按可信代理配置解析，而不得使用客户端自报值。

同一文件因上传init或普通下载注册请求的HTTP重试出现多条注册事实时，分析程序 SHALL 使用`occurred_at`最早且合法的一条，后续注册 SHALL NOT 刷新deadline或覆盖最终字段。后续完全一致的注册 SHALL 被忽略；`task_type`、`client_ip`、`server_ip`、`server_instance`、`server_version`或`file_inactivity_timeout_seconds`变化 SHALL 作为重试上下文漂移展示但不作为文件语义冲突；`file_size`、`client_id`、`client_os`、`client_version`、`caller_version`或`client_username`变化 SHALL 报告语义冲突，但不得阻止最早上下文继续归约。Action、file path或principal与file key不一致的注册 SHALL 按非法注册处理。

若最早`occurred_at`上并列注册会产生不同最终上下文字段，分析程序 SHALL 报告无法确定首次注册，且 SHALL NOT 为该`file_key`输出候选结果；最早并列但全部上下文字段一致 SHALL 视为同一事实。分析程序 SHALL NOT 使用外部存储导入顺序或虚构event ID选择并列上下文。

#### Scenario: 晚到的入口漂移

- **WHEN** 最早合法注册之后的重试注册使用不同client IP、server IP或server instance但文件语义字段一致
- **THEN** 分析程序 SHALL 保留最早上下文继续归约
- **AND** inspect SHALL 展示入口漂移但不得把它标记为file size或client metadata语义冲突

#### Scenario: 晚到的语义冲突注册

- **WHEN** 最早合法注册之后出现不同file size或client metadata的注册事件
- **THEN** 分析程序 SHALL 保留最早上下文继续归约
- **AND** 后续冲突注册 SHALL NOT 刷新deadline或改变最终字段
- **AND** inspect SHALL 报告该冲突

#### Scenario: 最早注册时间并列冲突

- **WHEN** 同一file key在最早`occurred_at`上存在两个会产生不同最终字段的注册上下文
- **THEN** 分析程序 SHALL NOT 按导入顺序选择其中一个
- **AND** SHALL NOT 输出该file key的候选结果
- **AND** inspect SHALL 报告无法确定首次注册

上传源文件在活动中发生变化 SHALL 停止当前文件活动且不得用新的size/hash覆盖原注册上下文。客户端上传变化后的内容 SHALL 使用新的task ID形成新的`file_key`；旧活动没有成功事实时 SHALL 独立TIMEOUT。

普通下载 producer SHALL 以Client-ID、Client-OS和Client-Version三项全部存在作为注册请求标志，全部不存在时不得重复输出注册，部分存在时 SHALL 拒绝请求。`Caller-Version` SHALL NOT 改变该三项判定；缺失时使用空字符串。Qtransc SHALL 在注册分片获得合法响应头前阻止同文件其他分片开始，因此遵守本协议的qtransc在任何普通chunk完成事实之前 SHALL 已经有至少一次注册写入。Qtserver SHALL NOT 为避免响应丢失产生的重复注册而增加持久download registration状态；分析程序 SHALL 合并内容一致的重复注册。

没有持久注册状态时Qtserver无法区分合法后续请求和三项metadata全缺失的非规范首请求，因此本spec SHALL NOT 要求它拒绝后一种情况。违反协议的客户端 MAY 产生无注册的孤立chunk/verify事件；分析程序 SHALL 保留它们，但在合法注册到达前 SHALL NOT 建立状态、deadline或最终结果。

#### Scenario: 无注册的普通下载事件

- **WHEN** 外部原始事件历史存储收到普通下载chunk或verify事件但没有该file key的合法`file.registered`
- **THEN** 分析程序 SHALL 保留该事件并在inspect中说明缺少注册上下文
- **AND** SHALL NOT 为该file key生成PROCESSING、TIMEOUT或最终结果

#### Scenario: 注册日志不可写

- **WHEN** Qtserver 无法可靠写入普通文件的 `file.registered`
- **THEN** SHALL 拒绝该文件活动并返回稳定的日志不可用错误
- **AND** SHALL NOT 开始数据传输

#### Scenario: 后续配置改变

- **WHEN** 文件注册后运维改变 task type 或 inactivity timeout 配置
- **THEN** 分析程序 SHALL 继续使用该 `file.registered` 中固定的历史值

#### Scenario: 上传源文件发生变化

- **WHEN** qtransc检测到已注册上传文件的size、mtime或文件身份变化
- **THEN** SHALL 停止当前活动且不得在同一file key下注册新文件内容
- **AND** 重新上传变化后的内容 SHALL 使用新task ID

#### Scenario: download grant不建立文件状态

- **WHEN** Qtserver成功签发一个随后可能走small路径的download grant
- **THEN** SHALL NOT 输出该文件的 `file.registered`
- **AND** 普通文件 SHALL 等到指定的合法 `/d/down` 或整文件verify请求才进入状态机

#### Scenario: 完整本地恢复只执行verify

- **WHEN** 普通下载没有任何Range请求且第一次整文件verify携带完整metadata
- **THEN** Qtserver SHALL 先可靠输出`file.registered`再执行verify

#### Scenario: 并行普通下载建立注册顺序

- **WHEN** 一个文件存在多个待下载分片
- **THEN** qtransc SHALL 先使最小待下载chunk的注册请求收到合法响应头
- **AND** 才能启动其他chunk请求

### Requirement: 上传完成事件覆盖分片、校验和最终成功

Qtserver SHALL 在每次已通过业务准入并开始处理数据的canonical上传分片请求结束后输出 `upload.chunk_finished`。Payload SHALL 包含非负 `chunk_index`、本次请求在整个文件中的绝对半开区间 `range_start` 与 `range_end`、非负 `actual_bytes` 和 `result=succeeded|interrupted|failed`。范围 SHALL 满足`0 <= range_start < range_end <= file_size`，其中`range_start=chunk_index*chunk_size+Upload-Offset`、`range_end=range_start+Content-Length`。正常完成和request body中断时，`actual_bytes` SHALL 是qtserver本次实际从HTTP request body读取的文件内容字节且不得大于Range宽度；服务端文件写入或进度持久化失败时，`actual_bytes` MAY 只包含失败前已经确认接受或写入的字节。

完整读取声明的request body并成功接受该段进度时result SHALL 是`succeeded`且actual bytes SHALL 等于Range宽度；request body在声明长度前结束时 SHALL 是`interrupted`；进入数据处理后发生文件写入、进度持久化或其他服务端失败时 SHALL 是`failed`。Interrupted的actual bytes SHALL 保留中断前已实际读取的文件字节。Failed的actual bytes MAY 是0或整个Range宽度；遇到文件写入或进度持久化失败时，它 MAY 低于已经从网络读取的字节，这是允许的异常统计缺口。认证、session、offset、Content-Length或Range等业务准入前校验失败 SHALL NOT 产生该事件。三种result都 SHALL 表示一次data attempt并在合法统计窗口内按actual bytes计入transmitted；result SHALL NOT 作为文件终态。

#### Scenario: 分片断点续传

- **WHEN** chunk index为2、chunk size为100、Upload-Offset为40且Content-Length为60
- **THEN** `upload.chunk_finished`的Range SHALL 是`[240,300)`
- **AND** 该请求 SHALL 继续使用chunk index 2

#### Scenario: 上传请求体中断

- **WHEN** 已准入请求声明本次Range宽度为100，但qtserver只读取40字节后request body提前结束
- **THEN** SHALL 输出`upload.chunk_finished{result=interrupted,actual_bytes=40}`
- **AND** 该事件 SHALL 作为一次attempt并按40字节参与合法结果窗口统计

#### Scenario: 上传处理失败但已读取数据

- **WHEN** qtserver已从合法request body读取60字节后发生服务端文件写入或进度持久化失败
- **THEN** SHALL 输出`upload.chunk_finished{result=failed}`
- **AND** `actual_bytes` MAY 只记录失败前已确认接受或写入的字节，允许小于60
- **AND** 分析程序 SHALL 按事件报告值统计，不得猜测未被可靠记录的网络读取量

每次通过认证、参数、session和chunk完整性等前置校验并实际开始读取或计算hash的上传分片校验结束后 SHALL 输出 `upload.verify_finished`，其已知payload字段 SHALL 只有非负integer `chunk_index` 与 `verification_result=matched|mismatched|failed`。完成hash比较且一致时 SHALL 使用`matched`，完成比较但内容不一致时 SHALL 使用`mismatched`，已经进入校验执行但因读取、计算或依赖错误无法得出比较结论时 SHALL 使用`failed`。前置校验失败以及hash尚未开始计算或结果尚不可用 SHALL NOT 输出verify完成事件。当前producer SHALL NOT 输出`verification_scope`或其他payload字段；consumer仍 SHALL 按公共规则保留并忽略未来未知payload字段。Mismatch 或 failed SHALL 只描述本次校验，不得直接结束整个文件。

Canonical upload的独立finalize API SHALL 只形成分片verify事实。Complete阶段组合整文件hash并发布成功 SHALL 仅由`upload.finished{result=committed}`表达；complete中途失败 SHALL NOT 额外输出整文件scope的`upload.verify_finished`。

#### Scenario: upload complete未发布文件

- **WHEN** canonical complete在组合hash、同步cache或发布目标过程中失败且文件没有committed
- **THEN** Qtserver SHALL NOT 输出file scope的`upload.verify_finished`
- **AND** 后续没有成功事实时该文件 SHALL 由inactivity timeout收敛

#### Scenario: 上传hash比较不一致

- **WHEN** Qtserver实际计算上传chunk hash并完成比较但与客户端值不一致
- **THEN** SHALL 输出`upload.verify_finished{verification_result=mismatched}`
- **AND** SHALL NOT 把该文件直接判定为失败

#### Scenario: 上传校验执行失败

- **WHEN** Qtserver已经开始读取或计算上传hash但因I/O或依赖错误无法完成比较
- **THEN** SHALL 输出`upload.verify_finished{verification_result=failed}`
- **AND** 调试日志 MAY 记录具体错误，但原始事件 SHALL NOT 保存异常文本

上传只有两种 producer 成功事实：文件最终校验并原子发布后输出 `upload.finished{result=committed}`；init 使用客户端整文件 hash确认已有目标内容相同时输出 `upload.finished{result=already_present}`。Canonical upload init SHALL 接受非空`file_hash`与受支持的`hash_algorithm`；already-present SHALL 同时要求目标为普通文件、大小相同、服务端hash可用、算法一致且hash值相同。仅目标存在、仅大小相同、hash pending/unavailable或hash不一致 SHALL NOT 输出成功事实。Cancel、session release/expire、源文件变化、客户端停止和单次服务端错误 SHALL NOT 输出文件失败事件；后续没有成功事实时由 inactivity timeout 收敛。

零字节上传 SHALL 使用普通canonical upload：init SHALL 输出`file.registered`并建立零chunk session，complete SHALL 使用协议定义的零chunk分层hash原子发布空文件并输出`upload.finished{result=committed}`。该活动 SHALL 不产生upload chunk或verify事件，最终`transmitted=0`、`retry_count=0`、`speed=null`。

#### Scenario: 零字节上传成功

- **WHEN** 合法file size为0的canonical upload完成并发布空文件
- **THEN** 原始历史 SHALL 只有注册和`upload.finished{result=committed}`成功事实
- **AND** 最终 SHALL 是`SUCCESS/UPLOADED_AND_COMMITTED`且transmitted与retry为0、speed为null

#### Scenario: hash mismatch 后重传

- **WHEN** 分片校验 mismatch 后相同 chunk index再次上传并最终 committed
- **THEN** mismatch、两次 chunk finished 和 committed 事实 SHALL 全部保留
- **AND** 文件最终 SHALL 是 `SUCCESS/UPLOADED_AND_COMMITTED`

#### Scenario: 目标内容已经存在

- **WHEN** upload init 携带整文件 hash且 qtserver 确认目标文件大小与内容一致
- **THEN** Qtserver SHALL 输出 `file.registered` 和 `upload.finished{result=already_present}`
- **AND** 最终 `transmitted` 与 `retry_count` SHALL 是 0
- **AND** `speed` SHALL 是 null

#### Scenario: 目标大小相同但hash不同

- **WHEN** upload init发现目标大小与客户端文件相同但整文件hash不一致
- **THEN** Qtserver SHALL NOT 输出`upload.finished{result=already_present}`
- **AND** 后续没有committed事实时文件 SHALL 最终TIMEOUT

#### Scenario: cancel 后没有继续

- **WHEN** 上传 session 被 cancel且没有后续 committed 或 already-present 事实
- **THEN** Producer SHALL NOT 输出 cancelled 文件终态
- **AND** 分析程序 SHALL 在 inactivity deadline 后形成 `FAILED/TIMEOUT`

### Requirement: 普通下载完成事件覆盖实际响应与整文件校验

普通下载每个 `/d/down` GET SHALL 使用请求头 `X-QT-Chunk-Index` 携带非负十进制integer `chunk_index`，包括Range GET与无Range完整文件GET；同一客户端分片的断点续传和重试 SHALL 保持相同chunk index，单请求完整GET SHOULD 使用0。该请求头缺失、格式非法或超出实现可接受整数范围时，Qtserver SHALL 在输出 `file.registered` 或开始发送数据前拒绝请求，并 SHALL NOT 为该请求输出原始业务事件。该值 SHALL 只用于原始日志分片关联和 retry count 分组，SHALL NOT 参与认证、授权、grant校验、文件定位、Range计算或传输成功判定。

普通`/d/down` SHALL 只为`file_size>0`的文件产生数据和chunk事件：Range GET使用规范非空半开区间，完整GET使用`[0,file_size)`。零字节下载 SHALL 走small路径，Qtserver SHALL NOT 为它构造`[0,0)`的`download.chunk_finished`。

#### Scenario: 无Range完整文件GET

- **WHEN** qtransc以`X-QT-Chunk-Index: 0`对非空普通文件执行无Range完整GET
- **THEN** `download.chunk_finished`的Range SHALL 是`[0,file_size)`且expected status为200

#### Scenario: 零字节文件不走普通GET

- **WHEN** download grant表示file size为0
- **THEN** qtransc SHALL 使用small路径而不调用`/d/down`
- **AND** Qtserver SHALL NOT 输出空Range的download chunk事件

Qtserver SHALL 校验外部请求头并通过以下九个只对Nginx可见的内部响应头重新构造可信handoff：

```text
X-QT-Log-Task-ID
X-QT-Log-Task-PID
X-QT-Log-Enterprise-ID
X-QT-Log-File-Key
X-QT-Log-Chunk-Index
X-QT-Log-Range-Start
X-QT-Log-Range-End
X-QT-Log-Expected-Status
X-QT-Log-Expected-Bytes
```

它们 SHALL 分别表示`task_id`、允许为空的`taskpid`、允许为空的`enterprise_id`、`file_key`、已校验`chunk_index`、规范半开Range两端、预期200或206状态及`range_end-range_start`。Nginx SHALL 只使用对应的`$upstream_http_x_qt_log_*`值构造业务事件，SHALL NOT 直接读取客户端`X-QT-Chunk-Index`、`X-Task-PID`、`X-Enterprise-ID`或客户端提交的任意内部同名header，并 SHALL 从客户端响应隐藏全部九项。Schema version 1与`event_type=download.chunk_finished` SHALL 是专用Nginx log format常量；Qtserver SHALL NOT 为schema v1 handoff传递event ID、operation ID、started time、producer或file size。

Nginx SHALL 在写专用业务事件前使用map或等价配置验证除允许为空的`taskpid`和`enterprise_id`外七项upstream handoff结构合法：task ID与file key非空，chunk index、Range端点与expected bytes为非负十进制integer文本，expected status为`200|206`。任一辅助标签为空 SHALL NOT 阻止事件写入。只有结构检查通过时，internal location才 SHALL 使用条件`access_log`写入`download_events.log`。缺失或非法必要handoff、客户端直接访问internal location以及非X-Accel请求 SHALL NOT 向业务事件文件写入含`-`占位符或非JSON数值的行；它们 MAY 由普通access/error log记录。Range顺序、expected bytes与Range宽度等跨字段关系仍 SHALL 由schema decoder校验。

实际数据发送方 SHALL 在普通下载响应结束时输出 `download.chunk_finished`，payload 包含非负`chunk_index`、`range_start`、`range_end`、非负 `actual_bytes`、`http_status`和`result=succeeded|interrupted|failed`。范围 SHALL 满足`0 <= range_start < range_end <= file_size`，actual bytes SHALL 不大于Range宽度，HTTP status SHALL 是`100..599` integer，succeeded SHALL 只允许状态200或206且actual bytes等于Range宽度。启用X-Accel时producer SHALL 是Nginx，direct模式 SHALL 是qtserver；两者 SHALL 使用完全相同的payload语义。`actual_bytes` SHALL 是本响应实际发送的文件内容字节。

两种producer SHALL 按以下规则确定结果：

- 实际HTTP状态等于expected status、200没有Content-Range或206具有合法单区间Content-Range、请求正常结束且实际body bytes等于expected bytes时，`result` SHALL 是`succeeded`、`actual_bytes` SHALL 是实际body bytes。
- 状态与Content-Range仍表示预期文件数据响应，但请求未正常结束或body bytes与expected bytes不同，`result` SHALL 是`interrupted`、`actual_bytes` SHALL 是实际发送的文件body bytes。
- 实际状态不等于expected status，或206 Content-Range格式无效，`result` SHALL 是`failed`、`actual_bytes` SHALL 是0。错误响应body SHALL NOT 计作文件内容传输字节。

Nginx SHALL 使用`$request_completion`、`$status`、`$sent_http_content_range`和`$body_bytes_sent`形成上述事实，`occurred_at` SHALL 使用log phase时间，并按主机本地时区输出三位毫秒与数字偏移。Nginx SHALL NOT 要求启动环境额外设置`TZ`；若无法构造协议要求的时间，SHALL NOT 写入带虚假兜底时间的业务事件。第一版 SHALL NOT 要求Nginx再次逐字符证明Content-Range与handoff Range完全相等；预期状态、Range格式与expected bytes校验 SHALL 是本契约要求的边界。Direct模式 SHALL 使用可获得的请求context、响应状态和实际writer bytes实现同一可观察语义。

Qtserver 每次通过认证、参数、路径等前置校验并实际开始读取、计算或比较hash的普通下载校验结束后 SHALL 输出 `download.verify_finished`，其已知payload字段 SHALL 是 `verification_scope=chunk|file`、适用的`chunk_index`与`verification_result=matched|mismatched|failed`。完成比较且一致时 SHALL 使用`matched`，完成比较但不一致时 SHALL 使用`mismatched`，进入校验执行后因读取、计算或依赖错误无法得出结论时 SHALL 使用`failed`。请求前置校验失败以及服务端hash为`HASH_PENDING`或`HASH_UNAVAILABLE`、尚无可比较结果时 SHALL NOT 输出verify完成事件，也 SHALL NOT 刷新文件不活动deadline。当前producer SHALL NOT 输出其他payload字段；consumer仍 SHALL 按公共规则保留并忽略未来未知payload字段。Scope为chunk时chunk index SHALL 是非负integer；scope为file时chunk index SHALL 是null。只有整文件 `matched` SHALL 是 `SUCCESS/DOWNLOADED_AND_VERIFIED` 的权威成功事实；分片 matched 和整文件 mismatched/failed 都不结束文件。

#### Scenario: 下载服务端hash仍在生成

- **WHEN** 整文件`/d/verify`得到`HASH_PENDING`或`HASH_UNAVAILABLE`且尚未开始比较hash
- **THEN** Qtserver SHALL NOT 输出`download.verify_finished`
- **AND** 该请求 SHALL NOT 刷新日志不活动deadline

#### Scenario: 下载hash计算执行失败

- **WHEN** Qtserver已经开始读取或计算下载校验hash但因I/O或依赖错误无法完成比较
- **THEN** SHALL 输出`download.verify_finished{verification_result=failed}`
- **AND** 该事件 SHALL 刷新当前有效的不活动deadline但不得建立文件失败终态

Schema v1 payload SHALL NOT 要求或输出expected hash、actual hash、hash algorithm、请求级reason code或异常文本。现有文件hash存储和调试日志 MAY 保存其职责内的信息，但分析程序 SHALL NOT 读取它们补齐或覆盖原始业务事件。

普通用户与内置 `anonymous` 用户 SHALL 使用相同 Range、整文件 verify 和日志分析流程。两者的身份解析方式 MAY 不同，但 SHALL NOT 形成不同的下载业务类型。整文件 matched 已经证明客户端持有一致内容，因此 qtransc SHALL NOT 再调用独立下载完成确认 API。

#### Scenario: 断点续传改变 Range 起点

- **WHEN** qtransc 对同一个 chunk 从后续 offset继续 Range 下载
- **THEN** 新请求的 `X-QT-Chunk-Index` SHALL 保持原 `chunk_index` 并携带实际新 Range
- **AND** 分析程序 SHALL 将它计作该 chunk 的额外 attempt

#### Scenario: 下载请求缺少 chunk index

- **WHEN** 普通 `/d/down` 请求缺少合法 `X-QT-Chunk-Index`
- **THEN** Qtserver SHALL 在注册文件或发送数据前拒绝请求
- **AND** SHALL NOT 输出 `file.registered` 或 `download.chunk_finished`

#### Scenario: 客户端伪造 Nginx 日志字段

- **WHEN** 客户端同时提交`X-QT-Chunk-Index`、`X-Task-PID`、`X-Enterprise-ID`和任意`X-QT-Log-*`内部header
- **THEN** Qtserver SHALL 只校验外部chunk index并从当前请求日志上下文重新构造全部内部handoff
- **AND** Nginx SHALL 只使用qtserver upstream的`X-QT-Log-*`值

#### Scenario: Nginx专用格式固定schema和event type

- **WHEN** Nginx记录一条X-Accel普通下载完成事件
- **THEN** log format SHALL 直接输出integer`schema_version=1`和string`event_type=download.chunk_finished`
- **AND** SHALL NOT 从handoff读取这两个常量或输出其他公共字段

#### Scenario: Nginx缺少完整必要handoff

- **WHEN** internal location请求没有结构合法的task、file、chunk、Range、expected status和expected bytes upstream handoff
- **THEN** Nginx SHALL NOT 向`download_events.log`写入该请求
- **AND** SHALL NOT 生成包含`-`或非JSON数值的半条schema v1 JSON

#### Scenario: Nginx收到空辅助标签

- **WHEN** 其他必要handoff合法但`X-QT-Log-Task-PID`或`X-QT-Log-Enterprise-ID`为空或缺失
- **THEN** Nginx SHALL 写出合法 v1 事件并为对应字段写入空字符串

#### Scenario: 未启用Nginx加速

- **WHEN** qtserver direct模式处理一个普通Range下载
- **THEN** qtserver SHALL 在响应结束后输出`download.chunk_finished`
- **AND** 分析程序 SHALL 与Nginx事件使用相同规则归约

#### Scenario: X-Accel连接中途断开

- **WHEN** Nginx已经开始合法文件数据响应但`$request_completion`不是`OK`
- **THEN** Nginx SHALL 输出`download.chunk_finished{result=interrupted}`
- **AND** `actual_bytes` SHALL 使用已经发送的文件body bytes

#### Scenario: X-Accel返回错误状态

- **WHEN** internal文件发送实际状态不等于qtserver handoff的expected status
- **THEN** Nginx SHALL 输出`download.chunk_finished{result=failed}`
- **AND** `actual_bytes` SHALL 是0，即使错误响应本身发送了body

#### Scenario: Nginx内部日志header不暴露

- **WHEN** 客户端收到X-Accel普通下载响应
- **THEN** SHALL 看不到上述九个task、辅助标签、file、chunk、Range、expected status或expected bytes handoff header

#### Scenario: 响应完整但没有整文件 verify

- **WHEN** 所有 Range 响应均成功但没有整文件 matched 事实
- **THEN** 普通下载 SHALL NOT 成为成功
- **AND** SHALL 在 inactivity deadline 后形成 `FAILED/TIMEOUT`

#### Scenario: anonymous 用户执行普通下载

- **WHEN** 使用 `anonymous` 用户的 qtransc 完成普通下载并通过整文件 verify
- **THEN** 文件 SHALL 成为 `SUCCESS/DOWNLOADED_AND_VERIFIED`
- **AND** principal 与 username SHALL 使用 `anonymous`

### Requirement: enterprise_id 作为辅助标签进入原始事件和最终日志

每条 schema v1 原始业务事件 SHALL 在 `taskpid` 后显式记录 string 字段 `enterprise_id`；无值时 SHALL 记录空字符串。Canonical upload SHALL 使用 session 创建时保存的初始 `enterprise_id` 输出该 session 的全部原始事件。普通下载和 Small 事件 SHALL 使用对应请求的 Qtserver 日志上下文；X-Accel 普通下载 chunk 事件 SHALL 使用 Qtserver 交给 Nginx 的内部 handoff，而不得直接信任客户端提交的同名内部 header。

`enterprise_id` SHALL NOT 参与 `file_key` 算法、注册合法性、上下文冲突、事件有效性、attempt、inactivity deadline、transmitted、retry count、speed、result、result reason 或其他业务判断，也不得产生企业级状态或新的事件类型。后续事件中的不同值 SHALL 只保留为原始证据，不得覆盖最终值。

普通文件最终日志 SHALL 从被选定的最早合法 `file.registered` envelope 同时取得 `taskpid` 与 `enterprise_id`；Small 文件 SHALL 从形成当前 `SMALL_FILE_SENT` 结果的同一条 `download.small_file_sent` 同时取得两项标签。最早候选事件的 `occurred_at` 并列、业务内容完全相同且仅辅助标签不同时，分析程序 SHALL 按 `(taskpid, enterprise_id)` 的 UTF-8 bytes 字典序选择最小 tuple 对应的整条事件，禁止分别选择两个字段或依赖导入顺序。

#### Scenario: 原始事件记录 enterprise_id

- **WHEN** Qtserver 为带非空 `enterprise_id` 的文件活动输出原始事件
- **THEN** 同一 envelope SHALL 包含相同归一化 string 值的 `enterprise_id`
- **AND** typed payload SHALL 与空企业标签时保持相同

#### Scenario: 后续事件携带不同 enterprise_id

- **WHEN** 最早合法注册之后的 chunk、verify 或 finished 事件携带不同 `enterprise_id`
- **THEN** producer SHALL 在各事件中记录对应日志上下文允许采用的值
- **AND** 该差异 SHALL NOT 改变事件类型、payload、状态、指标或业务结果

#### Scenario: 企业标签不同但文件活动相同

- **WHEN** 两个请求只在 `enterprise_id` 上不同而 task ID、路径、principal 和 action 相同
- **THEN** `file_key` SHALL 保持相同
- **AND** `enterprise_id` SHALL NOT 创建新的文件活动或企业聚合状态

#### Scenario: 同时间注册的辅助标签并列

- **WHEN** 两条最早合法注册具有相同 `occurred_at` 和业务内容，但标签 tuple 分别为 `("b","a")` 与 `("a","z")`
- **THEN** 分析程序 SHALL 选择 tuple `("a","z")` 对应的整条注册事件
- **AND** SHALL NOT 合成不存在的 `("a","a")`

### Requirement: 小文件下载只记录完整发送成功

Small download SHALL 不输出 `file.registered`、开始、失败、重试、timeout 或 verify 事件，也 SHALL NOT 为 v2 新增其他原始业务事件类型。

对 v1，Qtserver 只有在一个小文件的 `io.Copy` 成功、实际字节等于 `file_size` 且显式 `tar.Writer.Flush()` 成功写完当前 entry padding 后，才 SHALL 立即输出一条 `download.small_file_sent`；未写完、字节数不符、当前 entry flush 失败、中途停止或其他写入失败 SHALL 不输出该文件的任何原始业务事件。Producer SHALL NOT 仅以 `io.Copy` 返回成功提前记录，也 SHALL NOT 等待整个批次 tar 关闭后才统一补写已完成文件。

对 v2，Qtserver SHALL 在每个 payload 内容和 entry padding 完整写入时确定该文件的 `download.small_file_sent` 内容与 `occurred_at`，但 SHALL 将该批次事件暂存在内存中。只有全部 payload entry 均完成后，Qtserver 才 SHALL 按 manifest 顺序批量 append 这些逐文件事件，并在该批次全部事件完成一次 sync 后发送 checksum footer。任一 payload 未完成时 SHALL 不 append 本批次暂存的任何事件；事件 append 或 sync 失败时 SHALL 不发送 footer。Footer 或后续 tar 结束写入失败 SHALL NOT 撤回已经持久化的发送事实。

`download.small_file_sent` SHALL 自包含最终记录需要的 `task_type`、`action=download`、`file_path`、`file_size`、`principal_id`、`client_username`、`client_id`、`client_ip`、`client_os`、`client_version`、允许为空的 `caller_version`、`server_ip`、`server_instance`、`server_version` 和 `started_at`。这些上下文字段 SHALL 使用注册 payload 的相同类型规则；`started_at` SHALL 与 envelope `occurred_at` 使用相同的主机本地时区、三位毫秒与数字偏移格式，并且换算为绝对时间后不得晚于 envelope `occurred_at`。Envelope `occurred_at` SHALL 是 Qtserver 完成该文件 payload entry 写入的时间，即使 v2 事件稍后才批量 append。

普通事件family SHALL 与最早合法注册action匹配：`upload.*`只可用于upload，`download.*`只可用于download。事件早于注册、family与action不匹配、注册四元组或small自包含四元组无法按本spec重算出envelope file key时，该事件 SHALL NOT 参与状态、deadline或统计，并 SHALL 在inspect中报告。无注册普通事件 MAY 先保留在外部原始事件历史存储中，注册到达后再执行语义校验。

分析程序收到合法 small-file event 后 SHALL 立即形成 `SUCCESS/SMALL_FILE_SENT`，并设置 `transmitted=file_size`、`retry_count=0`、`start_time=started_at`、`end_time=occurred_at`。该事件只证明 Qtserver 已完整发送对应 payload entry，不证明客户端已收到 checksum footer、完成 tar 校验或发布本地文件。多个 v2 批次尝试 MAY 为同一 file key 产生多个真实发送事件；分析程序 SHALL 使用最早合法 small 成功事实且 SHALL NOT 从这些事件推导客户端重试次数。

多个小文件在同一响应中传输时 SHALL 按文件边界独立记录。v1 后续文件失败不得撤销此前已记录文件的成功；v2 任一 payload 失败 SHALL 使本批次暂存事件全部不写入，但 footer 写入失败不得撤销此前已经批量持久化的事件。

合法 small 成功 SHALL 对同一 `file_key` 具有终态优先级。客户端在 small 成功事件后因本地校验、tar 尾部或连接问题重试 v2 批次或改走普通下载时，后续 small、`file.registered`、`download.chunk_finished` 与 `download.verify_finished` MAY 保留在外部原始事件历史存储和 inspect 中，但 SHALL NOT 改变、补充或撤回现有 `SUCCESS/SMALL_FILE_SENT` 的任何最终字段。

零字节下载 SHALL 使用 small 路径而不是由 qtransc 根据 grant 响应直接在本地完成。v1 在 Qtserver 成功写入 header 并结束零长度 tar entry 后 SHALL 输出 `download.small_file_sent`；v2 SHALL 在全部 payload 结束后随批次持久化该零字节文件事件并在成功 sync 后发送 footer。其最终 `transmitted=0`、`retry_count=0`、`speed=null`。客户端随后无法创建本地空文件 SHALL NOT 改变该服务端成功事实。

#### Scenario: 小文件完整写完

- **WHEN** Qtserver 通过 v1 正常完成一个小文件全部内容和 entry padding 的响应写入
- **THEN** SHALL 输出一条自包含 `download.small_file_sent`
- **AND** 分析程序 SHALL 不等待其他事件即形成成功最终记录

#### Scenario: 小文件调用方版本为空

- **WHEN** small请求没有提供非空调用方版本且文件完整写完
- **THEN** `download.small_file_sent` payload 与最终记录 SHALL 显式包含空字符串 `caller_version`

#### Scenario: 当前tar entry flush失败

- **WHEN** 小文件内容字节已经全部复制，但`tar.Writer.Flush()`写当前entry padding失败
- **THEN** Qtserver SHALL NOT 输出该文件的`download.small_file_sent`
- **AND** SHALL 停止当前small响应的后续文件

#### Scenario: 小文件中途断开

- **WHEN** Qtserver 未完成一个小文件的全部响应写入或写入返回错误
- **THEN** SHALL NOT 输出该文件的任何原始业务事件
- **AND** 分析程序 SHALL NOT 为该文件生成 TIMEOUT 或失败结果

#### Scenario: 批次中后续文件失败

- **WHEN** v2 批次的第一个 payload 已完整写出，但第二个 payload 中途失败
- **THEN** Qtserver SHALL NOT append 本批次任何暂存的 `download.small_file_sent`
- **AND** SHALL NOT 发送 checksum footer

#### Scenario: 批次尾部关闭失败

- **WHEN** v2 全部 payload 的逐文件事件已经批量 append 并 sync，但 checksum footer 或 tar 结束写入失败
- **THEN** 已持久化的逐文件成功事实 SHALL 保留
- **AND** 客户端 MAY 重试整个批次

#### Scenario: v2 重试形成重复发送事实

- **WHEN** 同一 file key 因 v2 批次重试产生多个合法 `download.small_file_sent`
- **THEN** 分析程序 SHALL 保持最早的 `SUCCESS/SMALL_FILE_SENT`
- **AND** SHALL NOT 将后续事件计入 transmitted 或 retry count

#### Scenario: small成功后客户端普通下载fallback

- **WHEN** 同一file key在small成功事件之后出现普通下载注册、chunk或verify事件
- **THEN** 当前最终结果 SHALL 保持第一次`SUCCESS/SMALL_FILE_SENT`
- **AND** 普通事件 SHALL NOT 计入transmitted或retry count

#### Scenario: 零字节下载

- **WHEN** Qtserver 成功结束包含零字节文件的全部 v2 payload 并完成批次事件 sync
- **THEN** SHALL 为该文件持久化 `download.small_file_sent` 后发送 footer
- **AND** 最终记录 SHALL 是 `SUCCESS/SMALL_FILE_SENT` 且 transmitted 为 0、speed 为 null

### Requirement: 普通文件使用成功或 inactivity timeout状态机

分析程序 SHALL 为普通文件使用 `PROCESSING|SUCCESS|FAILED` 三态模型。最早合法 `file.registered` 建立 `PROCESSING`；最早合法 `upload.finished` 或整文件 matched 的 `download.verify_finished` 建立 `SUCCESS`；超过该文件不活动 deadline 仍没有权威成功事实 SHALL 建立 `FAILED/TIMEOUT`。

分析程序 SHALL 以最早合法注册时间初始化 `last_activity_time`，再按 `occurred_at` 升序处理合法 chunk/verify完成事件：

```text
last_activity_time = start_time
deadline = last_activity_time + file_inactivity_timeout_seconds

for occurred_at group in chunk_finished / verify_finished ordered by occurred_at:
    if group.occurred_at < start_time:
        reject event
    else if group.occurred_at <= deadline:
        validate and apply every event in this time group
        last_activity_time = group.occurred_at
        deadline = last_activity_time + file_inactivity_timeout_seconds
    else:
        stop extending deadline
```

分析程序 SHALL NOT 使用外部存储导入顺序作为同时间事件的先后关系。相同 `occurred_at` 的合法 chunk 与 verify 完成事实 SHALL 作为一个时间组处理；该时间等于当前 deadline 时 SHALL 先应用整个时间组再刷新 deadline。SUCCESS 与 TIMEOUT 的统计窗口 SHALL 是闭区间，因此与最早权威成功事实具有相同 occurred time 的所有合法 chunk attempt SHALL 全部参与 transmitted 与 retry count。普通同时间事实 SHALL NOT 要求 event ID或其他排序字段。语义互斥的权威成功事实 SHALL 继续按本spec的producer冲突规则处理，不得按导入顺序选择。

#### Scenario: 成功事实与 chunk attempt 同时发生

- **WHEN** 最早权威成功事实与一个或多个合法 chunk finished具有相同`occurred_at`
- **THEN** 这些chunk attempt SHALL 全部位于SUCCESS闭区间并参与transmitted与retry count
- **AND** 导入顺序 SHALL NOT 改变最终结果

#### Scenario: 活动事实恰好位于 deadline

- **WHEN** 一个或多个合法chunk/verify完成事实的`occurred_at`等于当前deadline
- **THEN** 分析程序 SHALL 应用整个同时间组并把deadline刷新到该时间加固定timeout
- **AND** SHALL NOT 在处理该时间组前形成TIMEOUT

内容一致的重复注册 SHALL NOT 刷新last activity。遇到第一条 `occurred_at > deadline` 的普通事件后，分析程序 SHALL 固定该首次不活动deadline，且更晚普通事件 SHALL NOT 再延长它。超时 `end_time` SHALL 使用该deadline而不是扫描程序运行时间；分析时钟 SHALL 只判断deadline是否已经到达。服务端没有暂停状态，客户端停止调用 API SHALL 不冻结 deadline。普通文件没有 producer 明确失败终态；所有未走到权威成功 API 的情况 SHALL 统一由 TIMEOUT 结束。

Qtserver `log.file_inactivity_timeout_seconds` SHALL 默认是`86400`，且配置校验 SHALL 要求大于0。该字段与`transfer.upload_session_retention_seconds`相互独立；默认值相同 SHALL NOT 使修改任一配置隐式改变另一个。每个注册事件 SHALL 保存当时实际生效值。

#### Scenario: 默认不活动超时

- **WHEN** 运维没有显式配置`log.file_inactivity_timeout_seconds`
- **THEN** Qtserver SHALL 在`file.registered`中写入86400

#### Scenario: 修改超时配置

- **WHEN** 运维把不活动超时配置为另一个正整数
- **THEN** 新注册文件 SHALL 使用新值
- **AND** 已有文件历史 SHALL 继续使用各自注册事件中的值

#### Scenario: 普通文件长期无活动

- **WHEN** 当前分析时钟达到 deadline且文件没有权威成功事实
- **THEN** 分析程序 SHALL 保存 `FAILED/TIMEOUT`
- **AND** `end_time` SHALL 等于 deadline

#### Scenario: deadline 前出现新事件

- **WHEN** 一个合法 chunk 或 verify事件不晚于当前 deadline
- **THEN** 分析程序 SHALL 用该事件时间刷新 last activity和新 deadline

#### Scenario: 全量历史跨过首次不活动间隙

- **WHEN** 注册后的当前deadline为T1，下一条普通事件发生在T1之后，且完整历史中还有更多更晚普通事件
- **THEN** 分析程序 SHALL 使用T1作为首次inactivity deadline
- **AND** SHALL NOT 以更晚普通事件继续向后滚动deadline

### Requirement: 普通文件字段使用完成事实确定性归约

普通文件 `start_time` SHALL 使用最早合法 `file.registered.occurred_at`。分析程序 SHALL 先确定包含两个边界的结果统计窗口：SUCCESS是`start_time..最早权威成功时间`，TIMEOUT是`start_time..首次inactivity deadline`。普通事件早于start time SHALL 非法；晚于结果窗口的普通事件 MAY 保留在外部原始事件历史存储和inspect中，但 SHALL NOT 参与最终字段。

普通文件的公共上下文 SHALL 使用最早合法注册payload，small SHALL 使用自身payload。两条路径都 SHALL 原样保留上下文中的可信字段；`task_type`只表示场景分类，`"0"`和`"1"`均不得导致`server_ip`、`client_id`、`client_os`、`client_version`、`caller_version`或其他最终字段被删除、清空或改写。

全部25个最终字段 SHALL 确定如下：普通文件的`task_type`、`server_ip`、`client_id`、`client_ip`、`client_os`、`client_version`、`caller_version`、`client_username`、`action`、`file_path`、`file_size`与`principal_id`来自最早合法注册payload，small的这些字段来自其自包含payload；`task_id`与`file_key`来自对应envelope并通过四元组校验；普通文件的`taskpid`与`enterprise_id`来自同一条被选定的最早合法注册envelope，small的两项标签来自同一条形成当前结果的small成功envelope。普通文件`start_time`来自最早合法注册时间，small来自`started_at`；普通文件`end_time`来自最早权威成功时间或首次deadline，small来自事件时间；`duration`为两者非负毫秒差，`log_time`为候选首次写入或内容实际修订时的固定analysis time。普通文件`result`与`result_reason`按committed、already-present、整文件matched或timeout映射，small固定为`SUCCESS/SMALL_FILE_SENT`。`transmitted`、`retry_count`与`speed` SHALL 按下述规则计算。除此之外不得从调试日志、qtserver数据库或客户端状态补字段。

除already-present外，上传 `transmitted` SHALL 是结果统计窗口内合法 `upload.chunk_finished.actual_bytes` 之和；下载 SHALL 是结果统计窗口内合法 `download.chunk_finished.actual_bytes` 之和。`retry_count` SHALL 在相同窗口内按 `chunk_index` 分组，对每组计算 `max(finished_count-1,0)` 后求和，不要求前一个attempt结果是failed或interrupted。`SUCCESS/ALREADY_PRESENT` SHALL 固定 `transmitted=0` 与 `retry_count=0`。

上传成功 `end_time` SHALL 使用最早合法 `upload.finished.occurred_at`；下载成功 SHALL 使用最早合法整文件 matched 时间；失败 SHALL 使用 timeout deadline。除already-present外，成功且`transmitted>0`、`duration_ms>0`、`file_size>0`时speed SHALL 按本spec的三位小数规则计算，其他情况为null；already-present的speed SHALL 固定为null。校验请求、HTTP header、TLS 和授权数据 SHALL NOT 计入 transmitted。

#### Scenario: 新task复用完整下载现场只执行verify

- **WHEN** 新task ID的文件活动没有任何download chunk finished，但第一次携带metadata的整文件verify得到matched
- **THEN** 最终记录 SHALL 是`SUCCESS/DOWNLOADED_AND_VERIFIED`
- **AND** `transmitted=0`、`retry_count=0`且`speed=null`

#### Scenario: 原task ID继续完整下载现场

- **WHEN** 调用方复用原task ID且四元组其余字段不变，并在已有历史chunk后执行整文件matched verify
- **THEN** 分析程序 SHALL 按同一file key完整历史计算transmitted与retry count

普通文件duration SHALL 包含注册后的传输、校验、重试等待、退避和客户端静默wall-clock时间；服务端 SHALL NOT 猜测或扣除客户端暂停。并行chunk持续时间 SHALL NOT 相加。Speed SHALL 使用file size而非transmitted作为分子，表示端到端有效速度而非链路吞吐率。Small文件duration只覆盖当前tar响应内该文件从started_at到entry完成，不包含grant或客户端接收与本地校验时间。

#### Scenario: 客户端暂停后继续

- **WHEN** 普通文件注册后客户端静默一段时间并在deadline前继续直到成功
- **THEN** duration SHALL 包含该静默时间
- **AND** 分析程序 SHALL NOT 扣除未上报的暂停区间

#### Scenario: 并行分片

- **WHEN** 多个chunk并行传输并最终成功
- **THEN** duration SHALL 只等于文件start到end的wall-clock差
- **AND** SHALL NOT 累加各chunk耗时

#### Scenario: 成功响应丢失后再次请求

- **WHEN** 最早权威成功事实之后出现chunk、verify或相同成功事实重试
- **THEN** 最终结果 SHALL 保持第一次成功
- **AND** 成功之后的chunk SHALL NOT 进入transmitted或retry count

#### Scenario: 上传成功事实冲突

- **WHEN** 同一file key同时存在合法`upload.finished{committed}`与`upload.finished{already_present}`
- **THEN** 分析程序 SHALL 报告producer终态冲突
- **AND** SHALL NOT 按到达顺序或时间猜测其中一个结果

本模型没有 started 事件，因此完全没有留下完成事件的调用无法计入 transmitted 或 retry。分析程序 SHALL NOT 猜测其字节数，也 SHALL NOT 为此引入 `statistics_complete`、operation pairing 或全局序号。

连接中断后从后续offset续传、hash mismatch后重传或客户端重新请求同一chunk SHALL 都作为额外data attempt计数。Init、grant、verify、complete和查询请求的重复调用 SHALL NOT 增加`retry_count`。

#### Scenario: 中断 attempt有完成事件

- **WHEN** 一个 `chunk_finished{result=interrupted}` 记录了非零 actual bytes，随后重试并成功
- **THEN** 两个完成事件的实际字节 SHALL 都计入 transmitted
- **AND** 相同 chunk index SHALL 使 retry count增加 1

#### Scenario: 完成事件整行丢失

- **WHEN** 一次请求没有留下任何 finished 事件
- **THEN** 分析程序 SHALL 不猜测该请求的实际字节或 attempt
- **AND** 本契约允许最终统计小于真实网络成本

### Requirement: timeout结果允许被迟到成功事实修订

原始事件 SHALL 只追加。分析程序收到新事件后 SHALL 按受影响 `file_key` 从原始事件存储读取完整历史并重新归约。第一版只允许 `FAILED/TIMEOUT` 被迟到的 `upload.finished` 或整文件 matched `download.verify_finished` 修订为相应 SUCCESS；普通 chunk 或非成功 verify SHALL NOT 重新打开 timeout结果。

没有权威成功事实时，TIMEOUT候选的transmitted与retry count SHALL 只使用`occurred_at`位于`start_time..首次inactivity deadline`闭区间的合法chunk事件。Deadline后的普通chunk与非成功verify SHALL NOT 刷新deadline、修改TIMEOUT当前行或刷新log time。若完整历史后来出现权威成功事实，分析程序 SHALL 修订为SUCCESS，并重新纳入`start_time..成功事实时间`闭区间的全部合法chunk事件，包括原deadline之后的attempt；end time与duration SHALL 使用该成功事实重算。Already-present SHALL 继续使用零transmitted、零retry与null speed的专门规则。

同一成功事实因 HTTP 重试再次出现时 SHALL 使用最早合法成功时间，且每个 `file_key` 在当前结果存储中 SHALL 只有一行。完整历史因冲突、溢出、缺上下文或尚未生效的未来事件无法形成候选时，分析程序 SHALL 不插入新行，也 SHALL NOT 更新或删除已有当前行。第一版 SHALL NOT 要求成功撤回、任意终态往返、结果版本号、watermark 或复杂冲突裁决。

#### Scenario: timeout 后迟到 commit

- **WHEN** 外部当前结果存储中的结果是 `FAILED/TIMEOUT`，且外部原始事件历史存储后续出现合法 `upload.finished{result=committed}`
- **THEN** 分析程序 SHALL 将当前结果修订为 `SUCCESS/UPLOADED_AND_COMMITTED`

#### Scenario: timeout 后迟到普通 chunk

- **WHEN** timeout 后只出现一个普通 chunk finished
- **THEN** 分析程序 SHALL 保持 `FAILED/TIMEOUT`
- **AND** SHALL NOT 把文件恢复为 PROCESSING
- **AND** SHALL NOT 修改transmitted、retry count或log time

#### Scenario: timeout 后继续传输并最终成功

- **WHEN** timeout后出现普通chunk且随后出现合法committed事实
- **THEN** 分析程序 SHALL 将结果修订为SUCCESS
- **AND** SHALL 统计注册到commit时间之间的全部合法chunk事件

### Requirement: Nginx 日志轮转配置随部署配置生成

`qtserver config gennginx` SHALL 在同一输出目录生成 `qtserver_http.conf`、`qtserver_locations.conf` 和 `qtserver-nginx.logrotate`，默认输出目录 SHALL 为 Qtserver 二进制所在目录，`-o/--output` SHALL 只指定输出目录。生成器 SHALL 根据二进制所在目录的 `../nginx` 计算 `logs/download_events.log` 和 `logs/nginx.pid` 的绝对路径，SHALL NOT 根据当前工作目录、配置文件位置或输出目录计算这两个路径。该布局 SHALL 以同级 `nginx` 目录作为 Nginx 运行时 prefix；部署位置变化后 SHALL 重新生成并安装配置。

Logrotate 配置 SHALL 复用 `[log.rotation]`：`max_size=N` SHALL 生成 `size NM`，SHALL NOT 添加按天或其他时间周期轮转；`max_backups>0` SHALL 生成对应的 `rotate N`，`max_backups=0` SHALL 生成 `rotate -1`；`max_age=N` SHALL 生成 `maxage N`，只用于历史保留；`compress=true` SHALL 生成 `compress` 与 `delaycompress`，否则 SHALL 生成 `nocompress`。大小检查 SHALL 由外部 logrotate 调度触发，SHALL NOT 被描述为实时大小上限；延迟压缩 SHALL NOT 被描述为等待采集完成。

启用轮转时，生成配置 SHALL 使用改名轮转、数字归档后缀、`nocopytruncate`、`missingok`、`notifempty`，并在轮转后读取对应 PID 文件向 Nginx master 发送 `USR1`。PID 文件不存在时 SHALL 跳过信号；读取失败、PID 非正十进制整数或信号发送失败 SHALL 报错。生成器 SHALL 正确引用路径，并在路径不能安全表示时拒绝生成。无论是否启用 Nginx 下载加速，生成器 SHALL 输出 logrotate 文件；`enable=false` 时该文件 SHALL 仅包含禁用说明注释，SHALL NOT 包含轮转规则。

生成器 SHALL 在写入前完成三份内容的渲染与校验，并复用临时文件加重命名的单文件替换方式；重新生成 SHALL 覆盖既有输出。命令 SHALL 输出三份文件的位置，SHALL NOT 自动安装 logrotate 配置、调度轮转或向运行中的 Nginx 发送信号。

#### Scenario: 安装目录与配置输出目录相互独立

- **WHEN** 二进制位于 `/opt/qtrans7443/qtserver/qtserver`，从其他工作目录使用任意 `-c` 和 `-o /tmp/nginx-configs` 执行 `config gennginx`
- **THEN** 三份配置 SHALL 输出到 `/tmp/nginx-configs`
- **AND** 轮转配置 SHALL 指向 `/opt/qtrans7443/nginx/logs/download_events.log` 与 `/opt/qtrans7443/nginx/logs/nginx.pid`

#### Scenario: 复用保留和压缩参数

- **WHEN** `enable=true`、`max_size=100`、`max_backups=0`、`max_age=7`、`compress=true`
- **THEN** 轮转配置 SHALL 包含 `size 100M`、`rotate -1`、`maxage 7`、`compress` 与 `delaycompress`
- **AND** SHALL NOT 包含 `daily` 或 `maxsize`

#### Scenario: 关闭轮转后重新生成

- **WHEN** `enable=false` 且输出目录已有启用轮转的配置
- **THEN** `qtserver-nginx.logrotate` SHALL 被替换为仅包含禁用说明的文件
- **AND** 即使未启用 Nginx 下载加速，命令也 SHALL 生成并报告全部三份文件

### Requirement: 原始事件写入、轮转和凭据边界明确

Qtserver active 文件 SHALL 固定为 `log.file_path/business-events.jsonl`；Nginx active 文件 SHALL 固定使用相对于 Nginx 运行时 prefix 的 `./logs/download_events.log`。每个事件 SHALL 完整占一行并以换行结束；压缩 SHALL 只处理已经关闭的轮转段。Active 文件末尾未换行内容 SHALL 留待下次采集，关闭段中的不完整行 SHALL 被隔离。

Qtserver SHALL 复用既有 `[log.rotation]` 配置，不增加业务日志专用轮转配置。仅当 `log.rotation.enable=true` 且 active 文件已有内容、追加下一条完整事件将使文件超过 `log.rotation.max_size` 时，Qtserver SHALL 在追加前按大小轮转；任何运行时长、自然日、固定时刻、进程关闭或进程重启 SHALL NOT 触发轮转。`log.rotation.max_age` SHALL 只控制已关闭归档的保留期清理，SHALL NOT 作为时间轮转周期。`log.rotation.max_backups` SHALL 限制已关闭归档数量，`log.rotation.compress` SHALL 只决定已关闭归档是否压缩。`log.rotation.enable=false` 时，Qtserver SHALL 持续追加同一个 active 文件且 SHALL NOT 因文件大小或时间生成新归档。

轮转前，所有事件 SHALL 只写入 `business-events.jsonl`，且目录中 SHALL NOT 为当前 active 内容预先创建带时间戳的归档或硬链接别名。一次成功轮转 SHALL 将刚关闭的 active 文件保存为不覆盖已有文件的 `business-events-<UTC timestamp>-<sequence>.jsonl`，并立即以 `business-events.jsonl` 创建新的 active 文件；启用压缩时 MAY 将刚关闭的归档转换为同名 `.jsonl.gz`。正常关闭 SHALL sync并关闭 active 文件但保留其固定路径；下一次启动 SHALL 修复最后一个完整换行之后的不完整尾部并继续追加，SHALL NOT 仅因关闭或重启把它改名、压缩或归档。

升级时，若新的 `business-events.jsonl` 不存在而旧版 `business_events.log` 存在，Qtserver SHALL 在继续写入前无损迁移旧 active 内容到新固定路径。若旧 active 与一个旧式 `business-events-*.jsonl` 是同一文件的硬链接，迁移后 SHALL 只保留新 active 路径承载该内容，SHALL NOT 将同一内容同时暴露为 active 和已关闭归档。若新旧 active 路径同时存在，或旧式文件关系无法无歧义判定，Qtserver SHALL NOT 合并、覆盖或删除任一文件，且 SHALL 进入日志不可用状态。旧版已经关闭且不与旧 active 同文件的归档 SHALL 保持关闭状态，并继续受归档保留策略管理。

Qtserver writer SHALL 串行 append 完整行，并在 `file.registered`、`upload.finished`、整文件 matched 的 `download.verify_finished` 以及 `download.small_file_sent` 上完成 sync 后才报告事件持久成功。v2 small 的同一批次多个 `download.small_file_sent` MAY 在同一个串行 writer 临界区内连续 append，并 SHALL 在全部完整行 append 后只执行一次 sync；sync 成功前 SHALL NOT 报告该批次事件持久成功。处于 logging-unhealthy 时 Qtserver SHALL 拒绝所有下一步会产生 schema v1 事件的传输或校验 API，而不只是新文件起点；不产业务事件的健康、恢复和查询操作 MAY 继续。Writer 或健康组件 SHALL 能在不写伪业务事件且不依赖事件生产 API 越过 gate 的情况下独立执行 reopen 与文件级 sync/状态探测；成功后 SHALL 先清除 gate，再恢复事件生产 API。恢复流程 SHALL NOT 因业务请求被 gate 拒绝而自锁。

Writer SHALL 在每次 append 前记录受同一串行锁保护的 active 文件边界。完整行已经写入但 sync 失败时 SHALL 只重试 sync，不得再次 append；partial write 后只有成功 truncate 并 sync 回写前边界时才 MAY 重试 append。v2 批量 append SHALL 对每个事件仍保留可恢复的行边界；任一行写入失败或最终 sync 失败 SHALL 使整个批量操作失败并进入 logging-unhealthy，但已经成为完整行的真实发送事实 SHALL NOT 被伪造为未发生。无法确认边界、truncate 失败或无法验证最后完整换行时 SHALL 保持 logging-unhealthy，不得盲目重写。独立恢复流程 MAY 截断 active 文件最后一个完整换行之后的不完整尾部并完成 sync；SHALL NOT 改写已经关闭的 segment。轮转 SHALL 与 append 使用同一串行边界。上述规则 SHALL 防止 producer 把一次 chunk 或 small payload 事实自身重复写成多个真实 attempt。

`file.registered`写入或sync失败 SHALL 在业务动作前返回稳定、可重试的日志不可用错误。Qtserver过程事件在请求业务事实已经发生后写失败 SHALL NOT 回滚已经接收、写入或校验的数据，当前请求 SHALL 返回其真实业务结果，同时 SHALL 进入logging-unhealthy并gate后续事件生产API。Producer SHALL NOT 为促使重试而把已经成功接受的PATCH伪装成业务失败。

真实committed、already-present或整文件verify matched发生后，Qtserver SHALL 在对应终态事件append并sync成功前不向客户端返回成功。写入失败 SHALL NOT 回滚真实文件或hash一致事实，但当前请求 SHALL 返回可重试的日志不可用错误；客户端以后对同一幂等API重试时，Qtserver SHALL 能再次输出内容一致的成功事件并在持久成功后返回业务成功。分析程序 SHALL 使用最早合法成功事实，不要求event ID。

Direct 下载响应完成后写 chunk 事件失败 SHALL NOT 回滚响应，但 SHALL 使 Qtserver logging-unhealthy 并接受本次统计事实缺失。v1 small 文件 entry 结束后 SHALL append 并 sync 其成功事件再开始下一个 entry；写入或 sync 失败 SHALL 停止继续生成该批次的后续文件响应、使 Qtserver logging-unhealthy 且不得撤回当前 entry，第一版接受当前文件成功事实缺失。v2 small SHALL 在全部 payload entry 结束后批量 append 逐文件成功事件并完成一次 sync；任一 append 或 sync 失败 SHALL 停止响应、不得发送 checksum footer 并使 Qtserver logging-unhealthy。Nginx access-log phase 写入失败 SHALL 通过 Nginx error log 与采集监控暴露，已发送响应不得回滚；第一版 SHALL NOT 要求 Nginx 反向修改 Qtserver 健康状态。

原始事件 SHALL NOT 包含 Authorization、access/refresh token、download grant、HMAC secret、anonymous fixed token、TLS key、请求 body或其他 credential。客户端 metadata SHALL 只用作日志上下文，服务端权威身份、IP、路径、大小、hash与发布结果 SHALL 使用已验证事实。

#### Scenario: 首次写入只创建固定 active 文件

- **WHEN** Qtserver 在空日志目录中写入第一条业务事件
- **THEN** 该事件 SHALL 写入 `business-events.jsonl`
- **AND** 目录中 SHALL NOT 因首次写入出现 `business-events-<UTC timestamp>-<sequence>.jsonl` 归档

#### Scenario: 达到大小阈值后轮转

- **WHEN** `log.rotation.enable=true` 且向非空 active 文件追加下一条完整事件将超过 `log.rotation.max_size`
- **THEN** 当前 active 内容 SHALL 先成为唯一的 `business-events-<UTC timestamp>-<sequence>.jsonl[.gz]` 归档
- **AND** 下一条事件 SHALL 写入新的 `business-events.jsonl`

#### Scenario: 保留期不是轮转周期

- **WHEN** `business-events.jsonl` 的存在时间超过 `log.rotation.max_age` 但没有达到大小轮转条件
- **THEN** Qtserver SHALL 继续向同一个 active 文件追加
- **AND** SHALL NOT 因经过该时间而创建归档

#### Scenario: 关闭并重启不轮转

- **WHEN** Qtserver 正常关闭后再次启动且 active 文件没有损坏
- **THEN** `business-events.jsonl` SHALL 保持 active 并继续追加
- **AND** 关闭或重启 SHALL NOT 单独产生新的归档

#### Scenario: 禁用轮转

- **WHEN** `log.rotation.enable=false` 且 active 文件超过 `log.rotation.max_size`
- **THEN** Qtserver SHALL 继续向 `business-events.jsonl` 追加
- **AND** SHALL NOT 生成新的业务事件归档

#### Scenario: 迁移旧式硬链接 active

- **WHEN** 新 active 不存在，且 `business_events.log` 与一个旧式未压缩时间戳文件指向同一文件
- **THEN** Qtserver SHALL 将其内容迁移为唯一的 `business-events.jsonl` active 文件
- **AND** SHALL NOT 将同一内容同时保留为时间戳归档

#### Scenario: 新旧 active 冲突

- **WHEN** `business-events.jsonl` 与 `business_events.log` 同时存在
- **THEN** Qtserver SHALL NOT 猜测、合并、覆盖或删除其中任一文件
- **AND** SHALL 报告日志不可用且拒绝事件生产API

#### Scenario: commit 后日志写入失败

- **WHEN** 文件已原子发布但 `upload.finished` 无法写入
- **THEN** Qtserver SHALL NOT 回滚已发布文件
- **AND** 当前complete请求 SHALL 返回可重试的日志不可用错误
- **AND** SHALL 进入logging-unhealthy并拒绝后续事件生产API

#### Scenario: writer恢复后重试已提交文件

- **WHEN** writer恢复后客户端重试一个文件已经committed但终态日志曾失败的complete请求
- **THEN** Qtserver SHALL 再次构造内容一致的`upload.finished{result=committed}`并可靠写入
- **AND** 写入成功后 SHALL 返回业务成功

#### Scenario: 过程事件写入失败

- **WHEN** 上传chunk数据已经被接受但对应`upload.chunk_finished`最终无法写入
- **THEN** Qtserver SHALL NOT 回滚或伪造未接收该数据
- **AND** 当前PATCH SHALL 返回已经接受数据的真实业务结果
- **AND** SHALL 进入logging-unhealthy并拒绝后续事件生产API

#### Scenario: 完整行写入后sync失败

- **WHEN** writer已确认当前chunk事件完整行存在但后续sync失败
- **THEN** writer SHALL 只重试sync且不得再次append该事件
- **AND** 分析结果 SHALL NOT 因writer恢复产生虚假的额外attempt

#### Scenario: partial write无法安全回滚

- **WHEN** writer发生partial write且无法truncate并sync回写前边界
- **THEN** SHALL 保持logging-unhealthy且不得盲目重写该行
- **AND** 独立恢复流程 SHALL 只清除active文件最后完整换行之后的不完整尾部

#### Scenario: small事件写入失败

- **WHEN** 当前 v1 small tar entry 已经结束但 `download.small_file_sent` 无法写入
- **THEN** Qtserver SHALL NOT 撤回已经写出的 entry
- **AND** SHALL 停止继续写该批次后续文件并进入logging-unhealthy

#### Scenario: small事件sync成功后继续批次

- **WHEN** 当前 v1 small tar entry 结束且其 `download.small_file_sent` 已经 append 并 sync 成功
- **THEN** Qtserver MAY 开始写下一个文件 entry
- **AND** 后续 entry 失败 SHALL NOT 撤回当前文件成功事实

#### Scenario: v2 批次事件只 sync 一次

- **WHEN** 一个 v2 批次的全部 payload entry 已完成且所有逐文件事件完整 append
- **THEN** writer SHALL 对该批次执行一次文件级 sync
- **AND** Qtserver SHALL 仅在 sync 成功后发送 checksum footer

#### Scenario: v2 批次事件 sync 失败

- **WHEN** v2 批次事件完整 append 后 sync 失败
- **THEN** writer SHALL 只恢复或重试 sync 而不得再次 append 同一发送 attempt
- **AND** Qtserver SHALL NOT 发送 checksum footer
- **AND** SHALL 进入 logging-unhealthy

#### Scenario: 内部 handoff header

- **WHEN** Nginx 返回一个普通下载响应
- **THEN** 所有 qtserver 提供的日志 handoff header SHALL 对客户端隐藏

### Requirement: caller_version 在 schema v1 中保持向前与历史兼容

当前 schema v1 producer SHALL 在 `file.registered` 与 `download.small_file_sent` payload 中显式输出 string `caller_version`，空值 SHALL 编码为空字符串。升级后的 decoder SHALL 把历史 schema v1 上下文 payload 中缺失的 `caller_version` 归一化为空字符串；字段存在但不是 string 时 SHALL 按已知字段类型错误隔离。旧 decoder SHALL 按 schema v1 未知 payload 字段规则保留原始 JSON 并忽略 `caller_version`，不得仅因该新增字段隔离整行。

#### Scenario: 历史 payload 缺少 caller_version

- **WHEN** 新分析程序读取一条其他字段均合法、但上下文 payload 没有 `caller_version` 的历史 schema v1 事件
- **THEN** SHALL 把该事件的 `caller_version` 解释为空字符串
- **AND** SHALL NOT 仅因缺少该字段隔离事件

#### Scenario: caller_version 类型错误

- **WHEN** schema v1 上下文 payload 显式包含非 string `caller_version`
- **THEN** decoder SHALL 将该行作为已知字段类型错误隔离

#### Scenario: 旧分析程序读取新增字段

- **WHEN** 遵守 schema v1 未知 payload 字段规则的旧分析程序读取带 `caller_version` 的新事件
- **THEN** SHALL 保留原始 JSON 并忽略该未知字段
- **AND** SHALL NOT 仅因该字段隔离整行

### Requirement: v2 批次重试细节只进入 debug log

qtransc 和 Qtserver SHALL 使用既有 debug logging 通道记录 v2 small 的调度与重试诊断信息，而 SHALL NOT 为 batch、attempt、lane 获取、footer 校验或客户端发布新增 schema v1 原始业务事件类型。每个客户端批次 SHALL 使用仅用于诊断关联的 `batch_id`；相关 debug 记录 SHALL 至少能够关联 `batch_id`、当前 `attempt`、文件数、计划总字节数、transport、结果分类以及适用时的 retry 分类和下次尝试时间。服务端能够取得客户端传入的 batch 关联值时 MAY 记录同一 `batch_id`，但 SHALL NOT 将其当作授权或业务文件身份。

Debug log SHALL NOT 输出批次完整文件列表、Authorization、token、download grant、HMAC secret、请求 body 或本地临时文件内容。业务事件仍 SHALL 只表达服务端逐文件完整发送事实；debug attempt 数 SHALL NOT 被分析程序解释为业务日志的 `retry_count`。

#### Scenario: 批次发生可恢复错误

- **WHEN** 一个 v2 批次尝试因 HTTP `500`、连接中断或 hash mismatch 进入重试
- **THEN** qtransc SHALL 写入包含同一 `batch_id`、递增 `attempt`、结果分类和 retry 分类的 debug 记录
- **AND** SHALL NOT 为该重试新增原始业务事件类型

#### Scenario: 批次最终成功

- **WHEN** 一个经历过重试的 v2 批次最终验证并发布成功
- **THEN** debug log SHALL 能通过 `batch_id` 关联各次尝试和最终 completed 结果
- **AND** 原始业务日志 SHALL 继续按最早合法 `download.small_file_sent` 形成既有最终结果

#### Scenario: debug log 保护敏感与高基数字段

- **WHEN** qtransc 或 Qtserver 记录 v2 批次诊断信息
- **THEN** 记录 SHALL NOT 包含凭据、请求 body 或批次完整路径列表
- **AND** `batch_id` SHALL NOT 参与认证、授权或 file key 计算
