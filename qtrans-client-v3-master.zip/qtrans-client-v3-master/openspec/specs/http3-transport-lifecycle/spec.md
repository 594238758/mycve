# http3-transport-lifecycle Specification

## Purpose
定义 qtransc 普通 HTTP/3 请求的连接生命周期、物理连接与并发 stream 硬上限，以及服务端 GOAWAY 后安全排空、替换连接和恢复尚未发送请求的可观察行为。

## Requirements

### Requirement: HTTP/3 实际连接数受硬上限约束

qtransc SHALL 将现有连接数量配置解释为每轮任务、每个 origin 的实际存活 QUIC 连接硬上限；前台命令和 serve SHALL 使用 `--connections`；serve 的历史配置文件键 `quic.transports` SHALL 继续作为该设置的文件来源。连接名额 SHALL 从一次底层 QUIC Dial 开始占用，Dial 失败或连接 Context 结束后 SHALL 恰好释放一次。连接处于 ready、draining 或仍承载既有 stream 时 SHALL 继续占用名额。

qtransc SHALL NOT 为 GOAWAY 替换、重试或其他内部恢复临时建立超过该上限的 QUIC 连接。连接数按需增长且 MAY 低于上限；本要求不要求预建或始终维持固定数量。

#### Scenario: 单连接收到 GOAWAY 且仍有活跃 stream

- **GIVEN** 某 origin 的连接上限为 1，唯一 QUIC 连接仍有活跃 stream
- **WHEN** 该连接收到 GOAWAY 且新请求需要替代连接
- **THEN** qtransc SHALL 等待旧连接关闭并释放名额后再开始替代连接 Dial
- **AND** 任意时刻该任务该 origin 的实际存活 QUIC 连接数 SHALL NOT 超过 1

#### Scenario: Dial 失败释放名额

- **WHEN** HTTP/3 Dial 在返回可用 QUIC 连接前失败
- **THEN** qtransc SHALL 释放该次 Dial 占用的连接名额和底层网络资源
- **AND** 后续请求 SHALL 能够在连接上限内再次 Dial

#### Scenario: 连接池关闭

- **WHEN** qtransc 关闭 HTTP/3 连接池
- **THEN** qtransc SHALL 关闭 ready 与 draining 连接并释放对应连接名额、UDP 资源和等待中的 Dial

### Requirement: 单条 QUIC 连接的活跃 stream 数受硬上限约束

qtransc SHALL 将现有 stream 数量配置解释为单条实际 QUIC 连接的活跃 HTTP 请求 stream 硬上限；前台命令和 serve SHALL 使用 `--streams`；serve 的历史配置文件键 `quic.streamsPerTransport` SHALL 继续作为该设置的文件来源。一个请求从获得传输 Lease 到 RoundTrip 失败，或 Response Body 到达 EOF/被关闭期间 SHALL 占用一个 stream 名额。

连接替换与协议层重试 SHALL NOT 绕过或额外扩张该上限。draining 连接 SHALL NOT 接收新 stream，其已有 stream MAY 继续完成。

#### Scenario: 并发请求达到 stream 上限

- **GIVEN** 某条 QUIC 连接的 stream 上限为 4 且已有 4 个活跃请求
- **WHEN** 第 5 个请求申请同一连接的传输资源
- **THEN** qtransc SHALL 等待 stream 名额或选择连接上限内的其他可用连接
- **AND** 该 QUIC 连接的活跃 stream 数 SHALL NOT 超过 4

#### Scenario: GOAWAY 不接收新 stream

- **WHEN** QUIC 连接对应的 HTTP/3 会话已收到 GOAWAY
- **THEN** qtransc SHALL NOT 在该连接上创建 GOAWAY 禁止的新 request stream
- **AND** 已被服务端接受的既有 stream SHALL 继续按正常响应、取消或超时语义结束

### Requirement: GOAWAY 安全排空并替换连接

qtransc SHALL 将 HTTP/3 GOAWAY 视为连接生命周期事件，而不是任务级文件、路径或权限错误。收到 GOAWAY 后，旧连接 SHALL 进入 draining；新请求 SHALL 使用连接上限内的其他连接，或等待旧连接完全关闭后建立替代连接。

当 HTTP/3 协议栈能够证明请求尚未打开 stream、因连接进入 graceful shutdown 而未发送时，qtransc SHALL 在替代连接上进行最多一次协议层重试。该重试 SHALL 复用原请求 Context，且 SHALL NOT 使任务仅因本次正常连接轮换而失败。

#### Scenario: 目录查询撞上 GOAWAY

- **WHEN** 一个 GET 目录查询因旧连接 graceful shutdown 而无法打开 request stream，且协议栈证明请求尚未发送
- **THEN** qtransc SHALL 在符合连接与 stream 上限的替代连接上重试该查询
- **AND** 替代连接在原请求 Context 内成功时，任务 SHALL NOT 报告 `conn unusable: connection in graceful shutdown`

#### Scenario: 排空等待被取消

- **WHEN** 新请求等待 draining 连接释放名额期间，其原请求 Context 被取消或超时
- **THEN** qtransc SHALL 停止等待且 SHALL NOT 在取消后建立替代连接
- **AND** 调用方 SHALL 收到对应的取消或超时错误

#### Scenario: 替代连接仍不可用

- **WHEN** 同一请求已经完成一次协议层连接替换重试且替代连接仍不可用
- **THEN** HTTP/3 传输层 SHALL 返回错误而不得无限重试
- **AND** 后续是否重试 SHALL 由现有业务重试策略决定
