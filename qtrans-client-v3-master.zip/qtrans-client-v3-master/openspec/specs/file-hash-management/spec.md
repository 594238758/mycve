# file-hash-management Specification

## Purpose
定义正式文件 hash 的跨语言算法、Redis 缓存和协调状态机、文件 fingerprint、后台计算、retention 与失效契约。
## Requirements

### Requirement: layered_xxh3_128_v1 算法必须完全确定

`layered_xxh3_128_v1` SHALL 将文件按 104857600 bytes 分 chunk；每个 chunk SHALL 使用 seed 0 的 XXH3-128；128-bit digest SHALL 使用 `github.com/zeebo/xxh3.Uint128.Bytes()` 等价的大端 16-byte 表示；服务 SHALL 按 chunk index 拼接 digest，对结果再执行 seed 0 XXH3-128，并输出 32 个 lowercase hex 字符。零 chunk 文件 SHALL 对空 byte string 执行外层 hash。

#### Scenario: 空文件固定向量

- **WHEN** 输入文件长度为 0
- **THEN** `layered_xxh3_128_v1` SHALL 等于 `99aa06d3014798d86001c324468d497f`

#### Scenario: 单 chunk 固定向量

- **WHEN** 文件内容是 UTF-8 bytes `abc`
- **THEN** `layered_xxh3_128_v1` SHALL 等于 `f758394eebabb2bb51ee911f78f31836`

#### Scenario: 跨 chunk 边界固定向量

- **WHEN** 文件由 104857600 个 `0x00` bytes 后接一个 `0x01` byte 构成
- **THEN** `layered_xxh3_128_v1` SHALL 等于 `8bfc757b9f970427d349bb75e516af66`

### Requirement: chunk hash 使用 xxh3_128

上传 chunk finalize 和下载 chunk verify SHALL 使用 seed 0 XXH3-128，输出同样的大端 16-byte digest 的 lowercase 32-hex 字符串，并以 `xxh3_128` 标识算法。

#### Scenario: finalize 验证 chunk

- **WHEN** 客户端提交一个完整 chunk 的 `xxh3_128`
- **THEN** Qtserver SHALL 用相同 byte representation 计算和比较

### Requirement: 正式 hash 按逻辑对象和算法版本标识

Redis hash identity SHALL 至少包含 principal、normalized object key、algorithm 和 version。不同逻辑路径 SHALL 有独立记录，即使它们当时指向同一个 inode。

#### Scenario: 同一 inode 有两个逻辑路径

- **WHEN** 两个 object key 通过 hard link 或 symlink 最终读取同一 inode
- **THEN** 服务 SHALL 独立缓存、失效和返回各自路径的正式 hash

#### Scenario: 算法升级

- **WHEN** 同一逻辑对象请求不同 algorithm/version
- **THEN** Redis SHALL 保存互不覆盖的记录

### Requirement: 正式 fingerprint 只使用 ctime mtime 和 size

Qtserver SHALL 以 `ctime_ns,mtime_ns,file_size` 判断正式文件事实是否变化，SHALL NOT 使用 inode 或 device ID。对服务外修改后同时恢复这三个属性导致 stale hash 的情况，SHALL 归入受信任运维边界。

#### Scenario: fingerprint 发生变化

- **WHEN** 当前 stat 的 ctime、mtime 或 size 与 hash 记录不同
- **THEN** 旧 hash SHALL 立即失效且不得作为 stale 值返回

#### Scenario: 正式文件已不存在

- **WHEN** hash lookup 发现对应 logical object 已不存在
- **THEN** 服务 SHALL 使 Redis generation、hash record 和相关索引失效
- **AND** SHALL 按对象不存在返回而不得返回旧 hash

#### Scenario: 运维恢复全部 fingerprint 字段

- **WHEN** 运维原地改变 bytes 后恢复 ctime、mtime 和 size 到记录值
- **THEN** 服务 MAY 继续返回旧 hash
- **AND** 本 change SHALL NOT 增加额外内容探测

### Requirement: complete 从 verified chunk hashes 生成正式 hash

complete SHALL 按 chunk index 组合所有已验证的 chunk digest，生成 `layered_xxh3_128_v1`，不得为此重新扫描完整 cache file。零字节 session SHALL 使用固定空文件向量。

#### Scenario: 大文件完成上传

- **WHEN** 所有 chunk 均为 verified
- **THEN** complete SHALL 只读取 Redis 中有序 chunk hashes 生成正式 file hash

#### Scenario: 零字节上传

- **WHEN** session 的 chunk_count 为 0
- **THEN** complete SHALL 发布空文件并返回 `99aa06d3014798d86001c324468d497f`

### Requirement: create 和 complete 的已知 hash 使用 generation CAS

create、complete 以及任何 overwrite 发布 SHALL 在同一业务流程中使旧 hash generation 失效，并以 CAS 写入新 inode 的已知 hash。旧 worker 持有旧文件描述符时，其延迟提交 SHALL NOT 覆盖新发布结果。

#### Scenario: overwrite 与旧 worker 竞争

- **WHEN** worker 正在计算旧正式文件而 complete overwrite 发布新文件
- **THEN** overwrite SHALL bump generation
- **AND** 旧 worker 的 submit SHALL 因 generation 不匹配被丢弃

### Requirement: principal hash namespace generation 提供固定成本失效

每个 principal 的正式 hash namespace SHALL 具有单调递增的 `namespace_generation`。每条正式 hash record 和 calculation claim SHALL 捕获创建时的 generation；捕获值与当前值不同时，服务 SHALL NOT 将该 record 作为 fresh 或 stale hash 返回，也 SHALL NOT 接受该 claim 的计算提交。move 和 delete SHALL 在尝试文件系统 mutation 之前推进一次当前 principal generation；该操作的 Redis 命令数量 SHALL 不随 source、destination、目录 descendant 或已索引 hash record 数量增长，且服务 SHALL NOT 为 move/delete 枚举 hash path index 或文件树。

#### Scenario: move 目录前推进 generation

- **WHEN** move 请求准备对目录执行普通 rename
- **THEN** 服务 SHALL 在 rename 之前推进 principal 的 `namespace_generation`
- **AND** SHALL NOT 枚举 source 或 destination subtree 的 hash record

#### Scenario: delete 前 generation 推进失败

- **WHEN** delete 在文件系统 mutation 前无法成功推进 principal 的 `namespace_generation`
- **THEN** 服务 SHALL 不尝试删除 target
- **AND** Redis 故障 SHALL 按 fatal dependency 处理

#### Scenario: 文件系统 mutation 最终失败

- **WHEN** generation 已推进但后续 rename 或单节点移除失败
- **THEN** 该 principal 的旧 generation hash SHALL 继续保持失效
- **AND** 服务 SHALL NOT 回滚 generation

#### Scenario: generation 推进后的旧 worker 提交

- **WHEN** worker 持有早于当前 principal generation 的 calculation claim
- **THEN** Redis SHALL 原子拒绝其提交

### Requirement: Redis incarnation 变化后正式 hash 不得沿用

正式 hash record 和 calculation claim SHALL 绑定创建时的 Redis incarnation。Redis 进程重启或故障切换导致 incarnation 变化后，Qtserver SHALL 将 AOF 恢复的正式 hash record 和 calculation claim 视为可重建的 cache miss，SHALL NOT 仅凭已恢复的 generation 和 fingerprint 返回旧 hash；上传 session 等非 hash 控制状态不受本要求改变。

#### Scenario: Redis AOF 恢复旧 hash record

- **WHEN** Redis 重启后从 AOF 恢复正式 hash record，且当前 Redis incarnation 与 record 捕获值不同
- **THEN** Qtserver SHALL 不返回该 hash
- **AND** SHALL 从当前正式文件事实重新建立 pending 状态

#### Scenario: Redis 未重启但 Qtserver 重启

- **WHEN** Qtserver 重启而 Redis incarnation 保持不变
- **THEN** generation 和 fingerprint 仍匹配的正式 hash record MAY 按原有 fresh 或 stale 规则继续使用

### Requirement: 文件管理 mutation 主动失效 hash

create 和 complete SHALL 对受影响 logical path 主动更新 object generation 并失效或写入 hash record。move 和 delete SHALL 在文件系统 mutation 前推进 principal 的 `namespace_generation`，使该 principal 下先前 generation 的全部正式 hash record 和 calculation claim 失效；它们 SHALL NOT 逐 path 或逐 subtree 清理 record。move SHALL NOT 把 source hash 记录迁移到 destination；destination 第一次需要 hash 时 SHALL 根据当前文件事实重新使用或建立计算状态。

#### Scenario: move 文件

- **WHEN** `/a` 准备移动为 `/b`
- **THEN** principal 的 `namespace_generation` SHALL 在 rename 前推进
- **AND** `/b` SHALL NOT 直接继承 `/a` 的记录

#### Scenario: 删除文件

- **WHEN** 正式文件准备被删除
- **THEN** principal 的旧 generation 正式 hash 状态 SHALL 在单节点移除前失效

#### Scenario: 移动目录

- **WHEN** `/dir` 准备移动为 `/new-dir`
- **THEN** `/dir` 和 `/new-dir` subtree 的旧 generation record SHALL 因 principal generation 不匹配而不可命中
- **AND** 服务 SHALL NOT 枚举任一 subtree 的 object key

#### Scenario: mutation 失败造成保守失效

- **WHEN** generation 已推进但 move 或 delete 的文件系统操作失败
- **THEN** 该 principal 的其他 hash record MAY 在后续访问时重新验证或计算

### Requirement: fresh 和 stale hash 使用 stale-while-revalidate

fingerprint、namespace generation 和 Redis incarnation 校验匹配且 hash 年龄不超过 `file_hash_revalidate_seconds` 时 SHALL 直接返回 fresh hash。超过该时长且记录仍存在、旧 hash 可用时 SHALL 立即返回现有 hash 并 best-effort 安排后台刷新；普通下载 SHALL NOT 等待刷新。retention SHALL 只决定后台清理资格，不构成返回旧 hash 的严格到期边界。

#### Scenario: hash 已到 revalidate 时间

- **WHEN** 请求命中 fingerprint 相同的过期 hash
- **THEN** 服务 SHALL 返回旧值
- **AND** SHALL 原子地将记录置为或保留为 pending refresh

#### Scenario: refresh notification queue 已满

- **WHEN** stale hash 已可返回但内存 notification queue 已满
- **THEN** 请求 SHALL 仍成功
- **AND** worker SHALL 通过 Redis pending 索引最终发现工作

### Requirement: 首次计算使用 202 轮询

fingerprint 当前但没有可用 hash 时，请求 SHALL 在 Redis 建立或保留 pending 状态，并返回 HTTP 202 `HASH_PENDING` 和 `Retry-After: 5`；SHALL NOT 在长 HTTP 请求内同步扫描完整正式文件。普通 download 不要求 hash 时 SHALL 正常传输。

#### Scenario: init 检查同大小正式目标

- **WHEN** overwrite=false、目标 size 相同但正式 hash 尚不可用
- **THEN** init SHALL 返回 202 `HASH_PENDING` 与 Retry-After 5

#### Scenario: 普通文件正在计算 hash

- **WHEN** 客户端只请求普通下载而 hash 状态是 pending
- **THEN** 下载 SHALL 不等待 hash worker

### Requirement: failed 状态由后续访问触发重试

worker 失败 SHALL 保存 failed、error、retry_count 和 next_retry_at。达到 next_retry_at 前，存在旧 hash 时 SHALL 返回旧值；没有旧 hash时 SHALL 返回 HTTP 503 `HASH_UNAVAILABLE`。达到时间后的首次访问 SHALL CAS 置为 pending并返回旧值或 202。

#### Scenario: refresh 失败但旧值存在

- **WHEN** failed 记录仍保存 fingerprint 匹配的旧 hash
- **THEN** 请求 SHALL 返回旧 hash

#### Scenario: 首次计算失败

- **WHEN** failed 记录没有可用旧 hash且尚未到重试时间
- **THEN** 请求 SHALL 返回 503 `HASH_UNAVAILABLE`

#### Scenario: retry 时间已到

- **WHEN** 新访问发生在 next_retry_at 之后
- **THEN** 服务 SHALL best-effort 将记录置为 pending
- **AND** 没有旧 hash 的请求 SHALL 返回 202

### Requirement: 服务外并发修改不提供额外稳定性保证

本 change SHALL 信任运维很少在 worker 扫描中修改正式目录。worker MAY 对一次打开的文件完成计算并用 generation CAS 提交，但 SHALL NOT 为服务外并发原地写增加计算前后 fingerprint 重试、全文件锁或 `FILE_CHANGED_DURING_HASH` 协议。

#### Scenario: 运维在 hash scan 中修改文件

- **WHEN** 服务外程序在 worker 读取期间修改同一正式 inode
- **THEN** 结果 MAY 反映弱一致性读取
- **AND** Qtserver SHALL NOT 因此定义新的客户端错误或自动暂停 qtransc

### Requirement: Redis hash cache 仍须核对 fingerprint

Redis hash record SHALL 包含 hash、algorithm、version、fingerprint、calculated_at、object generation、principal `namespace_generation` 和 Redis incarnation。cache hit 时 Qtserver SHALL 重新 stat 并比较 fingerprint，并验证 namespace generation 和 Redis incarnation；任一验证不匹配 SHALL 禁止返回该 hash。全部验证匹配后，记录超过 revalidate 时间 SHALL 按 stale-while-revalidate 处理，包括 retention 清理期限已到但记录尚未被删除的情况。记录已被清理或没有可用 hash 时 SHALL 按首次计算及失败重试契约处理。

#### Scenario: cache entry 对应旧 fingerprint

- **WHEN** Redis 命中但当前 ctime、mtime 或 size 不同
- **THEN** 服务 SHALL 丢弃 cache hit 并原子失效旧 object generation

#### Scenario: cache entry 对应旧 namespace generation

- **WHEN** Redis record 的 `namespace_generation` 与 principal 当前值不同
- **THEN** 服务 SHALL 不把该 record 作为 fresh 或 stale hash 返回
- **AND** SHALL 根据当前正式文件事实重新建立计算状态

#### Scenario: cache entry 对应旧 Redis incarnation

- **WHEN** Redis record 捕获的 incarnation 与当前 Redis 进程不同
- **THEN** 服务 SHALL 不返回该 hash

### Requirement: Redis 是正式 hash 的可重建缓存和协调状态源

Redis SHALL 保存 hash、fingerprint、`idle|pending|calculating|failed` 状态、calculation_id、object generation、principal `namespace_generation`、Redis incarnation、started/heartbeat、error/retry 和 next_retry_at。正式文件系统 SHALL 是内容事实源；Redis hash 状态丢失、被后台清理、incarnation 过时或被明确失效时，Qtserver SHALL 从当前文件事实重新建立计算状态，SHALL NOT 要求从其他数据库恢复历史 hash。

#### Scenario: Qtserver 重启时存在 pending

- **WHEN** Qtserver 重启且 Redis incarnation 未变化，并存在尚未被清理的 pending 记录
- **THEN** workers SHALL 继续从 Redis 领取这些记录
- **AND** 不得依赖重启前的内存 notification queue

#### Scenario: Redis 重启时存在 pending

- **WHEN** Redis AOF 恢复的 pending 记录绑定旧 Redis incarnation
- **THEN** workers SHALL NOT 继续旧 calculation claim
- **AND** 后续请求 SHALL 从当前正式文件事实重新建立 pending 状态

#### Scenario: hash cache 丢失

- **WHEN** 正式文件存在但 Redis 不存在可用 hash record
- **THEN** 服务 SHALL 建立 pending 状态并按首次计算协议返回

#### Scenario: 已知 hash 写入未进入 AOF

- **WHEN** Redis 重启后的 AOF 不包含最近 create 或 complete 写入的已知 hash
- **THEN** 正式文件 SHALL 保持有效
- **AND** 后续 hash 请求 SHALL 按 cache miss 重新计算

### Requirement: workers 通过 Redis queue lease 和 heartbeat 协调

workers SHALL 每五秒从 Redis 的持久 pending 索引以原子操作领取到期 record。calculating worker SHALL 每五秒更新 heartbeat 和 lease；超过 30 秒无 heartbeat 的 record MAY 由另一 worker 以新的 calculation_id 原子接管。领取、续租、接管、失败退避和提交 SHALL 使用 Redis 原子命令或 Lua script 完成，并使用 Redis server time 判断到期。提交 SHALL 同时验证 calculation_id、object generation、principal `namespace_generation` 和 Redis incarnation。默认 `hash_worker_count=2`、`hash_queue_size=1000`，两者 SHALL 大于 0。`file_hash_revalidate_seconds` SHALL 默认 86400 且必须大于 0。

#### Scenario: worker 进程退出

- **WHEN** calculating record 超过 30 秒未更新 heartbeat
- **THEN** 另一健康实例 SHALL 能以新 calculation_id 原子接管并重新计算

#### Scenario: 必需计算 notification queue 已满

- **WHEN** 无 hash 请求创建 pending 但内存 notification queue 已满
- **THEN** pending SHALL 保留在 Redis 持久索引
- **AND** 请求 SHALL 继续返回 202 而不是丢失工作

#### Scenario: 旧 worker 延迟提交

- **WHEN** record 已被接管，或 object generation、principal `namespace_generation`、Redis incarnation 任一已变化
- **THEN** 旧 calculation_id 的提交 SHALL 被原子拒绝

### Requirement: 非活跃 hash cache 按滑动 retention 后台清理

`file_hash_retention_seconds` SHALL 默认 2592000、必须大于 `file_hash_revalidate_seconds`，并表示 hash 记录的滑动闲置清理期限。成功读取、计算、领取或 heartbeat SHALL best-effort 续期；后台 SHALL 根据该期限清理长期未访问且未被续期的记录。清理期限到达 SHALL NOT 要求查询立即丢弃仍存在且通过校验的 hash；该记录 MAY 继续按 fresh/stale 规则返回并续期。记录删除后的首次访问 SHALL 重新建立计算状态。Redis SHALL 使用 `maxmemory-policy=noeviction`，不得以 maxmemory eviction 静默移除上传控制状态。

#### Scenario: 文件长期未访问

- **WHEN** hash 记录超过 retention 且没有活动计算，后台清理已经删除该记录
- **THEN** 下一次请求 SHALL 作为首次计算处理

#### Scenario: 清理期限已到但记录仍存在

- **WHEN** hash 记录已到 retention 清理期限但尚未被删除，且 fingerprint、namespace generation 和 Redis incarnation 校验匹配
- **THEN** 请求 MAY 按现有 fresh/stale 规则返回可用 hash 并续期
- **AND** SHALL NOT 仅因清理期限已到强制返回 202

#### Scenario: stale hash 仍在 retention 内

- **WHEN** fingerprint 匹配、hash 超过 revalidate 时间但记录尚未超过 retention
- **THEN** 服务 SHALL 继续按 stale-while-revalidate 返回旧值

#### Scenario: Redis 达到内存上限

- **WHEN** `noeviction` 下 Redis 拒绝写入而不是淘汰 key
- **THEN** Qtserver SHALL 将该 Redis 命令错误按 fatal dependency 处理
- **AND** SHALL NOT 静默丢弃 session 或 hash 协调状态

### Requirement: Redis 故障不使用同步 hash fallback

Redis 是 fatal dependency。运行期连接、协议或写入级故障 SHALL 触发 Qtserver graceful shutdown；服务 SHALL NOT 改为请求内同步扫描、只关闭 hash capability 或继续普通文件接口。

#### Scenario: verify 时 Redis 断开

- **WHEN** file verify 查询 Redis 时发生连接级故障
- **THEN** 请求 SHALL 返回 500 `INTERNAL_ERROR`（若仍可响应）
- **AND** Qtserver SHALL 触发 graceful shutdown
