# qtransc-serve-api-contract Specification

## Purpose

定义 qtransc `serve` 对 Agent 暴露的 HTTP 与 SSE 线协议，使调用方能够仅依据统一数字码和固定信封判断结果，并明确一次性字段迁移、安全文案及旧协议兼容边界。

## Requirements

### Requirement: serve 路由集合保持稳定

qtransc `serve` SHALL 暴露配置查询、token 更新、健康检查、v1 与 v2 任务创建、删除、详情、摘要、启动、暂停和列表共 11 个 JSON 接口，以及一个 SSE 事件接口。配置查询 SHALL 使用 `GET /api/v1/conf`，v2 创建 SHALL 使用 `POST /api/v2/tasks`；既有接口的 HTTP method 与 path SHALL 保持不变。v1 创建格式、CLI 与旧 WebSocket SHALL 保持兼容。两种创建入口 SHALL 共享任务 ID 空间、接纳容量、查询、控制和 SSE。

#### Scenario: 调用既有详情接口

- **WHEN** 调用方请求 `GET /api/v1/tasks/:task_id/detail`
- **THEN** qtransc SHALL 继续按该 method 与 path 返回任务详情，包括通过 v2 创建的任务

#### Scenario: 订阅既有事件接口

- **WHEN** 调用方请求 `GET /api/v1/events`
- **THEN** qtransc SHALL 建立 SSE 事件流并包含两种入口创建的任务

#### Scenario: 查询服务配置

- **WHEN** 调用方通过鉴权并请求 `GET /api/v1/conf`
- **THEN** qtransc SHALL 返回当前服务的任务限制和默认传输参数

### Requirement: JSON 业务响应使用统一信封和 HTTP 200

serve JSON SHALL 使用 `{code,message,data?,meta?}` 和 HTTP 200。成功 SHALL 为 `0/Success` 并省略顶层 meta；失败 SHALL 使用注册表 API 请求类错误，携带两个显式布尔 meta 字段并省略 data。无载荷 SHALL 省略 data，空列表 SHALL 为 data:[]。

#### Scenario: 无载荷成功

- **WHEN** token 更新、启动、暂停或删除请求成功
- **THEN** SHALL 返回 0/Success，省略 data 和 meta

#### Scenario: 业务失败

- **WHEN** API 请求失败
- **THEN** SHALL 返回请求类错误及固定 message/meta，HTTP 为 200 且无 data

#### Scenario: 空任务列表

- **WHEN** 查询没有任务的列表
- **THEN** SHALL 返回 code=0 和 data:[]

### Requirement: 协议旁路错误使用统一 JSON

控制面鉴权失败、未知路由、错误 HTTP method 以及响应尚未提交时恢复的 panic SHALL 使用统一 JSON 信封和 HTTP `200`。CORS `OPTIONS` SHALL 继续返回 `204`；HTTP 解析失败、连接中断、无响应和响应提交后的中断 SHALL 作为传输层失败，不要求生成 JSON。

#### Scenario: 控制面密钥错误

- **WHEN** 受保护接口收到缺失或不匹配的 server secret
- **THEN** qtransc SHALL 返回 HTTP `200`
- **AND** body SHALL 使用规范注册表中“访问拒绝”条目的完整 code、message 和 meta

#### Scenario: 未知路由

- **WHEN** 请求没有匹配的公开路由或 method
- **THEN** qtransc SHALL 返回 HTTP `200`
- **AND** body SHALL 使用规范注册表中“请求无效”条目的完整 code、message 和 meta

#### Scenario: CORS 预检

- **WHEN** 请求 method 为 `OPTIONS`
- **THEN** qtransc SHALL 返回 HTTP `204`
- **AND** SHALL NOT 输出 JSON 业务信封

#### Scenario: 响应提交前 panic

- **WHEN** handler 在写入响应前发生 panic
- **THEN** qtransc SHALL 返回 HTTP `200`
- **AND** body SHALL 使用规范注册表指定的未分类内部错误条目

### Requirement: HTTP JSON 字段使用严格 lowerCamelCase

serve 的 HTTP 请求体与响应字段 SHALL 全部使用 lowerCamelCase。日志关联字段 SHALL 使用 `taskPid`，`transfering_files` SHALL 修正为 `transferringFiles`。JSON body SHALL 恰好包含一个符合目标 schema 的对象；未知字段、旧 snake_case、旧 `taskpid`、错误类型、`null` 顶层值和第二个 JSON 值 SHALL 使用规范注册表的“请求无效”条目拒绝。

#### Scenario: 驼峰创建请求

- **WHEN** 创建请求使用 `taskId`、`taskPid`、`enterpriseId`、`callerVersion`、`serverAddr`、`fileList` 等 lowerCamelCase 字段并满足校验规则
- **THEN** qtransc SHALL 按该请求创建任务

#### Scenario: 旧 taskpid 字段被拒绝

- **WHEN** 创建请求携带旧字段 `taskpid`
- **THEN** qtransc SHALL 返回规范注册表的“请求无效”条目

#### Scenario: 旧字段被拒绝

- **WHEN** 创建请求携带 `task_id`、`server_addr`、`file_list` 或其他旧 snake_case 字段
- **THEN** qtransc SHALL 返回规范注册表的“请求无效”条目

#### Scenario: 多个 JSON 值

- **WHEN** body 在合法请求对象后还包含第二个 JSON 值
- **THEN** qtransc SHALL 返回规范注册表的“请求无效”条目

### Requirement: serve wire 不输出字符串原因码

serve wire SHALL NOT 输出 reasonCode 或 reason_code。任务摘要、详情、列表和创建返回值中的 error SHALL 为可选对象 `{code,message,meta}`，文件视图 SHALL 使用相同错误结构。失败任务 SHALL 携带当前执行错误，其余任务状态 SHALL 省略 error；成功查询的 HTTP 外层 SHALL 为 0/Success。原有非错误业务字段 SHALL 保留。

#### Scenario: 查询失败任务

- **WHEN** 成功查询失败任务
- **THEN** 外层 SHALL 为 code=0，task.error SHALL 包含与对应失败 SSE 相同的执行码、message 和 meta

#### Scenario: 查询失败文件

- **WHEN** 文件最终失败
- **THEN** file.error SHALL 为执行错误对象，原有上传文件 message SHALL 与 error.message 一致

#### Scenario: 查询正常或暂停任务

- **WHEN** 任务 pending、running、completed 或主动 stopped
- **THEN** task.error SHALL 省略

### Requirement: pending 查询隐藏上一轮错误但保留展示数据

HTTP 任务查询 SHALL 在 `pending` 状态隐藏上一轮任务级错误，并隐藏上一轮文件级 `error` 及仅用于表达该错误的 `message`；Task 内部 SHALL 继续保留这些错误直到下一次 Run。`pending` SHALL 继续返回上一轮保留的进度、文件信息及执行时间，调用方 SHALL 以 `status` 判断任务当前是否正在传输。该规则 SHALL 同样适用于创建响应、列表、摘要和详情，不得只处理详情。

#### Scenario: Retry 后 pending 查询

- **WHEN** 一个 failed 任务经 Retry 进入 pending，且内部仍保留上一轮错误和文件错误
- **THEN** HTTP task.error SHALL 省略
- **AND** file.error SHALL 省略，仅表达该旧错误的 message SHALL 省略
- **AND** 进度、文件完成标记及时间字段 MAY 继续显示上一轮值

#### Scenario: pending 状态 SSE

- **WHEN** Retry 被接受并发布 pending 任务状态事件
- **THEN** SSE SHALL 使用成功信封且不携带上一轮执行错误
- **AND** SHALL NOT 发布伪造归零的进度

### Requirement: 错误码遵循唯一规范注册表

`qtransc/docs/qtransc-error-codes.md` SHALL 是 qtransc `serve` 五位错误码的唯一规范源。code、默认 message、`retryable`、`visible`、适用对象、研发触发条件和未登记错误的归一规则 SHALL 以该注册表为准；本 OpenSpec SHALL 只定义信封、分类机制和其他协议行为，不得维护第二份完整码表。OpenSpec 或代码与注册表冲突时 SHALL 修正 OpenSpec 或代码，调用方 SHALL NOT 解析 message 决定业务行为。

#### Scenario: 认证配置无效

- **WHEN** qtransc 识别出传输认证配置无效
- **THEN** SHALL 输出规范注册表中研发触发条件覆盖该情况的完整条目

#### Scenario: 任务容量耗尽

- **WHEN** qtransc 无法接受更多运行或排队任务
- **THEN** SHALL 输出规范注册表中研发触发条件覆盖该情况的完整条目

#### Scenario: 本地资源不存在

- **WHEN** qtransc 识别出本地源文件或目录不存在
- **THEN** SHALL 输出规范注册表中研发触发条件覆盖该情况的完整条目

#### Scenario: 未分类错误

- **WHEN** qtransc 无法把错误安全归入其他稳定语义
- **THEN** SHALL 输出规范注册表指定的未分类内部错误条目

### Requirement: 错误出现位置与任务终态遵循规范注册表

HTTP 顶层失败 SHALL 只使用 API 请求码；SSE 失败和 HTTP 任务、文件 error SHALL 只使用执行码。任务因执行故障终止 SHALL 为 failed，明确停止 SHALL 为 stopped 且无任务错误；内部重试 SHALL 保持 running。注册表预留码 SHALL NOT 输出。

#### Scenario: HTTP API 专用错误

- **WHEN** API 请求被拒绝
- **THEN** HTTP 顶层 SHALL 使用请求类错误

#### Scenario: 文件失败后任务失败

- **WHEN** 源文件变化或完整性校验最终失败
- **THEN** 文件及任务失败事件 SHALL 使用相应执行错误，任务终态 SHALL 为 failed

#### Scenario: 预留错误码

- **WHEN** 错误码标记为预留
- **THEN** 当前实现 SHALL NOT 输出该码

### Requirement: 失败处置元数据固定随码

每个 HTTP 或 SSE 失败信封 SHALL 携带 `meta.retryable` 与 `meta.visible`，其值 SHALL 与规范注册表对应条目完全一致。handler 和事件转换 SHALL NOT 临时覆盖登记值。

#### Scenario: 容量错误携带登记元数据

- **WHEN** qtransc 输出规范注册表中的任务容量错误
- **THEN** meta SHALL 与该条目的 `retryable` 和 `visible` 完全一致

#### Scenario: 不可自动重试的内部错误

- **WHEN** qtransc 输出规范注册表指定的未分类内部错误
- **THEN** meta SHALL 与该条目的 `retryable` 和 `visible` 完全一致

### Requirement: 重复任务 ID 始终冲突

同一 `serve` 进程中只要 `taskId` 对应任务尚未删除，再次创建 SHALL 返回规范注册表中的“任务已存在”条目，不得按请求内容推断幂等成功。任务已成功入队但响应丢失时，使用同一 `taskId` 重试也 SHALL 返回冲突。

#### Scenario: 完全相同的重复请求

- **WHEN** 调用方用一个尚未删除的 `taskId` 重发相同创建请求
- **THEN** qtransc SHALL 返回规范注册表中的“任务已存在”完整条目

#### Scenario: 入队前失败

- **WHEN** 任务因容量不足或入队失败而未被接受
- **THEN** qtransc SHALL NOT 保留该任务 ID
- **AND** 后续相同 `taskId` 请求 SHALL NOT 因前一次失败返回“任务已存在”条目

### Requirement: 未登记失败码归一为内部错误

失败构造 SHALL 按请求或执行类别校验登记。成功码、未登记、非法、预留或跨类别码 SHALL 归一为对应类别的内部兜底完整条目。

#### Scenario: 未登记错误码

- **WHEN** 使用未登记值构造失败
- **THEN** SHALL 使用所在类别的兜底 code/message/meta

#### Scenario: 跨类别错误

- **WHEN** 请求失败构造器收到执行码或反之
- **THEN** SHALL 归一为目标类别的兜底条目

### Requirement: SSE 使用统一结果信封

每条 SSE data JSON SHALL 为 `{messageType,code,message,data,meta?}`，前四项必填。正常事件 SHALL 为 0/Success 且无 meta；失败任务或文件事件 SHALL 携带执行错误及固定 meta。data SHALL 使用 lowerCamelCase，且 SHALL NOT 重复包含 error 或字符串原因码。

#### Scenario: 任务失败事件

- **WHEN** 已接受任务因执行故障终止
- **THEN** SHALL 发布 qtrans.task.status、status=failed 和对应执行错误

#### Scenario: 查询失败任务恢复错误

- **WHEN** 调用方错过失败 SSE 后成功查询仍在内存中的任务
- **THEN** HTTP 外层 SHALL 为 code=0，data.error SHALL 返回该任务当前执行错误

#### Scenario: 正常文件进度

- **WHEN** 发布文件进度
- **THEN** SHALL 使用 qtrans.file.progress、0/Success，省略 meta，data SHALL 保留 taskId、fileKey、total、transferred、rate

#### Scenario: 心跳事件

- **WHEN** 连接建立或心跳周期到期
- **THEN** SHALL 使用 qtrans.health.heartbeat、0/Success，timestamp SHALL 保持 RFC3339

### Requirement: 综合 API 文档链接规范注册表

综合 `qtransc-apis.md` SHALL 只说明信封规则、HTTP 与 SSE 的观察差异并链接唯一规范源 `qtransc/docs/qtransc-error-codes.md`，不得复制完整码表。请求和执行错误的普通顺序编号、预留及固定兜底分配、后续追加与发布后稳定性 SHALL 遵循该注册表的号码选取规则；分类器 SHALL 显式映射两类错误，不得通过加减固定数值推导。规范注册表 SHALL NOT 包含“调用方处置”列；任何码值、message、meta、适用对象或研发触发条件变化 SHALL 先修订并批准规范注册表，再同步 OpenSpec 与代码。

#### Scenario: 调用方查找错误码

- **WHEN** 调用方从综合 API 文档查找 QTrans 错误码定义
- **THEN** 文档 SHALL 指向独立错误码注册表
- **AND** 综合 API 文档 SHALL NOT 维护第二份完整码表

#### Scenario: 调整编号保持错误含义

- **WHEN** 按批准的注册表调整错误码编号
- **THEN** HTTP、SSE 和查询错误对象 SHALL 使用新的集中登记值
- **AND** 该错误的 message、meta、适用对象和触发条件 SHALL 保持注册表定义，API 示例 SHALL 使用相同新编号

### Requirement: SSE 事件类型使用 qtrans 点分词汇

SSE messageType SHALL 限定为 `qtrans.health.heartbeat`、`qtrans.task.status`、`qtrans.task.delete`、`qtrans.file.status`、`qtrans.chunk.status`、`qtrans.task.progress`、`qtrans.file.progress` 和 `qtrans.chunk.progress`。旧 `heartbeat`、`task_status` 等值 SHALL 不再出现在 wire 中。

#### Scenario: 分片进度事件

- **WHEN** qtransc 发布分片进度
- **THEN** messageType SHALL 为 `qtrans.chunk.progress`
- **AND** data SHALL 使用 `chunkIndex` 和 `transferred`

### Requirement: SSE 与 HTTP 使用统一任务状态枚举

`qtrans.task.status.data.status` SHALL 与 HTTP 任务 summary/detail 的 `status` 使用同一组 `pending`、`running`、`completed`、`stopped`、`failed` 枚举。SSE SHALL NOT 使用 `created`、`started` 或 `paused` 作为任务状态。任务删除不是任务状态，SHALL 使用 `messageType="qtrans.task.delete"`，其 data SHALL 只携带 `taskId`，不得包含 `status`。

#### Scenario: 新任务进入调度队列

- **WHEN** 一个新任务被调度器接受并处于 HTTP `status="pending"`
- **THEN** SSE SHALL 发布 `messageType="qtrans.task.status"`
- **AND** data.status SHALL 为 `pending`

#### Scenario: 任务开始运行

- **WHEN** 任务的 HTTP 状态变为 `running`
- **THEN** 对应 SSE task status SHALL 为 `running`
- **AND** SHALL NOT 为 `started`

#### Scenario: 任务被暂停

- **WHEN** 任务的 HTTP 状态变为 `stopped`
- **THEN** 对应 SSE task status SHALL 为 `stopped`
- **AND** SHALL NOT 为 `paused`

#### Scenario: 任务被删除

- **WHEN** 调用方成功删除任务
- **THEN** SSE SHALL 发布 `messageType="qtrans.task.delete"`、`code=0`、`message="Success"`
- **AND** data SHALL 只包含 `taskId`

#### Scenario: completed 后重新排队

- **WHEN** 一个 completed 任务经 `/start` 被接纳
- **THEN** SSE SHALL 允许出现 `completed → pending → running` 的任务状态序列
- **AND** `completed → pending` SHALL 只由 Retry 发布一次 pending 事件

### Requirement: 非 serve 协议保持不变

本变更 SHALL NOT 改变 qtransc CLI 的错误格式、qtransc 与 Qtserver 的请求响应字段、upload2/download2 旧 WebSocket 帧或业务日志 schema。内部可以继续使用字符串原因码，但 SHALL NOT 将其泄露到 serve wire。

#### Scenario: 旧 WebSocket 查询进度

- **WHEN** upload2 或 download2 收到 `query-progress`
- **THEN** 响应字段、状态码和关闭语义 SHALL 与 `legacy-websocket-protocol` 保持一致

#### Scenario: Qtserver 结构化错误

- **WHEN** qtransc 内部解析 Qtserver 的 `reason_code`
- **THEN** SHALL 继续按 Qtserver 协议读取该字段
- **AND** SHALL NOT 因 serve wire 改造而要求 Qtserver 改名

### Requirement: 停止、重启与故障按执行轮次处理

任务最终错误 SHALL 采用首个记录的最终非取消错误，并保留各文件错误。已确认故障 SHALL 优先于后续停止。重启前轮次未释放 SHALL 拒绝；接受重启 SHALL 只把终态改回 `pending`，保留上一轮错误、进度、文件信息及执行时间，下一次 Run 成功接受后才初始化本轮数据并清除旧错误；拒绝 SHALL 保留原快照。`completed`、`stopped` 和 `failed` 均可通过 `/start` 重新排队。无停止意图的意外取消或未完成提前返回 SHALL failed。

#### Scenario: 故障后收到暂停

- **WHEN** 最终执行故障已记录，随后收到停止或清理取消
- **THEN** 任务 SHALL 保留 failed 及原故障

#### Scenario: 重启源文件变化任务

- **WHEN** 未启用 `autoRetry` 的原上传任务因源文件变化要求新建任务，调用方仍启动原任务
- **THEN** SHALL 返回请求状态冲突，保留原执行错误

#### Scenario: 自动重排源文件变化任务

- **WHEN** 启用 `autoRetry` 的上传任务因源文件变化结束一轮执行
- **THEN** SHALL 保留客户端 taskId，并在下一轮使用新的服务端执行 ID、重新读取的源文件指纹和哈希
- **AND** SHALL NOT 恢复变化文件的旧上传会话

#### Scenario: completed 后重新启动

- **WHEN** 一个 `completed` 任务收到 `/start` 且旧执行已结算、接纳容量可用
- **THEN** SHALL 接纳为 `pending` 并保留上一轮展示数据
- **AND** 下一次 Run SHALL 重新检查源和目标，目标已被删除时重新传输

#### Scenario: pending 任务被主动暂停

- **WHEN** 一个 `pending` 任务收到 `/pause`
- **THEN** SHALL 转为 `stopped` 并退出等待队列
- **AND** SHALL NOT 进入 `failed`，也不产生执行退出通知

#### Scenario: 执行准备错误

- **WHEN** 任务已被 Run 接受，随后能力预检、文件规划或网络初始化失败
- **THEN** SHALL 转为 `failed` 并保存本轮执行错误

### Requirement: serve 正常关闭先停止全部活动任务

正常关闭 SHALL 先禁止创建、启动和自动重排，并使用注册表的关闭条目拒绝创建或启动请求，再逐个停止 pending/running 任务并等待执行退出及完成通知结算。已有终态 SHALL 保留，最终故障 SHALL 优先。每轮任务 SHALL 在协程和必要清理收敛后提交终态并关闭自己的传输池。完成任务收尾和终态发布后 SHALL 关闭调度循环、SSE、HTTP 及日志。停止阶段 SHALL NOT 新增强杀期限，HTTP 收尾 SHALL 沿用五秒期限。

#### Scenario: 正常停服

- **WHEN** 收到正常退出信号
- **THEN** SHALL 先逐个 stop 活动任务，再结束服务，主动停止任务 SHALL stopped 且无 error

#### Scenario: 关闭期间创建或启动

- **WHEN** 服务已进入关闭阶段且收到创建或启动请求
- **THEN** SHALL 返回注册表的请求类关闭条目，不接受新执行

### Requirement: 创建任务的请求校验与执行准备分离

serve 创建请求 SHALL 显式提供 taskId，trim 后 SHALL 非空且最多 128 字节；缺失、空白、null 或错误类型 SHALL 使用注册表的请求无效条目拒绝。serve SHALL NOT 为调用方申请 task ID。接受前 SHALL 只校验请求格式、字段及路径语法、认证配置、显式 fileList 项数和任务接收条件。显式 fileList 超过 100000 项 SHALL 返回请求类文件数量超限错误且不登记任务。

能力协商、本地文件存在性和可访问性、单文件大小、目录展开及下游可用性和远端鉴权检查 SHALL 在任务被接受后执行。预检属于 running 执行准备阶段，SHALL 绑定该轮任务 context，按既有期限与重试策略执行，并响应主动停止。最终预检错误 SHALL 使任务 failed 并保存执行错误；HTTP 创建成功的外层 SHALL 保持 0/Success，即使响应快照已经观察到 failed。CLI 同步预检及 Qtserver taskid endpoint SHALL 保持原契约。

#### Scenario: 缺少 taskId

- **WHEN** 创建请求缺失 taskId、值为空白或不符合字段类型要求
- **THEN** SHALL 返回注册表的请求无效条目，不创建任务且不访问 Qtserver

#### Scenario: 显式列表超限

- **WHEN** 请求 fileList 有 100001 项
- **THEN** SHALL 在入队前返回请求类文件数量超限错误，且不保留任务 ID

#### Scenario: 本地文件或服务端能力预检失败

- **WHEN** 合法创建请求已被接受，执行准备发现上传源不存在、单文件超限、能力不可用或下游不可达
- **THEN** 任务 SHALL failed 并保存对应执行错误
- **AND** 成功的创建和后续查询响应外层 SHALL 保持 0/Success，SSE SHALL 在顶层给出执行错误

#### Scenario: 目录展开后数量超限

- **WHEN** 显式列表未超限，但任务执行规划展开后的普通文件超过上限
- **THEN** 任务 SHALL failed 并保存执行类文件数量超限错误，不得开始部分内容传输

#### Scenario: 预检期间主动暂停

- **WHEN** 任务在能力预检期间收到主动停止且未确认最终执行故障
- **THEN** SHALL 取消预检，任务 SHALL stopped 且无任务 error

### Requirement: serve 创建任务的 bearerToken 按请求隔离

`POST /api/v1/tasks` SHALL 将 `bearerToken` 限定为该任务的请求级凭据。字段缺失或 trim 后为空时，下载 SHALL 使用 anonymous 且不发送 Authorization，上传 SHALL 使用 `user-file-space` 规定的固定 anonymous 写 token；字段非空时，任务 SHALL 在整个生命周期固定使用 trim 后的请求值。进程级 static token 的已有值或后续更新 SHALL NOT 改变这些选择，认证失败 SHALL NOT 回退 anonymous 或其他进程级凭据。

#### Scenario: 未提供 token 的下载任务

- **WHEN** 调用方创建下载任务且省略 `bearerToken`，或其值 trim 后为空
- **THEN** qtransc SHALL 按 anonymous 下载语义执行
- **AND** 下游下载请求 SHALL NOT 携带 Authorization

#### Scenario: 未提供 token 的上传任务

- **WHEN** 调用方创建上传任务且省略 `bearerToken`，或其值 trim 后为空
- **THEN** qtransc SHALL 自动使用 `user-file-space` 规定的固定 anonymous 写 token
- **AND** 调用方 SHALL NOT 被要求提供该固定 token

#### Scenario: 创建任务时显式提供 token

- **WHEN** 调用方创建上传或下载任务并提供 trim 后非空的 `bearerToken`
- **THEN** qtransc SHALL 在该任务整个生命周期固定使用该请求值
- **AND** SHALL NOT 因进程级 static token 已存在或发生更新而改变任务凭据

#### Scenario: 显式 token 鉴权失败

- **WHEN** 使用显式 `bearerToken` 的任务收到下游 401 或其他鉴权失败
- **THEN** qtransc SHALL 按该显式凭据报告鉴权失败
- **AND** SHALL NOT 将任务凭据替换为 anonymous 或进程级凭据后重试

#### Scenario: 预先配置进程级 token 后创建无 token 任务

- **WHEN** 调用方先成功调用 `POST /api/v1/conf/token`，随后创建省略 `bearerToken` 的任务
- **THEN** 新任务 SHALL 仍按对应上传或下载的 anonymous 语义执行

#### Scenario: 任务运行期间更新进程级 token

- **WHEN** 一个 HTTP 创建的任务正在运行，调用方成功调用 `POST /api/v1/conf/token`
- **THEN** 该任务后续请求使用的凭据 SHALL 保持不变

#### Scenario: 非 serve 凭据生命周期保持不变

- **WHEN** CLI 使用用户名密码刷新凭据，或旧 WebSocket 按 `legacy-websocket-protocol` 处理 `update-token`
- **THEN** SHALL 继续遵守各自既有的凭据刷新和热更新契约
- **AND** SHALL NOT 套用 serve HTTP 任务的请求级隔离规则

### Requirement: 并发改造保持任务接口兼容

未提供并发覆盖字段时，连接池容量和普通文件并发 SHALL 从 serve 启动配置取得。创建任务 SHALL 接受可选的 connections、streams、transfers，且 SHALL NOT 引入 P。任务详情 fileConcurrency SHALL 继续表示普通文件并发上限；HTTP 原有字段、SSE 字段、状态枚举及错误结构 SHALL 保持现有契约。旧请求 SHALL 不要求迁移，创建响应和详情 SHALL 追加生效配置字段。

#### Scenario: 调用方继续使用已有请求

- **WHEN** 调用方以现有合法请求创建任务并订阅 SSE
- **THEN** 请求 SHALL 继续被接受，响应 SHALL 保留既有字段并追加生效配置，事件 SHALL 保持既有结构
- **AND** 普通分片操作 SHALL 按任务共享额度并行执行

### Requirement: 创建任务按字段覆盖传输默认值

POST /api/v1/tasks SHALL 接受可选整数 connections、streams、transfers，分别表示每轮任务每个 origin 的连接上限、每连接请求上限及普通文件并发上限。每个缺失字段 SHALL 继承服务默认值；transport 缺失或 trim 后为空 SHALL 保留继承语义。显式合法值 SHALL 覆盖对应默认值而不影响其他字段。启动默认值 SHALL NOT 充当请求覆盖值的上限。最终配置 SHALL 在接受任务前固定，暂停再启动 SHALL 沿用此配置，同时重建独占池与分片额度。

#### Scenario: 全部使用默认值

- **WHEN** 请求未提供四项传输设置，且服务使用内置默认值
- **THEN** 任务 SHALL 使用 v3、connections=10、streams=1、transfers=5

#### Scenario: 部分覆盖

- **WHEN** 服务默认 v2、connections=3、streams=4、transfers=5，请求只提供 connections=8
- **THEN** 任务 SHALL 使用 v2、connections=8、streams=4、transfers=5
- **AND** 该覆盖 SHALL NOT 改变其他任务或服务默认值

#### Scenario: 暂停后重新启动

- **WHEN** 调用方暂停一个使用显式覆盖值的任务，随后启动同一任务
- **THEN** 任务 SHALL 继续使用创建时确定的配置且使用新的执行资源

### Requirement: 传输覆盖值在入队前严格校验

connections SHALL 是 1..1024 整数；v2/v3 的 streams SHALL 是 1..1024 整数；transfers SHALL 是 Go int 可表示的正整数。已传入的数字字段 SHALL 拒绝 null、字符串、布尔值、数组、对象、小数形式和溢出值；零与负数 SHALL NOT 被解释为缺省。无效值或协议与 streams 的冲突 SHALL 在入队、登记 taskId 或访问 Qtserver 前返回现有请求无效错误，HTTP 信封及错误码注册表 SHALL 保持不变。

#### Scenario: 数字字段显式无效

- **WHEN** 任一新增字段为 null、0、负数、字符串或小数，或 connections/streams 大于 1024
- **THEN** API SHALL 返回请求无效错误，不创建任务且不访问 Qtserver

#### Scenario: 拒绝后修正重试

- **WHEN** 调用方修正无效并发值并重新提交同一 taskId，且该 ID 未被其他请求使用
- **THEN** 请求 SHALL 不因前一次参数拒绝而返回任务已存在

### Requirement: 创建响应和详情回显生效配置

成功创建响应及上传、下载任务详情 SHALL 返回 transport、connections、streams，并用已有 fileConcurrency 返回生效的 transfers。返回值 SHALL 表示合并及校验后的任务配置上限，而非当前实际活跃连接、流或文件数。该信息 SHALL 在 pending 阶段可用，停止及完成后 SHALL 保留。响应 SHALL NOT 另增 transfers 同义字段，任务摘要和 SSE SHALL 不新增配置字段；旧 WebSocket JSON SHALL 保持不变。

#### Scenario: 查询排队任务

- **WHEN** 合法任务已接受但尚未开始执行
- **THEN** 创建响应及详情 SHALL 返回该任务完整生效配置，且 SHALL NOT 为获取这些字段提前建池

#### Scenario: 请求 HTTP1 且未提供 streams

- **WHEN** 服务默认 streams=8，任务选择 v1 且省略 streams
- **THEN** 创建响应和后续详情 SHALL 返回 transport=v1、streams=1

#### Scenario: 详情文件并发字段兼容

- **WHEN** 上传或下载请求提供 transfers=3
- **THEN** 创建响应及详情 SHALL 返回 fileConcurrency=3 并保留其他既有字段

### Requirement: 创建任务设置聚合传输限速

POST /api/v1/tasks SHALL 接受可选字段 `limitRateBytesPerSec`，为 int64 可表示的正整数，单位 bytes/s。省略 SHALL 表示不限速；显式零、负数、null、字符串、布尔值、小数和溢出值 SHALL 在登记或入队前使用既有请求无效错误拒绝。上传和下载 SHALL 共享直接传输限速的任务级聚合 payload 语义：该任务的全部并发文件、chunk、连接和 stream 共享一个额度，重传内容再次计入额度。配置 SHALL 在任务创建时固定，同一任务暂停后启动、失败后手动启动或自动重排 SHALL 保留限速值，不得继承其他任务的额度。

#### Scenario: 并发上传或下载限速

- **WHEN** 创建任务携带 `limitRateBytesPerSec=1048576`，且有多个并发文件或分片
- **THEN** 该任务 SHALL 共享每秒 1048576 payload bytes 的持续额度，允许既有有界 burst，不能按并发数倍增

#### Scenario: 限速任务重新启动

- **WHEN** 一个已接受的限速任务结束本轮并再次启动
- **THEN** 新执行 SHALL 使用创建时的限速值和新的任务限速器

#### Scenario: 拒绝无效限速

- **WHEN** 请求显式携带非正整数、null 或溢出的限速值
- **THEN** SHALL 拒绝请求，不登记 taskId，不访问 Qtserver

### Requirement: 创建任务可选择无限次失败重排

POST /api/v1/tasks SHALL 接受可选布尔字段 `autoRetry`，省略或 false SHALL 保持手动重启行为；null 及非布尔类型 SHALL 在登记任务前被拒绝。true SHALL 对全部任务执行失败启动新一轮，不按错误类型或 retryable 筛选，不设次数上限。该策略 SHALL 只适用于当前 serve 进程内的已接受任务，不重试创建请求校验失败，不改变单轮 HTTP 操作的既有重试与恢复规则。

#### Scenario: 启用无限次失败重排

- **WHEN** 已接受任务设置 autoRetry=true，执行再次失败且未被主动停止
- **THEN** SHALL 继续自动重排，不因已重试次数或错误的 retryable=false 停止

#### Scenario: 没有进入 failed 的 HTTP 恢复循环

- **WHEN** 当前一轮仍在 HTTP 可用性恢复循环中
- **THEN** SHALL 沿用该操作现有策略，不额外提交同一任务的新执行

### Requirement: 自动重排按一秒周期检查

每个 TaskManager SHALL 使用一个专用协程，以 1 秒为周期串行检查自动重排任务，不并发执行多次扫描。周期 SHALL 从扫描协程启动时计算，不表示每次失败后固定等待 1 秒，也不保证失败后 1 秒内启动。每次扫描 SHALL 对每个候选最多尝试启动一次；启动失败 SHALL 保留后续检查资格，并继续检查其他候选，服务关闭时除外。后续扫描 SHALL 再次判断资格，不依赖任务结束或容量变化通知。服务关闭 SHALL 停止自动接纳，并在管理器 context 取消后退出扫描协程。

#### Scenario: 失败后等待周期检查

- **WHEN** 启用 autoRetry 的任务在两次扫描之间失败并完成收尾
- **THEN** SHALL 在后续扫描中尝试启动，不在失败回调中立即启动

#### Scenario: 单次启动失败不终止扫描

- **WHEN** 扫描中的一个候选启动失败，且服务未关闭
- **THEN** SHALL 继续检查其他候选，并在后续扫描中重新判断该任务的资格

### Requirement: 自动重排按当前状态与容量接纳

自动重排 SHALL 使用与手动 start 相同的任务启动流程，保持同一 taskId 和创建配置，并创建新的执行 context。每轮 SHALL 先发布原失败及错误，待执行资源释放后再接纳新一轮。成功接纳 SHALL 只把状态改为 pending 并加入队尾，保留旧错误；旧错误 SHALL 在下一次 Run 初始化时清除。容量不足 SHALL 保留 failed、原错误及重排资格。失败信息 SHALL 使用既有日志和 SSE 发布，不增加无界内存历史。

每次扫描的候选 SHALL 仅包含当前仍登记、创建时启用 autoRetry、未被主动中止重排、状态为 failed 且旧执行及停止等待者均已释放的任务。已接纳任务 SHALL NOT 因后续扫描而被重复提交。容量不足或旧执行仍在收尾时 SHALL 等待后续周期检查，不得在同次扫描中忙循环。

#### Scenario: 单槽位任务失败

- **WHEN** maxTotal=1 且唯一任务启用 autoRetry 后执行失败
- **THEN** SHALL 在旧槽位释放后的周期检查中接纳下一轮，不因先前槽位尚未释放而丢失重排资格

#### Scenario: 扫描时旧执行仍在收尾

- **WHEN** 启用 autoRetry 的任务已 failed，但扫描时旧执行尚未释放
- **THEN** SHALL 暂不接纳新一轮，并保留原错误
- **AND** 后续扫描 SHALL 再次检查该任务，旧执行已释放且容量可用时接纳新一轮

#### Scenario: 后续扫描遇到已接纳任务

- **WHEN** 失败任务的新一轮已被接纳，后续扫描再次检查该任务
- **THEN** SHALL 根据其 pending/running 状态及当前执行记录跳过它，不得重复提交同一轮

### Requirement: 自动重排按本轮失败时间确定顺序

同一次扫描选出的候选 SHALL 按上一轮失败的 finishedAt 从早到晚尝试接纳；finishedAt 相同时 SHALL 按 taskId 字典序升序处理，不得依赖无序遍历。自动重排 SHALL 加入正常队尾并服从容量限制。容量不足时尚未接纳的候选 SHALL 保留 failed 及原错误，等待后续周期检查。同一任务新一轮再次失败 SHALL 按该轮新的 finishedAt 参与后续扫描，不沿用旧轮的优先顺序。

#### Scenario: 多个失败任务竞争空位

- **WHEN** 同次检查发现多个可重排任务，但容量只允许接纳其中部分
- **THEN** SHALL 按各任务上一轮的 finishedAt 从早到晚接纳，相同时按 taskId 字典序升序处理
- **AND** 剩余任务 SHALL 保留 failed 及原错误，等待后续周期检查

#### Scenario: 重新执行后再次失败

- **WHEN** 一个任务已重新执行并再次失败，且另一个任务仍在等待重排
- **THEN** SHALL 使用两者当前失败轮次的 finishedAt 决定下一次接纳顺序

### Requirement: 自动重排服从显式停止和任务身份

成功完成、主动暂停/停止、删除任务及关闭服务 SHALL 中止自动重排。pause SHALL 也接受已 failed 但自动重排尚未中止的任务，撤销重排意图并保留原错误。成功手动 start SHALL 重新启用创建时的 autoRetry 策略。候选判断与接纳 SHALL 与手动 start、pause 和 delete 协调，避免重复提交或使用过期任务身份。调用方 SHALL 按生命周期调用协议避免重复结算一次退出通知，也 SHALL NOT 把旧执行的通知用于同 ID 的另一任务；本规范不要求实现额外的 runID 或迟到回调过滤机制。

#### Scenario: 等待队列容量时暂停

- **WHEN** failed 任务等待自动重排的可用容量，调用方 pause
- **THEN** SHALL 成功撤销重排意图，保留 failed 及原错误，后续周期检查不得重启它

#### Scenario: 停止与失败回调竞争

- **WHEN** 调用方 pause 与任务失败收尾并发发生
- **THEN** SHALL 在停止调用退出前阻止新一轮执行，并让明确停止意图中止自动重排

#### Scenario: 手动重新启动

- **WHEN** autoRetry 任务被暂停且已释放，随后手动 start 被接受
- **THEN** SHALL 恢复自动重排策略，后续失败继续参与周期检查

### Requirement: 配置查询只返回任务限制和生效默认值

`GET /api/v1/conf` SHALL 使用 HTTP 200 和既有成功信封，省略顶层 meta。data SHALL 只包含 limits 和 defaults；limits SHALL 包含整数 maxConcurrentTasks、maxAdmittedTasks；defaults SHALL 直接包含字符串 transport 及整数 connections、streams、fileConcurrency，不增加传输参数分组层级。字段 SHALL 使用 lowerCamelCase 且全部返回。响应 SHALL NOT 包含凭据、本地路径、实时占用、剩余容量或其他配置字段。

#### Scenario: 使用内置默认配置

- **WHEN** 服务使用当前内置配置且配置查询成功
- **THEN** 响应 SHALL 为 code=0、message="Success"
- **AND** data.limits SHALL 为 maxConcurrentTasks=10、maxAdmittedTasks=64
- **AND** data.defaults SHALL 为 transport="v3"、connections=10、streams=1、fileConcurrency=5
- **AND** SHALL NOT 返回未约定字段

#### Scenario: 启动时覆盖默认传输参数

- **WHEN** 配置文件和显式启动参数按既有优先级合并、校验后的默认值为 v2、connections=3、streams=4、transfers=7
- **THEN** 配置查询 SHALL 返回 transport="v2"、connections=3、streams=4、fileConcurrency=7
- **AND** SHALL NOT 返回被覆盖的内置默认值

### Requirement: 配置查询区分接纳上限和任务默认参数

maxConcurrentTasks SHALL 表示同时占用执行名额的任务数上限；maxAdmittedTasks SHALL 表示排队任务与尚未结算执行的总接纳上限，不统计已经释放名额的终态任务记录。两项 SHALL 返回服务实际使用的限制，SHALL NOT 随任务占用变化。defaults SHALL 表示未指定任务参数时使用的服务默认值，SHALL NOT 作为请求覆盖值的上限。

#### Scenario: 任务执行和结算改变占用

- **WHEN** 任务创建、排队、执行或结算改变当前占用
- **THEN** 配置查询 SHALL 仍返回相同的配置上限和服务默认值
- **AND** SHALL NOT 从任务数量推导新的限制或返回剩余容量

#### Scenario: 单任务覆盖默认值

- **WHEN** 一个合法任务指定大于服务默认值的 connections 或 transfers
- **THEN** SHALL 按既有任务参数规则接纳
- **AND** 配置查询 SHALL 继续返回服务默认值，而非该任务的覆盖值

### Requirement: 配置查询沿用控制面鉴权且保持只读

配置查询 SHALL 遵守既有受保护接口的 server secret 鉴权规则及失败信封。查询 SHALL 只读取本地配置，SHALL NOT 访问 Qtserver、创建连接池或执行 context、改变任务或调度状态。服务正常关闭期间，只要 HTTP 仍可用且鉴权成功，配置查询 SHALL 继续成功，不因停止接纳任务而返回关闭错误。

#### Scenario: 配置了控制面密钥

- **WHEN** 服务配置 server secret，调用方未提供或提供了不匹配的 Bearer 密钥
- **THEN** 配置查询 SHALL 返回既有访问拒绝条目的完整信封，HTTP SHALL 为 200
- **AND** SHALL NOT 返回 data

#### Scenario: 未配置控制面密钥

- **WHEN** 服务未配置 server secret，调用方请求配置查询
- **THEN** SHALL 按既有未启用鉴权的规则成功返回配置

#### Scenario: 下游不可用

- **WHEN** Qtserver 不可用，调用方通过鉴权并查询配置
- **THEN** 配置查询 SHALL 仍成功，且不发起任何下游请求或创建执行资源

#### Scenario: 服务正在正常关闭

- **WHEN** 服务已停止接纳任务，但 HTTP 仍可用，调用方通过鉴权并查询配置
- **THEN** SHALL 继续返回原配置，不改变关闭流程

### Requirement: v2 创建使用源与目标目录配对

POST /api/v2/tasks SHALL 接受非空 pathMappings 数组，每项仅接受非空字符串 src、dst。dst SHALL 始终表示目录。新入口 SHALL 拒绝 fileList、sourceDir、targetDir、dirPaths 和旧文件字段。其余公共字段、严格 JSON、认证隔离、配置继承、接纳和响应信封 SHALL 沿用 v1。入队前 SHALL 仅进行语法及接纳检查；能力、源类型、重复映射与展开检查 SHALL 在 running 执行。

#### Scenario: 混用旧路径字段

- **WHEN** v2 请求同时携带 pathMappings 和 fileList
- **THEN** SHALL 拒绝请求且不登记任务

#### Scenario: 上传与下载的路径方向

- **WHEN** mode 为 upload 或 download
- **THEN** upload 的 src SHALL 是本地绝对路径、dst 是远端逻辑绝对目录；download SHALL 相反
- **AND** SHALL 拒绝源根目录、通配符、非法逻辑路径；允许目标根目录并保留根路径

### Requirement: v2 服务地址接受主机和可选端口

v2 serverAddr SHALL 仅接受域名或 IP 及可选端口，IPv6 SHALL 使用方括号。省略端口时 SHALL 使用 23500；显式端口 SHALL 是 1..65535 的十进制整数。SHALL 拒绝 scheme、路径、userinfo、query、fragment、空的显式端口和无效端口。transport SHALL 决定网络传输配置。

#### Scenario: 使用 URL 前缀

- **WHEN** serverAddr 为 https://qt.example.com:8443
- **THEN** SHALL 在入队前返回请求无效

#### Scenario: 合法地址

- **WHEN** serverAddr 为 qt.example.com:8443 或 [2001:db8::1]:8443
- **THEN** SHALL 接受地址语法并使用已有 TLS 传输实现

#### Scenario: 省略端口

- **WHEN** serverAddr 为 qt.example.com、192.0.2.10 或 [2001:db8::1]
- **THEN** SHALL 分别使用 qt.example.com:23500、192.0.2.10:23500 或 [2001:db8::1]:23500

#### Scenario: 显式端口无效

- **WHEN** serverAddr 为 qt.example.com:、qt.example.com:0 或 qt.example.com:65536
- **THEN** SHALL 在入队前返回请求无效，不以默认端口替代

### Requirement: v2 文件记录以最终目标路径标识

v2 任务详情 SHALL 返回 pathMappings，并通过 fileList 展示完整文件计划，不再使用旧任务的 readyFiles/authorizedFiles 分类列表。已规划文件的详情和摘要 SHALL 增加 src、dst，dst 为最终文件完整路径。最终目标文件路径 SHALL 在同一任务内唯一，并在后续执行中保持稳定；SHALL 不增加独立 fileId 字段。文件及分片事件的 fileKey SHALL 等于该记录的完整 dst，不移除前导斜杠。调用方 SHALL 使用 taskId 与 fileKey 关联具体任务中的文件。旧任务的字段与事件身份 SHALL 保持原契约。

#### Scenario: 同源多份副本

- **WHEN** 同一远端文件复制到两个本地目录
- **THEN** 查询 SHALL 返回两条拥有不同 dst 的记录，事件 SHALL 使用对应的完整目标文件路径分别关联

#### Scenario: 多个文件共用目标目录

- **WHEN** 两个源文件 a.txt、b.txt 的请求 dst 均为 /backup
- **THEN** 展开后的目标 /backup/a.txt、/backup/b.txt SHALL 分别作为文件标识；SHALL 不把请求中的目标目录当作文件标识
