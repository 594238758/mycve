# versioned-https-transports Specification

## Purpose
定义 qtransc 如何以稳定的版本化 transport 名称选择 HTTP/1.1、HTTP/2 或 HTTP/3，并确保 URL、协议协商、参数校验和旧配置迁移具有一致且可验证的行为。

## Requirements

### Requirement: 版本化 transport 集合

qtransc SHALL 使用 `v1`、`v2`、`v3` 三个用户可见规范 transport 值，并 SHALL 在未提供默认配置且 transport 为空时规范化为 `v3`；serve 任务的空值 SHALL 使用服务启动时的默认 transport。三种模式的 server URL SHALL 均为包含 scheme 和 host 的绝对 `https://` URL；transport 名称 SHALL NOT 被解释为 URL scheme。

#### Scenario: transport 为空

- **WHEN** CLI 或未提供默认配置的内部公开入口收到空 transport
- **THEN** qtransc SHALL 使用 `v3`，并在持久化、日志或响应中需要输出 transport 时使用规范值 `v3`

#### Scenario: 使用三个合法模式

- **WHEN** 调用者提供 `v1`、`v2` 或 `v3`，且 server URL 是合法绝对 `https://` URL
- **THEN** qtransc SHALL 接受该 transport 与 URL 组合

#### Scenario: 兼容已有 transport 名称

- **WHEN** CLI、配置文件或任务请求提供 `https`、`https2` 或 `https3`
- **THEN** qtransc SHALL 分别规范化为 `v1`、`v2` 或 `v3`，并保留原有传输行为
- **AND** 帮助、合法值提示、任务持久化、日志和响应 SHALL 使用规范名称，不再将兼容输入名列为可选项

#### Scenario: 使用非 HTTPS URL

- **WHEN** 任一合法 transport 搭配 `http://`、相对 URL 或缺少 host 的 URL
- **THEN** qtransc SHALL 在发起网络请求前拒绝该输入

#### Scenario: 使用旧 transport

- **WHEN** 调用者提供 `quic`、`http` 或其他未定义 transport
- **THEN** qtransc SHALL 在发起网络请求前拒绝该输入，并 SHALL 在错误中列出 `v1`、`v2`、`v3` 三个合法值

### Requirement: transport 固定选择 HTTP 版本

`v1` SHALL 只使用 HTTP/1.1 over TLS over TCP；`v2` SHALL 只使用 HTTP/2 over TLS over TCP；`v3` SHALL 只使用 HTTP/3 over QUIC over UDP。qtransc SHALL NOT 在三个 transport 之间自动协商、回退或升级。

#### Scenario: v1 连接支持 HTTP/1.1

- **WHEN** `v1` 与服务端完成 TLS 握手，且服务端选择 `http/1.1` ALPN 或未返回 ALPN 并接受 HTTP/1.1
- **THEN** qtransc SHALL 使用 HTTP/1.1 发送请求，并 SHALL NOT 提议或切换到 `h2`

#### Scenario: v1 服务端不能使用 HTTP/1.1

- **WHEN** `v1` 无法建立可承载 HTTP/1.1 的 TLS/TCP 连接
- **THEN** qtransc SHALL 返回连接或协议错误，并 SHALL NOT 改用 `v2` 或 `v3`

#### Scenario: v2 成功协商 h2

- **WHEN** `v2` 的 TLS ALPN 协商结果为 `h2`
- **THEN** qtransc SHALL 在该 TLS/TCP 连接上使用 HTTP/2

#### Scenario: v2 未协商到 h2

- **WHEN** `v2` 的服务端未选择 `h2`、只支持 HTTP/1.1 或 TLS ALPN 结果不是 `h2`
- **THEN** qtransc SHALL 在发送 HTTP 请求前使连接失败，并 SHALL NOT 回退到 HTTP/1.1

#### Scenario: v3 协商 h3

- **WHEN** `v3` 建立 QUIC 连接
- **THEN** qtransc SHALL 使用 `h3` ALPN 和 HTTP/3，并 SHALL NOT 改用 TCP、HTTP/2 或 HTTP/1.1

#### Scenario: v3 不可用

- **WHEN** UDP、QUIC、TLS 握手或 `h3` 协商失败
- **THEN** qtransc SHALL 返回对应连接或协议错误，并 SHALL NOT 自动回退到 `v2` 或 `v1`

### Requirement: transport 参数严格校验

`connections` SHALL 对所有 transport 为 `1..1024` 范围内的整数。`v1` 的 `streams` SHALL 等于 1；`v2` 和 `v3` 的 `streams` SHALL 为 `1..1024` 范围内的整数。只影响 QUIC 的参数 SHALL 仅适用于 `v3`。无效组合 SHALL 在连接池创建或网络访问之前失败，而 SHALL NOT 被静默修正。任何 `connections * streams` 派生计算 SHALL 在两个操作数分别通过范围校验之后执行，使每个 origin 的最大配置本地容量不超过 1,048,576 且计算不会发生整数溢出。

#### Scenario: v1 配置多个 streams

- **WHEN** 调用者为 `v1` 配置 `streams` 大于 1
- **THEN** qtransc SHALL 返回参数错误，而 SHALL NOT 把它静默压缩为 1

#### Scenario: 容量参数超出范围

- **WHEN** `connections` 小于 1 或大于 1024，或 `v2`、`v3` 的 `streams` 小于 1 或大于 1024
- **THEN** qtransc SHALL 在建连前返回参数错误

#### Scenario: 校验后计算总容量

- **WHEN** qtransc 需要根据 `connections` 与 `streams` 派生每个 origin 的本地总容量
- **THEN** qtransc SHALL 先分别完成范围校验再执行乘法，且有效输入得到的结果 SHALL NOT 大于 1,048,576

#### Scenario: QUIC 专属参数用于 TCP transport

- **WHEN** 调用者把 QUIC receive window 等 QUIC 专属参数用于 `v1` 或 `v2`
- **THEN** qtransc SHALL 在建连前返回参数错误

#### Scenario: serve 按任务 transport 创建池

- **WHEN** qtransc serve 启动时校验并保存默认 transport、connections 和 streams，任务开始执行
- **THEN** 该轮任务 SHALL 按创建时合并并校验的任务配置创建独占池；`v1` SHALL 使用每连接容量 1，`v2` 与 `v3` SHALL 使用请求覆盖值或继承的默认值

#### Scenario: HTTP1 任务未提供 streams

- **WHEN** serve 请求的最终 transport 为 v1 且未提供 streams，即使服务默认 streams 大于 1
- **THEN** 任务 SHALL 使用 streams=1

#### Scenario: HTTP1 任务显式覆盖 streams

- **WHEN** serve 请求的最终 transport 为 v1 且显式提供 streams
- **THEN** 只有整数 1 SHALL 被接受，其他值 SHALL 在创建任务前被拒绝

### Requirement: 所有入口使用同一 transport 语义

前台命令、qtransc serve 任务 API、`upload2`、`download2`、文件管理命令和内部任务模型 SHALL 使用同一组规范 transport 值和协议映射。固定使用 HTTP/3 的兼容入口 SHALL 输出并使用 `v3`，而 SHALL NOT 继续生成 `quic`。

#### Scenario: API 创建未指定 transport 的任务

- **WHEN** qtransc serve 收到未提供 transport 的合法任务
- **THEN** 任务 SHALL 使用并保存服务启动时的默认 transport；服务未配置 transport 时 SHALL 使用 `v3`

#### Scenario: 兼容命令创建 HTTP/3 任务

- **WHEN** `upload2` 或 `download2` 构造其固定 HTTP/3 任务
- **THEN** 任务中的 transport SHALL 是 `v3`

#### Scenario: 不同入口收到旧值

- **WHEN** 任一入口收到 `quic` 或 `http`
- **THEN** 该入口 SHALL 按自身既有输入错误映射拒绝请求，且 SHALL NOT 将旧值静默转换为新值

### Requirement: v3 保持既有 HTTP3 生命周期契约

把用户可见名称从 `https3` 改为 `v3` SHALL NOT 改变既有 HTTP/3 物理连接硬上限、stream 硬上限、GOAWAY 排空、连接替换、UDP 资源关闭和安全协议层重试行为；这些行为 SHALL 继续遵守 `http3-transport-lifecycle` capability。

#### Scenario: v3 连接收到 GOAWAY

- **WHEN** `v3` 连接收到 GOAWAY，且替代连接需要等待物理连接名额
- **THEN** qtransc SHALL 继续按既有 HTTP/3 生命周期等待、排空和安全替换，而 SHALL NOT 因 transport 改名放宽连接或 stream 上限

### Requirement: CLI 统一传输参数与默认值

qtransc serve SHALL 使用 Cobra 的正常参数解析，并直接继承根命令的 `--transport`、`--connections`、`--streams`、`--transfers`。四项内置默认值 SHALL 分别为 `v3`、10、1、5。serve SHALL NOT 再接受 `--transports` 或 `--streamspertransport`。serve 的配置优先级 SHALL 为显式命令行参数、engine.toml、内置默认值；既有连接和流配置文件键 SHALL 保留。文件并发 SHALL 是正整数，无效配置 SHALL 在服务启动和创建连接池前失败。

#### Scenario: 未配置传输参数

- **WHEN** serve 没有显式传输参数且 engine.toml 没有对应配置
- **THEN** 新任务 SHALL 默认使用 v3、10 个连接、每连接 1 个流、5 个普通文件并发

#### Scenario: 根参数位于子命令前后

- **WHEN** 调用者将四项根参数放在 serve 子命令之前或之后
- **THEN** Cobra SHALL 正常解析并使用相同设置，帮助输出 SHALL 显示继承的参数及统一默认值

#### Scenario: 命令行覆盖配置文件

- **WHEN** engine.toml 包含历史连接或流配置键，且调用者提供对应的 --connections 或 --streams
- **THEN** serve SHALL 使用显式命令行值；未提供对应参数时 SHALL 使用配置文件值

#### Scenario: 旧 serve 参数名称

- **WHEN** 调用者提供 --transports 或 --streamspertransport
- **THEN** Cobra SHALL 拒绝未知参数，而 SHALL NOT 静默忽略或建立别名
