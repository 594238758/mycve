# client-transfer-concurrency Specification

## Purpose
定义 qtransc 如何把文件和分片的业务并发映射到按 origin 隔离的连接 lane 与本地请求容量，并在不自行实现 HTTP/2、HTTP/3 协议流量控制的前提下提供可取消背压和多连接传输能力。

## Requirements

### Requirement: 业务层约束文件并发和任务共享分片并发

qtransc SHALL 保留活动普通文件上限 F，并取消固定单文件分片并发 P。每轮任务的所有普通文件 SHALL 共享 N=C×S 个分片操作额度，HTTP/1.1 的 S SHALL 为 1。分片 SHALL 先取得额度再启动工作协程，直到该分片操作成功、失败或取消退出才归还额度；重试与退避期间 SHALL 继续持有额度。等待额度 SHALL 可取消且不消耗重试次数，不得为全部待传分片预建阻塞协程。文件之间不保证平均分配。

#### Scenario: 多文件并行分片传输

- **WHEN** C=3、S=3、F=3，多个普通文件包含足够多待传分片
- **THEN** 活动普通文件 SHALL 不超过 3，总活跃分片操作 SHALL 不超过 9
- **AND** 已完成操作释放的额度 SHALL 可被其他文件使用

#### Scenario: 单个文件包含大量分片

- **WHEN** C=3、S=3、F=3，但只有一个文件且待传分片充足
- **THEN** 该文件 SHALL 能使用全部 9 个分片额度
- **AND** 下载 SHALL 在首次注册响应头确认后继续填充剩余额度

#### Scenario: 退避和取消

- **WHEN** 分片在请求之间退避，或任务在等待额度时取消
- **THEN** 退避中的分片 SHALL 保留分片额度并释放已结束请求的网络名额
- **AND** 取消的等待 SHALL 退出且不泄漏额度

### Requirement: 网络层以连接 lane 和本地请求上限约束容量

qtransc SHALL 在每轮任务独占池内，为每个 transport 与规范化 origin 维护最多 `connections` 个相互独立的连接 lane。`streams` SHALL 表示一条 lane 同时准入的本地在途 HTTP 请求上限；`v1` 的该值 SHALL 固定为 1，`v2` 与 `v3` SHALL 使用有效配置值。每个请求从获准进入 lane 起，直到请求失败、无响应体请求完成、响应体读到 EOF 或响应体关闭期间 SHALL 占用一个本地名额。

`connections` 与 `streams` SHALL 仅定义客户端上限，不声明服务端实际连接或 stream 容量。连接 SHALL 按需建立；当业务需求和服务端能力足够时，qtransc SHALL 能将请求分散到多个 lane，使 `connections` 能形成多个独立物理连接，而 SHALL NOT 要求先耗尽第一条连接的对端 stream 容量后才使用其他 lane。

#### Scenario: 本地网络容量上限

- **WHEN** 一个 `v2` origin 配置 `connections=4`、`streams=8`
- **THEN** qtransc SHALL 为该 origin 维护最多 4 个连接 lane
- **AND** 每条 lane SHALL 最多准入 8 个本地在途请求
- **AND** 该 origin SHALL NOT 准入超过 32 个本地在途请求

#### Scenario: 多连接承载并发请求

- **WHEN** 至少有 `connections` 个并发请求、服务端接受相应连接且本地未受其他资源限制
- **THEN** qtransc SHALL 能让不同 lane 按需建立相互独立的物理连接并承载请求

#### Scenario: 响应体仍未消费完成

- **WHEN** 一个请求已收到响应头但响应体尚未读完或关闭
- **THEN** 该请求 SHALL 继续占用所在 lane 的一个本地请求名额

### Requirement: 本地容量不足形成可取消背压

当业务层可执行的分片操作数超过网络层本地容量时，超出部分 SHALL 等待 lane 名额，而 SHALL NOT 因容量不足被报告为传输失败。容量等待 SHALL NOT 增加业务重试次数或启动可用性错误退避；等待 SHALL 在名额释放后继续，并 SHALL 在任务 context 取消、显式总期限到达或网络池关闭时及时结束且不泄漏容量。

#### Scenario: 业务并发大于网络容量

- **WHEN** 文件与分片调度产生的可执行操作数大于 `connections * streams`
- **THEN** qtransc SHALL 只准入本地网络容量内的请求
- **AND** 其余操作 SHALL 等待容量释放而不计为失败尝试

#### Scenario: 容量等待期间取消任务

- **WHEN** 一个分片操作正在等待 lane 名额且任务 context 被取消
- **THEN** 该等待 SHALL 及时结束
- **AND** qtransc SHALL NOT 发送该请求或泄漏 lane 名额

### Requirement: 对端协议容量由所选传输协议约束

`v2` 的实际并发 HTTP/2 stream 数 SHALL NOT 超过对端发布的 `SETTINGS_MAX_CONCURRENT_STREAMS`，`v3` 的实际客户端请求 stream 数 SHALL NOT 超过对端授予的 QUIC stream credit。对端容量小于本地 `streams` 时，超出容量的请求 SHALL 在所选 transport 内等待或按协议保证安全的方式恢复，而 SHALL NOT 仅因该容量差异使文件或任务失败。qtransc SHALL NOT 通过额外业务探测请求猜测上述协议已明确发布的容量。

#### Scenario: HTTP2 服务端 stream 上限更小

- **WHEN** `v2` 的本地 `streams` 为 32，而服务端在一条连接上只允许 2 个并发 stream
- **THEN** 该连接实际同时活动的 HTTP/2 stream SHALL NOT 超过 2
- **AND** 其余已准入该 lane 的请求 SHALL 等待或由协议层安全恢复
- **AND** 任务 SHALL NOT 仅因该差异进入失败终态

#### Scenario: HTTP3 等待 stream credit

- **WHEN** `v3` 已用完对端允许的客户端双向 stream
- **THEN** 后续请求 SHALL 等待新的 QUIC stream credit 或其 context 结束
- **AND** qtransc SHALL NOT 把正常的 credit 等待计为一次失败重试

### Requirement: 最终网络错误释放容量并返回业务恢复

底层 transport 已完成其协议内安全处理后仍返回的网络错误 SHALL 结束当前请求尝试并释放对应 lane 名额。网络层 SHALL NOT 盲目重放无法证明未被处理的请求，也 SHALL NOT 要求业务层申请、持有或替换物理连接；业务层重新调度可恢复操作时 SHALL 重新获取网络容量，并 MAY 被分配到其他 lane。第一版 SHALL NOT 因单个 lane 的历史失败建立额外的持久熔断、健康探测或自适应并发状态。

对于 HTTP/2，lane 在发送请求前确认既有物理连接已经关闭或不可接受新 request stream 时，SHALL 淘汰该连接并在同一 lane 按需建立替代连接；因为请求尚未发送，该动作 SHALL NOT 计为重放。若连接错误与请求发送发生竞态且 transport 无法证明请求未发送，SHALL 按结果可能已产生处理，不得在网络层自动重放。

#### Scenario: 一条 lane 建连失败而其他 lane 可用

- **WHEN** 客户端配置的 lane 数大于服务端当前可接受的连接数，且一次请求最终收到建连或传输错误
- **THEN** qtransc SHALL 释放失败请求占用的本地容量并把结果交给业务恢复策略
- **AND** 其他可工作的 lane SHALL 能继续传输
- **AND** 可恢复操作的下一次尝试 SHALL NOT 被固定到原失败物理连接

#### Scenario: HTTP2请求发送前发现连接已关闭

- **WHEN** HTTP/2 lane 持有的既有连接已经关闭，且下一个请求尚未发送
- **THEN** qtransc SHALL 在该 lane 建立替代连接并发送该请求
- **AND** SHALL NOT 仅因旧连接关闭使任务失败

#### Scenario: 请求结果可能已经产生副作用

- **WHEN** transport 无法证明一个带请求体的操作尚未被服务端处理
- **THEN** 网络层 SHALL 返回该结果而不盲目重放请求
- **AND** 业务层 SHALL 按该操作的幂等或断点恢复契约决定后续动作

### Requirement: 小文件下载并发由网络 lane 独立约束

qtransc SHALL NOT 使用 `transfers` 限制 v2 小文件批次的并发数，也 SHALL NOT 让小文件批次占用普通大文件的文件并发名额。每个活动 v2 批次 SHALL 占用一个 HTTP 请求名额；本地最大活动批次数 SHALL 只受对应 origin 的可用 lane 容量以及本任务内其他共享该 origin 的在途请求约束，其中 `v1` 的容量为 `connections`，`v2` 和 `v3` 的客户端容量上限为 `connections * streams`，实际容量仍 SHALL 服从对端协议限制。

#### Scenario: transfers 小于可用 lane 数

- **WHEN** `transfers=1`，所选 transport 有 8 个可用请求 lane，且至少有 8 个已成形的小文件批次
- **THEN** qtransc SHALL 允许最多 8 个 v2 小文件批次同时传输
- **AND** SHALL NOT 因 `transfers=1` 把活动小文件批次限制为 1 个

#### Scenario: 小文件和大文件使用不同并发约束

- **WHEN** 小文件阶段已经收敛并进入普通大文件阶段
- **THEN** 普通大文件 SHALL 继续受 `transfers` 和任务共享分片额度规则约束
- **AND** 小文件阶段使用过的并发数 SHALL NOT 改变大文件并发上限

### Requirement: 小文件 worker 只在批次和 lane 同时就绪后启动

qtransc SHALL 先形成非空小文件批次，再以可取消方式申请一个空闲 lane；只有申请成功后才 SHALL 启动负责该批次请求和响应消费的 worker。等待 lane 的批次 SHALL 作为调度状态存在，而 SHALL NOT 预先创建一组阻塞等待 lane 的 worker。一次尝试完成或失败后 SHALL 先关闭响应体并释放 lane，再成功结束、进入退避队列、重新分批或形成终态失败；重试退避期间 SHALL NOT 占用 lane。

#### Scenario: 所有 lane 正忙

- **WHEN** 已有请求占满所选 origin 的全部本地 lane 容量且仍有已成形的小文件批次
- **THEN** 后续批次 SHALL 等待容量释放
- **AND** qtransc SHALL NOT 为这些等待批次预先启动阻塞 worker
- **AND** 容量等待 SHALL NOT 计为失败尝试

#### Scenario: 失败批次进入退避

- **WHEN** 一个 v2 批次尝试收到可重试结果并需要等待后再次尝试
- **THEN** 当前响应体 SHALL 被关闭且 lane SHALL 被释放
- **AND** 退避结束后的新尝试 SHALL 重新申请任意可用 lane

#### Scenario: 等待 lane 时取消任务

- **WHEN** 一个已成形批次正在等待 lane 且任务 context 被取消
- **THEN** 等待 SHALL 及时结束
- **AND** SHALL NOT 启动该批次 worker或泄漏 lane 名额

### Requirement: 小文件优化不隐式扩大配置

本变更 SHALL NOT 改变 `connections`、`streams` 或 `transfers` 的默认值。qtransc SHALL 将每个 v2 mini-tar 作为普通独立 HTTP 请求交给所选 transport，并 SHALL NOT 自行分配、固定或管理 HTTP/2、HTTP/3 stream ID。

#### Scenario: 用户保留默认 streams

- **WHEN** 用户未显式增大 `streams`
- **THEN** qtransc SHALL 使用现有默认值计算本地 lane 容量
- **AND** SHALL NOT 因启用 v2 小文件下载自动改写该配置

#### Scenario: HTTP2 多流映射

- **WHEN** qtransc 在 `v2` transport 上并发发起多个 v2 批次请求
- **THEN** 底层 transport SHALL 将请求映射到协议 stream
- **AND** 应用层 SHALL NOT 依赖特定 stream ID 或请求到物理连接的固定映射


### Requirement: 任务执行独占网络资源

每轮任务 SHALL 独占连接池；同任务控制请求和数据请求 SHALL 使用同一池，控制请求 SHALL NOT 再次申请分片额度。排队任务 SHALL 不创建池，且 SHALL NOT 持有独立执行 context。任务工作协程和必要清理结束后 SHALL 关闭池并提交终态，重启 SHALL 创建新池。serve SHALL 区分执行名额与接纳上限：执行名额限制同时 Run 的任务，接纳上限约束 pending 与尚未结算的执行；仅执行名额不足 SHALL 排队，整体接纳容量不足才拒绝。执行退出 SHALL 通过可靠内部通知归还名额，不得依赖可丢弃的 SSE 事件。CLI 预检客户端 SHALL 交给首轮执行，预执行失败 SHALL 关闭；若统一要求 pending Task 不持有连接，CLI 适配层 SHALL 在预检阶段持有并负责失败清理，不得改变 CLI 同步预检报错行为。独立文件命令和删除后清理 SHALL 在各自作用域结束时关闭短期池。容量不跨任务共享。

#### Scenario: 同地址的两个任务

- **WHEN** 两个任务使用相同 transport、origin、C 和 S
- **THEN** 两者 SHALL 各自拥有 C 个连接和 C×S 个请求容量上限
- **AND** 停止其中一个 SHALL 不关闭另一个的连接池

#### Scenario: 重启任务

- **WHEN** 任务旧执行资源仍在释放
- **THEN** 重启 SHALL 被拒绝；旧轮释放完成后的新轮 SHALL 使用新的池和分片额度

#### Scenario: 执行名额已满但仍有接纳容量

- **WHEN** 服务执行名额已满，但 pending 与尚未结算执行的总数仍低于接纳上限
- **THEN** 新任务或 `/start` SHALL 被接受并进入等待队列
- **AND** SHALL NOT 返回任务容量错误

#### Scenario: 执行退出后立即调度

- **WHEN** 一个执行名额通过任务退出通知释放，且等待队列中存在 pending 任务
- **THEN** 管理器 SHALL 立即按等待顺序调度可用名额
- **AND** 失败任务的自动重排 SHALL 仍由每秒扫描决定，不混同为立即重试
