# transfer-task-correlation Specification

## Purpose
定义 qtransc taskid 的生成和传播、taskpid 的日志关联与共现语义，并保留现有 download grant 的 taskid 绑定兼容契约。
## Requirements
### Requirement: taskid endpoint 独立生成关联标识

Qtserver SHALL 无认证且在健康运行时始终注册 `/qtserver/v1/taskid`。每次成功调用 SHALL 返回新的 UUID v4，且 SHALL NOT 创建上传、下载、Task 状态或其他业务资源，也 SHALL NOT 输出原始业务事件。

qtransc serve 创建 SHALL 要求调用方显式提供 taskId，且 SHALL NOT 因字段缺失自行申请 ID；缺失或空白值 SHALL 在请求阶段拒绝。直接 CLI 仍 MAY 按既有流程调用 taskid endpoint 取得新 ID。

同一个仍存在于qtransc进程内的task被再次start时 SHALL 继续使用该task保存的server task ID。Qtransc进程重启后由调用方使用新ID创建serve task，或CLI新进程在未显式提供原task ID时取得新ID，SHALL 被视为新task，并 SHALL 被日志视为新文件活动；本地download `.progress` SHALL 只恢复字节现场，不得自行恢复或猜测日志task ID。调用方需要显式跨进程延续同一文件活动时 SHALL 复用原task ID并保持路径、principal和action不变。Qtserver SHALL NOT 为跨进程合并task ID增加Task状态。

新task ID复用完整`.progress`且只执行整文件verify时 SHALL 形成新文件活动；其成功记录 SHALL 按`raw-business-event-log`输出零transmitted、零retry与null speed。复用原task ID并保持其余四元组字段时，旧chunk与新verify SHALL 属于同一file key完整历史。

#### Scenario: 申请 taskid

- **WHEN** 调用方或 qtransc 直接 CLI 调用 taskid endpoint
- **THEN** Qtserver SHALL 返回一个 UUID v4
- **AND** 该调用 SHALL NOT 改变文件或 session 状态
- **AND** SHALL NOT 输出 `task.registered` 或其他原始业务事件

#### Scenario: 同一内存task重新start

- **WHEN** qtransc在进程内对同一个已有task执行重新start
- **THEN** 后续文件请求 SHALL 继续使用该task原有server task ID

#### Scenario: 新进程只发现download progress

- **WHEN** 新qtransc CLI进程发现已有`.progress`但调用方没有提供原task ID
- **THEN** qtransc SHALL 使用新task ID并形成新的文件活动
- **AND** SHALL NOT 从progress路径、文件内容或服务端状态猜测原task ID

#### Scenario: serve 不自动申请 ID

- **WHEN** serve 创建请求未提供有效 taskId
- **THEN** qtransc SHALL 在请求阶段拒绝，不调用 taskid endpoint

### Requirement: qtransc 为上传和下载请求携带 X-Task-ID

qtransc SHALL 为同一个客户端 upload/download task 的 Qtserver 文件请求携带 `X-Task-ID`。Canonical upload session MAY 保存创建时收到的初始 task ID，但 SHALL 只把它用作不可变的日志关联值，不得用它参与 session ownership、业务幂等性、鉴权或签名。服务端 SHALL 把文件而不是客户端 task 作为日志主体；同一个客户端 task 中的多个文件 SHALL 分别产生文件活动。

Canonical upload session创建时的 task ID SHALL 固定为该文件活动的日志关联值。后续请求携带不同 `X-Task-ID` 恢复同一 principal拥有的session MAY 继续业务，但qtserver产生的chunk、verify和commit原始事件 SHALL 使用session保存的初始task ID及其`file_key`；当前请求的不同ID只可用于调试诊断。

#### Scenario: 恢复上传时重新创建 task

- **WHEN** qtransc 使用 SQLite 中的同一 session 恢复上传但当前 taskid 不同
- **THEN** Qtserver SHALL 按当前认证 principal 和 session 继续上传
- **AND** taskid 变化 SHALL NOT 使 session 失效
- **AND** 后续原始业务事件 SHALL 继续使用session创建时的task ID

#### Scenario: 第三方伪造 header

- **WHEN** 第三方请求携带任意受信任格式的 X-Task-ID
- **THEN** 该值 SHALL 只影响当前请求和文件日志关联
- **AND** SHALL NOT 扩大调用方权限或改变业务结果

### Requirement: 暂不新增 X-Task-ID 输入规则

Qtserver SHALL 保持当前 X-Task-ID 信任边界，本 change SHALL NOT 新增长度、字符集、截断或拒绝规则。qtransc 自己生成或申请的 taskid SHALL 继续使用 UUID v4。

#### Scenario: 现有客户端发送 taskid

- **WHEN** 请求使用当前协议允许的 taskid
- **THEN** 服务 SHALL 按现有方式记录它
- **AND** 本 change SHALL NOT 因新的格式策略拒绝该业务请求

### Requirement: download grant 保留 taskid 绑定

download grant request/body 中的 taskid、grant query taskid和HMAC input SHALL 保留现有绑定和格式校验。grant SHALL 自验证且不保存Redis状态。该绑定 SHALL 是“X-Task-ID 只用于日志”的明确兼容例外。

#### Scenario: 申请 download grant

- **WHEN** qtransc 使用 taskid 申请 grant
- **THEN** Qtserver SHALL 将该 taskid 纳入现有 grant 签名和校验上下文

#### Scenario: grant query 使用不同 taskid

- **WHEN** 下载请求 query/body taskid 与 grant 绑定值不同
- **THEN** Qtserver SHALL 按现有 grant 契约拒绝授权

#### Scenario: header 与 grant taskid 不同

- **WHEN** 有效 grant 请求的 X-Task-ID 与受 HMAC 绑定的 body/query taskid 不同或缺失
- **THEN** 下载授权 SHALL 只按现有 body/query taskid 校验
- **AND** header 差异 SHALL NOT 使有效 grant 失败

### Requirement: Qtserver 日志记录当前请求关联值

Qtserver 应用日志 SHALL 优先记录当前 `X-Task-ID`。旧 download grant 客户端缺失该 header 时，日志 SHALL 回退记录 grant 绑定的 taskid。日志 SHALL NOT 记录 Authorization、grant、HMAC secret 或固定 anonymous token。

#### Scenario: canonical upload 内部错误

- **WHEN** 携带 X-Task-ID 的 chunk 请求产生请求级错误
- **THEN** 对应结构化日志 SHALL 记录该 X-Task-ID

#### Scenario: 旧下载客户端没有 header

- **WHEN** 有效 grant 下载没有 X-Task-ID header
- **THEN** Qtserver SHALL 用 grant taskid 作为日志关联值

### Requirement: Nginx access log 记录但不授权 taskid

Nginx 加速下载 access log SHALL 使用安全转义格式记录客户端提供的 X-Task-ID；Nginx SHALL NOT 用该 header 做访问控制、路径选择或 grant 校验。

#### Scenario: X-Accel 下载

- **WHEN** Qtserver 返回 X-Accel-Redirect
- **THEN** Nginx SHALL 在 access log 中保留当前请求 X-Task-ID
- **AND** 下载授权 SHALL 仍完全由 Qtserver 的既有 grant 结果决定

### Requirement: 每个文件的第一个请求携带日志上下文

qtransc SHALL 在每个文件的第一个有效上传 init、普通下载注册分片请求或 small download 请求中携带 `Client-ID`、`Client-OS`、`Client-Version` 和允许为空的 `Caller-Version`。前三项 SHALL 继续构成必填 client metadata；`Caller-Version` SHALL 使用任务创建时固定的 `caller_version`，且其缺失或空值不影响前三项的完整性判断。普通下载注册分片 SHALL 是本次启动时最小的待下载`chunk_index`；在收到该分片一次合法HTTP响应头以前，该分片的每次attempt SHALL 携带完整metadata，且qtransc SHALL NOT 启动该文件其他分片请求。收到合法响应头后，后续Range SHALL 不再发送这四项metadata。如果恢复现场无需任何数据请求，第一次整文件 `/d/verify` SHALL 作为注册请求携带metadata。Qtserver SHALL 从配置取得 `task_type`、instance与timeout，从当前构建取得server version，从服务端解析的可信 principal取得`principal_id`，并按 `raw-business-event-log` 使用可信邮箱填充 `client_username`；无邮箱时 SHALL 写空字符串，不得回退到用户 ID；`anonymous`直接使用两项值`anonymous`而不查询身份服务。Qtserver SHALL 从可信网络边界取得 `client_ip` 与实际外部入口 `server_ip`，并从当前文件事实取得规范路径与file size。Qtransc SHALL NOT 提交 username、task type或服务端字段作为可信日志上下文，Qtserver也 SHALL NOT 从旧`/taskid`上下文回读这些字段。客户端元数据 SHALL 只用于文件日志上下文，不得参与授权、session ownership、grant HMAC、文件归属、能力协商或传输成功判定。

每个普通下载 `/d/down` GET还 SHALL 使用 `X-QT-Chunk-Index` 携带稳定的非负分片编号，包括Range和无Range完整GET。该编号 SHALL 只用于原始日志的分片关联和retry count分组，不得参与授权、grant、文件定位或Range计算；具体校验、零字节small分流与可信Nginx handoff规则由`raw-business-event-log`定义。

Download grant同时服务small与普通文件，SHALL NOT 产生原始业务事件，也不得被视为普通文件注册点。普通文件除指定注册请求及其在合法响应头确认前的重试外，后续 Range、verify和complete请求 SHALL NOT 重复提交上述客户端元数据。Small download 因不产生独立注册事件，其每个请求 SHALL 使用当前任务的完整metadata；同一请求的协议重试 MAY 重发相同metadata。

上传init与small请求是各自路径明确的首请求，缺少 `Client-ID`、`Client-OS` 或 `Client-Version` 任一必填metadata时Qtserver SHALL 拒绝；`Caller-Version` 缺失或为空时 SHALL 归一化为空字符串而不得拒绝。对普通下载`/d/down`和`/d/verify`，Qtserver SHALL 只把前三项必填metadata全部存在解释为注册请求，全部不存在解释为后续请求，只有前三项中的部分字段存在 SHALL 以参数错误拒绝；`Caller-Version` 单独存在 SHALL NOT 建立注册事实。Qtserver SHALL NOT 为此增加download registration业务状态；指定请求因HTTP异常重试产生内容一致的重复注册事实 MAY 被分析程序按最早事实合并。

因为Qtserver不保存普通下载注册状态，它 SHALL NOT 声称能区分“合法后续请求全无metadata”和“违反协议的首请求全无metadata”。Qtransc SHALL 通过注册分片串行握手保证自己的首个普通请求完整携带metadata。其他客户端若违反该契约，后续数据请求 MAY 产生无`file.registered`的孤立原始事件；分析程序 SHALL 保留但不得在注册到达前形成最终结果。

#### Scenario: 上传文件第一次 init

- **WHEN** qtransc 为一个文件发送第一次有效 upload init
- **THEN** 请求 SHALL 携带 client ID、OS、qtransc version 和任务的 caller version
- **AND** Qtserver SHALL 使用可信服务端事实补齐该文件日志上下文

#### Scenario: caller_version 只随注册请求发送

- **WHEN** 普通文件的注册请求已经收到一次合法响应头
- **THEN** qtransc 后续 Range、verify、chunk、complete 或其他数据请求 SHALL NOT 再发送 `Caller-Version`
- **AND** 首个请求在合法响应头确认前的重试 MAY 重发相同 `Caller-Version`

#### Scenario: 上传或small首请求metadata缺失

- **WHEN** upload init或small download请求缺少 `Client-ID`、`Client-OS` 或 `Client-Version`
- **THEN** Qtserver SHALL 在形成文件活动前拒绝该请求
- **AND** SHALL NOT 输出不完整的原始业务事件

#### Scenario: caller_version 缺失

- **WHEN** 合法首请求包含三项必填 client metadata 但未包含 `Caller-Version`
- **THEN** Qtserver SHALL 接受该请求并使用空字符串 `caller_version`
- **AND** 其他日志上下文与传输行为 SHALL 保持不变

#### Scenario: grant 后选择 small 路径

- **WHEN** qtransc 获取 download grant 后把文件分到 small download路径
- **THEN** grant SHALL NOT 已经为该文件产生 `file.registered`
- **AND** small请求未完整写完时 SHALL 不留下任何该文件原始业务事件

#### Scenario: 恢复下载无需Range请求

- **WHEN** qtransc本地已经具有全部文件数据且只需执行整文件verify
- **THEN** 第一次整文件verify SHALL 携带完整client metadata与任务的 caller version
- **AND** Qtserver SHALL 在校验前可靠输出`file.registered`

#### Scenario: metadata只出现一部分

- **WHEN** 普通下载请求只携带Client-ID、Client-OS、Client-Version中的一部分
- **THEN** Qtserver SHALL 以参数错误拒绝
- **AND** SHALL NOT 输出不完整注册事实

#### Scenario: Caller-Version 单独出现

- **WHEN** 普通下载请求没有三项必填metadata但单独携带 `Caller-Version`
- **THEN** Qtserver SHALL NOT 把该请求解释为注册请求
- **AND** SHALL NOT 仅凭该字段输出 `file.registered`

#### Scenario: 非规范客户端下载首请求完全不带metadata

- **WHEN** 非qtransc客户端第一次调用普通`/d/down`时三项metadata全部缺失
- **THEN** Qtserver MAY 按无状态协议把它解释为后续请求并发送数据
- **AND** 相应chunk事件 SHALL 在缺少注册时只保留供inspect使用，不得形成最终日志

#### Scenario: 注册分片响应头尚未确认

- **WHEN** 注册分片请求在qtransc收到合法响应头前发生网络错误
- **THEN** qtransc SHALL 使用包含相同 caller version 的完整metadata重试该注册分片
- **AND** SHALL NOT 启动其他分片请求

#### Scenario: 注册分片响应丢失导致重复注册

- **WHEN** Qtserver已经注册并返回响应但qtransc未收到响应头而重试
- **THEN** Qtserver MAY 输出内容一致的重复`file.registered`
- **AND** 分析程序 SHALL 使用最早合法注册事实

#### Scenario: 客户端伪造身份或 IP

- **WHEN** 客户端提交的字段与已认证 principal 或可信网络观察值冲突
- **THEN** Qtserver SHALL 使用服务端可信事实
- **AND** 客户端字段 SHALL NOT 改变授权结果

### Requirement: 文件活动使用稳定四元组关联

原始业务事件中的文件活动 SHALL 由 `(task_id, normalized_file_path, principal_id, action)` 唯一关联。`action` SHALL 是 `upload|download`。系统 SHALL NOT 定义“匿名下载”类型；选择内置 `anonymous` 用户的合法文件请求 SHALL 直接使用 `principal_id=anonymous` 和 `client_username=anonymous`，且 Qtserver SHALL NOT 为该用户查询外部身份服务。Qtserver SHALL 使用 `raw-business-event-log` 定义的确定性算法生成 `file_key`，且 SHALL NOT 把 `file_key` 当作新的授权或资源 ownership 字段。

#### Scenario: 一个客户端 task 包含多个文件

- **WHEN** qtransc 使用同一 task ID传输两个不同规范路径的文件
- **THEN** Qtserver SHALL 形成两个不同 `file_key` 的文件活动
- **AND** SHALL NOT 创建服务端 Task aggregate

#### Scenario: 同一路径上传和下载

- **WHEN** 同一 task ID、principal 和规范路径分别执行上传与下载
- **THEN** 两项活动 SHALL 因 action 不同而使用不同 `file_key`

### Requirement: serve 创建任务 API 接收可选 taskpid

qtransc `serve` 的 `POST /api/v1/tasks` 请求体 SHALL 接受可选 string 字段 `taskPid`。qtransc SHALL 先去除输入值首尾的 ASCII SP 和 HTAB，内部空白 SHALL 保留。字段缺失、值为空字符串或 trim 后为空时 SHALL 使用空字符串作为内部 `taskpid` 创建任务；该情况 SHALL NOT 使任务创建、启动或传输失败。内部 `taskpid` SHALL 是不透明的日志关联值，SHALL NOT 具有 task ID、用户 ID、授权标识或幂等键语义。

归一化后的非空 `taskPid` SHALL 至多为 128 bytes、是合法 UTF-8，且只包含可安全作为 HTTP header field value 传播的文本。不符合输入格式时，serve API SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封，且不得创建任务。旧字段 `taskpid` SHALL 作为未知字段被拒绝。qtransc 的 CLI 子命令 SHALL NOT 新增对应参数，非 serve 创建的任务 SHALL 使用空字符串作为内部 `taskpid`。

#### Scenario: serve 调用方传入 taskpid

- **WHEN** 调用方使用合法非空 `taskPid` 创建 upload 或 download 任务
- **THEN** qtransc SHALL 保存该 trim 后的 string 作为本任务的内部 `taskpid`
- **AND** `taskpid` SHALL NOT 改变任务 ID、文件选择或传输结果

#### Scenario: serve 调用方传入首尾空白

- **WHEN** 调用方使用首尾含 ASCII SP 或 HTAB、trim 后合法的 `taskPid` 创建任务
- **THEN** qtransc SHALL 去除首尾 SP 和 HTAB 并保留内部空白
- **AND** 后续 header、原始事件和最终日志 SHALL 使用相同的归一化值

#### Scenario: serve 调用方省略 taskpid

- **WHEN** 创建任务请求没有 `taskPid` 字段、该字段是空字符串或 trim 后为空
- **THEN** qtransc SHALL 正常创建和启动任务
- **AND** 该任务的内部日志关联值 SHALL 是空字符串

#### Scenario: CLI 创建任务

- **WHEN** 用户通过非 serve CLI 子命令创建传输任务
- **THEN** CLI SHALL NOT 提供对应参数
- **AND** 该任务所有需要共现的日志 SHALL 使用空字符串 `taskpid`

#### Scenario: 非法 taskpid

- **WHEN** serve 请求提供 trim 后超过 128 bytes、不是合法 UTF-8 或包含非法 HTTP field-value 字符的非空 `taskPid`
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务、截断、改写或部分传播该值

#### Scenario: 旧 taskpid 字段

- **WHEN** serve 请求使用旧字段 `taskpid`
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务

### Requirement: taskpid 与 task ID 同任务传播但不参与业务

qtransc SHALL 在同一upload/download task内保存固定`taskpid`，并在该task所有携带`X-Task-ID`的Qtserver HTTP请求中同时携带`X-Task-PID`；空值也 SHALL 以空string语义传播。Nginx SHALL 显式转发`X-Task-PID`，Qtserver SHALL 将其作为当前请求日志上下文读取。除serve创建任务API外，系统 SHALL NOT 从CLI flag、Qtserver响应、download grant、路径、token、session或其他字段生成或覆盖`taskpid`。

`taskpid` SHALL NOT 参与认证、授权、principal、文件空间、路径规范化、download grant或HMAC、upload session ownership、业务幂等、`file_key`、Range、hash、重试、任务状态或传输结果。相同业务请求在`taskpid`缺失、为空、不同或由第三方伪造时，除日志内容外 SHALL 具有相同业务行为。

Canonical upload session SHALL 保存创建session时与初始task ID一起收到的初始`taskpid`，并为该session后续原始业务事件继续使用这组初始日志关联值；后续请求当前`X-Task-PID`不同只 MAY 出现在请求运行日志中，SHALL NOT 改变session或原始事件的文件活动关联。

#### Scenario: 任务请求携带两个日志关联header

- **WHEN** qtransc为一个serve任务发送带`X-Task-ID`的Qtserver请求
- **THEN** 同一请求 SHALL 同时携带`X-Task-PID`
- **AND** 其值 SHALL 等于任务创建时保存的归一化`taskpid`

#### Scenario: 空 taskpid 继续传输

- **WHEN** qtransc任务的`taskpid`为空字符串
- **THEN** Qtserver SHALL 按现有task ID、身份和业务参数执行请求
- **AND** SHALL NOT 因`X-Task-PID`缺失或为空拒绝请求

#### Scenario: 第三方改变 taskpid

- **WHEN** 两个其他条件相同的请求携带不同`X-Task-PID`
- **THEN** Qtserver SHALL 只在对应日志中记录各自值
- **AND** 授权、session、文件状态和HTTP业务结果 SHALL 不因此改变

#### Scenario: canonical upload后续请求改变 taskpid

- **WHEN** 同principal对已有canonical upload session发送与创建时不同的`X-Task-PID`
- **THEN** Qtserver SHALL 按现有session契约继续处理请求
- **AND** 该session的原始业务事件 SHALL 继续使用创建时保存的初始`taskpid`

### Requirement: 结构化运行日志中的 task ID 与 taskpid 必须共现

qtransc、Qtserver和Nginx的结构化运行或访问日志中，只要一条记录包含名为`taskid`或`task_id`的结构化字段，同一条记录 SHALL 同时包含名为`taskpid`的string字段。存在关联值时 SHALL 记录该值；无值时 SHALL 显式记录空字符串，不得省略、写`null`或用占位符替代。该共现规则只约束日志记录，不要求含`task_id`的普通HTTP API响应或内部非日志数据模型新增`taskpid`。

Qtserver请求日志 SHALL 使用当前请求`X-Task-PID`，且其值 SHALL 经过结构化JSON日志编码。日志 SHALL NOT 因`taskpid`内容改变级别、消息、错误处理或采样决策。Authorization、grant、HMAC secret或token仍 SHALL NOT 因该关联值而进入日志。

#### Scenario: serve任务写qtransc运行日志

- **WHEN** qtransc为带非空`taskpid`的任务写出一条含`taskid`或`task_id`字段的结构化日志
- **THEN** 同一条日志 SHALL 包含值相同的string字段`taskpid`

#### Scenario: CLI任务写qtransc运行日志

- **WHEN** 非serve CLI任务写出一条含`taskid`或`task_id`字段的结构化日志
- **THEN** 同一条日志 SHALL 包含`"taskpid":""`

#### Scenario: Qtserver请求错误日志

- **WHEN** 携带`X-Task-ID`和`X-Task-PID`的请求在Qtserver产生结构化错误日志
- **THEN** 该记录的task ID字段与`taskpid` SHALL 同时存在
- **AND** `taskpid` SHALL NOT 改变返回给客户端的业务错误

### Requirement: serve 创建任务 API 接收可选 enterprise_id

qtransc `serve` 的 `POST /api/v1/tasks` 请求体 SHALL 接受可选 string 字段 `enterpriseId`。qtransc SHALL 先去除输入值首尾的 ASCII SP 和 HTAB，内部空白 SHALL 保留；字段缺失、值为空字符串或 trim 后为空时 SHALL 使用空字符串作为内部 `enterprise_id` 创建任务。归一化后的非空值 SHALL 至多为 128 bytes、是合法 UTF-8，且只包含可安全作为 HTTP header field value 传播的文本。不符合输入格式或显式使用 `null`、number、boolean、array 或 object 时，serve API SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封，且不得创建任务。旧字段 `enterprise_id` SHALL 作为未知字段被拒绝。

内部 `enterprise_id` SHALL 是不透明的外部企业日志关联标签，SHALL NOT 具有可信企业身份、tenant、principal、授权标识或幂等键语义。qtransc 的 CLI 子命令 SHALL NOT 新增对应参数，非 serve 创建的任务 SHALL 使用空字符串。创建任务响应、任务详情与摘要、SSE、WebSocket 和其他 API 响应 SHALL NOT 返回 `enterpriseId` 或内部 `enterprise_id`。

#### Scenario: serve 调用方传入 enterprise_id

- **WHEN** 调用方使用首尾含 ASCII SP 或 HTAB、trim 后合法的非空 `enterpriseId` 创建 upload 或 download 任务
- **THEN** qtransc SHALL 保存 trim 后的 string 作为内部 `enterprise_id` 并保留内部空白
- **AND** 后续请求 header、原始事件和最终日志 SHALL 使用相同的归一化值

#### Scenario: serve 调用方省略 enterprise_id

- **WHEN** 创建任务请求没有 `enterpriseId`、值为空字符串或 trim 后为空
- **THEN** qtransc SHALL 正常创建任务
- **AND** 该任务的内部企业关联标签 SHALL 是空字符串

#### Scenario: 非法 enterprise_id

- **WHEN** serve 请求的 `enterpriseId` 在 trim 后超过 128 bytes、不是合法 UTF-8、包含非法 HTTP field-value 字符或不是 string
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务、截断、改写或部分传播该值

#### Scenario: 旧 enterprise_id 字段

- **WHEN** serve 请求使用旧字段 `enterprise_id`
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务

#### Scenario: CLI 创建任务

- **WHEN** 用户通过非 serve CLI 子命令创建传输任务
- **THEN** CLI SHALL NOT 提供对应参数
- **AND** 该任务所有需要共现的日志 SHALL 使用空字符串 `enterprise_id`

#### Scenario: 查询任务不暴露企业标签

- **WHEN** 调用方创建带非空 `enterpriseId` 的 serve 任务后查询任务或订阅实时事件
- **THEN** 对应 API、SSE 和 WebSocket 输出 SHALL NOT 包含 `enterpriseId` 或 `enterprise_id`

### Requirement: enterprise_id 随 task ID 传播但不参与业务

qtransc SHALL 在同一 upload/download task 内不可变地保存 `enterprise_id`。该 task 的所有 Qtserver HTTP 请求只要携带当前有效的 `X-Task-ID`，就 SHALL 同时携带 `X-Task-PID` 与 `X-Enterprise-ID`；两项标签为空时也 SHALL 使用空 string 语义传播。当前有效 task ID MAY 是 qtransc 本地 task ID 或显式保存的 ServerTaskID，标签 SHALL 跟随最终写入 `X-Task-ID` 的值发送，但 SHALL NOT 参与选择或生成该 task ID。

Nginx SHALL 显式转发 `X-Enterprise-ID`，Qtserver SHALL 将其作为当前请求日志上下文读取。除 serve 创建任务 API 外，系统 SHALL NOT 从 CLI flag、Qtserver 响应、download grant、路径、token、session、principal 或其他字段生成、推导或覆盖 `enterprise_id`。

`enterprise_id` SHALL NOT 参与认证、授权、principal、企业或用户文件空间、路径规范化、download grant 或 HMAC、upload session ownership、业务幂等、`file_key`、Range、hash、重试、任务状态、指标或传输结果。相同业务请求在 `enterprise_id` 缺失、为空、不同或由第三方伪造时，除日志内容外 SHALL 具有相同业务行为。系统 SHALL NOT 按企业标签建立 Task aggregate 或企业级传输状态。

Canonical upload session SHALL 保存创建 session 时收到的初始 `(task_id, taskpid, enterprise_id)`，并为该 session 后续原始业务事件继续使用整组初始日志关联值。后续请求当前 `X-Task-ID`、`X-Task-PID` 或 `X-Enterprise-ID` 不同 MAY 出现在请求运行日志中，但 SHALL NOT 改变 session、`file_key` 或原始事件采用的初始值。

#### Scenario: 任务请求携带三项关联 header

- **WHEN** qtransc 为一个 serve 任务发送带 `X-Task-ID` 的 Qtserver 请求
- **THEN** 同一请求 SHALL 同时携带 `X-Task-PID` 与 `X-Enterprise-ID`
- **AND** 两项值 SHALL 等于任务创建时保存的归一化标签

#### Scenario: 本地 task ID 与 ServerTaskID 不同

- **WHEN** qtransc task 保存了与本地 task ID 不同的 ServerTaskID
- **THEN** Qtserver 请求 SHALL 使用 ServerTaskID 作为 `X-Task-ID`
- **AND** SHALL 继续携带该 qtransc task 不可变保存的 `taskpid` 与 `enterprise_id`

#### Scenario: 空企业标签继续传输

- **WHEN** qtransc 任务的 `enterprise_id` 为空字符串
- **THEN** Qtserver SHALL 按现有 task ID、身份和业务参数执行请求
- **AND** SHALL NOT 因 `X-Enterprise-ID` 缺失或为空拒绝请求

#### Scenario: 第三方改变企业标签

- **WHEN** 两个其他条件相同的请求携带不同 `X-Enterprise-ID`
- **THEN** Qtserver SHALL 只在对应日志上下文中记录各自值
- **AND** 授权、session、文件状态和 HTTP 业务结果 SHALL 不因此改变

#### Scenario: canonical upload 后续请求改变标签

- **WHEN** 同 principal 对已有 canonical upload session 发送与创建时不同的 `X-Task-PID` 或 `X-Enterprise-ID`
- **THEN** Qtserver SHALL 按现有 session 契约继续处理请求
- **AND** 该 session 的原始业务事件 SHALL 继续使用创建时保存的整组初始关联值

### Requirement: 结构化运行日志中的 task ID 与两个辅助标签必须共现

qtransc、Qtserver 和 Nginx 的结构化运行或访问日志中，只要一条记录包含名为 `taskid` 或 `task_id` 的结构化字段，同一条记录 SHALL 同时包含名为 `taskpid` 和 `enterprise_id` 的 string 字段。存在关联值时 SHALL 记录对应值；无值时 SHALL 显式记录空字符串，不得省略、写 `null` 或使用占位符。该规则只约束日志记录，不要求含 `task_id` 的普通 HTTP API 响应或内部非日志数据模型暴露两个标签。

Qtserver 请求日志 SHALL 分别使用当前请求 `X-Task-PID` 与 `X-Enterprise-ID`，并对两项值执行结构化 JSON 日志编码。任一标签 SHALL NOT 改变日志级别、消息、错误处理或采样决策。Authorization、grant、HMAC secret 和 token SHALL NOT 因标签共现而进入日志。

#### Scenario: serve 任务写 qtransc 运行日志

- **WHEN** qtransc 为带非空辅助标签的任务写出一条含 `taskid` 或 `task_id` 字段的结构化日志
- **THEN** 同一条日志 SHALL 包含值相同的 string 字段 `taskpid` 与 `enterprise_id`

#### Scenario: CLI 任务写 qtransc 运行日志

- **WHEN** 非 serve CLI 任务写出一条含 `taskid` 或 `task_id` 字段的结构化日志
- **THEN** 同一条日志 SHALL 包含 `"taskpid":""` 与 `"enterprise_id":""`

#### Scenario: Qtserver 请求错误日志

- **WHEN** 携带三项关联 header 的请求在 Qtserver 产生结构化错误日志
- **THEN** 该记录的 task ID、`taskpid` 与 `enterprise_id` SHALL 同时存在
- **AND** 两项辅助标签 SHALL NOT 改变返回给客户端的业务错误

### Requirement: serve 创建任务 API 接收可选 caller_version

qtransc `serve` 的 `POST /api/v1/tasks` 请求体 SHALL 接受可选 string 字段 `callerVersion`。qtransc SHALL 去除其首尾 ASCII SP 和 HTAB、保留内部字符，并在归一化后要求值为合法 UTF-8、至多 256 bytes 且可安全作为 HTTP header field value 传播。字段缺失、值为空字符串或 trim 后为空时 SHALL 使用空字符串作为内部 `caller_version` 创建任务；显式 `null`、非 string、超长或包含非法 header value 字符时 SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封，且不得创建任务。旧字段 `caller_version` SHALL 作为未知字段被拒绝。

内部 `caller_version` SHALL 是创建任务的 GUI 或 Agent 自报版本，仅用于诊断日志。它 SHALL NOT 具有客户端二进制版本、身份、授权、tenant、任务 ID、幂等键或能力协商语义。创建任务响应、任务详情与摘要、SSE、WebSocket 和其他 API 响应 SHALL NOT 返回 `callerVersion` 或内部 `caller_version`。除 `upload2`/`download2 --callerversion` 与 serve 创建任务 API 外，其他 qtransc CLI 创建的任务 SHALL 使用空字符串。

#### Scenario: serve 调用方传入 caller_version

- **WHEN** 调用方以合法 string `callerVersion` 创建 upload 或 download 任务
- **THEN** qtransc SHALL 在任务生命周期内保存归一化后的内部 `caller_version`
- **AND** 该值 SHALL NOT 改变任务 ID、文件选择、授权或传输结果

#### Scenario: serve 调用方省略 caller_version

- **WHEN** 创建任务请求没有 `callerVersion`、值为空字符串或 trim 后为空
- **THEN** qtransc SHALL 正常创建任务
- **AND** 该任务的内部 `caller_version` SHALL 是空字符串

#### Scenario: serve 调用方提交非法 caller_version

- **WHEN** `callerVersion` 是 `null`、非 string、trim 后超过 256 bytes、不是合法 UTF-8 或包含非法 HTTP header value 字符
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务、截断或部分传播该值

#### Scenario: 旧 caller_version 字段

- **WHEN** serve 请求使用旧字段 `caller_version`
- **THEN** qtransc SHALL 返回 HTTP `200` 和规范注册表的“请求无效”失败信封
- **AND** SHALL NOT 创建任务

#### Scenario: 查询任务不暴露 caller_version

- **WHEN** 调用方创建带非空 `callerVersion` 的 serve 任务后查询任务或订阅实时事件
- **THEN** 对应 API、SSE 与 WebSocket 输出 SHALL NOT 包含 `callerVersion` 或 `caller_version`
