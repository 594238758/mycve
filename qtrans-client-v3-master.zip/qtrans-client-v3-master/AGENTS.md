## Documentation Maintenance

Project documentation authority, the maintained-document list, internal/external audience boundaries, mandatory human review rules, and specialized maintenance requirements are defined in [`docs/document-maintenance.md`](docs/document-maintenance.md). Read and follow that document before reviewing or modifying project documentation.

## Working Rules

1. Unless explicitly requested, do not write test code.
2. Unless explicitly requested, do not write benchmark code.
3. Unless explicitly requested, do not run tests. After modifying source code, perform only the necessary build or compilation checks to ensure that the code compiles successfully.
4. Unless explicitly requested to implement a change, discuss the problem and design in detail before modifying code.
5. When discussing project design, critically challenge my proposals. Actively identify hidden assumptions, unresolved design decisions, boundary conditions, failure paths, concurrency issues, and relevant trade-offs. Do not accept a proposal merely for the sake of reaching agreement quickly.
