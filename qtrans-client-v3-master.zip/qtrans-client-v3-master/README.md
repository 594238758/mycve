# qtrans

本仓库包含同一传输系统的三个 Go module：

- [`qtransc`](qtransc/)：客户端传输执行引擎。
- [`qtserver`](qtserver/)：服务端控制面与传输 API。
- [`qtuser`](qtuser/)：可选的轻量身份服务。

跨组件行为契约统一维护在 [`openspec/specs`](openspec/specs/) 和 active change 中。当前原始业务日志契约见 [`raw-business-event-log`](openspec/specs/raw-business-event-log/spec.md)。

```bash
make build
```
