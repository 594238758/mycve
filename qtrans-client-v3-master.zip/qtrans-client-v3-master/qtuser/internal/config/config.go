package config

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net"
	"net/url"
	"os"
	"path/filepath"
	"slices"
	"strings"

	"github.com/pelletier/go-toml/v2"
)

const Filename = "qtuser_config.toml"

type Config struct {
	Server     ServerConfig     `toml:"server" json:"server"`
	Database   DatabaseConfig   `toml:"database" json:"database"`
	Management ManagementConfig `toml:"management" json:"management"`
	Client     ClientConfig     `toml:"client" json:"client"`
	Log        LogConfig        `toml:"log" json:"log"`
}

type ServerConfig struct {
	Host string `toml:"host" json:"host"`
	Port int    `toml:"port" json:"port"`
}

type DatabaseConfig struct {
	Path string `toml:"path" json:"path"`
}

type ManagementConfig struct {
	AllowRemote bool   `toml:"allow_remote" json:"allow_remote"`
	Token       string `toml:"token" json:"-"`
}

type ClientConfig struct {
	BaseURL string `toml:"base_url" json:"base_url"`
}

type LogConfig struct {
	Level string `toml:"level" json:"level"`
}

var requiredShape = map[string][]string{
	"server":     {"host", "port"},
	"database":   {"path"},
	"management": {"allow_remote", "token"},
	"client":     {"base_url"},
	"log":        {"level"},
}

func InstallDir() (string, error) {
	executable, err := os.Executable()
	if err != nil {
		return "", fmt.Errorf("resolve executable: %w", err)
	}
	resolved, err := filepath.EvalSymlinks(executable)
	if err != nil {
		return "", fmt.Errorf("resolve executable symlinks: %w", err)
	}
	abs, err := filepath.Abs(resolved)
	if err != nil {
		return "", fmt.Errorf("resolve executable absolute path: %w", err)
	}
	return filepath.Dir(abs), nil
}

func LoadFromInstallDir() (*Config, string, error) {
	dir, err := InstallDir()
	if err != nil {
		return nil, "", err
	}
	cfg, err := Load(filepath.Join(dir, Filename))
	if err != nil {
		return nil, "", err
	}
	return cfg, dir, nil
}

func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config %s: %w", path, err)
	}
	if err := validateShape(data); err != nil {
		return nil, fmt.Errorf("validate config %s: %w", path, err)
	}
	var cfg Config
	decoder := toml.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&cfg); err != nil {
		return nil, fmt.Errorf("decode config %s: %w", path, err)
	}
	if err := cfg.Validate(); err != nil {
		return nil, fmt.Errorf("validate config %s: %w", path, err)
	}
	return &cfg, nil
}

func validateShape(data []byte) error {
	var raw map[string]any
	if err := toml.Unmarshal(data, &raw); err != nil {
		return err
	}
	actualSections := make([]string, 0, len(raw))
	for section := range raw {
		actualSections = append(actualSections, section)
	}
	slices.Sort(actualSections)
	expectedSections := make([]string, 0, len(requiredShape))
	for section := range requiredShape {
		expectedSections = append(expectedSections, section)
	}
	slices.Sort(expectedSections)
	if !slices.Equal(actualSections, expectedSections) {
		return fmt.Errorf("top-level sections must be exactly %v, got %v", expectedSections, actualSections)
	}
	for section, expectedKeys := range requiredShape {
		table, ok := raw[section].(map[string]any)
		if !ok {
			return fmt.Errorf("section %q must be a table", section)
		}
		actualKeys := make([]string, 0, len(table))
		for key := range table {
			actualKeys = append(actualKeys, key)
		}
		slices.Sort(actualKeys)
		expected := slices.Clone(expectedKeys)
		slices.Sort(expected)
		if !slices.Equal(actualKeys, expected) {
			return fmt.Errorf("section %q fields must be exactly %v, got %v", section, expected, actualKeys)
		}
	}
	return nil
}

func (c Config) Validate() error {
	if strings.TrimSpace(c.Server.Host) == "" {
		return fmt.Errorf("server.host must not be empty")
	}
	if c.Server.Port < 1 || c.Server.Port > 65535 {
		return fmt.Errorf("server.port must be between 1 and 65535")
	}
	if strings.TrimSpace(c.Database.Path) == "" {
		return fmt.Errorf("database.path must not be empty")
	}
	if c.Management.AllowRemote && strings.TrimSpace(c.Management.Token) == "" {
		return fmt.Errorf("management.token must not be empty when management.allow_remote is true")
	}
	parsed, err := url.Parse(c.Client.BaseURL)
	if err != nil || parsed == nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" || parsed.User != nil {
		return fmt.Errorf("client.base_url must be an absolute HTTP or HTTPS URL without userinfo")
	}
	switch strings.ToLower(strings.TrimSpace(c.Log.Level)) {
	case "debug", "info", "warn", "error":
	default:
		return fmt.Errorf("log.level must be one of: debug, info, warn, error")
	}
	return nil
}

func (c Config) ListenAddress() string {
	return net.JoinHostPort(c.Server.Host, fmt.Sprintf("%d", c.Server.Port))
}

func ResolveDatabasePath(installDir, configured string) (string, error) {
	installAbs, err := filepath.Abs(installDir)
	if err != nil {
		return "", fmt.Errorf("resolve install directory: %w", err)
	}
	if resolved, resolveErr := filepath.EvalSymlinks(installAbs); resolveErr == nil {
		installAbs = resolved
	}
	candidate := configured
	if !filepath.IsAbs(candidate) {
		candidate = filepath.Join(installAbs, candidate)
	}
	candidate, err = filepath.Abs(filepath.Clean(candidate))
	if err != nil {
		return "", fmt.Errorf("resolve database path: %w", err)
	}
	if resolved, resolveErr := filepath.EvalSymlinks(candidate); resolveErr == nil {
		candidate = resolved
	} else if !os.IsNotExist(resolveErr) {
		return "", fmt.Errorf("resolve database path symlinks: %w", resolveErr)
	} else {
		parent, parentErr := filepath.EvalSymlinks(filepath.Dir(candidate))
		if parentErr != nil {
			return "", fmt.Errorf("resolve database parent directory: %w", parentErr)
		}
		candidate = filepath.Join(parent, filepath.Base(candidate))
	}
	relative, err := filepath.Rel(installAbs, candidate)
	if err != nil {
		return "", fmt.Errorf("compare database path with install directory: %w", err)
	}
	if relative == ".." || strings.HasPrefix(relative, ".."+string(filepath.Separator)) || filepath.IsAbs(relative) {
		return "", fmt.Errorf("database.path must resolve inside installation directory")
	}
	return candidate, nil
}

func (c Config) RedactedJSON() string {
	copy := c
	if copy.Management.Token != "" {
		copy.Management.Token = "[REDACTED]"
	}
	data, err := json.MarshalIndent(copy, "", "  ")
	if err != nil {
		return fmt.Sprintf("unable to encode config: %v", err)
	}
	return string(data)
}
