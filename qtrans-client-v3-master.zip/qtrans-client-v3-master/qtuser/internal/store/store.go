package store

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	"qtuser/internal/domain"

	"github.com/google/uuid"
	"modernc.org/sqlite"
)

const currentSchemaVersion = 1

var (
	ErrNotFound      = errors.New("user not found")
	ErrConflict      = errors.New("user or token already exists")
	ErrUserConflict  = errors.New("user already exists")
	ErrTokenConflict = errors.New("token already exists")
	ErrBusy          = errors.New("database busy or locked")
)

type FatalError struct {
	Err error
}

func (e *FatalError) Error() string {
	return fmt.Sprintf("fatal database error: %v", e.Err)
}

func (e *FatalError) Unwrap() error {
	return e.Err
}

func IsFatal(err error) bool {
	var fatal *FatalError
	return errors.As(err, &fatal)
}

type Store struct {
	db  *sql.DB
	now func() time.Time
}

func Open(ctx context.Context, databasePath string) (*Store, error) {
	if err := checkDirectoryWritable(filepath.Dir(databasePath)); err != nil {
		return nil, err
	}
	dsnURL := &url.URL{Scheme: "file", Path: databasePath}
	query := dsnURL.Query()
	query.Add("_pragma", "busy_timeout(5000)")
	query.Add("_pragma", "journal_mode(WAL)")
	query.Add("_pragma", "synchronous(NORMAL)")
	dsnURL.RawQuery = query.Encode()
	db, err := sql.Open("sqlite", dsnURL.String())
	if err != nil {
		return nil, fmt.Errorf("open SQLite: %w", err)
	}
	db.SetMaxOpenConns(4)
	db.SetMaxIdleConns(4)
	result := &Store{db: db, now: time.Now}
	if err := result.initialize(ctx); err != nil {
		_ = db.Close()
		return nil, err
	}
	return result, nil
}

func checkDirectoryWritable(directory string) error {
	info, err := os.Stat(directory)
	if err != nil {
		return fmt.Errorf("inspect database directory: %w", err)
	}
	if !info.IsDir() {
		return fmt.Errorf("database parent is not a directory")
	}
	probe := filepath.Join(directory, ".qtuser-write-check-"+uuid.NewString())
	file, err := os.OpenFile(probe, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o600)
	if err != nil {
		return fmt.Errorf("database directory is not writable: %w", err)
	}
	closeErr := file.Close()
	removeErr := os.Remove(probe)
	if closeErr != nil {
		return fmt.Errorf("close database directory probe: %w", closeErr)
	}
	if removeErr != nil {
		return fmt.Errorf("remove database directory probe: %w", removeErr)
	}
	return nil
}

func (s *Store) initialize(ctx context.Context) error {
	if err := s.db.PingContext(ctx); err != nil {
		return fmt.Errorf("ping SQLite: %w", err)
	}
	var integrity string
	if err := s.db.QueryRowContext(ctx, "PRAGMA integrity_check").Scan(&integrity); err != nil {
		return fmt.Errorf("check SQLite integrity: %w", err)
	}
	if integrity != "ok" {
		return fmt.Errorf("SQLite integrity check failed: %s", integrity)
	}
	var version int
	if err := s.db.QueryRowContext(ctx, "PRAGMA user_version").Scan(&version); err != nil {
		return fmt.Errorf("read SQLite schema version: %w", err)
	}
	if version > currentSchemaVersion {
		return fmt.Errorf("SQLite schema version %d is newer than supported version %d", version, currentSchemaVersion)
	}
	if version < currentSchemaVersion {
		if err := s.migrate(ctx, version); err != nil {
			return err
		}
	}
	if err := s.validateSchema(ctx); err != nil {
		return err
	}
	var one int
	if err := s.db.QueryRowContext(ctx, "SELECT 1").Scan(&one); err != nil || one != 1 {
		return fmt.Errorf("run SQLite startup query: %w", err)
	}
	return nil
}

func (s *Store) migrate(ctx context.Context, from int) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("begin SQLite migration: %w", err)
	}
	defer tx.Rollback()
	version := from
	if version == 0 {
		if _, err := tx.ExecContext(ctx, `CREATE TABLE IF NOT EXISTS users (
    id         TEXT PRIMARY KEY,
    token      TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
)`); err != nil {
			return fmt.Errorf("create users table: %w", err)
		}
		version = 1
	}
	if version != currentSchemaVersion {
		return fmt.Errorf("no migration path from SQLite schema version %d", from)
	}
	if _, err := tx.ExecContext(ctx, fmt.Sprintf("PRAGMA user_version = %d", currentSchemaVersion)); err != nil {
		return fmt.Errorf("record SQLite schema version: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return fmt.Errorf("commit SQLite migration: %w", err)
	}
	return nil
}

func (s *Store) validateSchema(ctx context.Context) error {
	rows, err := s.db.QueryContext(ctx, "PRAGMA table_info(users)")
	if err != nil {
		return fmt.Errorf("inspect users schema: %w", err)
	}
	defer rows.Close()
	type column struct {
		name     string
		typeName string
		notNull  int
		primary  int
	}
	columns := make([]column, 0, 4)
	for rows.Next() {
		var position int
		var current column
		var defaultValue any
		if err := rows.Scan(&position, &current.name, &current.typeName, &current.notNull, &defaultValue, &current.primary); err != nil {
			return fmt.Errorf("read users schema: %w", err)
		}
		columns = append(columns, current)
	}
	if err := rows.Err(); err != nil {
		return fmt.Errorf("iterate users schema: %w", err)
	}
	if len(columns) != 4 || columns[0].name != "id" || columns[1].name != "token" || columns[2].name != "created_at" || columns[3].name != "updated_at" || columns[0].primary != 1 {
		return fmt.Errorf("users table schema is unsupported")
	}
	var uniqueTokenIndex bool
	indexRows, err := s.db.QueryContext(ctx, "PRAGMA index_list(users)")
	if err != nil {
		return fmt.Errorf("inspect users indexes: %w", err)
	}
	defer indexRows.Close()
	for indexRows.Next() {
		var sequence, unique, partial int
		var name, origin string
		if err := indexRows.Scan(&sequence, &name, &unique, &origin, &partial); err != nil {
			return fmt.Errorf("read users indexes: %w", err)
		}
		if unique == 0 {
			continue
		}
		var indexSequence, columnPosition int
		var columnName string
		if err := s.db.QueryRowContext(ctx, "SELECT seqno, cid, name FROM pragma_index_info(?) LIMIT 1", name).Scan(&indexSequence, &columnPosition, &columnName); err == nil && columnName == "token" {
			uniqueTokenIndex = true
		}
	}
	if err := indexRows.Err(); err != nil {
		return fmt.Errorf("iterate users indexes: %w", err)
	}
	if !uniqueTokenIndex {
		return fmt.Errorf("users.token unique constraint is missing")
	}
	return nil
}

func (s *Store) Close() error {
	if s == nil || s.db == nil {
		return nil
	}
	return s.db.Close()
}

func (s *Store) Create(ctx context.Context, id string, requestedToken *string) (*domain.User, error) {
	canonicalID, err := domain.CanonicalizeID(id)
	if err != nil {
		return nil, err
	}
	generated := requestedToken == nil
	for attempt := 0; attempt < 5; attempt++ {
		token := ""
		if requestedToken != nil {
			token = *requestedToken
			if err := domain.ValidateToken(token); err != nil {
				return nil, err
			}
		} else {
			token, err = domain.NewToken()
			if err != nil {
				return nil, err
			}
		}
		now := s.now().UTC().Format(time.RFC3339)
		_, err = s.db.ExecContext(ctx, "INSERT INTO users (id, token, created_at, updated_at) VALUES (?, ?, ?, ?)", canonicalID, token, now, now)
		if err == nil {
			return &domain.User{ID: canonicalID, Token: token, CreatedAt: now, UpdatedAt: now}, nil
		}
		classified := classify(err)
		if generated && errors.Is(classified, ErrTokenConflict) {
			continue
		}
		return nil, classified
	}
	return nil, &FatalError{Err: fmt.Errorf("unable to generate a unique token")}
}

func (s *Store) Get(ctx context.Context, id string) (*domain.User, error) {
	canonicalID, err := domain.CanonicalizeID(id)
	if err != nil {
		return nil, err
	}
	return scanUser(s.db.QueryRowContext(ctx, "SELECT id, token, created_at, updated_at FROM users WHERE id = ?", canonicalID))
}

func (s *Store) GetByToken(ctx context.Context, token string) (*domain.User, error) {
	if err := domain.ValidateToken(token); err != nil {
		return nil, ErrNotFound
	}
	return scanUser(s.db.QueryRowContext(ctx, "SELECT id, token, created_at, updated_at FROM users WHERE token = ?", token))
}

func (s *Store) List(ctx context.Context) ([]domain.User, error) {
	rows, err := s.db.QueryContext(ctx, "SELECT id, token, created_at, updated_at FROM users ORDER BY id ASC")
	if err != nil {
		return nil, classify(err)
	}
	defer rows.Close()
	users := make([]domain.User, 0)
	for rows.Next() {
		var user domain.User
		if err := rows.Scan(&user.ID, &user.Token, &user.CreatedAt, &user.UpdatedAt); err != nil {
			return nil, classify(err)
		}
		users = append(users, user)
	}
	if err := rows.Err(); err != nil {
		return nil, classify(err)
	}
	return users, nil
}

func (s *Store) ReplaceToken(ctx context.Context, id string, requestedToken *string) (*domain.User, error) {
	canonicalID, err := domain.CanonicalizeID(id)
	if err != nil {
		return nil, err
	}
	generated := requestedToken == nil
	for attempt := 0; attempt < 5; attempt++ {
		token := ""
		if requestedToken != nil {
			token = *requestedToken
			if err := domain.ValidateToken(token); err != nil {
				return nil, err
			}
		} else {
			token, err = domain.NewToken()
			if err != nil {
				return nil, err
			}
		}
		now := s.now().UTC().Format(time.RFC3339)
		user, err := scanUser(s.db.QueryRowContext(ctx, `UPDATE users SET token = ?, updated_at = ? WHERE id = ?
RETURNING id, token, created_at, updated_at`, token, now, canonicalID))
		if err == nil {
			return user, nil
		}
		if generated && errors.Is(err, ErrTokenConflict) {
			continue
		}
		return nil, err
	}
	return nil, &FatalError{Err: fmt.Errorf("unable to generate a unique token")}
}

func (s *Store) Delete(ctx context.Context, id string) error {
	canonicalID, err := domain.CanonicalizeID(id)
	if err != nil {
		return err
	}
	result, err := s.db.ExecContext(ctx, "DELETE FROM users WHERE id = ?", canonicalID)
	if err != nil {
		return classify(err)
	}
	count, err := result.RowsAffected()
	if err != nil {
		return classify(err)
	}
	if count == 0 {
		return ErrNotFound
	}
	return nil
}

type rowScanner interface {
	Scan(...any) error
}

func scanUser(row rowScanner) (*domain.User, error) {
	var user domain.User
	if err := row.Scan(&user.ID, &user.Token, &user.CreatedAt, &user.UpdatedAt); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, classify(err)
	}
	return &user, nil
}

func classify(err error) error {
	if err == nil {
		return nil
	}
	if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
		return fmt.Errorf("%w: %v", ErrBusy, err)
	}
	var sqliteError *sqlite.Error
	if errors.As(err, &sqliteError) {
		switch sqliteError.Code() & 0xff {
		case 5, 6:
			return fmt.Errorf("%w: %v", ErrBusy, err)
		case 19:
			message := sqliteError.Error()
			switch {
			case strings.Contains(message, "users.token"):
				return fmt.Errorf("%w: %v", ErrTokenConflict, err)
			case strings.Contains(message, "users.id"):
				return fmt.Errorf("%w: %v", ErrUserConflict, err)
			default:
				return fmt.Errorf("%w: %v", ErrConflict, err)
			}
		}
	}
	return &FatalError{Err: err}
}
