package httpapi

import (
	"bytes"
	"context"
	"crypto/subtle"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"mime"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"

	"qtuser/internal/config"
	"qtuser/internal/domain"
	"qtuser/internal/store"
)

const (
	introspectionClientID     = "qtserver"
	introspectionClientSecret = "qtserver-introspection"
	maxRequestBodyBytes       = 64 * 1024
)

type API struct {
	config *config.Config
	store  *store.Store
	logger *slog.Logger
	fatal  func(error)
}

type problem struct {
	Type   string `json:"type"`
	Title  string `json:"title"`
	Status int    `json:"status"`
	Detail string `json:"detail,omitempty"`
}

type oauthError struct {
	Error string `json:"error"`
}

type introspectionResponse struct {
	Active    bool   `json:"active"`
	Sub       string `json:"sub,omitempty"`
	TokenType string `json:"token_type,omitempty"`
}

type usersResponse struct {
	Users []domain.User `json:"users"`
}

type optionalString struct {
	Value   string
	Present bool
}

func (value *optionalString) UnmarshalJSON(data []byte) error {
	value.Present = true
	if string(data) == "null" {
		return fmt.Errorf("value must be a string")
	}
	return json.Unmarshal(data, &value.Value)
}

func Run(ctx context.Context, cfg *config.Config, users *store.Store, logger *slog.Logger) error {
	if logger == nil {
		logger = slog.Default()
	}
	fatalCh := make(chan error, 1)
	reportFatal := func(err error) {
		if err == nil {
			return
		}
		select {
		case fatalCh <- err:
		default:
		}
	}
	api := &API{config: cfg, store: users, logger: logger, fatal: reportFatal}
	listener, err := net.Listen("tcp", cfg.ListenAddress())
	if err != nil {
		return fmt.Errorf("listen on %s: %w", cfg.ListenAddress(), err)
	}
	server := &http.Server{
		Handler:           api.routes(),
		ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout:       120 * time.Second,
	}
	serveErr := make(chan error, 1)
	go func() {
		err := server.Serve(listener)
		if errors.Is(err, http.ErrServerClosed) {
			err = nil
		}
		serveErr <- err
	}()
	logger.Info("qtuser HTTP service started", "address", listener.Addr().String())
	var fatalErr error
	select {
	case <-ctx.Done():
		logger.Info("shutting down qtuser HTTP service", "reason", "signal")
	case fatalErr = <-fatalCh:
		logger.Error("fatal SQLite failure; shutting down", "error_category", "database_fatal")
	case err := <-serveErr:
		return err
	}
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	if err := server.Shutdown(shutdownCtx); err != nil {
		_ = server.Close()
		if fatalErr == nil {
			return fmt.Errorf("shutdown HTTP service: %w", err)
		}
	}
	<-serveErr
	if fatalErr != nil {
		return fmt.Errorf("fatal SQLite failure: %w", fatalErr)
	}
	return nil
}

func (a *API) routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /oauth2/introspect", a.introspect)
	mux.HandleFunc("POST /api/v1/users", a.createUser)
	mux.HandleFunc("GET /api/v1/users", a.listUsers)
	mux.HandleFunc("GET /api/v1/users/{id}", a.getUser)
	mux.HandleFunc("PUT /api/v1/users/{id}/token", a.replaceToken)
	mux.HandleFunc("DELETE /api/v1/users/{id}", a.deleteUser)
	mux.HandleFunc("/api/v1/", func(w http.ResponseWriter, _ *http.Request) {
		writeProblem(w, http.StatusNotFound, "urn:qtuser:problem:not-found", "Not Found", "management API route not found")
	})
	return a.logRequests(a.managementBoundary(mux))
}

func (a *API) managementBoundary(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !strings.HasPrefix(r.URL.Path, "/api/v1/") {
			next.ServeHTTP(w, r)
			return
		}
		if peerIsLoopback(r.RemoteAddr) {
			next.ServeHTTP(w, r)
			return
		}
		if !a.config.Management.AllowRemote {
			writeProblem(w, http.StatusForbidden, "urn:qtuser:problem:remote-management-disabled", "Forbidden", "remote management is disabled")
			return
		}
		provided := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		if !strings.HasPrefix(r.Header.Get("Authorization"), "Bearer ") || !constantTimeEqual(provided, a.config.Management.Token) {
			w.Header().Set("WWW-Authenticate", "Bearer")
			writeProblem(w, http.StatusUnauthorized, "urn:qtuser:problem:invalid-management-token", "Unauthorized", "management bearer token is missing or invalid")
			return
		}
		next.ServeHTTP(w, r)
	})
}

func (a *API) logRequests(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		response := &statusWriter{ResponseWriter: w, status: http.StatusOK}
		next.ServeHTTP(response, r)
		a.logger.Info("HTTP request completed",
			"method", r.Method,
			"path", r.URL.Path,
			"peer_addr", r.RemoteAddr,
			"status", response.status,
		)
	})
}

type statusWriter struct {
	http.ResponseWriter
	status int
}

func (w *statusWriter) WriteHeader(status int) {
	w.status = status
	w.ResponseWriter.WriteHeader(status)
}

func peerIsLoopback(remoteAddress string) bool {
	host, _, err := net.SplitHostPort(remoteAddress)
	if err != nil {
		return false
	}
	ip := net.ParseIP(host)
	return ip != nil && ip.IsLoopback()
}

func constantTimeEqual(left, right string) bool {
	return subtle.ConstantTimeCompare([]byte(left), []byte(right)) == 1
}

func (a *API) introspect(w http.ResponseWriter, r *http.Request) {
	clientID, clientSecret, ok := r.BasicAuth()
	if !ok || !constantTimeEqual(clientID, introspectionClientID) || !constantTimeEqual(clientSecret, introspectionClientSecret) {
		w.Header().Set("WWW-Authenticate", "Basic")
		writeOAuthError(w, http.StatusUnauthorized, "invalid_client")
		return
	}
	mediaType, _, err := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if err != nil || mediaType != "application/x-www-form-urlencoded" {
		writeOAuthError(w, http.StatusBadRequest, "invalid_request")
		return
	}
	body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, maxRequestBodyBytes))
	if err != nil {
		writeOAuthError(w, http.StatusBadRequest, "invalid_request")
		return
	}
	form, err := url.ParseQuery(string(body))
	if err != nil || form.Get("token") == "" {
		writeOAuthError(w, http.StatusBadRequest, "invalid_request")
		return
	}
	user, err := a.store.GetByToken(r.Context(), form.Get("token"))
	if errors.Is(err, store.ErrNotFound) {
		writeJSON(w, http.StatusOK, introspectionResponse{Active: false})
		return
	}
	if err != nil {
		a.writeStoreFailure(w, err, true)
		return
	}
	writeJSON(w, http.StatusOK, introspectionResponse{Active: true, Sub: user.ID, TokenType: "Bearer"})
}

func (a *API) createUser(w http.ResponseWriter, r *http.Request) {
	var request struct {
		ID    string         `json:"id"`
		Token optionalString `json:"token,omitempty"`
	}
	if err := decodeStrictJSON(w, r, &request); err != nil {
		writeProblem(w, http.StatusBadRequest, "urn:qtuser:problem:invalid-request", "Invalid Request", "request body must contain only id and optional token")
		return
	}
	var requestedToken *string
	if request.Token.Present {
		requestedToken = &request.Token.Value
	}
	user, err := a.store.Create(r.Context(), request.ID, requestedToken)
	if err != nil {
		a.writeManagementError(w, err)
		return
	}
	writeJSON(w, http.StatusCreated, user)
}

func (a *API) listUsers(w http.ResponseWriter, r *http.Request) {
	users, err := a.store.List(r.Context())
	if err != nil {
		a.writeManagementError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, usersResponse{Users: users})
}

func (a *API) getUser(w http.ResponseWriter, r *http.Request) {
	user, err := a.store.Get(r.Context(), r.PathValue("id"))
	if err != nil {
		a.writeManagementError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, user)
}

func (a *API) replaceToken(w http.ResponseWriter, r *http.Request) {
	var request struct {
		Token optionalString `json:"token,omitempty"`
	}
	if err := decodeStrictJSON(w, r, &request); err != nil {
		writeProblem(w, http.StatusBadRequest, "urn:qtuser:problem:invalid-request", "Invalid Request", "request body must be {} or contain only token")
		return
	}
	var requestedToken *string
	if request.Token.Present {
		requestedToken = &request.Token.Value
	}
	user, err := a.store.ReplaceToken(r.Context(), r.PathValue("id"), requestedToken)
	if err != nil {
		a.writeManagementError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, user)
}

func (a *API) deleteUser(w http.ResponseWriter, r *http.Request) {
	if err := a.store.Delete(r.Context(), r.PathValue("id")); err != nil {
		a.writeManagementError(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (a *API) writeManagementError(w http.ResponseWriter, err error) {
	switch {
	case errors.Is(err, store.ErrNotFound):
		writeProblem(w, http.StatusNotFound, "urn:qtuser:problem:user-not-found", "User Not Found", "user does not exist")
	case errors.Is(err, store.ErrTokenConflict):
		writeProblem(w, http.StatusConflict, "urn:qtuser:problem:token-conflict", "Token Conflict", "token is already assigned")
	case errors.Is(err, store.ErrUserConflict), errors.Is(err, store.ErrConflict):
		writeProblem(w, http.StatusConflict, "urn:qtuser:problem:user-conflict", "User Conflict", "user already exists")
	case errors.Is(err, store.ErrBusy):
		writeProblem(w, http.StatusServiceUnavailable, "urn:qtuser:problem:database-unavailable", "Database Unavailable", "database is temporarily busy")
	case store.IsFatal(err):
		writeProblem(w, http.StatusServiceUnavailable, "urn:qtuser:problem:database-unavailable", "Database Unavailable", "database operation failed")
		a.fatal(err)
	default:
		writeProblem(w, http.StatusBadRequest, "urn:qtuser:problem:invalid-request", "Invalid Request", "request contains an invalid user id or token")
	}
}

func (a *API) writeStoreFailure(w http.ResponseWriter, err error, oauth bool) {
	if oauth {
		writeOAuthError(w, http.StatusServiceUnavailable, "temporarily_unavailable")
	} else {
		writeProblem(w, http.StatusServiceUnavailable, "urn:qtuser:problem:database-unavailable", "Database Unavailable", "database operation failed")
	}
	if store.IsFatal(err) {
		a.fatal(err)
	}
}

func decodeStrictJSON(w http.ResponseWriter, r *http.Request, destination any) error {
	mediaType, _, err := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if err != nil || mediaType != "application/json" {
		return fmt.Errorf("content type must be application/json")
	}
	body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, maxRequestBodyBytes))
	if err != nil {
		return err
	}
	body = bytes.TrimSpace(body)
	if len(body) == 0 || body[0] != '{' {
		return fmt.Errorf("request body must contain one JSON object")
	}
	decoder := json.NewDecoder(bytes.NewReader(body))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(destination); err != nil {
		return err
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return fmt.Errorf("request body must contain one JSON object")
	}
	return nil
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func writeOAuthError(w http.ResponseWriter, status int, code string) {
	writeJSON(w, status, oauthError{Error: code})
}

func writeProblem(w http.ResponseWriter, status int, problemType, title, detail string) {
	w.Header().Set("Content-Type", "application/problem+json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(problem{Type: problemType, Title: title, Status: status, Detail: detail})
}
