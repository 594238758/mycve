package domain

import (
	"fmt"
	"strings"

	"github.com/google/uuid"
)

type User struct {
	ID        string `json:"id"`
	Token     string `json:"token"`
	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
}

func CanonicalizeID(value string) (string, error) {
	if len(value) < 1 || len(value) > 128 {
		return "", fmt.Errorf("user id length must be between 1 and 128 bytes")
	}
	for index, char := range []byte(value) {
		valid := char >= 'A' && char <= 'Z' || char >= 'a' && char <= 'z' || char >= '0' && char <= '9'
		if index > 0 {
			valid = valid || char == '.' || char == '_' || char == '-'
		}
		if !valid {
			return "", fmt.Errorf("user id must match [A-Za-z0-9][A-Za-z0-9._-]{0,127}")
		}
	}
	return strings.ToLower(value), nil
}

func ValidateToken(value string) error {
	parsed, err := uuid.Parse(value)
	if err != nil || parsed.Version() != 4 || parsed.String() != value {
		return fmt.Errorf("token must be a canonical lowercase UUID v4")
	}
	return nil
}

func NewToken() (string, error) {
	value, err := uuid.NewRandom()
	if err != nil {
		return "", fmt.Errorf("generate UUID v4: %w", err)
	}
	return value.String(), nil
}
