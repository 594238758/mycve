package version

import (
	"fmt"
	"runtime/debug"
)

var Version = "dev"

func Text() string {
	version := Version
	if info, ok := debug.ReadBuildInfo(); ok && version == "dev" && info.Main.Version != "" && info.Main.Version != "(devel)" {
		version = info.Main.Version
	}
	return fmt.Sprintf("qtuser %s\n", version)
}
