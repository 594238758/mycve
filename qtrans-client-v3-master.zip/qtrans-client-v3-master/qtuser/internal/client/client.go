package client

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"qtuser/internal/domain"
)

type Client struct {
	baseURL         string
	managementToken string
	httpClient      *http.Client
}

type problem struct {
	Title  string `json:"title"`
	Status int    `json:"status"`
	Detail string `json:"detail"`
}

func New(baseURL, managementToken string) *Client {
	return &Client{
		baseURL:         strings.TrimRight(baseURL, "/"),
		managementToken: managementToken,
		httpClient:      &http.Client{Timeout: 30 * time.Second},
	}
}

func (c *Client) Create(ctx context.Context, id string, token *string) (*domain.User, error) {
	body := struct {
		ID    string  `json:"id"`
		Token *string `json:"token,omitempty"`
	}{ID: id, Token: token}
	var user domain.User
	if err := c.doJSON(ctx, http.MethodPost, "/api/v1/users", body, &user); err != nil {
		return nil, err
	}
	return &user, nil
}

func (c *Client) Get(ctx context.Context, id string) (*domain.User, error) {
	var user domain.User
	if err := c.doJSON(ctx, http.MethodGet, "/api/v1/users/"+url.PathEscape(id), nil, &user); err != nil {
		return nil, err
	}
	return &user, nil
}

func (c *Client) List(ctx context.Context) ([]domain.User, error) {
	var response struct {
		Users []domain.User `json:"users"`
	}
	if err := c.doJSON(ctx, http.MethodGet, "/api/v1/users", nil, &response); err != nil {
		return nil, err
	}
	return response.Users, nil
}

func (c *Client) ReplaceToken(ctx context.Context, id string, token *string) (*domain.User, error) {
	body := struct {
		Token *string `json:"token,omitempty"`
	}{Token: token}
	var user domain.User
	if err := c.doJSON(ctx, http.MethodPut, "/api/v1/users/"+url.PathEscape(id)+"/token", body, &user); err != nil {
		return nil, err
	}
	return &user, nil
}

func (c *Client) Delete(ctx context.Context, id string) error {
	return c.doJSON(ctx, http.MethodDelete, "/api/v1/users/"+url.PathEscape(id), nil, nil)
}

func (c *Client) doJSON(ctx context.Context, method, path string, requestBody, responseBody any) error {
	var body io.Reader
	if requestBody != nil {
		encoded, err := json.Marshal(requestBody)
		if err != nil {
			return fmt.Errorf("encode request: %w", err)
		}
		body = bytes.NewReader(encoded)
	}
	request, err := http.NewRequestWithContext(ctx, method, c.baseURL+path, body)
	if err != nil {
		return fmt.Errorf("create request: %w", err)
	}
	request.Header.Set("Accept", "application/json, application/problem+json")
	if requestBody != nil {
		request.Header.Set("Content-Type", "application/json")
	}
	if c.managementToken != "" {
		request.Header.Set("Authorization", "Bearer "+c.managementToken)
	}
	response, err := c.httpClient.Do(request)
	if err != nil {
		return fmt.Errorf("call Management API: %w", err)
	}
	defer response.Body.Close()
	limited := io.LimitReader(response.Body, 1<<20)
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		var detail problem
		if err := json.NewDecoder(limited).Decode(&detail); err != nil {
			return fmt.Errorf("Management API returned HTTP %d", response.StatusCode)
		}
		message := detail.Detail
		if message == "" {
			message = detail.Title
		}
		return fmt.Errorf("Management API returned HTTP %d: %s", response.StatusCode, message)
	}
	if responseBody == nil || response.StatusCode == http.StatusNoContent {
		return nil
	}
	if err := json.NewDecoder(limited).Decode(responseBody); err != nil {
		return fmt.Errorf("decode Management API response: %w", err)
	}
	return nil
}
