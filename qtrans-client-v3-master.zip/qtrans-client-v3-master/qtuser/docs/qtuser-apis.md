# qtuser HTTP API

`qtuser` 对外提供两组 HTTP 接口：供 Qtserver 验证用户 token 的 RFC 7662 Token Introspection，以及供管理员维护用户与 token 的 Management API。

- 默认 origin：`http://127.0.0.1:10020`
- Introspection 路径：`/oauth2/introspect`
- Management API 基础路径：`/api/v1`
- 服务不注册旧路径别名，也不提供 OAuth token 签发、登录、OIDC、JWT、scope 或角色授权
- 所有成功 JSON response 与错误 response 都设置 `Cache-Control: no-store`
- 用户 token 会由 Management API 以明文返回；调用方不得把 response 或请求认证 header 写入日志

监听地址、远程管理边界和 CLI 使用的 origin 由安装目录内的 `qtuser_config.toml` 控制。默认情况下 Management API 只接受 TCP peer 为 loopback 的请求，不信任 `Forwarded`、`X-Forwarded-For` 等代理 header。

## 公共数据结构

### 用户记录

用户记录精确包含四个 string 字段：

```json
{
  "id": "alice",
  "token": "3d797212-75fe-46fb-8707-97bd6896e4c1",
  "created_at": "2026-09-01T01:02:03Z",
  "updated_at": "2026-09-01T01:02:03Z"
}
```

字段约定：

| 字段 | 含义 |
| --- | --- |
| `id` | canonical 用户 ID；输入不区分大小写，response 一律为 ASCII lowercase |
| `token` | 当前用户唯一的明文 token，格式为 canonical lowercase UUID v4 |
| `created_at` | 创建时间，UTC RFC 3339 |
| `updated_at` | 最后一次替换 token 的时间，UTC RFC 3339 |

用户 ID 输入必须匹配 `[A-Za-z0-9][A-Za-z0-9._-]{0,127}`。服务先校验输入，再转换为 ASCII lowercase；因此 `Alice`、`ALICE` 和 `alice` 指向同一用户。用户 ID 创建后不可修改。

每个用户固定拥有一个 token，且 token 在所有用户之间全局唯一。创建用户或替换 token 时省略 token，服务会用安全随机源生成 UUID v4；显式传入时必须已经是 canonical lowercase UUID v4。

## Token Introspection

### `POST /oauth2/introspect`

该接口遵循 RFC 7662 的请求和核心 response 约定，供 Qtserver 把 bearer token 解析为用户身份。

请求必须使用：

- `Content-Type: application/x-www-form-urlencoded`
- OAuth `client_secret_basic` 认证
- form 字段 `token`，不能为空
- 可选 `token_type_hint=access_token`；服务接受并忽略该 hint

第一版固定使用以下 client identity：

```text
client_id     = qtserver
client_secret = qtserver-introspection
```

这组值编译在 Qtserver 与 qtuser 中，是公开、不可配置的协议标识，不是安全边界。

示例：

```http
POST /oauth2/introspect HTTP/1.1
Host: 127.0.0.1:10020
Authorization: Basic <base64(qtserver:qtserver-introspection)>
Content-Type: application/x-www-form-urlencoded

token=3d797212-75fe-46fb-8707-97bd6896e4c1&token_type_hint=access_token
```

已分配给用户的 token 返回 `200 application/json`：

```json
{
  "active": true,
  "sub": "alice",
  "token_type": "Bearer"
}
```

当前响应不包含 `email`，用户记录也没有邮箱字段。Qtserver 使用实际邮箱填写业务日志 `client_username` 时，接入 qtuser 的普通用户会记录空字符串，`principal_id` 仍使用 `sub`。

未知、格式错误、已被替换或已随用户删除的 token 返回 `200 application/json`，body 只包含：

```json
{
  "active": false
}
```

Introspection 错误使用 OAuth error response，不使用 Management API 的 Problem Details：

| HTTP 状态码 | `error` | 条件 |
| --- | --- | --- |
| `400` | `invalid_request` | Content-Type 错误、body 无法解析或缺少非空 `token` |
| `401` | `invalid_client` | HTTP Basic client identity 缺失或不匹配；同时返回 `WWW-Authenticate: Basic` |
| `503` | `temporarily_unavailable` | SQLite 暂时 busy/locked，或无法完成查询 |

错误示例：

```json
{
  "error": "invalid_client"
}
```

`active=false` 是成功的 token 状态，不是错误，也不会返回 401。

## Management API

Management API 使用 JSON 维护 SQLite 中的用户与 token。Loopback peer 默认不要求认证。远程 peer 的行为如下：

| 配置 | 远程请求行为 |
| --- | --- |
| `management.allow_remote=false` | 返回 `403` Problem Details |
| `management.allow_remote=true` | 要求 `Authorization: Bearer <management.token>`，缺失或不匹配返回 `401` |

远程访问可直接使用配置允许的 HTTP 地址；qtuser 不强制 HTTPS。是否通过可信网络或 TLS 保护明文用户 token 与 management token，由部署方决定。

### `POST /api/v1/users`

创建用户。请求必须使用 `Content-Type: application/json`，只允许以下两种 body：

```json
{
  "id": "Alice"
}
```

```json
{
  "id": "Alice",
  "token": "3d797212-75fe-46fb-8707-97bd6896e4c1"
}
```

省略 `token` 时自动生成。成功返回 `201 application/json` 和完整用户记录。重复 canonical ID 或 token 返回 409。

### `GET /api/v1/users`

列出所有用户，不分页。成功返回 `200 application/json`；`users` 按 canonical ID 的 bytewise ascending order 排序，每项都是完整用户记录并包含明文 token：

```json
{
  "users": [
    {
      "id": "alice",
      "token": "3d797212-75fe-46fb-8707-97bd6896e4c1",
      "created_at": "2026-09-01T01:02:03Z",
      "updated_at": "2026-09-01T01:02:03Z"
    }
  ]
}
```

没有用户时返回 `{"users":[]}`。

### `GET /api/v1/users/{id}`

按用户 ID 查询。Path 中的 ID 同样不区分大小写；成功返回 `200 application/json` 和 canonical 用户记录，不存在返回 404。

### `PUT /api/v1/users/{id}/token`

替换用户当前 token。请求必须使用 `Content-Type: application/json`。

提交空 JSON object 自动生成新 token：

```json
{}
```

提交指定 token：

```json
{
  "token": "3d797212-75fe-46fb-8707-97bd6896e4c1"
}
```

成功返回 `200 application/json` 和更新后的完整用户记录。提交成功后旧 token 立即失效；空 body、未知字段、`null` 或其他 JSON shape 返回 400。

### `DELETE /api/v1/users/{id}`

删除用户及其 token。成功返回 `204 No Content`，不存在返回 404。删除只影响 qtuser 的 SQLite row，不会删除或修改 Qtserver 中的文件、session、grant 或其他资源；删除后允许重新创建相同 canonical ID。

## Management API 错误

Management API 的非成功 response 使用 RFC 9457 Problem Details：

```http
Content-Type: application/problem+json
Cache-Control: no-store
```

```json
{
  "type": "urn:qtuser:problem:user-not-found",
  "title": "User Not Found",
  "status": 404,
  "detail": "user does not exist"
}
```

稳定错误类型如下：

| HTTP 状态码 | `type` | 条件 |
| --- | --- | --- |
| `400` | `urn:qtuser:problem:invalid-request` | Content-Type、JSON shape、用户 ID 或 token 不合法 |
| `401` | `urn:qtuser:problem:invalid-management-token` | 已启用远程管理，但远程 bearer token 缺失或不匹配 |
| `403` | `urn:qtuser:problem:remote-management-disabled` | 远程管理未启用 |
| `404` | `urn:qtuser:problem:user-not-found` | 用户不存在 |
| `404` | `urn:qtuser:problem:not-found` | Management API 路由不存在 |
| `409` | `urn:qtuser:problem:user-conflict` | canonical 用户 ID 已存在 |
| `409` | `urn:qtuser:problem:token-conflict` | token 已分配给其他用户 |
| `503` | `urn:qtuser:problem:database-unavailable` | SQLite busy/locked 或数据库操作失败 |

SQLite busy/locked 只使当前请求返回 503，服务继续运行。其他 fatal SQLite 读取、写入、损坏或 I/O 错误会尽量返回 503，然后触发进程 graceful shutdown，由 systemd 按配置重启。

## 请求解析限制

- Introspection form body 与 Management API JSON body 上限均为 64 KiB。
- Management API JSON 必须只有一个 object，拒绝未知字段和尾随第二个 JSON value。
- JSON 写请求必须明确使用 `application/json`；introspection 必须明确使用 `application/x-www-form-urlencoded`。
- 未注册的 `/api/v1/` 路由返回 404 Problem Details。
- Go HTTP router 对已注册路径自动处理错误 method；调用方不应依赖未记录 method 的 response body。
