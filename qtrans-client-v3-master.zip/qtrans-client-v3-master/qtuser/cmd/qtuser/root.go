package main

import (
	"fmt"
	"log/slog"
	"os"
	"strings"
	"text/tabwriter"

	"qtuser/internal/client"
	"qtuser/internal/config"
	"qtuser/internal/domain"
	"qtuser/internal/httpapi"
	"qtuser/internal/store"
	"qtuser/internal/version"

	"github.com/spf13/cobra"
)

func newRootCommand() *cobra.Command {
	command := &cobra.Command{
		Use:           "qtuser",
		Short:         "lightweight token registry and introspection provider",
		SilenceUsage:  true,
		SilenceErrors: true,
		Args:          cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			return command.Help()
		},
	}
	command.CompletionOptions.DisableDefaultCmd = true
	command.AddCommand(newServeCommand())
	command.AddCommand(newUserCommand())
	command.AddCommand(&cobra.Command{
		Use:   "version",
		Short: "show version information",
		Args:  cobra.NoArgs,
		Run: func(command *cobra.Command, _ []string) {
			fmt.Fprint(command.OutOrStdout(), version.Text())
		},
	})
	return command
}

func newServeCommand() *cobra.Command {
	return &cobra.Command{
		Use:   "serve",
		Short: "run the qtuser HTTP service in the foreground",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			cfg, installDir, err := config.LoadFromInstallDir()
			if err != nil {
				return err
			}
			databasePath, err := config.ResolveDatabasePath(installDir, cfg.Database.Path)
			if err != nil {
				return err
			}
			logger := newLogger(cfg.Log.Level)
			slog.SetDefault(logger)
			users, err := store.Open(command.Context(), databasePath)
			if err != nil {
				return err
			}
			defer users.Close()
			return httpapi.Run(command.Context(), cfg, users, logger)
		},
	}
}

func newLogger(level string) *slog.Logger {
	var slogLevel slog.Level
	switch strings.ToLower(strings.TrimSpace(level)) {
	case "debug":
		slogLevel = slog.LevelDebug
	case "warn":
		slogLevel = slog.LevelWarn
	case "error":
		slogLevel = slog.LevelError
	default:
		slogLevel = slog.LevelInfo
	}
	return slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: slogLevel}))
}

func newUserCommand() *cobra.Command {
	command := &cobra.Command{Use: "user", Short: "manage users through the Management API", Args: cobra.NoArgs}
	command.AddCommand(newUserCreateCommand())
	command.AddCommand(newUserGetCommand())
	command.AddCommand(newUserListCommand())
	command.AddCommand(newUserTokenCommand())
	command.AddCommand(newUserDeleteCommand())
	return command
}

func managementClient() (*client.Client, error) {
	cfg, _, err := config.LoadFromInstallDir()
	if err != nil {
		return nil, err
	}
	return client.New(cfg.Client.BaseURL, cfg.Management.Token), nil
}

func newUserCreateCommand() *cobra.Command {
	var token string
	command := &cobra.Command{
		Use:   "create <id>",
		Short: "create a user",
		Args:  cobra.ExactArgs(1),
		RunE: func(command *cobra.Command, args []string) error {
			id, err := domain.CanonicalizeID(args[0])
			if err != nil {
				return err
			}
			var requestedToken *string
			if command.Flags().Changed("token") {
				if err := domain.ValidateToken(token); err != nil {
					return err
				}
				requestedToken = &token
			}
			api, err := managementClient()
			if err != nil {
				return err
			}
			user, err := api.Create(command.Context(), id, requestedToken)
			if err != nil {
				return err
			}
			printUser(command, user)
			return nil
		},
	}
	command.Flags().StringVar(&token, "token", "", "canonical lowercase UUID v4; omitted to generate one")
	return command
}

func newUserGetCommand() *cobra.Command {
	return &cobra.Command{
		Use:   "get <id>",
		Short: "get a user and its token",
		Args:  cobra.ExactArgs(1),
		RunE: func(command *cobra.Command, args []string) error {
			id, err := domain.CanonicalizeID(args[0])
			if err != nil {
				return err
			}
			api, err := managementClient()
			if err != nil {
				return err
			}
			user, err := api.Get(command.Context(), id)
			if err != nil {
				return err
			}
			printUser(command, user)
			return nil
		},
	}
}

func newUserListCommand() *cobra.Command {
	return &cobra.Command{
		Use:   "list",
		Short: "list users and their tokens",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			api, err := managementClient()
			if err != nil {
				return err
			}
			users, err := api.List(command.Context())
			if err != nil {
				return err
			}
			writer := tabwriter.NewWriter(command.OutOrStdout(), 0, 4, 2, ' ', 0)
			fmt.Fprintln(writer, "ID\tTOKEN\tCREATED_AT\tUPDATED_AT")
			for _, user := range users {
				fmt.Fprintf(writer, "%s\t%s\t%s\t%s\n", user.ID, user.Token, user.CreatedAt, user.UpdatedAt)
			}
			return writer.Flush()
		},
	}
}

func newUserTokenCommand() *cobra.Command {
	command := &cobra.Command{Use: "token", Short: "replace a user's token", Args: cobra.NoArgs}
	command.AddCommand(&cobra.Command{
		Use:   "reset <id>",
		Short: "generate and assign a new token",
		Args:  cobra.ExactArgs(1),
		RunE: func(command *cobra.Command, args []string) error {
			return replaceUserToken(command, args[0], nil)
		},
	})
	command.AddCommand(&cobra.Command{
		Use:   "set <id> <uuid>",
		Short: "assign a specified token",
		Args:  cobra.ExactArgs(2),
		RunE: func(command *cobra.Command, args []string) error {
			if err := domain.ValidateToken(args[1]); err != nil {
				return err
			}
			token := args[1]
			return replaceUserToken(command, args[0], &token)
		},
	})
	return command
}

func replaceUserToken(command *cobra.Command, rawID string, token *string) error {
	id, err := domain.CanonicalizeID(rawID)
	if err != nil {
		return err
	}
	api, err := managementClient()
	if err != nil {
		return err
	}
	user, err := api.ReplaceToken(command.Context(), id, token)
	if err != nil {
		return err
	}
	printUser(command, user)
	return nil
}

func newUserDeleteCommand() *cobra.Command {
	return &cobra.Command{
		Use:   "delete <id>",
		Short: "delete a user and its token",
		Args:  cobra.ExactArgs(1),
		RunE: func(command *cobra.Command, args []string) error {
			id, err := domain.CanonicalizeID(args[0])
			if err != nil {
				return err
			}
			api, err := managementClient()
			if err != nil {
				return err
			}
			if err := api.Delete(command.Context(), id); err != nil {
				return err
			}
			fmt.Fprintf(command.OutOrStdout(), "deleted %s\n", id)
			return nil
		},
	}
}

func printUser(command *cobra.Command, user *domain.User) {
	writer := tabwriter.NewWriter(command.OutOrStdout(), 0, 4, 2, ' ', 0)
	fmt.Fprintf(writer, "ID\t%s\nTOKEN\t%s\nCREATED_AT\t%s\nUPDATED_AT\t%s\n", user.ID, user.Token, user.CreatedAt, user.UpdatedAt)
	_ = writer.Flush()
}
