# qtuser

`qtuser` 是供 Qtserver 使用的轻量 token registry。它以 SQLite 保存一个用户对应一个明文 UUID v4 token，并通过 RFC 7662 Token Introspection 返回 `active` 和 `sub`。它不提供登录、密码、OAuth token 签发、OIDC、scope 或业务授权。

## 安装与启动

默认把以下核心持久文件放在同一安装目录：

```text
/opt/qtuser/
├── qtuser
├── qtuser_config.toml
└── qtuser.db
```

首次启动会自动创建 `qtuser.db`。WAL mode 运行时，SQLite 会在同一目录维护 `qtuser.db-wal`、`qtuser.db-shm` 等辅助文件。整个目录包含明文 token，属于同一可信管理边界；qtuser 不在目录外创建数据、PID、cache 或日志文件。

复制 [`deploy/qtuser.service`](deploy/qtuser.service) 后，创建专用 `qtuser` OS 用户，并确保该用户可以在 `/opt/qtuser` 中创建和维护 SQLite 主数据库及辅助文件。服务以前台方式运行，日志写到 stdout/stderr，由 systemd/journald 收集。

配置文件固定名为 `qtuser_config.toml`，所有字段都必须显式存在，缺失字段和未知字段都会阻止启动。默认监听 `127.0.0.1:10020`。把 `server.host` 改为非 loopback 地址后，远程 Qtserver 可以直接使用 HTTP 调用 introspection；qtuser 不强制 HTTPS。

## Introspection API

完整请求、响应、认证、错误类型和状态码见 [`docs/qtuser-apis.md`](docs/qtuser-apis.md)。

```http
POST /oauth2/introspect
Content-Type: application/x-www-form-urlencoded
Authorization: Basic <base64(qtserver:qtserver-introspection)>

token=<uuid>&token_type_hint=access_token
```

上面的 Basic 值表示将 `qtserver:qtserver-introspection` 按 HTTP Basic 规则进行 Base64 编码，不是把带尖括号的文本原样发送。

有效 token 返回：

```json
{"active":true,"sub":"alice","token_type":"Bearer"}
```

当前 qtuser 不保存或返回用户邮箱。接入新版 Qtserver 后，普通用户业务日志中的 `client_username` 因此为空字符串，`principal_id` 仍为 `sub`；日志需要实际邮箱时，应使用能够返回 `email` 的身份服务。

无效、未知或已经被替换的 token 返回 HTTP 200：

```json
{"active":false}
```

内置 Basic client identity 是公开的协议标识，不是安全边界。SQLite 无法查询时返回 HTTP 503。

## Management API

完整 CRUD body、用户数据结构、远程访问边界和 RFC 9457 错误表见 [`docs/qtuser-apis.md`](docs/qtuser-apis.md)。

Management API 包括：

```text
POST   /api/v1/users
GET    /api/v1/users
GET    /api/v1/users/{id}
PUT    /api/v1/users/{id}/token
DELETE /api/v1/users/{id}
```

本机 TCP peer 默认无需管理 token。远程 peer 默认返回 403；只有同时设置 `management.allow_remote=true` 和非空 `management.token` 后，远程请求才能携带 `Authorization: Bearer <management-token>` 访问。服务只按真实 TCP peer 判断本机请求，不信任代理 header。

用户记录固定包含 `id`、`token`、`created_at` 和 `updated_at`。Management API 和 CLI 会按产品设计返回完整明文 token。业务错误使用 RFC 9457 Problem Details。

## CLI

CLI 从安装目录读取同一个 `qtuser_config.toml`，并通过 `client.base_url` 调用 Management API，不直接打开 SQLite：

```shell
qtuser user create Alice
qtuser user create alice --token 3d797212-75fe-46fb-8707-97bd6896e4c1
qtuser user get alice
qtuser user list
qtuser user token reset alice
qtuser user token set alice 3d797212-75fe-46fb-8707-97bd6896e4c1
qtuser user delete alice
```

用户 ID 输入不区分大小写，保存和输出时统一为 ASCII lowercase。删除用户只删除 qtuser 中的记录，不操作 Qtserver 文件或其他业务资源。
