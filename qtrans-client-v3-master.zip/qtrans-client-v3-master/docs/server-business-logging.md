# QTrans 服务端业务日志

## 原始日志

两个原始业务日志的位置如下：

| 日志 | 目录 | 文件名 |
| --- | --- | --- |
| Qtserver 业务日志 | 配置项 `log.file_path` 指定的目录 | `business-events.jsonl` |
| Nginx 普通下载业务日志 | `/xxxx/nginx/logs` | `download_events.log` |

日志采用 JSON Lines 格式：一行就是一条完整事件。一共有 7 类事件，本文逐类列出，不需要在多个字段分组之间自行拼接。

原始事件时间固定使用 `YYYY-MM-DDTHH:mm:ss.SSS±HH:MM`，按 producer 主机本地时区输出，例如 `2026-09-17T16:30:46.806+08:00`。Qtserver 与 Nginx 不需要额外配置时区。

普通上传通常依次出现：

```text
file.registered
upload.chunk_finished（可有多条）
upload.verify_finished（可有多条）
upload.finished
```

普通下载通常依次出现：

```text
file.registered
download.chunk_finished（可有多条）
download.verify_finished（可有多条）
```

Small 下载只需要一条：

```text
download.small_file_sent
```

每条事件外层都有以下 8 个字段，区别主要在 `payload`：

| 字段 | 说明 |
| --- | --- |
| `schema_version` | 日志格式版本，当前固定为 `1`。 |
| `event_type` | 本条日志的事件类型。 |
| `occurred_at` | 事件完成时间，使用服务端主机本地时区、三位毫秒和数字时区偏移。 |
| `task_id` | qtransc 任务 ID。 |
| `taskpid` | 外部任务关联值；未提供时为空字符串。 |
| `enterprise_id` | 企业业务关联值；未提供时为空字符串。 |
| `file_key` | 一次文件上传或下载活动的稳定关联键。 |
| `payload` | 当前事件的具体字段，下面按 7 类事件分别说明。 |

`client_username` 记录用户邮箱，例如 `user@example.com`；`principal_id` 仍记录稳定用户标识。没有邮箱时写 `"client_username":""`，不省略或写 `null`；匿名用户写 `"client_username":"anonymous"`。客户端提交的登录名或邮箱不会覆盖认证结果。

格式版本仍为 `1`。升级日志接收方时，需要允许 `client_username` 为空字符串。历史日志中的用户 ID 保留原值；同一文件的最终日志沿用首次有效注册时的值，Small 下载沿用本次成功事件的值，不按当前邮箱回填。

### 1. `file.registered`

普通上传或普通下载开始时记录一次文件上下文。请求重试时可能出现内容相同的重复记录。

`payload` 字段：

| 字段 | 说明 |
| --- | --- |
| `task_type` | 部署场景：`"0"` 表示多中心，`"1"` 表示 C/S。 |
| `action` | `upload` 或 `download`。 |
| `file_path` | 服务端规范化后的逻辑文件路径。 |
| `file_size` | 文件大小，单位 bytes。 |
| `principal_id` | Qtserver 认证得到的用户标识。 |
| `client_username` | 认证得到的用户邮箱；未提供邮箱时为空字符串，匿名用户固定为 `anonymous`。 |
| `client_id` | qtransc 的持久设备标识。 |
| `client_ip` | 服务端观察到的客户端 IP。 |
| `client_os` | qtransc 所在操作系统。 |
| `client_version` | 实际执行传输的 qtransc 版本。 |
| `caller_version` | 创建任务的 GUI 或 agent 版本；未提供时为空字符串。 |
| `server_ip` | 本次请求进入 QTrans 的服务端入口 IP。 |
| `server_instance` | Qtserver 实例标识。 |
| `server_version` | Qtserver 版本。 |
| `file_inactivity_timeout_seconds` | 该文件无活动超时时间，单位秒。 |

示例：

```json
{
  "schema_version": 1,
  "event_type": "file.registered",
  "occurred_at": "2026-09-17T16:30:46.806+08:00",
  "task_id": "caller-version-upload",
  "taskpid": "",
  "enterprise_id": "",
  "file_key": "-Q_Ib8mAZFs9nL5ulTWryIY4KSdBO4fCDNrpkJHPH50",
  "payload": {
    "task_type": "1",
    "action": "upload",
    "file_path": "/caller-version-e2e.txt",
    "file_size": 29,
    "principal_id": "e2e-user",
    "client_username": "user@example.com",
    "client_id": "qtc1_example",
    "client_ip": "172.22.0.5",
    "client_os": "linux",
    "client_version": "dev",
    "caller_version": "cw 0.8.3",
    "server_ip": "172.17.0.1",
    "server_instance": "qtserver-e2e",
    "server_version": "dev",
    "file_inactivity_timeout_seconds": 86400
  }
}
```

### 2. `upload.chunk_finished`

一次上传分片 attempt 结束时记录。失败或中断的 attempt 也会记录。

`payload` 字段：

| 字段 | 说明 |
| --- | --- |
| `chunk_index` | 分片编号，从 `0` 开始。 |
| `range_start` | 分片起点，单位 bytes，包含该位置。 |
| `range_end` | 分片终点，单位 bytes，不包含该位置。 |
| `actual_bytes` | 本次 attempt 实际收到的 bytes。 |
| `result` | `succeeded`、`interrupted` 或 `failed`。 |

示例：

```json
{
  "schema_version": 1,
  "event_type": "upload.chunk_finished",
  "occurred_at": "2026-09-17T16:30:46.813+08:00",
  "task_id": "caller-version-upload",
  "taskpid": "",
  "enterprise_id": "",
  "file_key": "-Q_Ib8mAZFs9nL5ulTWryIY4KSdBO4fCDNrpkJHPH50",
  "payload": {
    "chunk_index": 0,
    "range_start": 0,
    "range_end": 29,
    "actual_bytes": 29,
    "result": "succeeded"
  }
}
```

### 3. `upload.verify_finished`

一次上传分片校验结束时记录。

`payload` 字段：

| 字段 | 说明 |
| --- | --- |
| `chunk_index` | 被校验的上传分片编号。 |
| `verification_result` | `matched`、`mismatched` 或 `failed`。 |

示例：

```json
{
  "schema_version": 1,
  "event_type": "upload.verify_finished",
  "occurred_at": "2026-09-17T16:30:46.815+08:00",
  "task_id": "caller-version-upload",
  "taskpid": "",
  "enterprise_id": "",
  "file_key": "-Q_Ib8mAZFs9nL5ulTWryIY4KSdBO4fCDNrpkJHPH50",
  "payload": {
    "chunk_index": 0,
    "verification_result": "matched"
  }
}
```

### 4. `upload.finished`

整个上传文件成功提交时记录。

`payload` 字段：

| 字段 | 说明 |
| --- | --- |
| `result` | `committed` 表示本次完成提交；`already_present` 表示服务端已存在相同内容。 |

示例：

```json
{
  "schema_version": 1,
  "event_type": "upload.finished",
  "occurred_at": "2026-09-17T16:30:46.818+08:00",
  "task_id": "caller-version-upload",
  "taskpid": "",
  "enterprise_id": "",
  "file_key": "-Q_Ib8mAZFs9nL5ulTWryIY4KSdBO4fCDNrpkJHPH50",
  "payload": {
    "result": "committed"
  }
}
```

### 5. `download.chunk_finished`

一次普通下载分片响应结束时记录。使用 X-Accel 下载时，这类事件由 Nginx 根据实际响应结果写入 `download_events.log`；其他事件仍由 Qtserver 写入 `business-events.jsonl`。

`payload` 字段：

| 字段 | 说明 |
| --- | --- |
| `chunk_index` | 分片编号，从 `0` 开始。 |
| `range_start` | 分片起点，单位 bytes，包含该位置。 |
| `range_end` | 分片终点，单位 bytes，不包含该位置。 |
| `actual_bytes` | 本次响应实际发送的 bytes。 |
| `http_status` | 本次下载响应的 HTTP 状态码。 |
| `result` | `succeeded`、`interrupted` 或 `failed`。 |

示例：

```json
{
  "schema_version": 1,
  "event_type": "download.chunk_finished",
  "occurred_at": "2026-09-17T16:30:47.026+08:00",
  "task_id": "6cb0d2c2-67b3-4538-a4c6-4ecaf1792665",
  "taskpid": "",
  "enterprise_id": "",
  "file_key": "rl0tuMznF5DTWiah0pTZGSSY75-XFOF2-CDqVUIfp9g",
  "payload": {
    "chunk_index": 0,
    "range_start": 0,
    "range_end": 5242880,
    "actual_bytes": 5242880,
    "http_status": 206,
    "result": "succeeded"
  }
}
```

### 6. `download.verify_finished`

下载分片校验或整文件校验结束时记录。

`payload` 字段：

| 字段 | 说明 |
| --- | --- |
| `verification_scope` | `chunk` 表示分片校验，`file` 表示整文件校验。 |
| `chunk_index` | 分片校验时为分片编号；整文件校验时为 `null`。 |
| `verification_result` | `matched`、`mismatched` 或 `failed`。 |

示例：

```json
{
  "schema_version": 1,
  "event_type": "download.verify_finished",
  "occurred_at": "2026-09-17T16:30:52.038+08:00",
  "task_id": "6cb0d2c2-67b3-4538-a4c6-4ecaf1792665",
  "taskpid": "",
  "enterprise_id": "",
  "file_key": "rl0tuMznF5DTWiah0pTZGSSY75-XFOF2-CDqVUIfp9g",
  "payload": {
    "verification_scope": "file",
    "chunk_index": null,
    "verification_result": "matched"
  }
}
```

### 7. `download.small_file_sent`

Small 下载中的一个文件已经完整写入响应时记录。它不再另外产生 `file.registered`、`download.chunk_finished` 或 `download.verify_finished`。

`payload` 字段：

| 字段 | 说明 |
| --- | --- |
| `task_type` | 部署场景：`"0"` 表示多中心，`"1"` 表示 C/S。 |
| `action` | 固定为 `download`。 |
| `file_path` | 服务端规范化后的逻辑文件路径。 |
| `file_size` | 文件大小，单位 bytes。 |
| `principal_id` | Qtserver 认证得到的用户标识。 |
| `client_username` | 认证得到的用户邮箱；未提供邮箱时为空字符串，匿名用户固定为 `anonymous`。 |
| `client_id` | qtransc 的持久设备标识。 |
| `client_ip` | 服务端观察到的客户端 IP。 |
| `client_os` | qtransc 所在操作系统。 |
| `client_version` | 实际执行传输的 qtransc 版本。 |
| `caller_version` | 创建任务的 GUI 或 agent 版本；未提供时为空字符串。 |
| `server_ip` | 本次请求进入 QTrans 的服务端入口 IP。 |
| `server_instance` | Qtserver 实例标识。 |
| `server_version` | Qtserver 版本。 |
| `started_at` | 这个 Small 文件开始写入响应的时间，格式与 `occurred_at` 相同。 |

示例：

```json
{
  "schema_version": 1,
  "event_type": "download.small_file_sent",
  "occurred_at": "2026-09-17T16:30:52.051+08:00",
  "task_id": "46e898bb-e911-4d25-8ab2-fa37fbb4144b",
  "taskpid": "",
  "enterprise_id": "",
  "file_key": "Zi5qmVPcHMFMyrQEw353SS8AbFCCbXHpjINWF5OW-MM",
  "payload": {
    "task_type": "1",
    "action": "download",
    "file_path": "/small-e2e.txt",
    "file_size": 20,
    "principal_id": "e2e-user",
    "client_username": "user@example.com",
    "client_id": "qtc1_example",
    "client_ip": "172.22.0.5",
    "client_os": "linux",
    "client_version": "dev",
    "caller_version": "",
    "server_ip": "172.17.0.1",
    "server_instance": "qtserver-e2e",
    "server_version": "dev",
    "started_at": "2026-09-17T16:30:52.051+08:00"
  }
}
```

## 最终日志

最终业务日志按单个文件活动生成，每个 `file_key` 只保留一条当前结论。它不是 Qtserver 直接写出的原始事件，但仍在本文中维护，方便使用方在同一份文档中理解原始输入和最终结果。

最终日志共有 25 个字段：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `task_type` | string | 部署场景：`"0"` 表示多中心，`"1"` 表示 C/S。 |
| `server_ip` | string | 文件第一次进入系统时使用的可信服务端入口 IP。 |
| `task_id` | string | qtransc 任务 ID。 |
| `taskpid` | string | 外部任务关联值；未提供时为空字符串。 |
| `enterprise_id` | string | 企业业务关联值；未提供时为空字符串。 |
| `client_id` | string | qtransc 的持久设备标识。 |
| `client_ip` | string | 服务端观察到的客户端 IP。 |
| `client_os` | string | qtransc 所在操作系统。 |
| `client_version` | string | 实际执行传输的 qtransc 版本。 |
| `caller_version` | string | 创建任务的 GUI 或 agent 版本；未提供时为空字符串。 |
| `client_username` | string | 认证得到的用户邮箱；未提供邮箱时为空字符串，匿名用户固定为 `anonymous`。 |
| `action` | string | `upload` 或 `download`。 |
| `transmitted` | integer | 有原始完成事件证明的实际文件内容传输字节总和。 |
| `file_path` | string | 服务端规范化后的逻辑文件路径。 |
| `file_size` | integer | 文件大小，单位 bytes。 |
| `start_time` | string | 文件活动开始时间，UTC、三位毫秒。 |
| `end_time` | string | 权威成功事实发生时间或超时截止时间，UTC、三位毫秒。 |
| `duration` | number | `end_time - start_time` 的秒数，保留三位小数。 |
| `log_time` | string | 当前结果首次写入或最近一次实际修订的时间，UTC、三位毫秒。 |
| `file_key` | string | 文件活动的稳定关联键，也是当前结果的唯一键。 |
| `principal_id` | string | Qtserver 认证得到的用户标识。 |
| `result` | string | `SUCCESS` 或 `FAILED`。 |
| `result_reason` | string | 稳定的结果原因码，取值见下表。 |
| `retry_count` | integer | 相同分片编号的额外数据传输 attempt 数量之和。 |
| `speed` | number/null | 成功文件的端到端有效速度，单位 bytes/s；不可计算时为 `null`。 |

允许的 `result` 与 `result_reason` 组合只有：

| `result` | `result_reason` | 说明 |
| --- | --- | --- |
| `SUCCESS` | `UPLOADED_AND_COMMITTED` | 上传文件已经成功提交。 |
| `SUCCESS` | `ALREADY_PRESENT` | 服务端已经存在内容相同的文件。 |
| `SUCCESS` | `DOWNLOADED_AND_VERIFIED` | 普通下载已完成整文件校验。 |
| `SUCCESS` | `SMALL_FILE_SENT` | Small 文件已经由服务端完整发送。 |
| `FAILED` | `TIMEOUT` | 普通文件活动超过无活动期限且没有成功事实。 |

示例：

```json
{
  "task_type": "1",
  "server_ip": "172.17.0.1",
  "task_id": "caller-version-upload",
  "taskpid": "",
  "enterprise_id": "",
  "client_id": "qtc1_example",
  "client_ip": "172.22.0.5",
  "client_os": "linux",
  "client_version": "dev",
  "caller_version": "agent 1.0.0",
  "client_username": "user@example.com",
  "action": "upload",
  "transmitted": 29,
  "file_path": "/caller-version-e2e.txt",
  "file_size": 29,
  "start_time": "2026-09-17T08:30:46.806Z",
  "end_time": "2026-09-17T08:30:46.818Z",
  "duration": 0.012,
  "log_time": "2026-09-17T08:31:00.000Z",
  "file_key": "-Q_Ib8mAZFs9nL5ulTWryIY4KSdBO4fCDNrpkJHPH50",
  "principal_id": "e2e-user",
  "result": "SUCCESS",
  "result_reason": "UPLOADED_AND_COMMITTED",
  "retry_count": 0,
  "speed": 2416.667
}
```

## 特殊说明

### `caller_version`

`caller_version` 表示创建任务的外部调用者及其版本。调用者可以是 GUI、agent，也可以是其他上层程序。推荐按照 `<调用者标识> <版本号>` 的格式填写，例如 `"cw 0.8.3"`、`"agent 1.0.0"`。

QTrans 不拆分或解释其中的调用者标识和版本号，也不会根据该字段改变认证、授权或传输行为。该值仅作为一个完整字符串透传并记录到业务日志中；未提供时记录为空字符串 `""`。
