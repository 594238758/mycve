# MCD QTrans 部署

本部署包含两台 Qtserver 和两台 Nginx，由 LVS 提供统一入口。两台 Qtserver 共享 Redis 和业务数据目录，只提供 anonymous 下载，不配置普通用户、身份服务或上传能力。

## 1. Qtserver 部署

### 1.1 Docker 启动 Redis

Redis 是 Qtserver 唯一的共享状态依赖，本部署主要使用其中的 hash cache 和协调状态。即使关闭上传能力，也必须使用持久 volume、AOF `everysec`、`noeviction` 和最小 ACL，Qtserver 启动时会校验这些条件。

在 Redis 宿主机执行：

```bash
export QTSERVER_INFRA_LISTEN_IP="<infra-listen-ip>"
export QTSERVER_REDIS_PASSWORD="<redis-password>"

sudo install -d -m 0750 /opt/qtrans/redis
sudo install -d -m 0700 /opt/qtrans/redis/data
sudo install -m 0644 qtserver/deploy/redis.conf /opt/qtrans/redis/redis.conf
sudo install -m 0600 qtserver/deploy/qtserver-users.acl /opt/qtrans/redis/qtserver-users.acl
sudoedit /opt/qtrans/redis/qtserver-users.acl

sudo docker run -d \
  --name qtserver-redis \
  --restart unless-stopped \
  --publish "${QTSERVER_INFRA_LISTEN_IP}:6379:6379" \
  --mount type=bind,src=/opt/qtrans/redis/data,dst=/data \
  --mount type=bind,src=/opt/qtrans/redis/redis.conf,dst=/usr/local/etc/redis/redis.conf,readonly \
  --mount type=bind,src=/opt/qtrans/redis/qtserver-users.acl,dst=/usr/local/etc/redis/qtserver-users.acl,readonly \
  redis:7-alpine redis-server /usr/local/etc/redis/redis.conf
```

检查 Redis：

```bash
sudo docker exec -e REDISCLI_AUTH="${QTSERVER_REDIS_PASSWORD}" qtserver-redis redis-cli PING
sudo docker exec -e REDISCLI_AUTH="${QTSERVER_REDIS_PASSWORD}" qtserver-redis \
  redis-cli CONFIG GET appendonly appendfsync maxmemory-policy
sudo docker exec -e REDISCLI_AUTH="${QTSERVER_REDIS_PASSWORD}" qtserver-redis redis-cli INFO persistence
```

返回 `PONG`，且配置为 `appendonly yes`、`appendfsync everysec`、`maxmemory-policy noeviction`、AOF 最近写入状态正常才可启动 Qtserver。宿主机的 6379 端口必须限制在 Qtserver 和运维节点可访问的可信网络内。

### 1.2 准备数据源

Qtserver 使用 `server.user_home_root` 作为用户家目录的共同根目录。它本身不是用户家目录，实际文件空间位于 `<user_home_root>/<principal_id>/`。

本部署固定使用内置用户 `anonymous`：

| 用户看到的逻辑路径 | 服务器上的实际路径 |
| --- | --- |
| `/docs/a.txt` | `/opt/qtrans/qtserver/data/users/anonymous/docs/a.txt` |

客户端访问 `/` 时看到的是 `/opt/qtrans/qtserver/data/users/anonymous`，不会看到上一级 `users`。anonymous 下载不携带认证信息，Qtserver 也不会访问身份或授权服务。`anonymous` 家目录必须是真实目录，不能使用 symlink。

文件系统中的内容就是 Qtserver 的正式数据源。需要对外提供的业务数据全部放到：

```text
/opt/qtrans/qtserver/data/users/anonymous/
```

两台 Qtserver 必须把同一个共享文件系统挂载到相同路径：

```text
/opt/qtrans/qtserver/data/
`-- users/
    `-- anonymous/
```

在两台 Qtserver 上分别执行：

```bash
sudo install -d -m 0755 /opt/qtrans/qtserver/data
sudo mount <shared-filesystem-source> /opt/qtrans/qtserver/data
sudo install -d -m 0755 /opt/qtrans/qtserver/data/users/anonymous
```

把已有数据复制到 anonymous 家目录，并保留原有目录层级。生产环境应通过 `/etc/fstab` 或 systemd mount unit 自动挂载，并保证挂载完成后再启动 Qtserver。两台 Qtserver 和两台 Nginx 必须能读取同一份数据。

### 1.3 安装及配置 Qtserver

从仓库根目录构建，然后在两台 Qtserver 上安装：

```bash
make -C qtserver build

sudo install -d -m 0755 /opt/qtrans/qtserver
sudo install -m 0755 qtserver/bin/qtserver /opt/qtrans/qtserver/qtserver
```

创建配置文件：

```bash
sudoedit /opt/qtrans/qtserver/qtserver_config.toml
```

写入以下完整配置。将 `<...>` 替换为实际值，具体见配置后的字段清单。

```toml
[server]
host = "127.0.0.1"
port = 10001
trusted_proxies = ["127.0.0.1", "::1"]
user_home_root = "/opt/qtrans/qtserver/data/users"
# temp_root = "/opt/qtrans/qtserver/data/upload-temp"
read_enabled = true
write_enabled = false
anonymous_enabled = true
nginx_acc = "/qtserver/internal-download"

[redis]
addr = "<infra-host>:6379"
password = "<redis-password>"
db = 0
key_prefix = "qtserver"

[transfer]
hmac_secret = "<same-long-random-secret-on-both-nodes>"
grant_ttl_seconds = 900
max_download_files = 1000
max_small_files = 100
max_small_total_bytes = 134217728
max_small_file_bytes = 4194304
file_hash_revalidate_seconds = 86400
file_hash_retention_seconds = 2592000
hash_worker_count = 2
hash_queue_size = 1000
upload_session_retention_seconds = 86400

[identity]
mode = "off"
auth_base_url = ""
introspection_endpoint = ""
fake_tokens = {}
timeout_seconds = 5
userinfo_cache_ttl_seconds = 10

[log]
level = "info"
file_path = "/opt/qtrans/qtserver/logs"
task_type = "0"
file_inactivity_timeout_seconds = 86400

[log.rotation]
enable = true
max_size = 100
max_backups = 7
max_age = 30
compress = true
```

`instance_id` 由主机名自动生成；正常请求经过本机 Nginx 时，业务日志中的服务端 IP 来自 Nginx，因此不需要手工配置 `external_ip`。

部署前必须调整以下字段：

| 字段 | 如何填写 | 两台 Qtserver 的关系 |
| --- | --- | --- |
| `redis.addr` | Redis 宿主机的 `<地址>:6379` | 保持相同 |
| `redis.password` | 与 Redis ACL 中的强随机密码保持一致 | 必须相同 |
| `transfer.hmac_secret` | 生成并填写一个长随机字符串；该字段缺失或使用程序默认值时配置校验会失败 | 必须相同 |

以下字段只在部署环境变化时调整：

| 字段 | 调整场景 |
| --- | --- |
| `server.host`、`server.port` | Qtserver 不再监听本机 `127.0.0.1:10001` |
| `server.user_home_root` | anonymous 数据改用其他挂载路径；两台机器必须保持相同 |
| `redis.db`、`redis.key_prefix` | Redis 需要与其他环境隔离；两台机器必须保持相同 |

`write_enabled = false` 会关闭上传和文件修改路由。`temp_root` 已注释，上传 session 参数虽然保留默认值，但本部署不会使用或创建上传缓存目录。`identity.mode = "off"` 表示不解析普通用户，也不会连接任何身份或授权服务；配置中也不包含只适用于普通用户的 `[[server.user_home_init_dirs]]`。

其余字段保持示例值。完整字段说明见 [Qtserver 配置文档](../qtserver/docs/config.md)。

分别校验两台机器的配置：

```bash
/opt/qtrans/qtserver/qtserver config validate \
  -c /opt/qtrans/qtserver/qtserver_config.toml
```

把仓库中的 [systemd unit](../qtserver/deploy/qtserver.service) 安装到两台机器：

```bash
sudo install -m 0644 qtserver/deploy/qtserver.service \
  /etc/systemd/system/qtserver.service
sudo systemctl daemon-reload
sudo systemctl enable --now qtserver
sudo systemctl status qtserver
```

升级顺序和 Redis 持久化要求见 [Qtserver 部署说明](../qtserver/docs/deploy.md)。

### 1.4 配置 Nginx

每台 Qtserver 配置一套本机 Nginx，并回源到 `127.0.0.1:10001`。可使用仓库中的 [Nginx 配置模板](../qtserver/deploy/nginx.conf)，配置相同的服务域名、证书和私钥。

生成的两个文件需要分别包含在 Nginx 的 `http` 块和业务 `server` 块中：

```nginx
http {
    include /opt/qtrans/qtserver/qtserver_http.conf;

    server {
        include /opt/qtrans/qtserver/qtserver_locations.conf;
    }
}
```

在两台机器分别生成配置并检查 Nginx：

```bash
sudo /opt/qtrans/qtserver/qtserver config gennginx \
  -c /opt/qtrans/qtserver/qtserver_config.toml

sudo /opt/qtrans/nginx/sbin/nginx -t \
  -p /opt/qtrans/nginx \
  -c conf/nginx.conf
```

检查通过后启动或重载 Nginx。LVS 需要把服务 VIP 的 443/TCP 和 443/UDP 都转发到两台 Nginx，以同时支持 HTTPS 和 QUIC。

## 2. qtransc 部署

构建 Linux AMD64 版本：

```bash
make -C qtransc linux-amd64
```

安装二进制：

```bash
sudo install -d -m 0755 /opt/qtrans/qtransc
sudo install -m 0755 qtransc/bin/release/qtransc-linux-amd64 \
  /opt/qtrans/qtransc/qtransc
sudo ln -s /opt/qtrans/qtransc/qtransc /usr/local/bin/qtransc
```

qtransc 只作为命令行工具使用时不需要注册 systemd 服务。当前 Qtserver 只提供 anonymous 下载，不需要配置 token：

```bash
qtransc --server <service-domain> list /
qtransc --server <service-domain> list /docs
qtransc --server <service-domain> download /docs/file.bin -d ./downloads
```

上传、创建目录、移动和删除均已由 Qtserver 配置关闭。如果需要对外提供 qtransc GUI/API，再使用 `qtransc serve` 启动服务。完整命令参数见 [qtransc CLI 使用手册](../qtransc/docs/qtransc-cli-guide.md)，API 见 [qtransc API 文档](../qtransc/docs/qtransc-apis.md)。
