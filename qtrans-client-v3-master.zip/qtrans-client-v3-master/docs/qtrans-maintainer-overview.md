# qtrans 技术与运维总览

> 面向第一次接手本项目的开发者或运维人员。本文解释当前仓库中的组件、数据流、配置与排障边界；它是导读和运行手册，不替代 OpenSpec 的行为契约，也不保存任何实际环境的地址、账号或密钥。

## 1. 先建立正确的全局认识

qtrans 是一个文件传输系统，而不是单个二进制：客户端负责规划和执行传输，服务端负责认证、文件空间、断点续传和状态协调，Nginx 负责 TLS 网关与高效下载数据面，Redis 保存共享控制状态，文件本体保存在服务端文件系统。

```text
qtransc / 旧桌面端
        |
        | HTTPS、HTTP/2 或 HTTP/3
        v
      Nginx ------------------> 用户文件目录（下载数据面，X-Accel-Redirect）
        |
        | /qtserver/v1/
        v
    qtserver -----------------> Redis（共享控制状态）
        |  \
        |   +------------------> qtuser 或既有身份服务（可选）
        |
        +----------------------> 用户文件目录、上传临时目录、业务日志
```

阅读和决策时的权威顺序如下：

1. `openspec/specs/` 是行为契约；实现与其冲突时，以 OpenSpec 为准。
2. OpenSpec 未覆盖的实现细节，以当前代码为准。
3. `docs/`、README 是导读，不应反过来覆盖前两者。

重要规格入口：

- [文件管理与任务状态](../openspec/specs/file-management/spec.md)
- [可续传上传](../openspec/specs/resumable-upload/spec.md)
- [正式文件 hash](../openspec/specs/file-hash-management/spec.md)
- [服务发现与依赖故障策略](../openspec/specs/service-capability-discovery/spec.md)
- [原始业务日志](../openspec/specs/raw-business-event-log/spec.md)

## 2. 代码仓库与主要技术

| 模块/组件 | 作用 | 维护时需要知道的技术 |
| --- | --- | --- |
| `qtransc` | 命令行客户端、本地 `serve` API、旧桌面端兼容入口 | Go、Cobra、Gin、SQLite、HTTP/1.1/2/3、QUIC、WebSocket、XXH3 |
| `qtserver` | 控制面与传输 API | Go、Gin、Redis、POSIX 文件系统、Lua、HMAC、Nginx X-Accel-Redirect |
| `qtuser` | 可选的轻量 token registry 与 RFC 7662 introspection provider | Go、SQLite、HTTP Basic、RFC 7662 |
| Nginx | TLS/HTTP 网关、HTTP/2/HTTP/3 接入、内部下载数据面、下载完成事件 | Nginx 配置、证书、文件读取权限、主机时区 |
| Redis | qtserver 唯一共享状态依赖 | AOF、TTL、Lua、ACL、持久化与内存策略 |

根目录 `make build` 只构建 `qtransc` 和 `qtserver`。`qtuser` 是独立的 Go module，发布或部署它时需要在对应目录单独构建。当前 `qtransc` 要求 Go 1.26，`qtserver` 和 `qtuser` 要求 Go 1.25；统一构建机应满足其中较高版本。

值得优先熟悉的库与概念：

- **Cobra**：命令、位置参数和 flags 的解析。`qtransc` 的人机交互从这里开始。
- **Gin**：`qtransc serve`、`qtserver` 与 `qtuser` 的 HTTP handler 框架。
- **Viper/TOML**：qtserver 配置读取与严格校验。
- **go-redis/v9**：Redis 客户端；正式 hash 的关键状态转换使用 Redis Lua 脚本完成原子操作。
- **modernc.org/sqlite**：纯 Go SQLite。客户端用它定位未完成上传 session；qtuser 用它保存用户 token。
- **quic-go 与 `x/net/http2`**：qtransc 支持 HTTPS、HTTPS2 和 HTTPS3 三种传输实现。
- **XXH3-128 / layered hash**：上传分块校验和正式文件校验的共同基础；上传 chunk 固定为 100 MiB。

## 3. 业务与数据流

### 3.1 上传

1. qtransc 先访问 capabilities，解析远端路径并规划目录树。
2. 客户端调用 canonical upload API 创建或恢复 session。
3. 文件内容写入 qtserver `temp_root` 中的稀疏临时文件；session、chunk offset、chunk hash 等控制事实写入 Redis。
4. 每个 100 MiB chunk 完成后分别校验；全部 verified 后，`complete` 将临时文件原子发布到用户目录。
5. 发布后，服务写入正式 hash 的已知结果；qtransc 删除本地恢复行并 best-effort `release` 服务端 session。

暂停、网络中断或 Ctrl+C 不等于取消：正常情况下会保留服务端 active session 和客户端恢复状态；显式放弃或本地源文件改变才会取消旧 session。详见 [resumable-upload Spec](../openspec/specs/resumable-upload/spec.md) 与 [qtransc 设计说明](../qtransc/docs/DESIGN.md)。

### 3.2 下载

- 小文件走批量 `/d/small`；当前阈值为单文件 4 MiB、每批最多 100 个文件和 128 MiB。
- 大文件走 `grant -> down -> verify`。Nginx 根据 qtserver 返回的 `X-Accel-Redirect` 直接读取受控用户目录中的文件，避免由 Go 应用中转整个响应体。
- 下载进度保存在目标文件旁的 `.progress`，不使用上传 SQLite 数据库。

### 3.3 身份与文件空间

qtserver 把文件空间按可信 `principal_id` 隔离，物理路径为 `<user_home_root>/<principal_id>`。身份模式由 `[identity]` 决定：

- `off`：拒绝普通用户身份，是模板默认的安全状态。
- `fake`：开发/联调静态 token，不应用于生产。
- `auth`：调用既有 `/userinfo` 服务，并在 Redis 保存短期结果。
- `oauth2-introspection`：调用 qtuser 或其他 RFC 7662 provider；其不可用被视为致命依赖。

`anonymous` 是显式配置的内置 principal，不应误解为“没有任何权限控制”。是否允许它读写由 qtserver 的配置和 capability 决定。

业务日志把稳定身份和展示信息分开：`principal_id` 继续决定文件归属和事件关联，`client_username` 使用可信身份结果中的邮箱；邮箱不可用时为空字符串，匿名用户固定为 `anonymous`。`auth` 从 `/userinfo` 读取并缓存 ID 和邮箱，`oauth2-introspection` 使用同次响应的可选 `email`。当前 `fake` 和 `qtuser` 不提供独立邮箱。接收日志的组件必须允许空邮箱，历史日志不回填。详细契约见[业务日志设计](server-business-logging-design.md)。

## 4. Redis：本项目最重要的运维依赖

### 4.1 Redis 在这里是什么，不是什么

Redis 在本项目中是 **qtserver 的唯一共享控制状态源**，不是可随意执行 `FLUSHDB` 的普通缓存。它不保存用户文件 bytes；文件本体仍在用户目录和上传临时目录中。

Redis 中主要有以下几类带 `key_prefix` 前缀的记录：

| 类别 | 保存的事实 | 丢失或误清理的影响 |
| --- | --- | --- |
| canonical upload session/chunk | session、分块状态、确认 offset、发布结果与 retention | 断点续传可能无法恢复；临时文件后续由 orphan scanner 清理 |
| transfer grant | 下载授权的短期令牌 | 正在使用的授权链接失效，可按协议重新申请 |
| 正式 hash | 文件指纹、hash 记录、待处理队列、worker lease、generation | 缓存会重建；不能让旧 worker 把过期结果写回 |
| 分布式协调锁 | namespace mutation、session terminal operation、orphan cleanup | 并发操作可能冲突；锁记录本身均有短 TTL |
| 身份缓存 | `auth` 模式的短期 userinfo 结果 | 下次请求会回源身份服务 |

因此，改变 `[redis].key_prefix` 会让新实例看不到旧前缀下的 session、grant、hash 和锁；这相当于切换了一套控制状态，不是无风险的配置整理。需要清理时，先停止流量和所有 qtserver 实例，只针对已审查的本项目 `key_prefix` namespace 操作，绝不能对共享 Redis 执行全库清空。

### 4.2 必须满足的 Redis 配置

qtserver 启动及运行期间都会检查：

```text
appendonly yes
appendfsync everysec
maxmemory-policy noeviction
```

还会检查 `INFO persistence` 中 AOF 已启用且最近写入状态为正常。AOF `everysec` 的含义是异常断电时，最近约一秒已确认的 Redis 写入仍可能没有落盘；这是系统已接受的恢复边界，并不等于可以关闭 AOF。

Redis 连接、认证、AOF 健康或这些配置不满足时，qtserver 不会以“降级模式”继续运行：启动会失败，运行期检测到依赖故障会进入 graceful shutdown，再由服务管理器按 `Restart=on-failure` 重建进程。

Redis ACL 至少要允许 qtserver 进行连接/PING、读取必要配置、读取 `INFO`、访问自身前缀 key，以及运行当前 store 使用的 Lua 脚本。不要在未验证的生产环境中凭直觉收紧 ACL；当前部署文档提到 ACL 文件，但仓库 `qtserver/deploy/` 中并未提供该文件模板，部署前应补齐并在预发布环境验证。

### 4.3 AOF 恢复、`run_id` 与正式 hash

Redis 重启后，AOF 可能只恢复到较早检查点。上传 session 按恢复出的事实继续；缺少的 session 会按协议重新 init。正式文件 hash 更严格：每次关键 hash 操作都在 Lua 脚本内读取 Redis 当前 `run_id`（实例 incarnation）。

这样做的目的，是避免“Redis 重启前的 hash 记录或 worker lease，在重启后被误当成当前事实”。如果记录 incarnation 与当前 Redis 不一致：

- lookup 会清掉旧记录并按当前文件事实重新进入 pending；
- claim 不会领取旧 job；
- heartbeat、submit、fail 不允许旧 worker 续租或写回。

这也是为什么不能绕过 qtserver 直接手改 hash 相关 key：看似简单的修改，可能破坏 generation、lease 与 incarnation 的共同约束。

### 4.4 Redis 需要观察什么

日常至少关注：

- Redis 进程、持久卷和磁盘空间是否健康；AOF 不能持续报写入错误。
- `appendonly`、`appendfsync`、`maxmemory-policy` 是否仍是上述值。
- qtserver 是否因 `redis persistence health check` 反复退出。
- Redis 内存是否逼近容量；本项目要求 `noeviction`，内存耗尽应被当作容量事件处理，而不是改成淘汰策略。
- 上传临时目录是否有持续增长的 orphan；orphan scanner 启动时和每 60 秒扫描一次，使用 Redis 锁避免多实例重复扫描。

示例检查命令中的用户、地址和凭据应由实际部署的受控配置提供；避免把密码放进 shell 历史：

```bash
# Redis 本机健康与持久化状态（按实际 ACL 用户认证）
redis-cli --user <acl-user> --askpass PING
redis-cli --user <acl-user> --askpass INFO persistence
redis-cli --user <acl-user> --askpass CONFIG GET appendonly appendfsync maxmemory-policy

# qtserver 配置语义检查；不会启动服务
qtserver config validate -c /etc/qtrans/qtserver_config.toml
```

## 5. 文件系统与 Nginx 运维边界

### 5.1 两类目录不可混淆

| 目录 | 用途 | 关键约束 |
| --- | --- | --- |
| `user_home_root` | 正式用户文件空间 | 已存在、绝对路径、自身不能是 symlink；按 principal 隔离 |
| `temp_root` | 未完成上传的临时 cache | 绝对路径、不能位于任何 user home 内；服务以严格权限创建/收紧 |

上传发布依赖文件系统原子操作，因此部署时应让 `temp_root` 和正式目标满足部署文档要求的同一发布边界；不要把临时目录放到随时会被系统清理的 `/tmp`，也不要手动清理其中仍有 Redis session 的文件。

### 5.2 Nginx 的职责

Nginx 不是可选的纯反向代理。正常部署通过它提供 TLS、HTTP/2/HTTP/3 与 direct download；下载时 Nginx 的 internal location 读取用户目录，qtserver 只签发/校验控制事实。

每次改变 qtserver 配置中的网关相关项后，应重新生成并安装两份片段：

```bash
qtserver config gennginx -c /etc/qtrans/qtserver_config.toml
```

- `qtserver_http.conf` 必须 include 到 Nginx `http` 块。
- `qtserver_locations.conf` 必须 include 到目标 `server` 块。

Qtserver 与 Nginx 都使用主机本地时区生成带数字时区偏移的原始业务事件；服务不需要额外配置时区。主机时区发生变化后应完整重启两个进程，使后续事件使用新的偏移。还要保证 Nginx worker 对 `user_home_root` 及有效 symlink target 有读取权限。证书、监听端口、`client_max_body_size` 和文件权限问题通常表现为“控制面正常但下载/上传失败”，排查时不能只看 qtserver。

## 6. 服务启动、停止与发布顺序

### 6.1 推荐依赖顺序

```text
Redis
  -> qtuser 或其他 introspection provider（仅 oauth2-introspection 模式）
    -> qtserver
      -> Nginx 对外接流量
```

系统提供的 systemd 示例中，qtserver 使用 `Restart=on-failure`；使用 `oauth2-introspection` 时应额外添加 `After=qtuser.service` 和 `Wants=qtuser.service`。实际 unit 名、运行用户、路径和监听端口以受控部署配置为准。

### 6.2 发布前检查清单

1. 构建目标二进制，并记录版本和 commit。
2. 用 `qtserver config validate` 检查配置；不要直接靠“服务能启动”来发现拼写错误。
3. 确认 Redis 的 AOF、持久卷、`noeviction` 和 ACL 满足要求。
4. 确认 `user_home_root`、`temp_root`、日志目录存在且 owner/权限正确。
5. 如使用 qtuser，先确认其 SQLite 数据目录可写、服务可用，再启动 qtserver。
6. 重新执行 `qtserver config gennginx`，检查 Nginx 配置语法后 reload。
7. 通过 capabilities 和一次最小读/写链路做受控验收；不要只检查 TCP 端口。

### 6.3 停止与故障恢复原则

- 优先停止外部流量，再停止 Nginx/qtserver；避免在未知状态下杀掉 Redis。
- Redis 故障时先修复 Redis 与持久化，再让 systemd 重启 qtserver；不要试图让旧 qtserver 长期带病运行。
- qtransc 的暂停通常可恢复；不要把一次网络失败直接等同于应删除服务端 session。
- 在清理 Redis 或上传临时目录之前，确认是否仍有 active upload。错误清理会把可恢复任务变成重新传输。

## 7. 日志、观测与常见排障路径

### 7.1 日志分工

| 位置 | 用途 | 不应拿来做什么 |
| --- | --- | --- |
| qtransc `--debug` 日志 | 客户端参数、传输与本地问题排查 | 不是服务端业务事实 |
| qtserver/Gin 日志 | HTTP、配置、Redis、文件系统故障排查 | 不能补齐传输业务状态 |
| Nginx access/error log | TLS、网关、静态数据面、权限问题 | 不单独构成业务完成事实 |
| `business-events.jsonl` | qtserver 当前写入的原始业务事件；只按大小轮转 | 不是普通 debug log |
| `download_events.log` | Nginx 写出的下载完成事实 | 不由客户端产生 |

日志和 HTTP response 中不得记录 bearer token、Redis 密码、HMAC secret、身份 provider client credential 或完整 Authorization。日志排查时也应避免复制包含这些信息的命令行。

### 7.2 从现象到组件的快速定位

| 现象 | 优先检查 |
| --- | --- |
| qtserver 启动后立刻退出 | `qtserver config validate`、Redis PING/AOF 配置、identity mode 的依赖是否已启动 |
| 上传无法恢复 | 客户端 `state-db`、Redis session/chunk 是否存在、`temp_root` 是否被误删、源文件 fingerprint 是否改变 |
| 上传完成但 hash 一直 pending | hash worker 配置、Redis hash queue/lease、文件读取权限、qtserver 日志 |
| 授权用户都变成 401/403 | `[identity]` mode、qtuser/provider 健康、token 的传递方式与 Nginx header 转发 |
| 控制 API 正常但大文件下载失败 | Nginx internal location、`X-Accel-Redirect`、Nginx 对用户目录的读权限、TLS/HTTP3 网关日志 |
| Redis 重启后状态异常 | 确认 AOF 恢复状态；接受近期 checkpoint/hash cache 可能丢失，不要用旧 worker 结果手工覆盖新状态 |

## 8. 配置与密钥管理

需要作为敏感配置管理、不能提交到仓库或粘贴到工单/终端历史的内容包括：

- `[redis].password`
- `[transfer].hmac_secret`
- 身份服务 token、qtuser management token 和用户 token
- TLS 私钥
- qtransc 的 `--auth-password`、`--auth-token` 与 `serve --secret-key`

模板中的 `replace-with-...` 都是占位符，绝不能原样投入环境。配置校验输出会对部分 secret 脱敏，但这不能代替文件权限、专用运行账户、部署密钥管理和日志脱敏。

## 9. 建议的学习顺序

如果目前主要依赖 AI 维护，建议按以下顺序建立人工判断能力：

1. 先通读本文件和根目录 `AGENTS.md`，理解 OpenSpec 的权威边界。
2. 用 [qtransc CLI 手册](../qtransc/docs/qtransc-cli-guide.md) 实际跑通一条最小上传、下载和 `list`。
3. 阅读 [qtserver 配置文档](../qtserver/docs/config.md) 与 [部署文档](../qtserver/docs/deploy.md)，能解释 Redis、Nginx、用户目录分别做什么。
4. 阅读可续传上传和正式 hash 的 OpenSpec，再看 `qtserver/internal/store/` 与 `internal/hashmanager/`。
5. 最后再研究 HTTP/2、HTTP/3 lane、旧 WebSocket 兼容和原始业务日志；这些是排查性能或兼容性问题时的专项知识。

## 10. 本文不覆盖的事项

- 具体生产主机、域名、端口映射、登录方式和任何凭据属于受控环境知识，不写进仓库文档。
- Nginx、Redis ACL、备份和监控的最终实现需按实际环境补齐；当前仓库提供的是应用约束与示例，不是完整基础设施即代码。
- 对外 API 的精确 request/response 以 [qtserver API 文档](../qtserver/docs/qtserver-apis.md) 和 OpenSpec 为准。
