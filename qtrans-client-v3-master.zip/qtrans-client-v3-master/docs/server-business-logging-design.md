# QTrans 服务端业务日志设计

| 属性 | 值 |
| --- | --- |
| 文档版本 | 1.1 |
| 协议基线 | 原始业务事件 schema v1 |
| 设计状态 | 基线设计 |
| 适用对象 | 产品、客户端、服务端、下载代理、日志平台和运维人员 |

## 1. 文档定位

本文完整定义 QTrans 服务端业务日志的目标、边界、原始事件协议、文件状态机、最终字段、指标算法、写入可靠性，以及仓库外日志汇聚与分析组件的接口职责。本文不依赖其他设计文档、源代码、配置文档或外部附件，单独导出后即可用于方案评审、实现和验收。

为满足跨团队评审、交付和长期查阅需要，本文有意完整复述 `openspec/specs/` 中与业务日志有关的行为契约，而不是只提供概要或索引。仓库内行为契约仍以 OpenSpec 为权威；任何改变业务日志外部行为、协议字段、状态机或指标口径的变更，都必须在同一次变更中同步维护 OpenSpec 和本文。该维护规则不影响本文作为独立完整设计文档使用。

本文使用以下规范词：

- “必须”表示实现必须遵守的约束；
- “应当”表示正常情况下应遵守，偏离时必须说明理由；
- “可以”表示允许但不强制的选择。

本仓库只实现 Qtserver 与 Nginx 原始业务事件 producer，不实现或部署日志采集、历史存储、分析归约与当前结果存储。本文记录这些仓库外组件必须遵守的合并方法和结果契约，以便不同实现能够得到一致结果。

本文定义业务语义，不限定生产日志平台必须采用某种编程语言、计算框架或数据库产品。文中出现的 ClickHouse 和 PostgreSQL 是仓库外参考架构使用的存储实现，不构成协议依赖。

## 2. 目标与非目标

### 2.1 目标

系统根据一次文件传输过程中产生的多条服务端事实，形成一条可查询、可统计、可重放并可修订的最终业务日志。最终日志必须能够回答：

- 谁在什么入口上传或下载了哪个文件；
- 文件最终成功还是超时失败；
- 实际传输了多少文件内容字节；
- 经历了多少次分片重试；
- 从文件活动开始到得到最终结论经历了多长时间；
- 文件的端到端有效速度是多少；
- 已输出的超时结论是否因迟到的成功事实而被修订；
- 一次文件活动与客户端任务、外部业务日志如何关联。

服务端日志的业务主体是“一个文件的一次上传或下载活动”，不是客户端界面中的任务。一个客户端任务可以包含多个文件，但每个文件独立形成最终日志，服务端不生成任务级聚合状态。

### 2.2 非目标

本设计明确不做以下事情：

- 不建立服务端任务状态机或任务汇总日志；
- 不接收客户端 pause、resume、completed、failed、abandoned 等展示状态；
- 不用调试日志、数据库内部状态或客户端状态补齐业务结论；
- 不为缺少完成事件的请求估算传输字节或重试次数；
- 不为原始事件定义通用 event ID、全局序号或重复导入去重协议；
- 不把日志关联值用于认证、授权、文件归属、幂等或状态判断；
- 不定义独立的下载完成确认，普通下载以整文件校验一致作为成功事实；
- 不覆盖浏览器直接下载场景。
- 不在本仓库交付或部署日志采集调度、原始事件历史存储、分析程序或当前结果存储。

## 3. 术语与系统角色

| 名称 | 定义 |
| --- | --- |
| qtransc | QTrans 客户端，发起上传、下载和校验请求，并提供客户端日志上下文。 |
| Qtserver | QTrans 服务端，负责认证、路径和参数校验、文件传输、文件校验以及大部分原始业务事件生产。 |
| Nginx | 可选的下载数据面代理。启用 X-Accel 时，它根据真实响应结果生产普通下载分片完成事件。 |
| Canonical upload | QTrans 的标准分片上传流程，包含初始化、分片传输、分片校验和整文件提交。 |
| X-Accel | Qtserver 完成鉴权和业务校验后，由 Nginx internal location 实际发送下载数据的内部重定向机制。 |
| Producer | 产生原始业务事件的 Qtserver 或 Nginx。 |
| Consumer | 位于本仓库之外、负责采集、校验、保存或分析原始业务事件的组件。 |
| Wire event | Producer 按 JSON Lines 编码并交给采集链路的原始事件。 |
| Quarantine | 保存无效事件摘要和拒绝原因、且不参与业务归约的隔离区。 |
| 普通文件 | 通过注册、分片传输和校验状态机处理的文件，包括零字节上传。 |
| Small 文件 | 通过 tar 响应按 entry 发送的小文件，包括零字节下载。 |
| 文件活动 | 由 task ID、规范路径、可信用户和操作类型共同标识的一次文件上传或下载。 |
| 权威成功事实 | 能够直接把普通文件判定为成功的上传完成事件或整文件下载校验一致事件。 |
| Attempt | 一次已经进入数据处理并留下 chunk finished 事件的分片传输尝试。 |
| Analysis time | 一次分析运行固定使用的 UTC 毫秒时钟，用于过滤未来事件和判断 timeout 是否到达。 |
| 当前最终日志 | 每个文件活动最多一行、允许被迟到成功事实修订的当前结论。 |

## 4. 三类日志的边界

| 名称 | 作用 | 主要内容 | 是否参与业务分析 |
| --- | --- | --- | --- |
| 原始业务日志 | 保存服务端已经观察到的最小业务事实 | 文件注册、分片完成、校验完成、上传完成、小文件发送完成 | 是，且是唯一分析输入 |
| 最终业务日志 | 保存一个文件活动的当前结论 | 成功或超时失败、传输量、重试、耗时、速度和上下文 | 是分析结果，不由传输接口直接输出 |
| 调试和运行日志 | 定位程序、网络、认证和部署问题 | 请求错误、堆栈、运行状态、访问记录 | 否，不得用于补齐业务结论 |

关闭 debug 或调整运行日志级别不得改变原始业务事件和最终业务日志。未认证请求、非法参数、非法路径、扫描请求以及业务准入前失败只进入访问、安全或调试日志，不生成原始业务事件。

原始事件不得包含 Authorization、access token、refresh token、download grant、HMAC secret、固定匿名凭据、TLS 私钥、请求 body、hash 原值或异常堆栈。

## 5. 总体数据流

```mermaid
flowchart LR
    C["qtransc 客户端"] -->|"传输请求和客户端元数据"| E["Nginx 入口或 Qtserver 直连"]
    E --> S["Qtserver"]
    S --> Q["Qtserver 原始事件流"]
    S -->|"X-Accel 和可信内部日志上下文"| X["Nginx 下载数据面"]
    X --> D["Nginx 下载事件流"]
    Q --> I["仓库外：采集与校验"]
    D --> I
    I --> H["仓库外：原始事件历史存储"]
    H --> A["仓库外：日志分析程序"]
    A --> R["仓库外：当前最终业务日志"]
```

Qtserver 直接发送普通下载时，由 Qtserver 输出 `download.chunk_finished`；启用 X-Accel 时，由 Nginx 根据实际响应状态和发送字节输出同一种事件。两条路径使用相同 payload 和分析语义。

Producer 之后的采集、存储、分析和最终日志均由仓库外组件负责；仅运行本仓库提供的 Qtserver 与 Nginx 时，只保证生成原始事件，不会自动生成最终业务日志。参考架构使用 ClickHouse 保存只追加的原始事件历史，使用独立 PostgreSQL 保存当前最终业务日志。分析程序按文件完整历史归约并 UPSERT 当前结果。替代实现可以更换存储和执行框架，但必须保持本文定义的输入、合并顺序、状态机和结果语义。

## 6. 文件活动身份与关联值

### 6.1 权威身份

一项文件活动由以下四元组唯一关联：

```text
(task_id, normalized_file_path, principal_id, action)
```

| 字段 | 语义 |
| --- | --- |
| `task_id` | 客户端任务关联 ID。它关联同一客户端任务中的日志，但不代表服务端任务状态。 |
| `normalized_file_path` | Qtserver 完成业务校验后的规范逻辑路径，不是服务器磁盘绝对路径。 |
| `principal_id` | Qtserver 认证得到的可信用户标识。 |
| `action` | 固定为小写 `upload` 或 `download`。 |

`file_key` 必须由四元组确定性生成：

```text
base64url-no-padding(
  SHA-256(
    UTF-8("qtrans-file-v1") + NUL +
    UTF-8(task_id) + NUL +
    UTF-8(normalized_file_path) + NUL +
    UTF-8(principal_id) + NUL +
    UTF-8(action)
  )
)
```

`file_path` 用于阅读和业务查询，`file_key` 用于关联事件、读取完整历史和修订当前行。`file_key` 不参与授权、资源归属或业务幂等。分析程序不得再次改变路径大小写或重新规范化路径。

同一 task ID 下的不同文件、同一路径的不同用户以及同一路径的上传和下载必须形成不同的 `file_key`。Canonical upload session 建立后，全部后续事件固定使用 session 创建时保存的 `(task_id, taskpid, enterprise_id)` 和对应 `file_key`。

### 6.2 taskpid 与 enterprise_id

`taskpid` 和 `enterprise_id` 是外部业务提供的两个可选、不透明日志关联值。前者用于关联外部任务，后者用于关联企业业务；两者都不是可信身份或权限边界，并遵循相同输入规则：

- 类型为 string，允许空字符串；
- 输入时先去除首尾 ASCII SP 和 HTAB，内部空白保留；归一化后的值最多 128 bytes，必须是合法 UTF-8，且不得包含 HTTP field value 禁止的控制字符；
- 除上述 trim 外不截断、不生成，也不解释其业务格式；trim 后为空时按空字符串处理；
- schema v1 每条事件都必须显式包含两个 string 字段，空值写成 `"taskpid":""` 或 `"enterprise_id":""`，不得省略或写 `null`；
- 两者都不参与 `file_key`、认证、授权、tenant、principal、路径、文件空间、session ownership、幂等、事件排序、deadline、重试、指标或结果计算；
- 普通文件最终日志从被选定的最早合法 `file.registered` 同时取得两项标签；Small 文件从形成当前结果的同一条 `download.small_file_sent` 同时取得两项标签；
- 后续事件的任一标签不同只作为日志关联差异保留，不构成业务冲突；
- 最早同时间事件的业务内容完全相同、只有辅助标签不同时，按 `(taskpid, enterprise_id)` 的 UTF-8 bytes tuple 升序选择对应的整条事件，禁止分别选择字段或依赖导入顺序。

上层业务在创建 qtransc 内存任务时通过 JSON 字段 `taskpid` 和 `enterprise_id` 提供两项值。qtransc 在任务生命周期内保持它们不可变，并在所有携带 `X-Task-ID` 的 Qtserver 请求中同时发送 `X-Task-PID` 和 `X-Enterprise-ID`；Nginx 必须显式转发这三个请求 header。缺少输入时使用空字符串，不改变任务创建和文件传输结果。

结构化运行日志同样遵循关联字段共现规则：只要一条日志包含 `taskid` 或 `task_id`，同一条日志就必须包含 string 类型的 `taskpid` 与 `enterprise_id`；无值时写空字符串。该规则提高跨组件检索能力，但运行日志仍不得作为业务分析输入。

## 7. 上下文来源与信任边界

普通文件在第一个有效上传初始化请求、普通下载数据请求，或者恢复现场只需整文件校验时的第一次校验请求中建立上下文。客户端只提供 `client_id`、`client_os`、`client_version` 和允许为空的 `caller_version`，其余最终上下文由服务端可信事实补齐。`caller_version` 是创建任务的 GUI 或 agent 自报版本，仅用于日志诊断，不具有身份、授权、tenant、任务 ID、幂等或能力协商语义。

`caller_version` 在任务创建时固定：`qtransc serve` 从创建任务请求的可选同名字段取得，`upload2`/`download2` 从可选 `--callerversion` 取得，其他 CLI 任务使用空字符串。输入去除首尾 ASCII SP 和 HTAB，归一化后最多 256 bytes，并且必须能够安全作为 HTTP header field value 传播；缺失或 trim 后为空时使用空字符串。

qtransc 在每个文件的第一个有效上传 init、普通下载注册请求或 Small 请求中通过 `Caller-Version` 携带该值。普通下载在注册请求收到合法响应头前的重试继续携带完整元数据，确认后后续 Range、verify、chunk 或 complete 不再发送；恢复现场没有数据请求时，第一次整文件 verify 作为注册请求携带。`Caller-Version` 缺失或为空不得使合法请求失败，也不改变 `Client-ID`、`Client-OS`、`Client-Version` 三项必填元数据的完整性判断；该 header 单独出现不得建立注册事实。Small 没有独立注册状态，因此每个 Small 请求都携带当前任务的完整元数据。

| 信息 | 来源与约束 |
| --- | --- |
| `task_type` | 服务端部署场景配置；只允许 `"0"` 或 `"1"`，默认 `"1"`。`"0"` 表示多中心，`"1"` 表示 C/S。 |
| `principal_id` | Qtserver 认证结果，不得使用客户端自报用户名。 |
| `client_username` | 可信身份结果中的用户邮箱；无邮箱时为空字符串，内置匿名用户为 `anonymous`。 |
| `client_id` | qtransc 持久设备标识。 |
| `client_ip` | Qtserver 通过可信代理规则观察到的客户端 IP。 |
| `client_os` | qtransc 所在操作系统。 |
| `client_version` | 实际执行传输的 qtransc 版本。 |
| `caller_version` | 创建任务的 GUI 或 agent 版本；允许为空字符串。 |
| `server_ip` | 文件请求实际进入系统的外部入口 IP，不是服务端机器的内网 IP。 |
| `file_path` | Qtserver 已验证和规范化的逻辑路径。 |
| `file_size` | 上传初始化时已校验的声明值，或下载文件的服务端 stat 事实。 |
| `server_instance` | Qtserver 稳定实例标识；没有显式配置时可在启动时由 hostname 派生。 |
| `server_version` | 产生事件的 Qtserver 构建版本。 |
| `file_inactivity_timeout_seconds` | 文件注册时生效的不活动超时，必须大于 0，默认 86400 秒。 |

`task_type` 只表示部署场景，不得改变其他字段、传输协议、授权、文件空间、事件类型或状态机。两种取值都必须保留完整的 `server_ip`、`client_id`、`client_os`、`client_version`、`caller_version` 和其他上下文字段。

代理提供入口 IP 时，Qtserver 仅在直接连接方属于可信代理时接受该值，否则使用本地监听地址或显式外部入口配置。客户端伪造同名内部 header 不得改变 `server_ip`。`client_ip` 使用同样的可信代理原则。

qtransc 首次生成 `client_id` 时，应优先使用硬件或操作系统安装标识，经 SHA-256 和固定编码形成 `qtc1_...` 格式；无法取得稳定标识时使用安全随机值。标识必须持久化并在后续启动中复用，存储目录和文件仅允许当前用户访问。

`anonymous` 是无需密码、调用方可选择的内置用户，不是一种下载类型。选择该用户时，`principal_id` 和 `client_username` 固定为 `anonymous`，并与普通用户使用相同事件协议和状态机。

普通用户的 `client_username` 用于展示邮箱，`principal_id` 继续用于稳定身份、文件归属和 `file_key`。邮箱来自本次已认证的身份结果，去除首尾空白，不读取客户端登录参数或自报 header，不从 ID 推测邮箱，也不为日志增加一次身份请求：

- `auth` 从成功 `/userinfo` 响应的顶层 `email`、`data.email` 按顺序取第一个非空 string；缺失、null、非 string 和纯空白候选被跳过。
- `oauth2-introspection` 从同一次 active 响应读取可选顶层 `email`，继续逐请求认证且不缓存。邮箱不可用不构成 provider 故障，不触发进程退出。
- `fake` 只有 token 到 ID 的映射；当前 `qtuser` 也不存储或返回邮箱。这两种情况下普通用户的字段为空字符串。不能将用户名或 ID 假装成邮箱。

邮箱只影响日志展示。没有可用邮箱时显式写 `"client_username":""`，不省略字段、不写 null、不回退到 ID，也不阻止合法传输。该规则适用于普通上传、普通下载以及 Small v1/v2。

`auth` 的 Redis 缓存同时保存 `{id,email}`，仍使用原有 TTL（默认 10 秒），并保留同 token 的 singleflight 回源合并。新缓存 key 使用 `identity:userinfo:v2` 命名空间，旧 ID 字符串缓存继续留在旧命名空间并自然过期；新旧实例混合部署或回滚时不会互相误读。新实例首次遇到只有旧缓存的 token 时会回源。邮箱更新在缓存过期后可见，已经写入的文件上下文不回填。

同一文件重试期间邮箱变化仍按第 9 章的注册上下文冲突规则报告，分析继续采用最早合法上下文；邮箱变更不会生成新的 `file_key`，也不改变 session 或文件空间。

## 8. 原始业务事件协议

推荐按以下顺序阅读本章：8.2 节先说明每条事件共有的 envelope，8.3 节建立七类事件的整体关系，8.4 节定义两个事件复用的文件上下文字段，8.5 节再分别给出每类 payload 的完整结构和校验规则。

### 8.1 编码和时间

原始业务事件使用 UTF-8 JSON Lines：每个事件是一个完整 JSON object，独占一行并以换行结束。

所有 wire 时间必须按 producer 主机本地时区使用 RFC3339/ISO 8601 扩展格式，恰好保留三位毫秒并始终携带数字时区偏移，例如 `2026-08-18T18:00:00.123+08:00`。Producer、存储和分析时钟必须通过 NTP 或等价机制保持同步。分析程序按偏移换算绝对时间后再排序和比较，不估算或修正 producer 时钟偏差。

`occurred_at` 表示业务事实完成时间，不是日志采集时间。每次分析固定取得一次 analysis time，并且只应用 `occurred_at <= analysis_time` 的事件。合法未来事件保留在原始历史中，但在分析时钟追上前不得建立状态、刷新 deadline、参与统计或形成结果。

### 8.2 Schema v1 原始日志公共字段列表

Schema v1 是 producer 输出基线。公共字段必须恰好为以下八项：

```json
{
  "schema_version": 1,
  "event_type": "upload.finished",
  "occurred_at": "2026-08-18T18:00:00.123+08:00",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "taskpid": "external-business-log-id",
  "enterprise_id": "enterprise-42",
  "file_key": "6DBgq4NhBfzmOZyImy0-yOsAJ8edkeeIFxwTX_Ti0oM",
  "payload": {
    "result": "committed"
  }
}
```

| 字段 | 类型 | 约束 |
| --- | --- | --- |
| `schema_version` | integer | 固定为 `1`。 |
| `event_type` | string | 只能是本文定义的七类事件之一。 |
| `occurred_at` | string | 主机本地时区的 RFC3339/ISO 8601 扩展格式，恰好三位毫秒并携带数字偏移。 |
| `task_id` | string | 非空。 |
| `taskpid` | string | 允许为空，但必须存在。 |
| `enterprise_id` | string | 允许为空，但必须存在；只用于企业日志关联。 |
| `file_key` | string | 非空，且必须能由事件对应四元组重算。 |
| `payload` | object | 必须满足对应事件的 typed payload 约束。 |

Envelope 出现未知顶层字段、缺少字段或字段类型错误时，整行无效并进入隔离区。Schema v1 不定义 `event_id`、`operation_id`、`session_id`、`report_id`、fingerprint、producer instance、source sequence、started event 或客户端状态事件。

同一 major schema 中，consumer 必须保留 payload 的未来未知字段，并允许旧分析器忽略这些字段；producer 只输出本文已经定义的字段。未知 payload 字段不等同于未知 envelope 字段。

Envelope 增加字段仍需要新的 schema 版本；缺少 `enterprise_id` 的旧七字段 v1 行必须作为 envelope 缺字段进入 quarantine，不得默认补空字符串。Payload 在同一 schema major 内保持向前兼容：当前 producer 必须在 `file.registered` 和 `download.small_file_sent` 中显式输出 string `caller_version`，空值编码为空字符串；升级后的 consumer 读取历史上下文 payload 时，缺少 `caller_version` 按空字符串处理，字段存在但不是 string 时隔离该行。遵守未知 payload 字段规则的旧 consumer 可以忽略新增的 `caller_version`，不得仅因该字段隔离整行。

`client_username` 的邮箱语义沿用 schema v1，但放宽为允许空字符串。Consumer 必须先升级字段校验，再部署新 producer；否则无邮箱事件可能被旧校验器隔离。字段缺失、null 或非 string 仍属非法。历史事件中的旧用户 ID 保留原值，不做邮箱格式校验、不查询身份服务补写，也不改写已形成的历史上下文；最终日志继续取最早合法注册或对应 Small 成功事件中的值。

### 8.3 七类事件的职责与关系

普通文件先用 `file.registered` 固定身份和上下文，之后可以产生多条传输或校验完成事实，最后由权威成功事实结束；如果一直没有成功，则由第 10 章定义的 inactivity timeout 收口。Small 文件不走普通文件状态机，每个合法 `download.small_file_sent` 都同时提供一个文件的上下文和成功事实；v2 可以在同一批次中一次可靠持久化多条逐文件事件，但不引入新的业务事件类型。

```text
普通上传：file.registered
              -> upload.chunk_finished *
              -> upload.verify_finished *
              -> upload.finished

普通下载：file.registered
              -> download.chunk_finished *
              -> download.verify_finished{非权威成功校验} *
              -> download.verify_finished{verification_scope=file, verification_result=matched}

Small 下载：download.small_file_sent
```

星号表示一项文件活动可以没有该事件，也可以有多条。Chunk 和非成功 verify 只记录过程事实，不直接把文件判定为失败。

| 类别 | 事件 | Producer | 记录的事实及作用 |
| --- | --- | --- | --- |
| 建立上下文 | `file.registered` | Qtserver | 普通文件首次有效业务动作开始前，固定文件身份、上下文和 inactivity timeout |
| 数据 attempt | `upload.chunk_finished` | Qtserver | 一次上传分片 attempt 实际读取了多少字节以及如何结束 |
| 上传校验 | `upload.verify_finished` | Qtserver | 一次上传分片 hash 校验得到 matched、mismatched 或 failed |
| 上传成功 | `upload.finished` | Qtserver | 文件已经原子发布，或者目标已经存在相同内容 |
| 数据 attempt | `download.chunk_finished` | Qtserver 或 Nginx | 一次普通下载响应实际发送了多少字节、HTTP 状态以及如何结束 |
| 下载校验 | `download.verify_finished` | Qtserver | 一次分片或整文件 hash 校验结果；整文件 matched 是权威成功事实 |
| Small 成功 | `download.small_file_sent` | Qtserver | 一个 Small payload entry 的内容和 padding 已完整写出，并携带完整文件上下文；v2 按批次暂存和持久化逐文件事件 |

Producer 不得输出 task state、file result、operation started、pause、resume 或客户端 completed、failed、abandoned 事件。

### 8.4 共享文件上下文字段

`file.registered` 和 `download.small_file_sent` 都需要提供最终日志所需的文件上下文。为避免在文档中重复两遍，下表把这 14 个字段称为“共享文件上下文字段组”。这只是文档分组，wire payload 中不存在名为 `context` 的嵌套 object；这些字段仍然直接位于 `payload` 下。

| 字段 | 类型或允许值 | 语义 |
| --- | --- | --- |
| `task_type` | string：`"0"`、`"1"` | 部署场景分类 |
| `action` | string：`upload`、`download` | 文件活动操作类型 |
| `file_path` | 非空 string | 服务端规范化后的逻辑路径 |
| `file_size` | integer：`0..9223372036854775807` | 文件内容大小，单位 bytes |
| `principal_id` | 非空 string | 服务端可信用户标识 |
| `client_username` | string，允许为空 | 可信用户邮箱；无邮箱为空，内置匿名用户为 `anonymous` |
| `client_id` | 非空 string | qtransc 持久设备标识 |
| `client_ip` | 非 unspecified 的 IP string | 可信网络边界观察到的客户端 IP |
| `client_os` | 非空 string | 客户端操作系统类型 |
| `client_version` | 非空 string | 实际执行传输的 qtransc 版本 |
| `caller_version` | string，允许为空 | 创建任务的 GUI 或 agent 版本，仅用于日志诊断 |
| `server_ip` | 非 unspecified 的 IP string | 文件请求实际进入系统的外部入口 IP |
| `server_instance` | 非空 string | Qtserver 稳定实例标识 |
| `server_version` | 非空 string | Qtserver 构建版本 |

这些字段的来源和信任规则以第 7 章为准。`client_ip` 和 `server_ip` 必须能够解析为 IP 且不得为 unspecified 地址。`download.small_file_sent.action` 进一步固定为 `download`。

### 8.5 各事件 payload

一条 schema v1 原始日志由 8.2 节的八个 envelope 字段和本节对应 `event_type` 的 payload 组成。除明确规定可以为 `null` 的字段外，本节列出的 payload 字段都必须存在且不得为 `null`。同一 major schema 对未来未知 payload 字段的兼容规则仍按 8.2 节执行。

#### 8.5.1 file.registered

`file.registered` 在普通文件业务动作开始前建立上下文并初始化 inactivity deadline。Payload 必须包含 8.4 节全部共享文件上下文字段，并额外包含 `file_inactivity_timeout_seconds`：

```json
{
  "task_type": "1",
  "action": "upload",
  "file_path": "/dataset/a.bin",
  "file_size": 12582912,
  "principal_id": "alice",
  "client_username": "alice@example.com",
  "client_id": "qtc1_example",
  "client_ip": "192.0.2.10",
  "client_os": "linux",
  "client_version": "3.0.0",
  "caller_version": "gui-3.2.1",
  "server_ip": "198.51.100.20",
  "server_instance": "qtserver-01",
  "server_version": "3.0.0",
  "file_inactivity_timeout_seconds": 86400
}
```

`file_inactivity_timeout_seconds` 必须是大于 0 的 integer，并固定该文件活动使用的超时口径。注册必须在普通文件业务动作开始前可靠持久化。重复请求可能产生多条内容一致的注册事件，分析程序采用最早合法注册；后续注册不刷新 deadline，也不覆盖最终上下文。

#### 8.5.2 upload.chunk_finished

该事件描述一次已经进入数据处理的上传分片 attempt：

```json
{
  "chunk_index": 2,
  "range_start": 8388608,
  "range_end": 12582912,
  "actual_bytes": 4194304,
  "result": "succeeded"
}
```

- `chunk_index` 必须是非负 integer；
- Range 使用文件绝对半开区间，并满足 `0 <= range_start < range_end <= file_size`；
- `actual_bytes` 正常情况下是本次实际从请求 body 读取的文件内容字节，范围为 `0..range_end-range_start`；
- Producer 按 `range_start = chunk_index * chunk_size + upload_offset` 和 `range_end = range_start + content_length` 形成绝对 Range；
- `result` 只能是 `succeeded`、`interrupted` 或 `failed`；
- 完整读取并接受声明范围时为 `succeeded`，且 `actual_bytes` 等于 Range 宽度；
- 请求 body 提前结束时为 `interrupted`；
- 进入数据处理后发生文件写入、进度持久化或其他服务端失败时为 `failed`；
- `failed` 遇到文件写入或进度持久化失败时，允许只记录失败前已经确认接受或写入的字节，因此 `actual_bytes` 可以低于已经从网络读取的字节；这是可接受的异常统计缺口；
- 三种结果都表示真实 attempt，在有效统计窗口内累计实际字节；它们都不是文件失败终态。

业务准入前的认证、session、offset、长度或 Range 校验失败不得产生该事件。

#### 8.5.3 upload.verify_finished

该事件描述一次已经开始执行的上传分片 hash 校验：

```json
{
  "chunk_index": 2,
  "verification_result": "matched"
}
```

`chunk_index` 必须是非负 integer。`verification_result` 只能是：

- `matched`：hash 比较完成且一致；
- `mismatched`：hash 比较完成但不一致；
- `failed`：已经进入校验执行，但因读取、计算或依赖错误无法得出结论。

前置校验失败、hash 尚未开始计算或结果尚不可用不得产生事件。任何取值都不直接结束文件。

#### 8.5.4 upload.finished

该事件是普通上传的权威成功事实：

```json
{
  "result": "committed"
}
```

`result` 只能是：

- `committed`：整文件校验完成并原子发布成功；
- `already_present`：目标是普通文件，大小、hash 算法和 hash 值均确认一致。

仅目标存在、仅大小相同、hash pending、hash unavailable 或 hash 不一致不得形成 `already_present`。Cancel、session release、session expire、客户端停止和单次服务端错误不产生文件失败事件。

零字节上传仍使用 Canonical upload：初始化产生 `file.registered` 并建立零 chunk session，整文件提交成功后产生 `upload.finished{result=committed}`，不产生 upload chunk 或 verify 事件。其最终 `transmitted=0`、`retry_count=0`、`speed=null`。

#### 8.5.5 download.chunk_finished

该事件描述一次普通下载数据响应实际发生的结果：

```json
{
  "chunk_index": 2,
  "range_start": 8388608,
  "range_end": 12582912,
  "actual_bytes": 4194304,
  "http_status": 206,
  "result": "succeeded"
}
```

- `chunk_index` 必须是非负 integer；同一客户端分片的断点续传和重试保持相同 index；
- Range 是非空半开区间，满足 `0 <= range_start < range_end <= file_size`；
- `actual_bytes` 是实际发送的文件内容字节，不含错误响应 body；
- `http_status` 是 `100..599` 的 integer；
- `result` 只能是 `succeeded`、`interrupted` 或 `failed`；
- 实际状态等于预期状态、Range 响应结构合法、请求正常结束且实际字节等于预期字节时为 `succeeded`；
- 状态仍表示预期文件数据响应，但请求未正常结束或字节数不足时为 `interrupted`；
- 状态不等于预期状态或 Range 响应结构非法时为 `failed`，且 `actual_bytes=0`。

非空普通文件的完整 GET 使用 `[0,file_size)`；零字节下载走 Small 路径，不产生空 Range 事件。

#### 8.5.6 download.verify_finished

该事件描述一次普通下载的分片或整文件 hash 校验。以下示例表示整文件校验一致，也是普通下载的权威成功事实：

```json
{
  "verification_scope": "file",
  "chunk_index": null,
  "verification_result": "matched"
}
```

- `verification_scope` 只能是 `chunk` 或 `file`；
- scope 为 `chunk` 时，`chunk_index` 是非负 integer；
- scope 为 `file` 时，`chunk_index` 必须是 `null`；
- `verification_result` 只能是 `matched`、`mismatched` 或 `failed`，语义与上传校验相同；
- 只有 `{verification_scope=file, verification_result=matched}` 是普通下载权威成功事实；
- 分片 matched、整文件 mismatched 和 failed 都不结束文件。

服务端 hash 尚在生成、不可用且未开始比较时不产生事件，也不刷新 deadline。

#### 8.5.7 download.small_file_sent

Small 文件没有独立注册事件，因此该成功事件必须自包含上下文。Payload 包含 8.4 节全部共享文件上下文字段，以 `started_at` 记录当前 tar entry 开始发送的时间，并固定 `action=download`：

```json
{
  "task_type": "1",
  "action": "download",
  "file_path": "/dataset/readme.txt",
  "file_size": 1024,
  "principal_id": "alice",
  "client_username": "alice@example.com",
  "client_id": "qtc1_example",
  "client_ip": "192.0.2.10",
  "client_os": "linux",
  "client_version": "3.0.0",
  "caller_version": "",
  "server_ip": "198.51.100.20",
  "server_instance": "qtserver-01",
  "server_version": "3.0.0",
  "started_at": "2026-08-18T18:00:00.123+08:00"
}
```

`started_at` 与 envelope `occurred_at` 使用相同的主机本地时区、三位毫秒和数字偏移格式，换算为绝对时间后不得晚于 envelope 的 `occurred_at`。Envelope 的 `occurred_at` 使用当前文件 payload entry 完成时间，即使 v2 事件稍后才批量写入。

v1 在文件内容完整写出、实际字节等于 `file_size`，并且当前 tar entry padding flush 成功后，立即 append 并 sync 该文件的 `download.small_file_sent`；持久化成功后才继续下一个 entry。后续文件失败不得撤销已经持久化的前序文件成功事实。

v2 在每个 payload 内容和 entry padding 完整写入时确定逐文件事件内容与 `occurred_at`，但先暂存在内存中。只有全部 payload entry 都完成后，Qtserver 才按 manifest 顺序批量 append 本批次的逐文件事件，并在全部完整行 append 后执行一次文件级 sync；sync 成功后才发送 checksum footer。任一 payload 未完成时不得 append 本批次的任何暂存事件；事件 append 或 sync 失败时不得发送 footer。Footer 或后续 tar 结束写入失败不得撤回已经持久化的真实发送事实。

Small 文件不产生注册、开始、失败、重试、timeout、verify 或 batch/attempt 业务事件。v2 批次重试可能为同一 `file_key` 产生多条真实的 `download.small_file_sent`；分析程序采用最早合法成功事实，后续事件不得增加最终 `transmitted` 或 `retry_count`。调度、lane、attempt、footer 校验和客户端发布细节只进入 debug log，不参与业务归约。

## 9. 事件合法性与冲突处理

Consumer 必须先校验 JSON、envelope、event type 和 typed payload，再执行跨事件语义校验。无效事件进入 quarantine，并且不得阻塞其他文件分析。

跨事件规则如下：

- 普通事件的 family 必须与最早合法注册的 `action` 一致；
- 普通事件早于注册时间时无效；
- 注册四元组或 Small 自包含四元组必须能重算出 envelope 的 `file_key`；
- 无注册的普通事件可以保留，注册到达前不得建立状态或形成结果；
- 相同 `file_key + chunk_index` 的多条合法 chunk 完成事件表示多次真实 attempt，不得因怀疑重复采集而删除；
- 本设计假定采集链路不重复导入同一原始行，producer 和 consumer 不承担通用去重；
- 同一文件存在 `upload.finished{committed}` 和 `upload.finished{already_present}` 时属于互斥终态冲突，不得猜测结果；
- 完整历史因冲突、溢出、缺上下文或未来事件而无法形成候选时，不插入新结果，也不更新或删除已有当前结果。

重复注册按以下方式处理：

- 采用 `occurred_at` 最早且合法的注册；
- 完全一致的后续注册忽略；
- `task_type`、IP、实例、版本或 timeout 不同属于上下文漂移，保留最早值；
- `file_size`、`client_id`、`client_os`、`client_version`、`caller_version` 或 `client_username` 不同属于语义冲突，报告差异但继续用最早上下文归约；
- 最早时间并列且会形成不同最终上下文时，无法确定首次注册，不输出候选；
- 最早时间并列、业务上下文相同且只有辅助标签不同时，按 `(taskpid, enterprise_id)` 的 UTF-8 bytes tuple 升序选择对应的整条事件，禁止混合字段。

Quarantine 至少保存采集时间、来源标识、来源行号、原始行 SHA-256 摘要和稳定拒绝原因。默认不保存可能包含敏感数据的无效原始整行。

## 10. 文件状态机

### 10.1 普通文件

```mermaid
flowchart LR
    R["file.registered"] --> P["PROCESSING"]
    P -->|"有效窗口内的 chunk 或非终态 verify"| P
    P -->|"upload.finished"| S["SUCCESS"]
    P -->|"整文件 download verify matched"| S
    P -->|"到达 inactivity deadline"| F["FAILED / TIMEOUT"]
    F -->|"迟到的权威成功事实"| S
```

普通文件使用 `PROCESSING`、`SUCCESS`、`FAILED` 三态模型。当前结果存储只保存已经得到结论的 `SUCCESS` 或 `FAILED`，不保存 `PROCESSING` 行。

初始状态和 deadline：

```text
last_activity_time = start_time
deadline = last_activity_time + file_inactivity_timeout_seconds

for occurred_at group in chunk_finished / verify_finished ordered by occurred_at:
    if group.occurred_at < start_time:
        reject event
    else if group.occurred_at <= deadline:
        validate and apply every event in this time group
        last_activity_time = group.occurred_at
        deadline = last_activity_time + file_inactivity_timeout_seconds
    else:
        stop extending deadline
```

状态规则：

1. 最早合法 `file.registered` 建立 `PROCESSING`。
2. 不晚于当前 deadline 的合法 chunk 或 verify 完成事实按时间组应用，并刷新 deadline。
3. `upload.finished` 是上传权威成功事实。
4. 整文件 matched 的 `download.verify_finished` 是普通下载权威成功事实。
5. Analysis time 到达 deadline 且没有权威成功事实时形成 `FAILED/TIMEOUT`，`end_time` 等于 deadline。
6. 内容一致的重复注册不刷新 deadline。
7. 第一条普通事件晚于 deadline 后，首次 deadline 固定；更晚的普通事件不再延长它。
8. 服务端没有 pause 状态，客户端静默不冻结或扣除 timeout。
9. Hash mismatch、连接中断和普通请求失败都不是文件立即失败终态；没有最终成功时统一由 timeout 收口。

相同 `occurred_at` 的 chunk 和 verify 作为一个时间组处理；时间恰好等于 deadline 时先处理整个组，再刷新 deadline。权威成功事实与 chunk 同时发生时，同时间的全部合法 chunk 都进入成功统计窗口。

已经输出的 `FAILED/TIMEOUT` 允许被迟到的 `upload.finished` 或整文件 matched 修订为成功。修订时重新读取完整历史，并用注册到成功事实的闭区间重新计算全部字段。Timeout 后只有普通 chunk 或非成功 verify 时，不重开状态、不修改最终行，也不刷新 `log_time`。

### 10.2 Small 文件

Small 文件不建立 `PROCESSING`。合法 `download.small_file_sent` 到达后立即形成 `SUCCESS/SMALL_FILE_SENT`：

```text
start_time = payload.started_at
end_time = occurred_at
transmitted = file_size
retry_count = 0
```

服务端不推断客户端是否已经收到 checksum footer、完成 tar 校验、落盘或本地发布。多个文件在同一 tar 响应中仍按文件边界形成最终日志：v1 后续文件失败不撤销已经持久化的前序文件；v2 任一 payload 失败时整批暂存事件都不写入，但 footer 或 tar 尾部在批次事件持久化后失败时不得撤销这些真实发送事实。

同一 `file_key` 已有合法 Small 成功后，后续 v2 重试事件、普通下载注册、chunk 或 verify 事件可以保留供检查，但不得改变、补充或撤回 `SUCCESS/SMALL_FILE_SENT`。同一文件因 v2 批次重试产生多个合法 Small 成功事件时使用最早事实，最终 `transmitted=file_size`、`retry_count=0`。

## 11. 最终业务日志

每个已经得到结论的 `file_key` 在当前结果存储中只有一行。Schema v1 基线下共有 25 个字段：

| 字段 | 类型 | 含义或来源 |
| --- | --- | --- |
| `task_type` | string | 注册或 Small 事件中的场景分类，`"0"` 多中心、`"1"` C/S |
| `server_ip` | string | 文件第一次进入系统时的可信外部入口 IP |
| `task_id` | string | 客户端任务关联 ID |
| `taskpid` | string | 外部日志关联值，允许为空，不参与业务归约 |
| `enterprise_id` | string | 外部企业日志关联值，允许为空，不参与业务归约 |
| `client_id` | string | qtransc 持久设备标识 |
| `client_ip` | string | 可信网络边界观察到的客户端 IP |
| `client_os` | string | 客户端系统类型 |
| `client_version` | string | 实际执行传输的 qtransc 版本 |
| `caller_version` | string | 创建任务的 GUI 或 agent 版本，允许为空 |
| `client_username` | string | 原始上下文中的可信用户邮箱；无邮箱为空，内置匿名用户为 `anonymous` |
| `action` | string | `upload` 或 `download` |
| `transmitted` | integer | 统计窗口内全部合法 chunk 完成事件的实际文件内容字节总和 |
| `file_path` | string | 服务端校验并规范化后的逻辑路径 |
| `file_size` | integer | 文件内容大小，单位 bytes |
| `start_time` | string | 普通文件最早注册时间；Small 文件为 entry 开始时间 |
| `end_time` | string | 最早权威成功时间、首次 inactivity deadline 或 Small entry 完成时间 |
| `duration` | number | `end_time - start_time` 的 wall-clock 秒数，固定三位小数 |
| `log_time` | string | 当前结果首次写入或内容最近一次实际修订的 analysis time |
| `file_key` | string | 文件活动确定性关联键，也是当前结果主键 |
| `principal_id` | string | 服务端可信用户标识 |
| `result` | string | `SUCCESS` 或 `FAILED` |
| `result_reason` | string | 稳定结果原因码 |
| `retry_count` | integer | 各 chunk 的额外完成 attempt 数量之和 |
| `speed` | number/null | 成功文件的端到端有效速度，单位 bytes/s，保留三位小数 |

允许的结果组合只有：

```text
SUCCESS / UPLOADED_AND_COMMITTED
SUCCESS / ALREADY_PRESENT
SUCCESS / DOWNLOADED_AND_VERIFIED
SUCCESS / SMALL_FILE_SENT
FAILED  / TIMEOUT
```

普通文件的上下文字段（包括 `client_version` 和 `caller_version`）来自最早合法注册；Small 文件来自自身 payload。`task_id` 和 `file_key` 来自相应 envelope；`taskpid` 与 `enterprise_id` 必须从形成当前结果的同一条注册或 Small 成功事件整体复制。缺少 `caller_version` 的合法历史上下文按空字符串归一化，最终日志必须显式输出该字段且不得写 `null`。重复分析得到完全相同的候选内容时，不得只因为重新分析而刷新 `log_time`。

全部最终时间字段使用 UTC RFC3339 并恰好保留三位毫秒。`file_size` 和 `transmitted` 的有效范围均为 `0..9223372036854775807`；求和溢出时不得输出猜测结果。

## 12. 指标计算

### 12.1 统计窗口

- 成功普通文件：`start_time` 到最早权威成功时间，首尾都包含；
- 超时普通文件：`start_time` 到首次 inactivity deadline，首尾都包含；
- Small 文件：单个 tar entry 的 `started_at` 到事件 `occurred_at`；
- 结果窗口之后的普通事件保留在原始历史中，但不参与当前统计；迟到权威成功触发修订时例外。

### 12.2 transmitted

- 普通上传：窗口内全部合法 `upload.chunk_finished.actual_bytes` 之和；
- 普通下载：窗口内全部合法 `download.chunk_finished.actual_bytes` 之和；
- `ALREADY_PRESENT`：固定为 `0`；
- Small：固定为 `file_size`。

失败、中断和 hash mismatch 后重传产生的已完成 attempt 都是真实网络成本，因此 `transmitted` 可以大于 `file_size`。没有留下完成事件的请求不估算字节数，最终统计允许小于真实网络成本。

### 12.3 retry_count

在结果窗口内按 chunk index 分组：

```text
retry_count = sum(max(chunk_finished_count - 1, 0))
```

它统计额外 data attempt，不是错误响应数。Init、grant、verify、complete 和查询请求的重复调用不增加 `retry_count`。`ALREADY_PRESENT` 固定为 `0`。

### 12.4 duration

```text
duration_ms = end_time - start_time
duration = duration_ms / 1000
```

计算先使用非负整数毫秒差，再输出固定三位小数。Duration 是 wall-clock 时间，包含传输、校验、重试等待、退避和客户端在 deadline 前的静默时间。并行分片持续时间不得相加。`duration_ms=0` 时输出 `0.000`。

### 12.5 speed

```text
speed = file_size * 1000 / duration_ms
```

计算使用 decimal 或等价的无溢出算法，最终四舍五入到三位小数。它表示端到端有效速度，不是链路吞吐率，因此分子使用 `file_size`，而不是可能包含重传的 `transmitted`。

只有同时满足以下条件时才输出数值：

- 最终结果为成功；
- 不是 `ALREADY_PRESENT`；
- `transmitted > 0`；
- `file_size > 0`；
- `duration_ms > 0`。

失败、零字节、零传输、零耗时、无法计算和 `ALREADY_PRESENT` 的 `speed` 都是 `null`。

## 13. 写入可靠性与轮转

Qtserver 和 Nginx 分别写入独立的原始业务事件流。每个事件完整占一行并以换行结束；压缩只处理已经关闭的轮转段。Active 文件末尾没有换行的不完整内容等待后续采集，关闭段中的不完整行进入 quarantine。

Qtserver 的 active 文件固定为 `log.file_path/business-events.jsonl`，Nginx 的 active 文件固定为相对于 Nginx 运行时 prefix 的 `./logs/download_events.log`。当前正在写入的 Qtserver 文件始终使用固定名称；只有成功关闭的历史段才使用 `business-events-<UTC timestamp>-<sequence>.jsonl`，启用压缩时归档后缀为 `.jsonl.gz`。不得为当前 active 内容预先创建时间戳文件或硬链接别名。

Qtserver 复用现有 `[log.rotation]` 配置，不增加业务日志专用轮转配置。仅当 `log.rotation.enable=true`、active 文件已有内容，并且追加下一条完整事件会使文件超过 `log.rotation.max_size` 时，才在追加前执行轮转。运行时长、自然日、固定时刻、进程关闭和进程重启都不得触发轮转：

- `max_size` 控制大小轮转阈值；
- `max_age` 只控制已关闭归档的保留期清理，不是时间轮转周期；
- `max_backups` 限制已关闭归档数量；
- `compress` 只决定已关闭归档是否压缩；
- `enable=false` 时始终追加同一个 `business-events.jsonl`，不因大小或时间生成归档。

正常关闭只 sync 并关闭 active 文件，重启后修复最后一个完整换行之后的不完整尾部并继续追加。升级时，如果新 active 不存在而旧版 `business_events.log` 存在，Qtserver 必须无损迁移旧内容；如果旧 active 与旧式时间戳文件是同一文件的硬链接，迁移后只保留新的 active 路径承载该内容。如果新旧 active 同时存在，或旧式文件关系无法无歧义判断，不得合并、覆盖或删除任一文件，必须进入 logging-unhealthy。

Qtserver writer 必须串行追加完整行，并遵守以下规则：

- `file.registered` 必须在普通文件业务动作前 append 并 sync；失败时拒绝开始该业务动作并返回稳定、可重试的日志不可用错误；
- `upload.finished`、整文件 matched 的 `download.verify_finished` 和 `download.small_file_sent` 必须在报告持久成功前完成 sync；
- v2 Small 同一批次的多条 `download.small_file_sent` 可以在一个串行 writer 临界区中连续 append，但必须在全部完整行 append 后只执行一次 sync；sync 成功前不得报告该批次事件持久成功，也不得发送 checksum footer；
- 完整行已经 append 但 sync 失败时只重试 sync，不得再次 append；
- Partial write 后，只有成功 truncate 并 sync 回写前边界时才可以重试 append；
- v2 批量 append 仍必须为每个事件保留可恢复的行边界；任一行写入失败或最终 sync 失败都使整个批量操作失败并进入 logging-unhealthy，不得把已经形成完整行的真实发送事实伪装为未发生；
- 无法确认边界、truncate 失败或无法验证最后完整换行时保持 logging-unhealthy，不得盲目重写；
- 轮转与 append 使用同一个串行边界，已经关闭的 segment 不得改写。

Qtserver 处于 logging-unhealthy 时，必须拒绝后续所有会产生原始事件的传输或校验操作；健康检查、恢复和不产生事件的查询可以继续。恢复组件必须能独立执行 reopen、sync 和文件边界检查，恢复成功后先清除 gate，再开放事件生产操作。

业务事实已经发生后，日志失败不得伪造或回滚事实：

- 上传分片数据已经接受但 chunk 事件写入失败时，当前请求仍返回真实业务结果，同时 Qtserver 进入 logging-unhealthy；
- 文件已经 committed、确认 already present 或整文件 verify matched 后，终态事件持久化失败不得回滚文件或校验事实；当前请求返回可重试的日志不可用错误，恢复后由幂等操作补写内容一致的成功事件；
- Direct 下载响应完成后 chunk 事件写入失败不得回滚响应，但 Qtserver 进入 logging-unhealthy，并接受本次统计事实缺失；
- v1 Small entry 完成但成功事件写入失败时，不撤回已经发送的 entry，停止当前批次后续文件并进入 logging-unhealthy；
- v2 Small 在全部 payload 完成后批量 append 逐文件事件并执行一次 sync；任一 append 或 sync 失败时停止响应、不得发送 checksum footer，并进入 logging-unhealthy；
- Nginx 在响应结束阶段写日志失败时，已发送响应不回滚，通过运行日志和采集监控暴露缺口。

## 14. Nginx 下载事件信任边界

启用 X-Accel 时，Qtserver 必须通过只对 Nginx 可见的内部响应 header 传递以下可信字段：

```text
X-QT-Log-Task-ID
X-QT-Log-Task-PID
X-QT-Log-Enterprise-ID
X-QT-Log-File-Key
X-QT-Log-Chunk-Index
X-QT-Log-Range-Start
X-QT-Log-Range-End
X-QT-Log-Expected-Status
X-QT-Log-Expected-Bytes
```

Nginx 只使用 Qtserver upstream 返回的字段构造 `download.chunk_finished`，不得直接信任客户端提交的同名内部 header。全部内部 header 必须从客户端响应中隐藏。Nginx 使用主机当前本地时区构造时间，不要求启动环境额外设置时区；格式构造失败时不得写入带虚假兜底时间的业务事件。

除允许为空的 `taskpid` 与 `enterprise_id` 外，其余七项在写事件前必须完成结构校验：task ID 和 file key 非空；chunk index、Range 端点和 expected bytes 是非负十进制整数；expected status 是 `200` 或 `206`。任一辅助标签为空都不得阻止事件写入，必须编码为 JSON 空字符串。

缺失或非法的必要 handoff、客户端直接访问 internal location以及非 X-Accel 请求不得向业务事件流写入包含 `-` 占位符或非法数值的半条 JSON。Range 顺序和 expected bytes 等跨字段关系由 consumer 再次校验。

Schema version `1` 和 event type `download.chunk_finished` 是 Nginx 专用业务日志格式中的常量，不从 handoff 接收。Nginx 使用请求完成状态、实际 HTTP 状态、Content-Range 和实际发送 body bytes 形成响应完成事实。

## 15. 仓库外日志汇聚与分析职责

### 15.1 组件边界

本仓库只负责由 Qtserver 和 Nginx 生成原始业务事件。仓库外组件负责发现和采集日志文件、保存原始历史、隔离坏行、调度分析、归约完整历史、保存当前最终结果以及提供检查能力。仓库外组件未运行不影响传输接口继续按约定产生原始事件，但不会形成最终业务日志。

### 15.2 日志合并方法

仓库外组件至少必须按以下顺序工作：

1. 发现 Qtserver 的 `log.file_path/business-events.jsonl`、已经关闭的 `business-events-<UTC timestamp>-<sequence>.jsonl[.gz]`，以及 Nginx 运行时 prefix 下的 `./logs/download_events.log` 和已经关闭的轮转段。
2. 按 source、物理文件身份和读取位置维护 checkpoint，确保一个物理文件段中的同一行只导入一次；不得因为两条合法事件内容相同而猜测其为重复事件。
3. 每个输入流独立解析，只读取以换行结束的完整 JSONL 行。Active 文件未换行的末尾保持 pending；关闭段未换行的末尾进入 quarantine。
4. 校验严格八字段 schema v1 envelope、event type 和 typed payload；旧七字段 v1 行按缺字段隔离，历史上下文 payload 缺少 `caller_version` 时归一化为空字符串，字段存在但不是 string 时隔离。合法事件连同原始 JSON、source 和物理文件来源追加到原始历史存储，无效内容连同拒绝原因写入 quarantine。
5. 将每条合法事件携带数字偏移的时间换算为 UTC 毫秒绝对时间。跨 producer 的合并是合法事件的逻辑并集，不是文件拼接；不得使用文件名、文件发现顺序、采集顺序或导入顺序解释业务先后。
6. 以 `file_key` 为单位读取完整历史，校验 task ID、事件 family、四元组和 file key 一致性；固定一次 analysis time，过滤未来事件，按 `occurred_at` 升序分组，并把相同时间的事实作为同一时间组处理。
7. 根据普通文件状态机或 Small 直达规则形成候选结果，以 `file_key` 为主键 UPSERT 当前最终行，只有内容实际变化时更新 `log_time`，并允许 `FAILED/TIMEOUT` 被迟到权威成功事实修订。
8. 提供按 file key 查看完整事件时间线、schema version、`taskpid`、`enterprise_id`、`caller_version`、辅助标签的同事件来源、注册上下文、deadline、字段来源、当前结论和冲突原因的检查能力。

分析程序不得读取 Qtserver 进程内存、缓存、业务数据库、qtransc 本地状态或调试日志补齐结论。即使 Qtserver、qtransc 和 Nginx 均未运行，只要原始事件历史完整，仓库外组件也必须能够重新生成当前最终日志。存储产品、采集器、调度器和执行框架可以替换，但相同合法原始事件集合必须得到相同当前最终结果。

## 16. 评审与验收清单

- 每条最终日志都能仅依靠原始业务事件重新计算；
- 仓库只实现 Qtserver 与 Nginx producer，采集、存储、分析和当前结果由仓库外组件负责；
- 跨 producer 合并不依赖文件名、文件发现顺序、采集顺序或导入顺序；
- Active 文件未换行的末尾保持 pending，关闭段未换行的末尾进入 quarantine；
- 采集 checkpoint 能防止同一物理行重复导入，且不会把内容相同的真实 attempt 错当成重复事件；
- 文档之外不需要任何项目文件、附件或隐含规则才能解释字段和状态机；
- Schema v1 producer 始终输出 string 类型的 `taskpid` 与 `enterprise_id`，无值时使用空字符串；
- `file.registered` 和 `download.small_file_sent` 始终输出 string 类型的 `caller_version`，历史缺失按空字符串兼容，最终日志显式保留该字段；
- 两项辅助标签只用于日志关联，不改变文件身份、状态和指标，并从同一选定事件进入最终结果；
- 同一客户端任务下的多个文件不会被聚合成一个服务端结果；
- 上传只有 committed 或 already present、普通下载只有整文件 matched 才算成功；
- 未走到成功操作的普通文件最终由 inactivity timeout 收口；
- Hash mismatch、连接中断和重传正确反映在 `transmitted` 和 `retry_count` 中；
- v1 Small 文件只有内容和 entry padding 完整发送后才立即留下成功事件；v2 只有整批 payload 完成并可靠持久化逐文件事件后才发送 checksum footer；
- Timeout 当前行能够被迟到成功事实修订，普通迟到事件不能重开状态；
- `server_ip`、principal、路径和文件大小来自服务端可信事实；
- Nginx 内部 handoff 字段不暴露给客户端；
- 原始事件和最终结果不包含凭据、hash 原值或异常堆栈；
- Qtserver active 文件固定为 `business-events.jsonl`，只在追加下一条完整事件超过大小阈值时轮转，关闭、重启和 `max_age` 都不触发轮转；
- 写入失败和恢复不会把一次真实 attempt 重复记录成多个 attempt。
