# Qtserver / Nginx 日志轮转配置

## 1. 怎么配置

### Qtserver

以下以 `/opt/qtrans` 为安装根目录。修改 `/opt/qtrans/qtserver/qtserver_config.toml` 中现有的配置段，重启 Qtserver 生效：

```toml
[log]
file_path = "./logs"

[log.rotation]
enable = true
max_size = 100      # 下一条日志将使文件超过 100 MiB 时轮转
max_backups = 0     # 不按份数删除，使用下面的保留时间
max_age = 7         # 轮转时清理超过 7 天的历史文件
compress = false   # 历史文件不压缩，保留用于补采
```

原始业务日志写入 `business-events.jsonl`，旧段改名为 `business-events-时间戳-序号.jsonl`。这组配置也影响运行日志；不要再用 logrotate 轮转 Qtserver 的这些文件。

### Nginx

安装系统的 `logrotate`，以 root 身份生成轮转配置，文件直接保留在 Qtserver 目录：

```bash
sudo /opt/qtrans/qtserver/qtserver config gennginx
```

命令同时生成 `qtserver_http.conf`、`qtserver_locations.conf` 和 `qtserver-nginx.logrotate`，默认放在二进制旁边，`-o DIR` 可指定输出目录。日志和 PID 始终根据二进制所在目录的 `../nginx/logs/` 计算绝对路径，分别为 `download_events.log`、`nginx.pid`；与当前工作目录、`-c` 和 `-o` 无关。Nginx 应使用这个同级目录作为运行 prefix，安装位置改变后需重新生成，并更新下面的 cron 路径。

轮转参数复用 `[log.rotation]`：`max_size` → `size NM`，`max_backups` → `rotate N`（0 转为 -1，不限份数），`max_age` → `maxage N`。`compress=true` 生成 `compress + delaycompress`，否则不压缩；`enable=false` 生成仅含禁用说明的文件。修改参数后重新生成，下一次 cron 执行即读取新配置。

在 `/etc/cron.d/qtrans-nginx-logrotate` 中加入以下内容，以 root 身份每 5 分钟检查一次（需要 cron 服务运行）：

```cron
*/5 * * * * root /usr/sbin/logrotate /opt/qtrans/qtserver/qtserver-nginx.logrotate
```

logrotate 直接读取命令行指定的文件，无需复制到 `/etc/logrotate.d/`。上面是 `/etc/cron.d` 格式；若使用 `sudo crontab -e`，去掉 `root` 列。若此前已安装过旧配置，移除 `/etc/logrotate.d/` 中对应条目，避免重复配置。

### Vector 的采集范围

若采用前面讨论的“只采集当前文件”，两个 file source 的 `include` 分别使用：

```text
Qtserver：/opt/qtrans/qtserver/logs/business-events.jsonl
Nginx：  /opt/qtrans/nginx/logs/download_events.log
```

新文件从 `beginning` 读取，`data_dir` 使用持久目录保存读取位置。确保 Vector 对每次新建的日志文件都有读取权限。

## 2. 为什么这样配置

以下按 Linux 本地文件系统说明。A 是轮转前的文件，B 是轮转后新建的文件；假设 Vector 已打开 A、只匹配上述固定路径，且 A 未被提前清理。

### Qtserver：先关闭，再改名

```mermaid
sequenceDiagram
    participant Q as Qtserver
    participant F as 文件系统
    participant V as Vector
    Q->>F: 向 active 文件 A 追加
    V->>F: 打开并读取 A
    Q->>Q: 达到轮转条件，持有写入锁
    Q->>F: Sync A，关闭自己的写句柄
    Q->>F: 将 A 改名为历史文件
    Note over F,V: Vector 的读句柄仍有效
    Q->>F: 创建新的 active 文件 B
    Q->>Q: 按配置清理过期历史文件
    Q->>F: 将本条日志写入 B
    Q->>Q: 释放写入锁
    V->>F: 发现 B，开始读取
    V->>F: A 不再匹配路径，读到 EOF 后关闭 A
```

Qtserver 的原始业务日志由自定义 writer 管理，运行日志才使用 lumberjack。轮转与追加共用一把锁，期间其他业务日志写入等待；关闭的是 Qtserver 自己的句柄，不影响 Vector 的句柄。

### Nginx：先改名，再通知切换

```mermaid
sequenceDiagram
    participant R as logrotate
    participant N as Nginx
    participant F as 文件系统
    participant V as Vector
    N->>F: 向 active 文件 A 追加
    V->>F: 打开并读取 A
    R->>F: 将 A 改名为历史文件
    Note over N,V: 此时 Nginx 仍可写 A，Vector 仍可读 A
    R->>N: 发送 USR1
    N->>F: 打开新文件 B，各 worker 切换并关闭旧写句柄
    N->>F: 后续日志写入 B
    V->>F: 发现 B，开始读取
    V->>F: A 不再匹配路径，读到 EOF 后关闭 A
```

这是 Nginx 官方的日志重开方式。Vector 对 A、B 的读取可以交错进行，图中只展示一种顺序。[Nginx 说明](https://nginx.org/en/docs/control.html#logs)

- **不使用 `copytruncate`**：复制与截断之间的新日志可能丢失；采用改名和切换文件。
- **暂不压缩**：旧文件关闭不代表采集完成，保留未压缩段便于后续补采；Vector 对 gzip 的断点恢复有限制。
- **只匹配 active 可减少历史句柄占用**：旧段不再匹配且读到 EOF 后会关闭；若全部历史都匹配，读完也可能继续保持打开。[Vector 说明](https://vector.dev/docs/reference/configuration/sources/file/)
- **历史补采仍需单独设计**：Vector 停机、重启或未及时发现新文件可能造成遗漏；从机制上看，Nginx 切换完成前的暂时 EOF 也存在漏采窗口。仅采集 active 不等于完整采集，保留文件也不等于会自动补采。
