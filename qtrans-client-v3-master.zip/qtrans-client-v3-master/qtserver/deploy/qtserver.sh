#!/usr/bin/env bash

# A simple script to manage qtserver process (start/stop/restart/status).
# Put this script in the same directory as the qtserver binary and config.

set -euo pipefail

APP_HOME="${APP_HOME:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"

BIN_PATH="${BIN_PATH:-${APP_HOME}/qtserver}"
CONFIG_PATH="${APP_HOME}/qtserver_config.toml"
OUTPUT_LOG="${OUTPUT_LOG:-${APP_HOME}/logs/qtserver.out}"

usage() {
    printf 'Usage: %s {start|stop|restart|status}\n' "${0##*/}" >&2
    exit 2
}

resolved_output_log() {
    if [[ "${OUTPUT_LOG}" = /* ]]; then
        printf '%s\n' "${OUTPUT_LOG}"
        return
    fi
    printf '%s\n' "${APP_HOME}/${OUTPUT_LOG}"
}

configured_port() {
    awk -F'=' '/^[[:space:]]*port[[:space:]]*=/{gsub(/[[:space:]]/, "", $2); print $2; exit}' "${CONFIG_PATH}"
}

configured_log_dir() {
    local log_dir
    log_dir="$(awk -F'=' '/^[[:space:]]*file_path[[:space:]]*=/{sub(/^[[:space:]]*"/, "", $2); sub(/"[[:space:]]*$/, "", $2); print $2; exit}' "${CONFIG_PATH}")"
    if [[ -z "${log_dir}" ]]; then
        log_dir="./logs"
    fi
    if [[ "${log_dir}" = /* ]]; then
        printf '%s\n' "${log_dir}"
        return
    fi
    printf '%s\n' "${APP_HOME}/${log_dir}"
}

show_start_failure_diagnostics() {
    local port listener output_log log_dir business_log

    port="$(configured_port || true)"
    output_log="$(resolved_output_log)"
    log_dir="$(configured_log_dir || true)"
    business_log="${log_dir}/qtserver.log"

    if [[ -n "${port}" ]]; then
        if command -v ss >/dev/null 2>&1; then
            listener="$(ss -ltnp 2>/dev/null | grep -F ":${port} " || true)"
        elif command -v netstat >/dev/null 2>&1; then
            listener="$(netstat -tlnp 2>/dev/null | grep -F ":${port} " || true)"
        fi
        if [[ -n "${listener:-}" ]]; then
            printf 'port %s appears to already be in use\n' "${port}" >&2
            printf '%s\n' "${listener}" >&2
        fi
    fi

    if [[ -s "${output_log}" ]]; then
        printf 'recent startup output from %s:\n' "${output_log}" >&2
        tail -n 20 "${output_log}" >&2 || true
    fi

    if [[ -s "${business_log}" ]]; then
        printf 'recent application log from %s:\n' "${business_log}" >&2
        tail -n 20 "${business_log}" >&2 || true
    fi
}

app_pid() {
    local bin_name pid exe_path cwd_path args

    bin_name="$(basename "${BIN_PATH}")"
    while read -r pid; do
        [[ -n "${pid}" ]] || continue

        if [[ -d "/proc/${pid}" ]]; then
            exe_path="$(readlink -f "/proc/${pid}/exe" 2>/dev/null || true)"
            cwd_path="$(readlink -f "/proc/${pid}/cwd" 2>/dev/null || true)"
            if [[ "${exe_path}" == "${BIN_PATH}" || "${cwd_path}" == "${APP_HOME}" ]]; then
                printf '%s\n' "${pid}"
                return 0
            fi
            continue
        fi

        args="$(ps -p "${pid}" -o args= 2>/dev/null || true)"
        case "${args}" in
            "${BIN_PATH}"|"./${bin_name}")
                printf '%s\n' "${pid}"
                return 0
                ;;
        esac
    done < <(pgrep -x "${bin_name}" || true)

    return 1
}

app_is_running() {
    app_pid >/dev/null 2>&1
}

start() {
    local running_pid output_log pid
    if app_is_running; then
        running_pid="$(app_pid)"
        printf 'qtserver is already running (pid=%s)\n' "${running_pid}"
        return 0
    fi

    [[ -x "${BIN_PATH}" ]] || {
        printf 'qtserver binary not found or not executable: %s\n' "${BIN_PATH}" >&2
        return 1
    }
    [[ -f "${CONFIG_PATH}" ]] || {
        printf 'qtserver config not found: %s\n' "${CONFIG_PATH}" >&2
        return 1
    }

    output_log="$(resolved_output_log)"
    mkdir -p "$(dirname "${output_log}")"
    (
        cd "${APP_HOME}"
        exec nohup "${BIN_PATH}" run -c "${CONFIG_PATH}" >>"${output_log}" 2>&1
    ) &
    pid=$!
    sleep 1

    if app_is_running; then
        printf 'qtserver started (pid=%s)\n' "$(app_pid)"
        return 0
    fi

    printf 'qtserver failed to start\n' >&2
    show_start_failure_diagnostics
    return 1
}

stop() {
    if ! app_is_running; then
        printf 'qtserver is not running\n'
        return 0
    fi

    local pid
    pid="$(app_pid)"
    kill "${pid}"

    for _ in $(seq 1 15); do
        if ! app_is_running; then
            printf 'qtserver stopped\n'
            return 0
        fi
        sleep 1
    done

    printf 'qtserver did not stop in time, sending SIGKILL\n'
    kill -9 "${pid}" 2>/dev/null || true
}

status() {
    local pid
    if app_is_running; then
        pid="$(app_pid)"
        printf 'qtserver is running (pid=%s)\n' "${pid}"
        return 0
    fi

    printf 'qtserver is stopped\n'
    return 1
}

case "${1:-}" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
        stop
        start
        ;;
    status)
        status
        ;;
    *)
        usage
        ;;
esac
