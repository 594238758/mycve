package logx

import (
	"fmt"
	"io"
	"log/slog"
	"os"
	"path/filepath"

	"qtserver/internal/config"

	"gopkg.in/natefinch/lumberjack.v2"
)

var (
	businessLogger *slog.Logger
	ginLogger      io.Writer
)

const (
	DefaultLogName    = "qtserver.log"
	DefaultGinLogName = "gin.log"
)

// newLogWriter creates a log writer based on rotation config
func newLogWriter(logPath string, rotation config.LogRotationConfig) (io.Writer, error) {
	if rotation.Enable {
		file, err := os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
		if err != nil {
			return nil, err
		}
		if err := file.Close(); err != nil {
			return nil, err
		}
		return &lumberjack.Logger{
			Filename:   logPath,
			MaxSize:    rotation.MaxSize,
			MaxBackups: rotation.MaxBackups,
			MaxAge:     rotation.MaxAge,
			Compress:   rotation.Compress,
		}, nil
	}

	// If rotation is disabled, just write to file
	return os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o666)
}

// InitLogger initializes both business and gin loggers
func InitLogger(cfg *config.Config) error {
	// Ensure log directory exists

	logDir, err := config.ResolveLogDirectory(cfg.Log.FilePath)
	if err != nil {
		return fmt.Errorf("failed to resolve log directory: %w", err)
	}

	if err := os.MkdirAll(logDir, 0755); err != nil {
		return fmt.Errorf("failed to create log directory: %w", err)
	}

	// Initialize business logger (qtserver.log) with JSON format
	businessLogWriter, err := newLogWriter(
		filepath.Join(logDir, DefaultLogName),
		cfg.Log.Rotation,
	)
	if err != nil {
		return fmt.Errorf("failed to create business log writer: %w", err)
	}

	// Parse log level
	logLevel := parseLogLevel(cfg.Log.Level)

	// Create JSON handler for business logger
	handler := slog.NewJSONHandler(businessLogWriter, &slog.HandlerOptions{
		Level: logLevel,
	})
	businessLogger = slog.New(handler)

	// Set as default logger
	slog.SetDefault(businessLogger)

	// Initialize gin logger (gin.log)
	var ginErr error
	ginLogger, ginErr = newLogWriter(
		filepath.Join(logDir, DefaultGinLogName),
		cfg.Log.Rotation,
	)
	if ginErr != nil {
		return fmt.Errorf("failed to create gin log writer: %w", ginErr)
	}
	return nil
}

// GetBusinessLogger returns the business logger instance
func GetBusinessLogger() *slog.Logger {
	return businessLogger
}

// GetGinLogger returns the gin logger writer
func GetGinLogger() io.Writer {
	return ginLogger
}

// parseLogLevel converts string log level to slog.Level
func parseLogLevel(level string) slog.Level {
	switch level {
	case "debug":
		return slog.LevelDebug
	case "info":
		return slog.LevelInfo
	case "warn":
		return slog.LevelWarn
	case "error":
		return slog.LevelError
	default:
		return slog.LevelInfo
	}
}
