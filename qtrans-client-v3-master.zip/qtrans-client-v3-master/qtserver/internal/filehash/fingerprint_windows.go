//go:build windows

package filehash

import "os"

func fingerprintFromInfo(info os.FileInfo) Fingerprint {
	return Fingerprint{CTimeNS: info.ModTime().UnixNano(), MTimeNS: info.ModTime().UnixNano(), Size: info.Size()}
}
