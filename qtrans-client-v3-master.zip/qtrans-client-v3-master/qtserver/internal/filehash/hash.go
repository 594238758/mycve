package filehash

import (
	"context"
	"encoding/hex"
	"errors"
	"io"
	"os"
	"strconv"
	"strings"

	"github.com/zeebo/xxh3"
)

const (
	ChunkSize        = 104857600
	ChunkAlgorithm   = "xxh3_128"
	LayeredAlgorithm = "layered_xxh3_128_v1"
	AlgorithmVersion = 1
	digestBytes      = 16
	streamBufferSize = 64 * 1024
)

// LayeredHasher incrementally computes layered_xxh3_128_v1 without retaining
// a complete logical chunk in memory. Finalize must be called after the final
// payload byte has been written.
type LayeredHasher struct {
	chunk        *xxh3.Hasher
	overall      *xxh3.Hasher
	chunkBytes   int64
	finalized    bool
	finalizedSum string
}

func NewLayeredHasher() *LayeredHasher {
	return &LayeredHasher{
		chunk:   xxh3.New(),
		overall: xxh3.New(),
	}
}

func (h *LayeredHasher) Write(p []byte) (int, error) {
	if h == nil {
		return 0, errors.New("nil layered hasher")
	}
	if h.finalized {
		return 0, errors.New("layered hasher already finalized")
	}

	written := 0
	for len(p) > 0 {
		remaining := int64(ChunkSize) - h.chunkBytes
		take := len(p)
		if int64(take) > remaining {
			take = int(remaining)
		}
		n, err := h.chunk.Write(p[:take])
		written += n
		h.chunkBytes += int64(n)
		p = p[n:]
		if err != nil {
			return written, err
		}
		if n != take {
			return written, io.ErrShortWrite
		}
		if h.chunkBytes == int64(ChunkSize) {
			if err := h.commitChunk(); err != nil {
				return written, err
			}
		}
	}
	return written, nil
}

func (h *LayeredHasher) Finalize() (string, error) {
	if h == nil {
		return "", errors.New("nil layered hasher")
	}
	if h.finalized {
		return h.finalizedSum, nil
	}
	if h.chunkBytes > 0 {
		if err := h.commitChunk(); err != nil {
			return "", err
		}
	}
	sum := h.overall.Sum128().Bytes()
	h.finalizedSum = hex.EncodeToString(sum[:])
	h.finalized = true
	return h.finalizedSum, nil
}

func (h *LayeredHasher) commitChunk() error {
	sum := h.chunk.Sum128().Bytes()
	if _, err := h.overall.Write(sum[:]); err != nil {
		return err
	}
	h.chunk = xxh3.New()
	h.chunkBytes = 0
	return nil
}

func ChunkBytes(content []byte) string {
	hash := xxh3.Hash128(content)
	sum := hash.Bytes()
	return hex.EncodeToString(sum[:])
}

func ChunkReader(reader io.Reader) (string, error) {
	hasher := xxh3.New()
	if _, err := io.Copy(hasher, reader); err != nil {
		return "", err
	}
	sum := hasher.Sum128().Bytes()
	return hex.EncodeToString(sum[:]), nil
}

func LayeredFromChunkHashes(hashes map[string]string, count int) (string, bool, error) {
	if count < 0 {
		return "", false, errors.New("invalid chunk count")
	}
	overall := xxh3.New()
	for index := 0; index < count; index++ {
		encoded := strings.TrimSpace(hashes[strconv.Itoa(index)])
		if encoded == "" {
			return "", false, nil
		}
		digest, err := hex.DecodeString(encoded)
		if err != nil || len(digest) != digestBytes {
			return "", false, nil
		}
		if _, err := overall.Write(digest); err != nil {
			return "", false, err
		}
	}
	sum := overall.Sum128().Bytes()
	return hex.EncodeToString(sum[:]), true, nil
}

func LayeredReader(ctx context.Context, reader io.Reader) (string, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	hasher := NewLayeredHasher()
	buffer := make([]byte, streamBufferSize)
	for {
		if err := ctx.Err(); err != nil {
			return "", err
		}
		n, err := reader.Read(buffer)
		if n > 0 {
			if _, writeErr := hasher.Write(buffer[:n]); writeErr != nil {
				return "", writeErr
			}
		}
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil {
			return "", err
		}
	}
	return hasher.Finalize()
}

func LayeredFile(ctx context.Context, path string) (string, error) {
	file, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer file.Close()
	return LayeredReader(ctx, file)
}

type Fingerprint struct {
	CTimeNS int64 `json:"ctime_ns"`
	MTimeNS int64 `json:"mtime_ns"`
	Size    int64 `json:"file_size"`
}

func (f Fingerprint) Equal(other Fingerprint) bool {
	return f.CTimeNS == other.CTimeNS && f.MTimeNS == other.MTimeNS && f.Size == other.Size
}

func FingerprintPath(path string) (Fingerprint, error) {
	info, err := os.Stat(path)
	if err != nil {
		return Fingerprint{}, err
	}
	if !info.Mode().IsRegular() {
		return Fingerprint{}, errors.New("target is not a regular file")
	}
	return fingerprintFromInfo(info), nil
}
