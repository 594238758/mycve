//go:build !windows

package filehash

import (
	"os"
	"syscall"
)

func fingerprintFromInfo(info os.FileInfo) Fingerprint {
	fp := Fingerprint{MTimeNS: info.ModTime().UnixNano(), Size: info.Size()}
	if stat, ok := info.Sys().(*syscall.Stat_t); ok {
		fp.CTimeNS = stat.Ctim.Sec*1_000_000_000 + stat.Ctim.Nsec
	}
	return fp
}
