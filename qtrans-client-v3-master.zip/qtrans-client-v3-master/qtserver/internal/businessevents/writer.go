package businessevents

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"qtserver/internal/filespace"
)

const (
	ActiveFilename       = "business-events.jsonl"
	legacyActiveFilename = "business_events.log"
	maxEventBytes        = 1 << 20
)

var ErrUnavailable = errors.New("business event log unavailable")

type Durability uint8

const (
	DurabilityAppend Durability = iota
	DurabilitySync
)

type BusinessEventSink interface {
	Append(context.Context, Envelope, Durability) error
	Healthy() bool
	Reopen() error
	Close() error
}

type WriterOptions struct {
	Directory       string
	RotationEnabled bool
	MaxSizeMB       int
	MaxBackups      int
	MaxAgeDays      int
	Compress        bool
	Now             func() time.Time
}

type Writer struct {
	mu       sync.Mutex
	opts     WriterOptions
	file     *os.File
	syncFile func(*os.File) error
	path     string
	segment  uint64
	size     int64
	healthy  bool
	closed   bool
}

func NewWriter(opts WriterOptions) (*Writer, error) {
	if strings.TrimSpace(opts.Directory) == "" {
		return nil, fmt.Errorf("business event directory is required")
	}
	if opts.MaxSizeMB <= 0 {
		opts.MaxSizeMB = 100
	}
	if opts.Now == nil {
		opts.Now = time.Now
	}
	if err := os.MkdirAll(opts.Directory, 0o755); err != nil {
		return nil, fmt.Errorf("create business event directory: %w", err)
	}
	w := &Writer{opts: opts, syncFile: (*os.File).Sync}
	w.mu.Lock()
	err := w.openActiveLocked()
	w.mu.Unlock()
	if err != nil {
		return nil, err
	}
	return w, nil
}

func (w *Writer) Append(ctx context.Context, event Envelope, durability Durability) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.closed || !w.healthy || w.file == nil {
		return ErrUnavailable
	}
	if err := w.appendLocked(event); err != nil {
		return err
	}
	if durability == DurabilitySync {
		if err := w.syncLocked(); err != nil {
			return err
		}
	}
	return nil
}

// AppendBatch appends a group of terminal observations under one writer lock
// and makes them durable with one final file sync. A rotation may still sync a
// closing segment before the final batch sync.
func (w *Writer) AppendBatch(ctx context.Context, events []Envelope) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if len(events) == 0 {
		return nil
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.closed || !w.healthy || w.file == nil {
		return ErrUnavailable
	}
	for _, event := range events {
		if err := ctx.Err(); err != nil {
			return err
		}
		if err := w.appendLocked(event); err != nil {
			return err
		}
	}
	return w.syncLocked()
}

func (w *Writer) appendLocked(event Envelope) error {

	event.SchemaVersion = SchemaVersion
	event.OccurredAt = NewTimestamp(event.OccurredAt.Time)
	line, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("marshal business event: %w", err)
	}
	if len(line) > maxEventBytes {
		return fmt.Errorf("business event exceeds %d bytes", maxEventBytes)
	}
	line = append(line, '\n')
	if w.shouldRotateLocked(int64(len(line))) {
		if err := w.rotateLocked(); err != nil {
			w.healthy = false
			return errors.Join(ErrUnavailable, err)
		}
	}

	startOffset, err := w.file.Seek(0, io.SeekEnd)
	if err != nil {
		w.healthy = false
		return errors.Join(ErrUnavailable, fmt.Errorf("seek business event segment: %w", err))
	}
	n, writeErr := w.file.Write(line)
	if n == len(line) {
		w.size += int64(n)
		if writeErr != nil {
			w.healthy = false
			return errors.Join(ErrUnavailable, fmt.Errorf("append complete business event: %w", writeErr))
		}
	} else {
		rollbackErr := w.file.Truncate(startOffset)
		if rollbackErr == nil {
			rollbackErr = w.syncFile(w.file)
			if rollbackErr == nil {
				w.size = startOffset
			}
		}
		w.healthy = false
		if writeErr == nil {
			writeErr = io.ErrShortWrite
		}
		return errors.Join(
			ErrUnavailable,
			fmt.Errorf("append business event: %w", writeErr),
			wrapOptionalError("restore business event boundary", rollbackErr),
		)
	}
	return nil
}

func (w *Writer) syncLocked() error {
	if err := w.syncFile(w.file); err != nil {
		w.healthy = false
		return errors.Join(ErrUnavailable, fmt.Errorf("sync business event: %w", err))
	}
	return nil
}

func (w *Writer) Healthy() bool {
	w.mu.Lock()
	defer w.mu.Unlock()
	return !w.closed && w.healthy
}

func (w *Writer) Reopen() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.closed {
		return ErrUnavailable
	}
	if w.file != nil {
		_ = w.file.Close()
		w.file = nil
	}
	if err := w.openActiveLocked(); err != nil {
		w.healthy = false
		return errors.Join(ErrUnavailable, err)
	}
	return nil
}

func (w *Writer) Close() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.closed {
		return nil
	}
	w.closed = true
	w.healthy = false
	var closeErr error
	if w.file != nil {
		if err := w.file.Close(); err != nil {
			closeErr = errors.Join(closeErr, err)
		}
		w.file = nil
	}
	if _, err := repairSegmentTailWithSync(w.path, w.syncFile); err != nil {
		return errors.Join(closeErr, fmt.Errorf("repair closing business event segment: %w", err))
	}
	return closeErr
}

func (w *Writer) shouldRotateLocked(additional int64) bool {
	return w.opts.RotationEnabled && w.size > 0 && w.size+additional > int64(w.opts.MaxSizeMB)*1024*1024
}

func (w *Writer) rotateLocked() error {
	if err := w.syncFile(w.file); err != nil {
		return fmt.Errorf("sync closing business event segment: %w", err)
	}
	if err := w.file.Close(); err != nil {
		return fmt.Errorf("close business event segment: %w", err)
	}
	w.file = nil
	archivePath, err := w.archiveActiveLocked()
	if err != nil {
		return err
	}
	if err := syncDirectory(w.opts.Directory); err != nil {
		return err
	}
	if err := w.createActiveLocked(); err != nil {
		return err
	}
	if err := w.finishSegmentLocked(archivePath); err != nil {
		return err
	}
	return nil
}

func (w *Writer) archiveActiveLocked() (string, error) {
	timestamp := w.opts.Now().UTC().Format("20060102T150405.000000000Z")
	activePath := filepath.Join(w.opts.Directory, ActiveFilename)
	for attempt := 0; attempt < 1000; attempt++ {
		w.segment++
		archivePath := filepath.Join(w.opts.Directory, fmt.Sprintf("business-events-%s-%06d.jsonl", timestamp, w.segment))
		if _, err := os.Lstat(archivePath + ".gz"); err == nil {
			continue
		} else if !os.IsNotExist(err) {
			return "", fmt.Errorf("inspect compressed business event archive: %w", err)
		}
		if err := filespace.RenameNoReplace(activePath, archivePath); err == nil {
			return archivePath, nil
		} else if errors.Is(err, os.ErrExist) {
			continue
		} else {
			return "", fmt.Errorf("archive active business event file: %w", err)
		}
	}
	return "", fmt.Errorf("archive active business event file: no unique archive name available")
}

func (w *Writer) openActiveLocked() error {
	if err := w.migrateLegacyActiveLocked(); err != nil {
		return err
	}
	activePath := filepath.Join(w.opts.Directory, ActiveFilename)
	info, err := os.Lstat(activePath)
	if os.IsNotExist(err) {
		return w.createActiveLocked()
	}
	if err != nil {
		return fmt.Errorf("inspect active business event file: %w", err)
	}
	if !info.Mode().IsRegular() {
		return fmt.Errorf("active business event path is not a regular file")
	}
	size, err := repairSegmentTailWithSync(activePath, w.syncFile)
	if err != nil {
		return fmt.Errorf("repair active business event file: %w", err)
	}
	file, err := os.OpenFile(activePath, os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		return fmt.Errorf("open active business event file: %w", err)
	}
	w.file = file
	w.path = activePath
	w.size = size
	w.healthy = true
	return nil
}

func (w *Writer) createActiveLocked() error {
	activePath := filepath.Join(w.opts.Directory, ActiveFilename)
	file, err := os.OpenFile(activePath, os.O_CREATE|os.O_EXCL|os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		return fmt.Errorf("create active business event file: %w", err)
	}
	if err := w.syncFile(file); err != nil {
		_ = file.Close()
		return fmt.Errorf("sync new active business event file: %w", err)
	}
	if err := syncDirectory(w.opts.Directory); err != nil {
		_ = file.Close()
		return err
	}
	w.file = file
	w.path = activePath
	w.size = 0
	w.healthy = true
	return nil
}

func (w *Writer) migrateLegacyActiveLocked() error {
	activePath := filepath.Join(w.opts.Directory, ActiveFilename)
	legacyPath := filepath.Join(w.opts.Directory, legacyActiveFilename)
	_, activeExists, err := regularFileInfo(activePath)
	if err != nil {
		return fmt.Errorf("inspect active business event file: %w", err)
	}
	legacyInfo, legacyExists, err := regularFileInfo(legacyPath)
	if err != nil {
		return fmt.Errorf("inspect legacy active business event file: %w", err)
	}
	if activeExists && legacyExists {
		return fmt.Errorf("both active business event files exist: %s and %s", activePath, legacyPath)
	}
	if activeExists || !legacyExists {
		return nil
	}
	if _, err := repairSegmentTailWithSync(legacyPath, w.syncFile); err != nil {
		return fmt.Errorf("repair legacy active business event file: %w", err)
	}
	legacyInfo, legacyExists, err = regularFileInfo(legacyPath)
	if err != nil || !legacyExists {
		if err == nil {
			err = os.ErrNotExist
		}
		return fmt.Errorf("reinspect legacy active business event file: %w", err)
	}
	matches, err := filepath.Glob(filepath.Join(w.opts.Directory, "business-events-*.jsonl"))
	if err != nil {
		return fmt.Errorf("list legacy business event archives: %w", err)
	}
	linkedArchives := make([]string, 0, 1)
	for _, candidate := range matches {
		info, statErr := os.Stat(candidate)
		if statErr != nil {
			return fmt.Errorf("inspect legacy business event archive %s: %w", candidate, statErr)
		}
		if os.SameFile(legacyInfo, info) {
			linkedArchives = append(linkedArchives, candidate)
		}
	}
	if len(linkedArchives) > 1 {
		return fmt.Errorf("legacy active business event file has multiple archive links")
	}
	if len(linkedArchives) == 1 {
		if err := os.Remove(linkedArchives[0]); err != nil {
			return fmt.Errorf("remove legacy active archive link: %w", err)
		}
		if err := syncDirectory(w.opts.Directory); err != nil {
			return err
		}
	}
	if err := filespace.RenameNoReplace(legacyPath, activePath); err != nil {
		return fmt.Errorf("migrate legacy active business event file: %w", err)
	}
	return syncDirectory(w.opts.Directory)
}

func regularFileInfo(path string) (os.FileInfo, bool, error) {
	info, err := os.Lstat(path)
	if os.IsNotExist(err) {
		return nil, false, nil
	}
	if err != nil {
		return nil, false, err
	}
	if !info.Mode().IsRegular() {
		return nil, false, fmt.Errorf("path is not a regular file: %s", path)
	}
	return info, true, nil
}

func repairSegmentTailWithSync(path string, syncFile func(*os.File) error) (int64, error) {
	if strings.TrimSpace(path) == "" {
		return 0, fmt.Errorf("business event segment path is empty")
	}
	file, err := os.OpenFile(path, os.O_RDWR, 0o600)
	if err != nil {
		return 0, err
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return 0, err
	}
	size := info.Size()
	if size > 0 {
		last := []byte{0}
		if _, err := file.ReadAt(last, size-1); err != nil {
			return 0, err
		}
		if last[0] != '\n' {
			boundary, err := lastCompleteLineBoundary(file, size)
			if err != nil {
				return 0, err
			}
			if err := file.Truncate(boundary); err != nil {
				return 0, err
			}
			size = boundary
		}
	}
	if err := syncFile(file); err != nil {
		return 0, err
	}
	return size, nil
}

func lastCompleteLineBoundary(file *os.File, size int64) (int64, error) {
	const blockSize = int64(4096)
	buffer := make([]byte, blockSize)
	for end := size; end > 0; {
		start := end - blockSize
		if start < 0 {
			start = 0
		}
		chunk := buffer[:end-start]
		n, err := file.ReadAt(chunk, start)
		if err != nil && !errors.Is(err, io.EOF) {
			return 0, err
		}
		if index := bytes.LastIndexByte(chunk[:n], '\n'); index >= 0 {
			return start + int64(index) + 1, nil
		}
		end = start
	}
	return 0, nil
}

func wrapOptionalError(message string, err error) error {
	if err == nil {
		return nil
	}
	return fmt.Errorf("%s: %w", message, err)
}

func (w *Writer) finishSegmentLocked(segmentPath string) error {
	if segmentPath == "" {
		return nil
	}
	if w.opts.Compress {
		if err := gzipFile(segmentPath); err != nil {
			return fmt.Errorf("compress business event segment: %w", err)
		}
	}
	return w.cleanupSegmentsLocked()
}

func (w *Writer) cleanupSegmentsLocked() error {
	matches, err := filepath.Glob(filepath.Join(w.opts.Directory, "business-events-*.jsonl*"))
	if err != nil {
		return err
	}
	type segment struct {
		path string
		mod  time.Time
	}
	segments := make([]segment, 0, len(matches))
	for _, candidate := range matches {
		if candidate == w.path {
			continue
		}
		info, statErr := os.Stat(candidate)
		if statErr != nil {
			continue
		}
		if w.opts.MaxAgeDays > 0 && w.opts.Now().UTC().Sub(info.ModTime()) > time.Duration(w.opts.MaxAgeDays)*24*time.Hour {
			if err := os.Remove(candidate); err != nil && !os.IsNotExist(err) {
				return err
			}
			continue
		}
		segments = append(segments, segment{path: candidate, mod: info.ModTime()})
	}
	if w.opts.MaxBackups <= 0 || len(segments) <= w.opts.MaxBackups {
		return nil
	}
	sort.Slice(segments, func(i, j int) bool { return segments[i].mod.Before(segments[j].mod) })
	for _, old := range segments[:len(segments)-w.opts.MaxBackups] {
		if err := os.Remove(old.path); err != nil && !os.IsNotExist(err) {
			return err
		}
	}
	return nil
}

func gzipFile(source string) error {
	in, err := os.Open(source)
	if os.IsNotExist(err) {
		return nil
	}
	if err != nil {
		return err
	}
	defer in.Close()
	temp := source + ".gz.tmp"
	out, err := os.OpenFile(temp, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o600)
	if err != nil {
		return err
	}
	gz := gzip.NewWriter(out)
	_, copyErr := io.Copy(gz, in)
	closeErr := errors.Join(gz.Close(), out.Sync(), out.Close())
	if copyErr != nil || closeErr != nil {
		_ = os.Remove(temp)
		return errors.Join(copyErr, closeErr)
	}
	destination := source + ".gz"
	if err := os.Rename(temp, destination); err != nil {
		_ = os.Remove(temp)
		return err
	}
	return os.Remove(source)
}

func syncDirectory(directory string) error {
	file, err := os.Open(directory)
	if err != nil {
		return fmt.Errorf("open business event directory: %w", err)
	}
	defer file.Close()
	if err := file.Sync(); err != nil {
		return fmt.Errorf("sync business event directory: %w", err)
	}
	return nil
}
