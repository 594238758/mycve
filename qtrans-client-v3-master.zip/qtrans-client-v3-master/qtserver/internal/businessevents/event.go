package businessevents

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

const (
	SchemaVersion      = 1
	TimestampLayout    = "2006-01-02T15:04:05.000-07:00"
	fileKeyDomain      = "qtrans-file-v1"
	ActionUpload       = "upload"
	ActionDownload     = "download"
	DefaultTaskType    = "1"
	DefaultTimeoutSecs = 86400
	AnonymousPrincipal = "anonymous"
)

type EventType string

const (
	EventFileRegistered         EventType = "file.registered"
	EventUploadChunkFinished    EventType = "upload.chunk_finished"
	EventUploadVerifyFinished   EventType = "upload.verify_finished"
	EventUploadFinished         EventType = "upload.finished"
	EventDownloadChunkFinished  EventType = "download.chunk_finished"
	EventDownloadVerifyFinished EventType = "download.verify_finished"
	EventDownloadSmallFileSent  EventType = "download.small_file_sent"
)

type ChunkResult string

const (
	ChunkSucceeded   ChunkResult = "succeeded"
	ChunkInterrupted ChunkResult = "interrupted"
	ChunkFailed      ChunkResult = "failed"
)

type VerificationResult string

const (
	VerificationMatched    VerificationResult = "matched"
	VerificationMismatched VerificationResult = "mismatched"
	VerificationFailed     VerificationResult = "failed"
)

type VerificationScope string

const (
	VerificationScopeChunk VerificationScope = "chunk"
	VerificationScopeFile  VerificationScope = "file"
)

type UploadFinishResult string

const (
	UploadCommitted      UploadFinishResult = "committed"
	UploadAlreadyPresent UploadFinishResult = "already_present"
)

const ReasonBusinessLogUnavailable = "BUSINESS_LOG_UNAVAILABLE"

type TaskCorrelation struct {
	TaskID       string
	TaskPID      string
	EnterpriseID string
}

// Timestamp is a wire timestamp with the host-local offset and millisecond precision.
type Timestamp struct {
	time.Time
}

func NewTimestamp(value time.Time) Timestamp {
	return Timestamp{Time: value.In(time.Local).Truncate(time.Millisecond)}
}

func (t Timestamp) MarshalJSON() ([]byte, error) {
	if t.Time.IsZero() {
		return nil, fmt.Errorf("business event timestamp is required")
	}
	return json.Marshal(t.Time.In(time.Local).Truncate(time.Millisecond).Format(TimestampLayout))
}

func (t *Timestamp) UnmarshalJSON(data []byte) error {
	var encoded string
	if err := json.Unmarshal(data, &encoded); err != nil {
		return fmt.Errorf("decode business event timestamp: %w", err)
	}
	parsed, err := time.Parse(TimestampLayout, encoded)
	if err != nil || parsed.Format(TimestampLayout) != encoded {
		return fmt.Errorf("invalid business event timestamp %q", encoded)
	}
	t.Time = parsed.In(time.Local)
	return nil
}

type Envelope struct {
	SchemaVersion int             `json:"schema_version"`
	EventType     EventType       `json:"event_type"`
	OccurredAt    Timestamp       `json:"occurred_at"`
	TaskID        string          `json:"task_id"`
	TaskPID       string          `json:"taskpid"`
	EnterpriseID  string          `json:"enterprise_id"`
	FileKey       string          `json:"file_key"`
	Payload       json.RawMessage `json:"payload"`
}

func NewEnvelope(eventType EventType, occurredAt time.Time, taskID, fileKey string, payload any) (Envelope, error) {
	return NewEnvelopeWithCorrelation(eventType, occurredAt, TaskCorrelation{TaskID: taskID}, fileKey, payload)
}

func NewEnvelopeWithCorrelation(eventType EventType, occurredAt time.Time, correlation TaskCorrelation, fileKey string, payload any) (Envelope, error) {
	if !eventType.Valid() {
		return Envelope{}, fmt.Errorf("unsupported business event type %q", eventType)
	}
	if strings.TrimSpace(correlation.TaskID) == "" {
		return Envelope{}, fmt.Errorf("task id is required")
	}
	if strings.TrimSpace(fileKey) == "" {
		return Envelope{}, fmt.Errorf("file key is required")
	}
	if occurredAt.IsZero() {
		return Envelope{}, fmt.Errorf("occurred_at is required")
	}
	payloadJSON, err := json.Marshal(payload)
	if err != nil {
		return Envelope{}, fmt.Errorf("marshal business event payload: %w", err)
	}
	if string(payloadJSON) == "null" {
		return Envelope{}, fmt.Errorf("business event payload must be an object")
	}
	return Envelope{
		SchemaVersion: SchemaVersion,
		EventType:     eventType,
		OccurredAt:    NewTimestamp(occurredAt),
		TaskID:        correlation.TaskID,
		TaskPID:       correlation.TaskPID,
		EnterpriseID:  correlation.EnterpriseID,
		FileKey:       fileKey,
		Payload:       payloadJSON,
	}, nil
}

func (t EventType) Valid() bool {
	switch t {
	case EventFileRegistered,
		EventUploadChunkFinished,
		EventUploadVerifyFinished,
		EventUploadFinished,
		EventDownloadChunkFinished,
		EventDownloadVerifyFinished,
		EventDownloadSmallFileSent:
		return true
	default:
		return false
	}
}

// FileKey encodes the already-normalized file activity tuple. Path
// normalization belongs to qtserver's filespace layer, not to this function.
func FileKey(taskID, normalizedFilePath, principalID, action string) string {
	identity := strings.Join([]string{
		fileKeyDomain,
		taskID,
		normalizedFilePath,
		principalID,
		action,
	}, "\x00")
	sum := sha256.Sum256([]byte(identity))
	return base64.RawURLEncoding.EncodeToString(sum[:])
}

type FileRegisteredPayload struct {
	TaskType                     string `json:"task_type"`
	Action                       string `json:"action"`
	FilePath                     string `json:"file_path"`
	FileSize                     int64  `json:"file_size"`
	PrincipalID                  string `json:"principal_id"`
	ClientUsername               string `json:"client_username"`
	ClientID                     string `json:"client_id"`
	ClientIP                     string `json:"client_ip"`
	ClientOS                     string `json:"client_os"`
	ClientVersion                string `json:"client_version"`
	CallerVersion                string `json:"caller_version"`
	ServerIP                     string `json:"server_ip"`
	ServerInstance               string `json:"server_instance"`
	ServerVersion                string `json:"server_version"`
	FileInactivityTimeoutSeconds int64  `json:"file_inactivity_timeout_seconds"`
}

type UploadChunkFinishedPayload struct {
	ChunkIndex  int         `json:"chunk_index"`
	RangeStart  int64       `json:"range_start"`
	RangeEnd    int64       `json:"range_end"`
	ActualBytes int64       `json:"actual_bytes"`
	Result      ChunkResult `json:"result"`
}

type UploadVerifyFinishedPayload struct {
	ChunkIndex         int                `json:"chunk_index"`
	VerificationResult VerificationResult `json:"verification_result"`
}

type UploadFinishedPayload struct {
	Result UploadFinishResult `json:"result"`
}

type DownloadChunkFinishedPayload struct {
	ChunkIndex  int         `json:"chunk_index"`
	RangeStart  int64       `json:"range_start"`
	RangeEnd    int64       `json:"range_end"`
	ActualBytes int64       `json:"actual_bytes"`
	HTTPStatus  int         `json:"http_status"`
	Result      ChunkResult `json:"result"`
}

type DownloadVerifyFinishedPayload struct {
	VerificationScope  VerificationScope  `json:"verification_scope"`
	ChunkIndex         *int               `json:"chunk_index"`
	VerificationResult VerificationResult `json:"verification_result"`
}

type DownloadSmallFileSentPayload struct {
	TaskType       string    `json:"task_type"`
	Action         string    `json:"action"`
	FilePath       string    `json:"file_path"`
	FileSize       int64     `json:"file_size"`
	PrincipalID    string    `json:"principal_id"`
	ClientUsername string    `json:"client_username"`
	ClientID       string    `json:"client_id"`
	ClientIP       string    `json:"client_ip"`
	ClientOS       string    `json:"client_os"`
	ClientVersion  string    `json:"client_version"`
	CallerVersion  string    `json:"caller_version"`
	ServerIP       string    `json:"server_ip"`
	ServerInstance string    `json:"server_instance"`
	ServerVersion  string    `json:"server_version"`
	StartedAt      Timestamp `json:"started_at"`
}
