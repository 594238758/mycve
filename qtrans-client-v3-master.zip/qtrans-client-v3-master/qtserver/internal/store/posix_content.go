package store

import (
	"os"
	"path/filepath"

	"qtserver/internal/config"
	"qtserver/internal/misc"
)

type POSIXContentStore struct {
	downloadsRoot string
	uploadsRoot   string
}

func NewPOSIXContentStore(cfg config.ServerConfig) *POSIXContentStore {
	return &POSIXContentStore{
		downloadsRoot: cfg.UserHomeRoot,
		uploadsRoot:   cfg.UserHomeRoot,
	}
}

func (s *POSIXContentStore) DownloadHome(principalID string) (string, error) {
	owner, err := misc.NormalizeOwner(principalID)
	if err != nil {
		return "", err
	}
	return filepath.Join(filepath.Clean(s.downloadsRoot), owner), nil
}

func (s *POSIXContentStore) UploadHome(principalID string) (string, error) {
	owner, err := misc.NormalizeOwner(principalID)
	if err != nil {
		return "", err
	}
	return filepath.Join(filepath.Clean(s.uploadsRoot), owner), nil
}

func (s *POSIXContentStore) DownloadPath(principalID, objectKey string) (string, error) {
	owner, err := misc.NormalizeOwner(principalID)
	if err != nil {
		return "", err
	}
	return misc.ResolveUserObjectPath(s.downloadsRoot, owner, objectKey)
}

func (s *POSIXContentStore) UploadPath(principalID, objectKey string) (string, error) {
	return misc.ResolveUserObjectPath(s.uploadsRoot, principalID, objectKey)
}

func (s *POSIXContentStore) Stat(path string) (os.FileInfo, error) {
	return os.Stat(path)
}

func (s *POSIXContentStore) Lstat(path string) (os.FileInfo, error) {
	return os.Lstat(path)
}

func (s *POSIXContentStore) ReadDir(path string) ([]os.DirEntry, error) {
	return os.ReadDir(path)
}

func (s *POSIXContentStore) MkdirAll(path string, perm os.FileMode) error {
	return os.MkdirAll(path, perm)
}

func (s *POSIXContentStore) Remove(path string) error {
	return os.Remove(path)
}

func (s *POSIXContentStore) RemoveAll(path string) error {
	return os.RemoveAll(path)
}

func (s *POSIXContentStore) Rename(oldPath, newPath string) error {
	return os.Rename(oldPath, newPath)
}

func (s *POSIXContentStore) Open(path string) (*os.File, error) {
	return os.Open(path)
}

func (s *POSIXContentStore) OpenFile(path string, flag int, perm os.FileMode) (*os.File, error) {
	return os.OpenFile(path, flag, perm)
}

func (s *POSIXContentStore) WriteFile(path string, data []byte, perm os.FileMode) error {
	return os.WriteFile(path, data, perm)
}

func (s *POSIXContentStore) Truncate(path string, size int64) error {
	return os.Truncate(path, size)
}
