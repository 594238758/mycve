package store

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"time"

	"github.com/redis/go-redis/v9"
)

type CanonicalUploadResult struct {
	Code          int       `json:"code"`
	Status        string    `json:"status"`
	SessionID     string    `json:"session_id"`
	ObjectKey     string    `json:"object_key"`
	FileSize      int64     `json:"file_size"`
	FileHash      string    `json:"file_hash"`
	HashAlgorithm string    `json:"hash_algorithm"`
	CommittedAt   time.Time `json:"committed_at"`
}

type CanonicalUploadPublishIntent struct {
	TargetPath string `json:"target_path"`
	CachePath  string `json:"cache_path"`
	FileSize   int64  `json:"file_size"`
	FileHash   string `json:"file_hash"`
	Method     string `json:"method"`
}

type CanonicalUploadSession struct {
	SessionID     string                        `json:"session_id"`
	TaskID        string                        `json:"task_id"`
	TaskPID       string                        `json:"taskpid"`
	EnterpriseID  string                        `json:"enterprise_id"`
	FileKey       string                        `json:"file_key"`
	PrincipalID   string                        `json:"principal_id"`
	ObjectKey     string                        `json:"object_key"`
	FileSize      int64                         `json:"file_size"`
	FileHash      string                        `json:"file_hash"`
	HashAlgorithm string                        `json:"hash_algorithm"`
	Overwrite     bool                          `json:"overwrite"`
	ChunkSize     int64                         `json:"chunk_size"`
	ChunkCount    int                           `json:"chunk_count"`
	Status        string                        `json:"status"`
	CachePath     string                        `json:"cache_path"`
	CreatedAt     time.Time                     `json:"created_at"`
	PublishIntent *CanonicalUploadPublishIntent `json:"publish_intent,omitempty"`
	Result        *CanonicalUploadResult        `json:"result,omitempty"`
}

type CanonicalChunk struct {
	State  string `json:"state"`
	Stored int64  `json:"stored"`
	Hash   string `json:"hash,omitempty"`
}

func (s *RedisStore) CreateCanonicalUpload(ctx context.Context, session CanonicalUploadSession, ttl time.Duration) error {
	payload, err := json.Marshal(session)
	if err != nil {
		return err
	}
	ok, err := s.client.SetNX(ctx, s.canonicalUploadKey(session.SessionID), payload, ttl).Result()
	if err != nil {
		return fmt.Errorf("create canonical upload: %w", err)
	}
	if !ok {
		return ErrConflict
	}
	if err := s.client.Set(ctx, s.canonicalUploadTombstoneKey(session.SessionID), payload, canonicalUploadTombstoneTTL(ttl)).Err(); err != nil {
		_ = s.client.Del(ctx, s.canonicalUploadKey(session.SessionID)).Err()
		return fmt.Errorf("create canonical upload tombstone: %w", err)
	}
	return nil
}

func (s *RedisStore) GetCanonicalUpload(ctx context.Context, sessionID string) (CanonicalUploadSession, error) {
	var session CanonicalUploadSession
	err := s.getJSON(ctx, s.canonicalUploadKey(sessionID), &session)
	return session, err
}

func (s *RedisStore) SetCanonicalUpload(ctx context.Context, session CanonicalUploadSession, ttl time.Duration) error {
	if err := s.setJSON(ctx, s.canonicalUploadKey(session.SessionID), session, ttl); err != nil {
		return err
	}
	return s.setJSON(ctx, s.canonicalUploadTombstoneKey(session.SessionID), session, canonicalUploadTombstoneTTL(ttl))
}

func (s *RedisStore) DeleteCanonicalUpload(ctx context.Context, sessionID string) error {
	return s.client.Del(ctx, s.canonicalUploadKey(sessionID), s.canonicalChunksKey(sessionID), s.canonicalUploadTombstoneKey(sessionID)).Err()
}

func (s *RedisStore) GetCanonicalUploadTombstone(ctx context.Context, sessionID string) (CanonicalUploadSession, error) {
	var session CanonicalUploadSession
	err := s.getJSON(ctx, s.canonicalUploadTombstoneKey(sessionID), &session)
	return session, err
}

func (s *RedisStore) TouchCanonicalUpload(ctx context.Context, sessionID string, ttl time.Duration) error {
	ttlMillis := max(int64(1), ttl.Milliseconds())
	tombstoneTTLMillis := max(int64(1), canonicalUploadTombstoneTTL(ttl).Milliseconds())
	result, err := s.client.Eval(ctx, `
if redis.call('EXISTS', KEYS[1]) == 0 then
  return 0
end
redis.call('PEXPIRE', KEYS[1], ARGV[1])
redis.call('PEXPIRE', KEYS[2], ARGV[1])
redis.call('PEXPIRE', KEYS[3], ARGV[2])
return 1`, []string{s.canonicalUploadKey(sessionID), s.canonicalChunksKey(sessionID), s.canonicalUploadTombstoneKey(sessionID)}, ttlMillis, tombstoneTTLMillis).Int()
	if err != nil {
		return err
	}
	if result == 0 {
		return ErrNotFound
	}
	return nil
}

func (s *RedisStore) GetCanonicalChunk(ctx context.Context, sessionID string, index int) (CanonicalChunk, error) {
	raw, err := s.client.HGet(ctx, s.canonicalChunksKey(sessionID), strconv.Itoa(index)).Bytes()
	if errors.Is(err, redis.Nil) {
		return CanonicalChunk{State: "partial"}, ErrNotFound
	}
	if err != nil {
		return CanonicalChunk{}, err
	}
	var chunk CanonicalChunk
	if err := json.Unmarshal(raw, &chunk); err != nil {
		return CanonicalChunk{}, err
	}
	return chunk, nil
}

func (s *RedisStore) SetCanonicalChunk(ctx context.Context, sessionID string, index int, chunk CanonicalChunk, ttl time.Duration) error {
	payload, err := json.Marshal(chunk)
	if err != nil {
		return err
	}
	ttlMillis := max(int64(1), ttl.Milliseconds())
	result, err := s.client.Eval(ctx, `
if redis.call('EXISTS', KEYS[1]) == 0 then
  return 0
end
redis.call('HSET', KEYS[2], ARGV[1], ARGV[2])
redis.call('PEXPIRE', KEYS[2], ARGV[3])
redis.call('PEXPIRE', KEYS[1], ARGV[3])
return 1`, []string{s.canonicalUploadKey(sessionID), s.canonicalChunksKey(sessionID)}, strconv.Itoa(index), payload, ttlMillis).Int()
	if err != nil {
		return err
	}
	if result == 0 {
		return ErrNotFound
	}
	return nil
}

func (s *RedisStore) ListCanonicalChunks(ctx context.Context, sessionID string) (map[string]CanonicalChunk, error) {
	raw, err := s.client.HGetAll(ctx, s.canonicalChunksKey(sessionID)).Result()
	if err != nil {
		return nil, err
	}
	result := make(map[string]CanonicalChunk, len(raw))
	for index, encoded := range raw {
		var chunk CanonicalChunk
		if json.Unmarshal([]byte(encoded), &chunk) == nil {
			result[index] = chunk
		}
	}
	return result, nil
}

func (s *RedisStore) canonicalUploadKey(sessionID string) string {
	return fmt.Sprintf("%s:upload:v1:session:%s", s.keyPrefix, sessionID)
}

func (s *RedisStore) canonicalChunksKey(sessionID string) string {
	return fmt.Sprintf("%s:upload:v1:chunks:%s", s.keyPrefix, sessionID)
}

func (s *RedisStore) canonicalUploadTombstoneKey(sessionID string) string {
	return fmt.Sprintf("%s:upload:v1:tombstone:%s", s.keyPrefix, sessionID)
}

func canonicalUploadTombstoneTTL(sessionTTL time.Duration) time.Duration {
	return sessionTTL + 24*time.Hour
}
