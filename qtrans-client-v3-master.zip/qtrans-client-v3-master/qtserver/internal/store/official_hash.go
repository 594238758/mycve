package store

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"strconv"
	"time"

	"github.com/redis/go-redis/v9"
)

const officialHashTreeBatch = int64(128)

type OfficialHashIdentity struct {
	PrincipalID      string
	ObjectKey        string
	Algorithm        string
	AlgorithmVersion int
}

type OfficialHashFingerprint struct {
	CTimeNS  int64
	MTimeNS  int64
	FileSize int64
}

type OfficialHashLookup struct {
	Status       string
	Hash         string
	Generation   int64
	CalculatedAt time.Time
}

type OfficialHashJob struct {
	Identity            OfficialHashIdentity
	Fingerprint         OfficialHashFingerprint
	Generation          int64
	NamespaceGeneration int64
	RedisIncarnation    string
	CalculationID       string
}

const officialHashIncarnationPrelude = `
local info = redis.call('INFO', 'server')
local incarnation = string.match(info, '\nrun_id:([^\r\n]+)') or string.match(info, '^run_id:([^\r\n]+)')
if not incarnation or incarnation == '' then
  return redis.error_reply('QT_HASH_CORRUPT missing redis run_id')
end
`

var officialHashLookupScript = redis.NewScript(officialHashIncarnationPrelude + `
local t = redis.call('TIME')
local now = tonumber(t[1]) * 1000 + math.floor(tonumber(t[2]) / 1000)
local retention = tonumber(ARGV[10])
local revalidate = tonumber(ARGV[9])
local namespace = redis.call('GET', KEYS[5]) or '0'
local function corrupt(message)
  return redis.error_reply('QT_HASH_CORRUPT ' .. message)
end
local exists = redis.call('EXISTS', KEYS[1]) == 1
local generation = 1
if exists then
  local stored_principal = redis.call('HGET', KEYS[1], 'principal_id')
  local stored_object = redis.call('HGET', KEYS[1], 'object_key')
  local stored_algorithm = redis.call('HGET', KEYS[1], 'algorithm')
  local stored_version = redis.call('HGET', KEYS[1], 'algorithm_version')
  if stored_principal ~= ARGV[1] or stored_object ~= ARGV[2] or
     stored_algorithm ~= ARGV[3] or stored_version ~= ARGV[4] then
    return corrupt('identity mismatch')
  end
  generation = tonumber(redis.call('HGET', KEYS[1], 'generation'))
  if not generation then
    return corrupt('missing generation')
  end
else
  redis.call('HSET', KEYS[1],
    'principal_id', ARGV[1], 'object_key', ARGV[2], 'algorithm', ARGV[3],
    'algorithm_version', ARGV[4], 'principal_digest', ARGV[11],
    'generation', generation, 'state', 'pending',
    'ctime_ns', ARGV[5], 'mtime_ns', ARGV[6], 'file_size', ARGV[7],
    'namespace_generation', namespace, 'redis_incarnation', incarnation,
    'path_index_key', KEYS[4], 'path_member', ARGV[8])
  redis.call('ZADD', KEYS[2], now, ARGV[12])
end

local current_ctime = redis.call('HGET', KEYS[1], 'ctime_ns')
local current_mtime = redis.call('HGET', KEYS[1], 'mtime_ns')
local current_size = redis.call('HGET', KEYS[1], 'file_size')
if not current_ctime or not current_mtime or not current_size then
  return corrupt('missing fingerprint')
end
local stored_namespace = redis.call('HGET', KEYS[1], 'namespace_generation')
local stored_incarnation = redis.call('HGET', KEYS[1], 'redis_incarnation')
local needs_rebuild = not stored_namespace or not stored_incarnation or
  stored_namespace ~= namespace or stored_incarnation ~= incarnation or
  current_ctime ~= ARGV[5] or current_mtime ~= ARGV[6] or current_size ~= ARGV[7]
if needs_rebuild then
  generation = generation + 1
  redis.call('HSET', KEYS[1], 'generation', generation, 'state', 'pending',
    'ctime_ns', ARGV[5], 'mtime_ns', ARGV[6], 'file_size', ARGV[7],
    'namespace_generation', namespace, 'redis_incarnation', incarnation)
  redis.call('HDEL', KEYS[1], 'file_hash', 'calculated_at_ms', 'calculation_id',
    'started_at_ms', 'heartbeat_at_ms', 'lease_until_ms', 'error',
    'retry_count', 'next_retry_at_ms', 'claim_namespace_generation', 'claim_redis_incarnation')
  redis.call('ZADD', KEYS[2], now, ARGV[12])
end

local state = redis.call('HGET', KEYS[1], 'state')
if state ~= 'idle' and state ~= 'pending' and state ~= 'calculating' and state ~= 'failed' then
  return corrupt('invalid state')
end
local hash = redis.call('HGET', KEYS[1], 'file_hash') or ''
local calculated = tonumber(redis.call('HGET', KEYS[1], 'calculated_at_ms') or '0')
local status = 'pending'
if state == 'idle' then
  if hash == '' then
    redis.call('HSET', KEYS[1], 'state', 'pending')
    redis.call('ZADD', KEYS[2], now, ARGV[12])
  elseif calculated <= 0 then
    return corrupt('idle hash missing calculated_at')
  elseif now - calculated > revalidate then
    status = 'stale'
    redis.call('HSET', KEYS[1], 'state', 'pending')
    redis.call('ZADD', KEYS[2], now, ARGV[12])
  else
    status = 'fresh'
  end
elseif state == 'pending' or state == 'calculating' then
  if hash ~= '' then status = 'stale' end
elseif state == 'failed' then
  local next_retry = tonumber(redis.call('HGET', KEYS[1], 'next_retry_at_ms') or '0')
  if next_retry <= 0 then return corrupt('failed hash missing next_retry_at') end
  if now >= next_retry then
    redis.call('HSET', KEYS[1], 'state', 'pending')
    redis.call('HDEL', KEYS[1], 'calculation_id', 'started_at_ms',
      'heartbeat_at_ms', 'lease_until_ms', 'claim_namespace_generation',
      'claim_redis_incarnation')
    redis.call('ZADD', KEYS[2], now, ARGV[12])
    if hash ~= '' then status = 'stale' end
  elseif hash ~= '' then
    status = 'stale'
  else
    status = 'unavailable'
  end
end

local expires = now + retention
redis.call('HSET', KEYS[1], 'expires_at_ms', expires,
  'path_index_key', KEYS[4], 'path_member', ARGV[8],
  'principal_digest', ARGV[11], 'namespace_generation', namespace,
  'redis_incarnation', incarnation)
redis.call('ZADD', KEYS[3], expires, ARGV[12])
redis.call('ZADD', KEYS[4], 0, ARGV[8])
return {status, hash, tostring(generation), tostring(calculated)}
`)

var officialHashClaimScript = redis.NewScript(officialHashIncarnationPrelude + `
local t = redis.call('TIME')
local now = tonumber(t[1]) * 1000 + math.floor(tonumber(t[2]) / 1000)
local lease = tonumber(ARGV[3])
local retention = tonumber(ARGV[4])
local candidates = redis.call('ZRANGEBYSCORE', KEYS[1], '-inf', now, 'LIMIT', 0, 32)
local function discard(record, digest)
  local path_key = redis.call('HGET', record, 'path_index_key')
  local path_member = redis.call('HGET', record, 'path_member')
  redis.call('DEL', record)
  redis.call('ZREM', KEYS[1], digest)
  redis.call('ZREM', KEYS[2], digest)
  if path_key and path_member then redis.call('ZREM', path_key, path_member) end
end
for _, digest in ipairs(candidates) do
  local record = ARGV[1] .. digest
  if redis.call('EXISTS', record) == 0 then
    redis.call('ZREM', KEYS[1], digest)
    redis.call('ZREM', KEYS[2], digest)
  else
    local state = redis.call('HGET', record, 'state')
    if state == 'pending' or state == 'calculating' then
      local principal = redis.call('HGET', record, 'principal_id')
      local object_key = redis.call('HGET', record, 'object_key')
      local algorithm = redis.call('HGET', record, 'algorithm')
      local version = redis.call('HGET', record, 'algorithm_version')
      local principal_digest = redis.call('HGET', record, 'principal_digest')
      local generation = redis.call('HGET', record, 'generation')
      local ctime = redis.call('HGET', record, 'ctime_ns')
      local mtime = redis.call('HGET', record, 'mtime_ns')
      local size = redis.call('HGET', record, 'file_size')
      local record_namespace = redis.call('HGET', record, 'namespace_generation')
      local record_incarnation = redis.call('HGET', record, 'redis_incarnation')
      if not principal or not object_key or not algorithm or not version or
         not principal_digest or not generation or not ctime or not mtime or not size then
        return redis.error_reply('QT_HASH_CORRUPT incomplete claim record')
      elseif not record_namespace or not record_incarnation or record_incarnation ~= incarnation then
        discard(record, digest)
      else
        local namespace = redis.call('GET', ARGV[2] .. principal_digest) or '0'
        if record_namespace ~= namespace then
          discard(record, digest)
        else
          local lease_until = now + lease
          local expires = now + retention
          redis.call('HSET', record, 'state', 'calculating',
            'calculation_id', ARGV[5], 'claim_namespace_generation', namespace,
            'claim_redis_incarnation', incarnation,
            'started_at_ms', now, 'heartbeat_at_ms', now,
            'lease_until_ms', lease_until, 'expires_at_ms', expires)
          redis.call('ZADD', KEYS[1], lease_until, digest)
          redis.call('ZADD', KEYS[2], expires, digest)
          return {principal, object_key, algorithm, version, generation,
            ctime, mtime, size, namespace, incarnation, digest}
        end
      end
    elseif state == 'idle' or state == 'failed' then
      redis.call('ZREM', KEYS[1], digest)
    else
      return redis.error_reply('QT_HASH_CORRUPT invalid claim state')
    end
  end
end
return nil
`)

var officialHashHeartbeatScript = redis.NewScript(officialHashIncarnationPrelude + `
if redis.call('EXISTS', KEYS[1]) == 0 then return 0 end
local namespace = redis.call('GET', KEYS[4]) or '0'
if redis.call('HGET', KEYS[1], 'state') ~= 'calculating' or
   redis.call('HGET', KEYS[1], 'generation') ~= ARGV[2] or
   redis.call('HGET', KEYS[1], 'calculation_id') ~= ARGV[3] or
   redis.call('HGET', KEYS[1], 'claim_namespace_generation') ~= ARGV[4] or
   redis.call('HGET', KEYS[1], 'claim_redis_incarnation') ~= ARGV[5] or
   redis.call('HGET', KEYS[1], 'redis_incarnation') ~= ARGV[5] or
   ARGV[5] ~= incarnation or
   namespace ~= ARGV[4] then return 0 end
local t = redis.call('TIME')
local now = tonumber(t[1]) * 1000 + math.floor(tonumber(t[2]) / 1000)
local lease_until = now + tonumber(ARGV[6])
local expires = now + tonumber(ARGV[7])
redis.call('HSET', KEYS[1], 'heartbeat_at_ms', now,
  'lease_until_ms', lease_until, 'expires_at_ms', expires)
redis.call('ZADD', KEYS[2], lease_until, ARGV[1])
redis.call('ZADD', KEYS[3], expires, ARGV[1])
return 1
`)

var officialHashSubmitScript = redis.NewScript(officialHashIncarnationPrelude + `
if redis.call('EXISTS', KEYS[1]) == 0 then return 0 end
local namespace = redis.call('GET', KEYS[4]) or '0'
if redis.call('HGET', KEYS[1], 'state') ~= 'calculating' or
   redis.call('HGET', KEYS[1], 'generation') ~= ARGV[2] or
   redis.call('HGET', KEYS[1], 'calculation_id') ~= ARGV[3] or
   redis.call('HGET', KEYS[1], 'claim_namespace_generation') ~= ARGV[4] or
   redis.call('HGET', KEYS[1], 'claim_redis_incarnation') ~= ARGV[5] or
   redis.call('HGET', KEYS[1], 'redis_incarnation') ~= ARGV[5] or
   ARGV[5] ~= incarnation or
   namespace ~= ARGV[4] then return 0 end
local t = redis.call('TIME')
local now = tonumber(t[1]) * 1000 + math.floor(tonumber(t[2]) / 1000)
local expires = now + tonumber(ARGV[10])
redis.call('HSET', KEYS[1], 'state', 'idle', 'file_hash', ARGV[6],
	  'ctime_ns', ARGV[7], 'mtime_ns', ARGV[8], 'file_size', ARGV[9],
  'calculated_at_ms', now, 'expires_at_ms', expires, 'retry_count', 0)
redis.call('HDEL', KEYS[1], 'calculation_id', 'claim_namespace_generation', 'claim_redis_incarnation',
  'started_at_ms', 'heartbeat_at_ms', 'lease_until_ms', 'error', 'next_retry_at_ms')
redis.call('ZREM', KEYS[2], ARGV[1])
redis.call('ZADD', KEYS[3], expires, ARGV[1])
return 1
`)

var officialHashFailScript = redis.NewScript(officialHashIncarnationPrelude + `
if redis.call('EXISTS', KEYS[1]) == 0 then return 0 end
local namespace = redis.call('GET', KEYS[4]) or '0'
if redis.call('HGET', KEYS[1], 'state') ~= 'calculating' or
   redis.call('HGET', KEYS[1], 'generation') ~= ARGV[2] or
   redis.call('HGET', KEYS[1], 'calculation_id') ~= ARGV[3] or
   redis.call('HGET', KEYS[1], 'claim_namespace_generation') ~= ARGV[4] or
   redis.call('HGET', KEYS[1], 'claim_redis_incarnation') ~= ARGV[5] or
   redis.call('HGET', KEYS[1], 'redis_incarnation') ~= ARGV[5] or
   ARGV[5] ~= incarnation or
   namespace ~= ARGV[4] then return 0 end
local t = redis.call('TIME')
local now = tonumber(t[1]) * 1000 + math.floor(tonumber(t[2]) / 1000)
local retry = tonumber(redis.call('HGET', KEYS[1], 'retry_count') or '0') + 1
local power = math.min(retry - 1, 6)
local delay = math.min(300000, 5000 * math.pow(2, power))
local next_retry = now + delay
local expires = now + tonumber(ARGV[7])
redis.call('HSET', KEYS[1], 'state', 'failed', 'error', ARGV[6],
  'retry_count', retry, 'next_retry_at_ms', next_retry, 'expires_at_ms', expires)
redis.call('HDEL', KEYS[1], 'calculation_id', 'claim_namespace_generation', 'claim_redis_incarnation',
  'started_at_ms', 'heartbeat_at_ms', 'lease_until_ms')
redis.call('ZREM', KEYS[2], ARGV[1])
redis.call('ZADD', KEYS[3], expires, ARGV[1])
return 1
`)

var officialHashBeginMutationScript = redis.NewScript(officialHashIncarnationPrelude + `
local t = redis.call('TIME')
local now = tonumber(t[1]) * 1000 + math.floor(tonumber(t[2]) / 1000)
local namespace = redis.call('GET', KEYS[5]) or '0'
local generation = 1
if redis.call('EXISTS', KEYS[1]) == 1 then
  if redis.call('HGET', KEYS[1], 'principal_id') ~= ARGV[1] or
     redis.call('HGET', KEYS[1], 'object_key') ~= ARGV[2] or
     redis.call('HGET', KEYS[1], 'algorithm') ~= ARGV[3] or
     redis.call('HGET', KEYS[1], 'algorithm_version') ~= ARGV[4] then
    return redis.error_reply('QT_HASH_CORRUPT mutation identity mismatch')
  end
  local current = tonumber(redis.call('HGET', KEYS[1], 'generation'))
  if not current then return redis.error_reply('QT_HASH_CORRUPT missing generation') end
  generation = current + 1
end
local expires = now + tonumber(ARGV[9])
redis.call('HSET', KEYS[1],
  'principal_id', ARGV[1], 'object_key', ARGV[2], 'algorithm', ARGV[3],
  'algorithm_version', ARGV[4], 'principal_digest', ARGV[10],
  'generation', generation, 'state', 'pending',
  'ctime_ns', ARGV[5], 'mtime_ns', ARGV[6], 'file_size', ARGV[7],
  'namespace_generation', namespace, 'redis_incarnation', incarnation,
  'expires_at_ms', expires, 'path_index_key', KEYS[4], 'path_member', ARGV[8])
redis.call('HDEL', KEYS[1], 'file_hash', 'calculated_at_ms', 'calculation_id',
  'claim_namespace_generation', 'claim_redis_incarnation', 'started_at_ms', 'heartbeat_at_ms',
  'lease_until_ms', 'error', 'retry_count', 'next_retry_at_ms')
redis.call('ZADD', KEYS[2], now, ARGV[11])
redis.call('ZADD', KEYS[3], expires, ARGV[11])
redis.call('ZADD', KEYS[4], 0, ARGV[8])
return generation
`)

var officialHashCommitKnownScript = redis.NewScript(officialHashIncarnationPrelude + `
if redis.call('EXISTS', KEYS[1]) == 0 then return 0 end
if redis.call('HGET', KEYS[1], 'principal_id') ~= ARGV[2] or
   redis.call('HGET', KEYS[1], 'object_key') ~= ARGV[3] or
   redis.call('HGET', KEYS[1], 'algorithm') ~= ARGV[4] or
   redis.call('HGET', KEYS[1], 'algorithm_version') ~= ARGV[5] then
  return redis.error_reply('QT_HASH_CORRUPT commit identity mismatch')
end
if redis.call('HGET', KEYS[1], 'generation') ~= ARGV[6] then return 0 end
local namespace = redis.call('GET', KEYS[4]) or '0'
if redis.call('HGET', KEYS[1], 'namespace_generation') ~= namespace or
   redis.call('HGET', KEYS[1], 'redis_incarnation') ~= incarnation then return 0 end
local t = redis.call('TIME')
local now = tonumber(t[1]) * 1000 + math.floor(tonumber(t[2]) / 1000)
local expires = now + tonumber(ARGV[11])
redis.call('HSET', KEYS[1], 'state', 'idle', 'file_hash', ARGV[7],
  'ctime_ns', ARGV[8], 'mtime_ns', ARGV[9], 'file_size', ARGV[10],
  'calculated_at_ms', now, 'expires_at_ms', expires, 'retry_count', 0)
redis.call('HDEL', KEYS[1], 'calculation_id', 'claim_namespace_generation',
	  'claim_redis_incarnation',
  'started_at_ms', 'heartbeat_at_ms', 'lease_until_ms', 'error', 'next_retry_at_ms')
redis.call('ZREM', KEYS[2], ARGV[1])
redis.call('ZADD', KEYS[3], expires, ARGV[1])
return 1
`)

var officialHashInvalidateScript = redis.NewScript(`
redis.call('DEL', KEYS[1])
redis.call('ZREM', KEYS[2], ARGV[1])
redis.call('ZREM', KEYS[3], ARGV[1])
redis.call('ZREM', KEYS[4], ARGV[2])
return 1
`)

var officialHashCollectExpiredScript = redis.NewScript(`
local t = redis.call('TIME')
local now = tonumber(t[1]) * 1000 + math.floor(tonumber(t[2]) / 1000)
local candidates = redis.call('ZRANGEBYSCORE', KEYS[2], '-inf', now, 'LIMIT', 0, tonumber(ARGV[2]))
local removed = 0
for _, digest in ipairs(candidates) do
  local record = ARGV[1] .. digest
  if redis.call('EXISTS', record) == 0 then
    redis.call('ZREM', KEYS[1], digest)
    redis.call('ZREM', KEYS[2], digest)
  else
    local expires = tonumber(redis.call('HGET', record, 'expires_at_ms') or '0')
    if expires <= now then
      local path_key = redis.call('HGET', record, 'path_index_key')
      local path_member = redis.call('HGET', record, 'path_member')
      redis.call('DEL', record)
      redis.call('ZREM', KEYS[1], digest)
      redis.call('ZREM', KEYS[2], digest)
      if path_key and path_member then redis.call('ZREM', path_key, path_member) end
      removed = removed + 1
    else
      redis.call('ZADD', KEYS[2], expires, digest)
    end
  end
end
return removed
`)

func (s *RedisStore) LookupOfficialHash(ctx context.Context, identity OfficialHashIdentity, fingerprint OfficialHashFingerprint, revalidate, retention time.Duration) (OfficialHashLookup, error) {
	keys, values := s.officialHashKeys(identity)
	result, err := officialHashLookupScript.Run(ctx, s.client,
		[]string{keys.record, s.officialHashDueKey(), s.officialHashExpiryKey(), keys.pathIndex, keys.namespace},
		identity.PrincipalID, identity.ObjectKey, identity.Algorithm, identity.AlgorithmVersion,
		fingerprint.CTimeNS, fingerprint.MTimeNS, fingerprint.FileSize, keys.pathMember,
		max(int64(1), revalidate.Milliseconds()), max(int64(1), retention.Milliseconds()),
		values.principalDigest, values.digest,
	).Slice()
	if err != nil {
		return OfficialHashLookup{}, s.officialHashError("lookup", err)
	}
	if len(result) != 4 {
		return OfficialHashLookup{}, s.officialHashCorrupt("lookup returned %d fields", len(result))
	}
	status, err := luaString(result[0])
	if err != nil || (status != "fresh" && status != "stale" && status != "pending" && status != "unavailable") {
		return OfficialHashLookup{}, s.officialHashCorrupt("lookup returned invalid status")
	}
	hash, err := luaString(result[1])
	if err != nil {
		return OfficialHashLookup{}, s.officialHashCorrupt("lookup returned invalid hash")
	}
	generation, err := luaInt64(result[2])
	if err != nil || generation <= 0 {
		return OfficialHashLookup{}, s.officialHashCorrupt("lookup returned invalid generation")
	}
	calculatedMS, err := luaInt64(result[3])
	if err != nil || calculatedMS < 0 {
		return OfficialHashLookup{}, s.officialHashCorrupt("lookup returned invalid calculated time")
	}
	lookup := OfficialHashLookup{Status: status, Hash: hash, Generation: generation}
	if calculatedMS > 0 {
		lookup.CalculatedAt = time.UnixMilli(calculatedMS).UTC()
	}
	return lookup, nil
}

func (s *RedisStore) ClaimOfficialHash(ctx context.Context, calculationID string, lease, retention time.Duration) (*OfficialHashJob, error) {
	result, err := officialHashClaimScript.Run(ctx, s.client,
		[]string{s.officialHashDueKey(), s.officialHashExpiryKey()},
		s.officialHashRecordPrefix(), s.officialHashNamespacePrefix(),
		max(int64(1), lease.Milliseconds()), max(int64(1), retention.Milliseconds()), calculationID,
	).Result()
	if errors.Is(err, redis.Nil) || result == nil {
		return nil, nil
	}
	if err != nil {
		return nil, s.officialHashError("claim", err)
	}
	items, ok := result.([]interface{})
	if !ok || len(items) != 11 {
		return nil, s.officialHashCorrupt("claim returned invalid result")
	}
	stringsOut := make([]string, len(items))
	for i := range items {
		stringsOut[i], err = luaString(items[i])
		if err != nil {
			return nil, s.officialHashCorrupt("claim field %d is invalid", i)
		}
	}
	version, err := strconv.Atoi(stringsOut[3])
	if err != nil || version <= 0 {
		return nil, s.officialHashCorrupt("claim algorithm version is invalid")
	}
	generation, err := strconv.ParseInt(stringsOut[4], 10, 64)
	if err != nil || generation <= 0 {
		return nil, s.officialHashCorrupt("claim generation is invalid")
	}
	ctime, err := strconv.ParseInt(stringsOut[5], 10, 64)
	if err != nil {
		return nil, s.officialHashCorrupt("claim ctime is invalid")
	}
	mtime, err := strconv.ParseInt(stringsOut[6], 10, 64)
	if err != nil {
		return nil, s.officialHashCorrupt("claim mtime is invalid")
	}
	size, err := strconv.ParseInt(stringsOut[7], 10, 64)
	if err != nil || size < 0 {
		return nil, s.officialHashCorrupt("claim size is invalid")
	}
	namespace, err := strconv.ParseInt(stringsOut[8], 10, 64)
	if err != nil || namespace < 0 {
		return nil, s.officialHashCorrupt("claim namespace generation is invalid")
	}
	job := &OfficialHashJob{
		Identity: OfficialHashIdentity{
			PrincipalID: stringsOut[0], ObjectKey: stringsOut[1], Algorithm: stringsOut[2], AlgorithmVersion: version,
		},
		Fingerprint: OfficialHashFingerprint{CTimeNS: ctime, MTimeNS: mtime, FileSize: size},
		Generation:  generation, NamespaceGeneration: namespace, RedisIncarnation: stringsOut[9], CalculationID: calculationID,
	}
	if job.RedisIncarnation == "" {
		return nil, s.officialHashCorrupt("claim incarnation is empty")
	}
	if s.officialHashIdentityValues(job.Identity).digest != stringsOut[10] {
		return nil, s.officialHashCorrupt("claim identity digest mismatch")
	}
	return job, nil
}

func (s *RedisStore) HeartbeatOfficialHash(ctx context.Context, job OfficialHashJob, lease, retention time.Duration) (bool, error) {
	keys, values := s.officialHashKeys(job.Identity)
	result, err := officialHashHeartbeatScript.Run(ctx, s.client,
		[]string{keys.record, s.officialHashDueKey(), s.officialHashExpiryKey(), keys.namespace},
		values.digest, job.Generation, job.CalculationID, job.NamespaceGeneration, job.RedisIncarnation,
		max(int64(1), lease.Milliseconds()), max(int64(1), retention.Milliseconds()),
	).Int()
	if err != nil {
		return false, s.officialHashError("heartbeat", err)
	}
	return result == 1, nil
}

func (s *RedisStore) SubmitOfficialHash(ctx context.Context, job OfficialHashJob, hash string, retention time.Duration) (bool, error) {
	keys, values := s.officialHashKeys(job.Identity)
	result, err := officialHashSubmitScript.Run(ctx, s.client,
		[]string{keys.record, s.officialHashDueKey(), s.officialHashExpiryKey(), keys.namespace},
		values.digest, job.Generation, job.CalculationID, job.NamespaceGeneration, job.RedisIncarnation, hash,
		job.Fingerprint.CTimeNS, job.Fingerprint.MTimeNS, job.Fingerprint.FileSize,
		max(int64(1), retention.Milliseconds()),
	).Int()
	if err != nil {
		return false, s.officialHashError("submit", err)
	}
	return result == 1, nil
}

func (s *RedisStore) FailOfficialHash(ctx context.Context, job OfficialHashJob, message string, retention time.Duration) (bool, error) {
	if len(message) > 1024 {
		message = message[:1024]
	}
	keys, values := s.officialHashKeys(job.Identity)
	result, err := officialHashFailScript.Run(ctx, s.client,
		[]string{keys.record, s.officialHashDueKey(), s.officialHashExpiryKey(), keys.namespace},
		values.digest, job.Generation, job.CalculationID, job.NamespaceGeneration, job.RedisIncarnation, message,
		max(int64(1), retention.Milliseconds()),
	).Int()
	if err != nil {
		return false, s.officialHashError("fail", err)
	}
	return result == 1, nil
}

func (s *RedisStore) BeginOfficialHashMutation(ctx context.Context, identity OfficialHashIdentity, fingerprint OfficialHashFingerprint, retention time.Duration) (int64, error) {
	keys, values := s.officialHashKeys(identity)
	result, err := officialHashBeginMutationScript.Run(ctx, s.client,
		[]string{keys.record, s.officialHashDueKey(), s.officialHashExpiryKey(), keys.pathIndex, keys.namespace},
		identity.PrincipalID, identity.ObjectKey, identity.Algorithm, identity.AlgorithmVersion,
		fingerprint.CTimeNS, fingerprint.MTimeNS, fingerprint.FileSize, keys.pathMember,
		max(int64(1), retention.Milliseconds()), values.principalDigest, values.digest,
	).Int64()
	if err != nil {
		return 0, s.officialHashError("begin mutation", err)
	}
	return result, nil
}

func (s *RedisStore) CommitKnownOfficialHash(ctx context.Context, identity OfficialHashIdentity, generation int64, fingerprint OfficialHashFingerprint, hash string, retention time.Duration) (bool, error) {
	keys, values := s.officialHashKeys(identity)
	result, err := officialHashCommitKnownScript.Run(ctx, s.client,
		[]string{keys.record, s.officialHashDueKey(), s.officialHashExpiryKey(), keys.namespace},
		values.digest, identity.PrincipalID, identity.ObjectKey, identity.Algorithm,
		identity.AlgorithmVersion, generation, hash, fingerprint.CTimeNS,
		fingerprint.MTimeNS, fingerprint.FileSize, max(int64(1), retention.Milliseconds()),
	).Int()
	if err != nil {
		return false, s.officialHashError("commit known", err)
	}
	return result == 1, nil
}

func (s *RedisStore) InvalidateOfficialHash(ctx context.Context, identity OfficialHashIdentity) error {
	keys, values := s.officialHashKeys(identity)
	if _, err := officialHashInvalidateScript.Run(ctx, s.client,
		[]string{keys.record, s.officialHashDueKey(), s.officialHashExpiryKey(), keys.pathIndex},
		values.digest, keys.pathMember,
	).Result(); err != nil {
		return s.officialHashError("invalidate", err)
	}
	return nil
}

func (s *RedisStore) BumpOfficialHashNamespaceGeneration(ctx context.Context, principalID string) (int64, error) {
	value, err := s.client.Incr(ctx, s.officialHashNamespaceKey(principalID)).Result()
	if err != nil {
		return 0, fmt.Errorf("bump official hash namespace generation: %w", err)
	}
	if value <= 0 {
		return 0, s.officialHashCorrupt("namespace generation is invalid")
	}
	return value, nil
}

func (s *RedisStore) CollectExpiredOfficialHashes(ctx context.Context, limit int64) (int64, error) {
	if limit <= 0 {
		limit = officialHashTreeBatch
	}
	value, err := officialHashCollectExpiredScript.Run(ctx, s.client,
		[]string{s.officialHashDueKey(), s.officialHashExpiryKey()},
		s.officialHashRecordPrefix(), limit,
	).Int64()
	if err != nil {
		return 0, s.officialHashError("collect expired", err)
	}
	return value, nil
}

type officialHashKeySet struct {
	record     string
	pathIndex  string
	pathMember string
	namespace  string
}

type officialHashIdentityValue struct {
	digest          string
	principalDigest string
}

func (s *RedisStore) officialHashKeys(identity OfficialHashIdentity) (officialHashKeySet, officialHashIdentityValue) {
	values := s.officialHashIdentityValues(identity)
	return officialHashKeySet{
		record:     s.officialHashRecordPrefix() + values.digest,
		pathIndex:  fmt.Sprintf("%s:v2:hash:path:%s:%s:%d", s.keyPrefix, values.principalDigest, identity.Algorithm, identity.AlgorithmVersion),
		pathMember: identity.ObjectKey + "\x00" + values.digest,
		namespace:  s.officialHashNamespacePrefix() + values.principalDigest,
	}, values
}

func (s *RedisStore) officialHashIdentityValues(identity OfficialHashIdentity) officialHashIdentityValue {
	principalSum := sha256.Sum256([]byte(identity.PrincipalID))
	identityRaw := identity.PrincipalID + "\x00" + identity.ObjectKey + "\x00" + identity.Algorithm + "\x00" + strconv.Itoa(identity.AlgorithmVersion)
	identitySum := sha256.Sum256([]byte(identityRaw))
	return officialHashIdentityValue{digest: hex.EncodeToString(identitySum[:]), principalDigest: hex.EncodeToString(principalSum[:])}
}

func (s *RedisStore) officialHashRecordPrefix() string {
	return s.keyPrefix + ":v2:hash:record:"
}

func (s *RedisStore) officialHashDueKey() string {
	return s.keyPrefix + ":v2:hash:due"
}

func (s *RedisStore) officialHashExpiryKey() string {
	return s.keyPrefix + ":v2:hash:expiry"
}

func (s *RedisStore) officialHashNamespacePrefix() string {
	return s.keyPrefix + ":v2:hash:namespace-generation:"
}

func (s *RedisStore) officialHashNamespaceKey(principalID string) string {
	principalSum := sha256.Sum256([]byte(principalID))
	return s.officialHashNamespacePrefix() + hex.EncodeToString(principalSum[:])
}

func luaString(value interface{}) (string, error) {
	switch typed := value.(type) {
	case string:
		return typed, nil
	case []byte:
		return string(typed), nil
	case int64:
		return strconv.FormatInt(typed, 10), nil
	default:
		return "", fmt.Errorf("unexpected Lua value %T", value)
	}
}

func luaInt64(value interface{}) (int64, error) {
	text, err := luaString(value)
	if err != nil {
		return 0, err
	}
	return strconv.ParseInt(text, 10, 64)
}

func (s *RedisStore) officialHashError(action string, err error) error {
	return fmt.Errorf("%s official hash state: %w", action, err)
}

func (s *RedisStore) officialHashCorrupt(format string, args ...interface{}) error {
	err := fmt.Errorf("redis official hash state is corrupt: "+format, args...)
	if s.report != nil {
		s.report(err)
	}
	return err
}
