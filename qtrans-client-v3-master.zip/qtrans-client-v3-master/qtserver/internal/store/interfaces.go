package store

import (
	"context"
	"os"
	"time"

	"qtserver/internal/models"
)

type LockHandle struct {
	Token string
	Keys  []string
}

type SessionStore interface {
	Close() error
	SetGrant(ctx context.Context, grant *models.TransferGrant, ttl time.Duration) error
	GetGrant(ctx context.Context, direction models.TransferGrantDirection, taskID, objectKey string) (*models.TransferGrant, error)
	RefreshLock(ctx context.Context, lock *LockHandle, ttl time.Duration) error
	SetFileHash(ctx context.Context, objectID string, size int64, modTime time.Time, hash string, ttl time.Duration) error
	GetFileHash(ctx context.Context, objectID string, size int64, modTime time.Time) (string, error)
	TryAcquireCleanupLock(ctx context.Context, ttl time.Duration) (*LockHandle, error)
	ReleaseLock(ctx context.Context, lock *LockHandle) error
}

type ContentStore interface {
	DownloadHome(principalID string) (string, error)
	UploadHome(principalID string) (string, error)
	DownloadPath(principalID, objectKey string) (string, error)
	UploadPath(principalID, objectKey string) (string, error)
	Stat(path string) (os.FileInfo, error)
	Lstat(path string) (os.FileInfo, error)
	ReadDir(path string) ([]os.DirEntry, error)
	MkdirAll(path string, perm os.FileMode) error
	Remove(path string) error
	RemoveAll(path string) error
	Rename(oldPath, newPath string) error
	Open(path string) (*os.File, error)
	OpenFile(path string, flag int, perm os.FileMode) (*os.File, error)
	WriteFile(path string, data []byte, perm os.FileMode) error
	Truncate(path string, size int64) error
}
