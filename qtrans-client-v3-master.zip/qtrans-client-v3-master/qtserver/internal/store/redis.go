package store

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/url"
	"slices"
	"sort"
	"strings"
	"time"

	"qtserver/internal/config"
	"qtserver/internal/models"

	"github.com/redis/go-redis/v9"
)

var ErrNotFound = errors.New("store: not found")
var ErrConflict = errors.New("store: conflict")

type RedisStore struct {
	client    *redis.Client
	keyPrefix string
	report    func(error)
}

type redisFailureHook struct {
	report func(error)
}

func (h redisFailureHook) DialHook(next redis.DialHook) redis.DialHook {
	return func(ctx context.Context, network, addr string) (net.Conn, error) {
		conn, err := next(ctx, network, addr)
		h.maybeReport(ctx, "dial", err)
		return conn, err
	}
}

func (h redisFailureHook) ProcessHook(next redis.ProcessHook) redis.ProcessHook {
	return func(ctx context.Context, cmd redis.Cmder) error {
		err := next(ctx, cmd)
		h.maybeReport(ctx, "command "+safeRedisCommandName(cmd), err)
		return err
	}
}

func (h redisFailureHook) ProcessPipelineHook(next redis.ProcessPipelineHook) redis.ProcessPipelineHook {
	return func(ctx context.Context, cmds []redis.Cmder) error {
		err := next(ctx, cmds)
		h.maybeReport(ctx, fmt.Sprintf("pipeline commands=%d", len(cmds)), err)
		return err
	}
}

func (h redisFailureHook) maybeReport(ctx context.Context, operation string, err error) {
	if err == nil || errors.Is(err, redis.Nil) || errors.Is(err, redis.TxFailedErr) {
		return
	}
	if ctx != nil {
		if contextErr := ctx.Err(); (errors.Is(contextErr, context.Canceled) || errors.Is(contextErr, context.DeadlineExceeded)) && errors.Is(err, contextErr) {
			return
		}
	}
	if strings.HasPrefix(strings.ToUpper(strings.TrimSpace(err.Error())), "NOSCRIPT") {
		return
	}
	if h.report != nil {
		h.report(fmt.Errorf("redis dependency failure (%s): %w", strings.TrimSpace(operation), err))
	}
}

func safeRedisCommandName(cmd redis.Cmder) string {
	if cmd == nil {
		return "unknown"
	}
	name := strings.ToLower(strings.TrimSpace(cmd.FullName()))
	if name == "" {
		return "unknown"
	}
	return name
}

func NewRedisStore(cfg config.RedisConfig) (*RedisStore, error) {
	client := redis.NewClient(&redis.Options{
		Addr:     cfg.Addr,
		Password: cfg.Password,
		DB:       cfg.DB,
	})
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	store := NewRedisStoreFromClient(client, cfg.KeyPrefix)
	if err := store.CheckPersistence(ctx); err != nil {
		_ = client.Close()
		return nil, err
	}
	return store, nil
}

func NewRedisStoreFromClient(client *redis.Client, keyPrefix string) *RedisStore {
	return &RedisStore{client: client, keyPrefix: keyPrefix}
}

func (s *RedisStore) SetFailureReporter(report func(error)) {
	if s == nil || s.client == nil || report == nil {
		return
	}
	s.report = report
	s.client.AddHook(redisFailureHook{report: report})
}

func (s *RedisStore) Close() error {
	if s == nil || s.client == nil {
		return nil
	}
	return s.client.Close()
}

func (s *RedisStore) Ping(ctx context.Context) error {
	if s == nil || s.client == nil {
		return errors.New("redis is not initialized")
	}
	if err := s.client.Ping(ctx).Err(); err != nil {
		return fmt.Errorf("ping redis: %w", err)
	}
	return nil
}

func (s *RedisStore) CheckPersistence(ctx context.Context) error {
	if err := s.Ping(ctx); err != nil {
		return err
	}
	checks := map[string]string{
		"appendonly":       "yes",
		"appendfsync":      "everysec",
		"maxmemory-policy": "noeviction",
	}
	for name, expected := range checks {
		values, err := s.client.ConfigGet(ctx, name).Result()
		if err != nil {
			return fmt.Errorf("read redis config %s: %w", name, err)
		}
		actual, ok := values[name]
		if !ok {
			return fmt.Errorf("redis config %s is missing", name)
		}
		if !strings.EqualFold(strings.TrimSpace(actual), expected) {
			return fmt.Errorf("redis config %s must be %s, got %s", name, expected, actual)
		}
	}
	info, err := s.client.Info(ctx, "persistence").Result()
	if err != nil {
		return fmt.Errorf("read redis persistence info: %w", err)
	}
	fields := parseRedisInfo(info)
	if fields["aof_enabled"] != "1" {
		return fmt.Errorf("redis AOF is not enabled")
	}
	if !strings.EqualFold(fields["aof_last_write_status"], "ok") {
		return fmt.Errorf("redis AOF last write status is not ok: %q", fields["aof_last_write_status"])
	}
	if err := s.checkRedisIncarnation(ctx); err != nil {
		return err
	}
	return nil
}

func (s *RedisStore) checkRedisIncarnation(ctx context.Context) error {
	info, err := s.client.Info(ctx, "server").Result()
	if err != nil {
		return fmt.Errorf("read redis server info: %w", err)
	}
	runID := strings.TrimSpace(parseRedisInfo(info)["run_id"])
	if runID == "" {
		return errors.New("redis server info is missing run_id")
	}
	return nil
}

func parseRedisInfo(raw string) map[string]string {
	result := make(map[string]string)
	for _, line := range strings.Split(raw, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		name, value, ok := strings.Cut(line, ":")
		if ok {
			result[strings.TrimSpace(name)] = strings.TrimSpace(value)
		}
	}
	return result
}

func (s *RedisStore) SetGrant(ctx context.Context, grant *models.TransferGrant, ttl time.Duration) error {
	if ttl <= 0 {
		ttl = time.Second
	}
	return s.setJSON(ctx, s.grantKey(grant.Direction, grant.TaskID, grant.ObjectKey), grant, ttl)
}

func (s *RedisStore) GetGrant(ctx context.Context, direction models.TransferGrantDirection, taskID, objectKey string) (*models.TransferGrant, error) {
	var grant models.TransferGrant
	if err := s.getJSON(ctx, s.grantKey(direction, taskID, objectKey), &grant); err != nil {
		return nil, err
	}
	return &grant, nil
}

func (s *RedisStore) RefreshLock(ctx context.Context, lock *LockHandle, ttl time.Duration) error {
	if lock == nil || lock.Token == "" || len(lock.Keys) == 0 {
		return nil
	}
	if ttl <= 0 {
		ttl = time.Second
	}
	var refreshErr error
	for _, key := range lock.Keys {
		err := s.client.Watch(ctx, func(tx *redis.Tx) error {
			current, err := tx.Get(ctx, key).Result()
			if errors.Is(err, redis.Nil) {
				return nil
			}
			if err != nil {
				return err
			}
			if current != lock.Token {
				return nil
			}
			_, err = tx.TxPipelined(ctx, func(pipe redis.Pipeliner) error {
				pipe.Expire(ctx, key, ttl)
				return nil
			})
			return err
		}, key)
		if err != nil && refreshErr == nil {
			refreshErr = fmt.Errorf("refresh lock %s: %w", key, err)
		}
	}
	return refreshErr
}

func (s *RedisStore) SetFileHash(ctx context.Context, objectID string, size int64, modTime time.Time, hash string, ttl time.Duration) error {
	if err := s.client.Set(ctx, s.fileHashKey(objectID, size, modTime), hash, ttl).Err(); err != nil {
		return fmt.Errorf("set %s: %w", s.fileHashKey(objectID, size, modTime), err)
	}
	return nil
}

func (s *RedisStore) SetIdentityUser(ctx context.Context, tokenHash string, user models.IdentityUser, ttl time.Duration) error {
	if ttl <= 0 {
		ttl = time.Second
	}
	return s.setJSON(ctx, s.identityUserKey(tokenHash), user, ttl)
}

func (s *RedisStore) GetIdentityUser(ctx context.Context, tokenHash string) (models.IdentityUser, error) {
	var user models.IdentityUser
	if err := s.getJSON(ctx, s.identityUserKey(tokenHash), &user); err != nil {
		return models.IdentityUser{}, err
	}
	return user, nil
}

func (s *RedisStore) GetFileHash(ctx context.Context, objectID string, size int64, modTime time.Time) (string, error) {
	hash, err := s.client.Get(ctx, s.fileHashKey(objectID, size, modTime)).Result()
	if errors.Is(err, redis.Nil) {
		return "", ErrNotFound
	}
	if err != nil {
		return "", fmt.Errorf("get %s: %w", s.fileHashKey(objectID, size, modTime), err)
	}
	return hash, nil
}

func (s *RedisStore) AcquireNamespaceLock(ctx context.Context, principalID string, ttl time.Duration) (*LockHandle, error) {
	return s.acquireLockKeys(ctx, []string{s.namespaceLockKey(principalID)}, ttl)
}

func (s *RedisStore) AcquireSessionOperationLock(ctx context.Context, sessionID string, ttl time.Duration) (*LockHandle, error) {
	return s.acquireLockKeys(ctx, []string{s.sessionOperationLockKey(sessionID)}, ttl)
}

func (s *RedisStore) CheckLock(ctx context.Context, lock *LockHandle) (bool, error) {
	if lock == nil || lock.Token == "" || len(lock.Keys) == 0 {
		return false, nil
	}
	for _, key := range lock.Keys {
		value, err := s.client.Get(ctx, key).Result()
		if errors.Is(err, redis.Nil) || value != lock.Token {
			return false, nil
		}
		if err != nil {
			return false, fmt.Errorf("check lock %s: %w", key, err)
		}
	}
	return true, nil
}

func (s *RedisStore) TryAcquireCleanupLock(ctx context.Context, ttl time.Duration) (*LockHandle, error) {
	return s.acquireLockKeys(ctx, []string{s.cleanupLockKey()}, ttl)
}

func (s *RedisStore) ReleaseLock(ctx context.Context, lock *LockHandle) error {
	if lock == nil || lock.Token == "" || len(lock.Keys) == 0 {
		return nil
	}
	var releaseErr error
	for _, key := range lock.Keys {
		err := s.client.Watch(ctx, func(tx *redis.Tx) error {
			current, err := tx.Get(ctx, key).Result()
			if errors.Is(err, redis.Nil) {
				return nil
			}
			if err != nil {
				return err
			}
			if current != lock.Token {
				return nil
			}
			_, err = tx.TxPipelined(ctx, func(pipe redis.Pipeliner) error {
				pipe.Del(ctx, key)
				return nil
			})
			return err
		}, key)
		if err != nil && releaseErr == nil {
			releaseErr = fmt.Errorf("release lock %s: %w", key, err)
		}
	}
	return releaseErr
}

func (s *RedisStore) setJSON(ctx context.Context, key string, value any, ttl time.Duration) error {
	payload, err := json.Marshal(value)
	if err != nil {
		return fmt.Errorf("marshal %s: %w", key, err)
	}
	if err := s.client.Set(ctx, key, payload, ttl).Err(); err != nil {
		return fmt.Errorf("set %s: %w", key, err)
	}
	return nil
}

func (s *RedisStore) getJSON(ctx context.Context, key string, out any) error {
	payload, err := s.client.Get(ctx, key).Bytes()
	if errors.Is(err, redis.Nil) {
		return ErrNotFound
	}
	if err != nil {
		return fmt.Errorf("get %s: %w", key, err)
	}
	if err := json.Unmarshal(payload, out); err != nil {
		return fmt.Errorf("unmarshal %s: %w", key, err)
	}
	return nil
}

func (s *RedisStore) grantKey(direction models.TransferGrantDirection, taskID, objectKey string) string {
	return fmt.Sprintf("%s:grant:%s:%s:%s", s.keyPrefix, direction, taskID, url.QueryEscape(objectKey))
}

func (s *RedisStore) fileHashKey(objectID string, size int64, modTime time.Time) string {
	return fmt.Sprintf("%s:filehash:%s:%d:%d", s.keyPrefix, url.QueryEscape(objectID), size, modTime.UTC().UnixNano())
}

func (s *RedisStore) identityUserKey(tokenHash string) string {
	// Keep structured identities separate from legacy ID-only cache values,
	// including while old and new server versions run concurrently.
	return fmt.Sprintf("%s:identity:userinfo:v2:%s", s.keyPrefix, tokenHash)
}

func (s *RedisStore) namespaceLockKey(principalID string) string {
	return fmt.Sprintf("%s:lock:namespace:%s", s.keyPrefix, url.QueryEscape(principalID))
}

func (s *RedisStore) sessionOperationLockKey(sessionID string) string {
	return fmt.Sprintf("%s:lock:upload-operation:%s", s.keyPrefix, url.QueryEscape(sessionID))
}

func (s *RedisStore) cleanupLockKey() string {
	return fmt.Sprintf("%s:lock:cleanup", s.keyPrefix)
}

func (s *RedisStore) acquireLockKeys(ctx context.Context, keys []string, ttl time.Duration) (*LockHandle, error) {
	if ttl <= 0 {
		ttl = 30 * time.Second
	}
	keys = dedupeStrings(keys)
	if len(keys) == 0 {
		return &LockHandle{}, nil
	}
	lock := &LockHandle{
		Token: fmt.Sprintf("%d", time.Now().UnixNano()),
		Keys:  slices.Clone(keys),
	}
	acquired := make([]string, 0, len(keys))
	for _, key := range keys {
		ok, err := s.client.SetNX(ctx, key, lock.Token, ttl).Result()
		if err != nil {
			_ = s.ReleaseLock(ctx, &LockHandle{Token: lock.Token, Keys: acquired})
			return nil, fmt.Errorf("acquire lock %s: %w", key, err)
		}
		if !ok {
			_ = s.ReleaseLock(ctx, &LockHandle{Token: lock.Token, Keys: acquired})
			return nil, ErrConflict
		}
		acquired = append(acquired, key)
	}
	return lock, nil
}

func dedupeStrings(values []string) []string {
	if len(values) == 0 {
		return nil
	}
	sort.Strings(values)
	result := values[:0]
	var last string
	for i, value := range values {
		if i == 0 || value != last {
			result = append(result, value)
			last = value
		}
	}
	return result
}
