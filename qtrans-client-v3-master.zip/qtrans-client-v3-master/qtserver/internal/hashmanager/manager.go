package hashmanager

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"time"

	"qtserver/internal/filehash"
	"qtserver/internal/filespace"
	"qtserver/internal/store"

	"github.com/google/uuid"
)

const (
	hashWorkerPollInterval = 5 * time.Second
	hashWorkerLease        = 30 * time.Second
	hashGCBatch            = int64(128)
)

type Result struct {
	Hash        string
	Algorithm   string
	Pending     bool
	Unavailable bool
	Stale       bool
}

type Manager struct {
	redis      *store.RedisStore
	space      *filespace.Space
	revalidate time.Duration
	retention  time.Duration
	workers    int
	report     func(error)
	notify     chan struct{}
}

func New(redisStore *store.RedisStore, space *filespace.Space, revalidateSeconds, retentionSeconds, workers, queueSize int, report func(error)) *Manager {
	return &Manager{
		redis: redisStore, space: space,
		revalidate: time.Duration(revalidateSeconds) * time.Second,
		retention:  time.Duration(retentionSeconds) * time.Second,
		workers:    workers, report: report, notify: make(chan struct{}, queueSize),
	}
}

func (m *Manager) Lookup(ctx context.Context, principalID, objectKey, path string) (Result, error) {
	fingerprint, err := filehash.FingerprintPath(path)
	if err != nil {
		if os.IsNotExist(err) {
			if invalidateErr := m.Invalidate(ctx, principalID, objectKey); invalidateErr != nil {
				return Result{}, invalidateErr
			}
		}
		return Result{}, err
	}
	lookup, err := m.redis.LookupOfficialHash(ctx, officialIdentity(principalID, objectKey), storeFingerprint(fingerprint), m.revalidate, m.retention)
	if err != nil {
		m.reportStore(err)
		return Result{}, err
	}
	result := Result{Hash: lookup.Hash, Algorithm: filehash.LayeredAlgorithm}
	switch lookup.Status {
	case "fresh":
		return result, nil
	case "stale":
		result.Stale = true
		m.signal()
		return result, nil
	case "pending":
		result.Pending = true
		m.signal()
		return result, nil
	case "unavailable":
		result.Unavailable = true
		return result, nil
	default:
		err := fmt.Errorf("unknown Redis hash lookup status %q", lookup.Status)
		m.reportStore(err)
		return Result{}, err
	}
}

// BeginKnownMutation invalidates old workers before a service-controlled
// publish. CommitKnown must be called after the irreversible rename succeeds.
func (m *Manager) BeginKnownMutation(ctx context.Context, principalID, objectKey string, fingerprint filehash.Fingerprint) (int64, error) {
	generation, err := m.redis.BeginOfficialHashMutation(ctx, officialIdentity(principalID, objectKey), storeFingerprint(fingerprint), m.retention)
	if err != nil {
		m.reportStore(err)
	}
	return generation, err
}

func (m *Manager) CommitKnown(ctx context.Context, principalID, objectKey string, generation int64, fingerprint filehash.Fingerprint, hash string) (bool, error) {
	ok, err := m.redis.CommitKnownOfficialHash(ctx, officialIdentity(principalID, objectKey), generation, storeFingerprint(fingerprint), hash, m.retention)
	if err != nil {
		m.reportStore(err)
	}
	return ok, err
}

func (m *Manager) Invalidate(ctx context.Context, principalID, objectKey string) error {
	err := m.redis.InvalidateOfficialHash(ctx, officialIdentity(principalID, objectKey))
	if err != nil {
		m.reportStore(err)
	}
	return err
}

func (m *Manager) BumpNamespaceGeneration(ctx context.Context, principalID string) error {
	_, err := m.redis.BumpOfficialHashNamespaceGeneration(ctx, principalID)
	if err != nil {
		m.reportStore(err)
	}
	return err
}

func (m *Manager) Start(ctx context.Context) {
	for index := 0; index < m.workers; index++ {
		go m.worker(ctx, index)
	}
	go m.collectExpired(ctx)
}

func (m *Manager) worker(ctx context.Context, index int) {
	logger := slog.Default().With("component", "file_hash_worker", "worker", index)
	ticker := time.NewTicker(hashWorkerPollInterval)
	defer ticker.Stop()
	for {
		for {
			job, err := m.claim(ctx)
			if err != nil {
				if !errors.Is(err, context.Canceled) {
					logger.Error("claim file hash job", "error", err)
				}
				break
			}
			if job == nil {
				break
			}
			m.calculate(ctx, logger, job)
		}
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		case <-m.notify:
		}
	}
}

func (m *Manager) claim(ctx context.Context) (*store.OfficialHashJob, error) {
	job, err := m.redis.ClaimOfficialHash(ctx, uuid.NewString(), hashWorkerLease, m.retention)
	if err != nil {
		m.reportStore(err)
	}
	return job, err
}

type heartbeatResult struct {
	lost bool
	err  error
}

func (m *Manager) calculate(ctx context.Context, logger *slog.Logger, job *store.OfficialHashJob) {
	_, path, err := m.space.Resolve(job.Identity.PrincipalID, job.Identity.ObjectKey)
	if err == nil {
		jobCtx, cancel := context.WithCancel(ctx)
		heartbeatDone := make(chan heartbeatResult, 1)
		go m.heartbeat(jobCtx, cancel, *job, heartbeatDone)
		hash, hashErr := filehash.LayeredFile(jobCtx, path)
		cancel()
		heartbeat := <-heartbeatDone
		if heartbeat.err != nil {
			logger.Error("heartbeat file hash job", "object_key", job.Identity.ObjectKey, "error", heartbeat.err)
			return
		}
		if heartbeat.lost {
			logger.Info("discard file hash after losing lease", "object_key", job.Identity.ObjectKey)
			return
		}
		if hashErr == nil {
			ok, submitErr := m.redis.SubmitOfficialHash(context.Background(), *job, hash, m.retention)
			if submitErr != nil {
				m.reportStore(submitErr)
				logger.Error("submit file hash", "object_key", job.Identity.ObjectKey, "error", submitErr)
			} else if !ok {
				logger.Info("discard stale file hash result", "object_key", job.Identity.ObjectKey)
			}
			return
		}
		err = hashErr
	}
	if errors.Is(err, context.Canceled) || ctx.Err() != nil {
		return
	}
	message := "hash calculation failed"
	if err != nil {
		message = err.Error()
	}
	if _, markErr := m.redis.FailOfficialHash(context.Background(), *job, message, m.retention); markErr != nil {
		m.reportStore(markErr)
		logger.Error("mark file hash failure", "object_key", job.Identity.ObjectKey, "error", markErr)
	}
}

func (m *Manager) heartbeat(ctx context.Context, cancel context.CancelFunc, job store.OfficialHashJob, done chan<- heartbeatResult) {
	result := heartbeatResult{}
	defer func() { done <- result }()
	ticker := time.NewTicker(hashWorkerPollInterval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			ok, err := m.redis.HeartbeatOfficialHash(ctx, job, hashWorkerLease, m.retention)
			if err != nil {
				m.reportStore(err)
				result.err = err
				cancel()
				return
			}
			if !ok {
				result.lost = true
				cancel()
				return
			}
		}
	}
}

func (m *Manager) collectExpired(ctx context.Context) {
	logger := slog.Default().With("component", "file_hash_gc")
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()
	for {
		for {
			removed, err := m.redis.CollectExpiredOfficialHashes(ctx, hashGCBatch)
			if err != nil {
				if !errors.Is(err, context.Canceled) {
					m.reportStore(err)
					logger.Error("collect expired file hashes", "error", err)
				}
				break
			}
			if removed < hashGCBatch {
				break
			}
		}
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
	}
}

func (m *Manager) signal() {
	select {
	case m.notify <- struct{}{}:
	default:
	}
}

func (m *Manager) reportStore(err error) {
	if err == nil || errors.Is(err, context.Canceled) {
		return
	}
	if m.report != nil {
		m.report(fmt.Errorf("redis hash state failure: %w", err))
	}
}

func officialIdentity(principalID, objectKey string) store.OfficialHashIdentity {
	return store.OfficialHashIdentity{
		PrincipalID: principalID, ObjectKey: objectKey,
		Algorithm: filehash.LayeredAlgorithm, AlgorithmVersion: filehash.AlgorithmVersion,
	}
}

func storeFingerprint(value filehash.Fingerprint) store.OfficialHashFingerprint {
	return store.OfficialHashFingerprint{CTimeNS: value.CTimeNS, MTimeNS: value.MTimeNS, FileSize: value.Size}
}

func IsNotRegular(err error) bool { return errors.Is(err, os.ErrInvalid) }
