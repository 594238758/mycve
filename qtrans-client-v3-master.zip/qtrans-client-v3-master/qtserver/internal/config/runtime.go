package config

import (
	"fmt"
	"os"
	"path/filepath"
)

// PrepareRuntimeDirectories prepares mutable directories after read-only config
// validation has completed.
// It is intentionally called only when starting the server, not while running
// read-only configuration commands.
func PrepareRuntimeDirectories(cfg *Config) error {
	if cfg == nil {
		return fmt.Errorf("config cannot be nil")
	}

	if err := requireRuntimeDirectory(cfg.Server.UserHomeRoot); err != nil {
		return fmt.Errorf("server user_home_root %q: %w", cfg.Server.UserHomeRoot, err)
	}
	if cfg.Server.AnonymousEnabled {
		anonymousRoot := filepath.Join(cfg.Server.UserHomeRoot, "anonymous")
		if err := createExclusiveDirectory(anonymousRoot, 0o755); err != nil {
			return fmt.Errorf("server anonymous home %q: %w", anonymousRoot, err)
		}
	}
	if cfg.Server.WriteEnabled {
		if err := createExclusiveDirectory(cfg.Server.TempRoot, 0o700); err != nil {
			return fmt.Errorf("server temp_root %q: %w", cfg.Server.TempRoot, err)
		}
		if err := os.Chmod(cfg.Server.TempRoot, 0o700); err != nil {
			return fmt.Errorf("tighten server temp_root permissions: %w", err)
		}
	}

	return nil
}

func ResolveLogDirectory(raw string) (string, error) {
	directory := raw
	if directory == "" {
		directory = "./logs"
	}
	if filepath.IsAbs(directory) {
		return filepath.Clean(directory), nil
	}
	executable, err := os.Executable()
	if err != nil {
		return "", fmt.Errorf("get executable path: %w", err)
	}
	return filepath.Join(filepath.Dir(executable), directory), nil
}

func requireRuntimeDirectory(path string) error {
	info, err := os.Lstat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return fmt.Errorf("directory does not exist")
		}
		return fmt.Errorf("inspect directory: %w", err)
	}
	if info.Mode()&os.ModeSymlink != 0 {
		return fmt.Errorf("must not be a symbolic link")
	}
	if !info.IsDir() {
		return fmt.Errorf("must be a directory")
	}
	return nil
}

func createExclusiveDirectory(path string, mode os.FileMode) error {
	if err := os.MkdirAll(path, mode); err != nil {
		return fmt.Errorf("create directory: %w", err)
	}
	return requireRuntimeDirectory(path)
}
