package config

import (
	"fmt"
	"net"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"unicode/utf8"
)

func validateConfig(cfg *Config) error {
	if cfg.Server.Port < 1024 || cfg.Server.Port > 65535 {
		return fmt.Errorf("invalid server port: %d, must be between 1024 and 65535", cfg.Server.Port)
	}
	if cfg.Server.Host == "" {
		return fmt.Errorf("server host cannot be empty")
	}
	if strings.TrimSpace(cfg.Server.InstanceID) == "" || strings.ContainsAny(cfg.Server.InstanceID, "\r\n\x00") {
		return fmt.Errorf("server instance_id must be a non-empty single-line value")
	}
	if net.ParseIP(cfg.Server.ExternalIP) == nil {
		return fmt.Errorf("server external_ip must be an IP address")
	}
	if strings.TrimSpace(cfg.Server.ExternalAddress) == "" || strings.ContainsAny(cfg.Server.ExternalAddress, "\r\n\x00") {
		return fmt.Errorf("server external_address must be a non-empty single-line value")
	}
	if err := validateTrustedProxies(cfg.Server.TrustedProxies); err != nil {
		return fmt.Errorf("server trusted_proxies: %w", err)
	}
	if err := validateUserHomeRoot(cfg.Server.UserHomeRoot); err != nil {
		return fmt.Errorf("server user_home_root: %w", err)
	}
	if cfg.Server.WriteEnabled {
		if err := validateTempRoot(cfg.Server.UserHomeRoot, cfg.Server.TempRoot); err != nil {
			return fmt.Errorf("server temp_root: %w", err)
		}
	}
	nginxAcc, err := normalizeNginxAcc(cfg.Server.NginxAcc)
	if err != nil {
		return fmt.Errorf("server nginx_acc: %w", err)
	}
	cfg.Server.NginxAcc = nginxAcc
	seenInitDirs := make(map[string]struct{}, len(cfg.Server.UserHomeInitDirs))
	for _, item := range cfg.Server.UserHomeInitDirs {
		if err := validateUploadHomeInitDir(item.Name); err != nil {
			return err
		}
		if _, exists := seenInitDirs[item.Name]; exists {
			return fmt.Errorf("server user_home_init_dirs contains duplicate name %q", item.Name)
		}
		seenInitDirs[item.Name] = struct{}{}
		if item.HasOwnership {
			if item.UID < 0 {
				return fmt.Errorf("server upload_home_init_dirs uid must be >= 0")
			}
			if item.GID < 0 {
				return fmt.Errorf("server upload_home_init_dirs gid must be >= 0")
			}
		}
		if strings.TrimSpace(item.Mode) != "" {
			mode, err := parseUploadHomePolicyMode(item.Mode)
			if err != nil {
				return fmt.Errorf("server upload_home_init_dirs mode: %w", err)
			}
			if mode > 0o777 {
				return fmt.Errorf("server upload_home_init_dirs mode must be between 0000 and 0777")
			}
		}
	}
	if cfg.Redis.Addr == "" {
		return fmt.Errorf("redis addr cannot be empty")
	}
	if cfg.Redis.KeyPrefix == "" {
		return fmt.Errorf("redis key_prefix cannot be empty")
	}
	if cfg.Transfer.HMACSecret == "" || cfg.Transfer.HMACSecret == "change-me-in-config" {
		return fmt.Errorf("transfer hmac_secret must be configured")
	}
	if cfg.Transfer.GrantTTLSeconds < 60 {
		return fmt.Errorf("transfer grant_ttl_seconds must be at least 60")
	}
	if cfg.Transfer.MaxFileBytes <= 0 {
		return fmt.Errorf("transfer max_file_bytes must be greater than 0")
	}
	if cfg.Transfer.MaxDownloadFiles <= 0 || cfg.Transfer.MaxDownloadFiles > 1000 {
		return fmt.Errorf("transfer max_download_files must be between 1 and 1000")
	}
	if cfg.Transfer.MaxSmallFiles <= 0 || cfg.Transfer.MaxSmallFiles > cfg.Transfer.MaxDownloadFiles {
		return fmt.Errorf("transfer max_small_files must be between 1 and max_download_files")
	}
	if cfg.Transfer.MaxSmallTotalBytes <= 0 {
		return fmt.Errorf("transfer max_small_total_bytes must be greater than 0")
	}
	if cfg.Transfer.MaxSmallFileBytes <= 0 {
		return fmt.Errorf("transfer max_small_file_bytes must be greater than 0")
	}
	if cfg.Transfer.MaxSmallFileBytes > cfg.Transfer.MaxFileBytes {
		return fmt.Errorf("transfer max_small_file_bytes must not exceed max_file_bytes")
	}
	if cfg.Transfer.FileHashRevalidateSeconds <= 0 {
		return fmt.Errorf("transfer file_hash_revalidate_seconds must be greater than 0")
	}
	if cfg.Transfer.FileHashRetentionSeconds <= cfg.Transfer.FileHashRevalidateSeconds {
		return fmt.Errorf("transfer file_hash_retention_seconds must be greater than file_hash_revalidate_seconds")
	}
	if cfg.Transfer.HashWorkerCount <= 0 {
		return fmt.Errorf("transfer hash_worker_count must be greater than 0")
	}
	if cfg.Transfer.HashQueueSize <= 0 {
		return fmt.Errorf("transfer hash_queue_size must be greater than 0")
	}
	if cfg.Transfer.UploadSessionRetentionSeconds < 60 {
		return fmt.Errorf("transfer upload_session_retention_seconds must be at least 60")
	}

	switch cfg.Identity.Mode {
	case "", "fake", "off":
	case "auth":
		authBaseURL, err := normalizeAuthBaseURL(cfg.Identity.AuthBaseURL)
		if err != nil {
			return fmt.Errorf("identity auth_base_url: %w", err)
		}
		cfg.Identity.AuthBaseURL = authBaseURL
	case "oauth2-introspection":
		endpoint, err := normalizeIntrospectionEndpoint(cfg.Identity.IntrospectionEndpoint)
		if err != nil {
			return fmt.Errorf("identity introspection_endpoint: %w", err)
		}
		cfg.Identity.IntrospectionEndpoint = endpoint
	default:
		return fmt.Errorf("identity mode must be one of: auth, fake, off, oauth2-introspection")
	}
	if cfg.Identity.TimeoutSeconds <= 0 {
		return fmt.Errorf("identity timeout_seconds must be greater than 0")
	}
	if cfg.Identity.UserInfoCacheTTLSeconds < 0 {
		return fmt.Errorf("identity userinfo_cache_ttl_seconds cannot be negative")
	}

	validLevels := map[string]bool{"debug": true, "info": true, "warn": true, "error": true}
	if !validLevels[cfg.Log.Level] {
		return fmt.Errorf("invalid log level: %s, must be one of: debug, info, warn, error", cfg.Log.Level)
	}
	if cfg.Log.FilePath == "" {
		return fmt.Errorf("log file_path cannot be empty")
	}
	if cfg.Log.TaskType != "0" && cfg.Log.TaskType != "1" {
		return fmt.Errorf("log task_type must be 0 or 1")
	}
	if cfg.Log.FileInactivityTimeoutSeconds <= 0 {
		return fmt.Errorf("log file_inactivity_timeout_seconds must be greater than 0")
	}
	if cfg.Log.Rotation.MaxSize < 1 {
		return fmt.Errorf("log rotation max_size must be greater than 0")
	}
	if cfg.Log.Rotation.MaxBackups < 0 {
		return fmt.Errorf("log rotation max_backups cannot be negative")
	}
	if cfg.Log.Rotation.MaxAge < 1 {
		return fmt.Errorf("log rotation max_age must be greater than 0")
	}
	return nil
}

func normalizeIntrospectionEndpoint(raw string) (string, error) {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" {
		return "", fmt.Errorf("cannot be empty when mode=oauth2-introspection")
	}
	parsed, err := url.Parse(trimmed)
	if err != nil || !parsed.IsAbs() || parsed.Host == "" {
		if err == nil {
			err = fmt.Errorf("missing scheme or host")
		}
		return "", err
	}
	if parsed.Scheme != "http" && parsed.Scheme != "https" {
		return "", fmt.Errorf("scheme must be http or https")
	}
	if parsed.User != nil || parsed.RawQuery != "" || parsed.Fragment != "" || parsed.Opaque != "" {
		return "", fmt.Errorf("must not contain userinfo, query, fragment, or opaque data")
	}
	return parsed.String(), nil
}

func validateUserHomeRoot(raw string) error {
	if err := validateAbsoluteCleanPath(raw); err != nil {
		return err
	}
	info, err := os.Lstat(raw)
	if err != nil {
		return fmt.Errorf("inspect directory: %w", err)
	}
	if info.Mode()&os.ModeSymlink != 0 {
		return fmt.Errorf("must not be a symbolic link")
	}
	if !info.IsDir() {
		return fmt.Errorf("must be a directory")
	}
	file, err := os.Open(raw)
	if err != nil {
		return fmt.Errorf("must be accessible: %w", err)
	}
	return file.Close()
}

func validateTempRoot(userHomeRoot, tempRoot string) error {
	if err := validateAbsoluteCleanPath(tempRoot); err != nil {
		return err
	}
	if info, err := os.Lstat(tempRoot); err == nil {
		if info.Mode()&os.ModeSymlink != 0 || !info.IsDir() {
			return fmt.Errorf("existing path must be a real directory")
		}
	} else if !os.IsNotExist(err) {
		return fmt.Errorf("inspect path: %w", err)
	}

	defaultTemp := filepath.Join(userHomeRoot, ".uploadtemp")
	if tempRoot == defaultTemp {
		return nil
	}
	homeReal, err := filepath.EvalSymlinks(userHomeRoot)
	if err != nil {
		return fmt.Errorf("resolve user_home_root: %w", err)
	}
	tempReal, err := resolveExistingPath(tempRoot)
	if err != nil {
		return err
	}
	if pathsOverlap(homeReal, tempReal) {
		return fmt.Errorf("must not equal, contain, or be contained by user_home_root")
	}
	return nil
}

func validateAbsoluteCleanPath(raw string) error {
	if raw == "" || !filepath.IsAbs(raw) {
		return fmt.Errorf("must be an absolute path")
	}
	if filepath.Clean(raw) != raw {
		return fmt.Errorf("must be a clean path")
	}
	return nil
}

func resolveExistingPath(raw string) (string, error) {
	current := raw
	var suffix []string
	for {
		resolved, err := filepath.EvalSymlinks(current)
		if err == nil {
			for i := len(suffix) - 1; i >= 0; i-- {
				resolved = filepath.Join(resolved, suffix[i])
			}
			return filepath.Clean(resolved), nil
		}
		if !os.IsNotExist(err) {
			return "", fmt.Errorf("resolve path: %w", err)
		}
		parent := filepath.Dir(current)
		if parent == current {
			return "", fmt.Errorf("resolve path: no existing ancestor")
		}
		suffix = append(suffix, filepath.Base(current))
		current = parent
	}
}

func pathsOverlap(a, b string) bool {
	relAB, errAB := filepath.Rel(a, b)
	relBA, errBA := filepath.Rel(b, a)
	inside := func(rel string, err error) bool {
		return err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator))
	}
	return inside(relAB, errAB) || inside(relBA, errBA)
}

func normalizeNginxAcc(raw string) (string, error) {
	value := strings.TrimRight(strings.TrimSpace(raw), "/")
	if value == "" {
		return "", nil
	}
	if !strings.HasPrefix(value, "/") || value == "/" {
		return "", fmt.Errorf("must be a non-root absolute URI prefix")
	}
	if strings.ContainsAny(value, "\\\x00%?#") || strings.Contains(value, "://") {
		return "", fmt.Errorf("contains an unsafe URI component")
	}
	for _, segment := range strings.Split(strings.TrimPrefix(value, "/"), "/") {
		if segment == "" || segment == "." || segment == ".." {
			return "", fmt.Errorf("contains an empty or dot segment")
		}
	}
	return value, nil
}

func normalizeAuthBaseURL(raw string) (string, error) {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" {
		return "", fmt.Errorf("cannot be empty when mode=auth")
	}
	parsed, err := url.Parse(trimmed)
	if err != nil || !parsed.IsAbs() || parsed.Host == "" {
		if err == nil {
			err = fmt.Errorf("missing scheme or host")
		}
		return "", err
	}
	if parsed.Scheme != "http" && parsed.Scheme != "https" {
		return "", fmt.Errorf("scheme must be http or https")
	}
	if parsed.User != nil || parsed.RawQuery != "" || parsed.Fragment != "" || parsed.Opaque != "" {
		return "", fmt.Errorf("must not contain userinfo, query, fragment, or opaque data")
	}

	parsed.Path = strings.TrimRight(parsed.Path, "/")
	parsed.RawPath = ""
	if strings.HasSuffix(parsed.Path, "/oauth2/token") || strings.HasSuffix(parsed.Path, "/userinfo") {
		return "", fmt.Errorf("must be a service base URL, not an endpoint URL")
	}
	return parsed.String(), nil
}

func validateUploadHomeInitDir(raw string) error {
	name := raw
	switch {
	case name == "":
		return fmt.Errorf("server user_home_init_dirs cannot contain empty names")
	case !utf8.ValidString(name) || strings.ContainsRune(name, '\x00'):
		return fmt.Errorf("server user_home_init_dirs must contain valid UTF-8 names without NUL")
	case name == "." || name == "..":
		return fmt.Errorf("server user_home_init_dirs must contain only direct child directory names")
	case strings.ContainsAny(name, `/\`):
		return fmt.Errorf("server user_home_init_dirs must not contain path separators")
	default:
		return nil
	}
}

func validateTrustedProxies(values []string) error {
	for _, raw := range values {
		value := strings.TrimSpace(raw)
		if value == "" {
			return fmt.Errorf("must not contain empty entries")
		}
		if net.ParseIP(value) != nil {
			continue
		}
		if _, _, err := net.ParseCIDR(value); err == nil {
			continue
		}
		return fmt.Errorf("invalid entry %q, must be an IP or CIDR", raw)
	}
	return nil
}

func parseUploadHomePolicyMode(raw string) (uint32, error) {
	mode := strings.TrimSpace(raw)
	if mode == "" {
		return 0, fmt.Errorf("must not be empty")
	}
	mode = strings.TrimPrefix(strings.ToLower(mode), "0o")
	mode = strings.TrimPrefix(mode, "0")
	if mode == "" {
		mode = "0"
	}
	for _, ch := range mode {
		if ch < '0' || ch > '7' {
			return 0, fmt.Errorf("must be an octal permission like 700 or 0755")
		}
	}
	parsed, err := strconv.ParseUint(mode, 8, 32)
	if err != nil {
		return 0, err
	}
	return uint32(parsed), nil
}
