package config

import "github.com/spf13/pflag"

func RegisterOverrideFlags(flags *pflag.FlagSet) {
	flags.IntP("port", "p", 0, "port to run the server on")
	flags.String("host", "", "listen host override")
	flags.String("loglevel", "", "log level override")
	flags.String("logpath", "", "log directory override")
}
