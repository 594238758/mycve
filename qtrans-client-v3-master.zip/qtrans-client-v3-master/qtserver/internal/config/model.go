package config

import (
	"encoding/json"
	"fmt"
)

// Config represents the application configuration.
type Config struct {
	Server         ServerConfig   `mapstructure:"server"`
	Log            LogConfig      `mapstructure:"log"`
	Redis          RedisConfig    `mapstructure:"redis"`
	Transfer       TransferConfig `mapstructure:"transfer"`
	Identity       IdentityConfig `mapstructure:"identity"`
	LegacyPostgres struct {
		DSN string `mapstructure:"dsn" json:"-"`
	} `mapstructure:"postgres" json:"-"`
}

// ServerConfig represents HTTP server and filesystem layout settings.
type ServerConfig struct {
	Port               int                     `mapstructure:"port"`
	Host               string                  `mapstructure:"host"`
	InstanceID         string                  `mapstructure:"instance_id"`
	ExternalIP         string                  `mapstructure:"external_ip"`
	ExternalAddress    string                  `mapstructure:"external_address"`
	TrustedProxies     []string                `mapstructure:"trusted_proxies"`
	UserHomeRoot       string                  `mapstructure:"user_home_root"`
	UserHomeInitOnList bool                    `mapstructure:"user_home_init_on_list"`
	TempRoot           string                  `mapstructure:"temp_root"`
	ReadEnabled        bool                    `mapstructure:"read_enabled"`
	WriteEnabled       bool                    `mapstructure:"write_enabled"`
	AnonymousEnabled   bool                    `mapstructure:"anonymous_enabled"`
	NginxAcc           string                  `mapstructure:"nginx_acc"`
	UserHomeInitDirs   []UserHomeInitDirConfig `mapstructure:"user_home_init_dirs"`
}

func (c ServerConfig) NginxDownloadEnabled() bool {
	return c.ReadEnabled && c.NginxAcc != ""
}

type UserHomeInitDirConfig struct {
	Name         string `mapstructure:"name" json:"name"`
	UID          int    `mapstructure:"uid" json:"uid,omitempty"`
	GID          int    `mapstructure:"gid" json:"gid,omitempty"`
	Mode         string `mapstructure:"mode" json:"mode,omitempty"`
	HasOwnership bool   `mapstructure:"-" json:"-"`
}

// RedisConfig stores shared-state configuration.
type RedisConfig struct {
	Addr      string `mapstructure:"addr"`
	Password  string `mapstructure:"password"`
	DB        int    `mapstructure:"db"`
	KeyPrefix string `mapstructure:"key_prefix"`
}

// TransferConfig stores transfer policy and signing settings.
type TransferConfig struct {
	HMACSecret                    string `mapstructure:"hmac_secret" json:"-"`
	GrantTTLSeconds               int    `mapstructure:"grant_ttl_seconds"`
	MaxFileBytes                  int64  `mapstructure:"max_file_bytes"`
	MaxDownloadFiles              int    `mapstructure:"max_download_files"`
	MaxSmallFiles                 int    `mapstructure:"max_small_files"`
	MaxSmallTotalBytes            int64  `mapstructure:"max_small_total_bytes"`
	MaxSmallFileBytes             int64  `mapstructure:"max_small_file_bytes"`
	FileHashRevalidateSeconds     int    `mapstructure:"file_hash_revalidate_seconds"`
	FileHashRetentionSeconds      int    `mapstructure:"file_hash_retention_seconds"`
	HashWorkerCount               int    `mapstructure:"hash_worker_count"`
	HashQueueSize                 int    `mapstructure:"hash_queue_size"`
	UploadSessionRetentionSeconds int    `mapstructure:"upload_session_retention_seconds"`
}

// IdentityConfig stores identity source behavior for this service.
type IdentityConfig struct {
	Mode                    string            `mapstructure:"mode"`
	AuthBaseURL             string            `mapstructure:"auth_base_url"`
	IntrospectionEndpoint   string            `mapstructure:"introspection_endpoint"`
	FakeTokens              map[string]string `mapstructure:"fake_tokens"`
	TimeoutSeconds          int               `mapstructure:"timeout_seconds"`
	UserInfoCacheTTLSeconds int               `mapstructure:"userinfo_cache_ttl_seconds"`
}

// LogRotationConfig 日志切分配置。
type LogRotationConfig struct {
	Enable     bool `mapstructure:"enable"`
	MaxSize    int  `mapstructure:"max_size"`
	MaxBackups int  `mapstructure:"max_backups"`
	MaxAge     int  `mapstructure:"max_age"`
	Compress   bool `mapstructure:"compress"`
}

// LogConfig 日志配置选项。
type LogConfig struct {
	Level                        string            `mapstructure:"level"`
	FilePath                     string            `mapstructure:"file_path"`
	TaskType                     string            `mapstructure:"task_type"`
	FileInactivityTimeoutSeconds int               `mapstructure:"file_inactivity_timeout_seconds"`
	Rotation                     LogRotationConfig `mapstructure:"rotation"`
}

func (c *Config) String() string {
	type safeConfig Config
	redacted := safeConfig(*c)
	redacted.Redis.Password = "[REDACTED]"
	redacted.Transfer.HMACSecret = "[REDACTED]"
	if len(redacted.Identity.FakeTokens) > 0 {
		redacted.Identity.FakeTokens = map[string]string{"[REDACTED]": "[REDACTED]"}
	}
	data, err := json.MarshalIndent(redacted, "", "  ")
	if err != nil {
		return fmt.Sprintf("Error marshaling config: %v", err)
	}
	return string(data)
}
