package config

import (
	"fmt"
	"os"
	"path/filepath"
)

const demoConfigTOML = `[server]
host = "127.0.0.1"
port = 10001
instance_id = "qtserver-demo"
external_ip = "127.0.0.1"
external_address = "127.0.0.1:10001"
trusted_proxies = ["127.0.0.1", "::1"]
user_home_root = "/opt/qtrans/qtserver/data/users"
user_home_init_on_list = false
temp_root = "/opt/qtrans/qtserver/data/upload-temp"
read_enabled = true
write_enabled = true
anonymous_enabled = false
nginx_acc = "/qtserver/internal-download"

[[server.user_home_init_dirs]]
name = "gsa1"

[[server.user_home_init_dirs]]
name = "gsa2"

[[server.user_home_init_dirs]]
name = "gsa5"

[redis]
addr = "127.0.0.1:6379"
password = ""
db = 0
key_prefix = "qtserver-local"

[transfer]
hmac_secret = "qtserver-local-secret"
grant_ttl_seconds = 900
max_file_bytes = 1099511627776
max_download_files = 1000
max_small_files = 100
max_small_total_bytes = 134217728
max_small_file_bytes = 4194304
file_hash_revalidate_seconds = 86400
file_hash_retention_seconds = 2592000
hash_worker_count = 2
hash_queue_size = 1000
upload_session_retention_seconds = 86400

[identity]
mode = "fake"
auth_base_url = ""
introspection_endpoint = ""
fake_tokens = { "demo-token" = "demo" }
timeout_seconds = 5
userinfo_cache_ttl_seconds = 10

[log]
level = "debug"
file_path = "./logs"
task_type = "1"
file_inactivity_timeout_seconds = 86400

[log.rotation]
enable = false
max_size = 100
max_backups = 3
max_age = 7
compress = false
`

func DemoConfigTOML() string {
	return demoConfigTOML
}

func WriteDemoConfig(configPath string, force bool) (string, error) {
	resolvedPath, err := ResolveConfigPath(configPath)
	if err != nil {
		return "", err
	}
	if !force {
		if _, err := os.Stat(resolvedPath); err == nil {
			return "", fmt.Errorf("config file already exists: %s", resolvedPath)
		} else if !os.IsNotExist(err) {
			return "", err
		}
	}
	if err := os.MkdirAll(filepath.Dir(resolvedPath), 0755); err != nil {
		return "", err
	}
	if err := os.WriteFile(resolvedPath, []byte(demoConfigTOML), 0644); err != nil {
		return "", err
	}
	return resolvedPath, nil
}
