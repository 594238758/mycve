package config

import (
	"fmt"
	"math"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/spf13/pflag"
	"github.com/spf13/viper"
)

const defaultConfigFilename = "qtserver_config.toml"

const DefaultMaxFileBytes int64 = 1 << 40

type LoadOptions struct {
	ConfigPath string
	Flags      *pflag.FlagSet
}

func DefaultConfigFilename() string {
	return defaultConfigFilename
}

func DefaultConfigPath() (string, error) {
	return ResolveConfigPath("")
}

func ResolveConfigPath(configPath string) (string, error) {
	if configPath != "" {
		return configPath, nil
	}
	exePath, err := os.Executable()
	if err != nil {
		return "", fmt.Errorf("failed to get executable path: %w", err)
	}
	return filepath.Join(filepath.Dir(exePath), defaultConfigFilename), nil
}

func setDefaults(v *viper.Viper) {
	v.SetDefault("server.port", 10001)
	v.SetDefault("server.host", "0.0.0.0")
	v.SetDefault("server.instance_id", "")
	v.SetDefault("server.external_ip", "")
	v.SetDefault("server.external_address", "")
	v.SetDefault("server.trusted_proxies", []string{"127.0.0.1", "::1"})
	v.SetDefault("server.user_home_root", "/data/users")
	v.SetDefault("server.user_home_init_on_list", false)
	v.SetDefault("server.temp_root", "")
	v.SetDefault("server.read_enabled", true)
	v.SetDefault("server.write_enabled", true)
	v.SetDefault("server.anonymous_enabled", false)
	v.SetDefault("server.nginx_acc", "")
	v.SetDefault("server.user_home_init_dirs", []map[string]any{})

	v.SetDefault("redis.addr", "127.0.0.1:6379")
	v.SetDefault("redis.password", "")
	v.SetDefault("redis.db", 0)
	v.SetDefault("redis.key_prefix", "qtserver")

	v.SetDefault("transfer.hmac_secret", "change-me-in-config")
	v.SetDefault("transfer.grant_ttl_seconds", 900)
	v.SetDefault("transfer.max_file_bytes", DefaultMaxFileBytes)
	v.SetDefault("transfer.max_download_files", 1000)
	v.SetDefault("transfer.max_small_files", 100)
	v.SetDefault("transfer.max_small_total_bytes", 134217728)
	v.SetDefault("transfer.max_small_file_bytes", 4194304)
	v.SetDefault("transfer.file_hash_revalidate_seconds", 86400)
	v.SetDefault("transfer.file_hash_retention_seconds", 2592000)
	v.SetDefault("transfer.hash_worker_count", 2)
	v.SetDefault("transfer.hash_queue_size", 1000)
	v.SetDefault("transfer.upload_session_retention_seconds", 86400)

	v.SetDefault("identity.mode", "fake")
	v.SetDefault("identity.auth_base_url", "")
	v.SetDefault("identity.introspection_endpoint", "")
	v.SetDefault("identity.fake_tokens", map[string]string{})
	v.SetDefault("identity.timeout_seconds", 5)
	v.SetDefault("identity.userinfo_cache_ttl_seconds", 10)

	v.SetDefault("log.level", "debug")
	v.SetDefault("log.file_path", "./logs")
	v.SetDefault("log.task_type", "1")
	v.SetDefault("log.file_inactivity_timeout_seconds", 86400)
	v.SetDefault("log.rotation.enable", true)
	v.SetDefault("log.rotation.max_size", 100)
	v.SetDefault("log.rotation.max_backups", 3)
	v.SetDefault("log.rotation.max_age", 7)
	v.SetDefault("log.rotation.compress", true)
}

func loadConfigFromFile(v *viper.Viper, configPath string) error {
	resolvedPath, err := ResolveConfigPath(configPath)
	if err != nil {
		return err
	}
	v.SetConfigFile(resolvedPath)
	if err := v.ReadInConfig(); err != nil {
		return err
	}
	return nil
}

func mergeConfigFromCmdline(flags *pflag.FlagSet, v *viper.Viper) error {
	if flags == nil {
		return nil
	}
	setStringFlag(flags, v, "host", "server.host")
	setStringFlag(flags, v, "loglevel", "log.level")
	setStringFlag(flags, v, "logpath", "log.file_path")

	if flag := flags.Lookup("port"); flag != nil && flag.Changed {
		port, _ := flags.GetInt("port")
		v.Set("server.port", port)
	}
	return nil
}

func applyDerivedPaths(cfg *Config) {
	if cfg == nil {
		return
	}
	if cfg.Server.TempRoot == "" && cfg.Server.UserHomeRoot != "" {
		cfg.Server.TempRoot = filepath.Join(cfg.Server.UserHomeRoot, ".uploadtemp")
	}
	if strings.TrimSpace(cfg.Server.InstanceID) == "" {
		cfg.Server.InstanceID = localHostname()
	}
	if strings.TrimSpace(cfg.Server.ExternalIP) == "" {
		cfg.Server.ExternalIP = deriveExternalIP(cfg.Server.Host)
	}
	if strings.TrimSpace(cfg.Server.ExternalAddress) == "" {
		cfg.Server.ExternalAddress = net.JoinHostPort(cfg.Server.ExternalIP, strconv.Itoa(cfg.Server.Port))
	}
}

func localHostname() string {
	hostname, err := os.Hostname()
	if err == nil && strings.TrimSpace(hostname) != "" {
		return strings.TrimSpace(hostname)
	}
	return "qtserver"
}

func deriveExternalIP(host string) string {
	trimmed := strings.TrimSpace(host)
	if parsed := net.ParseIP(trimmed); parsed != nil && !parsed.IsUnspecified() {
		return parsed.String()
	}
	if trimmed != "" && trimmed != "0.0.0.0" && trimmed != "::" {
		if addresses, err := net.LookupIP(trimmed); err == nil {
			for _, address := range addresses {
				if !address.IsUnspecified() && !address.IsLoopback() {
					return address.String()
				}
			}
		}
	}
	if addresses, err := net.InterfaceAddrs(); err == nil {
		for _, address := range addresses {
			var ip net.IP
			switch value := address.(type) {
			case *net.IPNet:
				ip = value.IP
			case *net.IPAddr:
				ip = value.IP
			}
			if ip != nil && !ip.IsUnspecified() && !ip.IsLoopback() {
				return ip.String()
			}
		}
	}
	return "127.0.0.1"
}

func setStringFlag(flags *pflag.FlagSet, v *viper.Viper, flagName, key string) {
	if flags.Lookup(flagName) != nil && flags.Lookup(flagName).Changed {
		value, _ := flags.GetString(flagName)
		v.Set(key, value)
	}
}

func parseUploadHomeInitDirs(raw any, key string) ([]UserHomeInitDirConfig, error) {
	if raw == nil {
		return nil, nil
	}
	switch values := raw.(type) {
	case []any:
		result := make([]UserHomeInitDirConfig, 0, len(values))
		for index, rawEntry := range values {
			switch entry := rawEntry.(type) {
			case map[string]any:
				item, err := parseUploadHomeInitDirEntry(entry, key, index)
				if err != nil {
					return nil, err
				}
				result = append(result, item)
			default:
				return nil, fmt.Errorf("%s[%d] must be a table", key, index)
			}
		}
		return result, nil
	case []map[string]any:
		result := make([]UserHomeInitDirConfig, 0, len(values))
		for index, entry := range values {
			item, err := parseUploadHomeInitDirEntry(entry, key, index)
			if err != nil {
				return nil, err
			}
			result = append(result, item)
		}
		return result, nil
	default:
		return nil, fmt.Errorf("%s must be an array of tables", key)
	}
}

func parseUploadHomeInitDirEntry(entry map[string]any, key string, index int) (UserHomeInitDirConfig, error) {
	for field := range entry {
		switch field {
		case "name", "uid", "gid", "mode":
		default:
			return UserHomeInitDirConfig{}, fmt.Errorf("%s[%d] contains unknown field %q", key, index, field)
		}
	}
	name, err := parseRequiredString(entry, "name")
	if err != nil {
		return UserHomeInitDirConfig{}, fmt.Errorf("%s[%d].name: %w", key, index, err)
	}
	item := UserHomeInitDirConfig{Name: name}
	uid, hasUID, err := parseOptionalInt(entry, "uid")
	if err != nil {
		return UserHomeInitDirConfig{}, fmt.Errorf("%s[%d].uid: %w", key, index, err)
	}
	gid, hasGID, err := parseOptionalInt(entry, "gid")
	if err != nil {
		return UserHomeInitDirConfig{}, fmt.Errorf("%s[%d].gid: %w", key, index, err)
	}
	if hasUID != hasGID {
		return UserHomeInitDirConfig{}, fmt.Errorf("%s[%d]: uid and gid must be provided together", key, index)
	}
	if hasUID {
		item.UID = uid
		item.GID = gid
		item.HasOwnership = true
	}
	mode, hasMode, err := parseOptionalMode(entry, "mode")
	if err != nil {
		return UserHomeInitDirConfig{}, fmt.Errorf("%s[%d].mode: %w", key, index, err)
	}
	if hasMode {
		item.Mode = mode
	}
	return item, nil
}

func parseRequiredString(entry map[string]any, key string) (string, error) {
	raw, ok := entry[key]
	if !ok {
		return "", fmt.Errorf("is required")
	}
	value, ok := raw.(string)
	if !ok {
		return "", fmt.Errorf("must be a string")
	}
	if value == "" {
		return "", fmt.Errorf("must not be empty")
	}
	return value, nil
}

func parseOptionalInt(entry map[string]any, key string) (int, bool, error) {
	raw, ok := entry[key]
	if !ok {
		return 0, false, nil
	}
	switch value := raw.(type) {
	case int:
		return value, true, nil
	case int64:
		parsed, err := checkedInt64ToInt(value)
		if err != nil {
			return 0, false, err
		}
		return parsed, true, nil
	case float64:
		parsed, err := checkedFloat64ToInt(value)
		if err != nil {
			return 0, false, err
		}
		return parsed, true, nil
	case string:
		parsed, err := strconv.Atoi(strings.TrimSpace(value))
		if err != nil {
			return 0, false, fmt.Errorf("must be an integer: %w", err)
		}
		return parsed, true, nil
	default:
		return 0, false, fmt.Errorf("must be an integer")
	}
}

func parseOptionalMode(entry map[string]any, key string) (string, bool, error) {
	raw, ok := entry[key]
	if !ok {
		return "", false, nil
	}
	switch value := raw.(type) {
	case string:
		mode := strings.TrimSpace(value)
		if mode == "" {
			return "", false, fmt.Errorf("must not be empty")
		}
		return mode, true, nil
	case int:
		return strconv.Itoa(value), true, nil
	case int64:
		return strconv.FormatInt(value, 10), true, nil
	case float64:
		parsed, err := checkedFloat64ToInt(value)
		if err != nil {
			return "", false, fmt.Errorf("must be an integer or octal string: %w", err)
		}
		return strconv.Itoa(parsed), true, nil
	default:
		return "", false, fmt.Errorf("must be an integer or octal string")
	}
}

func checkedInt64ToInt(value int64) (int, error) {
	parsed := int(value)
	if int64(parsed) != value {
		return 0, fmt.Errorf("integer is out of range")
	}
	return parsed, nil
}

func checkedFloat64ToInt(value float64) (int, error) {
	if math.IsNaN(value) || math.IsInf(value, 0) || math.Trunc(value) != value {
		return 0, fmt.Errorf("must be an integer")
	}
	limit := math.Ldexp(1, strconv.IntSize-1)
	if value < -limit || value >= limit {
		return 0, fmt.Errorf("integer is out of range")
	}
	return int(value), nil
}

func validateLegacyPostgres(raw any) error {
	if raw == nil {
		return nil
	}
	section, ok := raw.(map[string]any)
	if !ok {
		return fmt.Errorf("postgres must be a table")
	}
	for field := range section {
		if field != "dsn" {
			return fmt.Errorf("postgres contains unknown field %q", field)
		}
	}
	dsn, exists := section["dsn"]
	if !exists {
		return fmt.Errorf("postgres.dsn is required when postgres is present")
	}
	if _, ok := dsn.(string); !ok {
		return fmt.Errorf("postgres.dsn must be a string")
	}
	return nil
}

// Load parses config file, defaults, and command-line overrides.
func Load(opts LoadOptions) (*Config, error) {
	v := viper.New()
	setDefaults(v)

	if err := loadConfigFromFile(v, opts.ConfigPath); err != nil {
		return nil, fmt.Errorf("failed to load config: %w", err)
	}
	if err := mergeConfigFromCmdline(opts.Flags, v); err != nil {
		return nil, fmt.Errorf("failed to merge config from cmdline: %w", err)
	}
	if err := validateLegacyPostgres(v.Get("postgres")); err != nil {
		return nil, fmt.Errorf("failed to parse legacy config: %w", err)
	}
	rawUploadHomeInitDirs := v.Get("server.user_home_init_dirs")
	v.Set("server.user_home_init_dirs", []map[string]any{})

	var cfg Config
	if err := v.UnmarshalExact(&cfg); err != nil {
		return nil, fmt.Errorf("failed to unmarshal config: %w", err)
	}
	cfg.LegacyPostgres.DSN = ""
	initDirs, err := parseUploadHomeInitDirs(rawUploadHomeInitDirs, "server.user_home_init_dirs")
	if err != nil {
		return nil, fmt.Errorf("failed to parse server.upload_home_init_dirs: %w", err)
	}
	cfg.Server.UserHomeInitDirs = initDirs
	applyDerivedPaths(&cfg)
	if err := validateConfig(&cfg); err != nil {
		return nil, fmt.Errorf("invalid config: %w", err)
	}
	return &cfg, nil
}
