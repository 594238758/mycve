package models

import "time"

type PrincipalType string

type TransferTaskType string

type TransferTaskStatus string

type TransferGrantDirection string

type TransferGrantState string

type DownloadBrowseEntryType string

// IdentityUser is the trusted userinfo result retained in the auth cache.
type IdentityUser struct {
	ID    string `json:"id"`
	Email string `json:"email"`
}

const (
	PrincipalAnonymous PrincipalType = "anonymous"
	PrincipalUser      PrincipalType = "user"

	TransferTaskDownload TransferTaskType = "download"
	TransferTaskUpload   TransferTaskType = "upload"

	TransferTaskCreated    TransferTaskStatus = "created"
	TransferTaskAuthorized TransferTaskStatus = "authorized"
	TransferTaskPartial    TransferTaskStatus = "partial"
	TransferTaskRejected   TransferTaskStatus = "rejected"
	TransferTaskCompleted  TransferTaskStatus = "completed"

	TransferGrantDownload TransferGrantDirection = "download"
	TransferGrantUpload   TransferGrantDirection = "upload"

	TransferGrantActive TransferGrantState = "active"
	TransferGrantUsed   TransferGrantState = "used"

	DownloadBrowseEntryFile      DownloadBrowseEntryType = "file"
	DownloadBrowseEntryDirectory DownloadBrowseEntryType = "directory"
)

type TransferTask struct {
	TaskID      string             `json:"taskid"`
	TaskType    TransferTaskType   `json:"task_type"`
	PrincipalID string             `json:"principal_id"`
	UserID      string             `json:"user_id,omitempty"`
	Mode        string             `json:"mode,omitempty"`
	FilesCount  int                `json:"files_count,omitempty"`
	BytesTotal  int64              `json:"bytes_total,omitempty"`
	Status      TransferTaskStatus `json:"status"`
	CreatedAt   time.Time          `json:"created_at"`
	ExpiresAt   time.Time          `json:"expires_at,omitempty"`
}

type TransferGrant struct {
	TaskID       string                 `json:"taskid"`
	ObjectKey    string                 `json:"object_key"`
	Direction    TransferGrantDirection `json:"direction"`
	PrincipalID  string                 `json:"principal_id"`
	Namespace    string                 `json:"namespace"`
	OwnerID      string                 `json:"owner_id"`
	PhysicalPath string                 `json:"physical_path"`
	InternalPath string                 `json:"internal_path"`
	ExpiresAt    int64                  `json:"expires_at"`
	HMAC         string                 `json:"hmac"`
	ExpectedHash string                 `json:"expected_hash,omitempty"`
	FileSize     int64                  `json:"file_size,omitempty"`
	ChunkSize    int64                  `json:"chunk_size,omitempty"`
	ChunkCount   int                    `json:"chunk_count,omitempty"`
	Authorized   bool                   `json:"authorized"`
	Exists       bool                   `json:"exists"`
	State        TransferGrantState     `json:"state"`
	CreatedAt    time.Time              `json:"created_at"`
}

type DownloadObjectRequest struct {
	ObjectKey string `json:"object_key" binding:"required"`
}

type DownloadFileResult struct {
	ObjectKey string `json:"object_key"`
	Size      int64  `json:"size"`
	Grant     string `json:"grant"`
}

type DownloadBrowseRequest struct {
	User string `form:"user" binding:"required"`
	Path string `form:"path"`
}

type DownloadBrowseEntry struct {
	Name         string                  `json:"name"`
	ObjectKey    string                  `json:"object_key"`
	EntryType    DownloadBrowseEntryType `json:"entry_type"`
	Size         int64                   `json:"size,omitempty"`
	LastModified string                  `json:"last_modified"`
}

type DownloadBrowseResponse struct {
	Code    int                   `json:"code"`
	Message string                `json:"message"`
	User    string                `json:"user"`
	Path    string                `json:"path"`
	Entries []DownloadBrowseEntry `json:"entries"`
}

type TaskIDResponse struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	TaskID  string `json:"taskid"`
}

type DownloadGrantRequest struct {
	TaskID string                  `json:"taskid" binding:"required"`
	Items  []DownloadObjectRequest `json:"items" binding:"required,min=1"`
}

type DownloadGrantResponse struct {
	Code    int                  `json:"code"`
	Message string               `json:"message"`
	TaskID  string               `json:"taskid"`
	Files   []DownloadFileResult `json:"files"`
}

type DownloadSmallRequest struct {
	TaskID string                  `json:"taskid" binding:"required"`
	Files  []DownloadObjectRequest `json:"files" binding:"required,min=1"`
}

type DownloadSmallSession struct {
	Version            int    `json:"version"`
	TaskID             string `json:"taskid"`
	UserID             string `json:"user_id"`
	FileCount          int    `json:"file_count"`
	TotalUnpackedBytes int64  `json:"total_unpacked_bytes"`
	HashAlgorithm      string `json:"hash_algorithm"`
}

type DownloadSmallManifestEntry struct {
	ObjectKey   string `json:"object_key"`
	ArchivePath string `json:"archive_path"`
	Size        int64  `json:"size"`
	Hash        string `json:"hash"`
}

type DownloadSmallManifest struct {
	Version       int                          `json:"version"`
	TaskID        string                       `json:"taskid"`
	UserID        string                       `json:"user_id"`
	HashAlgorithm string                       `json:"hash_algorithm"`
	Files         []DownloadSmallManifestEntry `json:"files"`
}

type DownloadSmallV2ManifestEntry struct {
	Index       int    `json:"index"`
	ObjectKey   string `json:"object_key"`
	ArchivePath string `json:"archive_path"`
	Size        int64  `json:"size"`
}

type DownloadSmallV2Manifest struct {
	Version            int                            `json:"version"`
	TaskID             string                         `json:"taskid"`
	FileCount          int                            `json:"file_count"`
	TotalUnpackedBytes int64                          `json:"total_unpacked_bytes"`
	HashAlgorithm      string                         `json:"hash_algorithm"`
	Files              []DownloadSmallV2ManifestEntry `json:"files"`
}

type DownloadSmallV2ChecksumEntry struct {
	Index       int    `json:"index"`
	ObjectKey   string `json:"object_key"`
	ArchivePath string `json:"archive_path"`
	Size        int64  `json:"size"`
	Hash        string `json:"hash"`
}

type DownloadSmallV2Checksums struct {
	Version            int                            `json:"version"`
	TaskID             string                         `json:"taskid"`
	FileCount          int                            `json:"file_count"`
	TotalUnpackedBytes int64                          `json:"total_unpacked_bytes"`
	HashAlgorithm      string                         `json:"hash_algorithm"`
	Files              []DownloadSmallV2ChecksumEntry `json:"files"`
}
