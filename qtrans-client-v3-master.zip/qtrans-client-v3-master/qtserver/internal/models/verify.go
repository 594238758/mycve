package models

type VerifyType string

const (
	VerifyTypeFile  VerifyType = "file"
	VerifyTypeChunk VerifyType = "chunk"
)

type VerifyRequest struct {
	TaskID     string     `json:"taskid" binding:"required"`
	ObjectKey  string     `json:"object_key" binding:"required"`
	VerifyType VerifyType `json:"verify_type"`
	FileHash   string     `json:"file_hash,omitempty"`
	ChunkIndex *int       `json:"chunk_index,omitempty"`
	ChunkSize  int64      `json:"chunk_size,omitempty"`
	ChunkHash  string     `json:"chunk_hash,omitempty"`
}

type VerifyResponse struct {
	Code           int        `json:"code"`
	Message        string     `json:"message"`
	TaskID         string     `json:"taskid,omitempty"`
	ObjectKey      string     `json:"object_key,omitempty"`
	VerifyType     VerifyType `json:"verify_type,omitempty"`
	ChunkIndex     *int       `json:"chunk_index,omitempty"`
	ExpectedHash   string     `json:"expected_hash,omitempty"`
	CalculatedHash string     `json:"calculated_hash,omitempty"`
	HashAlgorithm  string     `json:"hash_algorithm,omitempty"`
	Match          bool       `json:"match"`
	ReasonCode     string     `json:"reason_code,omitempty"`
}
