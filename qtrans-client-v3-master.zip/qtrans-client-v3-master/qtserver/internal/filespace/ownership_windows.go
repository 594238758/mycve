//go:build windows

package filespace

import (
	"os"

	"qtserver/internal/config"
)

func processUmask() os.FileMode { return 0o022 }

func applyOwnership(_ string, _ config.UserHomeInitDirConfig) error { return nil }
