package filespace

import (
	"fmt"
	"strings"
	"unicode/utf8"
)

const (
	MaxPathBytes    = 1024
	MaxSegmentBytes = 255
)

func NormalizeLogicalPath(raw string) (string, error) {
	if !utf8.ValidString(raw) {
		return "", fmt.Errorf("logical path must be valid UTF-8")
	}
	if raw == "" || raw[0] != '/' {
		return "", fmt.Errorf("logical path must be absolute")
	}
	if strings.ContainsRune(raw, '\x00') || strings.ContainsRune(raw, '\\') {
		return "", fmt.Errorf("logical path contains a forbidden character")
	}
	parts := strings.Split(raw, "/")
	normalized := make([]string, 0, len(parts))
	for _, part := range parts {
		if part == "" {
			continue
		}
		if part == "." || part == ".." {
			return "", fmt.Errorf("logical path contains a dot segment")
		}
		if len(part) > MaxSegmentBytes {
			return "", fmt.Errorf("logical path segment exceeds %d bytes", MaxSegmentBytes)
		}
		normalized = append(normalized, part)
	}
	result := "/" + strings.Join(normalized, "/")
	if len(result) > MaxPathBytes {
		return "", fmt.Errorf("logical path exceeds %d bytes", MaxPathBytes)
	}
	return result, nil
}

func FirstSegment(normalized string) string {
	value := strings.TrimPrefix(normalized, "/")
	if index := strings.IndexByte(value, '/'); index >= 0 {
		return value[:index]
	}
	return value
}
