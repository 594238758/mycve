//go:build !linux

package filespace

func RenameNoReplace(_, _ string) error {
	return newError("ATOMIC_NOREPLACE_UNSUPPORTED", "atomic no-replace rename is unsupported", nil)
}
