package filespace

import (
	"errors"
	"os"
	"syscall"
)

// PublishRegularNoReplace atomically exposes an inaccessible cache file at
// target while retaining the cache name for post-commit recovery.
func PublishRegularNoReplace(cachePath, targetPath string) error {
	info, err := os.Lstat(cachePath)
	if err != nil {
		return err
	}
	if !info.Mode().IsRegular() {
		return newError("ATOMIC_NOREPLACE_UNSUPPORTED", "atomic no-replace publish requires a regular cache file", nil)
	}
	if err := os.Link(cachePath, targetPath); err != nil {
		switch {
		case errors.Is(err, os.ErrExist):
			return os.ErrExist
		case errors.Is(err, syscall.EXDEV):
			return syscall.EXDEV
		case errors.Is(err, syscall.ENOSYS),
			errors.Is(err, syscall.EINVAL),
			errors.Is(err, syscall.EOPNOTSUPP),
			errors.Is(err, syscall.EPERM):
			return newError("ATOMIC_NOREPLACE_UNSUPPORTED", "atomic no-replace publish is unsupported", err)
		default:
			return err
		}
	}
	return nil
}
