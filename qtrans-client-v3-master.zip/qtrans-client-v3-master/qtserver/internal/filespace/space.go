package filespace

import (
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"syscall"

	"qtserver/internal/config"
)

type Space struct {
	root     string
	policies map[string]config.UserHomeInitDirConfig
	umask    os.FileMode
}

func New(cfg config.ServerConfig) *Space {
	policies := make(map[string]config.UserHomeInitDirConfig, len(cfg.UserHomeInitDirs))
	for _, policy := range cfg.UserHomeInitDirs {
		policies[policy.Name] = policy
	}
	return &Space{root: cfg.UserHomeRoot, policies: policies, umask: processUmask()}
}

func (s *Space) HomePath(principalID string) string {
	return filepath.Join(s.root, principalID)
}

func (s *Space) Resolve(principalID, raw string) (string, string, error) {
	normalized, err := NormalizeLogicalPath(raw)
	if err != nil {
		return "", "", newError("INVALID_PATH", err.Error(), err)
	}
	home := s.HomePath(principalID)
	if normalized == "/" {
		return normalized, home, nil
	}
	return normalized, filepath.Join(home, filepath.FromSlash(strings.TrimPrefix(normalized, "/"))), nil
}

// ExistingHome resolves ordinary home symlinks. Missing and damaged homes are
// reported as not found without creating or repairing them.
func (s *Space) ExistingHome(principalID string) (string, error) {
	home := s.HomePath(principalID)
	info, err := os.Stat(home)
	if err != nil {
		if os.IsNotExist(err) || errors.Is(err, fs.ErrNotExist) {
			return "", newError("NOT_FOUND", "principal home does not exist", err)
		}
		return "", newError("INTERNAL_ERROR", "cannot inspect principal home", err)
	}
	if !info.IsDir() {
		return "", newError("UNSUPPORTED_FILE_TYPE", "principal home is not a directory", nil)
	}
	return home, nil
}

// EnsureHome creates and initializes an ordinary principal home once. Existing
// directories and valid directory symlinks are deliberately left untouched.
func (s *Space) EnsureHome(principalID string, anonymous bool) (string, bool, error) {
	home := s.HomePath(principalID)
	if _, err := s.ExistingHome(principalID); err == nil {
		return home, false, nil
	} else if typed, ok := err.(*Error); !ok || typed.Reason != "NOT_FOUND" {
		return "", false, err
	}
	if info, err := os.Lstat(home); err == nil {
		if info.Mode()&os.ModeSymlink != 0 {
			return "", false, newError("HOME_INITIALIZATION_FAILED", "principal home symlink is damaged", nil)
		}
		return "", false, newError("HOME_INITIALIZATION_FAILED", "principal home cannot be initialized", nil)
	} else if !os.IsNotExist(err) {
		return "", false, newError("HOME_INITIALIZATION_FAILED", "cannot inspect principal home", err)
	}

	if err := os.Mkdir(home, s.defaultDirMode()); err != nil {
		return "", false, newError("HOME_INITIALIZATION_FAILED", "cannot create principal home", err)
	}
	rollback := func(cause error) (string, bool, error) {
		if removeErr := os.RemoveAll(home); removeErr != nil {
			return "", true, newError("HOME_INITIALIZATION_FAILED", "home initialization failed and rollback left residual data", errors.Join(cause, removeErr))
		}
		return "", true, newError("HOME_INITIALIZATION_FAILED", "home initialization failed", cause)
	}
	if !anonymous {
		for _, policy := range s.policies {
			path := filepath.Join(home, policy.Name)
			if err := os.Mkdir(path, s.policyDirMode(policy)); err != nil {
				return rollback(err)
			}
			if err := applyPolicy(path, policy, true); err != nil {
				return rollback(err)
			}
		}
	}
	return home, true, nil
}

func (s *Space) EnsureParents(principalID, normalized string, anonymous, includeLeaf bool) ([]string, error) {
	home, homeCreated, err := s.EnsureHome(principalID, anonymous)
	if err != nil {
		return nil, err
	}
	created := make([]string, 0)
	if homeCreated {
		created = append(created, "/")
	}
	parentLogical := normalized
	if !includeLeaf {
		parentLogical = filepath.ToSlash(filepath.Dir(filepath.FromSlash(normalized)))
	}
	segments := strings.Split(strings.TrimPrefix(parentLogical, "/"), "/")
	current := home
	logical := ""
	for index, segment := range segments {
		if segment == "" || segment == "." {
			continue
		}
		current = filepath.Join(current, segment)
		logical += "/" + segment
		info, statErr := os.Stat(current)
		if statErr == nil {
			if !info.IsDir() {
				if includeLeaf && index == len(segments)-1 {
					return created, newError("CONFLICT", "path already exists and is not a directory", nil)
				}
				return created, newError("NOT_A_DIRECTORY", "path parent is not a directory", nil)
			}
			continue
		}
		if errors.Is(statErr, syscall.ELOOP) {
			return created, newError("SYMLINK_LOOP", "path contains a symbolic link loop", statErr)
		}
		if !os.IsNotExist(statErr) {
			return created, newError("INTERNAL_ERROR", "cannot inspect path parent", statErr)
		}
		if linkInfo, linkErr := os.Lstat(current); linkErr == nil && linkInfo.Mode()&os.ModeSymlink != 0 {
			return created, newError("DAMAGED_SYMLINK", "path contains a damaged symbolic link", statErr)
		}
		mode := s.defaultDirMode()
		if !anonymous {
			if policy, ok := s.policyFor(logical); ok {
				mode = s.policyDirMode(policy)
			}
		}
		if err := os.Mkdir(current, mode); err != nil {
			return created, newError("INTERNAL_ERROR", "cannot create path parent", err)
		}
		if !anonymous {
			if policy, ok := s.policyFor(logical); ok {
				if err := applyPolicy(current, policy, true); err != nil {
					return created, newError("INTERNAL_ERROR", "cannot apply directory policy", err)
				}
			}
		}
		created = append(created, logical)
	}
	return created, nil
}

func (s *Space) ApplyFilePolicy(path, normalized string, anonymous bool) error {
	mode := s.defaultFileMode()
	if !anonymous {
		if policy, ok := s.policyFor(normalized); ok {
			if parsed, err := parseMode(policy.Mode); err == nil && policy.Mode != "" {
				mode = parsed
			}
			if err := os.Chmod(path, mode); err != nil {
				return err
			}
			return applyOwnership(path, policy)
		}
	}
	return os.Chmod(path, mode)
}

func (s *Space) policyFor(normalized string) (config.UserHomeInitDirConfig, bool) {
	policy, ok := s.policies[FirstSegment(normalized)]
	return policy, ok
}

func (s *Space) policyDirMode(policy config.UserHomeInitDirConfig) os.FileMode {
	if policy.Mode == "" {
		return s.defaultDirMode()
	}
	mode, err := parseMode(policy.Mode)
	if err != nil {
		return s.defaultDirMode()
	}
	return mode
}

func (s *Space) defaultFileMode() os.FileMode { return 0o666 &^ s.umask }
func (s *Space) defaultDirMode() os.FileMode  { return 0o777 &^ s.umask }

func parseMode(raw string) (os.FileMode, error) {
	value := strings.TrimPrefix(strings.ToLower(strings.TrimSpace(raw)), "0o")
	value = strings.TrimPrefix(value, "0")
	if value == "" {
		value = "0"
	}
	var parsed uint32
	if _, err := fmt.Sscanf(value, "%o", &parsed); err != nil {
		return 0, err
	}
	return os.FileMode(parsed), nil
}

func applyPolicy(path string, policy config.UserHomeInitDirConfig, directory bool) error {
	if policy.Mode != "" {
		mode, err := parseMode(policy.Mode)
		if err != nil {
			return err
		}
		if err := os.Chmod(path, mode); err != nil {
			return err
		}
	}
	if policy.HasOwnership {
		return applyOwnership(path, policy)
	}
	_ = directory
	return nil
}

func FsyncFile(file *os.File) error { return file.Sync() }

func FsyncDirectory(path string) error {
	directory, err := os.Open(path)
	if err != nil {
		return err
	}
	defer directory.Close()
	return directory.Sync()
}
