//go:build !windows

package filespace

import (
	"os"
	"sync"
	"syscall"

	"qtserver/internal/config"
)

var umaskMu sync.Mutex

func processUmask() os.FileMode {
	umaskMu.Lock()
	defer umaskMu.Unlock()
	value := syscall.Umask(0)
	syscall.Umask(value)
	return os.FileMode(value)
}

func applyOwnership(path string, policy config.UserHomeInitDirConfig) error {
	if !policy.HasOwnership {
		return nil
	}
	return os.Chown(path, policy.UID, policy.GID)
}
