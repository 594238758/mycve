//go:build linux

package filespace

import (
	"errors"
	"os"

	"golang.org/x/sys/unix"
)

func RenameNoReplace(oldPath, newPath string) error {
	err := unix.Renameat2(unix.AT_FDCWD, oldPath, unix.AT_FDCWD, newPath, unix.RENAME_NOREPLACE)
	if errors.Is(err, unix.ENOSYS) || errors.Is(err, unix.EINVAL) || errors.Is(err, unix.EOPNOTSUPP) {
		return newError("ATOMIC_NOREPLACE_UNSUPPORTED", "atomic no-replace rename is unsupported", err)
	}
	if errors.Is(err, unix.EEXIST) {
		return os.ErrExist
	}
	return err
}
