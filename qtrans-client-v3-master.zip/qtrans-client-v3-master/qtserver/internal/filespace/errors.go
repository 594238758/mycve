package filespace

import "fmt"

type Error struct {
	Reason     string
	Message    string
	Path       string
	FailedPath string
	Partial    bool
	Err        error
}

func (e *Error) Error() string {
	if e == nil {
		return ""
	}
	if e.Message != "" {
		return e.Message
	}
	if e.Err != nil {
		return e.Err.Error()
	}
	return fmt.Sprintf("file space error: %s", e.Reason)
}

func (e *Error) Unwrap() error { return e.Err }

func newError(reason, message string, err error) *Error {
	return &Error{Reason: reason, Message: message, Err: err}
}
