package version

import "fmt"

var (
	Version   = "dev"
	BuildTime = "unknown"
	MachineID = "unknown"
)

func Text() string {
	return fmt.Sprintf("BuildTime: %s\nVersion: %s\nMachine ID: %s\n", BuildTime, Version, MachineID)
}
