package misc

const (
	QtserverRoutePrefix          = "/qtserver/"
	QtserverAPIPrefix            = "/qtserver/v1"
	OAuthTokenRoute              = QtserverAPIPrefix + "/oauth2/token"
	InternalDownloadRoutePrefix  = "/qtserver/internal-download"
	DownloadContentRoute         = QtserverAPIPrefix + "/d/down"
	IdentityUserInfoEndpointPath = "/userinfo"
	OAuthTokenEndpointPath       = "/oauth2/token"
)
