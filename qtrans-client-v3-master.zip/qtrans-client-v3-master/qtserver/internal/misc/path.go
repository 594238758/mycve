package misc

import (
	"errors"
	"net/url"
	"path"
	"path/filepath"
	"strings"
)

var ErrInvalidObjectKey = errors.New("invalid object_key")
var ErrInvalidOwner = errors.New("invalid owner")

func NormalizeObjectKey(objectKey string) (string, error) {
	trimmed := strings.TrimSpace(strings.ReplaceAll(objectKey, "\\", "/"))
	trimmed = strings.TrimPrefix(trimmed, "/")
	if trimmed == "" || strings.Contains(trimmed, "\x00") {
		return "", ErrInvalidObjectKey
	}
	cleaned := path.Clean(trimmed)
	if cleaned == "." || cleaned == ".." || strings.HasPrefix(cleaned, "../") || strings.Contains(cleaned, "/../") {
		return "", ErrInvalidObjectKey
	}
	if strings.HasPrefix(objectKey, "/") {
		return "", ErrInvalidObjectKey
	}
	return cleaned, nil
}

func NormalizeOwner(owner string) (string, error) {
	value := strings.ToLower(strings.TrimSpace(owner))
	if value == "" || strings.ContainsAny(value, `/\\`) || value == "." || value == ".." {
		return "", ErrInvalidOwner
	}
	return value, nil
}

func ResolveObjectPath(root, objectKey string) (string, error) {
	normalized, err := NormalizeObjectKey(objectKey)
	if err != nil {
		return "", err
	}
	base := filepath.Clean(root)
	full := filepath.Join(base, filepath.FromSlash(normalized))
	rel, err := filepath.Rel(base, full)
	if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		return "", ErrInvalidObjectKey
	}
	return full, nil
}

func ResolveUserObjectPath(root, owner, objectKey string) (string, error) {
	normalizedOwner, err := NormalizeOwner(owner)
	if err != nil {
		return "", err
	}
	return ResolveObjectPath(filepath.Join(root, normalizedOwner), objectKey)
}

func EscapeObjectKeyForURL(objectKey string) (string, error) {
	normalized, err := NormalizeObjectKey(objectKey)
	if err != nil {
		return "", err
	}
	parts := strings.Split(normalized, "/")
	for i, part := range parts {
		parts[i] = url.PathEscape(part)
	}
	return strings.Join(parts, "/"), nil
}

func BuildInternalDownloadRedirect(owner, objectKey string) (string, error) {
	escapedObjectKey, err := EscapeObjectKeyForURL(objectKey)
	if err != nil {
		return "", err
	}
	normalizedOwner, err := NormalizeOwner(owner)
	if err != nil {
		return "", err
	}
	return InternalDownloadRoutePrefix + "/" + url.PathEscape(normalizedOwner) + "/" + escapedObjectKey, nil
}
