package handlers

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"

	"qtserver/internal/models"

	"github.com/google/uuid"
)

const (
	introspectionClientID        = "qtserver"
	introspectionClientSecret    = "qtserver-introspection"
	introspectionResponseMaxSize = 1 << 20
)

type introspectionPayload struct {
	Active *bool           `json:"active"`
	Sub    *string         `json:"sub,omitempty"`
	Email  json.RawMessage `json:"email,omitempty"`
}

func (c *introspectionIdentityClient) Health(ctx context.Context) error {
	if c == nil || c.httpClient == nil || strings.TrimSpace(c.endpoint) == "" {
		return newIdentityResolveError(ErrIdentityUnavailable, "", "introspection_health_config", 0, "", false, false, nil)
	}
	probeToken, err := uuid.NewRandom()
	if err != nil {
		return newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_health_probe_token", 0, "", false, false, err)
	}
	_, err = c.introspect(ctx, probeToken.String())
	return err
}

func (c *introspectionIdentityClient) Resolve(ctx context.Context, token string) (*Principal, error) {
	if token == "" {
		return nil, ErrInvalidToken
	}
	payload, err := c.introspect(ctx, token)
	if err != nil {
		return nil, err
	}
	if payload.Active == nil {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_missing_active", http.StatusOK, "", false, false, nil)
	}
	if !*payload.Active {
		return nil, ErrInvalidToken
	}
	if payload.Sub == nil || *payload.Sub == "" {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_missing_sub", http.StatusOK, "", false, false, nil)
	}
	return normalizeResolvedPrincipal(&Principal{
		ID:    *payload.Sub,
		Email: resolveIdentityEmail(payload.Email),
		Type:  models.PrincipalUser,
	})
}

func (c *introspectionIdentityClient) introspect(ctx context.Context, token string) (*introspectionPayload, error) {
	form := url.Values{}
	form.Set("token", token)
	form.Set("token_type_hint", "access_token")
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, c.endpoint, strings.NewReader(form.Encode()))
	if err != nil {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_new_request", 0, "", false, false, err)
	}
	request.Header.Set("Accept", "application/json")
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	request.SetBasicAuth(introspectionClientID, introspectionClientSecret)
	response, err := c.httpClient.Do(request)
	if err != nil {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		return nil, newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_http_do", 0, "", false, isIdentityTimeout(err), err)
	}
	defer response.Body.Close()
	body, err := io.ReadAll(io.LimitReader(response.Body, introspectionResponseMaxSize+1))
	if err != nil {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		return nil, newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_read_response", response.StatusCode, "", false, isIdentityTimeout(err), err)
	}
	if len(body) > introspectionResponseMaxSize {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_response_too_large", response.StatusCode, "", false, false, nil)
	}
	if response.StatusCode != http.StatusOK {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_http_status", response.StatusCode, "", false, false, nil)
	}
	var payload introspectionPayload
	decoder := json.NewDecoder(bytes.NewReader(body))
	if err := decoder.Decode(&payload); err != nil {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_decode_response", response.StatusCode, "", false, false, err)
	}
	var extra any
	if err := decoder.Decode(&extra); !errors.Is(err, io.EOF) {
		if err == nil {
			err = fmt.Errorf("multiple JSON values")
		}
		return nil, newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_decode_response", response.StatusCode, "", false, false, err)
	}
	if payload.Active == nil {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, c.endpoint, "introspection_missing_active", response.StatusCode, "", false, false, nil)
	}
	return &payload, nil
}
