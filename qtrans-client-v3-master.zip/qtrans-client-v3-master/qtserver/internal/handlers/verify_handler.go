package handlers

import (
	"io"
	"net/http"
	"os"
	"strings"

	"qtserver/internal/businessevents"
	"qtserver/internal/filehash"
	"qtserver/internal/models"

	"github.com/gin-gonic/gin"
)

func VerifyHandler(c *gin.Context) {
	principal, err := authenticateReadPrincipal(c.Request.Context(), c.GetHeader("Authorization"))
	if err != nil {
		handleIdentityError(c, getLogger(c), err)
		return
	}
	var request models.VerifyRequest
	if err := decodeStrictJSON(c, &request, false); err != nil {
		respondHTTPError(c, err)
		return
	}
	taskID, ok := requireTaskID(c, request.TaskID)
	if !ok {
		return
	}
	normalized, physical, err := deps.FileSpace.Resolve(principal.ID, request.ObjectKey)
	if err != nil || normalized == "/" {
		BadRequest(c, "INVALID_PATH", "invalid object_key")
		return
	}
	file, err := os.Open(physical)
	if err != nil {
		if os.IsNotExist(err) {
			NotFound(c, ReasonNotFound, "file not found")
		} else {
			InternalServerError(c, ReasonInternalError, "cannot open file")
		}
		return
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot inspect file")
		return
	}
	if !info.Mode().IsRegular() {
		writeError(c, http.StatusUnprocessableEntity, "UNSUPPORTED_FILE_TYPE", "path is not a regular file")
		return
	}

	verifyType := request.VerifyType
	if verifyType == "" {
		verifyType = models.VerifyTypeFile
	}
	switch verifyType {
	case models.VerifyTypeFile:
		if strings.TrimSpace(request.FileHash) == "" {
			BadRequest(c, ReasonInvalidRequest, "file_hash is required")
			return
		}
	case models.VerifyTypeChunk:
		if request.ChunkIndex == nil || *request.ChunkIndex < 0 || request.ChunkSize <= 0 || request.ChunkSize > filehash.ChunkSize || strings.TrimSpace(request.ChunkHash) == "" {
			BadRequest(c, ReasonInvalidRequest, "chunk verify requires a valid chunk_index, chunk_size and chunk_hash")
			return
		}
		if info.Size() <= 0 || int64(*request.ChunkIndex) > (info.Size()-1)/request.ChunkSize {
			BadRequest(c, ReasonInvalidRequest, "chunk_index out of range")
			return
		}
	default:
		BadRequest(c, ReasonInvalidRequest, "invalid verify_type")
		return
	}
	fileKey := businessevents.FileKey(taskID, normalized, principal.ID, businessevents.ActionDownload)
	metadata, present, err := parseClientLogMetadata(c)
	if err != nil {
		BadRequest(c, ReasonInvalidRequest, err.Error())
		return
	}
	if present > 0 {
		registered, eventErr := fileRegisteredEvent(c, taskID, businessevents.ActionDownload, normalized, info.Size(), principal, metadata)
		if eventErr != nil {
			InternalServerError(c, ReasonInternalError, "cannot create file registration event")
			return
		}
		if !requireBusinessEvent(c, registered) {
			return
		}
	}

	switch verifyType {
	case models.VerifyTypeFile:
		result, err := deps.Hashes.Lookup(c.Request.Context(), principal.ID, normalized, physical)
		if err != nil {
			InternalServerError(c, ReasonInternalError, "cannot query file hash")
			return
		}
		if result.Pending {
			c.Header("Retry-After", "5")
			writeError(c, http.StatusAccepted, "HASH_PENDING", "file hash is pending")
			return
		}
		if result.Unavailable {
			writeError(c, http.StatusServiceUnavailable, "HASH_UNAVAILABLE", "file hash is temporarily unavailable")
			return
		}
		matched := strings.EqualFold(request.FileHash, result.Hash)
		verificationResult := businessevents.VerificationMismatched
		if matched {
			verificationResult = businessevents.VerificationMatched
		}
		if !emitDownloadVerify(c, taskID, fileKey, businessevents.VerificationScopeFile, nil, verificationResult, matched) {
			return
		}
		c.JSON(http.StatusOK, models.VerifyResponse{
			Code: http.StatusOK, Message: "file hash available", TaskID: request.TaskID,
			ObjectKey: normalized, VerifyType: models.VerifyTypeFile,
			ExpectedHash: request.FileHash, CalculatedHash: result.Hash,
			HashAlgorithm: result.Algorithm,
			Match:         matched,
		})
	case models.VerifyTypeChunk:
		offset := int64(*request.ChunkIndex) * request.ChunkSize
		length := min(request.ChunkSize, info.Size()-offset)
		hash, err := filehash.ChunkReader(io.NewSectionReader(file, offset, length))
		if err != nil {
			if !emitDownloadVerify(c, taskID, fileKey, businessevents.VerificationScopeChunk, request.ChunkIndex, businessevents.VerificationFailed, false) {
				return
			}
			InternalServerError(c, ReasonInternalError, "cannot calculate chunk hash")
			return
		}
		matched := strings.EqualFold(request.ChunkHash, hash)
		verificationResult := businessevents.VerificationMismatched
		if matched {
			verificationResult = businessevents.VerificationMatched
		}
		if !emitDownloadVerify(c, taskID, fileKey, businessevents.VerificationScopeChunk, request.ChunkIndex, verificationResult, false) {
			return
		}
		c.JSON(http.StatusOK, models.VerifyResponse{
			Code: http.StatusOK, Message: "chunk hash available", TaskID: request.TaskID,
			ObjectKey: normalized, VerifyType: models.VerifyTypeChunk, ChunkIndex: request.ChunkIndex,
			ExpectedHash: request.ChunkHash, CalculatedHash: hash,
			HashAlgorithm: filehash.ChunkAlgorithm,
			Match:         matched,
		})
	}
}

func emitDownloadVerify(c *gin.Context, taskID, fileKey string, scope businessevents.VerificationScope, chunkIndex *int, result businessevents.VerificationResult, sync bool) bool {
	event, err := newBusinessEvent(
		businessevents.EventDownloadVerifyFinished,
		businessevents.TaskCorrelation{TaskID: taskID, TaskPID: requestTaskPIDForLog(c), EnterpriseID: requestEnterpriseIDForLog(c)},
		fileKey,
		businessevents.DownloadVerifyFinishedPayload{
			VerificationScope: scope, ChunkIndex: chunkIndex, VerificationResult: result,
		},
	)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot construct verify event")
		return false
	}
	if sync {
		return requireBusinessEvent(c, event)
	}
	appendObservedBusinessEvent(c, event)
	return true
}
