package handlers

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"strings"
	"time"

	"qtserver/internal/config"
	"qtserver/internal/misc"
	"qtserver/internal/models"
	"qtserver/internal/store"

	"golang.org/x/sync/singleflight"
)

var ErrIdentityUnavailable = errors.New("identity source unavailable")
var ErrInvalidToken = errors.New("invalid token")
var errIdentityCacheUnavailable = errors.New("identity cache unavailable")

const defaultIdentityUserInfoCacheTTLSeconds = 10
const identityResponseBodyLogLimit = 4096

var identityRetryAttempts = 5
var identityRetryInterval = 5 * time.Second

type Principal struct {
	ID    string
	Email string
	Type  models.PrincipalType
}

type IdentityClient interface {
	Health(context.Context) error
	Resolve(context.Context, string) (*Principal, error)
}

type IdentityCache interface {
	GetIdentityUser(ctx context.Context, tokenHash string) (models.IdentityUser, error)
	SetIdentityUser(ctx context.Context, tokenHash string, user models.IdentityUser, ttl time.Duration) error
}

type fakeIdentityClient struct {
	tokens map[string]string
}

type authIdentityClient struct {
	authURL    string
	httpClient *http.Client
	cache      IdentityCache
	cacheTTL   time.Duration
	inflight   singleflight.Group
}

type introspectionIdentityClient struct {
	endpoint   string
	httpClient *http.Client
}

type offIdentityClient struct{}

type httpIdentityResponse struct {
	Code             int             `json:"code"`
	Sub              string          `json:"sub"`
	ID               string          `json:"id"`
	Email            json.RawMessage `json:"email"`
	Error            string          `json:"error"`
	ErrorDescription string          `json:"error_description"`
	Data             struct {
		ID    string          `json:"id"`
		Email json.RawMessage `json:"email"`
	} `json:"data"`
}

type identityResolveError struct {
	kind                  error
	authURL               string
	stage                 string
	attempt               int
	statusCode            int
	responseBody          string
	responseBodyTruncated bool
	timeout               bool
	cause                 error
}

func (e *identityResolveError) Error() string {
	if e == nil {
		return ""
	}
	parts := make([]string, 0, 6)
	if e.kind != nil {
		parts = append(parts, e.kind.Error())
	} else {
		parts = append(parts, "identity failure")
	}
	if e.authURL != "" {
		parts = append(parts, fmt.Sprintf("auth_url=%s", e.authURL))
	}
	if e.stage != "" {
		parts = append(parts, fmt.Sprintf("stage=%s", e.stage))
	}
	if e.attempt > 0 {
		parts = append(parts, fmt.Sprintf("attempt=%d", e.attempt))
	}
	if e.statusCode > 0 {
		parts = append(parts, fmt.Sprintf("status=%d", e.statusCode))
	}
	if e.timeout {
		parts = append(parts, "timeout=true")
	}
	if e.cause != nil {
		parts = append(parts, fmt.Sprintf("cause=%v", e.cause))
	}
	return strings.Join(parts, " ")
}

func (e *identityResolveError) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.kind
}

func (e *identityResolveError) logAttrs() []any {
	if e == nil {
		return nil
	}
	attrs := make([]any, 0, 14)
	if e.authURL != "" {
		attrs = append(attrs, "auth_url", e.authURL)
	}
	if e.stage != "" {
		attrs = append(attrs, "auth_stage", e.stage)
	}
	if e.attempt > 0 {
		attrs = append(attrs, "auth_attempt", e.attempt)
	}
	if e.statusCode > 0 {
		attrs = append(attrs, "auth_status_code", e.statusCode)
	}
	if e.timeout {
		attrs = append(attrs, "auth_timeout", true)
	}
	if e.responseBody != "" {
		attrs = append(attrs, "auth_response_body", e.responseBody)
	}
	if e.responseBodyTruncated {
		attrs = append(attrs, "auth_response_body_truncated", true)
	}
	if e.cause != nil {
		attrs = append(attrs, "auth_cause", e.cause)
	}
	return attrs
}

func NewIdentityClient(cfg config.IdentityConfig) IdentityClient {
	return NewIdentityClientWithCache(cfg, nil)
}

func NewIdentityClientWithCache(cfg config.IdentityConfig, cache IdentityCache) IdentityClient {
	switch strings.TrimSpace(cfg.Mode) {
	case "auth":
		return &authIdentityClient{
			authURL:  strings.TrimRight(cfg.AuthBaseURL, "/") + misc.IdentityUserInfoEndpointPath,
			cache:    cache,
			cacheTTL: identityUserInfoCacheTTL(cfg),
			httpClient: &http.Client{
				Timeout: time.Duration(cfg.TimeoutSeconds) * time.Second,
				CheckRedirect: func(req *http.Request, via []*http.Request) error {
					return http.ErrUseLastResponse
				},
			},
		}
	case "off":
		return &offIdentityClient{}
	case "oauth2-introspection":
		return &introspectionIdentityClient{
			endpoint: cfg.IntrospectionEndpoint,
			httpClient: &http.Client{
				Timeout: time.Duration(cfg.TimeoutSeconds) * time.Second,
				CheckRedirect: func(req *http.Request, via []*http.Request) error {
					return http.ErrUseLastResponse
				},
			},
		}
	default:
		copied := make(map[string]string, len(cfg.FakeTokens))
		for token, user := range cfg.FakeTokens {
			copied[token] = user
		}
		return &fakeIdentityClient{tokens: copied}
	}
}

func identityUserInfoCacheTTL(cfg config.IdentityConfig) time.Duration {
	ttlSeconds := cfg.UserInfoCacheTTLSeconds
	if ttlSeconds == 0 {
		ttlSeconds = defaultIdentityUserInfoCacheTTLSeconds
	}
	return time.Duration(ttlSeconds) * time.Second
}

func (c *fakeIdentityClient) Health(context.Context) error {
	return nil
}

func (c *fakeIdentityClient) Resolve(ctx context.Context, token string) (*Principal, error) {
	cleanToken := strings.TrimSpace(token)
	if cleanToken == "" {
		return nil, ErrInvalidToken
	}
	userID, ok := c.tokens[cleanToken]
	if !ok {
		return nil, ErrInvalidToken
	}
	return normalizeResolvedPrincipal(&Principal{ID: userID, Type: models.PrincipalUser})
}

func (c *authIdentityClient) Health(ctx context.Context) error {
	if c == nil || c.httpClient == nil || strings.TrimSpace(c.authURL) == "" {
		return newIdentityResolveError(ErrIdentityUnavailable, "", "health_config", 0, "", false, false, nil)
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.authURL, nil)
	if err != nil {
		return newIdentityResolveError(ErrIdentityUnavailable, c.authURL, "health_new_request", 0, "", false, false, err)
	}
	req.Header.Set("Accept", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return newIdentityResolveError(ErrIdentityUnavailable, c.authURL, "health_http_do", 0, "", false, isIdentityTimeout(err), err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return newIdentityResolveError(ErrIdentityUnavailable, c.authURL, "health_read_response_body", resp.StatusCode, "", false, isIdentityTimeout(err), err)
	}
	responseBody, responseBodyTruncated := summarizeIdentityResponseBody(body)
	if resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden {
		return nil
	}

	if resp.StatusCode == http.StatusOK {
		var payload httpIdentityResponse
		if err := json.Unmarshal(body, &payload); err == nil && isInvalidTokenPayload(payload) {
			return nil
		}
	}
	return newIdentityResolveError(
		ErrIdentityUnavailable,
		c.authURL,
		"health_unexpected_response",
		resp.StatusCode,
		responseBody,
		responseBodyTruncated,
		false,
		nil,
	)
}

func (c *authIdentityClient) Resolve(ctx context.Context, token string) (*Principal, error) {
	cleanToken := strings.TrimSpace(token)
	if cleanToken == "" {
		return nil, ErrInvalidToken
	}
	return c.resolveWithCache(ctx, cleanToken)
}

func (c *authIdentityClient) resolveWithCache(ctx context.Context, token string) (*Principal, error) {
	principal, ok, err := c.resolveFromCache(ctx, token)
	if err != nil {
		return nil, err
	}
	if ok {
		return principal, nil
	}
	return c.resolveSharedAfterCacheMiss(ctx, token)
}

func (c *authIdentityClient) resolveSharedAfterCacheMiss(ctx context.Context, token string) (*Principal, error) {
	resultCh := c.inflight.DoChan(identityTokenCacheKey(token), func() (any, error) {
		return c.resolveAfterCacheMiss(context.WithoutCancel(ctx), token)
	})
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case result := <-resultCh:
		if result.Err != nil {
			return nil, result.Err
		}
		principal, ok := result.Val.(*Principal)
		if !ok || principal == nil {
			return nil, ErrIdentityUnavailable
		}
		return principal, nil
	}
}

func (c *authIdentityClient) resolveAfterCacheMiss(ctx context.Context, token string) (*Principal, error) {
	principal, ok, err := c.resolveFromCache(ctx, token)
	if err != nil {
		return nil, err
	}
	if ok {
		return principal, nil
	}
	return c.resolveAndCache(ctx, c.authURL, token)
}

func (c *authIdentityClient) resolveFromCache(ctx context.Context, token string) (*Principal, bool, error) {
	if c == nil || c.cache == nil || c.cacheTTL <= 0 {
		return nil, false, nil
	}
	user, err := c.cache.GetIdentityUser(ctx, identityTokenCacheKey(token))
	if err != nil {
		if errors.Is(err, store.ErrNotFound) {
			return nil, false, nil
		}
		return nil, false, fmt.Errorf("%w: %v", errIdentityCacheUnavailable, err)
	}
	principal, err := normalizeResolvedPrincipal(&Principal{ID: user.ID, Email: user.Email, Type: models.PrincipalUser})
	if err != nil {
		return nil, false, err
	}
	return principal, true, nil
}

func (c *authIdentityClient) resolveAndCache(ctx context.Context, authURL, token string) (*Principal, error) {
	principal, err := c.resolveAgainst(ctx, authURL, token)
	if err != nil {
		return nil, err
	}
	if err := c.cacheResolvedPrincipal(ctx, token, principal); err != nil {
		return nil, err
	}
	return principal, nil
}

func (c *authIdentityClient) cacheResolvedPrincipal(ctx context.Context, token string, principal *Principal) error {
	if c == nil || c.cache == nil || c.cacheTTL <= 0 || principal == nil {
		return nil
	}
	user := models.IdentityUser{ID: principal.ID, Email: principal.Email}
	if err := c.cache.SetIdentityUser(ctx, identityTokenCacheKey(token), user, c.cacheTTL); err != nil {
		return fmt.Errorf("%w: %v", errIdentityCacheUnavailable, err)
	}
	return nil
}

func (c *authIdentityClient) resolveAgainst(ctx context.Context, authURL, token string) (*Principal, error) {
	var lastErr error
	for attempt := 0; attempt <= identityRetryAttempts; attempt++ {
		principal, err := c.resolveAgainstOnce(ctx, authURL, token)
		if err == nil {
			return principal, nil
		}
		err = annotateIdentityResolveAttempt(err, attempt+1)
		if errors.Is(err, ErrInvalidToken) {
			return nil, err
		}
		lastErr = err
		if attempt == identityRetryAttempts {
			break
		}
		if err := waitIdentityRetryDelay(ctx, identityRetryInterval); err != nil {
			return nil, err
		}
	}
	if lastErr != nil {
		return nil, lastErr
	}
	return nil, ErrIdentityUnavailable
}

func (c *authIdentityClient) resolveAgainstOnce(ctx context.Context, authURL, token string) (*Principal, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, authURL, nil)
	if err != nil {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, authURL, "new_request", 0, "", false, false, err)
	}
	req.Header.Set("Authorization", "Bearer "+strings.TrimSpace(token))
	req.Header.Set("Accept", "application/json")
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, authURL, "http_do", 0, "", false, isIdentityTimeout(err), err)
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, authURL, "read_response_body", resp.StatusCode, "", false, isIdentityTimeout(err), err)
	}
	responseBody, responseBodyTruncated := summarizeIdentityResponseBody(body)
	if isInvalidTokenHTTPResponse(resp) {
		return nil, newIdentityResolveError(ErrInvalidToken, authURL, "http_status", resp.StatusCode, responseBody, responseBodyTruncated, false, nil)
	}
	if resp.StatusCode != http.StatusOK {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, authURL, "http_status", resp.StatusCode, responseBody, responseBodyTruncated, false, nil)
	}
	var payload httpIdentityResponse
	if err := json.Unmarshal(body, &payload); err != nil {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, authURL, "decode_response_body", resp.StatusCode, responseBody, responseBodyTruncated, false, err)
	}
	if isInvalidTokenPayload(payload) {
		return nil, newIdentityResolveError(ErrInvalidToken, authURL, "payload_invalid_token", resp.StatusCode, responseBody, responseBodyTruncated, false, nil)
	}
	if !isSuccessfulIdentityPayload(payload) {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, authURL, "payload_unsuccessful", resp.StatusCode, responseBody, responseBodyTruncated, false, nil)
	}
	userID := resolveIdentityUserID(payload)
	if userID == "" {
		return nil, newIdentityResolveError(ErrIdentityUnavailable, authURL, "payload_missing_user_id", resp.StatusCode, responseBody, responseBodyTruncated, false, nil)
	}
	return normalizeResolvedPrincipal(&Principal{
		ID:    userID,
		Email: resolveIdentityEmail(payload.Email, payload.Data.Email),
		Type:  models.PrincipalUser,
	})
}

func waitIdentityRetryDelay(ctx context.Context, delay time.Duration) error {
	if delay <= 0 {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
			return nil
		}
	}
	timer := time.NewTimer(delay)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-timer.C:
		return nil
	}
}

func isInvalidTokenHTTPResponse(resp *http.Response) bool {
	if resp == nil {
		return false
	}
	switch resp.StatusCode {
	case http.StatusUnauthorized, http.StatusForbidden:
		return true
	}
	if resp.StatusCode >= http.StatusMultipleChoices && resp.StatusCode < http.StatusBadRequest {
		return isLikelyLoginRedirect(resp.Header.Get("Location"))
	}
	return false
}

func isLikelyLoginRedirect(location string) bool {
	normalized := strings.ToLower(strings.TrimSpace(location))
	if normalized == "" {
		return false
	}
	return strings.Contains(normalized, "/login") || strings.Contains(normalized, "/sso/") || strings.Contains(normalized, "cas")
}

func isInvalidTokenPayload(payload httpIdentityResponse) bool {
	switch payload.Code {
	case http.StatusUnauthorized, http.StatusForbidden:
		return true
	}
	return strings.EqualFold(strings.TrimSpace(payload.Error), "invalid_token")
}

func isSuccessfulIdentityPayload(payload httpIdentityResponse) bool {
	switch payload.Code {
	case 0, http.StatusOK:
		return true
	default:
		return false
	}
}

func resolveIdentityUserID(payload httpIdentityResponse) string {
	for _, candidate := range []string{payload.Sub, payload.Data.ID, payload.ID} {
		if candidate != "" {
			return candidate
		}
	}
	return ""
}

// Email is optional log metadata; malformed values must not fail authentication.
func resolveIdentityEmail(candidates ...json.RawMessage) string {
	for _, candidate := range candidates {
		var email string
		if err := json.Unmarshal(candidate, &email); err != nil {
			continue
		}
		if email = strings.TrimSpace(email); email != "" {
			return email
		}
	}
	return ""
}

func (c *offIdentityClient) Health(context.Context) error {
	return nil
}

func (c *offIdentityClient) Resolve(context.Context, string) (*Principal, error) {
	return anonymousPrincipal(), nil
}

func extractBearerToken(value string) string {
	trimmed := strings.TrimSpace(value)
	if strings.HasPrefix(strings.ToLower(trimmed), "bearer ") {
		return strings.TrimSpace(trimmed[7:])
	}
	return trimmed
}

func normalizeResolvedPrincipal(principal *Principal) (*Principal, error) {
	if principal == nil {
		return nil, ErrIdentityUnavailable
	}
	clone := *principal
	return &clone, nil
}

func identityTokenCacheKey(token string) string {
	sum := sha256.Sum256([]byte(strings.TrimSpace(token)))
	return hex.EncodeToString(sum[:])
}

func newIdentityResolveError(kind error, authURL, stage string, statusCode int, responseBody string, responseBodyTruncated bool, timeout bool, cause error) error {
	return &identityResolveError{
		kind:                  kind,
		authURL:               strings.TrimSpace(authURL),
		stage:                 strings.TrimSpace(stage),
		statusCode:            statusCode,
		responseBody:          responseBody,
		responseBodyTruncated: responseBodyTruncated,
		timeout:               timeout,
		cause:                 cause,
	}
}

func annotateIdentityResolveAttempt(err error, attempt int) error {
	if attempt <= 0 {
		return err
	}
	var detailed *identityResolveError
	if !errors.As(err, &detailed) || detailed == nil {
		return err
	}
	clone := *detailed
	clone.attempt = attempt
	return &clone
}

func summarizeIdentityResponseBody(body []byte) (string, bool) {
	trimmed := strings.TrimSpace(string(body))
	if trimmed == "" {
		return "", false
	}
	runes := []rune(trimmed)
	if len(runes) <= identityResponseBodyLogLimit {
		return trimmed, false
	}
	return string(runes[:identityResponseBodyLogLimit]), true
}

func isIdentityTimeout(err error) bool {
	if err == nil {
		return false
	}
	if errors.Is(err, context.DeadlineExceeded) {
		return true
	}
	var netErr net.Error
	return errors.As(err, &netErr) && netErr.Timeout()
}
