package handlers

import (
	"archive/tar"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"

	"qtserver/internal/businessevents"
	"qtserver/internal/models"

	"github.com/gin-gonic/gin"
)

const smallHashAlgorithm = "layered_xxh3_128_v1"

func DownloadSmallHandler(c *gin.Context) {
	logger := getLogger(c)
	ctx := c.Request.Context()

	principal, err := authenticateReadPrincipal(ctx, c.GetHeader("Authorization"))
	if err != nil {
		handleIdentityError(c, logger, err)
		return
	}
	var req models.DownloadSmallRequest
	if err := decodeStrictJSON(c, &req, false); err != nil {
		respondHTTPError(c, err)
		return
	}
	if len(req.Files) == 0 {
		BadRequest(c, ReasonInvalidRequest, "files must contain at least one file")
		return
	}

	taskID, ok := requireTaskID(c, req.TaskID)
	if !ok {
		return
	}
	logTaskID := requestTaskIDForLog(c, taskID)
	metadata, ok := requireClientLogMetadata(c)
	if !ok {
		return
	}

	preparedFiles, totalBytes, err := prepareSmallFiles(ctx, logger, principal, req.Files)
	if err != nil {
		switch {
		case errors.Is(err, errEmptySmallSelection):
			BadRequest(c, ReasonInvalidRequest, "files must contain at least one file")
		case errors.Is(err, errDownloadTargetNotDirectory), errors.Is(err, errUnsupportedDownloadTarget):
			BadRequest(c, ReasonInvalidRequest, "small only supports regular files")
		case isTransferFileTooLarge(err):
			FileTooLarge(c, transferFileSize(err), transferMaxFileBytes())
		case errors.Is(err, errSmallDownloadLimitExceeded):
			BadRequest(c, ReasonInvalidRequest, "small selection exceeds configured limits")
		case os.IsNotExist(err):
			NotFound(c, ReasonNotFound, "selected file not found")
		default:
			logger.Error("prepare small download failed", "taskid", logTaskID, "error", err)
			InternalServerError(c, ReasonInternalError, "failed to prepare small download")
		}
		return
	}
	defer closePreparedSmallFiles(preparedFiles)
	type smallOperation struct {
		file       preparedSmallFile
		logContext fileLogContext
	}
	operations := make([]smallOperation, 0, len(preparedFiles))
	for _, file := range preparedFiles {
		logContext, eventErr := newFileLogContext(c, taskID, businessevents.ActionDownload, file.ObjectKey, file.Size, principal, metadata)
		if eventErr != nil {
			InternalServerError(c, ReasonInternalError, "cannot construct small file log context")
			return
		}
		operations = append(operations, smallOperation{file: file, logContext: logContext})
	}

	session := models.DownloadSmallSession{
		Version:            1,
		TaskID:             taskID,
		UserID:             principal.ID,
		FileCount:          len(preparedFiles),
		TotalUnpackedBytes: totalBytes,
		HashAlgorithm:      smallHashAlgorithm,
	}
	manifestFiles := make([]models.DownloadSmallManifestEntry, 0, len(preparedFiles))
	for _, file := range preparedFiles {
		manifestFiles = append(manifestFiles, models.DownloadSmallManifestEntry{
			ObjectKey:   file.ObjectKey,
			ArchivePath: file.ArchivePath,
			Size:        file.Size,
			Hash:        file.Hash,
		})
	}
	manifest := models.DownloadSmallManifest{
		Version:       1,
		TaskID:        taskID,
		UserID:        principal.ID,
		HashAlgorithm: smallHashAlgorithm,
		Files:         manifestFiles,
	}

	c.Header("Content-Type", "application/x-tar")
	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s.tar\"", taskID))
	c.Header("Cache-Control", "no-store")
	c.Header("X-Qtrans-TaskID", taskID)
	c.Header("X-Qtrans-UserID", principal.ID)
	c.Header("X-Qtrans-File-Count", fmt.Sprintf("%d", len(preparedFiles)))
	c.Header("X-Qtrans-Total-Bytes", fmt.Sprintf("%d", totalBytes))
	c.Status(http.StatusOK)

	streamErr := error(nil)
	tw := tar.NewWriter(c.Writer)
	defer func() {
		if err := tw.Close(); err != nil && streamErr == nil {
			streamErr = err
		}
	}()

	if streamErr = writeSmallJSONEntry(tw, ".qtrans/session.json", session); streamErr != nil {
		logger.Error("write small session failed", "taskid", logTaskID, "error", streamErr)
		return
	}
	if streamErr = writeSmallJSONEntry(tw, ".qtrans/manifest.json", manifest); streamErr != nil {
		logger.Error("write small manifest failed", "taskid", logTaskID, "error", streamErr)
		return
	}

	for _, operation := range operations {
		startedAt := deps.Now().UTC()
		file := operation.file
		openedFile := file.File
		info, err := openedFile.Stat()
		if err != nil {
			streamErr = err
			logger.Error("stat small payload failed", "taskid", logTaskID, "object_key", file.ObjectKey, "error", err)
			return
		}
		if !info.Mode().IsRegular() || info.Size() != file.Size || !info.ModTime().Equal(file.ModTime) {
			streamErr = fmt.Errorf("payload drift detected for %s", file.ObjectKey)
			logger.Error("small payload drift detected", "taskid", logTaskID, "object_key", file.ObjectKey)
			return
		}

		var actualBytes int64
		actualBytes, streamErr = writeSmallPayloadEntry(tw, file.ArchivePath, openedFile, info)
		if streamErr == nil && actualBytes == file.Size {
			streamErr = tw.Flush()
		}
		if streamErr != nil || actualBytes != file.Size {
			logger.Error("write small payload failed", "taskid", logTaskID, "object_key", file.ObjectKey, "error", streamErr)
			return
		}
		finished, eventErr := newBusinessEvent(
			businessevents.EventDownloadSmallFileSent, operation.logContext.Correlation, operation.logContext.FileKey,
			operation.logContext.smallFileSentPayload(startedAt),
		)
		if eventErr != nil || !syncObservedBusinessEvent(c, finished) {
			streamErr = businessevents.ErrUnavailable
			return
		}
	}

	logger.Info("small download completed", "taskid", logTaskID, "principal_id", principal.ID, "files", len(preparedFiles), "total_bytes", totalBytes)
}

func writeSmallJSONEntry(tw *tar.Writer, name string, payload any) error {
	data, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	header := &tar.Header{
		Name:    name,
		Mode:    0644,
		Size:    int64(len(data)),
		ModTime: time.Now().UTC(),
	}
	if err := tw.WriteHeader(header); err != nil {
		return err
	}
	_, err = tw.Write(data)
	return err
}

func writeSmallPayloadEntry(tw *tar.Writer, archivePath string, file *os.File, info os.FileInfo) (int64, error) {
	header := &tar.Header{
		Name:    archivePath,
		Mode:    0644,
		Size:    info.Size(),
		ModTime: info.ModTime().UTC(),
	}
	if err := tw.WriteHeader(header); err != nil {
		return 0, err
	}

	written, err := io.Copy(tw, file)
	return written, err
}
