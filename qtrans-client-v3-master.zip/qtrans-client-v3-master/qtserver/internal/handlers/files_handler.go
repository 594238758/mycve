package handlers

import (
	"errors"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"syscall"

	"qtserver/internal/filehash"
	"qtserver/internal/filespace"
	"qtserver/internal/models"

	"github.com/gin-gonic/gin"
)

const maxListEntries = 100000

type fileListEntry struct {
	Name         string   `json:"name"`
	Path         string   `json:"path"`
	Type         string   `json:"type"`
	Status       string   `json:"status"`
	TargetType   **string `json:"target_type,omitempty"`
	SpecialType  string   `json:"special_type,omitempty"`
	ReasonCode   string   `json:"reason_code,omitempty"`
	Size         int64    `json:"size,omitempty"`
	LastModified string   `json:"last_modified,omitempty"`
}

func FileListHandler(c *gin.Context) {
	principal, err := authenticateReadPrincipal(c.Request.Context(), c.GetHeader("Authorization"))
	if err != nil {
		handleIdentityError(c, getLogger(c), err)
		return
	}
	normalized, physical, err := deps.FileSpace.Resolve(principal.ID, c.Query("path"))
	if err != nil {
		BadRequest(c, "INVALID_PATH", err.Error())
		return
	}
	if _, err := deps.FileSpace.ExistingHome(principal.ID); err != nil {
		var typed *filespace.Error
		if !errors.As(err, &typed) || typed.Reason != "NOT_FOUND" {
			respondFileSpaceError(c, err)
			return
		}
		if normalized != "/" {
			NotFound(c, ReasonNotFound, "path not found")
			return
		}
		if !listHomeInitializationEnabled(principal, normalized) {
			c.JSON(http.StatusOK, gin.H{"code": http.StatusOK, "path": normalized, "truncated": false, "entries": []fileListEntry{}})
			return
		}
		if !initializeListHome(c, principal.ID) {
			return
		}
	}
	info, err := os.Stat(physical)
	if err != nil {
		respondListTargetError(c, physical, err)
		return
	}
	if !info.IsDir() {
		writeError(c, http.StatusUnprocessableEntity, "NOT_A_DIRECTORY", "path is not a directory")
		return
	}
	directory, err := os.Open(physical)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot read directory")
		return
	}
	defer directory.Close()
	children, readErr := directory.ReadDir(maxListEntries + 1)
	if readErr != nil && !errors.Is(readErr, io.EOF) {
		InternalServerError(c, ReasonInternalError, "cannot read directory")
		return
	}
	truncated := len(children) > maxListEntries
	if truncated {
		children = children[:maxListEntries]
	}
	entries := make([]fileListEntry, 0, len(children))
	for _, child := range children {
		logical := normalized
		if logical == "/" {
			logical = ""
		}
		logical += "/" + child.Name()
		entries = append(entries, inspectListEntry(filepath.Join(physical, child.Name()), logical, child.Name()))
	}
	c.JSON(http.StatusOK, gin.H{"code": http.StatusOK, "path": normalized, "truncated": truncated, "entries": entries})
}

func listHomeInitializationEnabled(principal *Principal, normalized string) bool {
	return normalized == "/" &&
		principal.Type == models.PrincipalUser &&
		deps.Config.Server.WriteEnabled &&
		deps.Config.Server.UserHomeInitOnList
}

func initializeListHome(c *gin.Context, principalID string) bool {
	lock, ok := requireNamespaceLock(c, principalID)
	if !ok {
		return false
	}
	defer lock.release()
	_, _, err := deps.FileSpace.EnsureHome(principalID, false)
	if err != nil {
		respondFileSpaceError(c, err)
		return false
	}
	return true
}

func respondListTargetError(c *gin.Context, physical string, err error) {
	if errors.Is(err, syscall.ELOOP) {
		writeError(c, http.StatusUnprocessableEntity, "SYMLINK_LOOP", "path contains a symbolic link loop")
		return
	}
	if os.IsNotExist(err) {
		if info, lstatErr := os.Lstat(physical); lstatErr == nil && info.Mode()&os.ModeSymlink != 0 {
			writeError(c, http.StatusUnprocessableEntity, "DAMAGED_SYMLINK", "path is a damaged symbolic link")
			return
		}
		NotFound(c, ReasonNotFound, "path not found")
		return
	}
	InternalServerError(c, ReasonInternalError, "cannot inspect path")
}

func inspectListEntry(physical, logical, name string) fileListEntry {
	entry := fileListEntry{Name: name, Path: logical, Status: "normal"}
	info, err := os.Lstat(physical)
	if err != nil {
		entry.Type, entry.Status = "unknown", "unavailable"
		if os.IsNotExist(err) {
			entry.ReasonCode = "ENTRY_CHANGED"
		} else {
			entry.ReasonCode = "ENTRY_UNREADABLE"
		}
		return entry
	}
	entry.LastModified = info.ModTime().UTC().Format("2006-01-02T15:04:05.999999999Z07:00")
	if info.Mode()&os.ModeSymlink != 0 {
		entry.Type = "symlink"
		target, targetErr := os.Stat(physical)
		if targetErr != nil {
			entry.Status = "damaged"
			var noTarget *string
			entry.TargetType = &noTarget
			if errors.Is(targetErr, syscall.ELOOP) {
				entry.ReasonCode = "SYMLINK_LOOP"
			} else {
				entry.ReasonCode = "DAMAGED_SYMLINK"
			}
			return entry
		}
		targetType := classifyMode(target.Mode())
		targetTypeValue := &targetType
		entry.TargetType = &targetTypeValue
		if targetType == "special" {
			entry.Status = "unsupported"
			entry.SpecialType = specialType(target.Mode())
		}
		if targetType == "file" {
			entry.Size = target.Size()
		}
		return entry
	}
	entry.Type = classifyMode(info.Mode())
	if entry.Type == "special" {
		entry.Status = "unsupported"
		entry.SpecialType = specialType(info.Mode())
	} else if entry.Type == "file" {
		entry.Size = info.Size()
	}
	return entry
}

func classifyMode(mode os.FileMode) string {
	if mode.IsRegular() {
		return "file"
	}
	if mode.IsDir() {
		return "directory"
	}
	return "special"
}

func specialType(mode os.FileMode) string {
	switch {
	case mode&os.ModeNamedPipe != 0:
		return "fifo"
	case mode&os.ModeSocket != 0:
		return "socket"
	case mode&os.ModeDevice != 0 && mode&os.ModeCharDevice != 0:
		return "char_device"
	case mode&os.ModeDevice != 0:
		return "block_device"
	default:
		return "other"
	}
}

type mkdirRequest struct {
	Path string `json:"path"`
}

func FileMkdirHandler(c *gin.Context) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	var request mkdirRequest
	if err := decodeStrictJSON(c, &request, false); err != nil {
		respondHTTPError(c, err)
		return
	}
	normalized, _, err := deps.FileSpace.Resolve(principal.ID, request.Path)
	if err != nil || normalized == "/" {
		BadRequest(c, "INVALID_PATH", "mkdir requires a non-root logical path")
		return
	}
	lock, ok := requireNamespaceLock(c, principal.ID)
	if !ok {
		return
	}
	defer lock.release()
	createdPaths, err := deps.FileSpace.EnsureParents(principal.ID, normalized, principal.Type == "anonymous", true)
	if err != nil {
		respondFileSpaceError(c, err)
		return
	}
	if !lock.valid(c.Request.Context()) {
		if len(createdPaths) > 0 {
			writeErrorWithExtras(c, http.StatusInternalServerError, "NAMESPACE_OPERATION_PARTIAL", "namespace lock was lost after creating directories", map[string]any{"partial": true})
		} else {
			Conflict(c, "NAMESPACE_LOCK_LOST", "namespace lock was lost")
		}
		return
	}
	created := len(createdPaths) > 0
	status := http.StatusOK
	if created {
		status = http.StatusCreated
	}
	c.JSON(status, gin.H{"code": status, "path": normalized, "created": created})
}

type moveRequest struct {
	Source      string `json:"source"`
	Destination string `json:"destination"`
}

func FileMoveHandler(c *gin.Context) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	var request moveRequest
	if err := decodeStrictJSON(c, &request, false); err != nil {
		respondHTTPError(c, err)
		return
	}
	source, sourcePath, sourceErr := deps.FileSpace.Resolve(principal.ID, request.Source)
	destination, destinationPath, destinationErr := deps.FileSpace.Resolve(principal.ID, request.Destination)
	if sourceErr != nil || destinationErr != nil || source == "/" || destination == "/" {
		BadRequest(c, "INVALID_PATH", "move requires valid non-root paths")
		return
	}
	if source == destination {
		Conflict(c, ReasonConflict, "source and destination are identical")
		return
	}
	if _, err := deps.FileSpace.ExistingHome(principal.ID); err != nil {
		var typed *filespace.Error
		if errors.As(err, &typed) && typed.Reason == "NOT_FOUND" {
			NotFound(c, ReasonNotFound, "source not found")
		} else {
			respondFileSpaceError(c, err)
		}
		return
	}
	sourceInfo, err := os.Lstat(sourcePath)
	if err != nil {
		if os.IsNotExist(err) {
			NotFound(c, ReasonNotFound, "source not found")
		} else {
			InternalServerError(c, ReasonInternalError, "cannot inspect source")
		}
		return
	}
	if sourceInfo.Mode()&os.ModeSymlink == 0 && !sourceInfo.IsDir() && !sourceInfo.Mode().IsRegular() {
		writeError(c, http.StatusUnprocessableEntity, "UNSUPPORTED_FILE_TYPE", "source type is unsupported")
		return
	}
	if sourceInfo.IsDir() && strings.HasPrefix(destination, source+"/") {
		Conflict(c, "INVALID_MOVE", "cannot move a directory into its descendant")
		return
	}
	parent := filepath.Dir(destinationPath)
	parentInfo, err := os.Stat(parent)
	if err != nil || !parentInfo.IsDir() {
		NotFound(c, ReasonNotFound, "destination parent not found")
		return
	}
	if destinationInfo, destinationErr := os.Lstat(destinationPath); destinationErr == nil {
		if destinationInfo.Mode()&os.ModeSymlink == 0 && !destinationInfo.IsDir() && !destinationInfo.Mode().IsRegular() {
			writeError(c, http.StatusUnprocessableEntity, "UNSUPPORTED_FILE_TYPE", "destination type is unsupported")
			return
		}
	} else if !os.IsNotExist(destinationErr) {
		InternalServerError(c, ReasonInternalError, "cannot inspect destination")
		return
	}
	if err := deps.Hashes.BumpNamespaceGeneration(c.Request.Context(), principal.ID); err != nil {
		InternalServerError(c, ReasonInternalError, "cannot advance hash namespace generation")
		return
	}
	renameErr := os.Rename(sourcePath, destinationPath)
	if renameErr != nil {
		var typed *filespace.Error
		switch {
		case errors.Is(renameErr, syscall.EXDEV):
			InternalServerError(c, "CROSS_DEVICE_MOVE", "cross-device move is unsupported")
		case errors.Is(renameErr, os.ErrExist), errors.Is(renameErr, syscall.EEXIST),
			errors.Is(renameErr, syscall.ENOTEMPTY), errors.Is(renameErr, syscall.EISDIR),
			errors.Is(renameErr, syscall.ENOTDIR):
			Conflict(c, ReasonConflict, "destination cannot be replaced")
		case errors.As(renameErr, &typed):
			InternalServerError(c, typed.Reason, typed.Error())
		default:
			InternalServerError(c, ReasonInternalError, "move failed")
		}
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": http.StatusOK, "source": source, "destination": destination})
}

type deleteRequest struct {
	Path string `json:"path"`
}

func FileDeleteHandler(c *gin.Context) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	var request deleteRequest
	if err := decodeStrictJSON(c, &request, false); err != nil {
		respondHTTPError(c, err)
		return
	}
	normalized, physical, err := deps.FileSpace.Resolve(principal.ID, request.Path)
	if err != nil || normalized == "/" {
		BadRequest(c, "INVALID_PATH", "delete requires a non-root path")
		return
	}
	info, err := os.Lstat(physical)
	if err != nil {
		if os.IsNotExist(err) {
			NotFound(c, ReasonNotFound, "path not found")
		} else {
			InternalServerError(c, ReasonInternalError, "cannot inspect path")
		}
		return
	}
	if info.Mode()&os.ModeSymlink == 0 && !info.IsDir() && !info.Mode().IsRegular() {
		writeError(c, http.StatusUnprocessableEntity, "UNSUPPORTED_FILE_TYPE", "top-level target type is unsupported")
		return
	}
	if err := deps.Hashes.BumpNamespaceGeneration(c.Request.Context(), principal.ID); err != nil {
		InternalServerError(c, ReasonInternalError, "cannot advance hash namespace generation")
		return
	}
	if err := os.Remove(physical); err != nil {
		if os.IsNotExist(err) {
			NotFound(c, ReasonNotFound, "path not found")
			return
		}
		if errors.Is(err, syscall.ENOTEMPTY) || errors.Is(err, syscall.EEXIST) {
			Conflict(c, "DIRECTORY_NOT_EMPTY", "directory is not empty")
			return
		}
		InternalServerError(c, ReasonInternalError, "delete failed")
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": http.StatusOK, "path": normalized})
}

type createRequest struct {
	Path      string `json:"path"`
	Overwrite bool   `json:"overwrite"`
}

func FileCreateHandler(c *gin.Context) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	var request createRequest
	if err := decodeStrictJSON(c, &request, false); err != nil {
		respondHTTPError(c, err)
		return
	}
	normalized, target, err := deps.FileSpace.Resolve(principal.ID, request.Path)
	if err != nil || normalized == "/" {
		BadRequest(c, "INVALID_PATH", "create requires a non-root path")
		return
	}
	lock, ok := requireNamespaceLock(c, principal.ID)
	if !ok {
		return
	}
	defer lock.release()
	targetExisted := false
	if info, statErr := os.Lstat(target); statErr == nil {
		targetExisted = true
		if !info.Mode().IsRegular() {
			writeError(c, http.StatusUnprocessableEntity, "UNSUPPORTED_FILE_TYPE", "target is not a regular file")
			return
		}
		if !request.Overwrite {
			if info.Size() == 0 {
				fp, fpErr := filehash.FingerprintPath(target)
				if fpErr != nil {
					InternalServerError(c, ReasonInternalError, "cannot fingerprint empty file")
					return
				}
				generation, stateErr := deps.Hashes.BeginKnownMutation(c.Request.Context(), principal.ID, normalized, fp)
				if stateErr != nil {
					InternalServerError(c, ReasonInternalError, "cannot prepare empty file hash state")
					return
				}
				emptyHash, _, _ := filehash.LayeredFromChunkHashes(nil, 0)
				if _, stateErr = deps.Hashes.CommitKnown(c.Request.Context(), principal.ID, normalized, generation, fp, emptyHash); stateErr != nil {
					InternalServerError(c, ReasonInternalError, "cannot persist empty file hash")
					return
				}
				c.JSON(http.StatusOK, gin.H{"code": http.StatusOK, "path": normalized, "created": false, "file_hash": emptyHash, "hash_algorithm": filehash.LayeredAlgorithm})
				return
			}
			Conflict(c, ReasonConflict, "target already exists")
			return
		}
	} else if !os.IsNotExist(statErr) {
		InternalServerError(c, ReasonInternalError, "cannot inspect target")
		return
	}
	createdPaths, err := deps.FileSpace.EnsureParents(principal.ID, normalized, principal.Type == "anonymous", false)
	if err != nil {
		respondFileSpaceError(c, err)
		return
	}
	temp, err := os.CreateTemp(filepath.Dir(target), ".qtserver-create-*.tmp")
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot create temporary file")
		return
	}
	tempPath := temp.Name()
	published := false
	defer func() {
		_ = temp.Close()
		if !published {
			_ = os.Remove(tempPath)
		}
	}()
	if err := deps.FileSpace.ApplyFilePolicy(tempPath, normalized, principal.Type == "anonymous"); err != nil {
		InternalServerError(c, ReasonInternalError, "cannot apply file policy")
		return
	}
	if err := temp.Sync(); err != nil {
		InternalServerError(c, ReasonInternalError, "cannot sync empty file")
		return
	}
	if err := temp.Close(); err != nil {
		InternalServerError(c, ReasonInternalError, "cannot close empty file")
		return
	}
	tempFP, err := filehash.FingerprintPath(tempPath)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot fingerprint empty file")
		return
	}
	generation, err := deps.Hashes.BeginKnownMutation(c.Request.Context(), principal.ID, normalized, tempFP)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot prepare file hash state")
		return
	}
	if !lock.valid(c.Request.Context()) {
		if len(createdPaths) > 0 {
			writeErrorWithExtras(c, http.StatusInternalServerError, "NAMESPACE_OPERATION_PARTIAL", "namespace lock was lost after creating directories", map[string]any{"partial": true})
		} else {
			Conflict(c, "NAMESPACE_LOCK_LOST", "namespace lock was lost")
		}
		return
	}
	if request.Overwrite {
		err = os.Rename(tempPath, target)
	} else {
		err = filespace.RenameNoReplace(tempPath, target)
	}
	if err != nil {
		var typed *filespace.Error
		switch {
		case errors.Is(err, os.ErrExist):
			Conflict(c, ReasonConflict, "target already exists")
		case errors.As(err, &typed):
			InternalServerError(c, typed.Reason, typed.Error())
		default:
			InternalServerError(c, ReasonInternalError, "cannot publish empty file")
		}
		return
	}
	published = true
	if err := filespace.FsyncDirectory(filepath.Dir(target)); err != nil {
		getLogger(c).Error("fsync parent after create", "path", normalized, "error", err)
	}
	finalFP, fpErr := filehash.FingerprintPath(target)
	emptyHash, _, _ := filehash.LayeredFromChunkHashes(nil, 0)
	if fpErr == nil {
		if _, commitErr := deps.Hashes.CommitKnown(c.Request.Context(), principal.ID, normalized, generation, finalFP, emptyHash); commitErr != nil {
			ReportFatalDependency(commitErr)
		}
	} else {
		getLogger(c).Error("fingerprint published empty file", "path", normalized, "error", fpErr)
		if invalidateErr := deps.Hashes.Invalidate(c.Request.Context(), principal.ID, normalized); invalidateErr != nil {
			ReportFatalDependency(invalidateErr)
		}
	}
	status := http.StatusCreated
	if targetExisted {
		status = http.StatusOK
	}
	c.JSON(status, gin.H{"code": status, "path": normalized, "created": !targetExisted, "file_hash": emptyHash, "hash_algorithm": filehash.LayeredAlgorithm})
}

func requireWritePrincipal(c *gin.Context) (*Principal, bool) {
	principal, err := authenticateWritePrincipal(c.Request.Context(), c.GetHeader("Authorization"))
	if err != nil {
		handleIdentityError(c, getLogger(c), err)
		return nil, false
	}
	return principal, true
}

func requireNamespaceLock(c *gin.Context, principalID string) (*renewableLock, bool) {
	lock, err := acquireNamespaceLock(c.Request.Context(), principalID)
	if err == nil {
		return lock, true
	}
	if isLockConflict(err) {
		c.Header("Retry-After", "1")
		Conflict(c, "NAMESPACE_BUSY", "principal namespace is busy")
	} else {
		InternalServerError(c, ReasonInternalError, "cannot acquire namespace lock")
	}
	return nil, false
}

func respondFileSpaceError(c *gin.Context, err error) {
	var typed *filespace.Error
	if errors.As(err, &typed) {
		status := http.StatusInternalServerError
		if typed.Reason == "CONFLICT" {
			status = http.StatusConflict
		}
		if typed.Reason == "NOT_FOUND" {
			status = http.StatusNotFound
		}
		if typed.Reason == "NOT_A_DIRECTORY" || typed.Reason == "UNSUPPORTED_FILE_TYPE" || typed.Reason == "DAMAGED_SYMLINK" || typed.Reason == "SYMLINK_LOOP" {
			status = http.StatusUnprocessableEntity
		}
		writeError(c, status, typed.Reason, typed.Error())
		return
	}
	InternalServerError(c, ReasonInternalError, "file operation failed")
}
