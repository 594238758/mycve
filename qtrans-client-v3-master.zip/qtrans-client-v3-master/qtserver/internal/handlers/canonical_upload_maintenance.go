package handlers

import (
	"context"
	"errors"
	"io/fs"
	"log/slog"
	"os"
	"path/filepath"
	"slices"
	"sync/atomic"
	"time"

	"qtserver/internal/store"
)

var errCanonicalCleanupLockLost = errors.New("canonical upload cleanup lock lost")

func StartCanonicalUploadMaintenance(ctx context.Context, logger *slog.Logger) {
	if deps == nil || deps.Config == nil || !deps.Config.Server.WriteEnabled {
		return
	}
	go func() {
		runCanonicalOrphanScan(ctx, logger)
		ticker := time.NewTicker(60 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				runCanonicalOrphanScan(ctx, logger)
			}
		}
	}()
}

func runCanonicalOrphanScan(ctx context.Context, logger *slog.Logger) {
	handle, err := deps.Redis.TryAcquireCleanupLock(ctx, 30*time.Second)
	if errors.Is(err, store.ErrConflict) {
		return
	}
	if err != nil {
		logger.Error("acquire upload orphan scanner lock", "error", err)
		return
	}
	scanCtx, cancel := context.WithCancel(ctx)
	done := make(chan struct{})
	var lockLost atomic.Bool
	go func() {
		defer close(done)
		ticker := time.NewTicker(10 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-scanCtx.Done():
				return
			case <-ticker.C:
				if err := deps.Redis.RefreshLock(scanCtx, handle, 30*time.Second); err != nil {
					lockLost.Store(true)
					if scanCtx.Err() == nil {
						ReportFatalDependency(err)
					}
					return
				}
				valid, err := deps.Redis.CheckLock(scanCtx, handle)
				if err != nil {
					lockLost.Store(true)
					if scanCtx.Err() == nil {
						ReportFatalDependency(err)
					}
					return
				}
				if !valid {
					lockLost.Store(true)
					return
				}
			}
		}
	}()
	defer func() {
		cancel()
		<-done
		_ = deps.Redis.ReleaseLock(context.Background(), handle)
	}()

	root := deps.Config.Server.TempRoot
	directories := make([]string, 0)
	err = filepath.WalkDir(root, func(path string, entry fs.DirEntry, walkErr error) error {
		if lockLost.Load() {
			return errCanonicalCleanupLockLost
		}
		if path == root {
			return nil
		}
		if walkErr != nil {
			logger.Warn("inspect upload cache node", "path", path, "error", walkErr)
			return nil
		}
		if entry.IsDir() {
			directories = append(directories, path)
			return nil
		}
		sessionID := filepath.Base(path)
		_, sessionErr := deps.Redis.GetCanonicalUpload(scanCtx, sessionID)
		if sessionErr == nil {
			return nil
		}
		if !errors.Is(sessionErr, store.ErrNotFound) {
			ReportFatalDependency(sessionErr)
			return sessionErr
		}
		_, tombstoneErr := deps.Redis.GetCanonicalUploadTombstone(scanCtx, sessionID)
		if tombstoneErr != nil && !errors.Is(tombstoneErr, store.ErrNotFound) {
			ReportFatalDependency(tombstoneErr)
			return tombstoneErr
		}
		if err := os.Remove(path); err != nil && !os.IsNotExist(err) {
			logger.Warn("remove orphan upload cache node", "path", path, "error", err)
			return nil
		}
		if tombstoneErr == nil {
			if err := deps.Redis.DeleteCanonicalUpload(scanCtx, sessionID); err != nil {
				ReportFatalDependency(err)
				return err
			}
		}
		return nil
	})
	if err != nil {
		if errors.Is(err, errCanonicalCleanupLockLost) {
			logger.Warn("upload orphan scanner lock was lost; scan stopped")
			return
		}
		logger.Warn("walk upload temp root", "error", err)
		return
	}
	slices.Reverse(directories)
	for _, directory := range directories {
		if lockLost.Load() {
			logger.Warn("upload orphan scanner lock was lost; directory cleanup stopped")
			return
		}
		_ = os.Remove(directory)
	}
}
