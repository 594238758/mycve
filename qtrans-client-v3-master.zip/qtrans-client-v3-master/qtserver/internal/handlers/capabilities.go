package handlers

import (
	"net/http"

	"qtserver/internal/version"

	"github.com/gin-gonic/gin"
)

const APIVersion = "1"

type capabilityState struct {
	Enabled   bool `json:"enabled"`
	Available bool `json:"available"`
}

func CapabilitiesHandler(c *gin.Context) {
	cfg := deps.Config
	read := cfg.Server.ReadEnabled
	write := cfg.Server.WriteEnabled
	c.Header("Cache-Control", "no-store")
	c.JSON(http.StatusOK, gin.H{
		"code":             http.StatusOK,
		"qtserver_version": version.Version,
		"api_version":      APIVersion,
		"capabilities": gin.H{
			"read":              capabilityState{Enabled: read, Available: read},
			"download":          capabilityState{Enabled: read, Available: read},
			"small_download_v2": capabilityState{Enabled: read, Available: read},
			"write":             capabilityState{Enabled: write, Available: write},
			"upload":            capabilityState{Enabled: write, Available: write},
			"file_management":   capabilityState{Enabled: true, Available: true},
		},
		"anonymous": gin.H{
			"read":  cfg.Server.AnonymousEnabled,
			"write": cfg.Server.AnonymousEnabled && write,
		},
		"limits": gin.H{
			"list_entries":       100000,
			"path_bytes":         1024,
			"segment_bytes":      255,
			"grant_objects":      1000,
			"upload_chunk_bytes": 104857600,
			"max_file_bytes":     transferMaxFileBytes(),
			"small_files":        cfg.Transfer.MaxSmallFiles,
			"small_file_bytes":   cfg.Transfer.MaxSmallFileBytes,
			"small_total_bytes":  cfg.Transfer.MaxSmallTotalBytes,
		},
		"algorithms": []string{"xxh3_128", "layered_xxh3_128_v1"},
	})
}
