package handlers

import (
	"errors"
	"log/slog"

	"github.com/gin-gonic/gin"
)

func handleIdentityError(c *gin.Context, logger *slog.Logger, err error) {
	attrs := append([]any{"error", err}, identityErrorLogAttrs(err)...)
	switch {
	case errors.Is(err, errIdentityCacheUnavailable):
		logger.Error("identity cache unavailable", attrs...)
		InternalServerError(c, ReasonInternalError, "internal dependency failure")
	case errors.Is(err, ErrIdentityUnavailable):
		logger.Error("identity source unavailable", attrs...)
		ServiceUnavailable(c, ReasonDependencyUnavailable, "identity source unavailable")
	case errors.Is(err, ErrInvalidToken):
		logger.Warn("invalid token", attrs...)
		Unauthorized(c, ReasonInvalidToken, "invalid or expired token")
	default:
		logger.Error("identity failure", attrs...)
		ServiceUnavailable(c, ReasonDependencyUnavailable, "identity source unavailable")
	}
}

func identityErrorLogAttrs(err error) []any {
	var detailed *identityResolveError
	if !errors.As(err, &detailed) || detailed == nil {
		return nil
	}
	return detailed.logAttrs()
}
