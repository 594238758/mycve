package handlers

import (
	"bytes"
	"context"
	"encoding/hex"
	"errors"
	"io"
	"log/slog"
	"os"
	"strconv"
	"strings"
	"time"

	"qtserver/internal/store"

	"github.com/zeebo/xxh3"
)

const (
	fileHashChunkSize = 100 * 1024 * 1024
	chunkHashByteSize = 16
)

func buildFileHashScope(namespace, principalID, objectKey string) string {
	return namespace + "|" + principalID + "|" + objectKey
}

func fileHashCacheTTL() time.Duration {
	if deps != nil && deps.Config != nil && deps.Config.Transfer.FileHashRevalidateSeconds > 0 {
		return time.Duration(deps.Config.Transfer.FileHashRevalidateSeconds) * time.Second
	}
	return 24 * time.Hour
}

func warmFileHashAsync(logger *slog.Logger, principalID, rootPath, objectKey string) {
	storeRef := deps.Store
	if storeRef == nil {
		return
	}
	scope := buildFileHashScope("download", principalID, objectKey)

	go func() {
		file, fileInfo, err := openDownloadPath(rootPath, objectKey)
		if err != nil || !fileInfo.Mode().IsRegular() {
			if file != nil {
				_ = file.Close()
			}
			return
		}
		defer file.Close()
		if _, ok := loadCachedFileHash(context.Background(), logger, storeRef, scope, objectKey, fileInfo); ok {
			return
		}

		calculatedHash, err := calculateReaderHash(file)
		if err != nil {
			logger.Warn("warm file hash cache failed", "object_key", objectKey, "error", err)
			return
		}
		if err := storeRef.SetFileHash(context.Background(), scope, fileInfo.Size(), fileInfo.ModTime(), calculatedHash, fileHashCacheTTL()); err != nil {
			logger.Warn("persist file hash cache failed", "object_key", objectKey, "error", err)
		}
	}()
}

func getOrCalculateFileHashReader(ctx context.Context, logger *slog.Logger, principalID string, reader io.Reader, objectKey string, fileInfo os.FileInfo) (string, error) {
	storeRef := deps.Store
	scope := buildFileHashScope("download", principalID, objectKey)
	if storeRef != nil {
		if cachedHash, ok := loadCachedFileHash(ctx, logger, storeRef, scope, objectKey, fileInfo); ok {
			return cachedHash, nil
		}
	}

	calculatedHash, err := calculateReaderHash(reader)
	if err != nil {
		return "", err
	}
	if storeRef != nil {
		if err := storeRef.SetFileHash(ctx, scope, fileInfo.Size(), fileInfo.ModTime(), calculatedHash, fileHashCacheTTL()); err != nil {
			logger.Warn("persist file hash cache failed", "object_key", objectKey, "error", err)
		}
	}
	return calculatedHash, nil
}

func loadCachedFileHash(ctx context.Context, logger *slog.Logger, storeRef store.SessionStore, scope, objectKey string, fileInfo os.FileInfo) (string, bool) {
	cachedHash, err := storeRef.GetFileHash(ctx, scope, fileInfo.Size(), fileInfo.ModTime())
	if err == nil {
		if refreshErr := storeRef.SetFileHash(ctx, scope, fileInfo.Size(), fileInfo.ModTime(), cachedHash, fileHashCacheTTL()); refreshErr != nil {
			logger.Warn("refresh file hash cache ttl failed", "object_key", objectKey, "error", refreshErr)
		}
		return cachedHash, true
	}
	if !errors.Is(err, store.ErrNotFound) {
		logger.Warn("load file hash cache failed", "object_key", objectKey, "error", err)
	}
	return "", false
}

func calculateFileHash(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	return calculateReaderHash(file)
}

func calculateBytesHash(content []byte) (string, error) {
	return calculateReaderHash(bytes.NewReader(content))
}

func calculateChunkHash(content []byte) string {
	sum := xxh3.Hash128(content)
	raw := sum.Bytes()
	return hex.EncodeToString(raw[:])
}

func calculateLayeredHashFromChunkHashes(chunkHashes map[string]string, chunkCount int) (string, bool, error) {
	if chunkCount < 0 {
		return "", false, errors.New("invalid chunk count")
	}

	overallHasher := xxh3.New()
	if chunkCount == 0 {
		finalBytes := overallHasher.Sum128().Bytes()
		return hex.EncodeToString(finalBytes[:]), true, nil
	}
	if len(chunkHashes) < chunkCount {
		return "", false, nil
	}

	for idx := 0; idx < chunkCount; idx++ {
		encodedHash := strings.TrimSpace(chunkHashes[strconv.Itoa(idx)])
		if encodedHash == "" {
			return "", false, nil
		}
		rawHash, err := hex.DecodeString(encodedHash)
		if err != nil || len(rawHash) != chunkHashByteSize {
			return "", false, nil
		}
		if _, err := overallHasher.Write(rawHash); err != nil {
			return "", false, err
		}
	}

	finalBytes := overallHasher.Sum128().Bytes()
	return hex.EncodeToString(finalBytes[:]), true, nil
}

func calculateReaderHash(reader io.Reader) (string, error) {
	overallHasher := xxh3.New()
	buf := make([]byte, fileHashChunkSize)

	for {
		n, err := io.ReadFull(reader, buf)
		if err != nil && err != io.ErrUnexpectedEOF && err != io.EOF {
			return "", err
		}
		if n > 0 {
			chunkHasher := xxh3.New()
			if _, err := chunkHasher.Write(buf[:n]); err != nil {
				return "", err
			}
			chunkBytes := chunkHasher.Sum128().Bytes()
			if _, err := overallHasher.Write(chunkBytes[:]); err != nil {
				return "", err
			}
		}
		if err == io.ErrUnexpectedEOF || err == io.EOF {
			break
		}
	}

	finalBytes := overallHasher.Sum128().Bytes()
	return hex.EncodeToString(finalBytes[:]), nil
}
