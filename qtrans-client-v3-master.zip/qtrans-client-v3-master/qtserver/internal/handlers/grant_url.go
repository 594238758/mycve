package handlers

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	"qtserver/internal/models"

	"github.com/gin-gonic/gin"
)

var errInvalidTransferGrantRef = errors.New("invalid transfer grant reference")

type transferGrantRef struct {
	TaskID    string `json:"task_id"`
	ExpiresAt int64  `json:"expires_at"`
	HMAC      string `json:"hmac"`
}

func encodeTransferGrantRef(grant *models.TransferGrant) (string, error) {
	payload, err := json.Marshal(transferGrantRef{
		TaskID:    grant.TaskID,
		ExpiresAt: grant.ExpiresAt,
		HMAC:      grant.HMAC,
	})
	if err != nil {
		return "", fmt.Errorf("marshal transfer grant reference: %w", err)
	}
	return base64.RawURLEncoding.EncodeToString(payload), nil
}

func resolveTransferGrantAccess(c *gin.Context) (string, int64, string, error) {
	encodedGrant := strings.TrimSpace(c.Query("grant"))
	if encodedGrant == "" {
		return "", 0, "", errInvalidTransferGrantRef
	}
	return decodeTransferGrantRef(encodedGrant)
}

func decodeTransferGrantRef(encodedGrant string) (string, int64, string, error) {
	payload, err := base64.RawURLEncoding.DecodeString(encodedGrant)
	if err != nil {
		return "", 0, "", errInvalidTransferGrantRef
	}
	var ref transferGrantRef
	if err := json.Unmarshal(payload, &ref); err != nil {
		return "", 0, "", errInvalidTransferGrantRef
	}

	ref.TaskID = strings.TrimSpace(ref.TaskID)
	ref.HMAC = strings.TrimSpace(ref.HMAC)
	if ref.TaskID == "" || ref.HMAC == "" || ref.ExpiresAt <= 0 {
		return "", 0, "", errInvalidTransferGrantRef
	}
	return ref.TaskID, ref.ExpiresAt, ref.HMAC, nil
}
