package handlers

import (
	"archive/tar"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strconv"
	"strings"

	"qtserver/internal/businessevents"
	"qtserver/internal/filehash"
	"qtserver/internal/models"

	"github.com/gin-gonic/gin"
)

const (
	smallV2Version       = 2
	smallBatchIDHeader   = "X-QT-Small-Batch-ID"
	smallAttemptHeader   = "X-QT-Small-Batch-Attempt"
	maxSmallBatchIDBytes = 128
)

func DownloadSmallV2Handler(c *gin.Context) {
	logger := getLogger(c)
	ctx := c.Request.Context()

	principal, err := authenticateReadPrincipal(ctx, c.GetHeader("Authorization"))
	if err != nil {
		handleIdentityError(c, logger, err)
		return
	}
	var req models.DownloadSmallRequest
	if err := decodeStrictJSON(c, &req, false); err != nil {
		respondHTTPError(c, err)
		return
	}
	if len(req.Files) == 0 {
		BadRequest(c, ReasonInvalidRequest, "files must contain at least one file")
		return
	}
	taskID, ok := requireTaskID(c, req.TaskID)
	if !ok {
		return
	}
	metadata, ok := requireClientLogMetadata(c)
	if !ok {
		return
	}
	batchID, attempt, ok := parseSmallV2DebugHeaders(c)
	if !ok {
		return
	}
	logTaskID := requestTaskIDForLog(c, taskID)
	logger = logger.With("small_batch_id", batchID, "small_attempt", attempt)

	preparedFiles, totalBytes, permit, err := prepareSmallFilesV2(ctx, principal, req.Files)
	if err != nil {
		var notSmall *notSmallFileError
		switch {
		case errors.As(err, &notSmall):
			NotSmall(c, notSmall.objectKey, notSmall.fileSize, notSmall.limit)
		case errors.Is(err, errEmptySmallSelection):
			BadRequest(c, ReasonInvalidRequest, "files must contain at least one file")
		case errors.Is(err, errDownloadTargetNotDirectory), errors.Is(err, errUnsupportedDownloadTarget):
			BadRequest(c, ReasonInvalidRequest, "small only supports regular files")
		case isTransferFileTooLarge(err):
			FileTooLarge(c, transferFileSize(err), transferMaxFileBytes())
		case errors.Is(err, errSmallDownloadLimitExceeded):
			BadRequest(c, ReasonInvalidRequest, "small selection exceeds configured limits")
		case os.IsNotExist(err):
			NotFound(c, ReasonNotFound, "selected file not found")
		case errors.Is(err, ctx.Err()):
			return
		default:
			logger.Error("prepare small v2 download failed", "taskid", logTaskID, "error", err)
			InternalServerError(c, ReasonInternalError, "failed to prepare small download")
		}
		return
	}
	defer func() {
		closePreparedSmallFiles(preparedFiles)
		permit.Release()
	}()
	logger = logger.With("file_count", len(preparedFiles), "total_bytes", totalBytes, "transport", c.Request.Proto)
	logger.Debug("small v2 batch streaming started", "result", "started")
	attemptResult := "failed"
	defer func() {
		logger.Debug("small v2 batch streaming finished", "result", attemptResult)
	}()

	type smallOperation struct {
		file       preparedSmallFile
		logContext fileLogContext
	}
	operations := make([]smallOperation, 0, len(preparedFiles))
	manifestFiles := make([]models.DownloadSmallV2ManifestEntry, 0, len(preparedFiles))
	for index, file := range preparedFiles {
		logContext, eventErr := newFileLogContext(c, taskID, businessevents.ActionDownload, file.ObjectKey, file.Size, principal, metadata)
		if eventErr != nil {
			InternalServerError(c, ReasonInternalError, "cannot construct small file log context")
			return
		}
		operations = append(operations, smallOperation{file: file, logContext: logContext})
		manifestFiles = append(manifestFiles, models.DownloadSmallV2ManifestEntry{
			Index:       index,
			ObjectKey:   file.ObjectKey,
			ArchivePath: file.ArchivePath,
			Size:        file.Size,
		})
	}
	manifest := models.DownloadSmallV2Manifest{
		Version:            smallV2Version,
		TaskID:             taskID,
		FileCount:          len(preparedFiles),
		TotalUnpackedBytes: totalBytes,
		HashAlgorithm:      filehash.LayeredAlgorithm,
		Files:              manifestFiles,
	}

	c.Header("Content-Type", "application/x-tar")
	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s.tar\"", taskID))
	c.Header("Cache-Control", "no-store")
	c.Header("X-Qtrans-TaskID", taskID)
	c.Header("X-Qtrans-UserID", principal.ID)
	c.Header("X-Qtrans-File-Count", strconv.Itoa(len(preparedFiles)))
	c.Header("X-Qtrans-Total-Bytes", strconv.FormatInt(totalBytes, 10))
	c.Status(http.StatusOK)

	tw := tar.NewWriter(c.Writer)
	closed := false
	defer func() {
		if !closed {
			_ = tw.Close()
		}
	}()
	if err := writeSmallJSONEntry(tw, ".qtrans/manifest.json", manifest); err != nil {
		logger.Error("write small v2 manifest failed", "taskid", logTaskID, "error", err)
		return
	}

	events := make([]businessevents.Envelope, 0, len(operations))
	checksums := make([]models.DownloadSmallV2ChecksumEntry, 0, len(operations))
	for index, operation := range operations {
		startedAt := deps.Now().UTC()
		actualBytes, hash, streamErr := writeSmallV2PayloadEntry(tw, operation.file)
		if streamErr == nil && actualBytes == operation.file.Size {
			streamErr = tw.Flush()
		}
		if streamErr != nil || actualBytes != operation.file.Size {
			logger.Error("write small v2 payload failed", "taskid", logTaskID, "index", index, "error", streamErr)
			return
		}
		finished, eventErr := newBusinessEvent(
			businessevents.EventDownloadSmallFileSent,
			operation.logContext.Correlation,
			operation.logContext.FileKey,
			operation.logContext.smallFileSentPayload(startedAt),
		)
		if eventErr != nil {
			logger.Error("construct small v2 business event failed", "taskid", logTaskID, "index", index, "error", eventErr)
			return
		}
		events = append(events, finished)
		checksums = append(checksums, models.DownloadSmallV2ChecksumEntry{
			Index:       index,
			ObjectKey:   operation.file.ObjectKey,
			ArchivePath: operation.file.ArchivePath,
			Size:        actualBytes,
			Hash:        hash,
		})
	}

	if !syncObservedBusinessEvents(c, events) {
		logger.Error("persist small v2 business event batch failed", "taskid", logTaskID, "files", len(events))
		return
	}
	footer := models.DownloadSmallV2Checksums{
		Version:            smallV2Version,
		TaskID:             taskID,
		FileCount:          len(preparedFiles),
		TotalUnpackedBytes: totalBytes,
		HashAlgorithm:      filehash.LayeredAlgorithm,
		Files:              checksums,
	}
	if err := writeSmallJSONEntry(tw, ".qtrans/checksums.json", footer); err != nil {
		logger.Error("write small v2 checksum footer failed", "taskid", logTaskID, "error", err)
		return
	}
	closeErr := tw.Close()
	closed = true
	if closeErr != nil {
		logger.Error("close small v2 tar failed", "taskid", logTaskID, "error", closeErr)
		return
	}
	attemptResult = "completed"
	logger.Info("small v2 download completed", "taskid", logTaskID, "result", "completed")
}

func writeSmallV2PayloadEntry(tw *tar.Writer, file preparedSmallFile) (int64, string, error) {
	header := &tar.Header{
		Name:    file.ArchivePath,
		Mode:    0o644,
		Size:    file.Size,
		ModTime: file.ModTime.UTC(),
	}
	if err := tw.WriteHeader(header); err != nil {
		return 0, "", err
	}
	hasher := filehash.NewLayeredHasher()
	written, err := io.CopyN(io.MultiWriter(tw, hasher), file.File, file.Size)
	if err != nil {
		return written, "", err
	}
	hash, err := hasher.Finalize()
	return written, hash, err
}

func parseSmallV2DebugHeaders(c *gin.Context) (string, int, bool) {
	batchID := strings.TrimSpace(c.GetHeader(smallBatchIDHeader))
	if len(batchID) > maxSmallBatchIDBytes || strings.ContainsAny(batchID, "\r\n\x00") {
		BadRequest(c, ReasonInvalidRequest, smallBatchIDHeader+" is invalid")
		return "", 0, false
	}
	attempt := 1
	if rawAttempt := strings.TrimSpace(c.GetHeader(smallAttemptHeader)); rawAttempt != "" {
		parsed, err := strconv.Atoi(rawAttempt)
		if err != nil || parsed <= 0 {
			BadRequest(c, ReasonInvalidRequest, smallAttemptHeader+" must be a positive integer")
			return "", 0, false
		}
		attempt = parsed
	}
	return batchID, attempt, true
}
