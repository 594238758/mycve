package handlers

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"strings"
	"time"

	"qtserver/internal/businessevents"
	"qtserver/internal/models"
	"qtserver/internal/version"

	"github.com/gin-gonic/gin"
)

const maxClientMetadataBytes = 256

type clientLogMetadata struct {
	ID            string
	OS            string
	Version       string
	CallerVersion string
}

type fileLogContext struct {
	Correlation    businessevents.TaskCorrelation
	FileKey        string
	TaskType       string
	Action         string
	FilePath       string
	FileSize       int64
	PrincipalID    string
	ClientUsername string
	ClientID       string
	ClientIP       string
	ClientOS       string
	ClientVersion  string
	CallerVersion  string
	ServerIP       string
	ServerInstance string
	ServerVersion  string
}

func appendBusinessEvent(ctx context.Context, event businessevents.Envelope, durability businessevents.Durability) error {
	if deps == nil || deps.BusinessEvents == nil || !deps.BusinessEvents.Healthy() {
		return businessevents.ErrUnavailable
	}
	return deps.BusinessEvents.Append(ctx, event, durability)
}

func requireBusinessEvent(c *gin.Context, event businessevents.Envelope) bool {
	if err := appendBusinessEvent(c.Request.Context(), event, businessevents.DurabilitySync); err != nil {
		handleBusinessLogError(c, err)
		return false
	}
	return true
}

func appendObservedBusinessEvent(c *gin.Context, event businessevents.Envelope) {
	if err := appendBusinessEvent(context.Background(), event, businessevents.DurabilityAppend); err != nil {
		getLogger(c).Error("append observed business event", "event_type", event.EventType, "file_key", event.FileKey, "error", err)
	}
}

func syncObservedBusinessEvent(c *gin.Context, event businessevents.Envelope) bool {
	if err := appendBusinessEvent(context.Background(), event, businessevents.DurabilitySync); err != nil {
		getLogger(c).Error("sync observed business event", "event_type", event.EventType, "file_key", event.FileKey, "error", err)
		return false
	}
	return true
}

type batchBusinessEventSink interface {
	AppendBatch(context.Context, []businessevents.Envelope) error
}

func syncObservedBusinessEvents(c *gin.Context, events []businessevents.Envelope) bool {
	if len(events) == 0 {
		return true
	}
	if deps == nil || deps.BusinessEvents == nil || !deps.BusinessEvents.Healthy() {
		getLogger(c).Error("sync observed business event batch", "events", len(events), "error", businessevents.ErrUnavailable)
		return false
	}
	ctx := context.Background()
	if sink, ok := deps.BusinessEvents.(batchBusinessEventSink); ok {
		if err := sink.AppendBatch(ctx, events); err != nil {
			getLogger(c).Error("sync observed business event batch", "events", len(events), "error", err)
			return false
		}
		return true
	}
	for index, event := range events {
		durability := businessevents.DurabilityAppend
		if index == len(events)-1 {
			durability = businessevents.DurabilitySync
		}
		if err := deps.BusinessEvents.Append(ctx, event, durability); err != nil {
			getLogger(c).Error("sync observed business event batch", "events", len(events), "index", index, "error", err)
			return false
		}
	}
	return true
}

func newBusinessEvent(eventType businessevents.EventType, correlation businessevents.TaskCorrelation, fileKey string, payload any) (businessevents.Envelope, error) {
	return businessevents.NewEnvelopeWithCorrelation(eventType, deps.Now(), correlation, fileKey, payload)
}

func parseClientLogMetadata(c *gin.Context) (clientLogMetadata, int, error) {
	metadata := clientLogMetadata{
		ID:            strings.TrimSpace(c.GetHeader("Client-ID")),
		OS:            strings.TrimSpace(c.GetHeader("Client-OS")),
		Version:       strings.TrimSpace(c.GetHeader("Client-Version")),
		CallerVersion: strings.TrimSpace(c.GetHeader("Caller-Version")),
	}
	values := []struct {
		name  string
		value string
	}{
		{name: "Client-ID", value: metadata.ID},
		{name: "Client-OS", value: metadata.OS},
		{name: "Client-Version", value: metadata.Version},
	}
	present := 0
	for _, item := range values {
		if item.value == "" {
			continue
		}
		present++
		if len(item.value) > maxClientMetadataBytes || strings.ContainsAny(item.value, "\r\n\x00") {
			return clientLogMetadata{}, 0, fmt.Errorf("%s is invalid", item.name)
		}
	}
	if present != 0 && present != len(values) {
		return clientLogMetadata{}, present, fmt.Errorf("Client-ID, Client-OS, and Client-Version must be provided together")
	}
	if len(metadata.CallerVersion) > maxClientMetadataBytes || strings.ContainsAny(metadata.CallerVersion, "\r\n\x00") {
		return clientLogMetadata{}, present, fmt.Errorf("Caller-Version is invalid")
	}
	return metadata, present, nil
}

func requireClientLogMetadata(c *gin.Context) (clientLogMetadata, bool) {
	metadata, present, err := parseClientLogMetadata(c)
	if err != nil {
		BadRequest(c, ReasonInvalidRequest, err.Error())
		return clientLogMetadata{}, false
	}
	if present == 0 {
		BadRequest(c, ReasonInvalidRequest, "Client-ID, Client-OS, and Client-Version are required")
		return clientLogMetadata{}, false
	}
	return metadata, true
}

func newFileLogContext(c *gin.Context, taskID, action, filePath string, fileSize int64, principal *Principal, metadata clientLogMetadata) (fileLogContext, error) {
	if principal == nil || strings.TrimSpace(principal.ID) == "" {
		return fileLogContext{}, fmt.Errorf("principal is required")
	}
	if action != businessevents.ActionUpload && action != businessevents.ActionDownload {
		return fileLogContext{}, fmt.Errorf("invalid file action %q", action)
	}
	if fileSize < 0 {
		return fileLogContext{}, fmt.Errorf("file size cannot be negative")
	}
	clientIP := strings.TrimSpace(c.ClientIP())
	if parsed := net.ParseIP(clientIP); parsed == nil || parsed.IsUnspecified() {
		return fileLogContext{}, fmt.Errorf("trusted client IP is unavailable")
	} else {
		clientIP = parsed.String()
	}
	serverIP := requestServerIP(c)
	if parsed := net.ParseIP(serverIP); parsed == nil || parsed.IsUnspecified() {
		return fileLogContext{}, fmt.Errorf("trusted server IP is unavailable")
	} else {
		serverIP = parsed.String()
	}
	clientUsername := strings.TrimSpace(principal.Email)
	if principal.Type == models.PrincipalAnonymous {
		clientUsername = businessevents.AnonymousPrincipal
	}
	return fileLogContext{
		Correlation: businessevents.TaskCorrelation{
			TaskID:       taskID,
			TaskPID:      requestTaskPIDForLog(c),
			EnterpriseID: requestEnterpriseIDForLog(c),
		},
		FileKey:        businessevents.FileKey(taskID, filePath, principal.ID, action),
		TaskType:       deps.Config.Log.TaskType,
		Action:         action,
		FilePath:       filePath,
		FileSize:       fileSize,
		PrincipalID:    principal.ID,
		ClientUsername: clientUsername,
		ClientID:       metadata.ID,
		ClientIP:       clientIP,
		ClientOS:       metadata.OS,
		ClientVersion:  metadata.Version,
		CallerVersion:  metadata.CallerVersion,
		ServerIP:       serverIP,
		ServerInstance: deps.Config.Server.InstanceID,
		ServerVersion:  version.Version,
	}, nil
}

func (value fileLogContext) registeredPayload() businessevents.FileRegisteredPayload {
	return businessevents.FileRegisteredPayload{
		TaskType:                     value.TaskType,
		Action:                       value.Action,
		FilePath:                     value.FilePath,
		FileSize:                     value.FileSize,
		PrincipalID:                  value.PrincipalID,
		ClientUsername:               value.ClientUsername,
		ClientID:                     value.ClientID,
		ClientIP:                     value.ClientIP,
		ClientOS:                     value.ClientOS,
		ClientVersion:                value.ClientVersion,
		CallerVersion:                value.CallerVersion,
		ServerIP:                     value.ServerIP,
		ServerInstance:               value.ServerInstance,
		ServerVersion:                value.ServerVersion,
		FileInactivityTimeoutSeconds: int64(deps.Config.Log.FileInactivityTimeoutSeconds),
	}
}

func (value fileLogContext) smallFileSentPayload(startedAt time.Time) businessevents.DownloadSmallFileSentPayload {
	return businessevents.DownloadSmallFileSentPayload{
		TaskType:       value.TaskType,
		Action:         value.Action,
		FilePath:       value.FilePath,
		FileSize:       value.FileSize,
		PrincipalID:    value.PrincipalID,
		ClientUsername: value.ClientUsername,
		ClientID:       value.ClientID,
		ClientIP:       value.ClientIP,
		ClientOS:       value.ClientOS,
		ClientVersion:  value.ClientVersion,
		CallerVersion:  value.CallerVersion,
		ServerIP:       value.ServerIP,
		ServerInstance: value.ServerInstance,
		ServerVersion:  value.ServerVersion,
		StartedAt:      businessevents.NewTimestamp(startedAt),
	}
}

func fileRegisteredEvent(c *gin.Context, taskID, action, filePath string, fileSize int64, principal *Principal, metadata clientLogMetadata) (businessevents.Envelope, error) {
	contextValue, err := newFileLogContext(c, taskID, action, filePath, fileSize, principal, metadata)
	if err != nil {
		return businessevents.Envelope{}, err
	}
	return newBusinessEvent(businessevents.EventFileRegistered, contextValue.Correlation, contextValue.FileKey, contextValue.registeredPayload())
}

func handleBusinessLogError(c *gin.Context, err error) {
	if errors.Is(err, businessevents.ErrUnavailable) {
		ServiceUnavailable(c, businessevents.ReasonBusinessLogUnavailable, "business event log is unavailable")
		return
	}
	writeError(c, http.StatusInternalServerError, ReasonInternalError, "cannot persist business event")
}
