package handlers

import (
	"context"
	"errors"
	"io"
	"mime"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"syscall"
	"time"

	"qtserver/internal/businessevents"
	"qtserver/internal/filehash"
	"qtserver/internal/filespace"
	"qtserver/internal/models"
	"qtserver/internal/store"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

const canonicalUploadChunkSize int64 = filehash.ChunkSize

var lowercaseChunkHash = regexp.MustCompile(`^[0-9a-f]{32}$`)

type canonicalInitRequest struct {
	ObjectKey     string `json:"object_key"`
	FileSize      int64  `json:"file_size"`
	FileHash      string `json:"file_hash"`
	HashAlgorithm string `json:"hash_algorithm"`
	Overwrite     bool   `json:"overwrite"`
}

type canonicalCompleteRequest struct {
	Overwrite bool `json:"overwrite"`
}
type canonicalFinalizeRequest struct {
	ChunkHash string `json:"chunk_hash"`
}

func CanonicalUploadInitHandler(c *gin.Context) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	taskID, ok := requireTaskID(c, c.GetHeader("X-Task-ID"))
	if !ok {
		return
	}
	var request canonicalInitRequest
	if err := decodeStrictJSON(c, &request, false); err != nil {
		respondHTTPError(c, err)
		return
	}
	if request.FileSize < 0 {
		BadRequest(c, ReasonInvalidRequest, "file_size must be non-negative")
		return
	}
	if request.FileSize > transferMaxFileBytes() {
		FileTooLarge(c, request.FileSize, transferMaxFileBytes())
		return
	}
	if request.HashAlgorithm != filehash.LayeredAlgorithm {
		BadRequest(c, ReasonInvalidRequest, "hash_algorithm must be "+filehash.LayeredAlgorithm)
		return
	}
	if !lowercaseChunkHash.MatchString(request.FileHash) {
		BadRequest(c, ReasonInvalidRequest, "file_hash must be lowercase 32-hex")
		return
	}
	normalized, target, err := deps.FileSpace.Resolve(principal.ID, request.ObjectKey)
	if err != nil || normalized == "/" {
		BadRequest(c, "INVALID_PATH", "invalid object_key")
		return
	}
	metadata, ok := requireClientLogMetadata(c)
	if !ok {
		return
	}
	logContext, err := newFileLogContext(c, taskID, businessevents.ActionUpload, normalized, request.FileSize, principal, metadata)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot construct file log context")
		return
	}
	registered, err := newBusinessEvent(businessevents.EventFileRegistered, logContext.Correlation, logContext.FileKey, logContext.registeredPayload())
	if err != nil || !requireBusinessEvent(c, registered) {
		return
	}
	if info, statErr := os.Lstat(target); statErr == nil {
		if !info.Mode().IsRegular() {
			writeError(c, http.StatusUnprocessableEntity, "UNSUPPORTED_FILE_TYPE", "upload target must be a regular file or missing")
			return
		}
		if !request.Overwrite {
			if info.Size() != request.FileSize {
				c.JSON(http.StatusOK, gin.H{"code": http.StatusOK, "status": "target_exists", "object_key": normalized, "target_size": info.Size()})
				return
			}
			result, err := deps.Hashes.Lookup(c.Request.Context(), principal.ID, normalized, target)
			if err != nil {
				InternalServerError(c, ReasonInternalError, "cannot query target hash")
				return
			}
			if result.Pending {
				c.Header("Retry-After", "5")
				writeError(c, http.StatusAccepted, "HASH_PENDING", "target hash is pending")
				return
			}
			if result.Unavailable {
				writeError(c, http.StatusServiceUnavailable, "HASH_UNAVAILABLE", "target hash is unavailable")
				return
			}
			if result.Algorithm == request.HashAlgorithm && result.Hash == request.FileHash {
				finished, eventErr := newBusinessEvent(businessevents.EventUploadFinished, logContext.Correlation, logContext.FileKey, businessevents.UploadFinishedPayload{Result: businessevents.UploadAlreadyPresent})
				if eventErr != nil || !requireBusinessEvent(c, finished) {
					return
				}
			}
			c.JSON(http.StatusOK, gin.H{"code": http.StatusOK, "status": "target_exists", "object_key": normalized, "target_size": info.Size(), "target_hash": result.Hash, "hash_algorithm": result.Algorithm})
			return
		}
	} else if !os.IsNotExist(statErr) {
		InternalServerError(c, ReasonInternalError, "cannot inspect upload target")
		return
	}

	sessionID := uuid.NewString()
	chunkCount64 := request.FileSize / canonicalUploadChunkSize
	if request.FileSize%canonicalUploadChunkSize != 0 {
		chunkCount64++
	}
	if chunkCount64 > int64(^uint(0)>>1) {
		BadRequest(c, ReasonInvalidRequest, "file produces too many chunks")
		return
	}
	cacheDir := filepath.Join(deps.Config.Server.TempRoot, principal.ID)
	cachePath := filepath.Join(cacheDir, sessionID)
	now := deps.Now().UTC()
	session := store.CanonicalUploadSession{
		SessionID: sessionID, TaskID: taskID, TaskPID: logContext.Correlation.TaskPID, EnterpriseID: logContext.Correlation.EnterpriseID, FileKey: logContext.FileKey, PrincipalID: principal.ID, ObjectKey: normalized,
		FileSize: request.FileSize, FileHash: request.FileHash, HashAlgorithm: request.HashAlgorithm, Overwrite: request.Overwrite,
		ChunkSize: canonicalUploadChunkSize, ChunkCount: int(chunkCount64),
		Status: "active", CachePath: cachePath, CreatedAt: now,
	}
	if err := deps.Redis.CreateCanonicalUpload(c.Request.Context(), session, uploadRetention()); err != nil {
		InternalServerError(c, ReasonInternalError, "cannot create upload session")
		return
	}
	if err := os.MkdirAll(cacheDir, 0o700); err != nil {
		_ = deps.Redis.DeleteCanonicalUpload(context.Background(), sessionID)
		InternalServerError(c, ReasonInternalError, "cannot create upload cache directory")
		return
	}
	_ = os.Chmod(cacheDir, 0o700)
	cache, err := os.OpenFile(cachePath, os.O_CREATE|os.O_EXCL|os.O_RDWR, 0o600)
	if err != nil {
		_ = deps.Redis.DeleteCanonicalUpload(context.Background(), sessionID)
		InternalServerError(c, ReasonInternalError, "cannot create upload cache")
		return
	}
	_ = cache.Close()
	location := "/qtserver/v1/uploads/" + sessionID
	c.Header("Location", location)
	c.JSON(http.StatusCreated, gin.H{
		"code": http.StatusCreated, "status": "active", "session_id": sessionID,
		"object_key": normalized, "file_size": request.FileSize,
		"chunk_size": canonicalUploadChunkSize, "chunk_count": int(chunkCount64),
		"chunk_hash_algorithm": filehash.ChunkAlgorithm, "file_hash_algorithm": filehash.LayeredAlgorithm,
	})
}

func CanonicalUploadGetHandler(c *gin.Context) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	session, ok := loadOwnedUpload(c, principal, false)
	if !ok {
		return
	}
	if session.Status == "committed" && session.Result != nil {
		reconcileCommittedUploadCache(c, session)
		c.JSON(http.StatusOK, session.Result)
		return
	}
	chunks, err := deps.Redis.ListCanonicalChunks(c.Request.Context(), session.SessionID)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot read upload chunks")
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code": http.StatusOK, "status": session.Status, "session_id": session.SessionID,
		"object_key": session.ObjectKey, "file_size": session.FileSize,
		"chunk_size": session.ChunkSize, "chunk_count": session.ChunkCount, "chunks": chunks,
	})
}

func CanonicalUploadChunkGetHandler(c *gin.Context) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	session, ok := loadOwnedUpload(c, principal, false)
	if !ok {
		return
	}
	index, ok := parseCanonicalChunkIndex(c, session)
	if !ok {
		return
	}
	chunk, err := deps.Redis.GetCanonicalChunk(c.Request.Context(), session.SessionID, index)
	if errors.Is(err, store.ErrNotFound) {
		chunk = store.CanonicalChunk{State: "partial"}
	} else if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot read chunk state")
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": http.StatusOK, "session_id": session.SessionID, "chunk_index": index, "state": chunk.State, "stored": chunk.Stored, "chunk_size": sessionChunkBytes(session, index), "hash": chunk.Hash})
}

func CanonicalUploadPatchHandler(c *gin.Context) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	taskID, ok := requireTaskID(c, c.GetHeader("X-Task-ID"))
	if !ok {
		return
	}
	_ = taskID
	if c.Request.ContentLength < 0 {
		writeError(c, http.StatusLengthRequired, "CONTENT_LENGTH_REQUIRED", "Content-Length is required")
		return
	}
	if c.Request.ContentLength == 0 {
		BadRequest(c, ReasonInvalidRequest, "Content-Length must be positive")
		return
	}
	mediaType, _, mediaErr := mime.ParseMediaType(c.GetHeader("Content-Type"))
	if mediaErr != nil || !strings.EqualFold(mediaType, "application/octet-stream") {
		writeError(c, http.StatusUnsupportedMediaType, "UNSUPPORTED_MEDIA_TYPE", "Content-Type must be application/octet-stream")
		return
	}
	session, ok := loadOwnedUpload(c, principal, false)
	if !ok {
		return
	}
	index, ok := parseCanonicalChunkIndex(c, session)
	if !ok {
		return
	}
	offset, err := strconv.ParseInt(c.GetHeader("Upload-Offset"), 10, 64)
	if err != nil || offset < 0 {
		BadRequest(c, ReasonInvalidRequest, "Upload-Offset must be a non-negative integer")
		return
	}
	chunk, err := deps.Redis.GetCanonicalChunk(c.Request.Context(), session.SessionID, index)
	if errors.Is(err, store.ErrNotFound) {
		chunk = store.CanonicalChunk{State: "partial"}
	} else if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot read chunk state")
		return
	}
	if chunk.State == "complete" || chunk.State == "verified" {
		writeUploadOffsetHeaders(c, chunk)
		c.Status(http.StatusNoContent)
		return
	}
	if offset > chunk.Stored {
		writeUploadOffsetHeaders(c, chunk)
		writeErrorWithExtras(c, http.StatusConflict, "CHUNK_OFFSET_MISMATCH", "upload offset is ahead of stored bytes", map[string]any{"correct_offset": chunk.Stored})
		return
	}
	chunkBytes := sessionChunkBytes(session, index)
	if offset > chunkBytes || c.Request.ContentLength > chunkBytes-offset {
		writeError(c, http.StatusRequestEntityTooLarge, "CHUNK_TOO_LARGE", "request body exceeds chunk boundary")
		return
	}
	rangeStart := int64(index)*session.ChunkSize + offset
	rangeEnd := rangeStart + c.Request.ContentLength
	position := offset
	confirmed := chunk.Stored
	result := businessevents.ChunkFailed
	defer func() {
		finished, eventErr := newBusinessEvent(
			businessevents.EventUploadChunkFinished,
			sessionTaskCorrelation(session), session.FileKey,
			businessevents.UploadChunkFinishedPayload{
				ChunkIndex: index, RangeStart: rangeStart, RangeEnd: rangeEnd,
				ActualBytes: position - offset, Result: result,
			},
		)
		if eventErr == nil {
			appendObservedBusinessEvent(c, finished)
		}
	}()
	cache, err := os.OpenFile(session.CachePath, os.O_WRONLY, 0)
	if err != nil {
		invalidateMissingCache(c, session, err)
		return
	}
	defer cache.Close()
	remaining := c.Request.ContentLength
	buffer := make([]byte, 1<<20)
	lastCheckpoint := time.Now()
	for remaining > 0 {
		readSize := int64(len(buffer))
		if remaining < readSize {
			readSize = remaining
		}
		n, readErr := io.ReadFull(c.Request.Body, buffer[:readSize])
		if n > 0 {
			written, writeErr := cache.WriteAt(buffer[:n], int64(index)*session.ChunkSize+position)
			if writeErr != nil || written != n {
				if errors.Is(writeErr, syscall.ENOSPC) {
					writeError(c, http.StatusInsufficientStorage, "INSUFFICIENT_STORAGE", "upload cache is full")
				} else {
					InternalServerError(c, ReasonInternalError, "cannot write upload cache")
				}
				return
			}
			position += int64(n)
			remaining -= int64(n)
			if position > confirmed {
				confirmed = position
			}
		}
		if readErr != nil {
			result = businessevents.ChunkInterrupted
			return
		}
		if time.Since(lastCheckpoint) >= 5*time.Second {
			chunk.Stored = confirmed
			chunk.State = "partial"
			if err := deps.Redis.SetCanonicalChunk(c.Request.Context(), session.SessionID, index, chunk, uploadRetention()); err != nil {
				if errors.Is(err, store.ErrNotFound) {
					NotFound(c, "SESSION_NOT_FOUND", "upload session not found")
					return
				}
				ReportFatalDependency(err)
				InternalServerError(c, ReasonInternalError, "cannot checkpoint upload progress")
				return
			}
			lastCheckpoint = time.Now()
		}
	}
	chunk.Stored = confirmed
	if confirmed == chunkBytes {
		chunk.State = "complete"
	} else {
		chunk.State = "partial"
	}
	if err := deps.Redis.SetCanonicalChunk(c.Request.Context(), session.SessionID, index, chunk, uploadRetention()); err != nil {
		if errors.Is(err, store.ErrNotFound) {
			NotFound(c, "SESSION_NOT_FOUND", "upload session not found")
			return
		}
		ReportFatalDependency(err)
		InternalServerError(c, ReasonInternalError, "cannot checkpoint upload progress")
		return
	}
	writeUploadOffsetHeaders(c, chunk)
	result = businessevents.ChunkSucceeded
	c.Status(http.StatusNoContent)
}

func CanonicalUploadFinalizeHandler(c *gin.Context) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	taskID, ok := requireTaskID(c, c.GetHeader("X-Task-ID"))
	if !ok {
		return
	}
	_ = taskID
	var request canonicalFinalizeRequest
	if err := decodeStrictJSON(c, &request, false); err != nil {
		respondHTTPError(c, err)
		return
	}
	if !lowercaseChunkHash.MatchString(request.ChunkHash) {
		BadRequest(c, "INVALID_CHUNK_HASH", "chunk_hash must be lowercase 32-hex")
		return
	}
	session, ok := loadOwnedUpload(c, principal, false)
	if !ok {
		return
	}
	index, ok := parseCanonicalChunkIndex(c, session)
	if !ok {
		return
	}
	chunk, err := deps.Redis.GetCanonicalChunk(c.Request.Context(), session.SessionID, index)
	if errors.Is(err, store.ErrNotFound) {
		chunk = store.CanonicalChunk{State: "partial"}
	} else if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot read chunk state")
		return
	}
	if chunk.State == "verified" {
		if chunk.Hash == request.ChunkHash {
			c.JSON(http.StatusOK, gin.H{"code": http.StatusOK, "state": "verified", "chunk_hash": chunk.Hash})
			return
		}
		Conflict(c, "CHUNK_HASH_CONFLICT", "chunk was verified with a different hash")
		return
	}
	if chunk.Stored != sessionChunkBytes(session, index) || chunk.State != "complete" {
		Conflict(c, "CHUNK_INCOMPLETE", "chunk is not complete")
		return
	}
	verifyResult := businessevents.VerificationFailed
	defer func() {
		finished, eventErr := newBusinessEvent(
			businessevents.EventUploadVerifyFinished,
			sessionTaskCorrelation(session), session.FileKey,
			businessevents.UploadVerifyFinishedPayload{ChunkIndex: index, VerificationResult: verifyResult},
		)
		if eventErr == nil {
			appendObservedBusinessEvent(c, finished)
		}
	}()
	cache, err := os.OpenFile(session.CachePath, os.O_RDWR, 0)
	if err != nil {
		invalidateMissingCache(c, session, err)
		return
	}
	defer cache.Close()
	stopTouch := keepUploadAlive(c.Request.Context(), session.SessionID)
	calculated, err := filehash.ChunkReader(io.NewSectionReader(cache, int64(index)*session.ChunkSize, sessionChunkBytes(session, index)))
	stopTouch()
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot hash upload chunk")
		return
	}
	if calculated != request.ChunkHash {
		verifyResult = businessevents.VerificationMismatched
		chunk = store.CanonicalChunk{State: "partial", Stored: 0}
		if err := deps.Redis.SetCanonicalChunk(c.Request.Context(), session.SessionID, index, chunk, uploadRetention()); err != nil {
			if errors.Is(err, store.ErrNotFound) {
				NotFound(c, "SESSION_NOT_FOUND", "upload session not found")
				return
			}
			ReportFatalDependency(err)
			InternalServerError(c, ReasonInternalError, "cannot reset mismatched chunk")
			return
		}
		writeUploadOffsetHeaders(c, chunk)
		writeErrorWithExtras(c, http.StatusConflict, "CHUNK_HASH_MISMATCH", "chunk hash mismatch", map[string]any{"calculated_hash": calculated, "correct_offset": 0})
		return
	}
	if err := syncCanonicalUploadFile(cache); err != nil {
		InternalServerError(c, ReasonInternalError, "cannot sync verified upload chunk")
		return
	}
	chunk.State, chunk.Hash = "verified", calculated
	if err := deps.Redis.SetCanonicalChunk(c.Request.Context(), session.SessionID, index, chunk, uploadRetention()); err != nil {
		if errors.Is(err, store.ErrNotFound) {
			NotFound(c, "SESSION_NOT_FOUND", "upload session not found")
			return
		}
		ReportFatalDependency(err)
		InternalServerError(c, ReasonInternalError, "cannot save verified chunk")
		return
	}
	verifyResult = businessevents.VerificationMatched
	c.JSON(http.StatusOK, gin.H{"code": http.StatusOK, "state": "verified", "chunk_hash": calculated})
}

func syncCanonicalUploadFile(file *os.File) error {
	if deps != nil && deps.SyncUploadFile != nil {
		return deps.SyncUploadFile(file)
	}
	return file.Sync()
}

func CanonicalUploadCompleteHandler(c *gin.Context) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	taskID, ok := requireTaskID(c, c.GetHeader("X-Task-ID"))
	if !ok {
		return
	}
	_ = taskID
	var request canonicalCompleteRequest
	if err := decodeStrictJSON(c, &request, true); err != nil {
		respondHTTPError(c, err)
		return
	}
	session, ok := loadOwnedUpload(c, principal, false)
	if !ok {
		return
	}
	timings := canonicalCompleteTimings{started: time.Now()}
	defer timings.log(c, session.SessionID)
	stopTouch := keepUploadAlive(c.Request.Context(), session.SessionID)
	defer stopTouch()
	sessionLockStarted := time.Now()
	sessionLock, err := acquireSessionLock(c.Request.Context(), session.SessionID)
	timings.sessionLockWait = time.Since(sessionLockStarted)
	if err != nil {
		if isLockConflict(err) {
			c.Header("Retry-After", "1")
			Conflict(c, "SESSION_BUSY", "upload session is busy")
		} else {
			InternalServerError(c, ReasonInternalError, "cannot acquire upload session lock")
		}
		return
	}
	defer sessionLock.release()
	session, ok = loadOwnedUpload(c, principal, false)
	if !ok {
		return
	}
	if session.Status == "committed" && session.Result != nil {
		sessionLock.release()
		reconcileCommittedUploadCache(c, session)
		businessLogStarted := time.Now()
		if !emitUploadCommitted(c, session) {
			timings.businessLog = time.Since(businessLogStarted)
			return
		}
		timings.businessLog = time.Since(businessLogStarted)
		c.JSON(http.StatusOK, session.Result)
		return
	}
	prepareStarted := time.Now()
	chunks, err := deps.Redis.ListCanonicalChunks(c.Request.Context(), session.SessionID)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot read upload chunks")
		return
	}
	verified := 0
	hashes := make(map[string]string, session.ChunkCount)
	for index := 0; index < session.ChunkCount; index++ {
		chunk, exists := chunks[strconv.Itoa(index)]
		if exists && chunk.State == "verified" {
			verified++
			hashes[strconv.Itoa(index)] = chunk.Hash
		}
	}
	if verified != session.ChunkCount {
		writeErrorWithExtras(c, http.StatusConflict, "UPLOAD_INCOMPLETE", "not all chunks are verified", map[string]any{"total_chunks": session.ChunkCount, "verified_chunks": verified})
		return
	}
	fileHash, _, err := filehash.LayeredFromChunkHashes(hashes, session.ChunkCount)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot combine chunk hashes")
		return
	}
	if session.HashAlgorithm != filehash.LayeredAlgorithm || fileHash != session.FileHash {
		Conflict(c, "FILE_HASH_MISMATCH", "verified chunks do not match the upload init file hash")
		return
	}
	effectiveOverwrite := session.Overwrite || request.Overwrite
	if session.PublishIntent == nil {
		if err := deps.FileSpace.ApplyFilePolicy(session.CachePath, session.ObjectKey, principal.Type == models.PrincipalAnonymous); err != nil {
			InternalServerError(c, ReasonInternalError, "cannot apply published file policy")
			return
		}
	}
	timings.prepare += time.Since(prepareStarted)
	cacheSyncStarted := time.Now()
	cache, err := os.OpenFile(session.CachePath, os.O_RDWR, 0)
	if err != nil {
		invalidateMissingCache(c, session, err)
		return
	}
	if err := syncCanonicalUploadFile(cache); err != nil {
		_ = cache.Close()
		timings.cacheSync = time.Since(cacheSyncStarted)
		InternalServerError(c, ReasonInternalError, "cannot sync upload cache")
		return
	}
	_ = cache.Close()
	timings.cacheSync = time.Since(cacheSyncStarted)
	fingerprintStarted := time.Now()
	cacheFP, err := filehash.FingerprintPath(session.CachePath)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot fingerprint upload cache")
		return
	}
	timings.prepare += time.Since(fingerprintStarted)

	namespaceWaitStarted := time.Now()
	namespaceLock, err := acquireNamespaceLock(c.Request.Context(), principal.ID)
	timings.namespaceLockWait = time.Since(namespaceWaitStarted)
	if err != nil {
		if isLockConflict(err) {
			c.Header("Retry-After", "1")
			Conflict(c, "NAMESPACE_BUSY", "principal namespace is busy")
		} else {
			InternalServerError(c, ReasonInternalError, "cannot acquire namespace lock")
		}
		return
	}
	defer namespaceLock.release()

	namespacePrepareStarted := time.Now()
	_, target, err := deps.FileSpace.Resolve(principal.ID, session.ObjectKey)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot resolve upload target")
		return
	}
	if session.PublishIntent != nil && !validCanonicalPublishIntent(session, target) {
		InternalServerError(c, ReasonInternalError, "invalid upload publish intent")
		return
	}
	publishedBySession := false
	if info, statErr := os.Lstat(target); statErr == nil {
		if !info.Mode().IsRegular() {
			writeError(c, http.StatusUnprocessableEntity, "UNSUPPORTED_FILE_TYPE", "upload target is not a regular file")
			return
		}
		if session.PublishIntent != nil {
			cacheInfo, cacheErr := os.Lstat(session.CachePath)
			if cacheErr == nil && cacheInfo.Mode().IsRegular() && os.SameFile(cacheInfo, info) {
				publishedBySession = true
			} else if cacheErr != nil && !os.IsNotExist(cacheErr) {
				InternalServerError(c, ReasonInternalError, "cannot inspect upload cache")
				return
			}
		}
		if !effectiveOverwrite && !publishedBySession {
			Conflict(c, ReasonConflict, "target already exists")
			return
		}
	} else if !os.IsNotExist(statErr) {
		InternalServerError(c, ReasonInternalError, "cannot inspect upload target")
		return
	}
	createdPaths, err := deps.FileSpace.EnsureParents(principal.ID, session.ObjectKey, principal.Type == models.PrincipalAnonymous, false)
	if err != nil {
		respondFileSpaceError(c, err)
		return
	}
	generation, err := deps.Hashes.BeginKnownMutation(c.Request.Context(), principal.ID, session.ObjectKey, cacheFP)
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot prepare published hash state")
		return
	}
	timings.namespacePrepare = time.Since(namespacePrepareStarted)
	if !sessionLock.valid(c.Request.Context()) || !namespaceLock.valid(c.Request.Context()) {
		if len(createdPaths) > 0 {
			writeErrorWithExtras(c, http.StatusInternalServerError, "NAMESPACE_OPERATION_PARTIAL", "namespace lock was lost after creating directories", map[string]any{"partial": true})
			return
		}
		Conflict(c, "NAMESPACE_LOCK_LOST", "namespace lock was lost")
		return
	}
	if !effectiveOverwrite && session.PublishIntent == nil {
		session.PublishIntent = &store.CanonicalUploadPublishIntent{
			TargetPath: target,
			CachePath:  session.CachePath,
			FileSize:   session.FileSize,
			FileHash:   session.FileHash,
			Method:     "hard_link",
		}
		if err := deps.Redis.SetCanonicalUpload(c.Request.Context(), session, uploadRetention()); err != nil {
			ReportFatalDependency(err)
			InternalServerError(c, ReasonInternalError, "cannot save upload publish intent")
			return
		}
	}
	publishStarted := time.Now()
	if !publishedBySession {
		if effectiveOverwrite {
			err = os.Rename(session.CachePath, target)
		} else {
			err = filespace.PublishRegularNoReplace(session.CachePath, target)
		}
	}
	timings.publish = time.Since(publishStarted)
	if err != nil {
		var typed *filespace.Error
		switch {
		case errors.Is(err, syscall.EXDEV):
			InternalServerError(c, "CROSS_DEVICE_PUBLISH", "cache and target are on different filesystems")
			return
		case errors.Is(err, os.ErrExist):
			if same, sameErr := sameRegularFile(session.CachePath, target); sameErr == nil && same {
				publishedBySession = true
				break
			}
			Conflict(c, ReasonConflict, "target already exists")
			return
		case errors.As(err, &typed):
			InternalServerError(c, typed.Reason, typed.Error())
			return
		default:
			InternalServerError(c, ReasonInternalError, "cannot publish upload")
			return
		}
	}
	if err := filespace.FsyncDirectory(filepath.Dir(target)); err != nil {
		getLogger(c).Error("fsync parent after upload publish", "object_key", session.ObjectKey, "error", err)
	}
	result := &store.CanonicalUploadResult{Code: http.StatusOK, Status: "committed", SessionID: session.SessionID, ObjectKey: session.ObjectKey, FileSize: session.FileSize, FileHash: fileHash, HashAlgorithm: filehash.LayeredAlgorithm, CommittedAt: deps.Now().UTC()}
	session.Status, session.Result = "committed", result
	session.PublishIntent = nil
	redisCommitStarted := time.Now()
	committedSaved := false
	if err := deps.Redis.SetCanonicalUpload(c.Request.Context(), session, uploadRetention()); err != nil {
		ReportFatalDependency(err)
	} else {
		committedSaved = true
	}
	finalFP, fpErr := filehash.FingerprintPath(target)
	if fpErr == nil {
		if _, commitErr := deps.Hashes.CommitKnown(c.Request.Context(), principal.ID, session.ObjectKey, generation, finalFP, fileHash); commitErr != nil {
			ReportFatalDependency(commitErr)
		}
	} else {
		getLogger(c).Error("fingerprint published upload", "object_key", session.ObjectKey, "error", fpErr)
		if invalidateErr := deps.Hashes.Invalidate(c.Request.Context(), principal.ID, session.ObjectKey); invalidateErr != nil {
			ReportFatalDependency(invalidateErr)
		}
	}
	timings.redisCommit = time.Since(redisCommitStarted)

	namespaceLock.release()
	sessionLock.release()
	if committedSaved {
		cleanupUploadCache(c, session)
	}
	businessLogStarted := time.Now()
	if !emitUploadCommitted(c, session) {
		timings.businessLog = time.Since(businessLogStarted)
		return
	}
	timings.businessLog = time.Since(businessLogStarted)
	c.JSON(http.StatusOK, result)
}

type canonicalCompleteTimings struct {
	started           time.Time
	sessionLockWait   time.Duration
	prepare           time.Duration
	cacheSync         time.Duration
	namespaceLockWait time.Duration
	namespacePrepare  time.Duration
	publish           time.Duration
	redisCommit       time.Duration
	businessLog       time.Duration
}

func (timings *canonicalCompleteTimings) log(c *gin.Context, sessionID string) {
	if timings == nil || timings.started.IsZero() {
		return
	}
	total := time.Since(timings.started)
	args := []any{
		"session_id", sessionID,
		"status", c.Writer.Status(),
		"total_ms", total.Milliseconds(),
		"session_lock_wait_ms", timings.sessionLockWait.Milliseconds(),
		"prepare_ms", timings.prepare.Milliseconds(),
		"cache_sync_ms", timings.cacheSync.Milliseconds(),
		"namespace_lock_wait_ms", timings.namespaceLockWait.Milliseconds(),
		"namespace_prepare_ms", timings.namespacePrepare.Milliseconds(),
		"publish_ms", timings.publish.Milliseconds(),
		"redis_commit_ms", timings.redisCommit.Milliseconds(),
		"business_log_ms", timings.businessLog.Milliseconds(),
	}
	if total >= time.Second {
		getLogger(c).Warn("slow canonical upload complete", args...)
		return
	}
	getLogger(c).Debug("canonical upload complete", args...)
}

func emitUploadCommitted(c *gin.Context, session store.CanonicalUploadSession) bool {
	if session.Result == nil {
		return false
	}
	committedAt := session.Result.CommittedAt.UTC()
	if committedAt.IsZero() {
		committedAt = session.CreatedAt.UTC()
	}
	event, err := businessevents.NewEnvelopeWithCorrelation(
		businessevents.EventUploadFinished, committedAt,
		sessionTaskCorrelation(session), session.FileKey,
		businessevents.UploadFinishedPayload{Result: businessevents.UploadCommitted},
	)
	if err != nil {
		handleBusinessLogError(c, err)
		return false
	}
	return requireBusinessEvent(c, event)
}

func sessionTaskCorrelation(session store.CanonicalUploadSession) businessevents.TaskCorrelation {
	return businessevents.TaskCorrelation{
		TaskID:       session.TaskID,
		TaskPID:      session.TaskPID,
		EnterpriseID: session.EnterpriseID,
	}
}

func CanonicalUploadCancelHandler(c *gin.Context)  { canonicalTerminalDelete(c, false) }
func CanonicalUploadReleaseHandler(c *gin.Context) { canonicalTerminalDelete(c, true) }

func canonicalTerminalDelete(c *gin.Context, release bool) {
	principal, ok := requireWritePrincipal(c)
	if !ok {
		return
	}
	taskID, ok := requireTaskID(c, c.GetHeader("X-Task-ID"))
	if !ok {
		return
	}
	_ = taskID
	rawID := c.Param("session_id")
	if !validSessionID(rawID) {
		c.Status(http.StatusNoContent)
		return
	}
	session, err := deps.Redis.GetCanonicalUpload(c.Request.Context(), rawID)
	if errors.Is(err, store.ErrNotFound) || (err == nil && session.PrincipalID != principal.ID) {
		c.Status(http.StatusNoContent)
		return
	}
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot read upload session")
		return
	}
	lock, err := acquireSessionLock(c.Request.Context(), rawID)
	if err != nil {
		if isLockConflict(err) {
			c.Header("Retry-After", "1")
			Conflict(c, "SESSION_BUSY", "upload session is busy")
		} else {
			InternalServerError(c, ReasonInternalError, "cannot acquire upload session lock")
		}
		return
	}
	defer lock.release()
	session, err = deps.Redis.GetCanonicalUpload(c.Request.Context(), rawID)
	if errors.Is(err, store.ErrNotFound) || (err == nil && session.PrincipalID != principal.ID) {
		c.Status(http.StatusNoContent)
		return
	}
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot read upload session")
		return
	}
	if release && session.Status != "committed" {
		Conflict(c, "SESSION_NOT_COMMITTED", "active session cannot be released")
		return
	}
	if !release && session.Status == "committed" {
		Conflict(c, "SESSION_COMMITTED", "committed session cannot be cancelled")
		return
	}
	if !lock.valid(c.Request.Context()) {
		Conflict(c, "NAMESPACE_LOCK_LOST", "upload session lock was lost")
		return
	}
	if !release && session.PublishIntent != nil {
		_, target, resolveErr := deps.FileSpace.Resolve(session.PrincipalID, session.ObjectKey)
		if resolveErr != nil || !validCanonicalPublishIntent(session, target) {
			InternalServerError(c, ReasonInternalError, "invalid upload publish intent")
			return
		}
		targetInfo, targetErr := os.Lstat(target)
		if targetErr == nil {
			cacheInfo, cacheErr := os.Lstat(session.CachePath)
			if cacheErr != nil || (cacheInfo.Mode().IsRegular() && targetInfo.Mode().IsRegular() && os.SameFile(cacheInfo, targetInfo)) {
				c.Header("Retry-After", "1")
				Conflict(c, "SESSION_BUSY", "upload publish is being committed")
				return
			}
		} else if !os.IsNotExist(targetErr) {
			InternalServerError(c, ReasonInternalError, "cannot inspect upload target")
			return
		}
	}
	if release {
		reconcileCommittedUploadCache(c, session)
	} else {
		cleanupUploadCache(c, session)
	}
	if err := deps.Redis.DeleteCanonicalUpload(c.Request.Context(), rawID); err != nil {
		InternalServerError(c, ReasonInternalError, "cannot delete upload session")
		return
	}
	c.Status(http.StatusNoContent)
}

func loadOwnedUpload(c *gin.Context, principal *Principal, allowMissing bool) (store.CanonicalUploadSession, bool) {
	id := c.Param("session_id")
	if !validSessionID(id) {
		if !allowMissing {
			NotFound(c, "SESSION_NOT_FOUND", "upload session not found")
		}
		return store.CanonicalUploadSession{}, false
	}
	session, err := deps.Redis.GetCanonicalUpload(c.Request.Context(), id)
	if errors.Is(err, store.ErrNotFound) || (err == nil && session.PrincipalID != principal.ID) {
		if !allowMissing {
			NotFound(c, "SESSION_NOT_FOUND", "upload session not found")
		}
		return store.CanonicalUploadSession{}, false
	}
	if err != nil {
		InternalServerError(c, ReasonInternalError, "cannot read upload session")
		return store.CanonicalUploadSession{}, false
	}
	if session.Status == "active" {
		if info, statErr := os.Lstat(session.CachePath); statErr != nil || !info.Mode().IsRegular() {
			if deleteErr := deps.Redis.DeleteCanonicalUpload(context.Background(), session.SessionID); deleteErr != nil {
				ReportFatalDependency(deleteErr)
				InternalServerError(c, ReasonInternalError, "cannot invalidate upload session")
				return store.CanonicalUploadSession{}, false
			}
			NotFound(c, "SESSION_NOT_FOUND", "upload session not found")
			return store.CanonicalUploadSession{}, false
		}
	}
	return session, true
}

func sameRegularFile(firstPath, secondPath string) (bool, error) {
	first, err := os.Lstat(firstPath)
	if err != nil {
		return false, err
	}
	second, err := os.Lstat(secondPath)
	if err != nil {
		return false, err
	}
	if !first.Mode().IsRegular() || !second.Mode().IsRegular() {
		return false, nil
	}
	return os.SameFile(first, second), nil
}

func validCanonicalPublishIntent(session store.CanonicalUploadSession, target string) bool {
	intent := session.PublishIntent
	return intent != nil &&
		intent.Method == "hard_link" &&
		intent.TargetPath == target &&
		intent.CachePath == session.CachePath &&
		intent.FileSize == session.FileSize &&
		intent.FileHash == session.FileHash
}

func cleanupUploadCache(c *gin.Context, session store.CanonicalUploadSession) bool {
	err := os.Remove(session.CachePath)
	if err == nil {
		return true
	}
	if !os.IsNotExist(err) {
		getLogger(c).Warn("remove upload cache", "session_id", session.SessionID, "error", err)
	}
	return false
}

func reconcileCommittedUploadCache(c *gin.Context, session store.CanonicalUploadSession) {
	if !cleanupUploadCache(c, session) || session.Result == nil {
		return
	}
	_, target, err := deps.FileSpace.Resolve(session.PrincipalID, session.ObjectKey)
	if err != nil {
		getLogger(c).Error("resolve committed upload target", "session_id", session.SessionID, "error", err)
		return
	}
	fingerprint, err := filehash.FingerprintPath(target)
	if err != nil {
		getLogger(c).Error("fingerprint committed upload after cache cleanup", "session_id", session.SessionID, "error", err)
		if invalidateErr := deps.Hashes.Invalidate(c.Request.Context(), session.PrincipalID, session.ObjectKey); invalidateErr != nil {
			ReportFatalDependency(invalidateErr)
		}
		return
	}
	generation, err := deps.Hashes.BeginKnownMutation(c.Request.Context(), session.PrincipalID, session.ObjectKey, fingerprint)
	if err != nil {
		ReportFatalDependency(err)
		return
	}
	if _, err := deps.Hashes.CommitKnown(c.Request.Context(), session.PrincipalID, session.ObjectKey, generation, fingerprint, session.Result.FileHash); err != nil {
		ReportFatalDependency(err)
	}
}

func validSessionID(raw string) bool {
	if len(raw) != 36 || strings.ToLower(raw) != raw {
		return false
	}
	parsed, err := uuid.Parse(raw)
	return err == nil && parsed.Version() == 4 && parsed.String() == raw
}

func parseCanonicalChunkIndex(c *gin.Context, session store.CanonicalUploadSession) (int, bool) {
	index64, err := strconv.ParseUint(c.Param("chunk_index"), 10, strconv.IntSize)
	if err != nil || index64 >= uint64(session.ChunkCount) {
		BadRequest(c, ReasonInvalidRequest, "invalid chunk index")
		return 0, false
	}
	return int(index64), true
}

func sessionChunkBytes(session store.CanonicalUploadSession, index int) int64 {
	start := int64(index) * session.ChunkSize
	return min(session.ChunkSize, session.FileSize-start)
}

func writeUploadOffsetHeaders(c *gin.Context, chunk store.CanonicalChunk) {
	c.Header("Upload-Offset", strconv.FormatInt(chunk.Stored, 10))
	c.Header("Upload-State", chunk.State)
}

func uploadRetention() time.Duration {
	return time.Duration(deps.Config.Transfer.UploadSessionRetentionSeconds) * time.Second
}

func invalidateMissingCache(c *gin.Context, session store.CanonicalUploadSession, err error) {
	if deleteErr := deps.Redis.DeleteCanonicalUpload(context.Background(), session.SessionID); deleteErr != nil {
		ReportFatalDependency(deleteErr)
		InternalServerError(c, ReasonInternalError, "cannot invalidate upload session")
		return
	}
	getLogger(c).Warn("upload cache unavailable; session invalidated", "session_id", session.SessionID, "error", err)
	NotFound(c, "SESSION_NOT_FOUND", "upload session not found")
}

func keepUploadAlive(ctx context.Context, sessionID string) func() {
	keepCtx, cancel := context.WithCancel(ctx)
	done := make(chan struct{})
	go func() {
		defer close(done)
		ticker := time.NewTicker(10 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-keepCtx.Done():
				return
			case <-ticker.C:
				if err := deps.Redis.TouchCanonicalUpload(keepCtx, sessionID, uploadRetention()); err != nil {
					if !errors.Is(err, store.ErrNotFound) && keepCtx.Err() == nil {
						ReportFatalDependency(err)
					}
					return
				}
			}
		}
	}()
	return func() { cancel(); <-done }
}
