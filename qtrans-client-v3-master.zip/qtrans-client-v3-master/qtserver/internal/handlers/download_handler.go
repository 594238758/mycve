package handlers

import (
	"fmt"
	"mime"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"qtserver/internal/businessevents"
	"qtserver/internal/models"

	"github.com/gin-gonic/gin"
)

func DownloadHandler(c *gin.Context) {
	logger := getLogger(c)
	ctx := c.Request.Context()
	principal, err := authenticateReadPrincipal(ctx, c.GetHeader("Authorization"))
	if err != nil {
		handleIdentityError(c, logger, err)
		return
	}
	taskID, expiresAt, hmacValue, err := resolveTransferGrantAccess(c)
	if err != nil {
		BadRequest(c, ReasonInvalidRequest, "grant is required")
		return
	}
	if deps.Now().Unix() > expiresAt {
		Gone(c, ReasonGrantExpired, "download grant expired")
		return
	}

	objectKey, physical, err := deps.FileSpace.Resolve(principal.ID, "/"+strings.TrimPrefix(c.Param("objectKey"), "/"))
	if err != nil || objectKey == "/" {
		BadRequest(c, "INVALID_PATH", "invalid object_key")
		return
	}

	// HMAC self-verification
	if !verifyGrantHMAC(taskID, objectKey, models.TransferGrantDownload, expiresAt, principal.ID, hmacValue) {
		Forbidden(c, ReasonForbidden, "invalid download grant")
		return
	}

	openedFile, err := os.Open(physical)
	if err != nil {
		if os.IsNotExist(err) {
			NotFound(c, ReasonNotFound, "file not found")
			return
		}
		logger.Error("stat download target failed", "taskid", taskID, "object_key", objectKey, "error", err)
		InternalServerError(c, ReasonInternalError, "failed to read target file")
		return
	}
	defer openedFile.Close()
	fileInfo, err := openedFile.Stat()
	if err != nil {
		InternalServerError(c, ReasonInternalError, "failed to inspect target file")
		return
	}
	if !fileInfo.Mode().IsRegular() {
		writeError(c, http.StatusUnprocessableEntity, "UNSUPPORTED_FILE_TYPE", "path must reference a regular file")
		return
	}
	if err := validateTransferFileSize(fileInfo.Size()); err != nil {
		FileTooLarge(c, fileInfo.Size(), transferMaxFileBytes())
		return
	}
	rangeStart, rangeEnd, expectedStatus, err := resolveDownloadRange(c.GetHeader("Range"), fileInfo.Size())
	if err != nil {
		writeError(c, http.StatusRequestedRangeNotSatisfiable, "INVALID_RANGE", "invalid Range")
		return
	}
	chunkIndex64, err := strconv.ParseInt(strings.TrimSpace(c.GetHeader("X-QT-Chunk-Index")), 10, 32)
	if err != nil || chunkIndex64 < 0 {
		BadRequest(c, ReasonInvalidRequest, "X-QT-Chunk-Index must be a non-negative integer")
		return
	}
	chunkIndex := int(chunkIndex64)
	fileKey := businessevents.FileKey(taskID, objectKey, principal.ID, businessevents.ActionDownload)
	metadata, present, err := parseClientLogMetadata(c)
	if err != nil {
		BadRequest(c, ReasonInvalidRequest, err.Error())
		return
	}
	if present > 0 {
		registered, eventErr := fileRegisteredEvent(c, taskID, businessevents.ActionDownload, objectKey, fileInfo.Size(), principal, metadata)
		if eventErr != nil {
			InternalServerError(c, ReasonInternalError, "cannot construct file registration event")
			return
		}
		if !requireBusinessEvent(c, registered) {
			return
		}
	}

	c.Header("Cache-Control", "private, no-store")
	c.Header("Content-Type", "application/octet-stream")
	c.Header("Content-Disposition", mime.FormatMediaType("attachment", map[string]string{"filename": filepath.Base(objectKey)}))
	c.Header("Accept-Ranges", "bytes")
	logger.Info("download accepted", "taskid", taskID, "object_key", objectKey, "principal_id", principal.ID, "expires_at", expiresAt)
	if deps.Config.Server.NginxDownloadEnabled() {
		internalPath, err := buildInternalDownloadURI(deps.Config.Server.NginxAcc, principal.ID, objectKey)
		if err != nil {
			logger.Error("build internal redirect failed", "taskid", taskID, "object_key", objectKey, "error", err)
			InternalServerError(c, ReasonInternalError, "failed to build internal redirect")
			return
		}
		c.Header("X-Accel-Redirect", internalPath)
		c.Header("X-QT-Log-Task-ID", taskID)
		c.Header("X-QT-Log-Task-PID", requestTaskPIDForLog(c))
		c.Header("X-QT-Log-Enterprise-ID", requestEnterpriseIDForLog(c))
		c.Header("X-QT-Log-File-Key", fileKey)
		c.Header("X-QT-Log-Chunk-Index", strconv.Itoa(chunkIndex))
		c.Header("X-QT-Log-Range-Start", strconv.FormatInt(rangeStart, 10))
		c.Header("X-QT-Log-Range-End", strconv.FormatInt(rangeEnd, 10))
		c.Header("X-QT-Log-Expected-Status", strconv.Itoa(expectedStatus))
		c.Header("X-QT-Log-Expected-Bytes", strconv.FormatInt(rangeEnd-rangeStart, 10))
		c.Status(http.StatusOK)
		return
	}
	beforeSize := c.Writer.Size()
	http.ServeContent(c.Writer, c.Request, filepath.Base(objectKey), fileInfo.ModTime(), openedFile)
	afterSize := c.Writer.Size()
	actualBytes := int64(afterSize)
	if beforeSize >= 0 && afterSize >= beforeSize {
		actualBytes = int64(afterSize - beforeSize)
	}
	status := c.Writer.Status()
	result := businessevents.ChunkInterrupted
	if status != expectedStatus {
		result = businessevents.ChunkFailed
		actualBytes = 0
	} else if actualBytes == rangeEnd-rangeStart {
		result = businessevents.ChunkSucceeded
	}
	finished, eventErr := newBusinessEvent(
		businessevents.EventDownloadChunkFinished,
		businessevents.TaskCorrelation{TaskID: taskID, TaskPID: requestTaskPIDForLog(c), EnterpriseID: requestEnterpriseIDForLog(c)},
		fileKey,
		businessevents.DownloadChunkFinishedPayload{
			ChunkIndex: chunkIndex, HTTPStatus: status, RangeStart: rangeStart, RangeEnd: rangeEnd,
			ActualBytes: actualBytes, Result: result,
		},
	)
	if eventErr == nil {
		appendObservedBusinessEvent(c, finished)
	}
}

func resolveDownloadRange(raw string, fileSize int64) (int64, int64, int, error) {
	value := strings.TrimSpace(raw)
	if value == "" {
		return 0, fileSize, http.StatusOK, nil
	}
	if !strings.HasPrefix(value, "bytes=") || strings.Contains(value, ",") || fileSize <= 0 {
		return 0, 0, 0, fmt.Errorf("unsupported range")
	}
	parts := strings.SplitN(strings.TrimPrefix(value, "bytes="), "-", 2)
	if len(parts) != 2 {
		return 0, 0, 0, fmt.Errorf("invalid range")
	}
	var start, end int64
	var err error
	if parts[0] == "" {
		suffix, parseErr := strconv.ParseInt(parts[1], 10, 64)
		if parseErr != nil || suffix <= 0 {
			return 0, 0, 0, fmt.Errorf("invalid suffix range")
		}
		suffix = min(suffix, fileSize)
		start, end = fileSize-suffix, fileSize
	} else {
		start, err = strconv.ParseInt(parts[0], 10, 64)
		if err != nil || start < 0 || start >= fileSize {
			return 0, 0, 0, fmt.Errorf("invalid range start")
		}
		end = fileSize
		if parts[1] != "" {
			inclusiveEnd, parseErr := strconv.ParseInt(parts[1], 10, 64)
			if parseErr != nil || inclusiveEnd < start {
				return 0, 0, 0, fmt.Errorf("invalid range end")
			}
			end = min(fileSize, inclusiveEnd+1)
		}
	}
	return start, end, http.StatusPartialContent, nil
}

func CalcTotalBytes(dir string) (int64, error) {
	var totalSize int64 = 0

	err := filepath.WalkDir(dir, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}

		// 只处理文件
		if d.IsDir() {
			return nil
		}

		info, err := d.Info()
		if err != nil {
			return err
		}

		size := info.Size()
		totalSize += size

		//fmt.Printf("%s %d bytes\n", path, size)
		return nil
	})

	if err != nil {
		return 0, err
	}

	return totalSize, nil
}

func ParseRangeSize(rangeHeader string) (int64, error) {
	// bytes=0-104857599
	// 基础校验
	if rangeHeader == "" {
		return 0, fmt.Errorf("empty range")
	}

	// 必须 bytes= 开头
	if !strings.HasPrefix(rangeHeader, "bytes=") {
		return 0, fmt.Errorf("invalid range prefix")
	}

	// 去掉 bytes=
	value := strings.TrimPrefix(rangeHeader, "bytes=")

	// 分割 start-end
	parts := strings.Split(value, "-")
	if len(parts) != 2 {
		return 0, fmt.Errorf("invalid range format")
	}

	// 转数字
	start, err := strconv.ParseInt(parts[0], 10, 64)
	if err != nil {
		return 0, fmt.Errorf("invalid start: %w", err)
	}

	end, err := strconv.ParseInt(parts[1], 10, 64)
	if err != nil {
		return 0, fmt.Errorf("invalid end: %w", err)
	}

	// 范围检查
	if start < 0 {
		return 0, fmt.Errorf("start cannot be negative")
	}

	if end < start {
		return 0, fmt.Errorf("end smaller than start")
	}

	// 计算大小
	size := end - start + 1

	return size, nil
}
