package handlers

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
)

type GrantSigner interface {
	Sign(payload string) string
	Verify(payload, signature string) bool
}

type HMACGrantSigner struct {
	secret []byte
}

func NewHMACGrantSigner(secret string) *HMACGrantSigner {
	return &HMACGrantSigner{secret: []byte(secret)}
}

func (s *HMACGrantSigner) Sign(payload string) string {
	mac := hmac.New(sha256.New, s.secret)
	mac.Write([]byte(payload))
	return hex.EncodeToString(mac.Sum(nil))
}

func (s *HMACGrantSigner) Verify(payload, signature string) bool {
	expected := s.Sign(payload)
	return hmac.Equal([]byte(expected), []byte(signature))
}
