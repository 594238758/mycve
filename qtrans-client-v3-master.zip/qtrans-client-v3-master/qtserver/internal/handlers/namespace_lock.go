package handlers

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"time"

	"qtserver/internal/store"
)

const (
	namespaceLockLease = 30 * time.Second
	lockRenewInterval  = 10 * time.Second
)

type renewableLock struct {
	handle      *store.LockHandle
	lost        atomic.Bool
	stop        context.CancelFunc
	done        chan struct{}
	releaseOnce sync.Once
}

func acquireNamespaceLock(ctx context.Context, principalID string) (*renewableLock, error) {
	handle, err := deps.Redis.AcquireNamespaceLock(ctx, principalID, namespaceLockLease)
	if err != nil {
		return nil, err
	}
	return startRenewableLock(ctx, handle), nil
}

func acquireSessionLock(ctx context.Context, sessionID string) (*renewableLock, error) {
	handle, err := deps.Redis.AcquireSessionOperationLock(ctx, sessionID, namespaceLockLease)
	if err != nil {
		return nil, err
	}
	return startRenewableLock(ctx, handle), nil
}

func startRenewableLock(parent context.Context, handle *store.LockHandle) *renewableLock {
	ctx, cancel := context.WithCancel(parent)
	lock := &renewableLock{handle: handle, stop: cancel, done: make(chan struct{})}
	go func() {
		defer close(lock.done)
		ticker := time.NewTicker(lockRenewInterval)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				if err := deps.Redis.RefreshLock(ctx, handle, namespaceLockLease); err != nil {
					lock.lost.Store(true)
					return
				}
				valid, err := deps.Redis.CheckLock(ctx, handle)
				if err != nil || !valid {
					lock.lost.Store(true)
					return
				}
			}
		}
	}()
	return lock
}

func (l *renewableLock) valid(ctx context.Context) bool {
	if l == nil || l.lost.Load() {
		return false
	}
	valid, err := deps.Redis.CheckLock(ctx, l.handle)
	if err != nil || !valid {
		l.lost.Store(true)
		return false
	}
	return true
}

func (l *renewableLock) release() {
	if l == nil {
		return
	}
	l.releaseOnce.Do(func() {
		l.stop()
		<-l.done
		_ = deps.Redis.ReleaseLock(context.Background(), l.handle)
	})
}

func isLockConflict(err error) bool { return errors.Is(err, store.ErrConflict) }
