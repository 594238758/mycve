package handlers

import (
	"errors"
	"io/fs"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"syscall"
)

func openDownloadPath(rootPath, normalizedPath string) (*os.File, fs.FileInfo, error) {
	fullPath := filepath.Clean(rootPath)
	if normalizedPath != "" {
		fullPath = filepath.Join(fullPath, filepath.FromSlash(normalizedPath))
	}

	info, err := os.Stat(fullPath)
	if err != nil {
		if errors.Is(err, syscall.ELOOP) {
			return nil, nil, fs.ErrNotExist
		}
		return nil, nil, err
	}
	if !info.IsDir() && !info.Mode().IsRegular() {
		return nil, nil, errUnsupportedDownloadTarget
	}

	file, err := os.Open(fullPath)
	if err != nil {
		if errors.Is(err, syscall.ELOOP) {
			return nil, nil, fs.ErrNotExist
		}
		return nil, nil, err
	}
	info, err = file.Stat()
	if err != nil {
		_ = file.Close()
		return nil, nil, err
	}
	if !info.IsDir() && !info.Mode().IsRegular() {
		_ = file.Close()
		return nil, nil, errUnsupportedDownloadTarget
	}
	return file, info, nil
}

func buildInternalDownloadURI(prefix, principalID, logicalPath string) (string, error) {
	segments := []string{url.PathEscape(principalID)}
	for _, segment := range strings.Split(strings.TrimPrefix(logicalPath, "/"), "/") {
		if segment != "" {
			segments = append(segments, url.PathEscape(segment))
		}
	}
	return strings.TrimRight(prefix, "/") + "/" + strings.Join(segments, "/"), nil
}
