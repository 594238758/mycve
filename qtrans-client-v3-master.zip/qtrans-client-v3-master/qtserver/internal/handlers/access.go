package handlers

import (
	"context"
	"errors"
	"io/fs"
	"os"
	"path/filepath"
	"strings"

	"qtserver/internal/misc"
)

var errUnsupportedHomeTarget = errors.New("unsupported home target")
var errPrivateDownloadDisabled = errors.New("private downloads disabled")

const AnonymousWriteToken = "00000000-0000-4000-8000-000000000000"

func authenticateReadPrincipal(ctx context.Context, authorization string) (*Principal, error) {
	token, err := extractIdentityToken(authorization)
	if err != nil {
		return nil, err
	}
	if token == "" {
		if deps.Config.Server.AnonymousEnabled {
			return anonymousPrincipal(), nil
		}
		return nil, ErrInvalidToken
	}
	if token == AnonymousWriteToken {
		if deps.Config.Server.AnonymousEnabled {
			return anonymousPrincipal(), nil
		}
		return nil, ErrInvalidToken
	}
	if isIdentityOff() {
		return nil, ErrInvalidToken
	}
	return resolvePrincipal(ctx, token)
}

func authenticateWritePrincipal(ctx context.Context, authorization string) (*Principal, error) {
	token, err := extractIdentityToken(authorization)
	if err != nil {
		return nil, err
	}
	if token == "" {
		return nil, ErrInvalidToken
	}
	if token == AnonymousWriteToken {
		if deps.Config.Server.AnonymousEnabled && deps.Config.Server.WriteEnabled {
			return anonymousPrincipal(), nil
		}
		return nil, ErrInvalidToken
	}
	if isIdentityOff() {
		return nil, ErrInvalidToken
	}
	return resolvePrincipal(ctx, token)
}

func authenticateRequiredPrincipal(ctx context.Context, credential string) (*Principal, error) {
	if isIdentityOff() {
		if deps.Config.Server.AnonymousEnabled {
			return anonymousPrincipal(), nil
		}
		return nil, ErrInvalidToken
	}
	token, err := extractIdentityToken(credential)
	if err != nil {
		return nil, err
	}
	return resolvePrincipal(ctx, token)
}

func authenticateOptionalPrincipal(ctx context.Context, credential string) (*Principal, error) {
	if isIdentityOff() {
		if deps.Config.Server.AnonymousEnabled {
			return anonymousPrincipal(), nil
		}
		return nil, ErrInvalidToken
	}
	token, err := extractIdentityToken(credential)
	if err != nil {
		return nil, err
	}
	if token == "" {
		return anonymousPrincipal(), nil
	}
	return resolvePrincipal(ctx, token)
}

func extractIdentityToken(value string) (string, error) {
	if !isOAuth2IntrospectionIdentity() {
		return extractBearerToken(value), nil
	}
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return "", nil
	}
	separator := strings.IndexByte(trimmed, ' ')
	if separator <= 0 || !strings.EqualFold(trimmed[:separator], "Bearer") {
		return "", ErrInvalidToken
	}
	token := strings.TrimSpace(trimmed[separator+1:])
	if !isRFC6750BearerToken(token) {
		return "", ErrInvalidToken
	}
	return token, nil
}

func isRFC6750BearerToken(token string) bool {
	if token == "" {
		return false
	}
	padding := false
	for _, char := range []byte(token) {
		if char == '=' {
			padding = true
			continue
		}
		if padding {
			return false
		}
		allowed := char >= 'A' && char <= 'Z' || char >= 'a' && char <= 'z' || char >= '0' && char <= '9'
		allowed = allowed || char == '-' || char == '.' || char == '_' || char == '~' || char == '+' || char == '/'
		if !allowed {
			return false
		}
	}
	return true
}

func resolvePrincipalHomeRoot(baseDir string, principal *Principal) (string, error) {
	ownerID, err := misc.NormalizeOwner(principal.ID)
	if err != nil {
		return "", err
	}
	return filepath.Join(filepath.Clean(baseDir), ownerID), nil
}

func authorizeHomeObjectPath(baseDir string, principal *Principal, objectKey string) (string, error) {
	rootPath, err := resolvePrincipalHomeRoot(baseDir, principal)
	if err != nil {
		return "", err
	}
	return misc.ResolveObjectPath(rootPath, objectKey)
}

func normalizeOptionalHomePath(rawPath string) (string, error) {
	trimmed := strings.TrimSpace(strings.ReplaceAll(rawPath, "\\", "/"))
	if trimmed == "" {
		return "", nil
	}
	return misc.NormalizeObjectKey(trimmed)
}

func authorizeOptionalHomePath(baseDir string, principal *Principal, rawPath string) (string, string, string, error) {
	rootPath, err := resolvePrincipalHomeRoot(baseDir, principal)
	if err != nil {
		return "", "", "", err
	}

	normalizedPath, err := normalizeOptionalHomePath(rawPath)
	if err != nil {
		return "", "", "", err
	}
	if normalizedPath == "" {
		return rootPath, "", rootPath, nil
	}

	fullPath, err := misc.ResolveObjectPath(rootPath, normalizedPath)
	if err != nil {
		return "", "", "", err
	}
	return rootPath, normalizedPath, fullPath, nil
}

func secureResolveAuthorizedHomePath(rootPath, normalizedPath string, allowMissingSuffix bool) (string, fs.FileInfo, error) {
	cleanRoot := filepath.Clean(rootPath)
	rootInfo, err := deps.Content.Lstat(cleanRoot)
	if err == nil {
		if rootInfo.Mode()&os.ModeSymlink != 0 || !rootInfo.IsDir() {
			return "", nil, errUnsupportedHomeTarget
		}
	} else if !os.IsNotExist(err) {
		return "", nil, err
	}

	if normalizedPath == "" {
		info, err := deps.Content.Lstat(cleanRoot)
		if err != nil {
			return "", nil, err
		}
		if info.Mode()&os.ModeSymlink != 0 || !info.IsDir() {
			return "", nil, errUnsupportedHomeTarget
		}
		return cleanRoot, info, nil
	}

	fullPath := filepath.Join(cleanRoot, filepath.FromSlash(normalizedPath))
	current := cleanRoot
	parts := strings.Split(normalizedPath, "/")
	for index, part := range parts {
		current = filepath.Join(current, filepath.FromSlash(part))
		info, err := deps.Content.Lstat(current)
		if err != nil {
			if os.IsNotExist(err) && allowMissingSuffix {
				return fullPath, nil, nil
			}
			return "", nil, err
		}
		if info.Mode()&os.ModeSymlink != 0 {
			return "", nil, errUnsupportedHomeTarget
		}
		if index < len(parts)-1 && !info.IsDir() {
			return "", nil, errUnsupportedHomeTarget
		}
		if index == len(parts)-1 {
			return current, info, nil
		}
	}
	return fullPath, nil, errUnsupportedHomeTarget
}

func isIdentityOff() bool {
	if deps == nil || deps.Config == nil {
		return false
	}
	return strings.TrimSpace(deps.Config.Identity.Mode) == "off"
}

func isOAuth2IntrospectionIdentity() bool {
	if deps == nil || deps.Config == nil {
		return false
	}
	return strings.TrimSpace(deps.Config.Identity.Mode) == "oauth2-introspection"
}
