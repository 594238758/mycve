package handlers

import (
	"context"
	"sync"

	"golang.org/x/sync/semaphore"
)

const maxPreparedSmallFileHandles int64 = 1024

var preparedSmallFileGate = semaphore.NewWeighted(maxPreparedSmallFileHandles)

type preparedSmallFilePermit struct {
	weight int64
	once   sync.Once
}

func acquirePreparedSmallFilePermit(ctx context.Context, fileCount int) (*preparedSmallFilePermit, error) {
	weight := int64(fileCount)
	if weight <= 0 {
		return &preparedSmallFilePermit{}, nil
	}
	if err := preparedSmallFileGate.Acquire(ctx, weight); err != nil {
		return nil, err
	}
	return &preparedSmallFilePermit{weight: weight}, nil
}

func (p *preparedSmallFilePermit) Release() {
	if p == nil || p.weight <= 0 {
		return
	}
	p.once.Do(func() {
		preparedSmallFileGate.Release(p.weight)
	})
}
