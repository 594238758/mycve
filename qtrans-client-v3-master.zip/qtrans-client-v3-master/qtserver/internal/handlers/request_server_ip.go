package handlers

import (
	"net"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

const serverIPHeader = "X-QT-Server-IP"

func requestServerIP(c *gin.Context) string {
	fallback := ""
	if deps != nil && deps.Config != nil {
		fallback = canonicalIP(deps.Config.Server.ExternalIP)
	}
	if c == nil || c.Request == nil {
		return fallback
	}

	if requestPeerIsTrusted(c.Request.RemoteAddr) {
		if forwarded := canonicalIP(c.GetHeader(serverIPHeader)); forwarded != "" {
			return forwarded
		}
		return fallback
	}
	if local, ok := c.Request.Context().Value(http.LocalAddrContextKey).(net.Addr); ok {
		if localIP := canonicalIP(addressHost(local.String())); localIP != "" {
			return localIP
		}
	}
	return fallback
}

func requestPeerIsTrusted(remoteAddr string) bool {
	if deps == nil || deps.Config == nil {
		return false
	}
	peer := net.ParseIP(addressHost(remoteAddr))
	if peer == nil {
		return false
	}
	for _, raw := range deps.Config.Server.TrustedProxies {
		value := strings.TrimSpace(raw)
		if trusted := net.ParseIP(value); trusted != nil {
			if trusted.Equal(peer) {
				return true
			}
			continue
		}
		if _, network, err := net.ParseCIDR(value); err == nil && network.Contains(peer) {
			return true
		}
	}
	return false
}

func addressHost(address string) string {
	value := strings.TrimSpace(address)
	if host, _, err := net.SplitHostPort(value); err == nil {
		return host
	}
	return strings.Trim(value, "[]")
}

func canonicalIP(raw string) string {
	ip := net.ParseIP(strings.TrimSpace(raw))
	if ip == nil || ip.IsUnspecified() {
		return ""
	}
	return ip.String()
}
