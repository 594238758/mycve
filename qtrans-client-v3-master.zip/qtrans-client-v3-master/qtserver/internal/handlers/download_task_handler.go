package handlers

import (
	"errors"
	"net/http"
	"os"
	"time"

	"qtserver/internal/models"

	"github.com/gin-gonic/gin"
)

func DownloadGrantHandler(c *gin.Context) {
	logger := getLogger(c)
	ctx := c.Request.Context()
	principal, err := authenticateReadPrincipal(ctx, c.GetHeader("Authorization"))
	if err != nil {
		handleIdentityError(c, logger, err)
		return
	}
	var request models.DownloadGrantRequest
	if err := decodeStrictJSON(c, &request, false); err != nil {
		respondHTTPError(c, err)
		return
	}
	if len(request.Items) == 0 || len(request.Items) > 1000 {
		BadRequest(c, ReasonInvalidRequest, "items must contain between 1 and 1000 files")
		return
	}
	taskID, ok := requireTaskID(c, request.TaskID)
	if !ok {
		return
	}
	logTaskID := requestTaskIDForLog(c, taskID)
	type candidate struct {
		key  string
		size int64
	}
	candidates := make([]candidate, 0, len(request.Items))
	seen := make(map[string]struct{}, len(request.Items))
	for _, item := range request.Items {
		normalized, physical, err := deps.FileSpace.Resolve(principal.ID, item.ObjectKey)
		if err != nil || normalized == "/" {
			BadRequest(c, "INVALID_PATH", "invalid object_key")
			return
		}
		if _, duplicate := seen[normalized]; duplicate {
			continue
		}
		seen[normalized] = struct{}{}
		info, err := os.Stat(physical)
		if err != nil {
			if os.IsNotExist(err) {
				NotFound(c, ReasonNotFound, "selected file not found")
			} else {
				InternalServerError(c, ReasonInternalError, "cannot inspect selected file")
			}
			return
		}
		if !info.Mode().IsRegular() {
			BadRequest(c, ReasonInvalidRequest, "grant only accepts explicit regular files")
			return
		}
		if err := validateTransferFileSize(info.Size()); err != nil {
			FileTooLarge(c, info.Size(), transferMaxFileBytes())
			return
		}
		candidates = append(candidates, candidate{key: normalized, size: info.Size()})
	}

	now := deps.Now().UTC()
	expiresAt := now.Add(time.Duration(deps.Config.Transfer.GrantTTLSeconds) * time.Second).Unix()
	results := make([]models.DownloadFileResult, 0, len(candidates))
	for _, candidate := range candidates {
		grant, _, err := buildDownloadGrant(principal, taskID, candidate.key, now, expiresAt)
		if err != nil {
			var tooLarge *transferFileTooLargeError
			if os.IsNotExist(err) {
				NotFound(c, ReasonNotFound, "selected file changed")
			} else if errors.As(err, &tooLarge) {
				FileTooLarge(c, tooLarge.fileSize, transferMaxFileBytes())
			} else if errors.Is(err, errUnsupportedDownloadTarget) {
				BadRequest(c, ReasonInvalidRequest, "selected target is not a regular file")
			} else {
				InternalServerError(c, ReasonInternalError, "failed to prepare download grants")
			}
			return
		}
		result, err := buildDownloadResult(logger, principal, grant, candidate.size)
		if err != nil {
			InternalServerError(c, ReasonInternalError, "failed to encode download grant")
			return
		}
		results = append(results, result)
	}
	logger.Info("download grants created", "taskid", logTaskID, "principal_id", principal.ID, "files", len(results))
	c.JSON(http.StatusOK, models.DownloadGrantResponse{Code: http.StatusOK, Message: "Success", TaskID: taskID, Files: results})
}
