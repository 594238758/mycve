package handlers

import (
	"errors"
	"os"

	"qtserver/internal/models"
)

func ensureDownloadHomeInitialized(principal *Principal) error {
	if principal == nil || principal.Type == models.PrincipalAnonymous {
		// Public downloads: no per-user home directory needed
		return nil
	}

	// Private downloads: check if directory exists but do NOT auto-create
	rootPath, err := resolvePrincipalHomeRoot(deps.Config.Server.UserHomeRoot, principal)
	if err != nil {
		return err
	}

	_, lstatErr := os.Lstat(rootPath)
	switch {
	case lstatErr == nil:
		info, statErr := os.Stat(rootPath)
		if statErr != nil {
			if errors.Is(statErr, os.ErrNotExist) {
				return errUnsupportedHomeTarget
			}
			return statErr
		}
		if !info.IsDir() {
			return errUnsupportedHomeTarget
		}
		return nil
	case os.IsNotExist(lstatErr):
		// Private download directory does not exist - this is OK
		// Callers should handle the missing directory gracefully
		return nil
	default:
		return lstatErr
	}
}
