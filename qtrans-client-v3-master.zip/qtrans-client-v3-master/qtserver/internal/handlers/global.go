package handlers

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"strings"
	"time"

	"qtserver/internal/businessevents"
	"qtserver/internal/config"
	"qtserver/internal/filehash"
	"qtserver/internal/filespace"
	"qtserver/internal/hashmanager"
	"qtserver/internal/models"
	"qtserver/internal/store"

	"github.com/gin-gonic/gin"
)

type HandlerDeps struct {
	Config         *config.Config
	Store          store.SessionStore
	Content        store.ContentStore
	GrantSigner    GrantSigner
	Identity       IdentityClient
	Redis          *store.RedisStore
	Fatal          func(error)
	FileSpace      *filespace.Space
	Hashes         fileHashManager
	Now            func() time.Time
	BusinessEvents businessevents.BusinessEventSink
	SyncUploadFile func(*os.File) error
}

type fileHashManager interface {
	Start(context.Context)
	Lookup(context.Context, string, string, string) (hashmanager.Result, error)
	BeginKnownMutation(context.Context, string, string, filehash.Fingerprint) (int64, error)
	CommitKnown(context.Context, string, string, int64, filehash.Fingerprint, string) (bool, error)
	Invalidate(context.Context, string, string) error
	BumpNamespaceGeneration(context.Context, string) error
}

var deps *HandlerDeps

func InitHandlers(cfg *config.Config, fatal func(error)) error {
	redisStore, err := store.NewRedisStore(cfg.Redis)
	if err != nil {
		return err
	}
	redisStore.SetFailureReporter(fatal)
	identityClient := NewIdentityClientWithCache(cfg.Identity, redisStore)
	if strings.TrimSpace(cfg.Identity.Mode) == "oauth2-introspection" {
		identityCtx, identityCancel := context.WithTimeout(context.Background(), time.Duration(cfg.Identity.TimeoutSeconds)*time.Second)
		err := identityClient.Health(identityCtx)
		identityCancel()
		if err != nil {
			_ = redisStore.Close()
			return fmt.Errorf("introspection startup probe: %w", err)
		}
	}
	space := filespace.New(cfg.Server)
	logDirectory, err := config.ResolveLogDirectory(cfg.Log.FilePath)
	if err != nil {
		_ = redisStore.Close()
		return err
	}
	eventWriter, err := businessevents.NewWriter(businessevents.WriterOptions{
		Directory:       logDirectory,
		RotationEnabled: cfg.Log.Rotation.Enable,
		MaxSizeMB:       cfg.Log.Rotation.MaxSize,
		MaxBackups:      cfg.Log.Rotation.MaxBackups,
		MaxAgeDays:      cfg.Log.Rotation.MaxAge,
		Compress:        cfg.Log.Rotation.Compress,
	})
	if err != nil {
		_ = redisStore.Close()
		return fmt.Errorf("initialize business event writer: %w", err)
	}
	deps = &HandlerDeps{
		Config:         cfg,
		Store:          redisStore,
		Content:        store.NewPOSIXContentStore(cfg.Server),
		GrantSigner:    NewHMACGrantSigner(cfg.Transfer.HMACSecret),
		Identity:       identityClient,
		Redis:          redisStore,
		Fatal:          fatal,
		FileSpace:      space,
		Hashes:         hashmanager.New(redisStore, space, cfg.Transfer.FileHashRevalidateSeconds, cfg.Transfer.FileHashRetentionSeconds, cfg.Transfer.HashWorkerCount, cfg.Transfer.HashQueueSize, fatal),
		Now:            time.Now,
		BusinessEvents: eventWriter,
	}
	return nil
}

func StartHashWorkers(ctx context.Context) {
	if deps != nil && deps.Hashes != nil {
		deps.Hashes.Start(ctx)
	}
}

func StartBusinessEventRecovery(ctx context.Context, logger *slog.Logger) {
	if logger == nil {
		logger = slog.Default()
	}
	go func() {
		ticker := time.NewTicker(time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				current := deps
				if current == nil || current.BusinessEvents == nil || current.BusinessEvents.Healthy() {
					continue
				}
				if err := current.BusinessEvents.Reopen(); err != nil {
					logger.Error("business event log recovery failed", "error", err)
					continue
				}
				logger.Info("business event log recovered")
			}
		}
	}()
}

func CloseHandlers() {
	if deps == nil {
		return
	}
	if deps.BusinessEvents != nil {
		_ = deps.BusinessEvents.Close()
	}
	if deps.Redis != nil {
		_ = deps.Redis.Close()
	}
	deps = nil
}

func CheckFatalDependencies(ctx context.Context) error {
	current := deps
	if current == nil {
		return fmt.Errorf("handler dependencies are not initialized")
	}
	if err := current.Redis.CheckPersistence(ctx); err != nil {
		return fmt.Errorf("redis persistence health check: %w", err)
	}
	if strings.TrimSpace(current.Config.Identity.Mode) == "oauth2-introspection" {
		if err := current.Identity.Health(ctx); err != nil {
			return fmt.Errorf("introspection health check: %w", err)
		}
	}
	return nil
}

func BusinessLoggingHealthy() bool {
	return deps != nil && deps.BusinessEvents != nil && deps.BusinessEvents.Healthy()
}

func ReportFatalDependency(err error) {
	if err != nil && deps != nil && deps.Fatal != nil {
		deps.Fatal(err)
	}
}

func SetHandlerDeps(d *HandlerDeps) {
	deps = d
}

func getDeps() *HandlerDeps {
	return deps
}

func getLogger(c *gin.Context) *slog.Logger {
	if logger, ok := c.Get("logger"); ok {
		if slogger, ok := logger.(*slog.Logger); ok {
			return slogger
		}
	}
	return slog.Default()
}

func requestTaskIDForLog(c *gin.Context, fallback string) string {
	return requestTaskCorrelationForLog(c, fallback).TaskID
}

func requestTaskPIDForLog(c *gin.Context) string {
	return requestTaskCorrelationForLog(c, "").TaskPID
}

func requestEnterpriseIDForLog(c *gin.Context) string {
	return requestTaskCorrelationForLog(c, "").EnterpriseID
}

func requestTaskCorrelationForLog(c *gin.Context, fallbackTaskID string) businessevents.TaskCorrelation {
	correlation := businessevents.TaskCorrelation{TaskID: fallbackTaskID}
	if c == nil {
		return correlation
	}
	if current := c.GetHeader("X-Task-ID"); current != "" {
		correlation.TaskID = current
	}
	correlation.TaskPID = c.GetHeader("X-Task-PID")
	correlation.EnterpriseID = c.GetHeader("X-Enterprise-ID")
	return correlation
}

func resolvePrincipal(ctx context.Context, token string) (*Principal, error) {
	principal, err := deps.Identity.Resolve(ctx, token)
	if err != nil {
		if isOAuth2IntrospectionIdentity() && errors.Is(err, ErrIdentityUnavailable) {
			ReportFatalDependency(fmt.Errorf("introspection request failed: %w", err))
		}
		return nil, err
	}
	principal, err = normalizeResolvedPrincipal(principal)
	if err != nil {
		return nil, err
	}
	if principal.Type == models.PrincipalAnonymous && !deps.Config.Server.AnonymousEnabled {
		return nil, ErrInvalidToken
	}
	return principal, nil
}

func anonymousPrincipal() *Principal {
	return &Principal{ID: "anonymous", Type: models.PrincipalAnonymous}
}

func signGrant(taskID, objectKey string, direction models.TransferGrantDirection, expiresAt int64, principalID string) string {
	payload := fmt.Sprintf("%s|%s|%s|%d|%s", taskID, objectKey, direction, expiresAt, principalID)
	return deps.GrantSigner.Sign(payload)
}

// verifyGrantHMAC performs constant-time HMAC verification to prevent timing attacks.
func verifyGrantHMAC(taskID, objectKey string, direction models.TransferGrantDirection, expiresAt int64, principalID, hmacValue string) bool {
	payload := fmt.Sprintf("%s|%s|%s|%d|%s", taskID, objectKey, direction, expiresAt, principalID)
	return deps.GrantSigner.Verify(payload, hmacValue)
}

func resolveDownloadPhysicalPath(principal *Principal, objectKey string) (string, error) {
	return deps.Content.DownloadPath(principal.ID, objectKey)
}

func resolveUploadPhysicalPath(principal *Principal, objectKey string) (string, error) {
	return deps.Content.UploadPath(principal.ID, objectKey)
}
