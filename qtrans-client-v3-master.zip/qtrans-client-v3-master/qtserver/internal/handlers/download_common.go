package handlers

import (
	"context"
	"errors"
	"fmt"
	"io/fs"
	"log/slog"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"qtserver/internal/config"
	"qtserver/internal/filehash"
	"qtserver/internal/misc"
	"qtserver/internal/models"

	"github.com/google/uuid"
)

var errInvalidDownloadUser = errors.New("invalid download user")
var errUnsupportedDownloadTarget = errors.New("unsupported download target")
var errDownloadTargetNotDirectory = errors.New("download target is not a directory")
var errEncodeDownloadGrant = errors.New("encode download grant")
var errEmptySmallSelection = errors.New("small selection empty")
var errSmallDownloadLimitExceeded = errors.New("small selection exceeds limits")

type notSmallFileError struct {
	objectKey string
	fileSize  int64
	limit     int64
}

func (e *notSmallFileError) Error() string {
	return "file exceeds small download size limit"
}

type transferFileTooLargeError struct {
	fileSize int64
}

func (e *transferFileTooLargeError) Error() string {
	return "file exceeds configured size limit"
}

func transferMaxFileBytes() int64 {
	if deps == nil || deps.Config == nil || deps.Config.Transfer.MaxFileBytes <= 0 {
		return config.DefaultMaxFileBytes
	}
	return deps.Config.Transfer.MaxFileBytes
}

func validateTransferFileSize(fileSize int64) error {
	if fileSize > transferMaxFileBytes() {
		return &transferFileTooLargeError{fileSize: fileSize}
	}
	return nil
}

func isTransferFileTooLarge(err error) bool {
	var tooLarge *transferFileTooLargeError
	return errors.As(err, &tooLarge)
}

func transferFileSize(err error) int64 {
	var tooLarge *transferFileTooLargeError
	if errors.As(err, &tooLarge) {
		return tooLarge.fileSize
	}
	return 0
}

type preparedSmallFile struct {
	File        *os.File
	ObjectKey   string
	ArchivePath string
	Size        int64
	ModTime     time.Time
	Hash        string
}

func resolveDownloadSelection(ctx context.Context, userSelector, authorization string) (*Principal, string, error) {
	switch strings.TrimSpace(userSelector) {
	case string(models.PrincipalAnonymous):
		return anonymousPrincipal(), string(models.PrincipalAnonymous), nil
	case "self":
		if isIdentityOff() {
			return nil, "", errPrivateDownloadDisabled
		}
		principal, err := authenticateRequiredPrincipal(ctx, authorization)
		if err != nil {
			return nil, "", err
		}
		return principal, "self", nil
	default:
		return nil, "", errInvalidDownloadUser
	}
}

func resolveDownloadRoot(principal *Principal) (string, error) {
	if principal == nil {
		return "", errInvalidDownloadUser
	}
	return deps.FileSpace.ExistingHome(principal.ID)
}

func normalizeOptionalDownloadPath(rawPath string) (string, error) {
	trimmed := strings.TrimSpace(strings.ReplaceAll(rawPath, "\\", "/"))
	if trimmed == "" {
		return "", nil
	}
	return misc.NormalizeObjectKey(trimmed)
}

func resolveDownloadPath(rootPath, relativePath string) (string, fs.FileInfo, error) {
	cleanRoot := filepath.Clean(rootPath)
	normalizedPath, err := normalizeOptionalDownloadPath(relativePath)
	if err != nil {
		return "", nil, err
	}
	file, info, err := openDownloadPath(cleanRoot, normalizedPath)
	if err != nil {
		return "", nil, err
	}
	defer file.Close()

	fullPath := cleanRoot
	if normalizedPath != "" {
		fullPath = filepath.Join(cleanRoot, filepath.FromSlash(normalizedPath))
	}
	return fullPath, info, nil
}

func buildDownloadBrowseEntry(relativePath, fullPath string, entryInfo fs.FileInfo) (models.DownloadBrowseEntry, error) {
	entry := models.DownloadBrowseEntry{
		Name:         filepath.Base(fullPath),
		ObjectKey:    relativePath,
		LastModified: formatBrowseLastModified(entryInfo.ModTime()),
	}

	switch {
	case entryInfo.IsDir():
		entry.EntryType = models.DownloadBrowseEntryDirectory
	case entryInfo.Mode().IsRegular():
		entry.EntryType = models.DownloadBrowseEntryFile
		entry.Size = entryInfo.Size()
	default:
		return models.DownloadBrowseEntry{}, errUnsupportedDownloadTarget
	}

	return entry, nil
}

func listDownloadEntries(rootPath, relativePath string) ([]models.DownloadBrowseEntry, error) {
	normalizedPath, err := normalizeOptionalDownloadPath(relativePath)
	if err != nil {
		return nil, err
	}
	targetFile, targetInfo, err := openDownloadPath(rootPath, normalizedPath)
	if err != nil {
		return nil, err
	}
	defer targetFile.Close()
	targetPath := filepath.Clean(rootPath)
	if normalizedPath != "" {
		targetPath = filepath.Join(targetPath, filepath.FromSlash(normalizedPath))
	}
	if !targetInfo.IsDir() {
		return nil, errDownloadTargetNotDirectory
	}

	dirEntries, err := targetFile.ReadDir(-1)
	if err != nil {
		return nil, err
	}

	entries := make([]models.DownloadBrowseEntry, 0, len(dirEntries))
	for _, entry := range dirEntries {
		objectKey := entry.Name()
		if normalizedPath != "" {
			objectKey = normalizedPath + "/" + entry.Name()
		}
		entryFile, entryInfo, openErr := openDownloadPath(rootPath, objectKey)
		if openErr != nil {
			if os.IsNotExist(openErr) || errors.Is(openErr, errUnsupportedDownloadTarget) {
				continue
			}
			return nil, openErr
		}
		fullPath := filepath.Join(targetPath, entry.Name())

		browseEntry, entryErr := buildDownloadBrowseEntry(objectKey, fullPath, entryInfo)
		_ = entryFile.Close()
		if entryErr != nil {
			switch {
			case errors.Is(entryErr, errUnsupportedDownloadTarget):
				continue
			default:
				return nil, entryErr
			}
		}
		entries = append(entries, browseEntry)
	}
	return entries, nil
}

func expandDownloadSelection(rootPath string, items []models.DownloadObjectRequest) ([]string, error) {
	selected := make(map[string]struct{})

	for _, item := range items {
		normalized, err := misc.NormalizeObjectKey(item.ObjectKey)
		if err != nil {
			return nil, err
		}
		targetFile, info, err := openDownloadPath(rootPath, normalized)
		if err != nil {
			return nil, err
		}
		_ = targetFile.Close()

		switch {
		case info.Mode().IsRegular():
			selected[normalized] = struct{}{}
		case info.IsDir():
			if err := expandDownloadDirectory(rootPath, normalized, selected); err != nil {
				return nil, err
			}
		default:
			return nil, errUnsupportedDownloadTarget
		}
	}

	objectKeys := make([]string, 0, len(selected))
	for objectKey := range selected {
		objectKeys = append(objectKeys, objectKey)
	}
	sort.Strings(objectKeys)
	return objectKeys, nil
}

func expandDownloadDirectory(rootPath, objectKey string, selected map[string]struct{}) error {
	return expandDownloadDirectoryWithAncestors(rootPath, objectKey, selected, nil)
}

func expandDownloadDirectoryWithAncestors(rootPath, objectKey string, selected map[string]struct{}, ancestors []fs.FileInfo) error {
	directory, info, err := openDownloadPath(rootPath, objectKey)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	defer directory.Close()
	if !info.IsDir() {
		return errUnsupportedDownloadTarget
	}
	for _, ancestor := range ancestors {
		if os.SameFile(ancestor, info) {
			return nil
		}
	}
	ancestors = append(ancestors, info)

	dirEntries, err := directory.ReadDir(-1)
	if err != nil {
		return err
	}

	for _, entry := range dirEntries {
		childObjectKey := entry.Name()
		if objectKey != "" {
			childObjectKey = objectKey + "/" + entry.Name()
		}
		childFile, childInfo, err := openDownloadPath(rootPath, childObjectKey)
		if err != nil {
			if os.IsNotExist(err) || errors.Is(err, errUnsupportedDownloadTarget) {
				continue
			}
			return err
		}
		_ = childFile.Close()

		switch {
		case childInfo.Mode().IsRegular():
			selected[childObjectKey] = struct{}{}
		case childInfo.IsDir():
			if err := expandDownloadDirectoryWithAncestors(rootPath, childObjectKey, selected, ancestors); err != nil {
				return err
			}
		}
	}

	return nil
}

func buildDownloadGrant(principal *Principal, taskID, objectKey string, now time.Time, expiresAt int64) (*models.TransferGrant, fs.FileInfo, error) {
	normalized, physicalPath, err := deps.FileSpace.Resolve(principal.ID, objectKey)
	if err != nil {
		return nil, nil, err
	}
	info, err := os.Stat(physicalPath)
	if err != nil {
		return nil, nil, err
	}
	if !info.Mode().IsRegular() {
		return nil, nil, errUnsupportedDownloadTarget
	}
	if err := validateTransferFileSize(info.Size()); err != nil {
		return nil, nil, err
	}

	internalPath := ""
	if deps.Config.Server.NginxDownloadEnabled() {
		internalPath, err = buildInternalDownloadURI(deps.Config.Server.NginxAcc, principal.ID, normalized)
		if err != nil {
			return nil, nil, err
		}
	}

	grant := &models.TransferGrant{
		TaskID:       taskID,
		ObjectKey:    normalized,
		Direction:    models.TransferGrantDownload,
		PrincipalID:  principal.ID,
		Namespace:    "user_download",
		OwnerID:      principal.ID,
		PhysicalPath: physicalPath,
		InternalPath: internalPath,
		ExpiresAt:    expiresAt,
		HMAC:         signGrant(taskID, normalized, models.TransferGrantDownload, expiresAt, principal.ID),
		Authorized:   true,
		Exists:       true,
		State:        models.TransferGrantActive,
		CreatedAt:    now,
	}
	return grant, info, nil
}

func buildDownloadResult(logger *slog.Logger, principal *Principal, grant *models.TransferGrant, size int64) (models.DownloadFileResult, error) {
	encodedGrant, err := encodeTransferGrantRef(grant)
	if err != nil {
		logger.Error("encode download grant failed", "taskid", grant.TaskID, "object_key", grant.ObjectKey, "error", err)
		return models.DownloadFileResult{}, errors.Join(errEncodeDownloadGrant, err)
	}

	return models.DownloadFileResult{
		ObjectKey: grant.ObjectKey,
		Size:      size,
		Grant:     encodedGrant,
	}, nil
}

func newDownloadTaskID() string {
	return uuid.NewString()
}

func allocateDownloadTask(principal *Principal, now time.Time) *models.TransferTask {
	return &models.TransferTask{
		TaskID:      newDownloadTaskID(),
		TaskType:    models.TransferTaskDownload,
		PrincipalID: principal.ID,
		UserID:      principal.ID,
		Status:      models.TransferTaskCreated,
		CreatedAt:   now,
	}
}

func prepareSmallFiles(ctx context.Context, logger *slog.Logger, principal *Principal, files []models.DownloadObjectRequest) ([]preparedSmallFile, int64, error) {
	seen := make(map[string]struct{}, len(files))
	prepared := make([]preparedSmallFile, 0, len(files))
	success := false
	defer func() {
		if !success {
			closePreparedSmallFiles(prepared)
		}
	}()
	var totalBytes int64

	for _, file := range files {
		normalized, physical, err := deps.FileSpace.Resolve(principal.ID, file.ObjectKey)
		if err != nil {
			return nil, 0, err
		}
		if _, dup := seen[normalized]; dup {
			continue
		}
		seen[normalized] = struct{}{}

		openedFile, err := os.Open(physical)
		if err != nil {
			return nil, 0, err
		}
		info, err := openedFile.Stat()
		if err != nil {
			_ = openedFile.Close()
			return nil, 0, err
		}
		if !info.Mode().IsRegular() {
			_ = openedFile.Close()
			if info.IsDir() {
				return nil, 0, errDownloadTargetNotDirectory
			}
			return nil, 0, errUnsupportedDownloadTarget
		}
		if err := validateTransferFileSize(info.Size()); err != nil {
			_ = openedFile.Close()
			return nil, 0, err
		}
		if len(seen) > deps.Config.Transfer.MaxSmallFiles {
			_ = openedFile.Close()
			return nil, 0, errSmallDownloadLimitExceeded
		}
		if info.Size() > deps.Config.Transfer.MaxSmallFileBytes {
			_ = openedFile.Close()
			return nil, 0, errSmallDownloadLimitExceeded
		}
		if info.Size() > math.MaxInt64-totalBytes {
			_ = openedFile.Close()
			return nil, 0, errSmallDownloadLimitExceeded
		}
		totalBytes += info.Size()
		if totalBytes > deps.Config.Transfer.MaxSmallTotalBytes {
			_ = openedFile.Close()
			return nil, 0, errSmallDownloadLimitExceeded
		}
		hash, err := filehash.LayeredReader(ctx, openedFile)
		if err != nil {
			_ = openedFile.Close()
			return nil, 0, err
		}
		if _, err := openedFile.Seek(0, 0); err != nil {
			_ = openedFile.Close()
			return nil, 0, err
		}
		prepared = append(prepared, preparedSmallFile{
			File:        openedFile,
			ObjectKey:   normalized,
			ArchivePath: "payload/" + strings.TrimPrefix(normalized, "/"),
			Size:        info.Size(),
			ModTime:     info.ModTime(),
			Hash:        hash,
		})
	}
	if len(prepared) == 0 {
		return nil, 0, errEmptySmallSelection
	}
	success = true
	return prepared, totalBytes, nil
}

func closePreparedSmallFiles(files []preparedSmallFile) {
	for _, file := range files {
		if file.File != nil {
			_ = file.File.Close()
		}
	}
}

func prepareSmallFilesV2(ctx context.Context, principal *Principal, files []models.DownloadObjectRequest) ([]preparedSmallFile, int64, *preparedSmallFilePermit, error) {
	type candidate struct {
		objectKey string
		physical  string
	}

	seen := make(map[string]struct{}, len(files))
	candidates := make([]candidate, 0, len(files))
	for _, file := range files {
		normalized, physical, err := deps.FileSpace.Resolve(principal.ID, file.ObjectKey)
		if err != nil {
			return nil, 0, nil, err
		}
		if _, duplicate := seen[normalized]; duplicate {
			continue
		}
		seen[normalized] = struct{}{}
		candidates = append(candidates, candidate{objectKey: normalized, physical: physical})
	}
	if len(candidates) == 0 {
		return nil, 0, nil, errEmptySmallSelection
	}
	if len(candidates) > deps.Config.Transfer.MaxSmallFiles {
		return nil, 0, nil, errSmallDownloadLimitExceeded
	}

	permit, err := acquirePreparedSmallFilePermit(ctx, len(candidates))
	if err != nil {
		return nil, 0, nil, err
	}
	prepared := make([]preparedSmallFile, 0, len(candidates))
	success := false
	defer func() {
		if !success {
			closePreparedSmallFiles(prepared)
			permit.Release()
		}
	}()

	var totalBytes int64
	for index, item := range candidates {
		openedFile, openErr := os.Open(item.physical)
		if openErr != nil {
			return nil, 0, nil, openErr
		}
		info, statErr := openedFile.Stat()
		if statErr != nil {
			_ = openedFile.Close()
			return nil, 0, nil, statErr
		}
		if !info.Mode().IsRegular() {
			_ = openedFile.Close()
			if info.IsDir() {
				return nil, 0, nil, errDownloadTargetNotDirectory
			}
			return nil, 0, nil, errUnsupportedDownloadTarget
		}
		if sizeErr := validateTransferFileSize(info.Size()); sizeErr != nil {
			_ = openedFile.Close()
			return nil, 0, nil, sizeErr
		}
		if info.Size() > deps.Config.Transfer.MaxSmallFileBytes {
			_ = openedFile.Close()
			return nil, 0, nil, &notSmallFileError{
				objectKey: item.objectKey,
				fileSize:  info.Size(),
				limit:     deps.Config.Transfer.MaxSmallFileBytes,
			}
		}
		if info.Size() > math.MaxInt64-totalBytes {
			_ = openedFile.Close()
			return nil, 0, nil, errSmallDownloadLimitExceeded
		}
		totalBytes += info.Size()
		if totalBytes > deps.Config.Transfer.MaxSmallTotalBytes {
			_ = openedFile.Close()
			return nil, 0, nil, errSmallDownloadLimitExceeded
		}
		prepared = append(prepared, preparedSmallFile{
			File:        openedFile,
			ObjectKey:   item.objectKey,
			ArchivePath: fmt.Sprintf("payload/%06d", index),
			Size:        info.Size(),
			ModTime:     info.ModTime(),
		})
	}

	success = true
	return prepared, totalBytes, permit, nil
}
