package handlers

import (
	"errors"
	"net/http"
	"strings"

	"qtserver/internal/models"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

var errInvalidTaskID = errors.New("invalid taskid")

const maxTaskIDBytes = 128

func normalizeAndValidateTaskID(raw string) (string, error) {
	taskID := strings.TrimSpace(raw)
	if taskID == "" || len(taskID) > maxTaskIDBytes {
		return "", errInvalidTaskID
	}
	return taskID, nil
}

func requireTaskID(c *gin.Context, raw string) (string, bool) {
	taskID := strings.TrimSpace(raw)
	if taskID == "" {
		BadRequest(c, ReasonInvalidRequest, "taskid is required")
		return "", false
	}
	if _, err := normalizeAndValidateTaskID(taskID); err != nil {
		BadRequest(c, ReasonInvalidRequest, "invalid taskid")
		return "", false
	}
	return taskID, true
}

func TaskIDHandler(c *gin.Context) {
	c.Header("Cache-Control", "no-store")
	c.JSON(http.StatusOK, models.TaskIDResponse{
		Code:    http.StatusOK,
		Message: "Success",
		TaskID:  uuid.New().String(),
	})
}
