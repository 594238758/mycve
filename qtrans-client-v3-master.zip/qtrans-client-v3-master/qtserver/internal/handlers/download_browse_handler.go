package handlers

import (
	"errors"
	"net/http"
	"os"

	"qtserver/internal/models"

	"github.com/gin-gonic/gin"
)

func DownloadBrowseHandler(c *gin.Context) {
	logger := getLogger(c)
	ctx := c.Request.Context()
	if _, exists := c.GetQuery("with_checksum"); exists {
		BadRequest(c, ReasonInvalidRequest, "with_checksum is not supported")
		return
	}

	var req models.DownloadBrowseRequest
	if err := c.ShouldBindQuery(&req); err != nil {
		BadRequest(c, ReasonInvalidRequest, "invalid request format")
		return
	}

	principal, selectedUser, err := resolveDownloadSelection(ctx, req.User, c.GetHeader("Authorization"))
	if err != nil {
		switch {
		case errors.Is(err, errInvalidDownloadUser):
			BadRequest(c, ReasonInvalidRequest, "user must be anonymous or self")
		case errors.Is(err, errPrivateDownloadDisabled):
			Forbidden(c, ReasonForbidden, "private downloads are disabled when identity.mode=off")
		default:
			handleIdentityError(c, logger, err)
		}
		return
	}

	rootPath, err := resolveDownloadRoot(principal)
	if err != nil {
		logger.Error("resolve download root failed", "user", req.User, "error", err)
		InternalServerError(c, ReasonInternalError, "failed to resolve download root")
		return
	}

	normalizedPath, err := normalizeOptionalDownloadPath(req.Path)
	if err != nil {
		BadRequest(c, ReasonInvalidRequest, "invalid path")
		return
	}

	entries, err := listDownloadEntries(rootPath, normalizedPath)
	if err != nil {
		switch {
		case os.IsNotExist(err) && selectedUser == "self" && normalizedPath == "":
			c.JSON(http.StatusOK, models.DownloadBrowseResponse{
				Code:    http.StatusOK,
				Message: "Success",
				User:    selectedUser,
				Path:    normalizedPath,
				Entries: []models.DownloadBrowseEntry{},
			})
			return
		case os.IsNotExist(err):
			NotFound(c, ReasonNotFound, "directory not found")
		case errors.Is(err, errDownloadTargetNotDirectory):
			BadRequest(c, ReasonInvalidRequest, "path is not a directory")
		case errors.Is(err, errUnsupportedDownloadTarget):
			BadRequest(c, ReasonInvalidRequest, "directory contains an unsupported entry")
		default:
			logger.Error("list download directory failed", "user", req.User, "path", normalizedPath, "error", err)
			InternalServerError(c, ReasonInternalError, "failed to browse directory")
		}
		return
	}

	c.JSON(http.StatusOK, models.DownloadBrowseResponse{
		Code:    http.StatusOK,
		Message: "Success",
		User:    selectedUser,
		Path:    normalizedPath,
		Entries: entries,
	})
}
