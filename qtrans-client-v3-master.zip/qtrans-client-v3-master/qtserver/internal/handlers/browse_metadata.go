package handlers

import "time"

func formatBrowseLastModified(modTime time.Time) string {
	return modTime.UTC().Format(time.RFC3339)
}
