package handlers

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

const (
	ReasonInvalidRequest        = "INVALID_REQUEST"
	ReasonInvalidObjectKey      = "INVALID_OBJECT_KEY"
	ReasonInvalidToken          = "INVALID_TOKEN"
	ReasonDependencyUnavailable = "DEPENDENCY_UNAVAILABLE"
	ReasonNotFound              = "NOT_FOUND"
	ReasonForbidden             = "FORBIDDEN"
	ReasonConflict              = "CONFLICT"
	ReasonChunkBusy             = "CHUNK_BUSY"
	ReasonChunkOffsetMismatch   = "CHUNK_OFFSET_MISMATCH"
	ReasonGrantExpired          = "GRANT_EXPIRED"
	ReasonFileTooLarge          = "FILE_TOO_LARGE"
	ReasonNotSmall              = "NOT_SMALL"
	ReasonInternalError         = "INTERNAL_ERROR"
	ReasonRouteNotFound         = "ROUTE_NOT_FOUND"
)

type ErrorResponse struct {
	Code       int    `json:"code"`
	Message    string `json:"message"`
	ReasonCode string `json:"reason_code,omitempty"`
}

func writeError(c *gin.Context, statusCode int, reasonCode, message string) {
	c.JSON(statusCode, ErrorResponse{
		Code:       statusCode,
		Message:    message,
		ReasonCode: reasonCode,
	})
}

func writeErrorWithExtras(c *gin.Context, statusCode int, reasonCode, message string, extras map[string]any) {
	body := map[string]any{"code": statusCode, "reason_code": reasonCode, "message": message}
	for key, value := range extras {
		body[key] = value
	}
	c.JSON(statusCode, body)
}

func FileTooLarge(c *gin.Context, fileSize, maxFileBytes int64) {
	writeErrorWithExtras(c, http.StatusRequestEntityTooLarge, ReasonFileTooLarge, "file exceeds configured size limit", map[string]any{
		"file_size":      fileSize,
		"max_file_bytes": maxFileBytes,
	})
}

func NotSmall(c *gin.Context, objectKey string, fileSize, maxSmallFileBytes int64) {
	writeErrorWithExtras(c, http.StatusConflict, ReasonNotSmall, "file exceeds small download size limit", map[string]any{
		"object_key":           objectKey,
		"file_size":            fileSize,
		"max_small_file_bytes": maxSmallFileBytes,
	})
}

const maxJSONBodyBytes = 2 << 20

func decodeStrictJSON(c *gin.Context, dst any, emptyAllowed bool) error {
	if emptyAllowed && c.Request.ContentLength == 0 {
		return nil
	}
	mediaType, _, err := mime.ParseMediaType(c.GetHeader("Content-Type"))
	if err != nil || !strings.EqualFold(mediaType, "application/json") {
		return &HTTPError{Status: http.StatusUnsupportedMediaType, Reason: "UNSUPPORTED_MEDIA_TYPE", Message: "Content-Type must be application/json"}
	}
	reader := http.MaxBytesReader(c.Writer, c.Request.Body, maxJSONBodyBytes)
	decoder := json.NewDecoder(reader)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(dst); err != nil {
		if emptyAllowed && errors.Is(err, io.EOF) {
			return nil
		}
		return &HTTPError{Status: http.StatusBadRequest, Reason: ReasonInvalidRequest, Message: fmt.Sprintf("invalid JSON body: %v", err)}
	}
	var extra any
	if err := decoder.Decode(&extra); !errors.Is(err, io.EOF) {
		return &HTTPError{Status: http.StatusBadRequest, Reason: ReasonInvalidRequest, Message: "request body must contain exactly one JSON value"}
	}
	return nil
}

type HTTPError struct {
	Status  int
	Reason  string
	Message string
	Extras  map[string]any
}

func (e *HTTPError) Error() string { return e.Message }

func respondHTTPError(c *gin.Context, err error) bool {
	var typed *HTTPError
	if !errors.As(err, &typed) {
		return false
	}
	writeErrorWithExtras(c, typed.Status, typed.Reason, typed.Message, typed.Extras)
	return true
}

func BadRequest(c *gin.Context, reasonCode, message string) {
	writeError(c, http.StatusBadRequest, reasonCode, message)
}

func Unauthorized(c *gin.Context, reasonCode, message string) {
	writeError(c, http.StatusUnauthorized, reasonCode, message)
}

func Forbidden(c *gin.Context, reasonCode, message string) {
	writeError(c, http.StatusForbidden, reasonCode, message)
}

func NotFound(c *gin.Context, reasonCode, message string) {
	writeError(c, http.StatusNotFound, reasonCode, message)
}

func Conflict(c *gin.Context, reasonCode, message string) {
	writeError(c, http.StatusConflict, reasonCode, message)
}

func Gone(c *gin.Context, reasonCode, message string) {
	writeError(c, http.StatusGone, reasonCode, message)
}

func ServiceUnavailable(c *gin.Context, reasonCode, message string) {
	writeError(c, http.StatusServiceUnavailable, reasonCode, message)
}

func InternalServerError(c *gin.Context, reasonCode, message string) {
	writeError(c, http.StatusInternalServerError, reasonCode, message)
}
