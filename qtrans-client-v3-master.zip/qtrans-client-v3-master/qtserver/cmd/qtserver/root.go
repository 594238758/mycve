package main

import (
	"fmt"

	"qtserver/internal/config"
	"qtserver/internal/version"

	"github.com/spf13/cobra"
)

type rootOptions struct {
	configPath string
}

func newRootCommand() *cobra.Command {
	opts := &rootOptions{}
	cmd := &cobra.Command{
		Use:           "qtserver",
		Short:         "qtserver transfer control plane",
		SilenceUsage:  true,
		SilenceErrors: true,
		Args:          cobra.NoArgs,
		RunE: func(cmd *cobra.Command, args []string) error {
			return cmd.Help()
		},
	}
	cmd.PersistentFlags().StringVarP(&opts.configPath, "config", "c", "", "config file path")
	cmd.CompletionOptions.DisableDefaultCmd = true
	cmd.Version = version.Version
	cmd.SetVersionTemplate(version.Text())

	cmd.AddCommand(newRunCommand(opts))
	cmd.AddCommand(newConfigCommand(opts))
	cmd.AddCommand(newVersionCommand())
	return cmd
}

func newVersionCommand() *cobra.Command {
	return &cobra.Command{
		Use:   "version",
		Short: "show version information",
		Args:  cobra.NoArgs,
		Run: func(cmd *cobra.Command, args []string) {
			fmt.Fprint(cmd.OutOrStdout(), versionText())
		},
	}
}

func versionText() string {
	return version.Text()
}

func registerConfigOverrideFlags(cmd *cobra.Command) {
	config.RegisterOverrideFlags(cmd.Flags())
}
