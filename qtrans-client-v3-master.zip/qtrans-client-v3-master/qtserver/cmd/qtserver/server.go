package main

import (
	"context"
	"fmt"
	"log/slog"
	"net"
	"net/http"
	"strings"
	"time"

	"qtserver/internal/businessevents"
	"qtserver/internal/config"
	"qtserver/internal/handlers"
	"qtserver/internal/logx"
	"qtserver/internal/misc"

	"github.com/gin-gonic/gin"
)

func initGinLogger() {
	gin.DefaultWriter = logx.GetGinLogger()
	gin.DefaultErrorWriter = logx.GetGinLogger()
}

func setupRouter(cfg *config.Config, fatal func(error)) (http.Handler, error) {
	if err := handlers.InitHandlers(cfg, fatal); err != nil {
		return nil, err
	}
	router, err := newHTTPRouter(cfg)
	if err != nil {
		return nil, err
	}
	registerRoutes(router.Group(misc.QtserverAPIPrefix), cfg)
	return router, nil
}

func registerRoutes(router gin.IRoutes, cfg *config.Config) {
	router.GET("/capabilities", handlers.CapabilitiesHandler)
	router.POST("/taskid", handlers.TaskIDHandler)
	router.GET("/files/list", handlers.FileListHandler)
	if cfg.Server.ReadEnabled {
		router.POST("/d/grant", handlers.DownloadGrantHandler)
		router.POST("/d/small", handlers.DownloadSmallHandler)
		router.POST("/d/small-v2", handlers.DownloadSmallV2Handler)
		router.POST("/d/verify", handlers.VerifyHandler)
		router.GET("/d/down/*objectKey", handlers.DownloadHandler)
	}
	if cfg.Server.WriteEnabled {
		router.POST("/uploads", handlers.CanonicalUploadInitHandler)
		router.GET("/uploads/:session_id", handlers.CanonicalUploadGetHandler)
		router.GET("/uploads/:session_id/chunks/:chunk_index", handlers.CanonicalUploadChunkGetHandler)
		router.PATCH("/uploads/:session_id/chunks/:chunk_index", handlers.CanonicalUploadPatchHandler)
		router.POST("/uploads/:session_id/chunks/:chunk_index/finalize", handlers.CanonicalUploadFinalizeHandler)
		router.POST("/uploads/:session_id/complete", handlers.CanonicalUploadCompleteHandler)
		router.POST("/uploads/:session_id/cancel", handlers.CanonicalUploadCancelHandler)
		router.POST("/uploads/:session_id/release", handlers.CanonicalUploadReleaseHandler)
		router.POST("/files/mkdir", handlers.FileMkdirHandler)
		router.POST("/files/move", handlers.FileMoveHandler)
		router.POST("/files/delete", handlers.FileDeleteHandler)
		router.POST("/files/create", handlers.FileCreateHandler)
	}
}

func newHTTPRouter(cfg *config.Config) (*gin.Engine, error) {
	router := gin.New()
	router.RedirectTrailingSlash = false
	router.RedirectFixedPath = false
	router.HandleMethodNotAllowed = true
	trustedProxies := []string(nil)
	if cfg != nil {
		trustedProxies = cfg.Server.TrustedProxies
	}
	if err := router.SetTrustedProxies(trustedProxies); err != nil {
		return nil, fmt.Errorf("configure trusted proxies: %w", err)
	}
	router.Use(requestLoggerMiddleware())
	router.Use(businessLoggingGateMiddleware())
	router.Use(transferProgressTimeoutMiddleware())
	router.Use(gin.Recovery())
	router.NoRoute(func(c *gin.Context) {
		c.JSON(http.StatusNotFound, handlers.ErrorResponse{Code: http.StatusNotFound, ReasonCode: handlers.ReasonRouteNotFound, Message: "route not found"})
	})
	router.NoMethod(func(c *gin.Context) {
		c.JSON(http.StatusMethodNotAllowed, handlers.ErrorResponse{Code: http.StatusMethodNotAllowed, ReasonCode: "METHOD_NOT_ALLOWED", Message: "method not allowed"})
	})
	return router, nil
}

func businessLoggingGateMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		if isBusinessEventProducingRequest(c.Request.Method, c.Request.URL.Path) && !handlers.BusinessLoggingHealthy() {
			c.AbortWithStatusJSON(http.StatusServiceUnavailable, handlers.ErrorResponse{
				Code:       http.StatusServiceUnavailable,
				ReasonCode: businessevents.ReasonBusinessLogUnavailable,
				Message:    "business event log is unavailable",
			})
			return
		}
		c.Next()
	}
}

func isBusinessEventProducingRequest(method, requestPath string) bool {
	if !strings.HasPrefix(requestPath, misc.QtserverAPIPrefix) {
		return false
	}
	relative := strings.TrimPrefix(requestPath, misc.QtserverAPIPrefix)
	switch {
	case method == http.MethodPost && (relative == "/uploads" || relative == "/d/small" || relative == "/d/small-v2" || relative == "/d/verify"):
		return true
	case method == http.MethodGet && strings.HasPrefix(relative, "/d/down/"):
		return true
	case strings.HasPrefix(relative, "/uploads/"):
		parts := strings.Split(strings.Trim(relative, "/"), "/")
		if method == http.MethodPatch && len(parts) == 4 && parts[0] == "uploads" && parts[2] == "chunks" {
			return true
		}
		if method == http.MethodPost && len(parts) == 5 && parts[0] == "uploads" && parts[2] == "chunks" && parts[4] == "finalize" {
			return true
		}
		return method == http.MethodPost && len(parts) == 3 && parts[0] == "uploads" && parts[2] == "complete"
	default:
		return false
	}
}

func requestLoggerMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		taskID := c.GetHeader("X-Task-ID")
		taskPID := c.GetHeader("X-Task-PID")
		enterpriseID := c.GetHeader("X-Enterprise-ID")
		logger := slog.Default().With(
			"task_id", taskID,
			"taskpid", taskPID,
			"enterprise_id", enterpriseID,
			"method", c.Request.Method,
			"path", c.Request.URL.Path,
			"remote_addr", resolveRequestRemoteAddr(c),
			"peer_addr", c.Request.RemoteAddr,
		)
		c.Set("logger", logger)
		logger.Debug("incoming request")
		c.Next()
		logger.Info("request completed", "status", c.Writer.Status(), "response_size", c.Writer.Size())
	}
}

func resolveRequestRemoteAddr(c *gin.Context) string {
	peerAddr := strings.TrimSpace(c.Request.RemoteAddr)
	clientIP := strings.TrimSpace(c.ClientIP())
	if clientIP == "" {
		return peerAddr
	}
	peerHost := peerAddr
	if host, _, err := net.SplitHostPort(peerAddr); err == nil {
		peerHost = host
	}
	if clientIP == peerHost {
		return peerAddr
	}
	return clientIP
}

func StartGinServer(ctx context.Context, cfg *config.Config) error {
	initGinLogger()
	serviceCtx, cancelService := context.WithCancel(context.Background())
	defer cancelService()
	fatalCh := make(chan error, 1)
	reportFatal := func(err error) {
		if err == nil {
			return
		}
		select {
		case fatalCh <- err:
		default:
		}
	}
	router, err := setupRouter(cfg, reportFatal)
	if err != nil {
		return err
	}
	defer handlers.CloseHandlers()
	handlers.StartHashWorkers(serviceCtx)
	handlers.StartBusinessEventRecovery(serviceCtx, slog.Default().With("component", "BusinessEventRecovery"))
	handlers.StartCanonicalUploadMaintenance(serviceCtx, slog.Default().With("component", "UploadMaintenance"))
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	server := &http.Server{
		Addr:              addr,
		Handler:           router,
		ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout:       120 * time.Second,
	}
	serveErr := make(chan error, 1)
	go func() {
		err := server.ListenAndServe()
		if err == http.ErrServerClosed {
			err = nil
		}
		serveErr <- err
	}()
	go monitorFatalDependencies(serviceCtx, cfg, reportFatal)

	var fatalErr error
	select {
	case <-ctx.Done():
		slog.Info("shutting down HTTP server", "reason", "signal")
	case fatalErr = <-fatalCh:
		slog.Error("fatal dependency failure; shutting down", "error", fatalErr)
	case err := <-serveErr:
		cancelService()
		return err
	}
	cancelService()
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer shutdownCancel()
	if err := server.Shutdown(shutdownCtx); err != nil {
		_ = server.Close()
		if fatalErr == nil {
			return fmt.Errorf("HTTP server shutdown: %w", err)
		}
	}
	<-serveErr
	if fatalErr != nil {
		return fmt.Errorf("fatal dependency failure: %w", fatalErr)
	}
	return nil
}

func monitorFatalDependencies(ctx context.Context, cfg *config.Config, report func(error)) {
	monitorFatalDependenciesWithCheck(ctx, cfg, 5*time.Second, handlers.CheckFatalDependencies, report)
}

func monitorFatalDependenciesWithCheck(ctx context.Context, cfg *config.Config, interval time.Duration, check func(context.Context) error, report func(error)) {
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			checkTimeout := 5 * time.Second
			if cfg != nil && strings.TrimSpace(cfg.Identity.Mode) == "oauth2-introspection" {
				identityTimeout := time.Duration(cfg.Identity.TimeoutSeconds) * time.Second
				if identityTimeout > checkTimeout {
					checkTimeout = identityTimeout
				}
			}
			checkCtx, cancel := context.WithTimeout(ctx, checkTimeout)
			err := check(checkCtx)
			cancel()
			if err != nil {
				report(err)
				return
			}
		}
	}
}
