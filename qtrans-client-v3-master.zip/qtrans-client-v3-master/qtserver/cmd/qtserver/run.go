package main

import (
	"context"
	"fmt"
	"log/slog"
	"os/signal"
	"syscall"

	"qtserver/internal/config"
	"qtserver/internal/logx"

	"github.com/spf13/cobra"
)

func newRunCommand(rootOpts *rootOptions) *cobra.Command {
	cmd := &cobra.Command{
		Use:   "run",
		Short: "run qtserver",
		Args:  cobra.NoArgs,
		RunE: func(cmd *cobra.Command, args []string) error {
			configPath, err := config.ResolveConfigPath(rootOpts.configPath)
			if err != nil {
				return err
			}
			fmt.Fprintf(cmd.ErrOrStderr(), "qtserver starting, config=%s\n", configPath)

			cfg, err := config.Load(config.LoadOptions{ConfigPath: rootOpts.configPath, Flags: cmd.Flags()})
			if err != nil {
				return fmt.Errorf("failed to load configuration: %w", err)
			}
			if err := logx.InitLogger(cfg); err != nil {
				return fmt.Errorf("failed to initialize logger: %w", err)
			}
			if err := config.PrepareRuntimeDirectories(cfg); err != nil {
				return fmt.Errorf("failed to prepare runtime directories: %w", err)
			}

			ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
			defer stop()
			if err := StartGinServer(ctx, cfg); err != nil {
				slog.Error("server exited with error", "error", err)
				return err
			}
			return nil
		},
	}
	registerConfigOverrideFlags(cmd)
	return cmd
}
