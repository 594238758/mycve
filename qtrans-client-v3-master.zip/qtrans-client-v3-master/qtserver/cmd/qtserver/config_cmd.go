package main

import (
	"fmt"

	"qtserver/internal/config"

	"github.com/spf13/cobra"
)

func newConfigCommand(rootOpts *rootOptions) *cobra.Command {
	cmd := &cobra.Command{
		Use:   "config",
		Short: "configuration utilities",
		Args:  cobra.NoArgs,
		RunE: func(cmd *cobra.Command, args []string) error {
			return cmd.Help()
		},
	}
	cmd.AddCommand(newConfigValidateCommand(rootOpts))
	cmd.AddCommand(newConfigGenDemoCommand(rootOpts))
	cmd.AddCommand(newConfigGenNginxCommand(rootOpts))
	return cmd
}

func newConfigValidateCommand(rootOpts *rootOptions) *cobra.Command {
	cmd := &cobra.Command{
		Use:   "validate",
		Short: "validate configuration",
		Args:  cobra.NoArgs,
		RunE: func(cmd *cobra.Command, args []string) error {
			configPath, err := config.ResolveConfigPath(rootOpts.configPath)
			if err != nil {
				return err
			}
			if _, err := config.Load(config.LoadOptions{ConfigPath: rootOpts.configPath, Flags: cmd.Flags()}); err != nil {
				return fmt.Errorf("configuration validation failed: %w", err)
			}
			fmt.Fprintf(cmd.OutOrStdout(), "configuration is valid: %s\n", configPath)
			return nil
		},
	}
	registerConfigOverrideFlags(cmd)
	return cmd
}

func newConfigGenDemoCommand(rootOpts *rootOptions) *cobra.Command {
	var force bool
	cmd := &cobra.Command{
		Use:   "gendemo",
		Short: "generate demo configuration",
		Args:  cobra.NoArgs,
		RunE: func(cmd *cobra.Command, args []string) error {
			path, err := config.WriteDemoConfig("", force)
			if err != nil {
				return err
			}
			fmt.Fprintf(cmd.OutOrStdout(), "generated demo config: %s\n", path)
			return nil
		},
	}
	cmd.Flags().BoolVar(&force, "force", false, "overwrite existing config file")
	return cmd
}

func newConfigGenNginxCommand(rootOpts *rootOptions) *cobra.Command {
	var outputDir string
	cmd := &cobra.Command{
		Use:   "gennginx",
		Short: "generate nginx http, server and logrotate configs for qtserver",
		Args:  cobra.NoArgs,
		RunE: func(cmd *cobra.Command, args []string) error {
			cfg, err := config.Load(config.LoadOptions{ConfigPath: rootOpts.configPath})
			if err != nil {
				return fmt.Errorf("failed to load configuration: %w", err)
			}
			paths, err := config.WriteNginxConfigs(cfg, outputDir)
			if err != nil {
				return fmt.Errorf("failed to generate nginx configs: %w", err)
			}
			fmt.Fprintf(cmd.OutOrStdout(), "generated nginx http config: %s\n", paths.HTTP)
			if !cfg.Server.NginxDownloadEnabled() {
				fmt.Fprintf(cmd.OutOrStdout(), "nginx_acc is empty or read is disabled; generated gateway proxy locations only: %s\n", paths.Locations)
			} else {
				fmt.Fprintf(cmd.OutOrStdout(), "generated nginx locations: %s\n", paths.Locations)
			}
			fmt.Fprintf(cmd.OutOrStdout(), "generated nginx logrotate config: %s\n", paths.Logrotate)
			return nil
		},
	}
	cmd.Flags().StringVarP(&outputDir, "output", "o", "", "output directory for qtserver_http.conf, qtserver_locations.conf and qtserver-nginx.logrotate")
	return cmd
}
