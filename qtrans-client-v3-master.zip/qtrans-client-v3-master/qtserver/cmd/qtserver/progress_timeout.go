package main

import (
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

const transferStallTimeout = 60 * time.Second

type progressBody struct {
	io.ReadCloser
	touch func()
}

func (r *progressBody) Read(p []byte) (int, error) {
	n, err := r.ReadCloser.Read(p)
	if n > 0 {
		r.touch()
	}
	return n, err
}

type progressWriter struct {
	gin.ResponseWriter
	touch func()
}

func (w *progressWriter) Write(p []byte) (int, error) {
	w.touch()
	return w.ResponseWriter.Write(p)
}

func (w *progressWriter) WriteString(value string) (int, error) {
	w.touch()
	return w.ResponseWriter.WriteString(value)
}

func (w *progressWriter) ReadFrom(reader io.Reader) (int64, error) {
	// Hide the underlying ReaderFrom method so every copied block passes through
	// Write and refreshes the progress deadline.
	return io.Copy(struct{ io.Writer }{Writer: w}, reader)
}

func transferProgressTimeoutMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		controller := http.NewResponseController(c.Writer)
		if c.Request.Method == http.MethodPatch {
			touchRead := func() { _ = controller.SetReadDeadline(time.Now().Add(transferStallTimeout)) }
			touchRead()
			c.Request.Body = &progressBody{ReadCloser: c.Request.Body, touch: touchRead}
			defer controller.SetReadDeadline(time.Time{})
		}
		if strings.HasPrefix(c.Request.URL.Path, "/qtserver/v1/d/down/") {
			touchWrite := func() { _ = controller.SetWriteDeadline(time.Now().Add(transferStallTimeout)) }
			c.Writer = &progressWriter{ResponseWriter: c.Writer, touch: touchWrite}
			touchWrite()
			defer controller.SetWriteDeadline(time.Time{})
		}
		c.Next()
	}
}
