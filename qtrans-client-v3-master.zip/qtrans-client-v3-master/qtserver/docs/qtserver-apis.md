# Qtserver v1 API

所有接口精确挂载在 `/qtserver/v1`。不注册旧别名，不自动修正尾随 `/`。未知路由返回 `404 ROUTE_NOT_FOUND`，已注册路由的错误 method 返回 405。业务错误 JSON 至少包含 `code`、`reason_code`、`message`。

## 公共接口

- `GET /capabilities`：无需认证，公布 API major、能力开关、固定及配置限制和 hash algorithms。
- `POST /taskid`：无需认证，返回一个新的 UUID v4 task ID。

`POST /taskid` 不接收日志 metadata，不创建服务端 Task 对象，不保存状态，也不输出原始业务事件。Task ID 只作为文件活动关联值；它不参与授权、session ownership、grant HMAC 或业务幂等。

携带 `X-Task-ID` 的请求可以同时携带 `X-Task-PID` 与 `X-Enterprise-ID`。后两项允许为空，分别是不透明的外部任务和企业日志关联值：Qtserver 将当前 header 值写入请求运行日志和该请求产生的 schema v1 原始业务事件，但不使用它们进行认证、授权、tenant/principal 解析、路径选择、grant/HMAC、session ownership、幂等或业务结果判断。Canonical upload session 在 init 时固定初始 `(task_id, taskpid, enterprise_id)`，后续 session 事件继续使用整组初始值；后续请求的当前值只影响请求运行日志。API response 不返回这两个标签

文件日志 metadata 使用以下三个 request headers：

| Header           | 值      | 说明                  |
| ---------------- | ------ | ------------------- |
| `Client-ID`      | string | 客户端持久设备 ID，仅作为日志上下文 |
| `Client-OS`      | string | 客户端系统类型             |
| `Client-Version` | string | qtransc 版本          |

上传 init 和 small download 必须同时携带三项 metadata。普通下载 `/d/down` 或 `/d/verify` 中三项全部存在表示该文件的注册请求，全部不存在表示后续请求，只出现一部分会被拒绝。Qtserver 使用配置和可信服务端事实补齐 task type、principal、client/server IP、文件路径、大小及服务端信息；客户端不能提交这些字段覆盖服务端事实。

业务日志的 `client_username` 使用身份服务认证结果中的邮箱，`principal_id` 继续使用稳定用户 ID。邮箱不可用时写空字符串，匿名用户写 `anonymous`。客户端无需增加 header，也不能通过登录名或自报邮箱覆盖该值；取值规则见 [`config.md`](config.md)，日志字段及示例见[服务端业务日志说明](../../docs/server-business-logging.md)。

文件 API 需要认证时使用 `Authorization: Bearer <token>`。当 capabilities 中 `anonymous.read=true` 时，不携带 `Authorization` 的 `GET /files/list` 映射到内置 `anonymous` principal；匿名下载还要求全局 `download` capability 可用。匿名写不能省略认证；当 `anonymous.write=true` 时，写请求必须携带固定公开 token `00000000-0000-4000-8000-000000000000`。该 token 是协议常量而不是 secret，不应作为访问控制手段。

当 `identity.mode="oauth2-introspection"` 时，普通用户凭据严格按 RFC 6750 解析：只接受 `Authorization: Bearer <token>`，scheme 不区分大小写；裸 token、其他 scheme、空 Bearer 或不合法的 bearer token 字符串直接返回 `401 INVALID_TOKEN`，不会调用 provider。该严格规则不改变既有 `auth`、`fake`、`off` mode 的兼容解析。

新 mode 对每个普通用户请求调用一次配置的 RFC 7662 endpoint，不使用 Redis 或进程内 token cache。`active=true` 且包含非空 string `sub` 时，Qtserver 原样把 `sub` 作为 principal ID，并继续在本地完成文件、session 和 grant 授权；scope、role 和其他 claims 不参与授权。`active=false` 返回 `401 INVALID_TOKEN`。连接、timeout、TLS、HTTP status 或 response 协议错误返回 `503 DEPENDENCY_UNAVAILABLE`，并触发当前 Qtserver 进程 graceful shutdown。完整配置和生命周期见 [`config.md`](config.md)。

该 response 的可选顶层 `email` 仅用于业务日志；缺失、null、非 string 或空邮箱不影响认证，也不触发上述依赖故障处理。

`anonymous` 是内置无密码用户，不是下载类型。它与普通用户使用相同的上传、下载和日志协议；Qtserver 不为它查询身份服务，可信身份固定为 `principal_id=anonymous`。

客户端必须先查询 capabilities。`read` 与 `download` 同为内容下载开关；`write` 与 `upload` 同为全部远端 mutation 开关；`file_management` 始终表示 canonical list 路由可用，不能单独表示 mutation 已获准。API v1 的固定关键限制为：logical path 1024 bytes、segment 255 bytes、list 100000 entries、grant 1000 files、upload chunk 104857600 bytes；`limits.max_file_bytes` 是当前有效的单文件内容传输上限；small download 的 `small_files`、`small_file_bytes` 与 `small_total_bytes` 是配置限制，以 capabilities 当前返回值为准。算法为 `xxh3_128` 与 `layered_xxh3_128_v1`。

## logical path 与文件管理

logical path 是以 `/` 开头的 UTF-8 绝对路径。重复 slash 会合并，非根尾随 slash 会去除；`.`、`..`、反斜杠、NUL、超长路径或 segment 会被拒绝。

```text
GET  /files/list?path=/docs
POST /files/mkdir  {"path":"/docs"}
POST /files/move   {"source":"/a","destination":"/b"}
POST /files/delete {"path":"/docs"}
POST /files/create {"path":"/empty","overwrite":false}
```

`list` 始终注册，独立于下载和 mutation 开关；无凭据 caller 只有在 `anonymous.read=true` 时可浏览 anonymous 空间，普通用户使用有效 bearer token 浏览自己的空间。`list` 只返回直接子项、不排序、不分页，并返回 `truncated`。entry 使用 `path,type,status`，symlink 额外使用 `target_type`，特殊节点使用 `special_type`。mutation POST 使用严格 JSON、2 MiB 上限和未知字段拒绝。

单文件大小限制不改变 list 结果：超过 `limits.max_file_bytes` 的普通文件仍以实际 `size` 返回。内容传输时，upload init、grant、small 和 direct download 会检查该限制；超限返回 HTTP `413 FILE_TOO_LARGE`，错误 JSON 除 `code`、`reason_code`、`message` 外还包含 `file_size` 与 `max_file_bytes`。grant batch 中只要有一个文件超限，整个 batch 不会签发任何 grant。

默认配置下，普通用户家目录缺失时 list `/` 返回 200 空 entries 且不创建目录。当服务端同时配置 `user_home_init_on_list=true` 和 `write_enabled=true` 时，已认证普通用户首次 list `/` 会在 principal namespace lock 内创建家目录及全部 `user_home_init_dirs`，再以不变的响应结构返回初始化后的 entries；客户端不传入额外 query 字段。已有家目录不会补建 init dirs，非根 list 和 anonymous 空间不触发该流程。锁冲突返回 `409 NAMESPACE_BUSY` 和 `Retry-After: 1`；创建或初始化失败（包括损坏的家目录 symlink）返回 `500 HOME_INITIALIZATION_FAILED`，且不会替换损坏节点。

## 下载

当 `read`/`download` capability 被关闭时，以下全部下载路由均不注册并返回 `404 ROUTE_NOT_FOUND`；这不影响 `GET /files/list`。

```text
POST /d/grant
POST /d/small
GET  /d/down/{logical-path}?grant=...
POST /d/verify
```

grant/small/verify body 中的 `object_key` 必须是 logical absolute path。grant 保持请求顺序并绑定 body `taskid`；`X-Task-ID` 只用于日志关联，缺失或与 body/grant task ID 不同均不影响授权。`X-Task-PID` 与 `X-Enterprise-ID` 只随当前请求记录，不参与一致性校验。`down` 支持 GET full 与单 Range，不注册 HEAD。file verify 无 hash 时返回 `202 HASH_PENDING` 与 `Retry-After: 5`；hash 可用时始终返回 200，mismatch 使用 `match=false`。chunk verify 同步计算 `xxh3_128`。

普通 `/d/down` GET 必须携带非负 `X-QT-Chunk-Index`，包括完整 GET。逻辑分片续传时 Range 可以推进，但 chunk index 保持不变。Small download 在服务端完整写完单个 tar entry 后直接形成该文件成功事实；客户端完成 manifest hash 校验后不再调用服务端 `/d/verify`。普通下载仍以整文件 `/d/verify` matched 作为成功事实。

`/d/grant`、`/d/small` 和 `/d/down` 在准备成功响应前均检查当前普通文件的大小；即使 grant 已在此前签发，direct path（包括 Nginx internal redirect）观察到文件已超过 `max_file_bytes` 时仍返回 `413 FILE_TOO_LARGE`，不发送内容 bytes 或内部重定向。

Qtserver 不提供客户端业务 event、task state 或 file result 上报 API。原始业务事件只由 Qtserver 和 Nginx 根据传输 API 已经发生的服务端事实输出。

当前 producer 输出严格 schema v1 JSONL envelope，公共字段恰好为 `schema_version`、`event_type`、`occurred_at`、`task_id`、`taskpid`、`enterprise_id`、`file_key` 和 `payload`；`schema_version`固定为整数 `1`，两个辅助标签始终存在且允许为空字符串。缺少 `enterprise_id` 的旧七字段开发事件无效，不提供默认值兼容。X-Accel 下载由 Qtserver 通过 `X-QT-Log-Task-PID` 与 `X-QT-Log-Enterprise-ID` 把可信日志值交给 Nginx；Nginx 只能使用 upstream response handoff 构造事件，全部九项 `X-QT-Log-*` header 都必须对客户端隐藏。

## 业务日志可用性错误

需要在业务动作前持久化的注册事件写入失败时，接口返回 `503 BUSINESS_LOG_UNAVAILABLE`，且不会开始对应文件活动。文件已经原子发布或 response 已经实际发送后的日志写入失败不会回滚真实业务结果，但实例会进入 logging-unhealthy，并拒绝后续会产生原始业务事件的 API。完整事件、状态机和可靠性契约见 [原始业务事件 OpenSpec](../../openspec/specs/raw-business-event-log/spec.md)。

## canonical resumable upload

```text
POST  /uploads
GET   /uploads/{session_id}
GET   /uploads/{session_id}/chunks/{chunk_index}
PATCH /uploads/{session_id}/chunks/{chunk_index}
POST  /uploads/{session_id}/chunks/{chunk_index}/finalize
POST  /uploads/{session_id}/complete
POST  /uploads/{session_id}/cancel
POST  /uploads/{session_id}/release
```

init body：

```json
{"object_key":"/docs/a.bin","file_size":123,"file_hash":"<layered hash>","hash_algorithm":"layered_xxh3_128_v1","overwrite":false}
```

服务生成 opaque lowercase UUID v4 session。PATCH 要求 `application/octet-stream`、positive `Content-Length` 和 `Upload-Offset`，成功返回 204 及最新 offset/state header。每个 chunk 上传完整后，客户端用 `{"chunk_hash":"<xxh3_128>"}` 调用 finalize。所有 chunks verified 后调用 complete；空 body 等价 `{}`。complete 是唯一发布 cache 的操作，成功返回正式 `file_hash` 和 `layered_xxh3_128_v1`。no-overwrite regular file 通过同文件系统 hard link 原子创建 target，committed 状态保存后再清理 cache 名称；target 已存在时返回 409且不覆盖。overwrite 继续通过原子 rename 替换目标。cache 与 target 跨文件系统返回500 `CROSS_DEVICE_PUBLISH`，文件系统不支持原子 hard-link publish 返回500 `ATOMIC_NOREPLACE_UNSUPPORTED`。

init 的 `file_size` 允许 `0..limits.max_file_bytes`。超过该上限时，已完成鉴权的请求返回 `413 FILE_TOO_LARGE` 和 `file_size`、`max_file_bytes`，不会创建 Redis session、cache 文件或业务登记。

cancel 只删除 active session，release 只删除 committed metadata；missing 或 other-principal 均返回 204。暂停不得调用 cancel。
