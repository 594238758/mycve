# qtserver 配置

本文说明当前严格配置 schema。除下文明确列出的旧 `[postgres].dsn` 兼容输入外，未知字段和已删除字段都会使 `validate` 或启动失败；环境变量不会覆盖配置

## 命令

```bash
qtserver run -c /absolute/qtserver_config.toml
qtserver config validate -c /absolute/qtserver_config.toml
qtserver config gendemo [--force]
qtserver config gennginx -c /absolute/qtserver_config.toml [-o FILE]
```

`run` 只允许 `--host`、`--port`、`--loglevel`、`--logpath` 覆盖配置。`config validate` 不连接 Redis 或身份服务，也不创建目录。Qtserver 没有数据库 migration 命令。

`config gennginx` 同时生成 `qtserver_http.conf` 和 `qtserver_locations.conf`。默认写入 qtserver 二进制所在目录；指定 `-o FILE` 时，`FILE` 是 locations 配置路径，HTTP 配置固定写入其同目录的 `qtserver_http.conf`。前者必须在 Nginx `http` 块引入，后者必须在目标 `server` 块引入。

## `[server]`

```toml
[server]
host = "127.0.0.1"
port = 10001
instance_id = "qtserver-prod-01"
external_ip = "192.0.2.10"
external_address = "https://transfer.example.com"
trusted_proxies = ["127.0.0.1", "::1"]
user_home_root = "/opt/qtrans/qtserver/data/users"
user_home_init_on_list = false
temp_root = "/opt/qtrans/qtserver/data/upload-temp"
read_enabled = true
write_enabled = true
anonymous_enabled = false
nginx_acc = "/qtserver/internal-download"

[[server.user_home_init_dirs]]
name = "gsa1"
```

`user_home_root` 必须是已存在且自身不是 symlink 的绝对目录。用户空间固定映射为 `<user_home_root>/<principal_id>`；匿名 principal 使用固定保留名 `anonymous`，对应 `<user_home_root>/anonymous`。`temp_root` 在启用写能力时必填，必须是绝对路径且不能位于任何用户 home 内，服务会以 `0700` 创建或收紧它。

`instance_id` 是写入文件注册上下文的稳定部署实例名。`external_ip` 是无法从可信反向代理取得实际入口 IP 时的回退值；`external_address` 保留为服务端对外地址配置，不进入当前 schema v1 原始事件。三者缺省时分别从 hostname、监听 IP和监听地址推导；生产配置应显式填写，避免多网卡环境产生歧义。

`read_enabled` 只决定下载路由是否注册：关闭时 `/d/grant`、`/d/small`、`/d/verify` 和 `/d/down/*` 返回 `404 ROUTE_NOT_FOUND`，但不关闭 `GET /files/list`。`write_enabled` 是全部远端 mutation 的总开关，控制 canonical upload 以及 `mkdir`、`move`、`delete`、`create`。`GET /files/list` 始终注册；`anonymous_enabled` 决定无 Authorization 的 list 是否浏览 anonymous 空间，关闭时无凭据 list 返回认证错误，携带有效普通用户凭据的 list 不受影响。因此 `read_enabled = false` 仍会向已获准的 caller 暴露目录名、大小和修改时间等元数据。

`user_home_init_on_list` 默认 `false`。只有它与 `write_enabled` 同时为 `true` 时，已认证普通用户首次 list `/` 才会在缺失家目录时创建家目录及全部 `user_home_init_dirs`，随后返回初始化后的目录列表；`write_enabled=false` 时该字段不产生目录副作用。已有家目录不会补建 init dirs，也不会重新 chmod/chown；非根 list 和 anonymous 空间不受该字段影响。Qtserver 使用严格配置 schema，旧版本会拒绝这个新字段，回滚到旧版本前必须从配置中删除它；已经创建的家目录不会自动删除。

`nginx_acc` 是 Nginx internal location 前缀。`user_home_init_dirs` 只允许一级名称；可选 `uid`/`gid` 必须成对出现，可选 `mode` 使用八进制字符串。

## Redis 与旧配置兼容

```toml
[redis]
addr = "127.0.0.1:6379"
password = ""
db = 0
key_prefix = "qtserver"
```

Redis 是 Qtserver 唯一的共享状态依赖，保存上传 session/chunk、可重建 hash cache、协调锁和 `auth` mode 的短期身份缓存。部署必须使用持久 volume、`appendonly yes`、`appendfsync everysec` 和 `maxmemory-policy noeviction`。Qtserver 在监听前校验这些配置及 AOF 写入状态，运行期每五秒继续检查；连接、协议、认证、AOF 或写入故障会触发最多 30 秒 graceful shutdown。配置输出会隐藏 Redis password、HMAC secret、fake token 和 Authorization。

为兼容存量配置，Qtserver 接受只含字符串 `dsn` 的旧 `[postgres]` section，但完全忽略该值，不校验、不连接、不执行 migration，也不在配置输出中保留它。新配置不应再写该 section；其中出现其他字段或 `dsn` 不是字符串时，严格校验仍会失败。

## `[transfer]`

```toml
[transfer]
hmac_secret = "replace-with-a-long-random-secret"
grant_ttl_seconds = 900
max_file_bytes = 1099511627776
max_download_files = 1000
max_small_files = 100
max_small_total_bytes = 134217728
max_small_file_bytes = 4194304
file_hash_revalidate_seconds = 86400
file_hash_retention_seconds = 2592000
hash_worker_count = 2
hash_queue_size = 1000
upload_session_retention_seconds = 86400
```

`max_file_bytes` 是上传和下载内容共用的单文件上限，默认 `1099511627776`（1 TiB），必须是正的 `int64`。`max_small_file_bytes` 不得大于它。该限制不影响 `GET /files/list`：超限普通文件仍会按实际大小列出；但 upload init、download grant、small download 和 direct download 都会拒绝其内容传输。

上传 chunk 固定为 104857600 bytes，不能配置。session retention 最小 60 秒；后台 hash worker 使用 Redis queue、lease 和 heartbeat 协调。`file_hash_retention_seconds` 必须大于 `file_hash_revalidate_seconds`，长期不活跃且没有活动计算的 hash cache 可被清理并在下次访问时重建。small download 默认限制为 100 files、单文件 4 MiB、总计 128 MiB。

## identity

`[identity]` 决定 Qtserver 如何把请求凭据转换为普通 principal。部署模板默认使用 `mode = "off"`，这是一种安全默认值：服务不会意外接入身份服务、接受 fake token 或信任外部 bearer token。`identity.mode` 与 `server.anonymous_enabled` 相互独立；模板同时设置 `anonymous_enabled = false` 时，所有需要普通 principal 的文件业务请求都会被拒绝。部署投入业务前，必须选择合适的身份 mode，或明确启用匿名能力及其对应权限。

`[identity]` 的字段含义如下：

| 字段                           | 含义                                                                                                           |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------ |
| `mode`                       | 身份来源模式：`auth`、`fake`、`off`、`oauth2-introspection`。                                                           |
| `auth_base_url`              | 仅 `auth` 使用。既有身份服务的基础地址，Qtserver 会在其后追加 `/userinfo`；不要填写成完整 `/userinfo` 地址。                                  |
| `introspection_endpoint`     | 仅 `oauth2-introspection` 使用。RFC 7662 的完整 introspection URL，例如 `http://127.0.0.1:10020/oauth2/introspect`。    |
| `fake_tokens`                | 仅 `fake` 使用。静态 token 到 principal ID 的映射，例如 `{ "dev-token" = "alice" }`。                                      |
| `timeout_seconds`            | 远程身份请求的超时秒数，必须大于 0。对 `auth` 和 `oauth2-introspection` 生效；`fake`、`off` 不会发起远程请求。未设置时默认为 5 秒。                   |
| `userinfo_cache_ttl_seconds` | 仅 `auth` 使用。`/userinfo` 成功结果在 Redis 中的缓存秒数；未设置时默认为 10 秒，设为 `0` 也会回退到该默认值，不能为负数。`oauth2-introspection` 不缓存结果。 |

只写 `mode` 和所选 mode 实际读取的身份来源字段即可；其他字段应省略，而不是写成空字符串或 `{}`。需要偏离默认 5 秒超时或默认 10 秒 `/userinfo` 缓存时，再显式设置相应调优字段。

### `off`：默认拒绝普通 principal

```toml
[identity]
mode = "off"
```

此模式下所有普通用户凭据均不会获得 principal。它适合作为尚未选择身份服务时的安全默认值；如需匿名读写，仍需单独配置 `server.anonymous_enabled` 和相应能力。

### `auth`：既有 `/userinfo` 服务

```toml
[identity]
mode = "auth"
auth_base_url = "https://identity.example.com/qtrans/auth/v1"
```

Qtserver 向 `<auth_base_url>/userinfo` 请求用户信息，因此 `auth_base_url` 应是服务基础 URL，不能填成完整的 `/userinfo` endpoint。成功结果按默认 10 秒写入 Redis 缓存；需要调整远程超时或缓存时间时，才额外设置 `timeout_seconds` 和 `userinfo_cache_ttl_seconds`。

业务日志的 `client_username` 使用该响应中的邮箱：优先取顶层 `email`，没有可用值时取 `data.email`。例如 `{"sub":"user-42","email":"alice@example.com"}` 会记录 `principal_id=user-42`、`client_username=alice@example.com`。邮箱必须是非空 string，取值时去除首尾空白；缺失、null、其他类型或空白值视为不可用。没有邮箱时日志写空字符串，不回退到用户 ID，也不阻断认证或传输。

缓存同时保留用户 ID 和邮箱，因此缓存命中仍能输出邮箱。升级后首次访问会忽略旧的仅含 ID 的缓存并重新请求身份服务；旧缓存自动过期，无需清空 Redis。邮箱变更最迟在现有缓存过期后用于新请求，已记录的文件上下文不回填。

### `fake`：开发或联调静态 token

```toml
[identity]
mode = "fake"
fake_tokens = { "dev-token-alice" = "alice", "dev-token-bob" = "bob" }
```

映射的 key 是客户端提供的 token，value 是 Qtserver 使用的 principal ID。此模式没有独立邮箱资料，普通用户的业务日志 `client_username` 为空字符串，即使 ID 看起来像邮箱也不会将它作为邮箱。此模式不访问远程身份服务，不应投入正式生产环境。

### `oauth2-introspection`：RFC 7662 provider

```toml
[identity]
mode = "oauth2-introspection"
introspection_endpoint = "http://127.0.0.1:10020/oauth2/introspect"
```

`introspection_endpoint` 必须是包含 scheme 和 host 的绝对 HTTP 或 HTTPS URL。Qtserver 使用精确 endpoint，不追加路径、不跟随 redirect，也不因 HTTP、非 loopback 地址或跨机器访问拒绝配置。该模式固定使用 RFC 6749 `client_secret_basic` 和内置 `client_id=qtserver`、`client_secret=qtserver-introspection`；第三方 provider 必须配置为接受它们。每个普通 Bearer token 都会调用 provider，不使用 token cache，通过 response 的 `active` 和 `sub` 确定身份，授权仍由 Qtserver 本地完成。

Active response 可携带顶层 `email`，例如 `{"active":true,"sub":"user-42","email":"alice@example.com"}`。Qtserver 将邮箱去除首尾空白后用于业务日志 `client_username`，文件归属仍使用 `sub`。缺失、null、非 string 或空邮箱只使日志字段为空，不触发认证失败或进程退出。当前 `qtuser` 不保存或返回邮箱，使用它时普通用户的 `client_username` 为空；需要邮箱展示时，应由身份服务提供实际邮箱。

`oauth2-introspection` 是强依赖。Qtserver 在监听前以随机 UUID v4 probe token 验证 endpoint、内置 client authentication、HTTP status 和 response shape；失败会阻止启动。运行时每五秒 probe，并在健康检查或业务请求第一次发现连接、TLS、timeout、client authentication、非 200 或 malformed response 时触发最多 30 秒 graceful shutdown。标准 `active=false` 只表示无效 token，不触发退出。现有 `auth` identity service 的故障仍是请求级错误，不阻止启动或终止进程。

外部 `/userinfo` 请求失败时会记录结构化错误日志，包含 `auth_url`、失败阶段、最终重试次数、HTTP 状态或 timeout/cause，但不记录 bearer token。Introspection 日志只记录 endpoint、失败阶段、HTTP status 和 timeout/cause，不记录请求 token、Basic credential、form body 或完整 response body。

## `[log]`

`log.file_path` 同时承载调试日志与独立的 `business-events.jsonl`。业务日志复用 `log.rotation`：`enable=true` 时，只有追加下一条完整事件会超过 `max_size` 才轮转；`max_backups` 限制关闭归档数量，`max_age` 只清理超过保留天数的关闭归档，`compress` 只压缩关闭归档。这里没有按时间轮转，正常关闭和重启也不会归档 active 文件。

业务日志 `client_username` 为可信用户邮箱，邮箱不可用时为空字符串；内置匿名用户固定为 `anonymous`。该字段无需新增配置，也不接受客户端自报值。字段和示例见[服务端业务日志说明](../../docs/server-business-logging.md)。

`log.task_type` 只允许字符串 `"0"`（多中心）或 `"1"`（C/S），默认 `"1"`。它只表示场景分类；两种取值下原始事件和最终业务日志都完整收集并原样输出可信的 `server_ip`、`client_id`、`client_os` 等上下文字段，不改变传输协议、授权、文件空间或状态机。`log.file_inactivity_timeout_seconds` 必须大于 0，默认 `86400`；实际值会写入每条 `file.registered`，以后修改配置不会重新解释已有文件活动。该值与 `transfer.upload_session_retention_seconds` 相互独立。

原始业务事件固定输出到 `business-events.jsonl`，大小轮转后的关闭文件名为 `business-events-<UTC timestamp>-<sequence>.jsonl[.gz]`。升级时，Qtserver 会将旧 `business_events.log` active 文件迁移到新名称；若新旧 active 同时存在则拒绝猜测合并。`qtserver.log` 与 `gin.log` 只用于调试。旧 `event.log` 与 `file_transmit.log` 不属于当前协议，也不再提供迁移开关。原始业务事件和调试日志的行为契约见 [`raw-business-event-log`](../../openspec/specs/raw-business-event-log/spec.md)。
