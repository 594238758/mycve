# Qtserver 部署

## 1. 部署 Redis

Qtserver 依赖 Redis 保存共享状态。可以使用已有 Redis，也可以通过 Docker 部署：

```bash
docker volume create qtrans-redis-data

docker run -d --name qtrans-redis \
  --restart unless-stopped \
  -p 127.0.0.1:6379:6379 \
  -v qtrans-redis-data:/data \
  redis:7-alpine redis-server \
    --dir /data \
    --appendonly yes \
    --appendfsync everysec \
    --maxmemory-policy noeviction \
    --requirepass 'replace-with-a-long-random-password'
```

将 Redis 地址和密码写入 Qtserver 配置。生产环境应使用持久化存储，并保持 AOF 和 `noeviction`。

## 2. 部署 Qtserver

将二进制、配置文件和 systemd unit 安装到目标机器：

```bash
sudo install -d /opt/qtrans/qtserver
sudo install -m 0755 qtserver/bin/qtserver /opt/qtrans/qtserver/qtserver
sudo install -m 0644 qtserver/deploy/qtserver_config_default.toml \
  /opt/qtrans/qtserver/qtserver_config.toml
sudo install -m 0644 qtserver/deploy/qtserver.service \
  /etc/systemd/system/qtserver.service
```

按 [`config.md`](config.md) 修改 `/opt/qtrans/qtserver/qtserver_config.toml`，并准备配置中使用的数据目录和日志目录。然后校验配置并启动服务：

```bash
sudo /opt/qtrans/qtserver/qtserver config validate \
  -c /opt/qtrans/qtserver/qtserver_config.toml
sudo systemctl daemon-reload
sudo systemctl enable --now qtserver
sudo systemctl status qtserver
```

业务日志通过身份服务返回的邮箱填写 `client_username`。`auth` 读取 `/userinfo` 的 `email` 或 `data.email`；`oauth2-introspection` 读取 active response 的顶层 `email`。未提供邮箱时写空字符串，匿名用户仍写 `anonymous`。当前 `fake` 和 `qtuser` 不提供邮箱。具体响应示例见 [`config.md`](config.md)。

从记录用户 ID 的旧版本升级时，先让日志接收方支持空字符串，再升级 Qtserver。历史日志保留原值，不自动回填邮箱。`auth` 的旧身份缓存会自然过期，升级无需清空 Redis。

## 3. 部署 Nginx

使用 Qtserver 配置生成 Nginx 所需的两个文件：

```bash
sudo /opt/qtrans/qtserver/qtserver config gennginx \
  -c /opt/qtrans/qtserver/qtserver_config.toml
```

生成的 `qtserver_http.conf` 应在 Nginx 的 `http` 块中引入，`qtserver_locations.conf` 应在对外服务的 `server` 块中引入。可以直接参考 [`deploy/nginx.conf`](../deploy/nginx.conf)，并按实际环境修改监听地址和 TLS 证书路径。

配置完成后检查并重新加载 Nginx：

```bash
sudo nginx -t
sudo systemctl enable --now nginx
sudo systemctl reload nginx
```
