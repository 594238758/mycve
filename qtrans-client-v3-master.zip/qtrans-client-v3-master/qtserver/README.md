# qtserver

`qtserver` 是 `qtrans` 传输体系中的服务端控制面。

当前实现支持：

- [x] `anonymous` 内置用户下载
- [x] 普通用户下载
- [x] 下载哈希校验
- [x] 上传任务号申请
- [x] 上传鉴权
- [x] 上传与上传后哈希校验
- [x] Redis 共享状态
- [x] Nginx `X-Accel-Redirect` 数据面
- [x] 静态 token / HTTP 身份服务两种认证模式

## Build & Test

```bash
# 在仓库根目录同时构建 qtransc 和 qtserver
make build

# 只构建 qtserver
make -C qtserver build

# 查看构建信息
./qtserver/bin/qtserver -v
```

本地单独部署 `qtserver` 时，生成的二进制位于 `qtserver/bin/qtserver`。

## CLI

```bash
qtserver                              # show help
qtserver run -c qtserver_config.toml  # start the service
qtserver config validate -c qtserver_config.toml
qtserver config gendemo
qtserver config gennginx
qtserver version
qtserver -v
```

## Deploy

常规部署文件集中在 `deploy/`：

- [默认 qtserver 配置](deploy/qtserver_config_default.toml)
- [本地覆盖部署脚本](deploy/install_local.sh)
- [qtserver.sh](deploy/qtserver.sh)
- [qtserver.service](deploy/qtserver.service)
- [完整 nginx.conf 示例](deploy/nginx.conf)

`qtserver config gennginx` 会同时生成供 Nginx `http` 块引入的 `qtserver_http.conf` 和供 `server` 块引入的 `qtserver_locations.conf`。

安装步骤和配置对应关系见 [docs/deploy.md](docs/deploy.md)。

## Key Docs

- 配置示例与字段说明：[docs/config.md](docs/config.md)
- 人类可读 API 文档：[docs/qtserver-apis.md](docs/qtserver-apis.md)
- 部署说明（含本地最小部署）：[docs/deploy.md](docs/deploy.md)
- 原始业务日志契约：[raw-business-event-log](../openspec/specs/raw-business-event-log/spec.md)

## 日志边界

`business-events.jsonl` 是 Qtserver 当前写入的原始业务事件 active 文件；达到 `[log.rotation].max_size` 后，关闭段才归档为 `business-events-<UTC timestamp>-<sequence>.jsonl[.gz]`。Nginx 的 X-Accel 完成事实写入 `download_events.log`。`qtserver.log`、`gin.log` 和 Nginx access/error log 只用于排障，不能补齐业务状态。事件与状态机契约见 [`raw-business-event-log`](../openspec/specs/raw-business-event-log/spec.md)，本 README 不重复维护事件清单。
